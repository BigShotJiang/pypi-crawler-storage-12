# Changelog

All notable changes to Synqed will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-11-16

### Added
- Initial release of Synqed
- Agent wrapper for simplified agent creation
- AgentCardBuilder for easy agent card generation
- AgentServer for hosting agents
- SynqedClient for connecting to agents
- TaskDelegator for multi-agent coordination
- Comprehensive test suite (unit, integration, and E2E tests)
- Full documentation (README, GETTING_STARTED, examples)
- Example scripts for basic usage and multi-agent systems

### Features
- **Agent Creation**: Simple API for creating agents with custom logic
- **Server Management**: One-line server setup with background mode
- **Client Communication**: Easy message sending with streaming support
- **Multi-Agent Delegation**: Automatic task routing based on skills
- **Skill-Based Routing**: Intelligent agent selection
- **Broadcasting**: Send tasks to multiple agents simultaneously

### Components
- `Agent` - Core agent wrapper
- `AgentCardBuilder` - Fluent API for building agent cards
- `AgentServer` - Server wrapper with CORS support
- `SynqedClient` - Client with streaming and async support
- `TaskDelegator` - Multi-agent orchestration

### Documentation
- Comprehensive README with quick start
- Getting Started guide with step-by-step instructions
- Example scripts (basic agent, client, multi-agent delegation)
- Full test suite with 127+ tests
- Publishing guide for PyPI

### Dependencies
- a2a-sdk[http-server]>=0.3.0
- pydantic>=2.0.0
- httpx>=0.24.0

[1.0.0]: https://github.com/your-org/synqed-python/releases/tag/v1.0.0

