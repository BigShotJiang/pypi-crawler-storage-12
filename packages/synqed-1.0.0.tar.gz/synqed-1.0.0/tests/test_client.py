"""
Unit tests for the SynqedClient class.
"""

import pytest
from synqed import SynqedClient
from a2a.types import AgentCard


class TestSynqedClient:
    """Tests for the SynqedClient class."""
    
    def test_client_creation_with_url(self):
        """Test creating client with URL."""
        client = SynqedClient(agent_url="http://localhost:8000")
        
        assert client.agent_url == "http://localhost:8000"
        assert client.streaming is True
        assert client.timeout == 30.0
    
    def test_client_creation_with_card(self):
        """Test creating client with agent card."""
        card = AgentCard(
            name="Test Agent",
            description="Test",
            version="1.0.0",
            url="http://localhost:8000",
            skills=[],
            default_input_modes=["text/plain"],
            default_output_modes=["text/plain"],
            capabilities={}
        )
        
        client = SynqedClient(agent_card=card)
        
        assert client._agent_card == card
    
    def test_client_creation_without_url_or_card(self):
        """Test that creating client without URL or card raises error."""
        with pytest.raises(ValueError, match="Either agent_url or agent_card"):
            SynqedClient()
    
    def test_client_repr(self):
        """Test client string representation."""
        client = SynqedClient(agent_url="http://localhost:8000")
        
        repr_str = repr(client)
        
        assert "SynqedClient" in repr_str
        assert "http://localhost:8000" in repr_str
    
    @pytest.mark.asyncio
    async def test_client_context_manager(self):
        """Test client as async context manager."""
        async with SynqedClient(agent_url="http://localhost:8000") as client:
            assert client is not None
    
    @pytest.mark.asyncio
    async def test_client_send_message(self, simple_server):
        """Test sending a message to an agent."""
        client = SynqedClient(agent_url=simple_server.url)
        
        responses = []
        async for response in client.send("Hello"):
            responses.append(response)
        
        # Should get at least one response
        assert len(responses) > 0
        
        # Response should contain echo
        full_response = "".join(responses)
        assert "Echo" in full_response or "Hello" in full_response
        
        await client.close()
    
    @pytest.mark.asyncio
    async def test_client_send_and_wait(self, simple_server):
        """Test sending message and waiting for complete response."""
        client = SynqedClient(agent_url=simple_server.url)
        
        response = await client.send_and_wait("Test message")
        
        assert isinstance(response, str)
        assert len(response) > 0
        
        await client.close()
    
    @pytest.mark.asyncio
    async def test_client_multiple_messages(self, simple_server):
        """Test sending multiple messages."""
        async with SynqedClient(agent_url=simple_server.url) as client:
            response1 = await client.send_and_wait("First message")
            response2 = await client.send_and_wait("Second message")
            
            assert response1 != response2
            assert "First" in response1 or "message" in response1
            assert "Second" in response2 or "message" in response2
    
    @pytest.mark.asyncio
    async def test_client_with_custom_timeout(self, simple_server):
        """Test client with custom timeout."""
        client = SynqedClient(
            agent_url=simple_server.url,
            timeout=10.0
        )
        
        assert client.timeout == 10.0
        
        response = await client.send_and_wait("Test")
        assert isinstance(response, str)
        
        await client.close()
    
    @pytest.mark.asyncio
    async def test_client_streaming_disabled(self, simple_server):
        """Test client with streaming disabled."""
        client = SynqedClient(
            agent_url=simple_server.url,
            streaming=False
        )
        
        assert client.streaming is False
        
        response = await client.send_and_wait("Test")
        assert isinstance(response, str)
        
        await client.close()

