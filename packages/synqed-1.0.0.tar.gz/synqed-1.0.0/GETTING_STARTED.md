# Getting Started with Synqed

Welcome to Synqed! This guide will help you get up and running quickly.

## Installation

### Option 1: From PyPI (once published)
```bash
pip install synqed
```

### Option 2: From Source (Development)
```bash
# Clone or navigate to the Synq directory
cd /path/to/Synq

# Install in development mode
pip install -e .

# Or with all extras
pip install -e ".[all]"
```

### Install Dependencies
```bash
# For running servers
pip install uvicorn

# For development
pip install -e ".[dev]"
```

## Your First Agent in 5 Minutes

### Step 1: Create an Agent

Create a file called `my_agent.py`:

```python
import asyncio
from synqed import Agent, AgentServer

async def my_agent_logic(context):
    """This is where your agent's intelligence goes."""
    user_message = context.get_request_message_text()
    
    # Your custom logic here
    response = f"You said: '{user_message}'. How can I help you?"
    
    return response

async def main():
    # Create the agent
    agent = Agent(
        name="My Helper Agent",
        description="A friendly assistant",
        skills=["conversation", "help"],
        executor=my_agent_logic
    )
    
    # Start the server
    server = AgentServer(agent, port=8000)
    print(f"Server starting at {server.url}")
    await server.start()

if __name__ == "__main__":
    asyncio.run(main())
```

### Step 2: Run Your Agent

```bash
python my_agent.py
```

Your agent is now running at `http://localhost:8000`!

### Step 3: Connect a Client

Create another file called `talk_to_agent.py`:

```python
import asyncio
from synqed import SynqedClient

async def main():
    async with SynqedClient("http://localhost:8000") as client:
        # Send a message and get response
        response = await client.send_and_wait("Hello, agent!")
        print(f"Agent says: {response}")

if __name__ == "__main__":
    asyncio.run(main())
```

Run it:
```bash
python talk_to_agent.py
```

## Next Steps

### Build a Multi-Agent System

```python
from synqed import Agent, TaskDelegator

# Create specialized agents
recipe_agent = Agent(
    name="Recipe Agent",
    skills=["cooking", "recipes"],
    ...
)

weather_agent = Agent(
    name="Weather Agent",
    skills=["weather", "forecast"],
    ...
)

# Set up delegator
delegator = TaskDelegator()
delegator.register_agent(recipe_agent)
delegator.register_agent(weather_agent)

# Submit a task - automatically routed!
result = await delegator.submit_task("Find me a dinner recipe")
```

### Explore Examples

Check out the complete examples in the `examples/` directory:

```bash
# Simple agent
python examples/basic_agent.py

# Client interaction
python examples/client_example.py

# Multi-agent coordination (all-in-one demo)
python examples/multi_agent_delegation.py
```

## Common Patterns

### Pattern 1: Stateless Agent
```python
async def stateless_handler(context):
    message = context.get_request_message_text()
    return process(message)

agent = Agent(name="Stateless", skills=["task"], executor=stateless_handler)
```

### Pattern 2: Stateful Agent
```python
class StatefulAgent:
    def __init__(self):
        self.state = {}
    
    async def handle(self, context):
        user_id = context.user_id  # hypothetical
        self.state[user_id] = ...
        return response

handler = StatefulAgent()
agent = Agent(name="Stateful", skills=["task"], executor=handler.handle)
```

### Pattern 3: Agent with External API
```python
async def api_handler(context):
    message = context.get_request_message_text()
    
    # Call external API
    result = await some_api_call(message)
    
    return f"API returned: {result}"

agent = Agent(name="API Agent", skills=["api"], executor=api_handler)
```

## Configuration Options

### Agent Configuration
```python
agent = Agent(
    name="Advanced Agent",
    description="Does advanced things",
    skills=["skill1", "skill2"],
    executor=handler,
    version="2.0.0",
    default_input_modes=["text/plain", "application/json"],
    default_output_modes=["text/plain"],
    capabilities={
        "streaming": True,
        "push_notifications": False
    }
)
```

### Server Configuration
```python
server = AgentServer(
    agent=agent,
    host="0.0.0.0",  # Listen on all interfaces
    port=8000,
    path_prefix="/a2a/v1",
    enable_cors=True  # Enable CORS for web clients
)
```

### Client Configuration
```python
client = SynqedClient(
    agent_url="http://localhost:8000",
    streaming=True,  # Use streaming responses
    timeout=30.0     # Request timeout in seconds
)
```

## Troubleshooting

### Port Already in Use
```bash
# Error: [Errno 48] Address already in use
# Solution: Use a different port or kill the process using that port
lsof -i :8000  # Find process
kill -9 <PID>  # Kill it
```

### Cannot Connect to Agent
- Make sure the agent server is running
- Check the URL is correct (include `/a2a/v1`)
- Verify the port is accessible

### Import Errors
```bash
# Make sure synqed is installed
pip install -e .

# Or check your Python path
python -c "import synqed; print(synqed.__file__)"
```

## Best Practices

1. **Error Handling**: Always wrap agent logic in try-except
2. **Logging**: Use Python's logging module for debugging
3. **Type Hints**: Add type hints to your agent handlers
4. **Documentation**: Document your agent's skills and capabilities
5. **Testing**: Write tests for your agent logic

## Resources

- 📚 [Full Documentation](README.md)
- 🎯 [Examples Directory](examples/)
- 🌐 [A2A Protocol](https://a2a-protocol.org)
- 💬 Contact Synq Team for support

Happy building! 🚀

