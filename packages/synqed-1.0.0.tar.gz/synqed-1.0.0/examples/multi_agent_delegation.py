"""
Example of multi-agent delegation using TaskDelegator.

This example shows how to:
1. Create multiple specialized agents
2. Register them with a TaskDelegator
3. Submit tasks that automatically get routed to the right agent
"""

import asyncio
from synqed import Agent, AgentServer, TaskDelegator


# Define custom agent executors
async def recipe_agent_executor(context):
    """Agent that handles recipe-related queries."""
    user_message = context.get_request_message_text()
    
    # Simulate recipe search
    return f"Recipe Agent: I found some great recipes for '{user_message}'! Here's a healthy option..."


async def shopping_agent_executor(context):
    """Agent that handles shopping and product queries."""
    user_message = context.get_request_message_text()
    
    # Simulate shopping assistance
    return f"Shopping Agent: I can help you shop for '{user_message}'. Here are some options..."


async def weather_agent_executor(context):
    """Agent that handles weather queries."""
    user_message = context.get_request_message_text()
    
    # Simulate weather lookup
    return f"Weather Agent: Let me check the weather for '{user_message}'... It's sunny!"


async def main():
    # Create specialized agents
    recipe_agent = Agent(
        name="Recipe Agent",
        description="Finds and recommends recipes",
        skills=["recipe_search", "meal_planning", "cooking"],
        executor=recipe_agent_executor,
    )
    
    shopping_agent = Agent(
        name="Shopping Agent",
        description="Helps with shopping and product recommendations",
        skills=["shopping", "product_search", "price_comparison"],
        executor=shopping_agent_executor,
    )
    
    weather_agent = Agent(
        name="Weather Agent",
        description="Provides weather information",
        skills=["weather", "forecast", "climate"],
        executor=weather_agent_executor,
    )
    
    # Start servers for each agent (in background)
    recipe_server = AgentServer(recipe_agent, port=8001)
    shopping_server = AgentServer(shopping_agent, port=8002)
    weather_server = AgentServer(weather_agent, port=8003)
    
    print("Starting agent servers...")
    await asyncio.gather(
        recipe_server.start_background(),
        shopping_server.start_background(),
        weather_server.start_background(),
    )
    
    print(f"✓ Recipe Agent running at {recipe_server.url}")
    print(f"✓ Shopping Agent running at {shopping_server.url}")
    print(f"✓ Weather Agent running at {weather_server.url}")
    print()
    
    # Create a task delegator
    delegator = TaskDelegator()
    
    # Register all agents
    delegator.register_agent(recipe_agent)
    delegator.register_agent(shopping_agent)
    delegator.register_agent(weather_agent)
    
    print(f"TaskDelegator created with {len(delegator.list_agents())} agents")
    print()
    
    # Example 1: Submit tasks and let delegator choose the right agent
    print("=" * 60)
    print("Example 1: Automatic agent selection")
    print("=" * 60)
    
    tasks = [
        "Find me a healthy dinner recipe",
        "What's the weather like today?",
        "Where can I buy fresh vegetables?",
    ]
    
    for task in tasks:
        print(f"\nTask: {task}")
        try:
            result = await delegator.submit_task(task)
            print(f"Result: {result}")
        except Exception as e:
            print(f"Error: {e}")
    
    # Example 2: Submit task with skill requirements
    print("\n" + "=" * 60)
    print("Example 2: Task with skill requirements")
    print("=" * 60)
    
    task = "I need help with cooking"
    print(f"\nTask: {task}")
    print("Required skills: ['cooking']")
    
    try:
        result = await delegator.submit_task(
            task,
            require_skills=["cooking"]
        )
        print(f"Result: {result}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Example 3: Submit to specific agent
    print("\n" + "=" * 60)
    print("Example 3: Submit to specific agent")
    print("=" * 60)
    
    task = "Generic question"
    print(f"\nTask: {task}")
    print(f"Preferred agent: {weather_agent.name}")
    
    try:
        result = await delegator.submit_task(
            task,
            preferred_agent=weather_agent.name
        )
        print(f"Result: {result}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Example 4: Submit to multiple agents
    print("\n" + "=" * 60)
    print("Example 4: Submit to multiple agents")
    print("=" * 60)
    
    task = "What do you know about food?"
    print(f"\nTask: {task}")
    print("Sending to all agents...")
    
    try:
        results = await delegator.submit_task_to_multiple(task)
        for agent_id, result in results.items():
            print(f"\n{agent_id}:")
            print(f"  {result}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Cleanup
    print("\n" + "=" * 60)
    print("Cleaning up...")
    await delegator.close_all()
    await recipe_server.stop()
    await shopping_server.stop()
    await weather_server.stop()
    print("Done!")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nInterrupted by user")

