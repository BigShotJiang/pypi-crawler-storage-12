"""Workflows defined in fabricatio-character."""
