"""Capabilities defined in fabricatio-character."""
