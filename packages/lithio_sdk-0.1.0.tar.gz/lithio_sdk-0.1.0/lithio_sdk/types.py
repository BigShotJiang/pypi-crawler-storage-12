from typing import Any, Dict, List
from dataclasses import dataclass
import json


@dataclass
class AddResponse:
    request: str
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AddResponse":
        return cls(**data)


@dataclass
class SearchResponse:
    results: List[Any]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SearchResponse":
        return cls(**data)
    
    def __str__(self) -> str:
        return json.dumps({"results": self.results}, indent=2, ensure_ascii=False)

