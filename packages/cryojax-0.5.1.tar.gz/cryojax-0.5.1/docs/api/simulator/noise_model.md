# Distributions: noisy images and likelihoods
