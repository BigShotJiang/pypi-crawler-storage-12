# Working with physical units

Here, convenience methods for working with physical units are described.

::: cryojax.constants.wavelength_from_kilovolts

---

::: cryojax.constants.lorentz_factor_from_kilovolts

---

::: cryojax.constants.interaction_constant_from_kilovolts
