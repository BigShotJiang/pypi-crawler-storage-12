# Utility functions for image and volume arrays
