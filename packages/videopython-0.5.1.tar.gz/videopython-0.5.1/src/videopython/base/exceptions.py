class OutOfBoundsError(Exception):
    pass
