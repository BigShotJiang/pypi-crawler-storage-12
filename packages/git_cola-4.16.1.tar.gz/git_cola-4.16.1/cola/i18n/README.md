# Internationalization

The `*.po` files are the translation files for Git Cola.

Git Cola has been translated into different languages thanks to the help of many
individuals.

Translation is approximate.

If you find a mistake, please let us know by opening an issue.

We invite you to participate in translation by adding or updating a translation and
opening a pull request.
