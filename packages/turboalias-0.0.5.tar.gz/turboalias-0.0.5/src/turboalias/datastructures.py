from enum import Enum


class SupportedShell(Enum):
    BASH = 'bash'
    ZSH = 'zsh'
