"""Core utilities for GitAuth."""
