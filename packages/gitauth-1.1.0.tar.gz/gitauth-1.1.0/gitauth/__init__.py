"""GitAuth - A CLI tool to rewrite Git commit authors and committers."""

__version__ = "1.1.0"
__author__ = "Mubashar Dev"
__license__ = "MIT"
