# marscore/__init__.py
from .downloader.downloader import MultiThreadDownloader

# 创建实例
_downloader_instance = MultiThreadDownloader()

# 将实例的方法直接暴露为模块级函数
downloader = _downloader_instance.run


# 如果需要，也可以暴露类
__all__ = ['downloader','MultiThreadDownloader']