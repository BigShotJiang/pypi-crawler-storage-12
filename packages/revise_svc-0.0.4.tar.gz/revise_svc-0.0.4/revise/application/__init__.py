from revise.application.sc_svc import ScSvc
from revise.application.sp_svc import SpSvc

__all__ = ['SpSvc', 'ScSvc']
