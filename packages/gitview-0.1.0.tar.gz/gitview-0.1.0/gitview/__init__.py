"""GitView - Git history analyzer with LLM-powered narrative generation."""

__version__ = "0.1.0"
