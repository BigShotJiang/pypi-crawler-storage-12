# -*- coding: utf-8 -*-

from canvasapi.canvas import Canvas

__all__ = ["Canvas"]

__version__ = "3.4.0"
