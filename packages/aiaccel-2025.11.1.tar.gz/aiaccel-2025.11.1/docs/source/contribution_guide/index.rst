Contribution Guide
==================

Thank you for contributing to aiaccel! This document introduces how to contribute.

.. toctree::
    :maxdepth: 2

    issues
    pull_requests
    documentation
    tests
    coding_styles
