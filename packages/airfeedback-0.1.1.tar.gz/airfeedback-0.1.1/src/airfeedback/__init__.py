"""AirFeedback - Simple feedback collection for Air/FastAPI apps."""

from .main import AirFeedback as AirFeedback

__all__ = ["AirFeedback"]
