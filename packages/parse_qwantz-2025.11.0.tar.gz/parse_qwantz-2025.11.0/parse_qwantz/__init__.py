from parse_qwantz.cli import app
from parse_qwantz.main import main
