from esgvoc.api.data_descriptors.data_descriptor import PatternTermDataDescriptor


class ForcingIndex(PatternTermDataDescriptor):
    pass
