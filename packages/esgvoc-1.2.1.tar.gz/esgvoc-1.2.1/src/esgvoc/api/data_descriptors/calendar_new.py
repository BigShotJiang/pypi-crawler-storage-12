from esgvoc.api.data_descriptors.data_descriptor import PlainTermDataDescriptor


class Calendar(PlainTermDataDescriptor):
    description: str
