from esgvoc.api.data_descriptors.data_descriptor import PlainTermDataDescriptor


class SourceType(PlainTermDataDescriptor):
    description: str
