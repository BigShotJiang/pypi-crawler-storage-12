from esgvoc.api.data_descriptors.data_descriptor import DataDescriptor


class TemporalRefinement(DataDescriptor):
    description: str
