from esgvoc.api.data_descriptors.data_descriptor import PlainTermDataDescriptor


class Frequency(PlainTermDataDescriptor):
    description: str
    long_name: str
    name: str
    unit: str
