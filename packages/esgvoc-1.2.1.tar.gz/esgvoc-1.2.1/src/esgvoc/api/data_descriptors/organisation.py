from esgvoc.api.data_descriptors.data_descriptor import PlainTermDataDescriptor


class Organisation(PlainTermDataDescriptor):
    pass
