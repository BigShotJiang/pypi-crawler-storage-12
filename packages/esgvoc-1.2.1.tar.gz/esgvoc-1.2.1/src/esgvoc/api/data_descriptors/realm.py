from esgvoc.api.data_descriptors.data_descriptor import PlainTermDataDescriptor


class Realm(PlainTermDataDescriptor):
    description: str
    name: str
