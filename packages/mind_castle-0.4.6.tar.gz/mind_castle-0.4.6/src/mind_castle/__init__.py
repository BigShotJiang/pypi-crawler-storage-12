import mind_castle.stores  # noqa: F401
import logging

logger = logging.getLogger("mind-castle")
