import os

os.environ["MIND_CASTLE_AWS_REGION"] = "us-east-1"
os.environ["MIND_CASTLE_AWS_ACCESS_KEY_ID"] = "0"
os.environ["MIND_CASTLE_AWS_SECRET_ACCESS_KEY"] = "0"
