"""text to pandas"""
from .component import Nl2pandasComponent