
from .component import TagExtraction