"""StyleRewrite"""
from .component import StyleRewrite
