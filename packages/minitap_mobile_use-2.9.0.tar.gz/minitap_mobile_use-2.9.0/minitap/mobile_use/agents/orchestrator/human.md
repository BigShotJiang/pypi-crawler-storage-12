Here is the input for your analysis:

**Initial goal** : {{ initial_goal }}

**Subgoal plan**
{{ subgoal_plan }}

**Subgoals to examine (provided by the Cortex)**
{{ subgoals_to_examine }}

**Agent thoughts**
{{ agent_thoughts }}