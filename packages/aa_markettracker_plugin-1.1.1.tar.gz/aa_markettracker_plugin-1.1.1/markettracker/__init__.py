"""Initialize the app"""

__version__ = "1.1.1"
__title__ = "Markettracker"
