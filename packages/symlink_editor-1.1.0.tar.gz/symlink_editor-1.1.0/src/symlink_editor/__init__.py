#!/usr/bin/env python3

'''
A TUI to change the target of a symlink.
'''

__version__ = '1.1.0'
