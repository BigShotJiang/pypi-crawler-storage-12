from django.apps import AppConfig


class UIConfig(AppConfig):
    name = "tawala.ui"
