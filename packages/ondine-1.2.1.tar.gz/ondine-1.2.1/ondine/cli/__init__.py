"""Command-line interface for LLM Dataset Engine."""

from ondine.cli.main import cli

__all__ = ["cli"]
