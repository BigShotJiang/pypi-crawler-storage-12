#!/usr/bin/env python3
"""Quick launcher for Sharingan UI."""

if __name__ == '__main__':
    from sharingan.ui import run_ui
    run_ui()
