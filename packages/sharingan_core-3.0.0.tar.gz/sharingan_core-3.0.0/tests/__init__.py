"""Test suite for Sharingan package."""
