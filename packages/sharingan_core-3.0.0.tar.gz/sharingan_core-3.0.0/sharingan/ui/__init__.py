"""Sharingan Web UI."""

from sharingan.ui.app import run_ui

__all__ = ["run_ui"]
