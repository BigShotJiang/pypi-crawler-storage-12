"""Example scripts for Sharingan package."""
