from django.apps import AppConfig


class JoditConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "jodit"
    verbose_name = "Django Jodit Editor"
