from gamengine3d import *

class Cylinder:
    def __init__(self, obj: Cylinder, context: Context):
        self.obj = obj
        self.context = context
        self.color_idx = 0
        self.obj.color = self.context.runtime_vars.cylinder_colors[0]
        self.context.add_scheduled_caller(n_times=-1, delay=1, callback=self.switch_color)
        self.context.on_key_held("w", self.draw_cylinder)
        self.obj.visible = False

    def update(self, dt):
        pass

    def switch_color(self):
        self.color_idx += 1
        self.obj.color = self.context.runtime_vars.cylinder_colors[self.color_idx % self.context.runtime_vars.num_cylinder_colors]

    def draw_cylinder(self):
        self.context.renderer.render_cylinder(vector3d.zero, 2, .1, Color.blue, 32)
