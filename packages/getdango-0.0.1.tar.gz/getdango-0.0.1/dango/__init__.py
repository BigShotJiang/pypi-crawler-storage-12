"""
Dango - Local-first data platform

Laptop to cloud data stack in one weekend.
"""

__version__ = "0.0.1"
__author__ = "Dango Team"
__license__ = "Apache-2.0"

# Package metadata
__all__ = ["__version__", "__author__", "__license__"]
