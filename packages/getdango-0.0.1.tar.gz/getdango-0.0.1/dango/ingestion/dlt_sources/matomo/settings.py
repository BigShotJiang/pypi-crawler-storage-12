"""Matomo source settings and constants"""

DEFAULT_START_DATE = "2000-01-01"
