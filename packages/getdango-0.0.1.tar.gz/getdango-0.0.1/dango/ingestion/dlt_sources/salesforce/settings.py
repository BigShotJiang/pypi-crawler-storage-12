"""Salesforce source settings and constants"""

# set to false to limit query to 100 records for testing
IS_PRODUCTION = True
