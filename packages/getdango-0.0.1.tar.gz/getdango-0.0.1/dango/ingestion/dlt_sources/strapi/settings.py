"""Strapi source settings and constants"""
