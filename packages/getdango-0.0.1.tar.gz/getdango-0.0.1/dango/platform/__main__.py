"""
Module entry point for watcher runner

Allows running: python -m dango.platform.watcher_runner
"""

from .watcher_runner import main

if __name__ == "__main__":
    main()
