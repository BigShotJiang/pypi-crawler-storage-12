"""
Dango Web Module

FastAPI web UI for monitoring and managing Dango platform.
"""

from . import app

__all__ = ['app']
