#
# Copyright (c) 2023 Airbyte, Inc., all rights reserved.
#

from .reader import TestReader

__all__ = ("TestReader",)
