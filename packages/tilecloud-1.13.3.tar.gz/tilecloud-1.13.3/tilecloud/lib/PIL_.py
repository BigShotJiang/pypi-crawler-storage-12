# pylint: disable=invalid-name # noqa: N999
FORMAT_BY_CONTENT_TYPE = {"image/jpeg": "JPEG", "image/png": "PNG", "image/webp": "WEBP"}
