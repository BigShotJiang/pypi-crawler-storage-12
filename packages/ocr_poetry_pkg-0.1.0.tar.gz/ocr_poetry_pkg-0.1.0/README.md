OCR CLI for Arabic images using unsloth/surya

