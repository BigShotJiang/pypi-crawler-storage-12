# sumo-logger

A simple Python package for sending logs to **Sumo Logic HTTP Source** endpoints.

## Installation

```bash
pip install sumo-logger
