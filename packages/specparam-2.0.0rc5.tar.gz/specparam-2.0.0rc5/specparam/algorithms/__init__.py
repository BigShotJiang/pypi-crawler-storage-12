"""Algorithms sub-module."""
