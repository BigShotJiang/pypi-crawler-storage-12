"""Tests for specparam.results.components."""

from specparam.results.components import *

###################################################################################################
###################################################################################################

## ModelComponents object

def test_model_components():

    mc = ModelComponents()
    assert mc
