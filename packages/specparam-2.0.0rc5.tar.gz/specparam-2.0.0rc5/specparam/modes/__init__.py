"""Functionality related to definining fit modes."""
