"""Plots sub-module."""

from .spectra import plot_spectra, plot_spectrogram
