"""Utilities sub-module."""

from .spectral import trim_spectrum, interpolate_spectrum, interpolate_spectra, subsample_spectra
