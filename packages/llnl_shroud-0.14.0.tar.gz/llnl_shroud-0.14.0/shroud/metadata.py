# Copyright Shroud Project Developers. See LICENSE file for details.
#
# SPDX-License-Identifier: (BSD-3-Clause)
########################################################################

__version__ = "0.14.0"
__version_info__ = (0, 14, 0, "final", 0)
# 'alpha', 'beta', 'candidate', or 'final'.
