def main():
    print("Developed by Darki using just a phone!")