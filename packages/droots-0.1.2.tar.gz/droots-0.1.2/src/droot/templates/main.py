"""
Entry point of your project
"""
from typing import NoReturn
import sys

def main() -> NoReturn:
    # Code goes below











    sys.exit(0) # Program shouldn't continue in run.py