invalid_chars = ["\\", "/", "<", ">", ":", "|", "\"", "*"]
reserved      = [".droot", "droot"]