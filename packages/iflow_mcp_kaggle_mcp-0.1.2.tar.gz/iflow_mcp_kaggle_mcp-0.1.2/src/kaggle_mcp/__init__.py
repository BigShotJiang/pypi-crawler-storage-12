"""Kaggle integration through the Model Context Protocol."""

__version__ = "0.1.0"
