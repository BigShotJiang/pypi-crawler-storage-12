from xursparks.error.main import GenericXursparksException


def test():
    return GenericXursparksException(f'test')