from .bisseccao import bisseccao
from .newton_raphson import newton_raphson
from .secante import secante

__all__ = ["bisseccao", "newton_raphson", "secante"]
