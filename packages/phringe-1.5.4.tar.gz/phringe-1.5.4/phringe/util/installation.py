def which_animals_have_fringes():
    """Print the animals that have fringes as a test method."""
    print('Zebras!')
