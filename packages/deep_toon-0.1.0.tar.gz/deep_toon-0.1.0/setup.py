#!/usr/bin/env python3
"""
Minimal setup.py for Deep-TOON package.
All configuration is in pyproject.toml.
"""

from setuptools import setup

# Use pyproject.toml for all configuration
setup()