"""
Main entry point for voice-mode when called as a module.
"""

from .cli import voice_mode

if __name__ == "__main__":
    voice_mode()