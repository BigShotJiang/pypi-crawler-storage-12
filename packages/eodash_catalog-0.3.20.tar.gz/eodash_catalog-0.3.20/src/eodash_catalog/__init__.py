# SPDX-FileCopyrightText: 2024-present Daniel Santillan <daniel.santillan@eox.at>
#
# SPDX-License-Identifier: MIT
