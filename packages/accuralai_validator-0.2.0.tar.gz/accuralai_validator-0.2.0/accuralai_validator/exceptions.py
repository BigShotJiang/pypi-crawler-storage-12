"""Domain-specific validation errors."""

from __future__ import annotations

from accuralai_core.contracts.errors import ValidationError

__all__ = ["ValidationError"]
