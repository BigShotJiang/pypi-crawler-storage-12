Translations were moved from crowdin to PR requests only!
