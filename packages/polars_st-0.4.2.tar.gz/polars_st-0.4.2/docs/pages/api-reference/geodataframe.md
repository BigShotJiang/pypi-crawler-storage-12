::: polars_st.GeoDataFrame
    options:
        show_root_heading: true
        members: [st]

::: polars_st.GeoDataFrameNameSpace
    options:
        show_root_heading: true
        show_object_full_path: true
        merge_init_into_class: false
        filters:
            - "!^_[^_]"
            - "!^__init__"
