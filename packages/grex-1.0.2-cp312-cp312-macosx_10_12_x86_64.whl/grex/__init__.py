from .grex import *

__doc__ = grex.__doc__
if hasattr(grex, "__all__"):
    __all__ = grex.__all__