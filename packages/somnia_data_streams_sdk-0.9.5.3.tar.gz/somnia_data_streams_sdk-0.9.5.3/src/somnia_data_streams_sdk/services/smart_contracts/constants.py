"""Smart contract constants."""

from somnia_data_streams_sdk.types.contracts import Chains, CHAIN_ID_NAME

__all__ = ["Chains", "CHAIN_ID_NAME"]
