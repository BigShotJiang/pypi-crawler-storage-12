# spoox

spoox - terminal assistant - SPlit lOOp eXplore agent

A terminal-integrated LLM agent created to support OS operations, server workflows, and development tasks. 