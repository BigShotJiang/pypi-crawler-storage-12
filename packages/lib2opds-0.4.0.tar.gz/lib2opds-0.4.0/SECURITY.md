# Security Policy

## Reporting a Vulnerability

To report a security issue, please use the GitHub Security Advisory ["Report a Vulnerability"](https://github.com/oxdef/lib2opds/security/advisories/new) tab.
