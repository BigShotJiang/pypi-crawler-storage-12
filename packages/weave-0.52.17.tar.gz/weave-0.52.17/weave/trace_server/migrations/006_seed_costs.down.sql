ALTER TABLE llm_token_prices DELETE WHERE
    created_by = 'system';
