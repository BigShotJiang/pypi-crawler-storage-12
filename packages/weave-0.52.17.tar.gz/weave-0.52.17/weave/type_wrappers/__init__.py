from weave.type_wrappers.Content import Content as Content
