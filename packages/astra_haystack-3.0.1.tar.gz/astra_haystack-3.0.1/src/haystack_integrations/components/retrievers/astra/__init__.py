# SPDX-FileCopyrightText: 2023-present Anant Corporation <support@anant.us>
#
# SPDX-License-Identifier: Apache-2.0
from .retriever import AstraEmbeddingRetriever

__all__ = ["AstraEmbeddingRetriever"]
