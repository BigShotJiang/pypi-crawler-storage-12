#!/usr/bin/env python
# coding: utf-8 -*-

"""CLI package initialization."""

from avd_cli.cli.main import cli

__all__ = ["cli"]
