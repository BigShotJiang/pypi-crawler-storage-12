*[array-like]: a Python list, a NumPy or JAX array, or any (potentially nested) sequence of these types
*[Array-like]: a Python list, a NumPy or JAX array, or any (potentially nested) sequence of these types
*[array-likes]: a Python list, a NumPy or JAX array, or any (potentially nested) sequence of these types
*[Array-likes]: a Python list, a NumPy or JAX array, or any (potentially nested) sequence of these types

*[qarray-like]: a Python list, a NumPy or JAX array, a Dynamiqs qarray, a QuTiP qobj, or any (potentially nested) sequence of these types
*[Qarray-like]: a Python list, a NumPy or JAX array, a Dynamiqs qarray, a QuTiP qobj, or any (potentially nested) sequence of these types
*[qarray-likes]: a Python list, a NumPy or JAX array, a Dynamiqs qarray, a QuTiP qobj, or any (potentially nested) sequence of these types
*[Qarray-likes]: a Python list, a NumPy or JAX array, a Dynamiqs qarray, a QuTiP qobj, or any (potentially nested) sequence of these types

*[PWC]: piecewise constant
*[SME]: stochastic master equation
*[SMEs]: stochastic master equations
*[SSE]: stochastic Schrödinger equation
*[SSEs]: stochastic Schrödinger equations
*[PRNG]: pseudorandom number generator
