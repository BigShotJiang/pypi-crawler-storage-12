# Computing gradients

!!! Warning "Work in progress."
    This tutorial is under construction. In the meantime, you can check out [this example](../getting_started/examples.md#compute-gradients-with-respect-to-some-parameters) that shows how to differentiate an expectation value obtained with [`dq.mesolve()`][dynamiqs.mesolve] with respect to simulation parameters.
