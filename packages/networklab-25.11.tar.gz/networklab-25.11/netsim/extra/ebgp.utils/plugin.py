_redirect: str = 'bgp.session'          # Redirect plugin load to bgp.session plugin
