'''
Router-specific data transformation: none
'''

from box import Box


def post_node_transform(topology: Box) -> None:
  pass
