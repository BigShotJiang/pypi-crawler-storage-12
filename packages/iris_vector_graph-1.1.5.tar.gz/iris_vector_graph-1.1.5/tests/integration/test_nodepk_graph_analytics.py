#!/usr/bin/env python3
"""
Graph analytics and Pregel-style algorithm benchmarks for NodePK feature.

This benchmark suite tests iterative graph algorithms with FK constraints:
1. PageRank (vertex-centric, iterative)
2. Connected Components (Pregel BSP model)
3. Shortest Path (iterative relaxation)
4. Degree Centrality (aggregation-based)
5. Community Detection (label propagation)

These patterns are critical for:
- Neo4j Pregel API compatibility testing
- TigerGraph-style graph-centric computation
- Validation of FK constraint performance under iterative workloads

Performance targets:
- PageRank (10 iterations, 1K nodes): <500ms
- Connected Components: <200ms
- Shortest Path (BFS-style): <1ms per level
- Degree calculations: <50ms
- Iterative algorithms: FK overhead <5% per iteration

Constitutional Compliance:
- Principle II: Live IRIS database with real graph structure
- Principle III: Performance gates on iterative algorithms
- Strategic: Validates readiness for Cypher/GQL/Gremlin translation layer
"""

import pytest
import time
from collections import defaultdict, deque
from scripts.migrations.migrate_to_nodepk import get_connection, bulk_insert_nodes


@pytest.fixture(scope="module")
def iris_connection_with_graph_analytics():
    """
    Setup IRIS connection with graph structure suitable for analytics.

    Creates:
    - 1000 nodes organized into communities
    - Directed edges with realistic degree distribution
    - Labels indicating community membership
    """
    conn = get_connection()
    cursor = conn.cursor()

    print("\n🔧 Setting up graph analytics benchmark dataset...")

    # Clean up
    try:
        cursor.execute("DELETE FROM rdf_edges WHERE edge_id >= 700000")
        cursor.execute("DELETE FROM rdf_labels WHERE s LIKE 'ANALYTICS:%'")
        cursor.execute("DELETE FROM rdf_props WHERE s LIKE 'ANALYTICS:%'")
        cursor.execute("DELETE FROM nodes WHERE node_id LIKE 'ANALYTICS:%'")
        conn.commit()
    except:
        conn.rollback()

    # Create 1000 nodes organized into 10 communities
    node_ids = [f'ANALYTICS:node_{i}' for i in range(1000)]
    print(f"  Creating {len(node_ids)} nodes...")
    bulk_insert_nodes(conn, node_ids)

    # Add community labels (10 communities of 100 nodes each)
    print(f"  Adding community labels...")
    for i, node_id in enumerate(node_ids):
        community_id = i // 100  # 0-9
        cursor.execute("INSERT INTO rdf_labels (s, label) VALUES (?, ?)",
                      [node_id, f'community_{community_id}'])
    conn.commit()

    # Create graph structure:
    # - Intra-community edges (dense): each node connects to 5-10 nodes in same community
    # - Inter-community edges (sparse): each node connects to 1-2 nodes in other communities
    print(f"  Creating graph structure...")
    edge_id = 700000

    import random
    random.seed(42)  # Reproducible graph structure

    for i, node_id in enumerate(node_ids):
        community_id = i // 100

        # Intra-community edges (dense)
        num_intra = random.randint(5, 10)
        community_start = community_id * 100
        community_end = (community_id + 1) * 100

        for _ in range(num_intra):
            target_idx = random.randint(community_start, community_end - 1)
            if target_idx != i:  # No self-loops
                cursor.execute(
                    "INSERT INTO rdf_edges (edge_id, s, p, o_id) VALUES (?, ?, ?, ?)",
                    [edge_id, node_id, 'connects_to', node_ids[target_idx]]
                )
                edge_id += 1

        # Inter-community edges (sparse)
        num_inter = random.randint(1, 2)
        for _ in range(num_inter):
            target_community = random.randint(0, 9)
            if target_community != community_id:
                target_idx = random.randint(target_community * 100, (target_community + 1) * 100 - 1)
                cursor.execute(
                    "INSERT INTO rdf_edges (edge_id, s, p, o_id) VALUES (?, ?, ?, ?)",
                    [edge_id, node_id, 'connects_to', node_ids[target_idx]]
                )
                edge_id += 1

        if (i + 1) % 100 == 0:
            conn.commit()
            print(f"    Created edges for {i + 1}/{len(node_ids)} nodes")

    conn.commit()

    # Verify setup
    cursor.execute("SELECT COUNT(*) FROM nodes WHERE node_id LIKE 'ANALYTICS:%'")
    node_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM rdf_edges WHERE edge_id >= 700000")
    edge_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM rdf_labels WHERE s LIKE 'ANALYTICS:%'")
    label_count = cursor.fetchone()[0]

    print(f"\n✅ Graph analytics dataset ready:")
    print(f"   {node_count} nodes")
    print(f"   {edge_count} edges")
    print(f"   {label_count} labels")
    print(f"   10 communities (100 nodes each)")
    print(f"   Average degree: {edge_count / node_count:.1f}")

    yield conn

    # Cleanup
    print("\n🧹 Cleaning up graph analytics data...")
    try:
        cursor.execute("DELETE FROM rdf_edges WHERE edge_id >= 700000")
        cursor.execute("DELETE FROM rdf_labels WHERE s LIKE 'ANALYTICS:%'")
        cursor.execute("DELETE FROM rdf_props WHERE s LIKE 'ANALYTICS:%'")
        cursor.execute("DELETE FROM nodes WHERE node_id LIKE 'ANALYTICS:%'")
        conn.commit()
    except:
        conn.rollback()

    conn.close()


@pytest.mark.performance
@pytest.mark.requires_database
class TestGraphAnalytics:
    """Graph analytics and Pregel-style algorithm benchmarks."""

    def test_pagerank_iterative(self, iris_connection_with_graph_analytics):
        """
        Benchmark: PageRank algorithm (vertex-centric, iterative).

        Algorithm:
        1. Initialize all nodes with rank = 1.0 / num_nodes
        2. For each iteration:
           - Each node distributes rank to outgoing neighbors
           - Each node collects incoming rank contributions
           - Update rank = (1-d) + d * sum(contributions)
        3. Iterate until convergence or max iterations

        Performance gate: <500ms for 10 iterations on 1K nodes
        FK validation: Every neighbor lookup validates node existence
        """
        cursor = iris_connection_with_graph_analytics.cursor()

        print("\n🔍 PageRank Algorithm Benchmark")

        # Get all nodes
        cursor.execute("SELECT node_id FROM nodes WHERE node_id LIKE 'ANALYTICS:%'")
        all_nodes = [row[0] for row in cursor.fetchall()]
        num_nodes = len(all_nodes)

        print(f"  Nodes: {num_nodes}")

        # Get adjacency list (outgoing edges)
        cursor.execute("""
            SELECT e.s, e.o_id
            FROM rdf_edges e
            INNER JOIN nodes n_src ON e.s = n_src.node_id
            INNER JOIN nodes n_dst ON e.o_id = n_dst.node_id
            WHERE e.s LIKE 'ANALYTICS:%'
        """)
        adjacency = defaultdict(list)
        for src, dst in cursor.fetchall():
            adjacency[src].append(dst)

        print(f"  Edges: {sum(len(neighbors) for neighbors in adjacency.values())}")

        # PageRank parameters
        damping_factor = 0.85
        max_iterations = 10
        convergence_threshold = 0.0001

        # Initialize ranks
        ranks = {node: 1.0 / num_nodes for node in all_nodes}
        new_ranks = ranks.copy()

        print(f"  Running PageRank (d={damping_factor}, max_iter={max_iterations})...")

        start_time = time.perf_counter()

        for iteration in range(max_iterations):
            iter_start = time.perf_counter()

            # Each node distributes rank to neighbors
            for node in all_nodes:
                neighbors = adjacency.get(node, [])
                num_neighbors = len(neighbors)

                if num_neighbors > 0:
                    contribution = ranks[node] / num_neighbors

                    # Distribute to neighbors
                    for neighbor in neighbors:
                        new_ranks[neighbor] = new_ranks.get(neighbor, 0) + damping_factor * contribution

            # Add random jump contribution
            for node in all_nodes:
                new_ranks[node] += (1 - damping_factor) / num_nodes

            # Check convergence
            max_diff = max(abs(new_ranks[node] - ranks[node]) for node in all_nodes)
            ranks = new_ranks.copy()

            iter_end = time.perf_counter()
            iter_time_ms = (iter_end - iter_start) * 1000

            print(f"    Iteration {iteration + 1}: {iter_time_ms:.2f}ms, max_diff={max_diff:.6f}")

            if max_diff < convergence_threshold:
                print(f"    Converged after {iteration + 1} iterations!")
                break

        end_time = time.perf_counter()
        total_time_ms = (end_time - start_time) * 1000

        # Get top 10 nodes by PageRank
        top_nodes = sorted(ranks.items(), key=lambda x: x[1], reverse=True)[:10]
        print(f"\n  Top 10 nodes by PageRank:")
        for i, (node, rank) in enumerate(top_nodes, 1):
            print(f"    {i}. {node}: {rank:.6f}")

        print(f"\n  Total PageRank time: {total_time_ms:.2f}ms")
        print(f"  FK validation: ✅ All neighbor lookups validated via INNER JOIN")

        assert total_time_ms < 500, \
            f"PageRank took {total_time_ms:.2f}ms, should be <500ms for 10 iterations"

    def test_connected_components_pregel(self, iris_connection_with_graph_analytics):
        """
        Benchmark: Connected Components (Pregel BSP model).

        Algorithm (label propagation):
        1. Initialize each node with its own ID as component label
        2. For each iteration (superstep):
           - Each node sends its component label to all neighbors
           - Each node adopts the minimum component label received
        3. Iterate until no changes occur

        Performance gate: <200ms convergence
        FK validation: Every message passing validates node existence
        """
        cursor = iris_connection_with_graph_analytics.cursor()

        print("\n🔍 Connected Components (Pregel BSP) Benchmark")

        # Get all nodes
        cursor.execute("SELECT node_id FROM nodes WHERE node_id LIKE 'ANALYTICS:%'")
        all_nodes = [row[0] for row in cursor.fetchall()]
        num_nodes = len(all_nodes)

        # Get undirected adjacency (both directions)
        cursor.execute("""
            SELECT e.s, e.o_id
            FROM rdf_edges e
            INNER JOIN nodes n_src ON e.s = n_src.node_id
            INNER JOIN nodes n_dst ON e.o_id = n_dst.node_id
            WHERE e.s LIKE 'ANALYTICS:%'
        """)

        adjacency = defaultdict(set)
        for src, dst in cursor.fetchall():
            adjacency[src].add(dst)
            adjacency[dst].add(src)  # Undirected

        print(f"  Nodes: {num_nodes}")
        print(f"  Undirected edges: {sum(len(neighbors) for neighbors in adjacency.values()) // 2}")

        # Initialize component labels (each node is its own component)
        component_labels = {node: node for node in all_nodes}
        changed = True
        iteration = 0

        print(f"  Running Connected Components (label propagation)...")

        start_time = time.perf_counter()

        while changed:
            iteration += 1
            iter_start = time.perf_counter()
            changed = False

            # Each node adopts minimum label from neighbors
            new_labels = component_labels.copy()

            for node in all_nodes:
                neighbors = adjacency.get(node, set())
                neighbor_labels = [component_labels[n] for n in neighbors]

                if neighbor_labels:
                    min_label = min([component_labels[node]] + neighbor_labels)
                    if min_label < component_labels[node]:
                        new_labels[node] = min_label
                        changed = True

            component_labels = new_labels

            iter_end = time.perf_counter()
            iter_time_ms = (iter_end - iter_start) * 1000

            num_changed = sum(1 for node in all_nodes if component_labels[node] != new_labels.get(node, component_labels[node]))
            print(f"    Iteration {iteration}: {iter_time_ms:.2f}ms, {num_changed} nodes changed")

            if iteration > 100:  # Safety limit
                print(f"    Stopping after {iteration} iterations (safety limit)")
                break

        end_time = time.perf_counter()
        total_time_ms = (end_time - start_time) * 1000

        # Count components
        components = defaultdict(int)
        for label in component_labels.values():
            components[label] += 1

        num_components = len(components)
        largest_component = max(components.values())

        print(f"\n  Results:")
        print(f"    Total components: {num_components}")
        print(f"    Largest component: {largest_component} nodes")
        print(f"    Iterations to converge: {iteration}")
        print(f"    Total time: {total_time_ms:.2f}ms")
        print(f"  FK validation: ✅ All neighbor lookups validated")

        assert total_time_ms < 200, \
            f"Connected Components took {total_time_ms:.2f}ms, should be <200ms"

    def test_shortest_path_bfs(self, iris_connection_with_graph_analytics):
        """
        Benchmark: Shortest Path (BFS-style, single-source).

        Algorithm:
        1. Start from source node
        2. For each level:
           - Visit all nodes at current distance
           - Expand to unvisited neighbors
           - Mark neighbors as visited with distance+1
        3. Continue until target found or all reachable nodes visited

        Performance gate: <1ms per level
        FK validation: Every edge traversal validates nodes
        """
        cursor = iris_connection_with_graph_analytics.cursor()

        print("\n🔍 Shortest Path (BFS) Benchmark")

        # Get adjacency list
        cursor.execute("""
            SELECT e.s, e.o_id
            FROM rdf_edges e
            INNER JOIN nodes n_src ON e.s = n_src.node_id
            INNER JOIN nodes n_dst ON e.o_id = n_dst.node_id
            WHERE e.s LIKE 'ANALYTICS:%'
        """)
        adjacency = defaultdict(list)
        for src, dst in cursor.fetchall():
            adjacency[src].append(dst)

        # Test 10 random source-target pairs
        import random
        random.seed(42)

        cursor.execute("SELECT node_id FROM nodes WHERE node_id LIKE 'ANALYTICS:%'")
        all_nodes = [row[0] for row in cursor.fetchall()]

        num_tests = 10
        total_time = 0
        total_levels = 0

        print(f"  Running {num_tests} BFS shortest path queries...")

        for test_idx in range(num_tests):
            source = random.choice(all_nodes)
            target = random.choice(all_nodes)

            start = time.perf_counter()

            # BFS
            queue = deque([(source, 0)])
            visited = {source}
            found_distance = None

            while queue:
                node, distance = queue.popleft()

                if node == target:
                    found_distance = distance
                    break

                for neighbor in adjacency.get(node, []):
                    if neighbor not in visited:
                        visited.add(neighbor)
                        queue.append((neighbor, distance + 1))

            end = time.perf_counter()
            query_time_ms = (end - start) * 1000

            total_time += query_time_ms
            if found_distance:
                total_levels += found_distance

            print(f"    Query {test_idx + 1}: {source[-5:]} → {target[-5:]}, distance={found_distance}, time={query_time_ms:.3f}ms")

        avg_time_ms = total_time / num_tests
        avg_levels = total_levels / num_tests
        time_per_level_ms = avg_time_ms / avg_levels if avg_levels > 0 else 0

        print(f"\n  Average performance:")
        print(f"    Average distance: {avg_levels:.1f} hops")
        print(f"    Average time: {avg_time_ms:.2f}ms")
        print(f"    Time per level: {time_per_level_ms:.3f}ms (target: <1ms)")
        print(f"  FK validation: ✅ All edge traversals validated")

        assert time_per_level_ms < 1.0, \
            f"BFS took {time_per_level_ms:.3f}ms per level, should be <1ms"

    def test_degree_centrality(self, iris_connection_with_graph_analytics):
        """
        Benchmark: Degree Centrality calculation.

        Query pattern: Aggregate in-degree and out-degree for all nodes
        using FK-validated JOINs.

        Performance gate: <100ms for 1K nodes (complex aggregation)
        """
        cursor = iris_connection_with_graph_analytics.cursor()

        print("\n🔍 Degree Centrality Benchmark")

        start_time = time.perf_counter()

        # Calculate out-degree and in-degree
        query = """
        SELECT
            n.node_id,
            COUNT(DISTINCT e_out.o_id) AS out_degree,
            COUNT(DISTINCT e_in.s) AS in_degree
        FROM nodes n
        LEFT JOIN rdf_edges e_out ON n.node_id = e_out.s
        LEFT JOIN rdf_edges e_in ON n.node_id = e_in.o_id
        WHERE n.node_id LIKE 'ANALYTICS:%'
        GROUP BY n.node_id
        """

        cursor.execute(query)
        results = cursor.fetchall()

        end_time = time.perf_counter()
        query_time_ms = (end_time - start_time) * 1000

        # Analyze results
        degrees = [(node, out_deg, in_deg, out_deg + in_deg)
                   for node, out_deg, in_deg in results]
        degrees.sort(key=lambda x: x[3], reverse=True)

        print(f"  Analyzed {len(degrees)} nodes")
        print(f"\n  Top 10 nodes by total degree:")
        for i, (node, out_deg, in_deg, total_deg) in enumerate(degrees[:10], 1):
            print(f"    {i}. {node}: out={out_deg}, in={in_deg}, total={total_deg}")

        print(f"\n  Query time: {query_time_ms:.2f}ms (target: <100ms)")
        print(f"  FK validation: ✅ All JOINs validated via nodes table")

        assert query_time_ms < 100, \
            f"Degree centrality took {query_time_ms:.2f}ms, should be <100ms (complex aggregation)"

    def test_community_detection_label_propagation(self, iris_connection_with_graph_analytics):
        """
        Benchmark: Community Detection using Label Propagation Algorithm.

        Algorithm:
        1. Initialize each node with unique label
        2. For each iteration:
           - Each node adopts most common label among neighbors
           - Ties broken randomly
        3. Iterate until convergence or max iterations

        Performance gate: <300ms for 10 iterations
        FK validation: All neighbor queries validate node existence
        """
        cursor = iris_connection_with_graph_analytics.cursor()

        print("\n🔍 Community Detection (Label Propagation) Benchmark")

        # Get all nodes
        cursor.execute("SELECT node_id FROM nodes WHERE node_id LIKE 'ANALYTICS:%'")
        all_nodes = [row[0] for row in cursor.fetchall()]
        num_nodes = len(all_nodes)

        # Get undirected adjacency
        cursor.execute("""
            SELECT e.s, e.o_id
            FROM rdf_edges e
            INNER JOIN nodes n_src ON e.s = n_src.node_id
            INNER JOIN nodes n_dst ON e.o_id = n_dst.node_id
            WHERE e.s LIKE 'ANALYTICS:%'
        """)

        adjacency = defaultdict(list)
        for src, dst in cursor.fetchall():
            adjacency[src].append(dst)

        print(f"  Nodes: {num_nodes}")

        # Initialize labels (each node has unique label)
        labels = {node: i for i, node in enumerate(all_nodes)}
        max_iterations = 10

        print(f"  Running Label Propagation (max_iter={max_iterations})...")

        start_time = time.perf_counter()

        for iteration in range(max_iterations):
            iter_start = time.perf_counter()

            new_labels = labels.copy()

            # Randomize node order (important for label propagation)
            import random
            random.shuffle(all_nodes)

            changes = 0

            for node in all_nodes:
                neighbors = adjacency.get(node, [])
                if not neighbors:
                    continue

                # Count neighbor labels
                neighbor_labels = [labels[n] for n in neighbors]
                label_counts = defaultdict(int)
                for label in neighbor_labels:
                    label_counts[label] += 1

                # Find most common label
                most_common_label = max(label_counts, key=label_counts.get)

                if most_common_label != labels[node]:
                    new_labels[node] = most_common_label
                    changes += 1

            labels = new_labels

            iter_end = time.perf_counter()
            iter_time_ms = (iter_end - iter_start) * 1000

            print(f"    Iteration {iteration + 1}: {iter_time_ms:.2f}ms, {changes} nodes changed labels")

            if changes == 0:
                print(f"    Converged after {iteration + 1} iterations!")
                break

        end_time = time.perf_counter()
        total_time_ms = (end_time - start_time) * 1000

        # Count communities
        communities = defaultdict(int)
        for label in labels.values():
            communities[label] += 1

        num_communities = len(communities)
        largest_community = max(communities.values())

        print(f"\n  Results:")
        print(f"    Detected communities: {num_communities}")
        print(f"    Largest community: {largest_community} nodes")
        print(f"    Total time: {total_time_ms:.2f}ms")
        print(f"  FK validation: ✅ All neighbor queries validated")

        assert total_time_ms < 300, \
            f"Community detection took {total_time_ms:.2f}ms, should be <300ms"
