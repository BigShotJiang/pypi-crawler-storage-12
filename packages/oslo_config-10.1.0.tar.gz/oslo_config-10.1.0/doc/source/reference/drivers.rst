
---------------
Backend Drivers
---------------

Refer to :py:mod:`oslo_config.sources`


Known Backend Drivers
---------------------

.. NOTE(bnemec): These are private modules, so we need to explicitly
   document them

.. automodule:: oslo_config.sources._uri
.. automodule:: oslo_config.sources._environment
