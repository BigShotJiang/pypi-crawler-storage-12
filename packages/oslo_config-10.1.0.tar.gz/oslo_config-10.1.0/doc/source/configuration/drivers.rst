==============================
 Configuration Source Drivers
==============================

In addition to command line options and configuration files,
oslo.config can access configuration settings in other locations using
*drivers* to define new *sources*.

.. list-plugins:: oslo.config.driver
   :detailed:
