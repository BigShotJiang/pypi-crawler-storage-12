=============
 oslo.config
=============

An OpenStack library for parsing configuration options from the command
line and configuration files.

Contents
========

.. toctree::
   :maxdepth: 2

   configuration/index
   reference/index
   cli/index
   contributor/index


Release Notes
=============

Read also the `oslo.config Release Notes
<https://docs.openstack.org/releasenotes/oslo.config/>`_.

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

