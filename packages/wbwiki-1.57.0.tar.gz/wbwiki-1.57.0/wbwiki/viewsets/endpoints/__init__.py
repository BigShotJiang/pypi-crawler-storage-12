from .wikis import (
    ContentObjectWikiArticleEndpointConfig,
    WikiArticleRelationshipEndpointConfig,
)
