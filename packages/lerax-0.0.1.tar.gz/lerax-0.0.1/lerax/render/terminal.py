from .base_renderer import AbstractRenderer


class TerminalRenderer(AbstractRenderer):
    """Terminal renderer implementation."""
