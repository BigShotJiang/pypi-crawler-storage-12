"""Command-line tool for real-time WiiM player monitoring."""

from __future__ import annotations

import asyncio
import sys
import time
from datetime import datetime
from typing import Any

from .client import WiiMClient
from .exceptions import WiiMError
from .models import DeviceInfo
from .player import Player
from .polling import PollingStrategy
from .role import detect_role
from .upnp.client import UpnpClient
from .upnp.eventer import UpnpEventer


class PlayerMonitor:
    """Real-time player monitor with adaptive polling."""

    def __init__(self, player: Player) -> None:
        """Initialize monitor with a Player instance."""
        self.player = player
        self.running = False
        self.last_state: dict[str, Any] = {}
        self.last_device_info_check = 0.0
        self.last_multiroom_check = 0.0
        self.last_multiroom: dict[str, Any] | None = None
        self.current_role = "solo"
        self.strategy: PollingStrategy | None = None
        self.upnp_client: UpnpClient | None = None
        self.upnp_eventer: UpnpEventer | None = None
        self.upnp_enabled = False
        self.upnp_event_count = 0
        self.last_upnp_event_time: float | None = None
        self._callback_host_override: str | None = None

        # Statistics tracking
        self.start_time: float | None = None
        self.http_poll_count = 0
        self.state_change_count = 0
        self.error_count = 0
        self.poll_intervals: list[float] = []

    def _detect_callback_host(self) -> str | None:
        """Detect the local network IP address for UPnP callback URL.

        Returns:
            IP address string, or None if detection fails
        """
        import socket

        # Use socket trick to get local IP address
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            detected_ip = s.getsockname()[0]
            s.close()

            # Return the detected IP (caller should validate if needed)
            return str(detected_ip)
        except Exception:
            pass

        return None

    def on_state_changed(self, source: str = "polling") -> None:
        """Callback when player state changes.

        Args:
            source: Source of the state change ("polling" or "upnp")
        """
        if not self.player.available:
            return

        # Note: UPnP event count is tracked in upnp_callback, not here
        # This method is called for both polling and UPnP state changes

        # Detect changes
        current_state = {
            "play_state": self.player.play_state,
            "volume": self.player.volume_level,
            "mute": self.player.is_muted,
            "source": self.player.source,
            "title": self.player.media_title,
            "artist": self.player.media_artist,
            "position": self.player.media_position,
            "duration": self.player.media_duration,
            "artwork": self.player.media_image_url,
        }

        # Track state changes
        if current_state != self.last_state:
            self.state_change_count += 1

        # Print changes (only show meaningful changes, not None -> None)
        changes = []
        for key, value in current_state.items():
            old_value = self.last_state.get(key)
            # Only report change if both values are meaningful or there's a real change
            if old_value != value and (value is not None or old_value is not None):
                old_str = str(old_value) if old_value is not None else "None"
                new_str = str(value) if value is not None else "None"
                changes.append(f"{key}: {old_str} → {new_str}")

        if changes:
            timestamp = datetime.now().strftime("%H:%M:%S")
            source_indicator = "📡 UPnP" if source == "upnp" else "🔄 HTTP"
            # Clear the status line before printing change notification
            print("\r" + " " * 100 + "\r", end="", flush=True)
            print(f"[{timestamp}] {source_indicator} State changed:")
            for change in changes:
                print(f"  • {change}")

        self.last_state = current_state

    async def setup(self) -> None:
        """Initialize monitor and detect capabilities."""
        print("🔧 Initializing monitor...")
        self.start_time = time.time()

        # Detect capabilities
        await self.player.client._detect_capabilities()
        self.strategy = PollingStrategy(self.player.client.capabilities)

        # Initialize UPnP event support
        try:
            device_info = await self.player.client.get_device_info_model()
            if device_info.uuid:
                # UPnP description URL is typically on port 49152
                description_url = f"http://{self.player.client.host}:49152/description.xml"

                # Create UPnP client using factory method
                self.upnp_client = await UpnpClient.create(
                    self.player.client.host,
                    description_url,
                    session=None,
                )

                # Create wrapper callback to mark UPnP events
                def upnp_callback():
                    # Track that UPnP event was received (even if no state change)
                    self.upnp_event_count += 1
                    self.last_upnp_event_time = time.time()
                    # Also call state changed callback
                    self.on_state_changed(source="upnp")

                # Create eventer with Player as state manager
                self.upnp_eventer = UpnpEventer(
                    self.upnp_client,
                    self.player,  # Player has apply_diff() method
                    device_info.uuid,
                    state_updated_callback=upnp_callback,
                )

                # Start UPnP subscriptions
                # Try to get LAN IP for callback
                callback_host: str | None = None
                if hasattr(self, "_callback_host_override") and self._callback_host_override:
                    callback_host = self._callback_host_override
                    print(f"   📡 Using specified callback host: {callback_host}")
                else:
                    detected_host = self._detect_callback_host()
                    callback_host = detected_host
                    if callback_host:
                        print(f"   📡 Detected callback host: {callback_host}")
                    else:
                        print("   ⚠️  Could not auto-detect callback host - UPnP events may not work")
                        print("      Use --callback-host <ip> to specify manually")

                await self.upnp_eventer.start(callback_host=callback_host)
                self.upnp_enabled = True

                # Log callback URL if available
                if self.upnp_client.notify_server:
                    callback_url = getattr(self.upnp_client.notify_server, "callback_url", None)
                    if callback_url:
                        print(f"   ✓ UPnP events enabled (callback: {callback_url})")
                    else:
                        print("   ✓ UPnP events enabled (callback URL not available)")
                else:
                    print("   ✓ UPnP events enabled")
        except Exception as e:
            # UPnP failed, continue with HTTP polling only
            print(f"   ⚠ UPnP events unavailable: {e}")
            self.upnp_enabled = False

        # Initial refresh
        await self.player.refresh()

        # Get initial multiroom/grouping data for role detection
        # All LinkPlay devices support grouping, but request may fail due to network/device issues
        try:
            self.last_multiroom = await self.player.client.get_multiroom_status()
        except WiiMError:
            self.last_multiroom = {}  # Request failed, will retry in monitoring loop

        # Detect initial role
        if self.player._status_model and self.last_multiroom is not None:
            role_result = detect_role(
                self.player._status_model,
                self.last_multiroom,
                self.player.device_info,
                self.player.client.capabilities,
                self.player.client.host,
            )
            self.current_role = role_result.role

        self.on_state_changed()

        # Print device info
        device_info_print: DeviceInfo | None = self.player.device_info
        if device_info_print:
            print(f"\n📱 Device: {device_info_print.name} ({device_info_print.model})")
            print(f"   Firmware: {device_info_print.firmware}")
            print(f"   MAC: {device_info_print.mac}")
            print(f"   Vendor: {self.player.client.capabilities.get('vendor', 'unknown')}")
            print(f"   Role: {self.current_role}")

        print("\n" + "=" * 60)
        print("🎵 Real-time Player Monitor")
        print("=" * 60)
        print("Press Ctrl+C to stop\n")

    async def monitor_loop(self) -> None:
        """Main monitoring loop with adaptive polling."""
        self.running = True

        while self.running:
            try:
                # Detect role from status and multiroom data
                if self.player._status_model and self.last_multiroom is not None:
                    role_result = detect_role(
                        self.player._status_model,
                        self.last_multiroom,
                        self.player.device_info,
                        self.player.client.capabilities,
                        self.player.client.host,
                    )
                    self.current_role = role_result.role

                role = self.current_role
                is_playing = self.player.play_state in ("play", "playing")

                # Get optimal polling interval
                if self.strategy:
                    interval = self.strategy.get_optimal_interval(role, is_playing)
                else:
                    interval = 5.0  # Default

                # Track polling intervals for statistics
                self.poll_intervals.append(interval)

                # Refresh player state (HTTP polling)
                await self.player.refresh()
                self.http_poll_count += 1
                self.on_state_changed(source="polling")

                # Conditional fetching (less frequent data)
                now = time.time()

                # Device info (every 60s)
                if self.strategy and self.strategy.should_fetch_device_info(self.last_device_info_check, now):
                    await self.player.get_device_info()
                    self.last_device_info_check = now

                # Multiroom/grouping info (every 15s)
                # All LinkPlay devices support grouping, but request may fail due to network/device issues
                if self.strategy and self.strategy.should_fetch_multiroom(self.last_multiroom_check, False, now):
                    try:
                        self.last_multiroom = await self.player.client.get_multiroom_status()
                    except WiiMError:
                        # Request failed (network/device issue), keep last known state
                        if self.last_multiroom is None:
                            self.last_multiroom = {}
                    self.last_multiroom_check = now

                # Display current status
                self._display_status(role, interval)

                # Wait for next poll (use sleep_until_cancelled to handle Ctrl-C gracefully)
                try:
                    await asyncio.sleep(interval)
                except asyncio.CancelledError:
                    self.running = False
                    break

            except KeyboardInterrupt:
                self.running = False
                break
            except Exception as e:
                # Print error on new line, then continue
                print(f"\n⚠️  Error during monitoring: {e}")
                self.error_count += 1
                # Mark player as unavailable
                self.player._available = False
                await asyncio.sleep(5)  # Wait before retrying

    def _display_status(self, role: str, interval: float) -> None:
        """Display current player status."""
        if not self.player.available:
            print("\r❌ Device unavailable" + " " * 80, end="", flush=True)
            return

        # Build status line
        status_parts = []

        # Play state
        play_state = self.player.play_state or "unknown"
        if play_state == "play":
            status_parts.append("▶️  PLAYING")
        elif play_state == "pause":
            status_parts.append("⏸️  PAUSED")
        elif play_state == "stop":
            status_parts.append("⏹️  STOPPED")
        else:
            status_parts.append(f"⏺️  {play_state.upper()}")

        # Volume
        volume = self.player.volume_level
        if volume is not None:
            mute_indicator = "🔇" if self.player.is_muted else ""
            status_parts.append(f"Vol: {volume:.0%}{mute_indicator}")
        else:
            status_parts.append("Vol: ?")

        # Source (capitalize properly)
        source = self.player.source or "none"
        if source != "none":
            # Capitalize first letter of each word
            source = " ".join(word.capitalize() for word in source.split())
        status_parts.append(f"Source: {source}")

        # Track info
        if self.player.media_title and self.player.media_title.lower() not in ("unknown", "unknow", "none"):
            title = self.player.media_title
            artist = self.player.media_artist or "Unknown Artist"
            if artist.lower() not in ("unknown", "unknow", "none"):
                status_parts.append(f"🎵 {artist} - {title}")
            else:
                status_parts.append(f"🎵 {title}")

            # Position
            if self.player.media_position is not None and self.player.media_duration:
                pos_min = self.player.media_position // 60
                pos_sec = self.player.media_position % 60
                dur_min = self.player.media_duration // 60
                dur_sec = self.player.media_duration % 60
                status_parts.append(f"⏱️  {pos_min:02d}:{pos_sec:02d}/{dur_min:02d}:{dur_sec:02d}")

            # Artwork URL (truncate if too long)
            artwork_url = self.player.media_image_url
            if artwork_url:
                # Truncate long URLs for display
                max_url_len = 50
                if len(artwork_url) > max_url_len:
                    artwork_url = artwork_url[: max_url_len - 3] + "..."
                status_parts.append(f"🖼️  {artwork_url}")

        # Role
        if role != "solo":
            status_parts.append(f"👥 {role.upper()}")

        # Polling interval and UPnP status
        upnp_status = ""
        if self.upnp_enabled:
            if self.upnp_event_count > 0:
                time_since_last = time.time() - self.last_upnp_event_time if self.last_upnp_event_time else None
                if time_since_last and time_since_last < 10:
                    upnp_status = f" + UPnP ({self.upnp_event_count} events)"
                elif time_since_last is not None:
                    upnp_status = f" + UPnP ({self.upnp_event_count} events, last {int(time_since_last)}s ago)"
                else:
                    upnp_status = f" + UPnP ({self.upnp_event_count} events)"
            else:
                upnp_status = " + UPnP (no events yet)"
        status_parts.append(f"📡 poll: {interval:.1f}s{upnp_status}")

        # Print status line (overwrite previous line, clear to end)
        status_line = " | ".join(status_parts)
        print(f"\r{status_line:<100}", end="", flush=True)

    async def stop(self) -> None:
        """Stop monitoring."""
        self.running = False

        # Stop UPnP subscriptions
        if self.upnp_eventer:
            try:
                await self.upnp_eventer.async_unsubscribe()
            except Exception:
                pass

        if self.upnp_client:
            try:
                await self.upnp_client.unwind_notify_server()
            except Exception:
                pass

        await self.player.client.close()

    def print_statistics(self) -> None:
        """Print monitoring statistics summary."""
        if self.start_time is None:
            return

        duration = time.time() - self.start_time
        duration_min = int(duration // 60)
        duration_sec = int(duration % 60)

        print("\n" + "=" * 60)
        print("📊 Monitoring Statistics")
        print("=" * 60)

        # Duration
        print(f"⏱️  Duration: {duration_min}m {duration_sec}s")

        # HTTP Polling
        avg_interval = sum(self.poll_intervals) / len(self.poll_intervals) if self.poll_intervals else 0
        print("\n📡 HTTP Polling:")
        print(f"   • Total polls: {self.http_poll_count}")
        print(f"   • Average interval: {avg_interval:.2f}s")
        if self.poll_intervals:
            print(f"   • Interval range: {min(self.poll_intervals):.2f}s - {max(self.poll_intervals):.2f}s")

        # UPnP Events
        if self.upnp_enabled:
            print("\n📨 UPnP Events:")
            print(f"   • Total events received: {self.upnp_event_count}")
            if self.last_upnp_event_time and self.start_time:
                time_since_last = time.time() - self.last_upnp_event_time
                if time_since_last < 60:
                    print(f"   • Last event: {int(time_since_last)}s ago")
                else:
                    print(f"   • Last event: {int(time_since_last // 60)}m {int(time_since_last % 60)}s ago")
            if self.upnp_event_count > 0 and duration > 0:
                events_per_min = (self.upnp_event_count / duration) * 60
                print(f"   • Average rate: {events_per_min:.1f} events/min")
            if self.upnp_client:
                print("   • Status: ✅ Subscribed")
            else:
                print("   • Status: ❌ Not available")
        else:
            print("\n📨 UPnP Events: ❌ Not enabled")

        # State Changes
        print("\n🔄 State Changes:")
        print(f"   • Total changes detected: {self.state_change_count}")
        if self.http_poll_count > 0:
            change_rate = (self.state_change_count / self.http_poll_count) * 100
            print(f"   • Change rate: {change_rate:.1f}% of polls")

        # Errors
        if self.error_count > 0:
            print(f"\n⚠️  Errors: {self.error_count}")
        else:
            print("\n✅ Errors: None")

        # Device Status
        print("\n📱 Device Status:")
        print(f"   • Available: {'✅' if self.player.available else '❌'}")
        if self.player.device_info:
            print(f"   • Name: {self.player.device_info.name}")
            print(f"   • Model: {self.player.device_info.model}")
        if self.player.play_state:
            print(f"   • Play state: {self.player.play_state}")

        print("=" * 60)


async def main() -> int:
    """Main entry point for monitor CLI."""
    import argparse
    import logging

    parser = argparse.ArgumentParser(
        description="Real-time WiiM player monitor with UPnP event support",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage
  wiim-monitor 192.168.1.68

  # Specify callback host for UPnP
  wiim-monitor 192.168.1.68 --callback-host 192.168.1.254

  # Enable verbose logging for debugging
  wiim-monitor 192.168.1.68 --verbose
  wiim-monitor 192.168.1.68 --log-level DEBUG
        """,
    )
    parser.add_argument(
        "device_ip",
        help="Device IP address or hostname",
    )
    parser.add_argument(
        "--callback-host",
        help="IP address for UPnP callback URL (auto-detected if not specified)",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose logging (equivalent to --log-level INFO)",
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        default="WARNING",
        help="Set logging level (default: WARNING)",
    )

    args = parser.parse_args()
    device_ip = args.device_ip
    callback_host_override = args.callback_host

    # Configure logging
    log_level = logging.INFO if args.verbose else getattr(logging, args.log_level)
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    _LOGGER = logging.getLogger(__name__)

    # Create client and player
    client = WiiMClient(device_ip)
    player = Player(client, on_state_changed=None)  # We'll handle callbacks in monitor

    monitor = PlayerMonitor(player)
    monitor.player._on_state_changed = monitor.on_state_changed  # Set callback

    # Store callback host override for use in setup
    if callback_host_override:
        monitor._callback_host_override = callback_host_override
    else:
        monitor._callback_host_override = None

    try:
        await monitor.setup()
        await monitor.monitor_loop()
        # Print statistics if loop exits normally
        monitor.print_statistics()
        return 0
    except KeyboardInterrupt:
        print("\n\n⚠️  Monitoring stopped by user (Ctrl+C)")
        # Print statistics on Ctrl-C
        monitor.print_statistics()
        return 0
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        import traceback

        traceback.print_exc()
        return 1
    finally:
        # Clean up resources
        try:
            await monitor.stop()
        except Exception as cleanup_err:
            _LOGGER.debug("Error during cleanup: %s", cleanup_err)
        try:
            await client.close()
        except Exception as cleanup_err:
            _LOGGER.debug("Error closing client: %s", cleanup_err)


def cli_main() -> None:
    """CLI entry point."""
    sys.exit(asyncio.run(main()))


if __name__ == "__main__":
    cli_main()
