"""Scripts package for Valid8r."""
