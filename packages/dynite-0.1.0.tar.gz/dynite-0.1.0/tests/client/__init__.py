"""Test dynite client."""
