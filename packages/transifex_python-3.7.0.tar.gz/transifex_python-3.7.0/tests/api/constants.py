from __future__ import absolute_import, unicode_literals

host = "https://rest.api.transifex.com"
