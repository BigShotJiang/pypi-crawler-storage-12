from transifex.native.django.utils import lazy_translate as lazyt
from transifex.native.django.utils import translate as t
from transifex.native.django.utils import utranslate as ut

default_app_config = 'transifex.native.django.apps.NativeConfig'
