def main():
    print("Hello from jusfltuls!")


if __name__ == "__main__":
    main()
