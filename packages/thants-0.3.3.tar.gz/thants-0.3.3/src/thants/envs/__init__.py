from thants.envs.mono import ThantsMono
from thants.envs.multi import Thants
from thants.envs.presets import ThantsDual, ThantsQuad
