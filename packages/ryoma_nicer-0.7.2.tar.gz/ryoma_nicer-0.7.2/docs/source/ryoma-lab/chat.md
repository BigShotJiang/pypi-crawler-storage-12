# Chat
The Chat page is the main interfance for the user to interact with the Ryoma AI. The playground page is divided into two sections:

1. Chat Window
2. Notebook

## Chat Window
The playground window is where the user can interact with the AI. The user can ask questions, run code, and explore data using Ryoma AI.

## Notebook
The notebook is where the Ryoma AI generates code based on the user's input. The user can run the code in the notebook to see the output.
