# -*- coding: utf-8 -*-
"""mytext modules."""