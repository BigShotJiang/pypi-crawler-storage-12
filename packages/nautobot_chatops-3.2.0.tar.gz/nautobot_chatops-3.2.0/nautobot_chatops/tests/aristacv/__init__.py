"""Unit tests for Arista CloudVision integration."""
