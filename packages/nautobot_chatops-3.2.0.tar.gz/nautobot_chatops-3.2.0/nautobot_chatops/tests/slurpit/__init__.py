"""Unit tests for Slurpit Integration."""
