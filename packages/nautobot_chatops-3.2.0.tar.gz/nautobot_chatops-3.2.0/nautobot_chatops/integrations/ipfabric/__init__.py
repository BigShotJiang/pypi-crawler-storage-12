"""Base module for IP Fabric Integration."""
