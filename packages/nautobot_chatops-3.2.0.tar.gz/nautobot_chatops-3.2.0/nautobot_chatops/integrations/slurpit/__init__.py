"""Base module for Slurpit Integration."""
