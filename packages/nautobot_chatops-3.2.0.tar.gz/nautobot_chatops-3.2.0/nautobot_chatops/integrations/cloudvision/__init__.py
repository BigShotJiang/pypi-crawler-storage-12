"""Base module for Arista CloudVision integration."""
