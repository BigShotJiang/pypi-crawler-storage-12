from .QGISCore import QGISBase, QGISLocator, QGISAction
from .QGISMap import QGISMapOverlay


class QGISLibrary(QGISBase, QGISMapOverlay):
    pass

