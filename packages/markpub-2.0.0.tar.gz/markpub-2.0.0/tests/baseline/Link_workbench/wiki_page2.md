# wiki page2

 - another test page

2022-09-19: testing linking to different pages with the same name:

- link to the first page created: [[Link workbench/samePageName]]

- link to the second page created: [[Link workbench/subdir/samePageName]]  


