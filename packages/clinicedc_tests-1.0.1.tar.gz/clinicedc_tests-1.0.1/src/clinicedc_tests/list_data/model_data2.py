model_data = {
    ("clinicedc_tests.consignee", "name"): [
        {
            "name": "The META Trial",
            "contact": "Sokoine Kivuyo",
            "address": "NIMR Tanzania",
        }
    ]
}
