list_data = {
    "clinicedc_tests.antibiotic": [
        ("one", "One"),
        ("two", "Two"),
        ("three", "Three"),
    ],
}
