|pypi| |downloads| |clinicedc|

.. |pypi| image:: https://img.shields.io/pypi/v/clinicedc-tests.svg
    :target: https://pypi.python.org/pypi/clinicedc-tests

.. |downloads| image:: https://pepy.tech/badge/clinicedc-tests
   :target: https://pepy.tech/project/clinicedc-tests

.. |clinicedc| image:: https://img.shields.io/badge/framework-Clinic_EDC-green
   :alt:Made with clinicedc
   :target: https://github.com/clinicedc
