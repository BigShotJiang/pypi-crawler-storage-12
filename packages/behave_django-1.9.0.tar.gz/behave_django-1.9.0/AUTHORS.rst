Maintainers
-----------

* `Mitchel Cabuloy <https://github.com/mixxorz>`_ (original author)
* `Peter Bittner <https://github.com/bittner>`_
* `Javier Buzzi <https://github.com/kingbuzzman>`_

Contributors
------------

* `薛丞宏 <https://github.com/sih4sing5hong5>`_
* `Alex Hutton <https://github.com/alex-hutton>`_
* `Dave Kwon <https://github.com/Blue-Hope>`_
* `David Avsajanishvili <https://github.com/avsd>`_
* `Dolan Antenucci <https://github.com/pydolan>`_
* `Ivan Rocha <https://github.com/ivancrneto>`_
* `Jens Engel <https://github.com/jenisys>`_
* `Jérôme Thiard <https://github.com/jthiard>`_
* `Juho Rutila <https://github.com/jrutila>`_
* `Karel Hovorka <https://github.com/hovi>`_
* `Nate Hill <https://github.com/nhill-cpi>`_
* `Nik Nyby <https://github.com/nikolas>`_
* `Paolo Melchiorre <https://github.com/pauloxnet>`_
* `Sebastian Manger <https://github.com/sebastianmanger>`_
* `Tom Mortimer-Jones <https://github.com/morty>`_
* `Wojciech Banaś <https://github.com/fizista>`_
