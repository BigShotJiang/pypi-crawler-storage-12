"""Behave BDD integration for Django"""

__version__ = '1.9.0'
