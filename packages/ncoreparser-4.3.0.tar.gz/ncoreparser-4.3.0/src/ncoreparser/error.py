class NcoreConnectionError(Exception):
    pass


class NcoreCredentialError(Exception):
    pass


class NcoreParserError(Exception):
    pass


class NcoreDownloadError(Exception):
    pass
