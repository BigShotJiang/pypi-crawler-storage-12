:github_url: {{ fullname }}

{% extends "!autosummary/base.rst" %}

.. http://www.sphinx-doc.org/en/stable/ext/autosummary.html#customizing-templates
