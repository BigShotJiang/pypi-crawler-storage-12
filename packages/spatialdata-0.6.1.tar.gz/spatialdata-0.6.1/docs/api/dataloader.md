# Data Loaders

```{eval-rst}
.. currentmodule:: spatialdata.dataloader

.. autoclass:: ImageTilesDataset
```
