#!/usr/bin/env bash
export PYTHONPATH=src
export DCO_ENV=development
python -m examples.simple_app.app
