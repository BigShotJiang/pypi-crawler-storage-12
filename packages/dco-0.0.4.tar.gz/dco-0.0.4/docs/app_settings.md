# AppSettings Configuration

AppSettings

## Properties

### `debug`
- **Type:** boolean • Optional • **Default:** `False`

Debug

### `environment`
- **Type:** string • Optional • **Default:** `development`

Environment

### `sample_value`
- **Type:** string • Optional • **Default:** `hello`

Sample Value

### `db`
- **Type:** any • **Required**
