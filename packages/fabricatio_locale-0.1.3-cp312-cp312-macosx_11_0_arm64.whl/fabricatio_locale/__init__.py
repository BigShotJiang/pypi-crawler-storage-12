"""An extension of fabricatio, which brings up the capability to generate locolization based on po file.."""
