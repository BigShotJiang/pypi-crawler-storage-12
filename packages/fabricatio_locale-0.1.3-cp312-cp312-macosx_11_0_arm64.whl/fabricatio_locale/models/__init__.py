"""Models defined in fabricatio-locale."""
