"""Workflows defined in fabricatio-locale."""
