"""Capabilities defined in fabricatio-locale."""
