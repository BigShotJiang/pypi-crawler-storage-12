"""Actions defined in fabricatio-locale."""
