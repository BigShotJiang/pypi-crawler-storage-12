from decimal import Decimal


KG = Decimal("0.001")
UNIT_IN_STROOPS = Decimal(10_000_000)
