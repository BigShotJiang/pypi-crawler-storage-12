# Vizion

Smart EDA and model suggestion library.

## Installation

```bash
pip install vizion

"""
--Usage--

import pandas as pd
import vizion

df = pd.read_csv("data.csv")
vizion.data_summary(df)
vizion.plot_columns(df)
steps = vizion.help_steps()

"""