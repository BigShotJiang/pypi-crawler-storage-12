"""HireBase MCP Server package."""

__version__ = "1.0.22"

from src.server import main

if __name__ == "__main__":
    main()
