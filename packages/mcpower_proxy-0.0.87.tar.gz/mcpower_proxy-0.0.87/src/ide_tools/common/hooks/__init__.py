"""
Common Hook Handlers

Shared hook logic for all IDEs
"""
