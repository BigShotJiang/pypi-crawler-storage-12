# TOPIC: Trusted Offline Portable Information Container

This is a placeholder Python package for TOPIC.
It currently does nothing, but it will be updated in the future.
