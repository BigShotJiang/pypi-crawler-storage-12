"""Juejin (掘金) fetcher package."""

from .fetcher import JuejinFetcher

__all__ = ["JuejinFetcher"]
