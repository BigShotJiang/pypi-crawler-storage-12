"""Indie Hackers fetcher package."""

from .fetcher import IndieHackersFetcher

__all__ = ["IndieHackersFetcher"]
