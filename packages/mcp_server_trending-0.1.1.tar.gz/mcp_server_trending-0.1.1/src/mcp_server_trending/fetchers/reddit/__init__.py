"""Reddit fetcher package."""

from .fetcher import RedditFetcher

__all__ = ["RedditFetcher"]
