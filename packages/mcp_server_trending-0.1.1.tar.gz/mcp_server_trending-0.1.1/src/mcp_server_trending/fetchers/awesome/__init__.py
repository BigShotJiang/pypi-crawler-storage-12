"""Awesome Lists fetcher module."""

from .fetcher import AwesomeFetcher

__all__ = ["AwesomeFetcher"]

