"""HuggingFace fetcher package."""

from .fetcher import HuggingFaceFetcher

__all__ = ["HuggingFaceFetcher"]
