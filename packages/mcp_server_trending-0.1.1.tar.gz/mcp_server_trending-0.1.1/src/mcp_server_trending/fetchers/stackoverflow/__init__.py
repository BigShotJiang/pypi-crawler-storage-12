"""Stack Overflow fetcher module."""

from .fetcher import StackOverflowFetcher

__all__ = ["StackOverflowFetcher"]

