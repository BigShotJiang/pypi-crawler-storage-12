"""Top-level package for the DeepSeek CLI."""

from __future__ import annotations

from . import testing as testing

__all__ = ["__version__", "testing"]

__version__ = "0.6.5"
