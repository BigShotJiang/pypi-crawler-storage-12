# Security Policy

## Reporting a Vulnerability

If you have found a possible vulnerability, please email `security at plugboard dot dev`.
