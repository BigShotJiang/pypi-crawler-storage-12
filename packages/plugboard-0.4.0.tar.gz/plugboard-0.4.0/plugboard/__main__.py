"""Provides CLI entrypoint."""

from plugboard.cli import app


if __name__ == "__main__":
    app()
