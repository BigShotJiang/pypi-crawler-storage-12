"""Plugboard is a modelling and orchestration framework for simulating complex processes."""

from importlib.metadata import version


__version__ = version(__package__)
