# component
::: plugboard.component
    options:
      members:
      - Component
      - IOController

## component.utils
::: plugboard.component.utils
    options:
      members:
      - component
      - ComponentDecoratorHelper
