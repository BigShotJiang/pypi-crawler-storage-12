# utils
::: plugboard.utils
    options:
        filters:
        - "!Settings"