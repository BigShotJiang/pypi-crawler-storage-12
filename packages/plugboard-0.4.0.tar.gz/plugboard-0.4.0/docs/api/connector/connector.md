::: plugboard.connector
    options:
      members:
      - Connector
      - ConnectorSpec
      - Channel
      - AsyncioConnector
      - AsyncioChannel
      - SerdeChannel
      - RabbitMQConnector
      - RabbitMQChannel
      - RayConnector
      - RayChannel
      - ZMQConnector
      - ZMQChannel
