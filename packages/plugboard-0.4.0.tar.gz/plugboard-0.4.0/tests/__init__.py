"""Provides tests for plugboard package."""
