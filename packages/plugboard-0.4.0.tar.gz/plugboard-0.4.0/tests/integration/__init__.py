"""Provides integration tests for plugboard package."""
