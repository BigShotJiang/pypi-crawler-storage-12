"""Provides benchmark tests for Plugboard."""
