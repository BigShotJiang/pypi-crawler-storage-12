"""Provides unit tests for plugboard package."""
