from rapidquery import _lib
import dataclasses
import typing
import pytest


@dataclasses.dataclass
class ColumnTestCase:
    name: str
    type: typing.Type
    primary_key: bool = False
    unique: bool = False
    nullable: bool = False
    auto_increment: bool = False
    extra: str | None = None
    comment: str | None = None
    default_expr: str = ""
    stored_generated: bool = False
    column_ref: typing.Optional[_lib.ColumnRef] = None


def test_different_types():
    # Simple
    ty = _lib.IntegerType()
    assert ty == _lib.IntegerType()
    assert repr(ty) == "<IntegerType >"

    # Length
    ty = _lib.StringType(None)
    assert ty == _lib.StringType()
    assert ty.length is None
    assert repr(ty) == "<StringType length=None>"

    ty = _lib.StringType(20)
    assert ty != _lib.StringType(30)
    assert ty != _lib.StringType(None)
    assert ty == _lib.StringType(20)
    assert ty.length == 20
    assert repr(ty) == "<StringType length=20>"

    # Percision Scale
    ty = _lib.MoneyType()
    assert ty == _lib.MoneyType()
    assert ty.precision_scale is None
    assert repr(ty) == "<MoneyType precision_scale=None>"

    ty = _lib.MoneyType((10, 8))
    assert ty != _lib.MoneyType((4, 6))
    assert ty != _lib.MoneyType(None)
    assert ty == _lib.MoneyType((10, 8))
    assert ty.precision_scale == (10, 8)
    assert repr(ty) == "<MoneyType precision_scale=(10, 8)>"

    # Enum
    ty = _lib.EnumType("priority", ["low", "medium"])
    assert ty.name == "priority"
    assert ty.variants == ["low", "medium"]

    assert ty == _lib.EnumType("priority", ["low", "medium"])
    assert ty != _lib.EnumType("priority", ["low", "medium", "high"])

    # Array
    try:
        ty = _lib.ArrayType(str)
    except Exception:
        pass
    else:
        pytest.fail()

    ty = _lib.ArrayType(_lib.TextType())
    assert ty.element == _lib.TextType()

    # Interval
    try:
        ty = _lib.IntervalType(5983)
    except Exception:
        pass
    else:
        pytest.fail()

    ty = _lib.IntervalType(_lib.INTERVAL_DAY_TO_MINUTE)
    assert ty.fields == _lib.INTERVAL_DAY_TO_MINUTE
    assert ty.precision is None

    ty = _lib.IntervalType(_lib.INTERVAL_HOUR, 5)
    assert ty.fields == _lib.INTERVAL_HOUR
    assert ty.precision == 5


_metadata_column = _lib.Column(
    "metadata", _lib.ArrayType(_lib.IntegerType()), nullable=True, default=[1, 2, 3]
)
_lib.Table("users", [_metadata_column])


columndata = [
    (
        _lib.Column(
            "id",
            _lib.BigIntegerType(),
            primary_key=True,
            nullable=False,
            auto_increment=True,
            default=1,
        ),
        ColumnTestCase(
            "id",
            _lib.BigIntegerType,
            primary_key=True,
            nullable=False,
            auto_increment=True,
            default_expr="1",
            column_ref=_lib.ColumnRef("id"),
        ),
    ),
    (
        _metadata_column,
        ColumnTestCase(
            "metadata",
            _lib.ArrayType,
            nullable=True,
            default_expr="ARRAY [1,2,3]",
            column_ref=_lib.ColumnRef("metadata", table="users"),
        ),
    ),
]


@pytest.mark.parametrize("val,case", columndata)
def test_column(val: _lib.Column, case: ColumnTestCase):
    assert val.name == case.name
    assert val.primary_key == case.primary_key
    assert val.unique == case.unique
    assert val.nullable == case.nullable
    assert val.auto_increment == case.auto_increment
    assert val.extra == case.extra
    assert val.comment == case.comment
    assert val.stored_generated == case.stored_generated
    assert val.to_column_ref() == case.column_ref
    assert val.default.to_sql("postgres") == case.default_expr

    val.extra = "HELLO"
    val.comment = "COMMENT"

    assert val.extra == "HELLO"
    assert val.comment == "COMMENT"
