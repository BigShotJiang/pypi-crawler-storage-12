from .hifigan import HifiganConfig, HifiganGenerator
from .istftnet import iSTFTNetConfig, iSTFTNetGenerator
