"""Version information."""
VERSION = "1.2.3"
