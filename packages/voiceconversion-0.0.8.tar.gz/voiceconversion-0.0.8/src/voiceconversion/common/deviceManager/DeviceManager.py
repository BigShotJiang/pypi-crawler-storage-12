import torch
import onnxruntime
import re
import threading
from typing import TypedDict, Literal
from enum import IntFlag

try:
    import torch_directml
except ImportError:
    import voiceconversion.common.deviceManager.DummyDML as torch_directml

import logging

logger = logging.getLogger(__name__)


class CoreMLFlag(IntFlag):
    USE_CPU_ONLY = 0x001
    ENABLE_ON_SUBGRAPH = 0x002
    ONLY_ENABLE_DEVICE_WITH_ANE = 0x004
    ONLY_ALLOW_STATIC_INPUT_SHAPES = 0x008
    CREATE_MLPROGRAM = 0x010


class DevicePresentation(TypedDict):
    id: int
    name: str
    memory: int
    backend: Literal['cpu', 'cuda', 'directml', 'mps']


class DeviceManagerAccessError(RuntimeError):
    """Raised when DeviceManager is used outside of an allowed context."""

    pass


class DeviceManagerContext:
    _local = threading.local()

    def __enter__(self):
        count = getattr(self._local, "count", 0)
        self._local.count = count + 1
        self._local.enabled = True
        return DeviceManager.get_instance()

    def __exit__(self, exc_type, exc_val, exc_tb):
        count = getattr(self._local, "count", 1) - 1
        if count <= 0:
            self._local.enabled = False
            self._local.count = 0
        else:
            self._local.count = count

    @classmethod
    def is_enabled(cls) -> bool:
        return getattr(cls._local, "enabled", False)


def require_context(func):
    """Decorator to block calls outside DeviceManagerContext."""

    def wrapper(*args, **kwargs):
        if not DeviceManagerContext.is_enabled():
            raise DeviceManagerAccessError(
                f"Cannot call {func.__qualname__}() outside DeviceManagerContext"
            )
        return func(*args, **kwargs)

    return wrapper


def with_device_manager_context(func):
    """Runs the wrapped function inside a DeviceManagerContext automatically."""
    from functools import wraps

    @wraps(func)
    def wrapper(*args, **kwargs):
        with DeviceManagerContext():
            return func(*args, **kwargs)

    return wrapper


def allow_outside_context(func):
    """Marker decorator: exempt this method from context enforcement."""
    func._allow_outside_context = True
    return func


class ContextProtectedMeta(type):
    """Metaclass to automatically protect all public methods (instance, static, or class)."""

    def __new__(mcls, name, bases, namespace):
        for attr, val in namespace.items():
            if attr.startswith("_"):
                continue
            target_func = (
                val.__func__ if isinstance(val, (staticmethod, classmethod)) else val
            )
            if getattr(target_func, "_allow_outside_context", False):
                continue
            if isinstance(val, staticmethod):
                fn = val.__func__
                namespace[attr] = staticmethod(require_context(fn))
            elif isinstance(val, classmethod):
                fn = val.__func__
                namespace[attr] = classmethod(require_context(fn))
            elif callable(val):
                namespace[attr] = require_context(val)
        return super().__new__(mcls, name, bases, namespace)


class DeviceManager(metaclass=ContextProtectedMeta):
    _instance = None

    @classmethod
    def get_instance(cls):
        if not DeviceManagerContext.is_enabled():
            raise DeviceManagerAccessError(
                "DeviceManager.get_instance() called outside DeviceManagerContext"
            )
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self.device = torch.device('cpu')
        self.cuda_enabled = torch.cuda.is_available()
        self.mps_enabled: bool = (
            getattr(torch.backends, "mps", None) is not None
            and torch.backends.mps.is_available()
        )
        self.dml_enabled: bool = torch_directml.is_available()
        self.fp16_available = False
        self.force_fp32 = False
        self.disable_jit = False
        self.lock = threading.Lock()
        logger.info('Initialized DeviceManager. Backend statuses:')
        logger.info(f'* DirectML: {self.dml_enabled}, device count: {torch_directml.device_count()}')
        logger.info(f'* CUDA: {self.cuda_enabled}, device count: {torch.cuda.device_count()}')
        logger.info(f'* MPS: {self.mps_enabled}')

    def initialize(self, device_id: int, force_fp32: bool, disable_jit: bool):
        self.set_device(device_id)
        self.force_fp32 = force_fp32
        self.disable_jit = disable_jit

    def set_device(self, id: int):
        if self.mps_enabled:
            torch.mps.empty_cache()
        elif self.cuda_enabled:
            torch.cuda.empty_cache()

        device, metadata = self._get_device(id)
        self.device = device
        self.device_metadata = metadata
        self.fp16_available = self.is_fp16_available()
        logger.info(f'Switched to {metadata["name"]} ({device}). FP16 support: {self.fp16_available}')

        # Enable TF32 on supported NVIDIA GPUs (Ampere/Hopper or newer)
        try:
            if self.device.type == 'cuda':
                major, _ = torch.cuda.get_device_capability(self.device)
                if major >= 8:
                    # Allow TensorFloat-32 for float32 matmul and cuDNN conv
                    torch.backends.cuda.matmul.allow_tf32 = True
                    if hasattr(torch.backends, 'cudnn'):
                        torch.backends.cudnn.allow_tf32 = True
                    # Use highest matmul precision (lets PyTorch pick TF32 where applicable)
                    if hasattr(torch, 'set_float32_matmul_precision'):
                        torch.set_float32_matmul_precision('high')
                    logger.info('Enabled TF32 (TensorFloat-32) for CUDA matmul/conv on this GPU.')
        except Exception as e:
            logger.debug(f'Unable to configure TF32: {e}')

    def use_fp16(self):
        return self.fp16_available and not self.force_fp32

    def use_jit_compile(self):
        # FIXME: DirectML backend seems to have issues with JIT. Disable it for now.
        return self.device_metadata['backend'] != 'directml' and not self.disable_jit

    # TODO: This function should also accept backend type
    def _get_device(self, dev_id: int) -> tuple[torch.device, DevicePresentation]:
        if dev_id == -1:
            if self.mps_enabled:
                return (torch.device('mps'), { "id": -1, "name": "MPS", 'backend': 'mps' })
            else:
                return (torch.device("cpu"), { "id": -1, "name": "CPU", 'backend': 'cpu' })

        if self.cuda_enabled:
            name = torch.cuda.get_device_name(dev_id)
            memory = torch.cuda.get_device_properties(dev_id).total_memory
            return (torch.device("cuda", index=dev_id), {"id": dev_id, "name": f"{dev_id}: {name} (CUDA)", "memory": memory, 'backend': 'cuda'})
        elif self.dml_enabled:
            name = torch_directml.device_name(dev_id)
            return (torch.device(torch_directml.device(dev_id)), {"id": dev_id, "name": f"{dev_id}: {name} (DirectML)", "memory": 0, 'backend': 'directml'})
        raise Exception(f'Failed to find device with index {dev_id}')

    @staticmethod
    @allow_outside_context
    def list_devices() -> list[DevicePresentation]:
        devCount = torch.cuda.device_count()
        if getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
            devices = [{ "id": -1, "name": "MPS", 'backend': 'mps' }]
        else:
            devices = [{ "id": -1, "name": "CPU", 'backend': 'cpu' }]
        for id in range(devCount):
            name = torch.cuda.get_device_name(id)
            memory = torch.cuda.get_device_properties(id).total_memory
            device = {"id": id, "name": f"{id}: {name} (CUDA)", "memory": memory, 'backend': 'cuda'}
            devices.append(device)
        devCount = torch_directml.device_count()
        for id in range(devCount):
            name = torch_directml.device_name(id)
            device = {"id": id, "name": f"{id}: {name} (DirectML)", "memory": 0, 'backend': 'directml'}
            devices.append(device)
        return devices

    def get_onnx_execution_provider(self):
        cpu_settings = {
            "intra_op_num_threads": 8,
            "execution_mode": onnxruntime.ExecutionMode.ORT_PARALLEL,
            "inter_op_num_threads": 8,
        }
        availableProviders = onnxruntime.get_available_providers()
        if self.device.type == 'cuda' and "ROCMExecutionProvider" in availableProviders:
            return ["ROCMExecutionProvider", "CPUExecutionProvider"], [{"device_id": self.device.index}, cpu_settings]
        elif self.device.type == 'cuda' and "CUDAExecutionProvider" in availableProviders:
            return ["CUDAExecutionProvider", "CPUExecutionProvider"], [{"device_id": self.device.index}, cpu_settings]
        elif self.device.type == 'privateuseone' and "DmlExecutionProvider" in availableProviders:
            return ["DmlExecutionProvider", "CPUExecutionProvider"], [{"device_id": self.device.index}, cpu_settings]
        elif 'CoreMLExecutionProvider' in availableProviders:
            coreml_flags = CoreMLFlag.ONLY_ENABLE_DEVICE_WITH_ANE
            return ["CoreMLExecutionProvider", "CPUExecutionProvider"], [{'coreml_flags': coreml_flags}, cpu_settings]
        else:
            return ["CPUExecutionProvider"], [cpu_settings]

    def set_disable_jit(self, disable_jit: bool):
        if self.mps_enabled:
            torch.mps.empty_cache()
        elif self.cuda_enabled:
            torch.cuda.empty_cache()
        self.disable_jit = disable_jit

    def set_force_fp32(self, force_fp32: bool):
        if self.mps_enabled:
            torch.mps.empty_cache()
        elif self.cuda_enabled:
            torch.cuda.empty_cache()
        self.force_fp32 = force_fp32

    def is_int8_avalable(self):
        if self.device.type == 'cpu':
            return True
        # TODO: Need information on INT8 support on GPUs.
        return False

    def is_fp16_available(self):
        # TODO: Maybe need to add bfloat16 support?
        # FP16 is not supported on CPU
        if self.device.type == 'cpu':
            return False

        device_name_uppercase = self.device_metadata['name'].upper()
        # TODO: Need information and filtering for Radeon and Intel GPUs
        # All Radeon GPUs starting from GCN 1 (Radeon HD 7000 series and later) reportedly have 2:1 FP16 performance
        # Intel UHD Graphics 600 and later reportedly have 2:1 FP16 performance
        # All Intel Arc GPUs reportedly have 2:1 FP16 performance or better
        ignored_nvidia_gpu = re.search(r'((GTX|RTX|TESLA|QUADRO) (V100|[789]\d{2}|1[06]\d{2}|P40|TITAN)|MX\d{3}|\d{3}MX)', device_name_uppercase)
        if ignored_nvidia_gpu is not None:
            return False

        # FIXME: Apparently FP16 does not work well for Intel iGPUs in DirectML backend.
        # Causes problems with Intel UHD on 10th Gen Intel CPU.
        ignored_intel_gpu = 'INTEL' in device_name_uppercase and 'ARC' not in device_name_uppercase
        if ignored_intel_gpu:
            return False

        if self.device.type == 'cuda':
            major, _ = torch.cuda.get_device_capability(self.device)
            if major < 7:  # コンピューティング機能が7以上の場合half precisionが使えるとされている（が例外がある？T500とか）
                return False

        return True
