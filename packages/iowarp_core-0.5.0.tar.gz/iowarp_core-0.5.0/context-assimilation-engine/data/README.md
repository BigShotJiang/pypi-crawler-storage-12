# CAE Sample Data

* A46_xx.csv: A sample file from AFRL Challenge
* A46_xx.h5: HDF5 file converted by Pandas from CSV
* afrl_list.md: AFRL Challenge file list in Globus