@CLAUDE.md We need to add the following methods to the core chimod:

## DelBlob

Removes blob info from the associated maps. Decrements the size of the tag the blob is apart of.

## DelTag

Removes all blobs from the tag and then removes the tag from all associated maps.

## GetTagSize

Get the size of a tag.
