This folder contains icons from the KDE Oxygen project, used in the HDFCompass
GUI. Refer to "license.txt" for the icon licensing terms.

The following images are NOT under the LGPL, and are (c) Heliosphere Research
LLC (all rights reserved):

logo.png
logo.xcf