from google.oauth2.service_account import Credentials
from typing import Optional


OptionalCredentials = Optional[Credentials]
