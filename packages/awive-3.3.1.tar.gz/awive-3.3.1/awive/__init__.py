import importlib.metadata

__version__ = importlib.metadata.version("awive")
__authors__ = importlib.metadata.metadata("awive")["Author-Email"]
