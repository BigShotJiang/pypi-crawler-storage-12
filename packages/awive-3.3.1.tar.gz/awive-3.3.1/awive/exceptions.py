class VideoSourceError(Exception):
    """Video source error."""

    pass
