from cel.assistants.context import Context

class RequestContext(Context):
    pass