"""EnvNX – a small CLI toolkit for environment checks, project cleanup, code search, and config sync."""
