from hatch_build import *  # noqa


def test_all():
    assert True
