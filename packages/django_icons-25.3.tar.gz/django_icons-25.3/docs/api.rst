===
API
===


icon
~~~~

.. autofunction:: django_icons.render_icon
