=========================
Template Tags and Filters
=========================


.. note::

 To use these template tags, you should have already loaded the ``icons`` template tag library,
 and made sure that the necessary media for the icons is available to your template (e.g.
 the FontAwesome CSS).
 Read the :doc:`installation` and :doc:`quickstart` sections on how to accomplish this.


icon
~~~~

.. autofunction:: django_icons.templatetags.icons.icon_tag
