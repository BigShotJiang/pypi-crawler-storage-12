Demo
====


There is a demo application in the `tests` folder. You can run it from the main directory::

    $ python manage.py runserver

