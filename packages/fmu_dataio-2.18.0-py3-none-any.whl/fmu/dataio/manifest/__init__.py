from ._manifest import get_manifest_path

__all__ = ["get_manifest_path"]
