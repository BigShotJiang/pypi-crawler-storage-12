# pypi_example

This is an example Python package registered as a placeholder to prevent dependency confusion attacks and ensure supply chain security.

