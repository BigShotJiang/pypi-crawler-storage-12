We need to create a unified readme based on the subdirectories. Each them should have its own
readme. No need to delete the individual readmes afterwards. 

IOWarp Core is a comprehensive platform for context management. 
