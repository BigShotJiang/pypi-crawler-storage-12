# wire-file

Wire for storing to a file.
