__title__ = "perftrack"
__version__ = "0.1.1"
__author__ = "Pravin Kamble"
__license__ = "MIT"
__copyright__ = "Copyright 2025 Pravin Kamble"

VERSION = __version__
