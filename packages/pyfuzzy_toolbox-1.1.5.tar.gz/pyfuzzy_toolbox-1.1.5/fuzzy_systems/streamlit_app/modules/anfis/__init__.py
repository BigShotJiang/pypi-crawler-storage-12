"""
ANFIS submodule package
"""

from . import dataset_tab
from . import training_tab
from . import metrics_tab
from . import prediction_tab
from . import analysis_tab
from . import overview_tab
