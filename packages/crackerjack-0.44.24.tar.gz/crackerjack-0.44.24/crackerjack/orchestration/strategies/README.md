# Orchestration Strategies

Strategy implementations for agent coordination.
