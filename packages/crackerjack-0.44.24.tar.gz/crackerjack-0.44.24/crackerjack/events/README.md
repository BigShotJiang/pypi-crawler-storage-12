# Events

Event types, signals, and dispatch-related helpers.
