"""
    Unit tests for raxpy
"""
