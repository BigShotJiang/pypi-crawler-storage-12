"""
    Tests the raxpy.spaces module.
"""
