"""
    Units tests that consider the introspectation and 
    specification of InputSpaces and OutputSpaces given
    a Python function
"""
