"""
    This modules provides design of experiment (DOE)
    data structures, design algorithms, design measurements
    computations.
"""
