.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Callback Plugins
=============================

ns.col2
-------

* `ns.col2.extra <ns/col2/extra_callback.rst>`_ --

ns2.col
-------

* `ns2.col.foo <ns2/col/foo_callback.rst>`_ -- Foo output :literal:`bar` (of callback plugin `ns2.col.foo <foo_callback.rst>`__)
