.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Collection Index
================

These are the collections documented here.

* `ns.col1 <ns/col1/index.rst>`_
* `ns.col2 <ns/col2/index.rst>`_
* `ns2.col <ns2/col/index.rst>`_
* `ns2.flatcol <ns2/flatcol/index.rst>`_
