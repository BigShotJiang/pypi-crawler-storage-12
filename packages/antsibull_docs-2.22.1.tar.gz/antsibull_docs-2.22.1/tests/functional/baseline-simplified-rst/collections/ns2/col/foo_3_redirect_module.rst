.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

ns2.col.foo_3_redirect module
+++++++++++++++++++++++++++++

- This redirect is part of the `ns2.col collection <https://galaxy.ansible.com/ui/repo/published/ns2/col/>`_ (version 2.1.0).

  To use it in a playbook, specify: ``ns2.col.foo_3_redirect``.

- This is a redirect to the ns2.col.foo2 module.
- This redirect does **not** work with Ansible 2.9.
