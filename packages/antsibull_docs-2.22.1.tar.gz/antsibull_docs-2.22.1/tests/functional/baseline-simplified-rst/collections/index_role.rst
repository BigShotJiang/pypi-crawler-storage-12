.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Roles
==================

ns.col2
-------

* `ns.col2.bar <ns/col2/bar_role.rst>`_ -- Bar role
* `ns.col2.extra <ns/col2/extra_role.rst>`_ --

ns2.col
-------

* `ns2.col.foo <ns2/col/foo_role.rst>`_ -- Foo role **(DEPRECATED)**
