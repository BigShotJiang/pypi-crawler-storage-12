.. Document meta

:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. Anchors

.. _ansible_collections.ns2.col.foo_5_redirect_module:

.. Title

ns2.col.foo_5_redirect module
+++++++++++++++++++++++++++++

.. Collection note

.. note::
    This redirect is part of the `ns2.col collection <https://galaxy.ansible.com/ui/repo/published/ns2/col/>`_ (version 2.1.0).


- This redirect has been **deprecated**. Please update your tasks to use the new name ``ns2.col.foo2`` instead.
  It will be removed in version 5.0.0 of ns2.col.
- This is a redirect to the :ansplugin:`ns2.col.foo2 module <ns2.col.foo2#module>`.
- This redirect does **not** work with Ansible 2.9.
- The collection contains the following information on this deprecation: It will be really gone
