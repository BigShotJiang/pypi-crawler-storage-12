.. Document meta

:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. Anchors

.. _ansible_collections.ns2.col.foo_redirect_module:

.. Title

ns2.col.foo_redirect module
+++++++++++++++++++++++++++

.. Collection note

.. note::
    This redirect is part of the `ns2.col collection <https://galaxy.ansible.com/ui/repo/published/ns2/col/>`_ (version 2.1.0).

    To use it in a playbook, specify: :code:`ns2.col.foo_redirect`.

- This is a redirect to the :ansplugin:`ns2.col.foo module <ns2.col.foo#module>`.
- This redirect does **not** work with Ansible 2.9.
