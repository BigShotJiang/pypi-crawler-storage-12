.. Document meta

:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. Anchors

.. _ansible_collections.ns2.col.is_bar_test:

.. Title

ns2.col.is_bar test
+++++++++++++++++++

.. Collection note

.. note::
    This redirect is part of the `ns2.col collection <https://galaxy.ansible.com/ui/repo/published/ns2/col/>`_ (version 2.1.0).

    To use it in a playbook, specify: :code:`ns2.col.is_bar`.

- This is a redirect to the :ansplugin:`ns2.col.bar test plugin <ns2.col.bar#test>`.
- This redirect does **not** work with Ansible 2.9.
