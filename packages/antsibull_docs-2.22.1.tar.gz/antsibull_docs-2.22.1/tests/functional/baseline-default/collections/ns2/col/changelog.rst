.. _changelog_for_ns2.col:

The changelog of ns2.col is empty.
