:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_shell_plugins:

Index of all Shell Plugins
==========================

ns.col2
-------

* :ansplugin:`ns.col2.extra#shell` --

ns2.col
-------

* :ansplugin:`ns2.col.foo#shell` -- Foo shell :ansopt:`ns2.col.foo#shell:bar`
