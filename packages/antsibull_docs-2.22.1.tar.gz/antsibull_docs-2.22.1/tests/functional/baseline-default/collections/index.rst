:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_collections:

Collection Index
================

These are the collections documented here.

* :anscollection:`ns.col1 <ns.col1>`
* :anscollection:`ns.col2 <ns.col2>`
* :anscollection:`ns2.col <ns2.col>`
* :anscollection:`ns2.flatcol <ns2.flatcol>`

.. toctree::
    :maxdepth: 1
    :hidden:

    ns/index
    ns2/index
