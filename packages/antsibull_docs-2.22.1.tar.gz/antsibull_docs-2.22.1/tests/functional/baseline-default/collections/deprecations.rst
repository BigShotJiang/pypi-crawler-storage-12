:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_all_deprecations:

Index of all deprecated plugins
===============================

Index of all deprecated become plugins
--------------------------------------

* :ansplugin:`ns2.col.foo#become` -- Use foo :ansopt:`ns2.col.foo#become:bar`
  (Will be removed from :anscollection:`ns2.col`
  5.0.0.)

Index of all deprecated roles
-----------------------------

* :ansplugin:`ns2.col.foo#role` -- Foo role
  (Will be removed from :anscollection:`ns2.col`
  in a major release after 2020-01-01.)
