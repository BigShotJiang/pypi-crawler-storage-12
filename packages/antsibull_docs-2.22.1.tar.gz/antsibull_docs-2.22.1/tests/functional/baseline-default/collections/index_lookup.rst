:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_lookup_plugins:

Index of all Lookup Plugins
===========================

ns.col2
-------

* :ansplugin:`ns.col2.extra#lookup` --

ns2.col
-------

* :ansplugin:`ns2.col.foo#lookup` -- Look up some foo :ansopt:`ns2.col.foo#lookup:bar`
