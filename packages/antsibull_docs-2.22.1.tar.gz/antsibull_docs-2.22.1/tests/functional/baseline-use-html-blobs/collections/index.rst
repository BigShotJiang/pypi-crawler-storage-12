:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_collections:

Collection Index
================

These are the collections documented here.

* :anscollection:`ns2.col <ns2.col>`

.. toctree::
    :maxdepth: 1
    :hidden:

    ns2/index
