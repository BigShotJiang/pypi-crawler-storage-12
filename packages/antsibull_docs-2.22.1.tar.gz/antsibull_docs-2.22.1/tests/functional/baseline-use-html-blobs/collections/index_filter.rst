:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_filter_plugins:

Index of all Filter Plugins
===========================

ns2.col
-------

* :ansplugin:`ns2.col.bar#filter` -- The bar filter
* :ansplugin:`ns2.col.foo#filter` -- The foo filter :ansopt:`ns2.col.foo#filter:bar`
