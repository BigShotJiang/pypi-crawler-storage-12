:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_cache_plugins:

Index of all Cache Plugins
==========================

ns2.col
-------

* :ansplugin:`ns2.col.foo#cache` -- Foo files :ansopt:`ns2.col.foo#cache:bar`
