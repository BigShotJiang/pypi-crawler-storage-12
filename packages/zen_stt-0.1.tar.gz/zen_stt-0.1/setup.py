from setuptools import setup,find_packages

setup(
    name='Zen-STT',
    version='0.1',
    author='ZEN',
    author_email='zenloq7@gmail.com',
    description='this is speech to text package created by ZEN'
)
packages = find_packages(),
install_requirement = [
    'selenium',
    'webdriver_manager'
]

