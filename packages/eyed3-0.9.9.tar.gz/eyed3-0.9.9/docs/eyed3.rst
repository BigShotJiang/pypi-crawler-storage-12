eyed3 package
=============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   eyed3.id3
   eyed3.mp3
   eyed3.plugins
   eyed3.utils

Submodules
----------

eyed3.core module
-----------------

.. automodule:: eyed3.core
   :members:
   :show-inheritance:
   :undoc-members:

eyed3.main module
-----------------

.. automodule:: eyed3.main
   :members:
   :show-inheritance:
   :undoc-members:

eyed3.mimetype module
---------------------

.. automodule:: eyed3.mimetype
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: eyed3
   :members:
   :show-inheritance:
   :undoc-members:
