eyed3.id3 package
=================

Submodules
----------

eyed3.id3.apple module
----------------------

.. automodule:: eyed3.id3.apple
   :members:
   :show-inheritance:
   :undoc-members:

eyed3.id3.frames module
-----------------------

.. automodule:: eyed3.id3.frames
   :members:
   :show-inheritance:
   :undoc-members:

eyed3.id3.headers module
------------------------

.. automodule:: eyed3.id3.headers
   :members:
   :show-inheritance:
   :undoc-members:

eyed3.id3.tag module
--------------------

.. automodule:: eyed3.id3.tag
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: eyed3.id3
   :members:
   :show-inheritance:
   :undoc-members:
