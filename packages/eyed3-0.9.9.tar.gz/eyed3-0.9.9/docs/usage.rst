:orphan:

========
Usage
========

To use eyeD3 in a project::

    import eyed3
