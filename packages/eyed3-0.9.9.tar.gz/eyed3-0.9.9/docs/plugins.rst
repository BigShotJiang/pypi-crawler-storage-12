Plugins
--------
.. toctree::
   :maxdepth: 1

   plugins/art_plugin
   plugins/classic_plugin
   plugins/extract_plugin
   plugins/fixup_plugin
   plugins/itunes_plugin
   plugins/json_plugin
   plugins/genres_plugin
   plugins/lameinfo_plugin
   plugins/mimetypes_plugin
   plugins/nfo_plugin
   plugins/pymod_plugin
   plugins/stats_plugin
   plugins/xep118_plugin
   plugins/yaml_plugin
