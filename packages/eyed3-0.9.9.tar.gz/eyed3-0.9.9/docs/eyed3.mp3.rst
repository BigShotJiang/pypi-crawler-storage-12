eyed3.mp3 package
=================

Submodules
----------

eyed3.mp3.headers module
------------------------

.. automodule:: eyed3.mp3.headers
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: eyed3.mp3
   :members:
   :show-inheritance:
   :undoc-members:
