YAML Plugin
===============

.. {{{cog
.. cog.out(cog_pluginHelp("yaml"))
.. }}}

*Outputs all tags as YAML.*

Names
-----
yaml 

Description
-----------


Options
-------
.. code-block:: text

  No extra options supported

.. {{{end}}}
