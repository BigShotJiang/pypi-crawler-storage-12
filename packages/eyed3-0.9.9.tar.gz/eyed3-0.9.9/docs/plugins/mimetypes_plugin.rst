Mime-types Plugin
==================

.. {{{cog
.. cog.out(cog_pluginHelp("mimetypes"))
.. }}}

*eyeD3 plugin*

Names
-----
mimetypes 

Description
-----------


Options
-------
.. code-block:: text

    --status         Print dot status.
    --parse-files    Parse each file.
    --hide-notfound


.. {{{end}}}
