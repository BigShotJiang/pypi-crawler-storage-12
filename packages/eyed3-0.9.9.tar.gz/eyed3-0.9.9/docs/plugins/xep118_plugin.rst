xep-118 - Jabber (XMPP) Tune Format
===================================

.. {{{cog
.. cog.out(cog_pluginHelp("xep-118"))
.. }}}

*Outputs all tags in XEP-118 XML format. (see: http://xmpp.org/extensions/xep-0118.html)*

Names
-----
xep-118 

Description
-----------


Options
-------
.. code-block:: text

    --no-pretty-print  Output without new lines or indentation.


.. {{{end}}}
