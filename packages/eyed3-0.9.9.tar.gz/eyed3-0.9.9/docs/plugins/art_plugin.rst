art(work) plugin
=================

.. {{{cog
.. cog.out(cog_pluginHelp("art"))
.. }}}

*Art for albums, artists, etc.*

Names
-----
art 

Description
-----------


Options
-------
.. code-block:: text

    -F, --update-files  Write art files from tag images.
    -T, --update-tags   Write tag image from art files.
    -D, --download      Attempt to download album art if missing.
    -v, --verbose       Show detailed information for all art found.


.. {{{end}}}
