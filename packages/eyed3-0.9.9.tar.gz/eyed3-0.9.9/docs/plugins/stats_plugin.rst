stats - Music Collection Statistics
===================================

.. {{{cog
.. cog.out(cog_pluginHelp("stats"))
.. }}}

*Computes statistics for all audio files scanned.*

Names
-----
stats 

Description
-----------


Options
-------
.. code-block:: text

    --verbose   Show details for each file with rule violations.


.. {{{end}}}
