JSON Plugin
===============

.. {{{cog
.. cog.out(cog_pluginHelp("json"))
.. }}}

*Outputs all tags as JSON.*

Names
-----
json 

Description
-----------


Options
-------
.. code-block:: text

    -c, --compact  Output in compact form, wound new lines or indentation.
    -s, --sort     Output JSON in sorted by key.


.. {{{end}}}
