Extract Plugin
===============

.. {{{cog
.. cog.out(cog_pluginHelp("extract"))
.. }}}

*Extract tags from audio files.*

Names
-----
extract 

Description
-----------


Options
-------
.. code-block:: text

    -o OUTPUT_FILE, --output-file OUTPUT_FILE
                          The the tag is written to this file in native format.
    -H, --hex             Output hexadecimal format.
    --strip-padding       Exclude tag padding, if any.


.. {{{end}}}

