eyed3 module
============

.. toctree::
   :maxdepth: 4

   eyed3
