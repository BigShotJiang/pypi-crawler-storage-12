"""
Generated protobuf code for Signal Fabric
"""
