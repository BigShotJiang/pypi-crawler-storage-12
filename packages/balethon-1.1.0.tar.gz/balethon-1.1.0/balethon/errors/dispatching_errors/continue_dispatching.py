class ContinueDispatching(Exception):
    pass
