class BreakDispatching(Exception):
    pass
