from __future__ import annotations

"""Utility functions."""

from adcp.utils.operation_id import create_operation_id

__all__ = ["create_operation_id"]
