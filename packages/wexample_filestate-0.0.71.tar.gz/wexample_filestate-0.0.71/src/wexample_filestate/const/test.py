from __future__ import annotations

TEST_FILE_NAME_SIMPLE_TEXT = "simple-text.txt"
TEST_DIR_NAME_RECURSIVE = "recursive-test"
