metrics computation
+ deprecated: analysis/, pipelines/
+ new: flow
