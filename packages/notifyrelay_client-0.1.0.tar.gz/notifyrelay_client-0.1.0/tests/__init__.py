# Tests for notifyrelay-client
