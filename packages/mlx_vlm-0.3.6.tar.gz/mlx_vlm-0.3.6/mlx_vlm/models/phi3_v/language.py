import inspect

from .config import TextConfig


class LanguageModel:
    pass
