Drillholes is a simple python library to visualise, composite, and create drill holes for which can be passed to implicit geological modelling packages such as gempy( potentially) and loopstructural.

