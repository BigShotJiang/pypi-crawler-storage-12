"""Tests for Fleet MCP authentication module."""
