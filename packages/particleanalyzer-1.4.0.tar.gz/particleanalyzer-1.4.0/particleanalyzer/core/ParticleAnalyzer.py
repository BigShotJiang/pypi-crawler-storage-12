import cv2
import numpy as np
import gradio as gr
import pandas as pd
import torch
from torch import device as torch_device
import os
import gc
from tqdm import tqdm
from typing import Optional, Tuple, Dict, List
from scipy.spatial.distance import pdist
import random
import re
from PIL import Image
import io
import json

try:
    from detectron2.engine import DefaultPredictor
    from particleanalyzer.core.CustomDetectron2Model import CustomDetectron2Model

    DETECTRON2_AVAILABLE = True
except ImportError:
    DETECTRON2_AVAILABLE = False
from sahi import AutoDetectionModel
from sahi.predict import get_sliced_prediction

from particleanalyzer.core.ModelManager import ModelManager
from particleanalyzer.core.ImagePreprocessor import ImagePreprocessor
from particleanalyzer.core.StatisticsBuilder import StatisticsBuilder
from particleanalyzer.core.languages import translations
from particleanalyzer.core.language_context import LanguageContext
from particleanalyzer.core.PointManager import PointManager
from particleanalyzer.core.EnhancementPipeline import EnhancementPipeline
from particleanalyzer.core.ScaleProcessor import ScaleProcessor

lang = "en"


class ParticleAnalyzer:
    SCALE_OPTIONS = {
        "Pixels": {
            "scale": False,
            "unit": "пикс",
            "unit_short": "px",
            "correction_factor": 1,
            "description": "Работа в пикселях без масштабирования",
        },
        "Micrometers (µm)": {
            "scale": True,
            "unit": "мкм",
            "unit_short": "µm",
            "correction_factor": 1,
            "description": "Масштабирование в микронах (1 µm = 1e-6 m)",
        },
        "Nanometers (nm)": {
            "scale": True,
            "unit": "нм",
            "unit_short": "nm",
            "correction_factor": 1,
            "description": "Масштабирование в нанометрах (1 nm = 1e-9 m)",
        },
    }

    def __init__(
        self,
        default_lang="en",
        device=None,
        output_dir: str = "output",
    ):
        """Инициализация анализатора частиц с настройкой окружения"""
        self._setup_environment(device)
        self.model_manager = ModelManager(device=self.device)
        self.preprocessor = ImagePreprocessor()
        self.point_manager = PointManager()
        self.scale_processor = ScaleProcessor(
            model=self.model_manager.get_model("ScaleProcessor"), device=self.device
        )
        # Улучшение качетсва изображения
        self.enhancement_pipeline = EnhancementPipeline()
        self.error_return = self._create_error_return()
        self.default_lang = default_lang
        # Устанавливаем язык в контекст
        LanguageContext.set_language(default_lang)

        # Устанавливаем папку для сохранения
        self.output_dir = output_dir

    def _setup_environment(self, device=None):
        """Настройка параметров окружения и CUDA"""
        os.environ["GRADIO_TEMP_DIR"] = os.path.expanduser("~/.gradio_temp")
        os.environ["GRADIO_ANALYTICS_ENABLED"] = "False"
        os.environ["GRADIO_CACHE_EXAMPLES"] = "True"
        # os.environ["GRADIO_SSR_MODE"] = "True"

        if device is None:
            self.device = torch_device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch_device(device)
        if self.device.type == "cuda":
            torch.set_default_device("cuda")
            torch.backends.cudnn.enabled = True
            torch.backends.cudnn.benchmark = True
            # Дополнительные настройки для лучшей производительности
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.allow_tf32 = True
            print(f"CUDA device in use: {torch.cuda.get_device_name(0)}")
        else:
            print("CUDA not available, using CPU")
            torch.set_default_device("cpu")

    def _get_translation(self, text):
        """Получение перевода текста на текущий язык"""
        return translations.get(self.lang, translations[self.default_lang]).get(
            text, text
        )

    def _determine_language(self, accept_language: str):
        """Определение языка на основе заголовка Accept-Language"""
        if not accept_language:
            return self.default_lang

        lang_code = accept_language.split(",")[0].lower()

        language_mapping = {
            "en-us": "en",
            "en": "en",
            "ru": "ru",
            "zh-cn": "zh-cn",
            "zh-tw": "zh-tw",
        }

        return language_mapping.get(
            lang_code, language_mapping.get(lang_code.split("-")[0], self.default_lang)
        )

    def _create_error_return(self) -> Tuple:
        """Создает кортеж для возврата в случае ошибки"""
        return (
            None,
            None,
            None,
            None,
            None,
            None,
            gr.update(visible=False),
            gr.update(visible=False),
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            gr.update(visible=False),
            gr.update(visible=False),
            None,
        )

    def analyze_image(
        self,
        image2: Optional[np.ndarray],
        scale: float,
        points_scale: tuple,
        scale_input: float,
        confidence_threshold: float,
        scale_selector: str,
        confidence_iou: float,
        number_detections: int,
        solution: str,
        model_change: str,
        round_value: int,
        slice_height: int,
        slice_width: int,
        overlap_height_ratio: float,
        overlap_width_ratio: float,
        sahi_mode: bool,
        number_of_bins: int,
        show_Feret_diametr: bool,
        show_Scale_bar: bool,
        outline_color,
        show_fillPoly: bool,
        show_polylines: bool,
        fill_type_color,
        fill_color,
        fill_alpha,
        pipelines_enhancer: str,
        api_key: bool,
        request: gr.Request,
        pr=gr.Progress(),
    ) -> Tuple:
        """
        Основной метод для анализа изображения.
        """
        lang = self._determine_language(request.headers.get("Accept-Language", ""))
        LanguageContext.set_language(lang)
        self.lang = lang  # Для обратной совместимости
        scale_selector = self.__class__.SCALE_OPTIONS[scale_selector]
        try:
            pbar = tqdm(
                total=6,
                desc=self._get_translation("Подготовка..."),
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]",
                leave=False,
            )
            pr(0, desc=self._get_translation("Подготовка..."))
            selected_image = image2

            if selected_image is None:
                gr.Warning(self._get_translation("Ошибка: изображение отсутствует..."))
                return self._create_error_return()

            image, orig_image, gray_image, scale, scale_factor_glob, image_name = (
                self.preprocessor.preprocess_image(
                    image=selected_image,
                    scale=scale,
                    scale_selector=scale_selector,
                    solution=solution,
                    request=request,
                    pbar=pbar,
                    pr=pr,
                    sahi_mode=sahi_mode,
                    lang=self.lang,
                )
            )
            if pipelines_enhancer:
                image = self.enhancement_pipeline.apply_pipeline(
                    image, pipelines_enhancer
                )

            if not scale and scale_selector["scale"]:
                return self._create_error_return()

            config = {
                "image": image,
                "scale_input": scale_input,
                "confidence_threshold": confidence_threshold,
                "scale_selector": scale_selector,
                "confidence_iou": confidence_iou,
                "number_detections": number_detections,
                "model_change": model_change,
                "round_value": round_value,
                "slice_height": slice_height,
                "slice_width": slice_width,
                "overlap_height_ratio": overlap_height_ratio,
                "overlap_width_ratio": overlap_width_ratio,
                "pbar": pbar,
                "pr": pr,
                "orig_image": orig_image,
                "gray_image": gray_image,
                "scale": scale,
                "scale_factor_glob": scale_factor_glob,
                "show_Feret_diametr": show_Feret_diametr,
                "outline_color": outline_color,
                "show_fillPoly": show_fillPoly,
                "show_polylines": show_polylines,
                "fill_type_color": fill_type_color,
                "fill_color": fill_color,
                "fill_alpha": fill_alpha,
            }

            # Выбор стратегии обработки

            processor = self._select_processor(model_change, sahi_mode)
            output_image, particle_data, annotations = processor(**config)

            if output_image is None and particle_data is None and annotations is None:
                self._cleanup(pbar)
                return self._create_error_return()

            self._create_binary_mask(annotations, image_name)

            if scale_selector["scale"] and show_Scale_bar:
                output_image = self.point_manager.draw_scale_on_image(
                    output_image, scale_factor_glob, scale, *points_scale
                )

            df = pd.DataFrame(particle_data)
            points_df = pd.DataFrame(df["points"])

            self._df_to_coco(points_df, output_image, image_name)

            df = df.drop(columns=["points"])

            pbar.set_description(self._get_translation("Построение таблицы..."))
            pr(0.75, desc=self._get_translation("Построение таблицы..."))

            builder = StatisticsBuilder(
                df,
                scale_selector,
                round_value=round_value,
                number_of_bins=number_of_bins,
                lang=self.lang,
            )
            stats_df = builder.build_stats_table()

            limits = self.calculate_limits(df, config["round_value"])

            pbar.update(1)

            pbar.set_description(self._get_translation("Построение графиков..."))
            pr(0.9, desc=self._get_translation("Построение графиков..."))
            fig, vector_fig = builder.build_distribution_fig(image)
            pbar.update(1)

            pr(1, desc=self._get_translation("Готово!"))
            return (
                output_image,
                df,
                points_df,
                fig,
                vector_fig,
                stats_df,
                gr.update(visible=api_key),
                gr.update(visible=True),
                gr.update(
                    minimum=limits["d_max_min"],
                    maximum=limits["d_max_max"],
                    value=(limits["d_max_min"], limits["d_max_max"]),
                    step=limits["d_max_max"] * 0.01,
                    label=f"Dₘₐₓ [{self._get_translation(scale_selector['unit'])}]",
                ),
                gr.update(
                    minimum=limits["d_min_min"],
                    maximum=limits["d_min_max"],
                    value=(limits["d_min_min"], limits["d_min_max"]),
                    step=limits["d_min_max"] * 0.01,
                    label=f"Dₘᵢₙ [{self._get_translation(scale_selector['unit'])}]",
                ),
                gr.update(
                    minimum=limits["theta_max_min"],
                    maximum=limits["theta_max_max"],
                    value=(limits["theta_max_min"], limits["theta_max_max"]),
                ),
                gr.update(
                    minimum=limits["theta_min_min"],
                    maximum=limits["theta_min_max"],
                    value=(limits["theta_min_min"], limits["theta_min_max"]),
                ),
                gr.update(minimum=0, maximum=1, value=(0, 1)),
                gr.update(
                    minimum=limits["S_min"],
                    maximum=limits["S_max"],
                    value=(limits["S_min"], limits["S_max"]),
                    step=limits["S_max"] * 0.01,
                    label=f"S [{self._get_translation(scale_selector['unit'])}²]",
                ),
                gr.update(
                    minimum=limits["P_min"],
                    maximum=limits["P_max"],
                    value=(limits["P_min"], limits["P_max"]),
                    step=limits["P_max"] * 0.01,
                    label=f"P [{self._get_translation(scale_selector['unit'])}]",
                ),
                gr.update(
                    minimum=limits["I_min"],
                    maximum=limits["I_max"],
                    value=(limits["I_min"], limits["I_max"]),
                ),
                gr.update(visible=True),
                gr.update(visible=True),
                image_name,
            )
        except Exception as e:
            self._handle_error(e)
            self._cleanup(pbar)
            return self._create_error_return()
        finally:
            self._cleanup(pbar)

    def _select_processor(self, model_name: str, sahi_mode: bool):
        """Выбор стратегии обработки в зависимости от модели и режима"""
        if sahi_mode:
            return self._process_with_sahi
        if model_name in self.model_manager.yolo_loader.MODEL_MAPPING:
            return self._process_with_yolo
        if model_name in self.model_manager.detectron_loader.MODEL_MAPPING:
            return self._process_with_detectron
        if model_name in self.model_manager.onnx_loader.MODEL_MAPPING:
            return self._process_with_onnx
        raise ValueError(f"Неизвестная модель или неподдерживаемый тип: {model_name}")

    def _process_with_onnx(self, **config):
        """Обработка с использованием ONNX моделей"""
        config["pbar"].set_description(
            self._get_translation("RF-DETR обрабатывает изображение...")
        )
        config["pr"](
            0.5, desc=self._get_translation("RF-DETR обрабатывает изображение...")
        )

        try:
            # Просто передаем numpy массив
            results = self.model_manager.predict(
                model_name=config["model_change"],
                image_np=config["image"],  # numpy массив
                confidence_threshold=config["confidence_threshold"],
                max_detections=config["number_detections"],
            )

        except Exception as e:
            self._handle_error(e)
            return None, None, None

        if len(results) == 0:
            gr.Info(self._get_translation("Объекты не обнаружены."))
            return None, None, None
        elif len(results) == config["number_detections"]:
            gr.Info(
                self._get_translation(
                    "Достигнут предел количества обнаружений. Увеличьте максимальное количество обнаружений в настройках."
                )
            )

        config["pbar"].update(1)

        config["pbar"].set_description(self._get_translation("Обработка частиц..."))
        config["pr"](0.62, desc=self._get_translation("Обработка частиц..."))

        output_image = config["orig_image"].copy()
        thickness = self._get_scaled_thickness(
            output_image.shape[1], output_image.shape[0]
        )
        particle_counter, particle_data, annotations = 1, [], []

        # Обработка детекций
        for i in range(len(results.xyxy)):
            mask = results.mask[i] if results.mask is not None else None

            if mask is not None:
                contours, _ = cv2.findContours(
                    mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
                )

                if contours:
                    main_contour = max(contours, key=cv2.contourArea)
                    points = main_contour.reshape(-1, 2)

                    particle_counter = self._analyze_particle(
                        points=points,
                        output_image=output_image,
                        thickness=thickness,
                        particle_data=particle_data,
                        annotations=annotations,
                        raw_mask=mask,
                        particle_counter=particle_counter,
                        **config,
                    )

        config["pbar"].update(1)
        return output_image, particle_data, annotations

    def _process_with_yolo(self, **config):
        """Обработка с использованием YOLO"""
        model = self.model_manager.get_model(config["model_change"])
        config["pbar"].set_description(
            self._get_translation("YOLO обрабатывает изображение...")
        )
        config["pr"](
            0.5, desc=self._get_translation("YOLO обрабатывает изображение...")
        )

        try:
            with torch.no_grad():
                results = model(
                    config["image"],
                    imgsz=640,
                    verbose=False,
                    conf=config["confidence_threshold"],
                    retina_masks=True,
                    iou=config["confidence_iou"],
                    max_det=config["number_detections"],
                    device=self.device,
                )
        except (torch.cuda.OutOfMemoryError, RuntimeError) as e:
            self._handle_gpu_error(e)
            return None, None, None
        except Exception as e:
            self._handle_error(e)
            return None, None, None

        if torch.cuda.is_available():
            torch.cuda.synchronize()

        if len(results[0].boxes) == 0:
            gr.Info(self._get_translation("Объекты не обнаружены."))
            return None, None, None
        elif len(results[0].boxes) == config["number_detections"]:
            gr.Info(
                self._get_translation(
                    "Достигнут предел количества обнаружений. Увеличьте максимальное количество обнаружений в настройках."
                )
            )
        config["pbar"].update(1)

        config["pbar"].set_description(self._get_translation("Обработка частиц..."))
        config["pr"](0.62, desc=self._get_translation("Обработка частиц..."))
        output_image = config["orig_image"].copy()
        thickness = self._get_scaled_thickness(
            output_image.shape[1], output_image.shape[0]
        )
        particle_counter, particle_data, annotations = 1, [], []
        for r in results:
            if r.masks is not None and len(r.masks.xy) > 0:
                for mask, mask2 in zip(r.masks.xy, r.masks.data.cpu().numpy()):
                    particle_counter = self._analyze_particle(
                        points=mask,
                        output_image=output_image,
                        thickness=thickness,
                        particle_data=particle_data,
                        annotations=annotations,
                        raw_mask=mask2,
                        particle_counter=particle_counter,
                        **config,
                    )
        config["pbar"].update(1)
        return output_image, particle_data, annotations

    def _process_with_detectron(self, **config):
        """Обработка с использованием Detectron2"""
        cfg = self.model_manager.get_model(config["model_change"])
        cfg.TEST.DETECTIONS_PER_IMAGE = config["number_detections"]
        cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = config["confidence_threshold"]
        cfg.MODEL.ROI_HEADS.NMS_THRESH_TEST = config["confidence_iou"]

        config["pbar"].set_description(
            self._get_translation("Detectron2 обрабатывает изображение...")
        )
        config["pr"](
            0.5, desc=self._get_translation("Detectron2 обрабатывает изображение...")
        )
        try:
            predictor = DefaultPredictor(cfg)
            results = predictor(config["image"])
            masks = results["instances"].pred_masks.to("cpu").numpy()
        except Exception as e:
            self._handle_error(e)
            return None, None, None
        if len(masks) == 0:
            gr.Info(self._get_translation("Объекты не обнаружены."))
            return None, None, None
        elif len(masks) == config["number_detections"]:
            gr.Info(
                self._get_translation(
                    "Достигнут предел количества обнаружений. Увеличьте максимальное количество обнаружений в настройках."
                )
            )
        config["pbar"].update(1)

        config["pbar"].set_description(self._get_translation("Обработка частиц..."))
        config["pr"](0.62, desc=self._get_translation("Обработка частиц..."))
        output_image = config["orig_image"].copy()
        thickness = self._get_scaled_thickness(
            output_image.shape[1], output_image.shape[0]
        )
        particle_counter, particle_data, annotations = 1, [], []
        for mask in masks:
            contours, _ = cv2.findContours(
                mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
            )
            if not contours:
                continue
            contour = max(contours, key=cv2.contourArea)
            points = contour.squeeze()
            particle_counter = self._analyze_particle(
                points=points,
                output_image=output_image,
                thickness=thickness,
                particle_data=particle_data,
                annotations=annotations,
                raw_mask=mask,
                particle_counter=particle_counter,
                **config,
            )
        config["pbar"].update(1)
        return output_image, particle_data, annotations

    def _process_with_sahi(self, **config):
        """Обработка с использованием SAHI"""
        if config["model_change"] in self.model_manager.yolo_loader.MODEL_MAPPING:
            detection_model = AutoDetectionModel.from_pretrained(
                model_type="ultralytics",
                model_path=self.model_manager.get_model_path(config["model_change"]),
                confidence_threshold=config["confidence_threshold"],
                device="cuda",
            )
        elif (
            config["model_change"] in self.model_manager.detectron_loader.MODEL_MAPPING
        ):
            detection_model = CustomDetectron2Model(
                model_path=self.model_manager.get_model_path(config["model_change"]),
                config_path=self.model_manager.get_config_path(config["model_change"]),
                confidence_threshold=config["confidence_threshold"],
                device="cuda",
            )

        config["pbar"].set_description(
            self._get_translation("SAHI обрабатывает изображение...")
        )
        config["pr"](
            0.5, desc=self._get_translation("SAHI обрабатывает изображение...")
        )
        try:
            results = get_sliced_prediction(
                config["image"],
                detection_model,
                slice_height=config["slice_height"],
                slice_width=config["slice_width"],
                overlap_height_ratio=config["overlap_height_ratio"],
                overlap_width_ratio=config["overlap_width_ratio"],
                postprocess_match_threshold=config["confidence_iou"],
                verbose=0,
            )
        except torch.cuda.OutOfMemoryError as e:
            self._handle_gpu_error(e)
            return None, None, None
        if len(results.object_prediction_list) == 0:
            gr.Info(self._get_translation("Объекты не обнаружены."))
            return None, None, None
        config["pbar"].update(1)

        config["pbar"].set_description(self._get_translation("Обработка частиц..."))
        config["pr"](0.62, desc=self._get_translation("Обработка частиц..."))
        output_image = config["orig_image"].copy()
        thickness = self._get_scaled_thickness(
            output_image.shape[1], output_image.shape[0]
        )

        image_height, image_width = config["orig_image"].shape[:2]

        particle_counter, particle_data, annotations = 1, [], []
        for r in results.object_prediction_list:
            mask = r.mask.segmentation
            mask2 = self._sahi_polygon_to_binary_mask(mask, image_height, image_width)
            if isinstance(mask, list) and len(mask) > 0:
                flat_coords = (
                    np.concatenate(mask).astype(np.int32)
                    if isinstance(mask[0], list)
                    else np.array(mask, dtype=np.int32)
                )
                if flat_coords.shape[0] < 6:
                    continue
                points = flat_coords.reshape(-1, 1, 2)
                particle_counter = self._analyze_particle(
                    points=points,
                    output_image=output_image,
                    thickness=thickness,
                    particle_data=particle_data,
                    annotations=annotations,
                    raw_mask=mask2,
                    particle_counter=particle_counter,
                    **config,
                )
        config["pbar"].update(1)
        return output_image, particle_data, annotations

    def _analyze_particle(self, **config) -> int:
        """Анализ отдельной частицы с расчетом Feret-диаметров"""
        if len(config["points"]) < 3:
            return config["particle_counter"]

        points = np.array(config["points"], dtype=np.int32).reshape((-1, 1, 2))

        # Вычисление центроида (геометрического центра)
        moments = cv2.moments(points)
        if moments["m00"] != 0:
            centroid_x = moments["m10"] / moments["m00"]
            centroid_y = moments["m01"] / moments["m00"]
        else:
            centroid_x, centroid_y = np.mean(points[:, 0, :], axis=0)

        # Вычисление базовых характеристик
        area = cv2.contourArea(points)
        perimeter = cv2.arcLength(points, closed=True)
        distances = pdist(points[:, 0, :])
        diameter = np.max(distances) if len(distances) > 0 else 0

        # Эксцентриситет
        eccentricity = 0
        if len(points) >= 5:
            ellipse = cv2.fitEllipse(points)
            (xc, yc), (major_axis, minor_axis), angle = ellipse
            a, b = max(major_axis, minor_axis) / 2, min(major_axis, minor_axis) / 2
            eccentricity = np.sqrt(1 - (b**2 / a**2)) if a > b else 0

        # Расчет Feret-диаметров и углов
        def get_feret(contour, angles=np.arange(0, 180, 1)):
            feret_values = []
            feret_angles = []

            for angle in angles:
                M = cv2.getRotationMatrix2D((0, 0), angle, 1)
                rotated = cv2.transform(contour, M)
                x_coords = rotated[:, 0, 0]
                feret = x_coords.max() - x_coords.min()
                feret_values.append(feret)
                feret_angles.append(angle)

            feret_max = max(feret_values)
            feret_min = min(feret_values)
            feret_mean = np.mean(feret_values)
            angle_max = feret_angles[feret_values.index(feret_max)]
            angle_min = feret_angles[feret_values.index(feret_min)]

            return feret_max, feret_min, feret_mean, angle_max, angle_min

        feret_max, feret_min, feret_mean, angle_max, angle_min = get_feret(points)

        # Средняя интенсивность
        mask_img = np.zeros_like(config["gray_image"], dtype=np.uint8)
        cv2.fillPoly(mask_img, [points], 255)
        mean_intensity = cv2.mean(config["gray_image"], mask=mask_img)[0]
        # Отрисовка контура и Feret-линий (опционально)
        if config["show_fillPoly"]:
            overlay = config["output_image"].copy()
            cv2.fillPoly(
                overlay,
                [points],
                (
                    self.get_random_color()
                    if config["fill_type_color"] == "Random"
                    else self.rgba_to_bgr(config["fill_color"])
                ),
            )
            alpha = config["fill_alpha"]
            cv2.addWeighted(
                overlay,
                alpha,
                config["output_image"],
                1 - alpha,
                0,
                config["output_image"],
            )
        if config["show_polylines"]:
            cv2.polylines(
                config["output_image"],
                [points],
                isClosed=True,
                color=self.rgba_to_bgr(config["outline_color"]),
                thickness=config["thickness"],
            )

        if config["show_Feret_diametr"]:
            self._draw_feret_lines(
                config["output_image"], points, angle_max, (0, 255, 255)
            )  # Желтый - Feret max
            self._draw_feret_lines(
                config["output_image"], points, angle_min, (255, 0, 0)
            )  # Синий - Feret min

        # Сохранение аннотации
        if config["annotations"] is not None and config["raw_mask"] is not None:
            config["annotations"].append(
                (config["raw_mask"], f"Particle {config['particle_counter']}")
            )

        # Масштабирование
        scale_factor = (
            float(config["scale_input"])
            / float(config["scale"])
            * config["scale_factor_glob"]
            / config["scale_selector"]["correction_factor"]
            if config["scale_selector"]["scale"]
            else 1 * config["scale_factor_glob"]
        )
        scale_area = scale_factor**2

        # Добавление данных частицы
        unit = self._get_translation(
            config["scale_selector"]["unit"]
        )  # Переводим единицу измерения

        config["particle_data"].append(
            {
                "№": round(config["particle_counter"], config["round_value"]),
                "D [{}]".format(unit): round(
                    diameter * scale_factor, config["round_value"]
                ),
                "Dₘₐₓ [{}]".format(unit): round(
                    feret_max * scale_factor, config["round_value"]
                ),
                "Dₘᵢₙ [{}]".format(unit): round(
                    feret_min * scale_factor, config["round_value"]
                ),
                "Dₘₑₐₙ [{}]".format(unit): round(
                    feret_mean * scale_factor, config["round_value"]
                ),
                "θₘₐₓ [°]": round(angle_max, config["round_value"]),
                "θₘᵢₙ [°]": round(angle_min, config["round_value"]),
                "S [{}²]".format(unit): round(area * scale_area, config["round_value"]),
                "P [{}]".format(unit): round(
                    perimeter * scale_factor, config["round_value"]
                ),
                "e": round(eccentricity, config["round_value"]),
                f'I [{self._get_translation("ед.")}]': round(
                    mean_intensity, config["round_value"]
                ),
                "centroid_x": round(centroid_x, config["round_value"]),
                "centroid_y": round(centroid_y, config["round_value"]),
                "points": points.tolist(),
            }
        )

        return config["particle_counter"] + 1

    def _draw_feret_lines(self, image, contour, angle, color=(0, 255, 0), thickness=2):
        """Отрисовка Feret-линий"""
        moments = cv2.moments(contour)
        if moments["m00"] == 0:
            return
        cx = int(moments["m10"] / moments["m00"])
        cy = int(moments["m01"] / moments["m00"])
        center = (cx, cy)

        M = cv2.getRotationMatrix2D(center, angle, 1.0)

        rotated = cv2.transform(contour, M)

        x_coords = rotated[:, 0, 0]
        if len(x_coords) == 0:
            return

        x_min, x_max = np.min(x_coords), np.max(x_coords)
        y_center = np.mean(rotated[:, 0, 1])

        pt1_rotated = np.array([[[x_min, y_center]]], dtype=np.float32)
        pt2_rotated = np.array([[[x_max, y_center]]], dtype=np.float32)

        M_inv = cv2.getRotationMatrix2D(center, -angle, 1.0)
        pt1 = cv2.transform(pt1_rotated, M_inv)[0][0]
        pt2 = cv2.transform(pt2_rotated, M_inv)[0][0]

        cv2.line(
            image, tuple(pt1.astype(int)), tuple(pt2.astype(int)), color, thickness
        )

    @staticmethod
    def _get_scaled_thickness(
        image_width: int,
        image_height: int,
        base_width: int = 300,
        base_thickness: int = 1,
    ) -> int:
        if image_width < base_width or image_height < base_width:
            return 1
        return max(1, int(base_thickness * (image_width / base_width)))

    def _handle_error(self, error: Exception):
        """Обработка ошибок"""
        gr.Warning(f"{self._get_translation('Критическая ошибка')}: {error}")
        print(f"{self._get_translation('Критическая ошибка')}: {error}")

    def _handle_gpu_error(self, error: Exception):
        """Обработка ошибок GPU"""
        gr.Warning(
            self._get_translation(
                "Ошибка: недостаточно памяти CUDA. Освобождаем память. Попробуйте уменьшить разрешение изображения или включите режим SAHI..."
            )
        )
        print(
            self._get_translation(
                "Ошибка: недостаточно памяти CUDA. Освобождаем память. Попробуйте уменьшить разрешение изображения или включите режим SAHI..."
            )
        )

    @staticmethod
    def get_random_color():
        """Генерирует случайный цвет в BGR формате"""
        return (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

    @staticmethod
    def rgba_to_bgr(rgba_str):
        numbers = re.findall(r"[\d.]+", rgba_str)
        if len(numbers) < 3:
            raise ValueError("Неправильный формат rgba")

        r = int(float(numbers[0]))
        g = int(float(numbers[1]))
        b = int(float(numbers[2]))

        return (b, g, r)

    @staticmethod
    def calculate_limits(df: pd.DataFrame, round_value: int) -> Dict[str, float]:

        results = {}

        results["d_max_max"] = round(
            df.iloc[:, 2].max() + df.iloc[:, 2].max() * 0.01, round_value
        )
        results["d_max_min"] = round(df.iloc[:, 2].min(), round_value)
        results["d_min_max"] = round(
            df.iloc[:, 3].max() + df.iloc[:, 3].max() * 0.01, round_value
        )
        results["d_min_min"] = round(df.iloc[:, 3].min(), round_value)

        results["theta_max_max"] = round(
            df.iloc[:, 5].max() + df.iloc[:, 5].max() * 0.01, round_value
        )
        results["theta_max_min"] = round(df.iloc[:, 5].min(), round_value)
        results["theta_min_max"] = round(
            df.iloc[:, 6].max() + df.iloc[:, 6].max() * 0.01, round_value
        )
        results["theta_min_min"] = round(df.iloc[:, 6].min(), round_value)

        results["S_max"] = round(
            df.iloc[:, 7].max() + df.iloc[:, 7].max() * 0.01, round_value
        )
        results["S_min"] = round(df.iloc[:, 7].min(), round_value)

        results["P_max"] = round(
            df.iloc[:, 8].max() + df.iloc[:, 8].max() * 0.01, round_value
        )
        results["P_min"] = round(df.iloc[:, 8].min(), round_value)

        results["I_max"] = round(
            df.iloc[:, 10].max() + df.iloc[:, 10].max() * 0.01, round_value
        )
        results["I_min"] = round(df.iloc[:, 10].min(), round_value)

        return results

    def _cleanup(self, pbar: Optional[tqdm] = None):
        """Очистка ресурсов"""
        if pbar:
            pbar.set_description(self._get_translation("Готово!"))
            pbar.close()

        gc.collect()

        if torch.cuda.is_available():
            # Синхронизация перед очисткой
            torch.cuda.synchronize()
            # Очистка кэша CUDA
            torch.cuda.empty_cache()
            # Сброс статистики памяти
            torch.cuda.reset_peak_memory_stats()

    def _img_to_numpy_array(
        self, file_path: str, max_size_kb: int = 500, quality: int = 85
    ) -> Optional[np.ndarray]:
        """
        Конвертирует изображение в numpy array с обработкой различных форматов и оптимизацией размера.

        Args:
            file_path: Путь к файлу изображения
            max_size_kb: Максимальный размер в KB (по умолчанию 500)
            quality: Качество JPEG сжатия (по умолчанию 85)

        Returns:
            np.ndarray или None в случае ошибки
        """
        try:
            with Image.open(file_path) as img:
                # Обработка специальных режимов изображений
                if img.mode in ["I", "I;16", "I;16B", "I;16L", "F"]:
                    img_array = np.array(img)

                    # Нормализация в 8-бит для специальных форматов
                    if img_array.dtype in [np.uint16, np.int16]:
                        img_array = (img_array / 256).astype(np.uint8)
                    elif img_array.dtype in [np.float32, np.float64]:
                        img_array = (img_array * 255).astype(np.uint8)
                    elif img_array.dtype in [np.int32, np.int64]:
                        img_array = (img_array / (img_array.max() / 255)).astype(
                            np.uint8
                        )

                    img = Image.fromarray(img_array)

                elif img.mode == "CMYK":
                    img = img.convert("RGB")

                elif img.mode in ("RGBA", "LA", "P"):
                    # Обработка прозрачности и палитровых изображений
                    background = Image.new("RGB", img.size, (255, 255, 255))

                    if img.mode == "P":
                        img = img.convert("RGBA")

                    if img.mode in ("RGBA", "LA"):
                        bands = img.split()
                        alpha = bands[-1]

                        # Черный фон для полностью прозрачных изображений
                        if np.array(alpha).max() == 0:
                            background = Image.new("RGB", img.size, (0, 0, 0))

                    background.paste(
                        img,
                        mask=img.split()[-1] if img.mode in ("RGBA", "LA") else None,
                    )
                    img = background

                elif img.mode != "RGB":
                    img = img.convert("RGB")

                # Проверка и коррекция белых изображений
                test_array = np.array(img)
                if np.all(test_array >= 250):
                    with Image.open(file_path) as img_alt:
                        alt_array = np.array(img_alt)
                        if alt_array.max() > 0 and alt_array.max() <= 255:
                            normalized = (alt_array / alt_array.max() * 255).astype(
                                np.uint8
                            )
                            img = Image.fromarray(normalized)

                # Оптимизация размера файла
                with io.BytesIO() as buffer:
                    img.save(buffer, format="JPEG", quality=quality)
                    current_size_kb = len(buffer.getvalue()) / 1024

                if current_size_kb > max_size_kb:
                    ratio = (max_size_kb / current_size_kb) ** 0.5
                    new_size = (
                        max(1, int(img.size[0] * ratio)),
                        max(1, int(img.size[1] * ratio)),
                    )
                    img = img.resize(new_size, Image.Resampling.LANCZOS)

                return np.array(img)

        except (IOError, OSError, ValueError, Exception):
            gr.Info(self._get_translation("Не поддерживаемый формат изображения."))
            return None

    def handle_file_upload(
        self, file, scale_selector, auto_scale_mode, request: gr.Request
    ):
        # Быстрая проверка на None файл
        if file is None:
            return (
                gr.skip(),
                gr.update(visible=True),
                gr.update(visible=False),
                gr.skip(),
                gr.skip(),
                gr.skip(),
                gr.skip(),
                gr.skip(),
                gr.skip(),
            )

        # Установка языка
        lang = self._determine_language(request.headers.get("Accept-Language", ""))
        LanguageContext.set_language(lang)
        self.lang = lang
        
        ImagePreprocessor.file_name = os.path.basename(file.name).rsplit('.', 1)[0]
        
        # Обработка изображения
        in_image = self._img_to_numpy_array(file.name)

        if auto_scale_mode:
            (
                crop_in_image,
                info_bar_image,
                scale_bar_image,
                scale_text_image,
                result,
                points_scale,
            ) = self.scale_processor.process_image(in_image, 0.1)

            scale_type = result[2]

            # Обработка значений с защитой от None
            scale_bar_width = self._safe_float_convert(result[0], default=1.0)
            scale_value = self._safe_float_convert(result[1], default=1.0)

            # Формирование статусного текста
            status_text = (
                self._get_translation("Выберите две крайние точки на шкале")
                if result[0] is None
                else f"{self._get_translation('Расстояние равно')}: {scale_bar_width:.0f} {self._get_translation('пикселей')}"
            )

            # Если шкала не в микрометрах или нанометрах - возвращаем пиксельный результат
            if scale_type not in ("µm", "nm"):
                gr.Info(
                    self._get_translation(
                        "Автоматическое определение масштабной шкалы не удалось. Укажите шкалу вручную или продолжите анализ в пикселях."
                    )
                )
                return self._get_pixel_result(in_image, status_text)

            # Формирование результата для µm/nm случаев
            type_scale = self._get_scale_type_display(scale_type)
            gr.Info(
                self._get_translation(
                    "Масштабная шкала обнаружена и распознана автоматически. Можно продолжить дальнейший анализ."
                )
            )
            return (
                in_image,
                gr.update(visible=False),
                gr.update(visible=True),
                gr.update(visible=True),  # scale_input_row
                scale_bar_width,  # scale
                points_scale,  # points_scale
                gr.update(value=status_text),  # scale_input_status
                gr.update(value=scale_value),  # scale_input
                gr.update(value=type_scale),  # scale_selector
            )
        return (
            in_image,
            gr.update(visible=False),
            gr.update(visible=True),
            gr.skip(),  # scale_input_row
            gr.skip(),  # scale
            gr.skip(),  # points_scale
            gr.skip(),
            gr.skip(),
            gr.skip(),
        )

    def _safe_float_convert(self, value, default=0.0):
        """Безопасно конвертирует значение в float"""
        if value is None:
            return default
        try:
            return float(value)
        except (ValueError, TypeError):
            return default

    def _get_scale_type_display(self, scale_type):
        """Возвращает отображаемое название типа шкалы"""
        type_scale_map = {"µm": "Micrometers (µm)", "nm": "Nanometers (nm)"}
        return type_scale_map.get(scale_type, "Pixels")

    def _get_pixel_result(self, in_image, status_text):
        """Возвращает результат для пиксельного случая"""
        return (
            in_image,
            gr.update(visible=False),
            gr.update(visible=True),
            gr.skip(),  # scale_input_row
            gr.skip(),  # scale
            gr.skip(),  # points_scale
            gr.update(value=status_text),  # scale_input_status
            gr.update(value=1.0),  # scale_input
            gr.update(value="Pixels"),  # scale_selector
        )

    def _create_binary_mask(
        self, annotations: List[Tuple[np.ndarray, str]], image_name: str
    ) -> np.ndarray:
        """
        Создает бинарное изображение из списка масок частиц.

        Args:
            annotations: Список кортежей (маска, имя_частицы)
            output_path: Путь для сохранения результата

        Returns:
            Бинарное изображение с объединенными масками
        """
        if not annotations:
            raise ValueError("Список аннотаций пуст")

        # Берем размер из первой маски
        first_mask, first_name = annotations[0]
        height, width = first_mask.shape

        # Создаем выходное изображение
        binary_mask_output = np.zeros((height, width), dtype=np.uint8)

        # Векторизованная обработка всех масок
        for mask, particle_name in annotations:
            # Используем in-place операцию для экономии памяти
            np.maximum(
                binary_mask_output,
                (mask > 0).astype(np.uint8) * 255,
                out=binary_mask_output,
            )

        # Сохраняем результат
        image_path = os.path.join(self.output_dir, f"binary_mask_{image_name}.png")
        cv2.imwrite(image_path, binary_mask_output)

        return binary_mask_output

    def _df_to_coco(self, df, image_np, image_name):
        """
        Преобразование DataFrame с точками контуров в COCO формат для одного изображения (numpy array)

        Args:
            df: DataFrame с колонкой 'points' (все аннотации для одного изображения)
            image_np: изображение в формате numpy array (H, W, C)
            image_name: имя файла для сохранения в COCO
        """

        # Получаем размеры из numpy array
        height, width = image_np.shape[:2]

        # Базовая структура COCO
        coco_format = {
            "images": [
                {
                    "id": 1,
                    "file_name": f"{image_name}.png",
                    "width": width,
                    "height": height,
                }
            ],
            "annotations": [],
            "categories": [{"id": 1, "name": "Particle", "supercategory": "none"}],
        }

        # Обрабатываем каждую аннотацию
        for annotation_id, (idx, row) in enumerate(df.iterrows(), 1):
            points = row["points"]
            segmentation = []

            # Обрабатываем разные форматы точек
            for point in points:
                if isinstance(point[0], list):  # [[[x, y]]]
                    x, y = point[0]
                else:  # [[x, y]]
                    x, y = point

                # Проверяем границы координат
                x = max(0, min(x, width - 1))
                y = max(0, min(y, height - 1))
                segmentation.extend([float(x), float(y)])

            # Вычисляем bounding box только если есть точки
            if len(segmentation) >= 4:  # минимум 2 точки
                x_coords = segmentation[::2]
                y_coords = segmentation[1::2]

                x_min, x_max = min(x_coords), max(x_coords)
                y_min, y_max = min(y_coords), max(y_coords)

                bbox_width = x_max - x_min
                bbox_height = y_max - y_min

                bbox = [x_min, y_min, bbox_width, bbox_height]
                area = bbox_width * bbox_height

                # Добавляем аннотацию
                coco_format["annotations"].append(
                    {
                        "id": annotation_id,
                        "image_id": 1,
                        "category_id": 1,
                        "segmentation": [segmentation],
                        "area": area,
                        "bbox": bbox,
                        "iscrowd": 0,
                    }
                )

        # Сохраняем в файл
        coco_path = os.path.join(self.output_dir, f"coco_file_{image_name}.json")
        with open(coco_path, "w") as f:
            json.dump(coco_format, f, indent=2)

        return coco_format

    def _sahi_polygon_to_binary_mask(
        self, sahi_polygon: list, height: int, width: int
    ) -> np.ndarray:
        """
        Преобразует полигон SAHI в бинарную маску
        """
        mask = np.zeros((height, width), dtype=np.uint8)

        if not sahi_polygon:
            return mask

        try:
            # Быстрое выравнивание через itertools (избегаем рекурсии)
            from collections.abc import Iterable

            def flatten_fast(lst):
                for item in lst:
                    if isinstance(item, Iterable) and not isinstance(
                        item, (str, bytes)
                    ):
                        yield from flatten_fast(item)
                    else:
                        yield item

            flat_coords = np.fromiter(flatten_fast(sahi_polygon), dtype=np.float32)

            # Проверяем четность координат
            if len(flat_coords) & 1:
                print(f"Warning: Odd number of coordinates: {len(flat_coords)}")
                return mask

            points = flat_coords.reshape(-1, 2).astype(np.int32)

            # Минимум 3 точки для полигона
            if len(points) < 3:
                return mask

            # Клиппинг векторизованный
            np.clip(points[:, 0], 0, width - 1, out=points[:, 0])
            np.clip(points[:, 1], 0, height - 1, out=points[:, 1])

            # Создаем маску
            cv2.fillPoly(mask, [points], color=1)

        except Exception as e:
            print(f"Error in _sahi_polygon_to_binary_mask: {e}")
            print(
                f"Input polygon structure: {type(sahi_polygon)}, length: {len(sahi_polygon) if hasattr(sahi_polygon, '__len__') else 'N/A'}"
            )

        return mask
