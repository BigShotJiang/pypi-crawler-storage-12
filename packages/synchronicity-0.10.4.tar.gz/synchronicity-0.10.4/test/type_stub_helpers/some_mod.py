import typing_extensions


class Foo:
    pass


cool: str

P = typing_extensions.ParamSpec("P")
