Notes about origin/copyright of files:

f[01]*.dat.xz: database files from XOP/DABAX project [1]

nist_atom.dat: included from NIST Physical Reference Database [2]

colors.dat: colors for atoms as found in Jmol [3]

atomic_radius.dat: atomic radii from Wikipedia [4]

[1] http://ftp.esrf.eu/pub/scisoft/xop2.3/
[2] http://www.nist.gov/pml/data/comp.cfm
[3] http://jmol.sourceforge.net/jscolors/
[4] https://en.wikipedia.org/wiki/Atomic_radii_of_the_elements_(data_page)
