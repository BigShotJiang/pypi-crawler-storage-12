Files:

*.cif .... structure files from the American Mineralogist database http://rruff.geo.arizona.edu/AMS/amcsd.php
rms_*.xrdml .. Panalytical data files for reciprocal space map measuremenst on Si(001) - curtesy of Tanja Etzelstorfer
polefig_Ge113.xrdml .. Panalytical data file for a pole figure measurement on Ge(113) - curtesy of Dominik Kriegner
test.spec  datafile generated at ESRF beamline ID10B using spec including reciprocal space maps of InP - curtesy of Dominik Kriegner
simpack_xrd_AlGaAs.xrdml .. Panalytical data file for a om-2th curve of AlGaAs/GaAs structure on GaAs (100) - curtesy of Aristide Lemaitre
