Installation Guide
==================

This page covers the installation process for BeastX.

Requirements
------------

* Python 3.7 or higher
* pip (Python package manager)

Basic Installation
------------------

Install BeastX from PyPI:

.. code-block:: bash

   pip install beastx-python

This will install the core library with minimal dependencies.

Installation with Extras
-------------------------

Cryptography Optimization
~~~~~~~~~~~~~~~~~~~~~~~~~

For faster encryption (recommended):

.. code-block:: bash

   pip install beastx-python[cryptg]

All Performance Features
~~~~~~~~~~~~~~~~~~~~~~~~

Install with all performance optimizations:

.. code-block:: bash

   pip install beastx-python[fast]

Development Installation
~~~~~~~~~~~~~~~~~~~~~~~~

For contributors and developers:

.. code-block:: bash

   git clone https://github.com/beastx-python
   cd beastx-python
   pip install -e .[dev]

Verifying Installation
----------------------

Test your installation:

.. code-block:: python

   import beastx
   print(beastx.__version__)

You should see the version number (1.0.3) and a welcome banner.

Getting API Credentials
------------------------

1. Visit https://my.telegram.org
2. Log in with your phone number
3. Go to **API Development Tools**
4. Create a new application
5. Copy your ``api_id`` and ``api_hash``

.. note::
   Keep your API credentials secure and never share them publicly.

Next Steps
----------

* :doc:`quickstart` - Learn the basics
* :doc:`examples` - See practical examples
* :doc:`api/client` - Explore the full API
