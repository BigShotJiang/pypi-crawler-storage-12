Quick Start Guide
=================

This guide will help you get started with BeastX quickly.

Prerequisites
-------------

Before you begin, make sure you have:

1. Installed BeastX: ``pip install beastx-python``
2. Obtained API credentials from https://my.telegram.org

Your First Bot
--------------

Create a file called ``my_bot.py``:

.. code-block:: python

   from beastx import TelegramClient, events

   # Your credentials
   api_id = 12345
   api_hash = 'your_api_hash_here'

   # Create client
   client = TelegramClient('my_session', api_id, api_hash)

   @client.on(events.NewMessage(pattern='/start'))
   async def start_handler(event):
       await event.respond('Welcome to BeastX!')

   # Start the bot
   client.start()
   client.run_until_disconnected()

Run it:

.. code-block:: bash

   python my_bot.py

Sending Messages
----------------

.. code-block:: python

   from beastx import TelegramClient

   client = TelegramClient('session', api_id, api_hash)

   async def main():
       await client.start()
       
       # Send to yourself
       await client.send_message('me', 'Hello!')
       
       # Send to a user
       await client.send_message('username', 'Hi there!')
       
       # Send with formatting
       await client.send_message('me', '**Bold** and __italic__')

   with client:
       client.loop.run_until_completed(main())

Event Handlers
--------------

.. code-block:: python

   from beastx import TelegramClient, events

   client = TelegramClient('session', api_id, api_hash)

   # Respond to any message containing "hello"
   @client.on(events.NewMessage(pattern='(?i)hello'))
   async def greet(event):
       await event.respond('Hello! 👋')

   # Handle commands
   @client.on(events.NewMessage(pattern='/help'))
   async def help_handler(event):
       await event.respond('Here is the help!')

   client.start()
   client.run_until_disconnected()

Downloading Media
-----------------

.. code-block:: python

   from beastx import TelegramClient

   client = TelegramClient('session', api_id, api_hash)

   async def download_photos():
       await client.start()
       
       # Download from a channel
       async for message in client.iter_messages('channel'):
           if message.photo:
               path = await message.download_media()
               print(f'Downloaded: {path}')

   with client:
       client.loop.run_until_completed(download_photos())

Next Steps
----------

* :doc:`examples` - More practical examples
* :doc:`api/client` - Full API reference
* :doc:`api/events` - Event types
