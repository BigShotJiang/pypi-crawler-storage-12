Welcome to BeastX Documentation!
=================================

**BeastX** is a powerful, feature-rich Python library for interacting with Telegram's MTProto API.

.. image:: https://img.shields.io/badge/pypi-v1.0.3-blue.svg
   :target: https://pypi.org/project/beastx-python/
   :alt: PyPI version

.. image:: https://img.shields.io/badge/python-3.7+-blue.svg
   :target: https://www.python.org/downloads/
   :alt: Python

.. image:: https://img.shields.io/badge/license-MIT-green.svg
   :alt: License

Credits
-------

* **Original Telethon**: Created by `Lonami <https://github.com/LonamiWebs>`_ - `Telethon Repository <https://github.com/LonamiWebs/Telethon>`_
* **BeastX Developer**: `t.me/GODMRUNAL <https://t.me/GODMRUNAL>`_
* **Official Channel**: `@BEASTX_BOTS <https://t.me/BEASTX_BOTS>`_
* **GitHub**: `github.com/beastx-python <https://github.com/beastx-python>`_

Installation
------------

Install from PyPI:

.. code-block:: bash

   pip install beastx-python

Install with performance enhancements:

.. code-block:: bash

   pip install beastx-python[fast]

Quick Start
-----------

.. code-block:: python

   from beastx import TelegramClient, events

   api_id = 12345
   api_hash = 'your_api_hash'

   client = TelegramClient('session_name', api_id, api_hash)

   @client.on(events.NewMessage(pattern='hello'))
   async def handler(event):
       await event.respond('Hello from BeastX!')

   client.start()
   client.run_until_disconnected()

Features
--------

* 📨 **Messaging**: Send, edit, delete messages with rich formatting
* 📁 **File Operations**: Upload and download files with progress tracking
* 🎯 **Events**: Real-time event handlers for messages, edits, and more
* 👥 **User Management**: Get users, participants, and manage permissions
* 🤖 **Bot Support**: Full bot API with inline buttons and keyboards
* 🔐 **Sessions**: Persistent authentication with session files
* ⚡ **Performance**: Async/await support for high performance

Table of Contents
-----------------

.. toctree::
   :maxdepth: 2
   :caption: Getting Started

   installation
   quickstart
   examples

.. toctree::
   :maxdepth: 2
   :caption: API Reference

   api/client
   api/events
   api/errors
   api/custom

.. toctree::
   :maxdepth: 2
   :caption: Advanced

   advanced/sessions
   advanced/files
   advanced/conversations

.. toctree::
   :maxdepth: 1
   :caption: Additional

   changelog
   credits

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
