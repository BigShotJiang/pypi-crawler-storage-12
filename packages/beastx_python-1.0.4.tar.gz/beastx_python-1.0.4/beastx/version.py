# BeastX - Python Telegram Client Library
# Version complies with PEP440
# Credits: Based on Telethon by Lonami (https://github.com/LonamiWebs/Telethon)
# Developer: t.me/GODMRUNAL
# Channel: @BEASTX_BOTS
# This line is parsed in setup.py:
__version__ = '1.0.4'
