"""
Telegram API Types

This module contains Telegram type definitions.
For a complete list of types, refer to the official Telegram API documentation.
"""

__all__ = []
