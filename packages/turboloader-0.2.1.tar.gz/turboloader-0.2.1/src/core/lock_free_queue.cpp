// Lock-free queue implementation is header-only (template)
// This file exists to satisfy CMake build system
#include "turboloader/core/lock_free_queue.hpp"

namespace turboloader {
// Explicit instantiations for common types can go here if needed
}
