# -*- coding: utf-8 -*-
"""
EQUseApi模块
"""