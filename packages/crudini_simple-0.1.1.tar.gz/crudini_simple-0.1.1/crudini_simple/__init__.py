#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright: (c)  : @Time 2025/11/13 18  @Author  : hjl
# @Site    : 
# @File    : __init__.py.py
# @Project: crudini_sample
# @Software: PyCharm
# @Desc    :
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from .core import Curdini