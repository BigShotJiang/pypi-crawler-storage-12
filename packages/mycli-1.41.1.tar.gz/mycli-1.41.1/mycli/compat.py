"""Platform and Python version compatibility support."""

import sys

WIN: bool = sys.platform in ("win32", "cygwin")
