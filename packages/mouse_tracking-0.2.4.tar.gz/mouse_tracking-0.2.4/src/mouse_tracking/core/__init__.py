"""Core Module for Mouse Tracking."""
