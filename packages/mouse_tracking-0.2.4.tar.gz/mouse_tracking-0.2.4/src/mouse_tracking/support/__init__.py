"""Support code module for mouse-tracking-runtime."""
