"""CLI Module for Mouse Tracking Runtime."""
