"""Tests for the writes utils module."""
