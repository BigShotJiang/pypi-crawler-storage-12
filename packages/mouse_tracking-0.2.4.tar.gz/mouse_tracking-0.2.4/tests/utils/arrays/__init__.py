"""Tests for the arrays utils module."""
