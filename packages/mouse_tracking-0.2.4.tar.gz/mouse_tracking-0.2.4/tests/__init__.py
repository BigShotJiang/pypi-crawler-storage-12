"""Tests for the mouse_tracking package."""
