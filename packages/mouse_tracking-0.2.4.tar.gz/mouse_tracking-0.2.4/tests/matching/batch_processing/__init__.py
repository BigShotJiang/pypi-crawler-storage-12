"""Tests for batch processing matching."""
