"""Tests for mouse_tracking CLI module."""
