"""Tests for the qa CLI module."""
