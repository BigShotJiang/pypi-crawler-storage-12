"""
Subsystem for submitting work to schedulers for enactment.
"""
