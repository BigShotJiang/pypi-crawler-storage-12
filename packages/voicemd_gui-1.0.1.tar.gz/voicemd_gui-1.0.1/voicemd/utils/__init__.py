"""VoiceMD utilities"""

