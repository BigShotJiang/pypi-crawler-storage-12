# AMD P-State issue triage tool
`amd-pstate` is a tool used for identification of issues with amd-pstate.
It will capture some state from the system as well as from the machine specific registers that
amd-pstate uses.
