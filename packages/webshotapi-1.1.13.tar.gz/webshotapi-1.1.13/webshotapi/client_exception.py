class WebshotapiClientError(Exception):
    pass