# Kurt Profile

**Created:** {{CREATED_DATE}}
**Last Updated:** {{UPDATED_DATE}}

---

## Company Context

**Company:** {{COMPANY_NAME}}
**Primary Website:** {{COMPANY_WEBSITE}}
**Documentation:** {{DOCS_URL}}
**Blog:** {{BLOG_URL}}

## User Context
**Function:** {{FUNCTION_NAME}}
**Role:** {{FUNCTION_ROLE}}

---

## Communication Goals

What we're trying to achieve with content:
{{GOALS_LIST}}
