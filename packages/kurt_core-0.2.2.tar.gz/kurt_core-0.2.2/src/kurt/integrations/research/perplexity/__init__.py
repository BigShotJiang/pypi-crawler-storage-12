"""Perplexity research adapter for Kurt."""

from kurt.integrations.research.perplexity.adapter import PerplexityAdapter

__all__ = ["PerplexityAdapter"]
