"""Analytics adapter implementations."""

from kurt.integrations.analytics.adapters.base import AnalyticsAdapter

__all__ = ["AnalyticsAdapter"]
