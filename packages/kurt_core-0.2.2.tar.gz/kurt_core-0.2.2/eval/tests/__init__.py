"""Tests for the evaluation framework itself."""
