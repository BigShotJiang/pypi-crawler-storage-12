"""Kurt Evaluation Framework - Automated testing for Kurt agent behavior."""

__version__ = "0.1.0"
