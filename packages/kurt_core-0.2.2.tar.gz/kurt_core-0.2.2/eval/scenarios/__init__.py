"""Evaluation scenarios for Kurt agent behavior."""
