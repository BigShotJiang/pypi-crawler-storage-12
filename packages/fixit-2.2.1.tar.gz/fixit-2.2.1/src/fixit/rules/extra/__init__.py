# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

"""
These are highly opinionated rules, and are not enabled by default.
They can be enabled in your project's :attr:`enable` configuration option.
"""
