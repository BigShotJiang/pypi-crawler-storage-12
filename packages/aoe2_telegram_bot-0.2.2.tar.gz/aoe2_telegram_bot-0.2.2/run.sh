#!/bin/bash
python3 -m pip install . && python3 -m aoe2_bot.bot