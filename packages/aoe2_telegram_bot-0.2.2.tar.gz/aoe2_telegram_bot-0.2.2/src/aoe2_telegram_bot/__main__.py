from aoe2_telegram_bot._bot import main

main()
