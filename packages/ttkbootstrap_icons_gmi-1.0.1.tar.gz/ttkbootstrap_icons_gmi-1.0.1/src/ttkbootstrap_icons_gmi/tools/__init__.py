"""Tools for building Google Material Icons assets."""

