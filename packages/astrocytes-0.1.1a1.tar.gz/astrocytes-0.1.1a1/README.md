# open-astrocytes
Open data and models for astrocyte dynamics
