"""Tests for OpenAstrocyte datasets"""

##
# Imports

import pytest


##
# Test units

def test_placeholder():
    """TODO A placeholder test to get the CI workflow up"""
    assert True == True