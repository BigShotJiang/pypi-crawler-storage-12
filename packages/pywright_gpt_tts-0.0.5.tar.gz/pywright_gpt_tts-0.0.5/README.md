# Pywright GPT TTS
Python Module for Free ChatGPT TTS.  
ChatGPT Automation for Text-To-Speech programmatically.  

*Easy to use - No need for extra documentation !*  
*Learn as you go ! Try it out !*  