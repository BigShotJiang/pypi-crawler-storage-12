def greet():
    print("Hello, How is your day?")
