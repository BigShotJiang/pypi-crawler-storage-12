import os

SETTINGS_PATH = f"{os.path.expanduser('~')}/.ai-setup/settings.json"