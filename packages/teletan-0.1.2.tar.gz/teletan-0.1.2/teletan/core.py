import requests
from bs4 import BeautifulSoup
import json
import re

def getinfo(ccc: str) -> str:
    if not isinstance(ccc, str) or not ccc.strip():
        return "خطأ: اسم المستخدم يجب أن يكون نصًا غير فارغ."

    try:
        url_official = f"https://t.me/{ccc}"
        res = requests.get(url_official, timeout=10, headers={"User-Agent": "Mozilla/5.0"})
        if res.status_code == 200:
            soup = BeautifulSoup(res.text, "html.parser")
            full_name_tag = soup.find("h2", class_="tgme_page_title")
            full_name = full_name_tag.get_text(strip=True) if full_name_tag else "غير متوفر"
            parts = full_name.split()
            ff = parts[0] if len(parts) > 0 else "غير متوفر"
            dd = parts[-1] if len(parts) > 1 else "غير متوفر"
        else:
            first_name = last_name = "غير متوفر"
    except requests.exceptions.RequestException:
        first_name = last_name = "غير متوفر"

    try:
        url_unofficial = f'https://api.x7m.site/v1/telid.php?user={ccc}'
        res2 = requests.get(url_unofficial, timeout=10)
        res2.raise_for_status()
        text_content = res2.text.strip()
        json_match = re.search(r'\{.*\}', text_content, re.DOTALL)
        if json_match:
            try:
                data = json.loads(json_match.group())
            except json.JSONDecodeError:
                data = {}
        else:
            data = {}
    except requests.exceptions.RequestException:
        data = {}

    un = data.get("Username", ccc)
    ui = data.get("ID", "غير متوفر")
    ib = data.get("Is Bot", "غير متوفر")
    iv = data.get("Is Verified", "غير متوفر")

    return f"""
الاسم الاول : {ff}
الاسم الاخير : {dd}
اسم المستخدم : {un}
ايدي الحساب : {ui}
هل هو بوت : {ib}
الحساب موثق : {iv}
""".strip()