import logging
logger = logging.getLogger('rivapy.models')