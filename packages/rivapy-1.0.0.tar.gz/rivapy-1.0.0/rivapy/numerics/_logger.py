import logging
logger = logging.getLogger('rivapy.numerics')