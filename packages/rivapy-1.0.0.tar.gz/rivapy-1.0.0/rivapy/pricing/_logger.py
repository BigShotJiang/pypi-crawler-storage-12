import logging
logger = logging.getLogger('rivapy.pricing')