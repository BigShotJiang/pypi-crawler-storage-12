import logging
logger = logging.getLogger('rivapy.market_data')