"""
@Author = 'Michael Stanley'

============ Change Log ============
11/11/2025 = Created.

============ License ============
Copyright (C) 2025 Michael Stanley

MIT License
"""
from red_aluminum import read_file_data

from pathlib import Path
