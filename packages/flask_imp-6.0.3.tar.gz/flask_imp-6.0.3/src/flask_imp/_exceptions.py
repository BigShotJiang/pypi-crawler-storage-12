class NoConfigProvided(Exception):
    """
    Raised when no config is provided.
    """

    pass
