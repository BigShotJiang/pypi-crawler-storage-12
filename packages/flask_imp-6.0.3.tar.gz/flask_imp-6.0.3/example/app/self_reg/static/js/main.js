console.log('This log is from the file /Users/david/PycharmProjects/CheeseCake87-Repos/flask-imp/example/app/self_reg/static/main.js')
