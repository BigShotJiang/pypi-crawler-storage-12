console.log('This log is from the file /Users/david/PycharmProjects/flask-imp/app/blueprints/www/static/main.js')
