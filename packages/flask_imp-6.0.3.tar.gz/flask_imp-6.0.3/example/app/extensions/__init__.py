from flask_imp import Imp
from flask_sqlalchemy import SQLAlchemy

imp = Imp()
db = SQLAlchemy()
