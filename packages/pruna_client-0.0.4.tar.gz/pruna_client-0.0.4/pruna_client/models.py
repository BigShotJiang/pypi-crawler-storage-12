"""Data models for Pruna API responses."""
from dataclasses import dataclass
from typing import Optional

from PIL import Image


@dataclass
class PrunaResponse:
    """Response from Pruna API."""
    status: str
    generation_url: Optional[str] = None
    image: Optional[Image.Image] = None
    message: Optional[str] = None
    error: Optional[str] = None
    prediction_id: Optional[str] = None
    get_url: Optional[str] = None

