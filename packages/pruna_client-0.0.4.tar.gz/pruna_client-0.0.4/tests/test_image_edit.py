"""Integration tests for image editing."""
import base64
from io import BytesIO

import pytest
from PIL import Image

from pruna_client import PrunaResponse


class TestImageEditingFlow:
    """Integration tests for image editing flow."""
    
    def test_complete_image_edit_flow_with_file_path(self, client, temp_image_file):
        """Test complete image editing flow: upload -> edit -> download."""
        response = client.generate_image_edit(
            model="p-image-edit",
            prompt="Make the image blue and add a sunset sky",
            images=[temp_image_file],
            sync=True
        )
        
        # Verify result - handle both success and error cases
        assert response is not None
        if isinstance(response.image, Image.Image):
            assert response.image.size[0] > 0
            assert response.image.size[1] > 0
        elif isinstance(response, PrunaResponse):
            # API may return error if upload fails (e.g., 401 Unauthorized)
            assert response.status in ["succeeded"]
    
    def test_image_edit_flow_with_pil_image(self, client, sample_image):
        """Test image editing flow using PIL Image object."""
        response = client.generate_image_edit(
            model="p-image-edit",
            prompt="Transform the image into a watercolor painting style",
            images=[sample_image],
            sync=True
        )
        
        assert response is not None
        if isinstance(response.image, Image.Image):
            assert isinstance(response.image, Image.Image)
        elif isinstance(response, PrunaResponse):
            pytest.skip(f"Image upload failed: {response.error}")
    
    def test_image_edit_flow_with_data_uri(self, client, sample_image):
        """Test image editing flow using data URI."""
        # Convert image to data URI
        buffer = BytesIO()
        sample_image.save(buffer, format="PNG")
        buffer.seek(0)
        image_data = base64.b64encode(buffer.read()).decode()
        data_uri = f"data:image/png;base64,{image_data}"
        
        response = client.generate_image_edit(
            model="p-image-edit",
            prompt="Add a beautiful landscape background",
            images=[data_uri],
            sync=True
        )
        
        assert response is not None
        if isinstance(response.image, Image.Image):
            assert isinstance(response.image, Image.Image)
        elif isinstance(response, PrunaResponse):
            pytest.skip(f"Image upload failed: {response.error}")
    
    def test_image_edit_flow_with_multiple_images(self, client, sample_image):
        """Test image editing flow with multiple images."""
        # Create second image
        image2 = Image.new("RGB", (200, 200), color="blue")
        
        response = client.generate_image_edit(
            model="p-image-edit",
            prompt="Blend and merge these images into a cohesive composition",
            images=[sample_image, image2],
            sync=True
        )
        
        assert response is not None
        if isinstance(response.image, Image.Image):
            assert isinstance(response.image, Image.Image)
        elif isinstance(response, PrunaResponse):
            pytest.skip(f"Image upload failed: {response.error}")


class TestEndToEndImageEditWorkflows:
    """Integration tests for complete end-to-end image editing workflows."""
    
    def test_workflow_generate_then_edit(self, client, sample_image):
        """Test workflow: generate image -> edit it."""
        # Step 1: Generate an image
        response = client.generate_text_to_image(
            model="p-image",
            prompt="A simple red circle on white background",
            sync=True
        )
        
        if not isinstance(response.image, Image.Image):
            pytest.skip("Image generation failed, cannot test edit workflow")
        
        # Step 2: Edit the generated image
        response = client.generate_image_edit(
            model="p-image-edit",
            prompt="Add a blue border around the image",
            images=[response.image],
            sync=True
        )
        
        assert response is not None
        if isinstance(response.image, Image.Image):
            assert isinstance(response.image, Image.Image)
        elif isinstance(response, PrunaResponse):
            raise ValueError(f"Image edit failed: {response.error}")    

