# Pruna Client

Official Pruna API client for synchronous and asynchronous image generation and editing.

## Installation

```bash
uv add pruna-client
```

Or install from source:

```bash
cd pruna_client
uv pip install -e .
```

## Quick Start

```python
from pruna_client import PrunaClient

# Initialize client
client = PrunaClient(api_key="your_api_key")
# Or set PRUNA_API_KEY environment variable

# Generate image synchronously
response = client.generate_text_to_image(
    model="p-image",
    prompt="A beautiful sunset over a calm ocean",
    sync=True
)

if isinstance(response.image, Image.Image):
    response.image.save("output.png")
```

## Features

- **Synchronous Image Generation**: Generate images and wait for completion
- **Asynchronous Image Generation**: Start generation and poll for status
- **Image Editing**: Edit images using prompts
- **File Upload**: Upload images from file paths, PIL Images, or data URIs
- **Status Polling**: Poll async operations until completion

## Usage Examples

### Synchronous Generation

```python
from pruna_client import PrunaClient
from PIL import Image

client = PrunaClient()
response = client.generate_text_to_image(
    model="p-image",
    prompt="A serene mountain landscape",
    sync=True
)

if isinstance(response.image, Image.Image):
    response.image.save("output.png")
```

### Asynchronous Generation

```python
from pruna_client import PrunaClient

client = PrunaClient()

# Start async generation
response = client.generate_text_to_image(
    model="p-image",
    prompt="An abstract painting",
    sync=False
)

# Poll for completion
final_response = client.poll_status(
    response=response,
    poll_interval=2.0,
    max_wait=120
)

if final_response.status == "succeeded":
    image = client._download_image(final_response.generation_url)
    if isinstance(image, Image.Image):
        image.save("output.png")
```

### Image Editing

```python
from pruna_client import PrunaClient
from PIL import Image

client = PrunaClient()

# Edit an image
response = client.generate_image_edit(
    model="p-image-edit",
    prompt="Make the image blue",
    images=["path/to/image.png" | Image.Image | data URI],
    sync=True
)

if isinstance(response.image, Image.Image):
    response.image.save("output.png")
```

## Running Tests

```bash
cd pruna_client
uv run pytest tests/ -v
```

Tests require `PRUNA_API_KEY` environment variable to be set.
