"""A command line tool to create a graph representing your Ansible playbook tasks and roles.

While you can use this package into another project, it is not primarily designed for that (yet).
"""

__version__ = "2.10.1"
__prog__ = "ansible-playbook-grapher"
