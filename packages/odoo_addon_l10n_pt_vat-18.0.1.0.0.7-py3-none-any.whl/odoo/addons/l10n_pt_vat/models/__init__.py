from . import l10n_pt_vat_exempt_reason
from . import account_journal
from . import account_move
from . import account_tax
from . import vat_adjustment_norm
