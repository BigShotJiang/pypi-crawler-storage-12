On Accounting Taxes, the "Fiscal Zone" can be set, to identify the VAT zone:
Continental Portugal, Madeira or Azores.

The default VAT Exemption reason can be set on the Sales Journal:

- Go to *Accounting/Invoicing > Configuration > Accounting / Journals*
