- Pedro Castro Silva ([Sossia](http://www.sossia.pt))

- [Open Source Integrators](https://www.opensourceintegrators.com)

  > - Daniel Reis (<dreis@opensourceintegrators.com>)
