This modules extends the base localization modules with a few VAT
specific functions that are required by the Portuguese Tax Authorities,
including:

- The use of pre-defined legally accepted reasons for issuing credit
  notes, as required for fields 40/41 of the VAT statement (Portaria nº
  255/2013).

NOTE: scheduled to replaced by the future core module `l10n_pt_certification`.
