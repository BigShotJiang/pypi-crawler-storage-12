On an Invoice, the VAT adjustment reason is available for selection.
