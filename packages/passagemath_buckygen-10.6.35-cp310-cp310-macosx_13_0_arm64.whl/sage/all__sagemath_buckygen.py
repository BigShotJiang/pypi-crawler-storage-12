# sage_setup: distribution = sagemath-buckygen
# delvewheel: patch

from sage.all__sagemath_graphs import *
