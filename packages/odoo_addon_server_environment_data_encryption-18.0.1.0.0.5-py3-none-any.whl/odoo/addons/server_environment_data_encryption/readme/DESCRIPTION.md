This module changes a little the behavior of server_environment modules.
When Odoo does not find the value of the field in the configuration
file, it will fallback on a Odoo encrypted field instead. Also it allows
you to configure the environment dependent fields for all your
environments from the production server.
