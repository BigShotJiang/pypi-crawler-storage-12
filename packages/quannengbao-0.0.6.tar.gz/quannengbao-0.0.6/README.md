# quannengbao
### 需要显示安装全能包指定路径
pip install quannengbao[byted] --extra-index-url https://bytedpypi.byted.org/simpl
### quannengbao安装完成后另外安装bytedtqs
pip install bytedtqs==0.0.50 --index-url=https://bytedpypi.byted.org/simple/