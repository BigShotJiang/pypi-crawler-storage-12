"""Módulo que contiene la CloudFunction que se usará para escuchar los mensajes de Pub/Sub
y disparar el entrenamiento de un modelo."""

# Librerías Externas.
import json
import base64
import logging


logging.basicConfig(level = logging.INFO,
                    format = "%(asctime)s - %(levelname)s - %(message)s")


def main(event, context) -> None:
    """Función principal que se ejecuta cuando se recibe un mensaje de Pub/Sub.
    
    Args:
    ----------
    event: dict
        Evento recibido de Pub/Sub.

    context: dict
        Contexto de la función."""
    
    logging.info(f"Evento recibido: {event}")
    logging.info(f"Contexto de la función: {context}")

    message = base64.b64decode(event["data"]).decode("utf-8")

    logging.info(f"Mensaje recibido: {message}")

    payload = json.loads(message)

    logging.info(f"Payload recibido: {payload}")
    
    logging.info("Procesando el mensaje...")
    