"""Módulo que define el componente principal para la validación de modelos."""

# Librerías Externas.
import logging
import argparse

from sklearn.metrics import roc_auc_score

# Librerías Internas.
from migracion_gcp.lib.clients.factory.abstract_factory import CloudFactory

from migracion_gcp.lib.validations.director import Director
from migracion_gcp.lib.validations.concrete_builders.classification_builder import ValidateClassificationBuilder


def main(args: argparse.Namespace) -> None:
    """Método principal para la validación de modelos."""

    MODEL_TEAM = args.team
    MODEL_SITE = args.site
    MODEL_TAG = args.tag_modelo
    MODEL_VERSION = args.version
        
    BLOB_PATH_PREFIX = f"{MODEL_TEAM}/{MODEL_TAG}/{MODEL_SITE}/{MODEL_VERSION}"

    logging.info(f"🏁 Iniciando proceso de validación del modelo ...")

    storage_client = CloudFactory.create_storage_service(cloud_provider = args.cloud_provider,
                                                          project_id = args.project_id)
    
    logging.info("✅ Cliente de almacenamiento creado correctamente.\n")

    logging.info("⏰ Descargando el modelo productivo y datos para validación...")

    modelo = storage_client.download_pickle(bucket_name = args.bucket_name,
                                            file_path = f"{BLOB_PATH_PREFIX}/productive_model.pkl")
    
    train_df = storage_client.download_csv(bucket_name = args.bucket_name,
                                           file_path = f"{BLOB_PATH_PREFIX}/train.csv")
    
    oot_df = storage_client.download_csv(bucket_name = args.bucket_name,
                                         file_path = f"{BLOB_PATH_PREFIX}/oot.csv")
    
    X_train = train_df.drop(columns = [args.target_column])
    y_train = train_df[args.target_column]

    X_oot = oot_df.drop(columns = [args.target_column])
    y_oot = oot_df[args.target_column]

    logging.info("✅ Datos y modelo descargados correctamente.\n")

    logging.info("⏰ Comenzando la validación del modelo...")

    builder = ValidateClassificationBuilder()
    director = Director(builder)

    director.add_score_validation()
    #director.add_metric_validation()
    director.add_csi_validation()

    validator = director.get_validator()

    validator.execute_validations(modelo = modelo,
                                  metric_fn = roc_auc_score,
                                  X_train = X_train, X_test = X_oot, y_train = y_train, y_test = y_oot)

    logging.info("✅ Validación del modelo completada correctamente.\n")

    logging.info("🏁 Iniciando proceso de entrenamiento del modelo...")


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description = "Proceso de validación del modelo.")

    parser.add_argument("--cloud_provider",
                        type = str,
                        required = True,
                        default = "gcs",
                        help = "Proveedor de nube.")
    
    parser.add_argument("--project_id",
                        type = str,
                        required = True,
                        default = "mlops-credits-vertex-poc",
                        help = "ID del proyecto de Google Cloud.")
    
    parser.add_argument("--bucket_name",
                        type = str,
                        required = True,
                        default = "migracion-gcp-bucket",
                        help = "Nombre del bucket de Google Cloud Storage.")
    
    parser.add_argument("--team",
                        type = str,
                        required = True,
                        default = "consumers",
                        help = "Equipo del modelo.")
    
    parser.add_argument("--tag_modelo",
                        type = str,
                        required = True,
                        default = "consumers_iris",
                        help = "Tag del modelo.")
    
    parser.add_argument("--site",
                        type = str,
                        required = True,
                        default = "MLB",
                        help = "Site del modelo.")
    
    parser.add_argument("--version",
                        type = int,
                        required = True,
                        default = 1,
                        help = "Versión de los datos.")
    
    parser.add_argument("--target_column",
                        type = str,
                        required = True,
                        default = "target",
                        help = "Columna objetivo.")
    
    args = parser.parse_args()

    main(args)
