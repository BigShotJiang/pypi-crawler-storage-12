"""Módulo que contiene el pipeline de entrenamiento de modelos en Vertex AI."""

# Librerías Externas.
from typing import Optional

from kfp import dsl, compiler
from google.cloud import aiplatform


@dsl.component(
    base_image = "us-east1-docker.pkg.dev/mlops-credits-vertex-poc/mlops-pruebas/imagen-split-data:latest",
    command = ["python", "src/migracion_gcp/process/vertex_components/split_data/main.py"],
    args = [
        "--cloud_provider", dsl.InputArgumentPlaceholder("cloud_provider"),
        "--project_id", dsl.InputArgumentPlaceholder("project_id"),
        "--dataset_name", dsl.InputArgumentPlaceholder("dataset_name"),
        "--table_name", dsl.InputArgumentPlaceholder("table_name"),
        "--bucket_name", dsl.InputArgumentPlaceholder("bucket_name"),
        "--team", dsl.InputArgumentPlaceholder("team"),
        "--tag_modelo", dsl.InputArgumentPlaceholder("tag_modelo"),
        "--site", dsl.InputArgumentPlaceholder("site"),
        "--version", dsl.InputArgumentPlaceholder("version"),
        "--test_size", dsl.InputArgumentPlaceholder("test_size"),
        "--oot_size", dsl.InputArgumentPlaceholder("oot_size"),
        "--random_seed", dsl.InputArgumentPlaceholder("random_seed"),
    ],
)
def split_data_component(
    cloud_provider: str = "gcs",
    project_id: str = "mlops-credits-vertex-poc",
    dataset_name: str = "pruebas_migracion_juan_pablo",
    table_name: str = "base_iris",
    bucket_name: str = "migracion-gcp-bucket",
    team: str = "consumers",
    tag_modelo: str = "consumers_iris",
    site: str = "MLB",
    version: int = 1,
    test_size: float = 0.3,
    oot_size: float = 0.2,
    random_seed: int = 42,
):
    """Función que define un componente del pipeline de KubeFlow."""

    pass


@dsl.component(base_image = "us-east1-docker.pkg.dev/mlops-credits-vertex-poc/mlops-pruebas/imagen-train-model:latest")
def train_model_component(cloud_provider: Optional[str] = "gcs",
                          project_id: Optional[str] = "mlops-credits-vertex-poc",
                          bucket_name: Optional[str] = "migracion-gcp-bucket",
                          team: Optional[str] = "consumers",
                          tag_modelo: Optional[str] = "consumers_iris",
                          site: Optional[str] = "MLB",
                          version: Optional[int] = 1,
                          random_seed: Optional[int] = 42,
                          target_column: Optional[str] = "target") -> None:
    """Función que define un componente del pipeline de KubeFlow."""

    import logging
    import subprocess


    logging.basicConfig(level = logging.INFO,
                        format = "%(asctime)s - %(levelname)s - %(message)s")

    logging.info("Iniciando el proceso de entrenamiento de modelo...")

    cmd = ["python", "src/migracion_gcp/process/vertex_components/train_model/main.py",
           "--cloud_provider", cloud_provider,
           "--project_id", project_id,
           "--bucket_name", bucket_name,
           "--team", team,
           "--tag_modelo", tag_modelo,
           "--site", site,
           "--version", str(version),
           "--random_seed", str(random_seed),
           "--target_column", target_column]
    
    subprocess.run(cmd, check = True)
    logging.info("Train model completado correctamente.")


@dsl.component(base_image = "us-east1-docker.pkg.dev/mlops-credits-vertex-poc/mlops-pruebas/imagen-validate-model:latest")
def validate_model_component(cloud_provider: Optional[str] = "gcs",
                             project_id: Optional[str] = "mlops-credits-vertex-poc",
                             bucket_name: Optional[str] = "migracion-gcp-bucket",
                             team: Optional[str] = "consumers",
                             tag_modelo: Optional[str] = "consumers_iris",
                             site: Optional[str] = "MLB",
                             version: Optional[int] = 1,
                             target_column: Optional[str] = "target") -> None:
    """Función que define un componente del pipeline de KubeFlow."""

    import logging
    import subprocess


    logging.basicConfig(level = logging.INFO,
                        format = "%(asctime)s - %(levelname)s - %(message)s")
    
    logging.info("Iniciando el proceso de validación de modelo...")

    cmd = ["python", "src/migracion_gcp/process/vertex_components/validate_model/main.py",
           "--cloud_provider", cloud_provider,
           "--project_id", project_id,
           "--bucket_name", bucket_name,
           "--team", team,
           "--tag_modelo", tag_modelo,
           "--site", site,
           "--version", str(version),
           "--target_column", target_column]
    
    subprocess.run(cmd, check = True)
    logging.info("Validate model completado correctamente.")


@dsl.pipeline(name = "pipeline-entrenamiento-modelo",
              description = "Pipeline de entrenamiento de modelo. (Split data -> Train model -> Validate model)")
def train_model_pipeline(cloud_provider: Optional[str] = "gcs",
                         project_id: Optional[str] = "mlops-credits-vertex-poc",
                         dataset_name: Optional[str] = "pruebas_migracion_juan_pablo",
                         table_name: Optional[str] = "base_iris",
                         bucket_name: Optional[str] = "migracion-gcp-bucket",
                         team: Optional[str] = "consumers",
                         tag_modelo: Optional[str] = "consumers_iris",
                         site: Optional[str] = "MLB",
                         version: Optional[int] = 1,
                         test_size: Optional[float] = 0.3,
                         oot_size: Optional[float] = 0.2,
                         random_seed: Optional[int] = 42,
                         target_column: Optional[str] = "target") -> None:
    """Función que define el pipeline de entrenamiento de modelo."""

    split_data_task = split_data_component(cloud_provider = cloud_provider,
                                           project_id = project_id,
                                           dataset_name = dataset_name,
                                           table_name = table_name,
                                           bucket_name = bucket_name,
                                           team = team,
                                           tag_modelo = tag_modelo,
                                           site = site,
                                           version = version,
                                           test_size = test_size,
                                           oot_size = oot_size,
                                           random_seed = random_seed)
    
    split_data_task.set_display_name("Split data")
    
    train_model_task = train_model_component(cloud_provider = cloud_provider,
                                             project_id = project_id,
                                             bucket_name = bucket_name,
                                             team = team,
                                             tag_modelo = tag_modelo,
                                             site = site,
                                             version = version,
                                             random_seed = random_seed,
                                             target_column = target_column).after(split_data_task)
    
    train_model_task.set_display_name("Train model")
    
    validate_model_task = validate_model_component(cloud_provider = cloud_provider,
                                                    project_id = project_id,
                                                    bucket_name = bucket_name,
                                                    team = team,
                                                    tag_modelo = tag_modelo,
                                                    site = site,
                                                    version = version,
                                                    target_column = target_column).after(train_model_task)
    
    validate_model_task.set_display_name("Validate model")
    

def run_pipeline() -> None:
    """Función que ejecuta el pipeline de entrenamiento de modelo."""
    
    job = aiplatform.PipelineJob(display_name = "pipeline-entrenamiento-modelo-juan-pablo",
                                 template_path = "src/migracion_gcp/process/vertex_components/vertex_pipeline.json",
                                 pipeline_root = "gs://migracion-gcp-bucket/pipeline-entrenamiento-modelo-juan-pablo/",
                                 parameter_values = {"cloud_provider": "gcs",
                                                     "project_id": "mlops-credits-vertex-poc",
                                                     "bucket_name": "migracion-gcp-bucket",
                                                     "team": "consumers",
                                                     "tag_modelo": "consumers_iris",
                                                     "site": "MLB",
                                                     "version": 1,
                                                     "random_seed": 42,
                                                     "target_column": "target"})
    
    job.run()


if __name__ == "__main__":

    aiplatform.init(project = "mlops-credits-vertex-poc",
                    location = "us-east1")
    
    compiler.Compiler().compile(pipeline_func = train_model_pipeline,
                                package_path = "src/migracion_gcp/process/vertex_components/vertex_pipeline.json")

    run_pipeline()
