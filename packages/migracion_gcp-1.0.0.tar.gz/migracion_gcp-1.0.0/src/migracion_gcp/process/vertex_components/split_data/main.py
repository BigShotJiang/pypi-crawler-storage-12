"""Módulo que contiene el proceso de separación de unos datos genéricos."""

# Librerías Externas.
import logging
import argparse

from sklearn.model_selection import train_test_split

# Librerías Internas.
from migracion_gcp.lib.io.registry import LocalFileRegistry
from migracion_gcp.lib.clients.factory.abstract_factory import CloudFactory


logging.basicConfig(level = logging.INFO,
                    format = "%(asctime)s - %(levelname)s - %(message)s")


def main(args: argparse.Namespace) -> None:
    """Función de encapsulamiento de la task de partición de datos.
    
    Args:
    ----------
    args: argparse.Namespace.
        Argumentos de la línea de comandos."""
    
    MODEL_TEAM = args.team
    MODEL_SITE = args.site
    MODEL_TAG = args.tag_modelo
    MODEL_VERSION = args.version
    
    RANDOM_SEED = args.random_seed
    
    TABLE_NAME_PREFIX = f"{MODEL_TEAM}_{MODEL_TAG}_{MODEL_SITE}_{MODEL_VERSION}"
    BLOB_PATH_PREFIX = f"{MODEL_TEAM}/{MODEL_TAG}/{MODEL_SITE}/{MODEL_VERSION}"
    
    logging.info("🏁 Iniciando el proceso de partición de datos...")

    database_client = CloudFactory.create_database_service(cloud_provider = args.cloud_provider,
                                                           project_id = args.project_id)

    logging.info("✅ Cliente de bases de datos creado correctamente.")

    storage_client = CloudFactory.create_storage_service(cloud_provider = args.cloud_provider,
                                                         project_id = args.project_id)

    logging.info("✅ Cliente de almacenamiento creado correctamente.")

    logging.info("⏰ Obteniendo los datos de la tabla...")

    dataframe = database_client.get_table(table_name = args.table_name,
                                          dataset_name = args.dataset_name)

    logging.info("✅ Datos obtenidos correctamente.")

    logging.info("⏰ Particionando los datos...")

    dataframe_train, dataframe_test = train_test_split(dataframe,
                                                       test_size = args.test_size,
                                                       random_state = RANDOM_SEED)
        
    dataframe_test, dataframe_oot = train_test_split(dataframe_test,
                                                            test_size = args.oot_size,
                                                            random_state = RANDOM_SEED)

    logging.info("✅ Datos particionados correctamente.\n")

    logging.info("⏰ Guardando los datos en la tablas y archivos versionados...")

    TABLES = [("train", dataframe_train),
              ("test", dataframe_test),
              ("oot", dataframe_oot)]
    
    file_registry = LocalFileRegistry.get_file_handler(file_type = "csv")
    with file_registry() as manager:

        for table_suffix, table_content in TABLES:
            database_client.create_table_from_dataframe(table_name = f"{TABLE_NAME_PREFIX}_{table_suffix}",
                                                        dataset_name = args.dataset_name,
                                                        dataframe = table_content)
            
            manager.write_file(file_path = f"{table_suffix}.csv",
                               content = table_content)

            storage_client.upload_file(bucket_name = args.bucket_name,
                                       file_path = f"{manager.temp_dir}/{table_suffix}.csv",
                                       destination_path = f"{BLOB_PATH_PREFIX}/{table_suffix}.csv")

    logging.info("✅ Datos guardados correctamente.")

    logging.info("🏁 Proceso de partición de datos finalizado correctamente.")


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description = "Proceso de partición de datos.")

    parser.add_argument("--cloud_provider",
                        type = str,
                        required = True,
                        default = "gcs",
                        help = "Proveedor de nube.")
    
    parser.add_argument("--project_id",
                        type = str,
                        required = True,
                        default = "mlops-credits-vertex-poc",
                        help = "ID del proyecto de Google Cloud.")
    
    parser.add_argument("--dataset_name",
                        type = str,
                        required = True,
                        default = "pruebas_migracion_juan_pablo",
                        help = "Nombre del dataset.")
    
    parser.add_argument("--table_name",
                        type = str,
                        required = True,
                        default = "base_iris",
                        help = "Nombre de la tabla.")
    
    parser.add_argument("--bucket_name",
                        type = str,
                        required = True,
                        default = "migracion-gcp-bucket",
                        help = "Nombre del bucket de Google Cloud Storage.")
    
    parser.add_argument("--team",
                        type = str,
                        required = True,
                        default = "consumers",
                        help = "Equipo del modelo.")
    
    parser.add_argument("--tag_modelo",
                        type = str,
                        required = True,
                        default = "consumers_iris",
                        help = "Tag del modelo.")
    
    parser.add_argument("--site",
                        type = str,
                        required = True,
                        default = "MLB",
                        help = "Site del modelo.")
    
    parser.add_argument("--version",
                        type = int,
                        required = True,
                        default = 1,
                        help = "Versión de los datos.")
    
    parser.add_argument("--test_size",
                        type = float,
                        required = True,
                        default = 0.3,
                        help = "Tamaño de la partición de prueba.")
    
    parser.add_argument("--oot_size",
                        type = float,
                        required = True,
                        default = 0.2,
                        help = "Tamaño de la partición de validación.")
    
    parser.add_argument("--random_seed",
                        type = int,
                        required = True,
                        default = 42,
                        help = "Semilla para la reproducibilidad.")
    
    args = parser.parse_args()

    main(args)
