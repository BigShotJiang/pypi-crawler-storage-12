"""Módulo que contiene el proceso de separación de unos datos genéricos."""

# Librerías Externas.
import logging
import argparse

from lightgbm import LGBMClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler, LabelEncoder

# Librerías Internas.
from migracion_gcp.lib.io.registry import LocalFileRegistry
from migracion_gcp.lib.clients.factory.abstract_factory import CloudFactory


logging.basicConfig(level = logging.INFO,
                    format = "%(asctime)s - %(levelname)s - %(message)s")


def main(args: argparse.Namespace) -> None:
    """Función de encapsulamiento de la task de partición de datos.
    
    Args:
    ----------
    args: argparse.Namespace.
        Argumentos de la línea de comandos."""
    
    MODEL_TEAM = args.team
    MODEL_SITE = args.site
    MODEL_TAG = args.tag_modelo
    MODEL_VERSION = args.version
    
    RANDOM_SEED = args.random_seed
    
    BLOB_PATH_PREFIX = f"{MODEL_TEAM}/{MODEL_TAG}/{MODEL_SITE}/{MODEL_VERSION}"

    logging.info("🏁 Iniciando el proceso de entrenamiento del modelo...")

    storage_client = CloudFactory.create_storage_service(cloud_provider = args.cloud_provider,
                                                         project_id = args.project_id)

    logging.info("✅ Cliente de almacenamiento creado correctamente.\n")

    logging.info("⏰ Obteniendo los datos de entrenamiento...")

    dataframe_train = storage_client.download_csv(bucket_name = args.bucket_name,
                                                  file_path = f"{BLOB_PATH_PREFIX}/train.csv")

    logging.info("✅ Datos obtenidos correctamente.\n")

    logging.info("⏰ Entrenando el modelo...")

    X_train = dataframe_train.drop(columns = [args.target_column], axis = 1)
    y_train = dataframe_train[args.target_column]

    pipeline = Pipeline(steps = [("scaler", StandardScaler()),
                                 ("model", LGBMClassifier(random_state = RANDOM_SEED))])
    
    target_transformer = LabelEncoder()
    y_train_transformed = target_transformer.fit_transform(y_train)

    pipeline.fit(X_train, y_train_transformed)
    
    logging.info("✅ Modelo entrenado correctamente.\n")

    logging.info("⏰ Calculando métricas del modelo...")

    dataframe_test = storage_client.download_csv(bucket_name = args.bucket_name,
                                                 file_path = f"{BLOB_PATH_PREFIX}/test.csv")

    dataframe_oot = storage_client.download_csv(bucket_name = args.bucket_name,
                                                file_path = f"{BLOB_PATH_PREFIX}/oot.csv")
    
    X_test = dataframe_test.drop(columns = [args.target_column], axis = 1)
    y_test = dataframe_test[args.target_column]

    X_oot = dataframe_oot.drop(columns = [args.target_column], axis = 1)
    y_oot = dataframe_oot[args.target_column]
    
    y_test_transformed = target_transformer.transform(y_test)
    y_oot_transformed = target_transformer.transform(y_oot)

    y_train_scores = pipeline.predict_proba(X_train)
    roc_auc_train = roc_auc_score(y_train_transformed, y_train_scores, multi_class = "ovr")

    y_test_scores = pipeline.predict_proba(X_test)
    roc_auc_test = roc_auc_score(y_test_transformed, y_test_scores, multi_class = "ovr")

    y_oot_scores = pipeline.predict_proba(X_oot)
    roc_auc_oot = roc_auc_score(y_oot_transformed, y_oot_scores, multi_class = "ovr")

    logging.info(f"El AUC del modelo en el conjunto de entrenamiento es: {roc_auc_train}")
    logging.info(f"El AUC del modelo en el conjunto de test es: {roc_auc_test}")
    logging.info(f"El AUC del modelo en el conjunto de oot es: {roc_auc_oot}")

    metrics = {"roc_auc_train": roc_auc_train,
               "roc_auc_test": roc_auc_test,
               "roc_auc_oot": roc_auc_oot}
    
    json_registry = LocalFileRegistry.get_file_handler(file_type = "json")
    pickle_registry = LocalFileRegistry.get_file_handler(file_type = "pickle")

    with json_registry() as manager:
        manager.write_file(file_path = "metrics.json",
                           content = metrics)

        storage_client.upload_file(bucket_name = args.bucket_name,
                                   file_path = f"{manager.temp_dir}/metrics.json",
                                   destination_path = f"{BLOB_PATH_PREFIX}/metrics.json")
        
    logging.info("✅ Métricas calculadas y guardadas correctamente.\n")

    logging.info("⏰ Guardando el modelo ...")

    with pickle_registry() as manager:
        manager.write_file(file_path = "productive_model.pkl",
                           content = pipeline)

        storage_client.upload_file(bucket_name = args.bucket_name,
                                   file_path = f"{manager.temp_dir}/productive_model.pkl",
                                   destination_path = f"{BLOB_PATH_PREFIX}/productive_model.pkl")

    logging.info("✅ Modelo guardado correctamente.")

    logging.info("🏁 Proceso de entrenamiento del modelo finalizado correctamente.")


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description = "Proceso de entrenamiento del modelo.")

    parser.add_argument("--cloud_provider",
                        type = str,
                        required = True,
                        default = "gcs",
                        help = "Proveedor de nube.")
    
    parser.add_argument("--project_id",
                        type = str,
                        required = True,
                        default = "mlops-credits-vertex-poc",
                        help = "ID del proyecto de Google Cloud.")
    
    parser.add_argument("--bucket_name",
                        type = str,
                        required = True,
                        default = "migracion-gcp-bucket",
                        help = "Nombre del bucket de Google Cloud Storage.")
    
    parser.add_argument("--team",
                        type = str,
                        required = True,
                        default = "consumers",
                        help = "Equipo del modelo.")
    
    parser.add_argument("--tag_modelo",
                        type = str,
                        required = True,
                        default = "consumers_iris",
                        help = "Tag del modelo.")
    
    parser.add_argument("--site",
                        type = str,
                        required = True,
                        default = "MLB",
                        help = "Site del modelo.")
    
    parser.add_argument("--version",
                        type = int,
                        required = True,
                        default = 1,
                        help = "Versión de los datos.")
    
    parser.add_argument("--random_seed",
                        type = int,
                        required = True,
                        default = 42,
                        help = "Semilla para la reproducibilidad.")
    
    parser.add_argument("--target_column",
                        type = str,
                        required = True,
                        default = "target",
                        help = "Columna objetivo.")
    
    args = parser.parse_args()

    main(args)
