"""Módulo que implementa la task de partición de datos en Kubeflow."""

# Librerías Externas.
from kfp.v2.dsl import component, Output, Dataset


@component(base_image = "us-east1-docker.pkg.dev/mlops-credits-vertex-poc/mlops-pruebas/base-image:latest")
def split_data(team: str,
               site: str,
               tag_modelo: str,
               version: int,
               project_id: str,
               dataset_name: str,
               table_name: str,
               bucket_name: str,
               random_seed: int,
               test_size: float,
               oot_size: float,
               train_dataset: Output[Dataset],
               test_dataset: Output[Dataset],
               oot_dataset: Output[Dataset]):

    # Librerías Externas.
    import os
    import logging

    from sklearn.model_selection import train_test_split

    # Librerías Internas.
    from migracion_gcp.lib.io.registry import LocalFileRegistry
    from migracion_gcp.lib.clients.factory.abstract_factory import CloudFactory


    logging.basicConfig(level = logging.INFO,
                        format = "%(asctime)s - %(levelname)s - %(message)s")

    
    TABLE_NAME_PREFIX = f"{team}_{tag_modelo}_{site}_{version}"
    
    logging.info("Iniciando el proceso de partición de datos...")

    database_client = CloudFactory.create_database_service(cloud_provider = "gcp",
                                                           project_id = project_id)

    logging.info("Cliente de bases de datos creado correctamente.")

    logging.info("Cliente de almacenamiento creado correctamente.")

    logging.info("Obteniendo los datos de la tabla...")

    dataframe = database_client.get_table(table_name = table_name,
                                          dataset_name = dataset_name)

    logging.info("Datos obtenidos correctamente.")

    logging.info("Particionando los datos...")

    dataframe_train, dataframe_test = train_test_split(dataframe,
                                                       test_size = test_size,
                                                       random_state = random_seed)
        
    dataframe_test, dataframe_oot = train_test_split(dataframe_test,
                                                            test_size = oot_size,
                                                            random_state = random_seed)

    logging.info("Datos particionados correctamente.\n")

    logging.info("Guardando los datos en la tablas y archivos versionados...")

    # Crear directorios locales de Vertex
    os.makedirs(train_dataset.path, exist_ok=True)
    os.makedirs(test_dataset.path, exist_ok=True)
    os.makedirs(oot_dataset.path, exist_ok=True)

    # Rutas locales
    train_path = os.path.join(train_dataset.path, "train_dataset.csv")
    test_path = os.path.join(test_dataset.path, "test_dataset.csv")
    oot_path = os.path.join(oot_dataset.path, "oot_dataset.csv")

    # Guardar CSVs
    dataframe_train.to_csv(train_path, index=False)
    dataframe_test.to_csv(test_path, index=False)
    dataframe_oot.to_csv(oot_path, index=False)

    logging.info("Datos guardados correctamente.")

    logging.info("Proceso de partición de datos finalizado correctamente.")

    train_dataset.display_name = "Train Dataset"
    train_dataset.metadata["version"] = version
    train_dataset.metadata["description"] = "Dataset de entrenamiento"
    train_dataset.metadata["bq_table"] = f"{dataset_name}.{TABLE_NAME_PREFIX}_train"

    test_dataset.display_name = "Test Dataset"
    test_dataset.metadata["version"] = version
    test_dataset.metadata["description"] = "Dataset de prueba"
    test_dataset.metadata["bq_table"] = f"{dataset_name}.{TABLE_NAME_PREFIX}_test"

    oot_dataset.display_name = "OOT Dataset"
    oot_dataset.metadata["version"] = version
    oot_dataset.metadata["description"] = "Dataset de validación"
    oot_dataset.metadata["bq_table"] = f"{dataset_name}.{TABLE_NAME_PREFIX}_oot"
