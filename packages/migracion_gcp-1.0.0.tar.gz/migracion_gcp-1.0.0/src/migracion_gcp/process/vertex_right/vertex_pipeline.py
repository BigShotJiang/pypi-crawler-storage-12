# Librerías Externas.
from typing import Optional

from kfp.v2 import compiler
from kfp.v2.dsl import pipeline, Output, Dataset

from google.cloud import aiplatform

# Librerías Internas.
from migracion_gcp.process.vertex_right.kubeflow_component_split_data import split_data
from migracion_gcp.process.vertex_right.kubefloe_component_train_model import train_model


@pipeline(name = "pipeline-entrenamiento-modelo",
              description = "Pipeline de entrenamiento de modelo. (Split data -> Train model -> Validate model)")
def train_model_pipeline(project_id: Optional[str] = "mlops-credits-vertex-poc",
                         dataset_name: Optional[str] = "pruebas_migracion_juan_pablo",
                         table_name: Optional[str] = "base_iris",
                         bucket_name: Optional[str] = "migracion-gcp-bucket",
                         team: Optional[str] = "consumers",
                         tag_modelo: Optional[str] = "consumers_iris",
                         site: Optional[str] = "MLB",
                         version: Optional[int] = 1,
                         test_size: Optional[float] = 0.3,
                         oot_size: Optional[float] = 0.2,
                         random_seed: Optional[int] = 42,
                         target_column: Optional[str] = "target") -> None:
    """Función que define el pipeline de entrenamiento de modelo."""

    split_data_task = split_data(team = team,
                                 site = site,
                                 tag_modelo = tag_modelo,
                                 version = version,
                                 project_id = project_id,
                                 dataset_name = dataset_name,
                                 table_name = table_name,
                                 bucket_name = bucket_name, random_seed = random_seed, test_size = test_size, oot_size = oot_size)
    
    split_data_task.set_display_name("Split data")

    train_model_task = train_model(team = team,
                                   site = site,
                                   tag_modelo = tag_modelo,
                                   version = version,
                                   project_id = project_id,
                                   bucket_name = bucket_name,
                                   random_seed = random_seed,
                                   target_column = target_column,
                                   train_dataset = split_data_task.outputs["train_dataset"],
                                   test_dataset = split_data_task.outputs["test_dataset"],
                                   oot_dataset = split_data_task.outputs["oot_dataset"])
    
    train_model_task.set_display_name("Train model")


if __name__ == "__main__":

    aiplatform.init(project = "mlops-credits-vertex-poc",
                    location = "us-east1")

    compiler = compiler.Compiler()
    compiler.compile(pipeline_func = train_model_pipeline, package_path = "src/migracion_gcp/process/vertex_right/vertex_pipeline.json")

    pipeline_job = aiplatform.PipelineJob(display_name = "pipeline-entrenamiento-modelo-juan-pablo",
                                          template_path = "src/migracion_gcp/process/vertex_right/vertex_pipeline.json",
                                          pipeline_root = "gs://migracion-gcp-bucket/pipeline-entrenamiento-modelo-juan-pablo/",
                                          parameter_values = {"project_id": "mlops-credits-vertex-poc",
                                                              "dataset_name": "pruebas_migracion_juan_pablo",
                                                              "table_name": "base_iris",
                                                              "bucket_name": "migracion-gcp-bucket",
                                                              "team": "consumers",
                                                              "tag_modelo": "consumers_iris",
                                                              "site": "MLB",
                                                              "version": 1,
                                                              "test_size": 0.3,
                                                              "oot_size": 0.2,
                                                              "random_seed": 42})
    
    pipeline_job.submit()
    pipeline_job.wait()