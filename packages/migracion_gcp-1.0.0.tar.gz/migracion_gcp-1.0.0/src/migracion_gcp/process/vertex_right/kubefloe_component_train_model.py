"""Módulo que implementa la task de entrenamiento de modelo en Kubeflow."""

# Librerías Externas.
from kfp.v2.dsl import component, Input, Output, Dataset, Model, Metrics


@component(base_image = "us-east1-docker.pkg.dev/mlops-credits-vertex-poc/mlops-pruebas/base-image:latest")
def train_model(team: str,
                site: str,
                tag_modelo: str,
                version: int,
                project_id: str,
                bucket_name: str,
                random_seed: int,
                target_column: str,
                train_dataset: Input[Dataset],
                test_dataset: Input[Dataset],
                oot_dataset: Input[Dataset],
                model: Output[Model],
                metrics: Output[Metrics]):
    
    # Librerías Externas.
    import os
    import json
    import pickle
    import logging
    from datetime import datetime as dt

    import pandas as pd

    from lightgbm import LGBMClassifier
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import LabelEncoder
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import roc_auc_score

    from google.cloud import aiplatform

    # Librerías Internas.
    from migracion_gcp.lib.clients.factory.abstract_factory import CloudFactory
    

    logging.info("Iniciando el proceso de entrenamiento del modelo...")

    aiplatform.init(project = project_id,
                    location = "us-east1",
                    experiment = f"{team}_{tag_modelo}_{site}_{version}",
                    experiment_description = "Experimento de entrenamiento de modelo.")
    
    with aiplatform.start_run(run = f"{team}_{tag_modelo}_{site}_{version}_{dt.now().strftime('%Y%m%d_%H%M%S')}") as run:

        logging.info("Cliente de Vertex AI creado correctamente.")

        logging.info("Obteniendo los datos de entrenamiento...")
        
        train_csv_path = os.path.join(train_dataset.path, "train_dataset.csv")
        dataframe_train = pd.read_csv(train_csv_path)

        test_csv_path = os.path.join(test_dataset.path, "test_dataset.csv")
        dataframe_test = pd.read_csv(test_csv_path)

        oot_csv_path = os.path.join(oot_dataset.path, "oot_dataset.csv")
        dataframe_oot = pd.read_csv(oot_csv_path)

        logging.info("Datos obtenidos correctamente.\n")

        logging.info("Entrenando el modelo...")

        X_train = dataframe_train.drop(columns = [target_column], axis = 1)
        y_train = dataframe_train[target_column]

        pipeline = Pipeline(steps = [("scaler", StandardScaler()),
                                     ("model", LGBMClassifier(random_state = random_seed))])
        
        target_transformer = LabelEncoder()
        y_train_transformed = target_transformer.fit_transform(y_train)

        pipeline.fit(X_train, y_train_transformed)
        
        logging.info("Modelo entrenado correctamente.\n")

        logging.info("Calculando métricas del modelo...")

        X_test = dataframe_test.drop(columns = [target_column], axis = 1)
        y_test = dataframe_test[target_column]

        X_oot = dataframe_oot.drop(columns = [target_column], axis = 1)
        y_oot = dataframe_oot[target_column]
        
        y_test_transformed = target_transformer.transform(y_test)
        y_oot_transformed = target_transformer.transform(y_oot)

        y_train_scores = pipeline.predict_proba(X_train)
        roc_auc_train = roc_auc_score(y_train_transformed, y_train_scores, multi_class = "ovr")

        y_test_scores = pipeline.predict_proba(X_test)
        roc_auc_test = roc_auc_score(y_test_transformed, y_test_scores, multi_class = "ovr")

        y_oot_scores = pipeline.predict_proba(X_oot)
        roc_auc_oot = roc_auc_score(y_oot_transformed, y_oot_scores, multi_class = "ovr")

        logging.info(f"El AUC del modelo en el conjunto de entrenamiento es: {roc_auc_train}")
        logging.info(f"El AUC del modelo en el conjunto de test es: {roc_auc_test}")
        logging.info(f"El AUC del modelo en el conjunto de oot es: {roc_auc_oot}")

        metrics = {"roc_auc": {"train": roc_auc_train,
                               "test": roc_auc_test,
                               "oot": roc_auc_oot}}

        metrics_file_path = os.path.join(metrics.path, "metrics.json")
        with open(metrics_file_path, "w") as f:
            json.dump(metrics, f)

        logging.info("Métricas calculadas y guardadas correctamente.\n")

        logging.info("Guardando el modelo ...")

        model_file_path = os.path.join(model.path, "model.pkl")
        with open(model_file_path, "wb") as f:
            pickle.dump(pipeline, f)

        logging.info("Modelo guardado correctamente.")

        run.log_artifact(name = "model",
                         artifact_uri = model_file_path,
                         metadata = {"version": version,
                                     "description": "Modelo experimento"})
        
        run.log_artifact(name = "train_dataset",
                         artifact_uri = train_dataset.path,
                         metadata = {"version": version,
                                     "description": "Dataset de entrenamiento"})
        
        run.log_artifact(name = "test_dataset",
                         artifact_uri = test_dataset.path,
                         metadata = {"version": version,
                                     "description": "Dataset de test"})

        run.log_artifact(name = "oot_dataset",
                         artifact_uri = oot_dataset.path,
                         metadata = {"version": version,
                                     "description": "Dataset de oot"})
        
        for metric in metrics:
            for key, value in metric.items():
                run.log_metric(f"{metric}_{key}", value)

        model.display_name = "Model"
        model.metadata["version"] = version
        model.metadata["description"] = "Modelo experimento"

        metrics.display_name = "Metrics"
        metrics.metadata["version"] = version
        metrics.metadata["description"] = "Metricas experimento"

    logging.info("Proceso de entrenamiento del modelo finalizado correctamente.")
