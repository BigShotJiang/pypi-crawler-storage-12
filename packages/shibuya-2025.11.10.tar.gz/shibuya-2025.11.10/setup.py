from setuptools import setup

# for pip install -e
setup()
