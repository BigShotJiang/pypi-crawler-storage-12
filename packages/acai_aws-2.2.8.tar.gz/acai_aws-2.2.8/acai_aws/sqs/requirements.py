from acai_aws.common.records.requirements import requirements as sqs_requirements


requirements = sqs_requirements
