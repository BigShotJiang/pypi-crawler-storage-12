from acai_aws.common.records.requirements import requirements as sns_requirements


requirements = sns_requirements
