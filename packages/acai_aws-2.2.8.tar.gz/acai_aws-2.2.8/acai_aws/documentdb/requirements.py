from acai_aws.common.records.requirements import requirements as documentdb_requirements


requirements = documentdb_requirements
