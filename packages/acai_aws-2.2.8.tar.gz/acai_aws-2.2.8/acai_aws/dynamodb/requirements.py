from acai_aws.common.records.requirements import requirements as ddb_requirements


requirements = ddb_requirements
