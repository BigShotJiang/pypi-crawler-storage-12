# coding: utf-8

"""
PostFinance Python SDK

This library allows to interact with the PostFinance payment service.

Copyright owner: Wallee AG
Website: https://www.postfinance.ch/en/private.html
Developer email: ecosystem-team@wallee.com

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""


from __future__ import annotations
import pprint
import re
import json

from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictFloat, StrictInt, StrictStr
from typing import Any, ClassVar, Dict, List, Optional, Union
from typing import Optional, Set
from typing_extensions import Self

class SubscriptionProductComponentUpdate(BaseModel):
    """
    SubscriptionProductComponentUpdate
    """
    reference: Optional[StrictInt] = Field(default=None, description="The reference is used to link components across different product versions.")
    tax_class: Optional[StrictInt] = Field(default=None, description="The tax class to be applied to fees.", alias="taxClass")
    quantity_step: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, description="The quantity step determines the interval in which the quantity can be increased.", alias="quantityStep")
    sort_order: Optional[StrictInt] = Field(default=None, description="When listing components, they can be sorted by this number.", alias="sortOrder")
    component_group: Optional[StrictInt] = Field(default=None, description="The group that the component belongs to.", alias="componentGroup")
    name: Optional[Dict[str, StrictStr]] = Field(default=None, description="The localized name of the component that is displayed to the customer.")
    description: Optional[Dict[str, StrictStr]] = Field(default=None, description="The localized description of the component that is displayed to the customer.")
    component_change_weight: Optional[StrictInt] = Field(default=None, description="If switching from a component with a lower tier to a component with a higher one, this is considered an upgrade and a fee may be applied.", alias="componentChangeWeight")
    version: StrictInt = Field(description="The version number indicates the version of the entity. The version is incremented whenever the entity is changed.")
    maximal_quantity: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, description="A maximum of the defined quantity can be selected for this component.", alias="maximalQuantity")
    default_component: Optional[StrictBool] = Field(default=None, description="Whether this is the default component in its group and preselected.", alias="defaultComponent")
    minimal_quantity: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, description="A minimum of the defined quantity must be selected for this component.", alias="minimalQuantity")
    __properties: ClassVar[List[str]] = ["reference", "taxClass", "quantityStep", "sortOrder", "componentGroup", "name", "description", "componentChangeWeight", "version", "maximalQuantity", "defaultComponent", "minimalQuantity"]

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of SubscriptionProductComponentUpdate from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of SubscriptionProductComponentUpdate from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "reference": obj.get("reference"),
            "taxClass": obj.get("taxClass"),
            "quantityStep": obj.get("quantityStep"),
            "sortOrder": obj.get("sortOrder"),
            "componentGroup": obj.get("componentGroup"),
            "name": obj.get("name"),
            "description": obj.get("description"),
            "componentChangeWeight": obj.get("componentChangeWeight"),
            "version": obj.get("version"),
            "maximalQuantity": obj.get("maximalQuantity"),
            "defaultComponent": obj.get("defaultComponent"),
            "minimalQuantity": obj.get("minimalQuantity")
        })
        return _obj


