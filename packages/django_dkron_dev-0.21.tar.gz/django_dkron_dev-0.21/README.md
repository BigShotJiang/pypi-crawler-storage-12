dev releases from https://github.com/surface-security/django-dkron
