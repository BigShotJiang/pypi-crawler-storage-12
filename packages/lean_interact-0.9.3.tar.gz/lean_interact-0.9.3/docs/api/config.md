::: lean_interact.config
    options:
      heading_level: 1
      heading: "Configuration"
      show_symbol_type_heading: false
      members:
        - LeanREPLConfig
