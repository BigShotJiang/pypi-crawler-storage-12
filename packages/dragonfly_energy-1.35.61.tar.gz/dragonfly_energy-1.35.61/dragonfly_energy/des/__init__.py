"""Subpackage for District Energy System (DES) simulation."""
