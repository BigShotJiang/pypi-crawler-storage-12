<div align="center">

# toolkitplus

[![GitHub](https://img.shields.io/badge/github-code-blue?label=GitHub)](https://github.com/oyghen/toolkitplus)
[![PyPI](https://img.shields.io/pypi/v/toolkitplus?label=PyPI)](https://pypi.org/project/toolkitplus)
[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://github.com/oyghen/toolkitplus/blob/main/LICENSE)
[![CI](https://github.com/oyghen/toolkitplus/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/oyghen/toolkitplus/actions/workflows/ci.yml)

</div>

```shell
pip install toolkitplus
```
