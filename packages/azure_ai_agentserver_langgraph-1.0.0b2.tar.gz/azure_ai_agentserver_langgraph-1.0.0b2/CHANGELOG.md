# Release History


## 1.0.0b2 (2025-11-10)

### Bugs Fixed

- Fixed Id generator format.

- Improved stream mode error messsage.

- Updated application insights related configuration environment variables.


## 1.0.0b1 (2025-11-07)

### Features Added

First version
