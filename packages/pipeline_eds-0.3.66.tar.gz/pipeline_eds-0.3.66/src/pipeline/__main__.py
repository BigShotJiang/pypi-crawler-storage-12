# src/__main__.py

import pipeline.cli as c

c.help() # error, needs Context input   