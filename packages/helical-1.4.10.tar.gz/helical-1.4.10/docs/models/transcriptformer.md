::: helical.models.transcriptformer.TranscriptFormer
    handler: python
    options:
      members:
        - process_data
        - get_embeddings
        - get_output_adata
      show_root_heading: True
      show_source: True