__app_name__ = 'kaas-cli'
__version__ = '0.1.287'
