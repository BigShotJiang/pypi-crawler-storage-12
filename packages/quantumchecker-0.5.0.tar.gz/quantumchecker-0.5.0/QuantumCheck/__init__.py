from .main import HomeworkEvaluator
