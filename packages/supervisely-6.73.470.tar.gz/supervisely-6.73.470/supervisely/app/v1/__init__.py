# from supervisely.app.v1.constants import *
# import supervisely.app.v1.widgets

# server-address/apps/designer
# <!--    <sly-notification content="<Notification text in markdown>" :options="{ type: 'note|info|warning|error', name: '<notification header>'}" />-->
# {
# 	"a": "...",
# 	"context_menu": {
# 			"target": ["images_project", "images_dataset", "labeling_job", "team", "workspace"]
#                          "DELME show_description (false by default)": true,
# 			"context_root (optional)": "Download as / Run App (default) / Report",
#                          "context_category (optional)": "Objects"
# 		}
# }

# context_root: Download as, Run App (default), Report
# [![Views](https://app.supervisely.com/public/api/v3/ecosystem.counters?repo=supervisely-ecosystem/roads-test&counter=views&label=custom)](https://supervisely.com)
