from .vad import VAD

__all__ = ["VAD"]
