// Platform-specific modules
#[cfg(target_os = "windows")]
pub mod windows;
