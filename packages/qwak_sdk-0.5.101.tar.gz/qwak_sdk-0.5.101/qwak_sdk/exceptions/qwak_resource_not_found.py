class QwakResourceNotFound(Exception):
    pass
