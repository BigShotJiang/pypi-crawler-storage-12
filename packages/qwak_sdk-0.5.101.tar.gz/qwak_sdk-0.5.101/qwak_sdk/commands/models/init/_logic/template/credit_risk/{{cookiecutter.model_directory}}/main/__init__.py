from .model import CreditRisk


def load_model():
    return CreditRisk()
