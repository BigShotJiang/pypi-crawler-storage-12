from v2simux_gui.cmpbox import CmpBox

    
if __name__ == "__main__":
    app = CmpBox()
    app.mainloop()