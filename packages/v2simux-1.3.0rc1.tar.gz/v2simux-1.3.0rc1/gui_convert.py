from v2simux_gui.convertbox import *


if __name__ == "__main__":
    app = ConvertBox()
    app.mainloop()