# Eventix

## Database

[Frontend for CouchDB localhost](http://admin:dpaeiob@localhost:5984/_utils)


