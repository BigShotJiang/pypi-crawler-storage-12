# This is a demo module for a stub package
