from .cli import PipZapCLI


def main():
    cli = PipZapCLI()
    cli.run()


if __name__ == "__main__":
    main()
