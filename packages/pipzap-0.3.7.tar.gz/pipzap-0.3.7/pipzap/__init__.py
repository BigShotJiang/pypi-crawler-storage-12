"""Dependency optimization and pruning made simple."""

from importlib.metadata import version

__version__ = version("pipzap")
__uv_version__ = version("uv")
