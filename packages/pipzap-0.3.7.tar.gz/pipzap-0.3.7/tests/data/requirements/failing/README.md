# Failing test

A collection of the test cases that fail for one reason or another,
pending audit if it's a problem of the pipzap, just invalid requirements, or something else.
