"""Global settings for pyORCA."""


orca_exe: str = "orca"
