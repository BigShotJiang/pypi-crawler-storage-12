List of all Intent methods used in the application.
