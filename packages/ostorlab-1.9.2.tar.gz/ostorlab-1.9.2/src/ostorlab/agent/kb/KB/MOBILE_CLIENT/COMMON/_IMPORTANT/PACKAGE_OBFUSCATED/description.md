The flutter code is obfuscated, which limits detection capabilities.
