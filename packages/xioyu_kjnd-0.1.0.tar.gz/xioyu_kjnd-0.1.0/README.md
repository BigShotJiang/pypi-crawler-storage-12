# Xioyu_kjnd

A minimal multiplication package demo for PyPI.

## Usage

from ryomath_3.multiply import multiply
print(multiply(5, 7))
