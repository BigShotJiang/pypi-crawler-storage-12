def multiply(a, b):
    """Return the product of a and b."""
    return a * b