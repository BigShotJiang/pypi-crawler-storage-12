from __future__ import annotations

from dandy import BaseIntel


class SmsIntel(BaseIntel):
    body: str
