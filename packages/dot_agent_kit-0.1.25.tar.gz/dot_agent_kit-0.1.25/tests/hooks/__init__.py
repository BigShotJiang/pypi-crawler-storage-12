"""Tests for hooks management functionality."""
