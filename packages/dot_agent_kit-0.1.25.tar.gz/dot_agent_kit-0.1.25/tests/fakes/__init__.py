"""Test fakes for dot-agent-kit."""

from tests.fakes.fake_artifact_repository import FakeArtifactRepository

__all__ = ["FakeArtifactRepository"]
