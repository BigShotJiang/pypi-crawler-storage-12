from ccflow_s3 import *  # noqa


def test_all():
    assert True
