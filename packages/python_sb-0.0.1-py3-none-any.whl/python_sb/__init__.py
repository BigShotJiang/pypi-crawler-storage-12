from pysandboxes import python_sb


def main():
    python_sb.main()


if __name__ == "__main__":
    main()
