from func_validator import ValidationError

__all__ = ["ValidationError"]
