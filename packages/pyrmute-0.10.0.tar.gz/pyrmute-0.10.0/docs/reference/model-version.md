# `ModelVersion` class

Here's the reference information for the `ModelVersion` class, with all its
parameters, attributes and methods.

You can import the `ModelVersion` class directly from `pyrmute`:

```python
from pyrmute import ModelVersion
```

::: pyrmute.ModelVersion
