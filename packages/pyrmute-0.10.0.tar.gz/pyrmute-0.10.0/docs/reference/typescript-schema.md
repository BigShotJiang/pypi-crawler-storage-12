# TypeScript Schema Generator

Here's the reference information for the included TypeScript schema generator
classes with all their parameters, attributes and methods.

You can import these classes directly from `pyrmute`:

```python
from pyrmute import TypeScriptConfig, TypeScriptExporter
```

::: pyrmute.TypeScriptExporter

::: pyrmute.TypeScriptConfig
