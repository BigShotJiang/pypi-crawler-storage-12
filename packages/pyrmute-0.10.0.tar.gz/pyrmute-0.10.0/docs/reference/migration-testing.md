# Migration Testing

Here's the reference information for the migration testing classes, with all
their parameters, attributes and methods.

You can import these classes directly from `pyrmute`:

```python
from pyrmute import (
    MigrationTestCase,
    MigrationTestResult,
    MigrationTestResults,
)
```

::: pyrmute.MigrationTestCase

::: pyrmute.MigrationTestResult

::: pyrmute.MigrationTestResults
