"""Solvent - AI-powered pre-commit hook for code review."""

from solvent_ai.hook import run_pre_commit_review

__all__ = ["run_pre_commit_review"]
