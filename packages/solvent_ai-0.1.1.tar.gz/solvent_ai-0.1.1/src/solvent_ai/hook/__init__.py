"""Pre-commit hook module."""

from solvent_ai.hook.orchestrator import run_pre_commit_review

__all__ = ["run_pre_commit_review"]
