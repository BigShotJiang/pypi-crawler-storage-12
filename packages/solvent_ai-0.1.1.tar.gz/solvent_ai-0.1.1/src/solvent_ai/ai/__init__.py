"""AI integration module for Gemini."""

from solvent_ai.ai.gemini_client import GeminiClient

__all__ = ["GeminiClient"]
