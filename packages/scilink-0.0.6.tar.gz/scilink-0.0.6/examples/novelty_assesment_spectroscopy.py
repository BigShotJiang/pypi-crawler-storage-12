#!/usr/bin/env python3

import sys
sys.path.append("../")

import scilink

# Configure APIs
#scilink.configure('google', '') #I suggest change 'google' to LLM key
#scilink.configure('futurehouse', '')


# data_path="data/tepl_raw.npy"
# system_info="data/tepl_raw.json"

data_path="data/eels_plasmon2.npy"
system_info="data/eels_plasmon2.json"


if __name__ == "__main__":
    
    workflow = scilink.workflows.ExperimentNoveltyAssessment(
        data_type='spectroscopy',
        enable_human_feedback=True,
        measurement_recommendations=True,
    )

    result_unified = workflow.run_complete_workflow(
        data_path=data_path,
        system_info=system_info,
    )

    print("\n--- Workflow Summary ---")
    print(workflow.get_summary(result_unified))
