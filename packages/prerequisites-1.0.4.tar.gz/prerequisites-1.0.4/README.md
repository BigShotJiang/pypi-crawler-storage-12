# prerequisites
[![GitHub license](https://img.shields.io/github/license/SamuelNLP/pyhon-template)](https://github.com/SamuelNLP/pyhon-template/blob/master/LICENSE)

Prerequisite functions to help and assert inputs and outputs condition and type.
