"""Cache manager for music libraries (albums and tracks).

This provides reusable caching infrastructure for both MusicSource and MusicService
classes, eliminating code duplication.
"""

import os
import time
from dataclasses import asdict
from typing import Callable

import orjson
from platformdirs import PlatformDirs

from ..models.album import Album
from ..models.track import Track
from .logging import get_logger


class CacheManager:
    """Manages caching of album and track libraries.

    Uses platformdirs for cross-platform cache directory location with 1-hour TTL.
    """

    def __init__(
        self,
        service_name: str,
        fetch_albums_fn: Callable[[], list[Album]],
        fetch_tracks_fn: Callable[[], list[Track]],
    ):
        """Initialize cache manager.

        Args:
            service_name: Name of the service (e.g., 'spotify', 'subsonic')
            fetch_albums_fn: Function to call to fetch albums from source
            fetch_tracks_fn: Function to call to fetch tracks from source
        """
        self.service_name = service_name
        self.fetch_albums_fn = fetch_albums_fn
        self.fetch_tracks_fn = fetch_tracks_fn
        self.log = get_logger(__name__)

        self.albums: list[Album] = []
        self.tracks: list[Track] = []

        # Setup cache file paths
        self.dirs: PlatformDirs = PlatformDirs(appname="pushtunes", appauthor="psy-q")
        self.album_cache_file = os.path.join(
            self.dirs.user_cache_dir, f"{service_name}_albums.json"
        )
        self.track_cache_file = os.path.join(
            self.dirs.user_cache_dir, f"{service_name}_tracks.json"
        )

    # Album cache methods

    def _update_album_cache(self):
        """Update album cache by fetching fresh data."""
        if self._is_album_cache_expired():
            self.log.info("Album cache is expired or missing, fetching library albums")
            try:
                self.albums = self.fetch_albums_fn()
                # Only save cache if fetch succeeded
                if len(self.albums) > 0:
                    self._save_album_cache()
                    self.log.debug(f"Saved {len(self.albums)} albums to cache")
                else:
                    self.log.warning(
                        "Fetch returned 0 albums. Not saving cache. "
                        "This could indicate an authentication issue."
                    )
            except Exception as e:
                self.log.error(f"Failed to fetch library albums: {e}. Not saving cache.")
                # Re-raise so caller knows the operation failed
                raise

    def _save_album_cache(self):
        """Save albums to cache file."""
        os.makedirs(os.path.dirname(self.album_cache_file), exist_ok=True)
        with open(self.album_cache_file, "w+") as cache:
            albums_as_dicts = [asdict(album) for album in self.albums]
            _ = cache.write(
                orjson.dumps(albums_as_dicts, option=orjson.OPT_INDENT_2).decode()
            )

    def load_album_cache(self):
        """Load albums from cache, updating if expired.

        Load cached album data. It will automatically fetch fresh data if the
        cache is expired (>1 hour old).

        Raises:
            Exception: If cache update or loading fails
        """
        if self._is_album_cache_expired():
            try:
                self._update_album_cache()
            except Exception as e:
                self.log.error(f"Failed to update album cache: {e}")
                # Don't try to load from file if update failed - propagate the error
                raise
        try:
            with open(self.album_cache_file, "r") as cache:
                albums = [Album(**a) for a in orjson.loads(cache.read())]
                self.albums = albums
                self.log.debug(f"Loaded {len(self.albums)} albums from cache")
        except FileNotFoundError:
            self.log.error(
                f"Album cache file not found. Please ensure authentication is set up correctly."
            )
            raise
        except Exception as e:
            self.log.error(f"Error loading album cache: {e}")
            raise

    def _is_album_cache_expired(self, seconds: int = 3600):
        """Check if album cache is expired.

        Args:
            seconds: Cache lifetime in seconds (default: 3600 = 1 hour)

        Returns:
            True if cache is expired or doesn't exist
        """
        if not os.path.exists(self.album_cache_file):
            return True
        else:
            age = time.time() - os.path.getmtime(self.album_cache_file)
            return age > seconds

    # Track cache methods

    def _update_track_cache(self):
        """Update track cache by fetching fresh data."""
        if self._is_track_cache_expired():
            self.log.info("Track cache is expired or missing, fetching library tracks")
            try:
                self.tracks = self.fetch_tracks_fn()
                # Only save cache if fetch succeeded
                if len(self.tracks) > 0:
                    self._save_track_cache()
                    self.log.debug(f"Saved {len(self.tracks)} tracks to cache")
                else:
                    self.log.warning(
                        "Fetch returned 0 tracks. Not saving cache. "
                        "This could indicate an authentication issue."
                    )
            except Exception as e:
                self.log.error(f"Failed to fetch library tracks: {e}. Not saving cache.")
                # Re-raise so caller knows the operation failed
                raise

    def _save_track_cache(self):
        """Save tracks to cache file."""
        os.makedirs(os.path.dirname(self.track_cache_file), exist_ok=True)
        with open(self.track_cache_file, "w+") as cache:
            tracks_as_dicts = [asdict(track) for track in self.tracks]
            _ = cache.write(
                orjson.dumps(tracks_as_dicts, option=orjson.OPT_INDENT_2).decode()
            )

    def load_track_cache(self):
        """Load tracks from cache, updating if expired.

        Load cached track data. It will automatically fetch fresh data if the
        cache is expired (>1 hour old).

        Raises:
            Exception: If cache update or loading fails
        """
        if self._is_track_cache_expired():
            try:
                self._update_track_cache()
            except Exception as e:
                self.log.error(f"Failed to update track cache: {e}")
                # Don't try to load from file if update failed - propagate the error
                raise
        try:
            with open(self.track_cache_file, "r") as cache:
                tracks = [Track(**t) for t in orjson.loads(cache.read())]
                self.tracks = tracks
                self.log.debug(f"Loaded {len(self.tracks)} tracks from cache")
        except FileNotFoundError:
            self.log.error(
                f"Track cache file not found. Please ensure authentication is set up correctly."
            )
            raise
        except Exception as e:
            self.log.error(f"Error loading track cache: {e}")
            raise

    def _is_track_cache_expired(self, seconds: int = 3600):
        """Check if track cache is expired.

        Args:
            seconds: Cache lifetime in seconds (default: 3600 = 1 hour)

        Returns:
            True if cache is expired or doesn't exist
        """
        if not os.path.exists(self.track_cache_file):
            return True
        else:
            age = time.time() - os.path.getmtime(self.track_cache_file)
            return age > seconds
