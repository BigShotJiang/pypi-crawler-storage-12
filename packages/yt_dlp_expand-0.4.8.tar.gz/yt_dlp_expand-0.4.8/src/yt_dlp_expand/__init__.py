from .main_script import ExpandYt_dlp
from .main_script import main
