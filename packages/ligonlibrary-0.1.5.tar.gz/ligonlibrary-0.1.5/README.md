Miscellaneous useful (?) oddments.
