from setuptools import setup

# This setup.py is minimal and defers all configuration to pyproject.toml
# in accordance with modern Python packaging standards (PEP 621).
setup()