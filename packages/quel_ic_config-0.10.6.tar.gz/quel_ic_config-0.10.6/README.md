# quel_ic_config

A host-side software intended for QuEL control devices.

## docs

- [Getting Started](./docs/GETTING_STARTED.md)
- [Developer's Guide](./DEVELOPERS.md)
