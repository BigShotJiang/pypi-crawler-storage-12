"""
WatchDock - A local, self-hosted file monitoring and organization tool.
"""

__version__ = "0.1.0"

