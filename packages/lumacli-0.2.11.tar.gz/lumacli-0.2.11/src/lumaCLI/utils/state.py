"""Luma CLI state."""

state = {"config_dir": None}
