class SimpleJupSwapError(Exception):
	"""Base exception for SimpleJupSwap errors."""


