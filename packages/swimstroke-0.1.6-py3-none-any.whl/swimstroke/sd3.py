

def load(fo):
    raise NotImplementedError()