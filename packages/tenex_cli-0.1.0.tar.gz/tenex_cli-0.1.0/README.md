# Tenex

Tenex (10x) is a Codex wrapper that lets you easily control swarms of agents
