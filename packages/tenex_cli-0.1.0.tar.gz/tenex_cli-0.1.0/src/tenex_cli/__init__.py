"""tenex CLI package."""
