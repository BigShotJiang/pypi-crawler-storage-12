import win32more.appsdk

win32more.appsdk.initialize()
