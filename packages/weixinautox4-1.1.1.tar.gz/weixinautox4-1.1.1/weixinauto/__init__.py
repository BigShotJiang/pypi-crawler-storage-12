from .domain.wechat import Wechat

__all__ = ["Wechat"]
