VERSION = "0.28.2"
VENDOR = "qtoggle/qtoggleserver"
