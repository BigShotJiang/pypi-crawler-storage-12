"""
CLI tool leveraging Redis locking pattern for management of distributed applications in cloud
"""
__version__ = '0.1.6'
