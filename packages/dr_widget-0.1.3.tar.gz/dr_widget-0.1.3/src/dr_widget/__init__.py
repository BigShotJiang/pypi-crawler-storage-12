"""Top-level package for dr_widget."""

from .widgets.config_file_manager import ConfigFileManager

__all__ = ["ConfigFileManager"]
