var _l = Object.defineProperty;
var yl = Object.getPrototypeOf;
var wl = Reflect.get;
var oa = (e) => {
  throw TypeError(e);
};
var xl = (e, t, r) => t in e ? _l(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r;
var Pe = (e, t, r) => xl(e, typeof t != "symbol" ? t + "" : t, r), Bi = (e, t, r) => t.has(e) || oa("Cannot " + r);
var v = (e, t, r) => (Bi(e, t, "read from private field"), r ? r.call(e) : t.get(e)), H = (e, t, r) => t.has(e) ? oa("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, r), te = (e, t, r, n) => (Bi(e, t, "write to private field"), n ? n.call(e, r) : t.set(e, r), r), be = (e, t, r) => (Bi(e, t, "access private method"), r);
var la = (e, t, r) => wl(yl(e), r, t);
var ks = Array.isArray, kl = Array.prototype.indexOf, Ss = Array.from, Sl = Object.defineProperty, xr = Object.getOwnPropertyDescriptor, Al = Object.getOwnPropertyDescriptors, Cl = Object.prototype, El = Array.prototype, Wa = Object.getPrototypeOf, ca = Object.isExtensible;
function wn(e) {
  return typeof e == "function";
}
const lt = () => {
};
function Pl(e) {
  for (var t = 0; t < e.length; t++)
    e[t]();
}
function Ja() {
  var e, t, r = new Promise((n, i) => {
    e = n, t = i;
  });
  return { promise: r, resolve: e, reject: t };
}
function Tl(e, t) {
  if (Array.isArray(e))
    return e;
  if (!(Symbol.iterator in e))
    return Array.from(e);
  const r = [];
  for (const n of e)
    if (r.push(n), r.length === t) break;
  return r;
}
const it = 2, As = 4, Si = 8, fr = 16, dr = 32, Lr = 64, Ai = 128, rt = 1024, St = 2048, vr = 4096, kt = 8192, ar = 16384, Cs = 32768, cr = 65536, ua = 1 << 17, zl = 1 << 18, mn = 1 << 19, qa = 1 << 20, zt = 256, ui = 512, fi = 32768, Yi = 1 << 21, Es = 1 << 22, Fr = 1 << 23, kr = Symbol("$state"), Ka = Symbol("legacy props"), Ml = Symbol(""), Hr = new class extends Error {
  constructor() {
    super(...arguments);
    Pe(this, "name", "StaleReactionError");
    Pe(this, "message", "The reaction that called `getAbortSignal()` was re-run or destroyed");
  }
}();
function Nl(e) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
function Rl() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
function jl(e) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
function Ol() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function Fl(e) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
function Il() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function Ll(e) {
  throw new Error("https://svelte.dev/e/props_invalid_value");
}
function Vl() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function Dl() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function Bl() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
function Gl() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
const Ci = 1, Ei = 2, Ha = 4, Ul = 8, Wl = 16, Jl = 1, ql = 4, Kl = 8, Hl = 16, Yl = 1, Xl = 2, He = Symbol(), Zl = "http://www.w3.org/1999/xhtml", Ql = "http://www.w3.org/2000/svg", Ya = "@attach";
function $l() {
  console.warn("https://svelte.dev/e/select_multiple_invalid_value");
}
function ec() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
let tc = !1;
function Xa(e) {
  return e === this.v;
}
function rc(e, t) {
  return e != e ? t == t : e !== t || e !== null && typeof e == "object" || typeof e == "function";
}
function Za(e) {
  return !rc(e, this.v);
}
let Ze = null;
function cn(e) {
  Ze = e;
}
function fa(e) {
  return (
    /** @type {T} */
    Ps().get(e)
  );
}
function nc(e, t) {
  return Ps().set(e, t), t;
}
function ic(e) {
  return Ps().has(e);
}
function Ae(e, t = !1, r) {
  Ze = {
    p: Ze,
    i: !1,
    c: null,
    e: null,
    s: e,
    x: null,
    l: null
  };
}
function Ce(e) {
  var t = (
    /** @type {ComponentContext} */
    Ze
  ), r = t.e;
  if (r !== null) {
    t.e = null;
    for (var n of r)
      po(n);
  }
  return t.i = !0, Ze = t.p, /** @type {T} */
  {};
}
function Qa() {
  return !0;
}
function Ps(e) {
  return Ze === null && Nl(), Ze.c ?? (Ze.c = new Map(sc(Ze) || void 0));
}
function sc(e) {
  let t = e.p;
  for (; t !== null; ) {
    const r = t.c;
    if (r !== null)
      return r;
    t = t.p;
  }
  return null;
}
let Yr = [];
function ac() {
  var e = Yr;
  Yr = [], Pl(e);
}
function Vr(e) {
  if (Yr.length === 0) {
    var t = Yr;
    queueMicrotask(() => {
      t === Yr && ac();
    });
  }
  Yr.push(e);
}
function $a(e) {
  var t = ve;
  if (t === null)
    return ue.f |= Fr, e;
  if (t.f & Cs)
    un(e, t);
  else {
    if (!(t.f & Ai))
      throw e;
    t.b.error(e);
  }
}
function un(e, t) {
  for (; t !== null; ) {
    if (t.f & Ai)
      try {
        t.b.error(e);
        return;
      } catch (r) {
        e = r;
      }
    t = t.parent;
  }
  throw e;
}
const Xn = /* @__PURE__ */ new Set();
let Ge = null, Xe = null, pr = [], Ts = null, Xi = !1;
var $r, en, Mr, Nr, Nn, tn, rn, tt, Zi, Tr, eo, to;
const mi = class mi {
  constructor() {
    H(this, tt);
    Pe(this, "committed", !1);
    /**
     * The current values of any sources that are updated in this batch
     * They keys of this map are identical to `this.#previous`
     * @type {Map<Source, any>}
     */
    Pe(this, "current", /* @__PURE__ */ new Map());
    /**
     * The values of any sources that are updated in this batch _before_ those updates took place.
     * They keys of this map are identical to `this.#current`
     * @type {Map<Source, any>}
     */
    Pe(this, "previous", /* @__PURE__ */ new Map());
    /**
     * When the batch is committed (and the DOM is updated), we need to remove old branches
     * and append new ones by calling the functions added inside (if/each/key/etc) blocks
     * @type {Set<() => void>}
     */
    H(this, $r, /* @__PURE__ */ new Set());
    /**
     * If a fork is discarded, we need to destroy any effects that are no longer needed
     * @type {Set<(batch: Batch) => void>}
     */
    H(this, en, /* @__PURE__ */ new Set());
    /**
     * The number of async effects that are currently in flight
     */
    H(this, Mr, 0);
    /**
     * The number of async effects that are currently in flight, _not_ inside a pending boundary
     */
    H(this, Nr, 0);
    /**
     * A deferred that resolves when the batch is committed, used with `settled()`
     * TODO replace with Promise.withResolvers once supported widely enough
     * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
     */
    H(this, Nn, null);
    /**
     * Deferred effects (which run after async work has completed) that are DIRTY
     * @type {Effect[]}
     */
    H(this, tn, []);
    /**
     * Deferred effects that are MAYBE_DIRTY
     * @type {Effect[]}
     */
    H(this, rn, []);
    /**
     * A set of branches that still exist, but will be destroyed when this batch
     * is committed — we skip over these during `process`
     * @type {Set<Effect>}
     */
    Pe(this, "skipped_effects", /* @__PURE__ */ new Set());
    Pe(this, "is_fork", !1);
  }
  /**
   *
   * @param {Effect[]} root_effects
   */
  process(t) {
    var n;
    pr = [], this.apply();
    var r = {
      parent: null,
      effect: null,
      effects: [],
      render_effects: [],
      block_effects: []
    };
    for (const i of t)
      be(this, tt, Zi).call(this, i, r);
    this.is_fork || be(this, tt, eo).call(this), v(this, Nr) > 0 || this.is_fork ? (be(this, tt, Tr).call(this, r.effects), be(this, tt, Tr).call(this, r.render_effects), be(this, tt, Tr).call(this, r.block_effects)) : (Ge = null, da(r.render_effects), da(r.effects), (n = v(this, Nn)) == null || n.resolve()), Xe = null;
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} value
   */
  capture(t, r) {
    this.previous.has(t) || this.previous.set(t, r), this.current.set(t, t.v), Xe == null || Xe.set(t, t.v);
  }
  activate() {
    Ge = this;
  }
  deactivate() {
    Ge = null, Xe = null;
  }
  flush() {
    if (this.activate(), pr.length > 0) {
      if (oc(), Ge !== null && Ge !== this)
        return;
    } else v(this, Mr) === 0 && this.process([]);
    this.deactivate();
  }
  discard() {
    for (const t of v(this, en)) t(this);
    v(this, en).clear();
  }
  /**
   *
   * @param {boolean} blocking
   */
  increment(t) {
    te(this, Mr, v(this, Mr) + 1), t && te(this, Nr, v(this, Nr) + 1);
  }
  /**
   *
   * @param {boolean} blocking
   */
  decrement(t) {
    te(this, Mr, v(this, Mr) - 1), t && te(this, Nr, v(this, Nr) - 1), this.revive();
  }
  revive() {
    for (const t of v(this, tn))
      nt(t, St), Ir(t);
    for (const t of v(this, rn))
      nt(t, vr), Ir(t);
    te(this, tn, []), te(this, rn, []), this.flush();
  }
  /** @param {() => void} fn */
  oncommit(t) {
    v(this, $r).add(t);
  }
  /** @param {(batch: Batch) => void} fn */
  ondiscard(t) {
    v(this, en).add(t);
  }
  settled() {
    return (v(this, Nn) ?? te(this, Nn, Ja())).promise;
  }
  static ensure() {
    if (Ge === null) {
      const t = Ge = new mi();
      Xn.add(Ge), mi.enqueue(() => {
        Ge === t && t.flush();
      });
    }
    return Ge;
  }
  /** @param {() => void} task */
  static enqueue(t) {
    Vr(t);
  }
  apply() {
  }
};
$r = new WeakMap(), en = new WeakMap(), Mr = new WeakMap(), Nr = new WeakMap(), Nn = new WeakMap(), tn = new WeakMap(), rn = new WeakMap(), tt = new WeakSet(), /**
 * Traverse the effect tree, executing effects or stashing
 * them for later execution as appropriate
 * @param {Effect} root
 * @param {EffectTarget} target
 */
Zi = function(t, r) {
  var f;
  t.f ^= rt;
  for (var n = t.first; n !== null; ) {
    var i = n.f, s = (i & (dr | Lr)) !== 0, a = s && (i & rt) !== 0, u = a || (i & kt) !== 0 || this.skipped_effects.has(n);
    if (n.f & Ai && ((f = n.b) != null && f.is_pending()) && (r = {
      parent: r,
      effect: n,
      effects: [],
      render_effects: [],
      block_effects: []
    }), !u && n.fn !== null) {
      s ? n.f ^= rt : i & As ? r.effects.push(n) : Jn(n) && (n.f & fr && r.block_effects.push(n), zn(n));
      var l = n.first;
      if (l !== null) {
        n = l;
        continue;
      }
    }
    var c = n.parent;
    for (n = n.next; n === null && c !== null; )
      c === r.effect && (be(this, tt, Tr).call(this, r.effects), be(this, tt, Tr).call(this, r.render_effects), be(this, tt, Tr).call(this, r.block_effects), r = /** @type {EffectTarget} */
      r.parent), n = c.next, c = c.parent;
  }
}, /**
 * @param {Effect[]} effects
 */
Tr = function(t) {
  for (const r of t)
    (r.f & St ? v(this, tn) : v(this, rn)).push(r), nt(r, rt);
}, eo = function() {
  if (v(this, Nr) === 0) {
    for (const t of v(this, $r)) t();
    v(this, $r).clear();
  }
  v(this, Mr) === 0 && be(this, tt, to).call(this);
}, to = function() {
  var i;
  if (Xn.size > 1) {
    this.previous.clear();
    var t = Xe, r = !0, n = {
      parent: null,
      effect: null,
      effects: [],
      render_effects: [],
      block_effects: []
    };
    for (const s of Xn) {
      if (s === this) {
        r = !1;
        continue;
      }
      const a = [];
      for (const [l, c] of this.current) {
        if (s.current.has(l))
          if (r && c !== s.current.get(l))
            s.current.set(l, c);
          else
            continue;
        a.push(l);
      }
      if (a.length === 0)
        continue;
      const u = [...s.current.keys()].filter((l) => !this.current.has(l));
      if (u.length > 0) {
        const l = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Map();
        for (const f of a)
          ro(f, u, l, c);
        if (pr.length > 0) {
          Ge = s, s.apply();
          for (const f of pr)
            be(i = s, tt, Zi).call(i, f, n);
          pr = [], s.deactivate();
        }
      }
    }
    Ge = null, Xe = t;
  }
  this.committed = !0, Xn.delete(this);
};
let sr = mi;
function oc() {
  var e = Zr;
  Xi = !0;
  try {
    var t = 0;
    for (ga(!0); pr.length > 0; ) {
      var r = sr.ensure();
      if (t++ > 1e3) {
        var n, i;
        lc();
      }
      r.process(pr), Sr.clear();
    }
  } finally {
    Xi = !1, ga(e), Ts = null;
  }
}
function lc() {
  try {
    Il();
  } catch (e) {
    un(e, Ts);
  }
}
let Ot = null;
function da(e) {
  var t = e.length;
  if (t !== 0) {
    for (var r = 0; r < t; ) {
      var n = e[r++];
      if (!(n.f & (ar | kt)) && Jn(n) && (Ot = /* @__PURE__ */ new Set(), zn(n), n.deps === null && n.first === null && n.nodes_start === null && (n.teardown === null && n.ac === null ? yo(n) : n.fn = null), (Ot == null ? void 0 : Ot.size) > 0)) {
        Sr.clear();
        for (const i of Ot) {
          if (i.f & (ar | kt)) continue;
          const s = [i];
          let a = i.parent;
          for (; a !== null; )
            Ot.has(a) && (Ot.delete(a), s.push(a)), a = a.parent;
          for (let u = s.length - 1; u >= 0; u--) {
            const l = s[u];
            l.f & (ar | kt) || zn(l);
          }
        }
        Ot.clear();
      }
    }
    Ot = null;
  }
}
function ro(e, t, r, n) {
  if (!r.has(e) && (r.add(e), e.reactions !== null))
    for (const i of e.reactions) {
      const s = i.f;
      s & it ? ro(
        /** @type {Derived} */
        i,
        t,
        r,
        n
      ) : s & (Es | fr) && !(s & St) && // we may have scheduled this one already
      no(i, t, n) && (nt(i, St), Ir(
        /** @type {Effect} */
        i
      ));
    }
}
function no(e, t, r) {
  const n = r.get(e);
  if (n !== void 0) return n;
  if (e.deps !== null)
    for (const i of e.deps) {
      if (t.includes(i))
        return !0;
      if (i.f & it && no(
        /** @type {Derived} */
        i,
        t,
        r
      ))
        return r.set(
          /** @type {Derived} */
          i,
          !0
        ), !0;
    }
  return r.set(e, !1), !1;
}
function Ir(e) {
  for (var t = Ts = e; t.parent !== null; ) {
    t = t.parent;
    var r = t.f;
    if (Xi && t === ve && r & fr)
      return;
    if (r & (Lr | dr)) {
      if (!(r & rt)) return;
      t.f ^= rt;
    }
  }
  pr.push(t);
}
function zs(e) {
  let t = 0, r = Ar(0), n;
  return () => {
    Sc() && (o(r), mo(() => (t === 0 && (n = vn(() => e(() => Kt(r)))), t += 1, () => {
      Vr(() => {
        t -= 1, t === 0 && (n == null || n(), n = void 0, Kt(r));
      });
    })));
  };
}
var cc = cr | mn | Ai;
function uc(e, t, r) {
  new fc(e, t, r);
}
var Et, Pt, xs, Bt, Rr, Gt, Tt, vt, Ut, er, mr, jr, br, Or, _r, bi, qe, dc, vc, Qi, ii, si, $i;
class fc {
  /**
   * @param {TemplateNode} node
   * @param {BoundaryProps} props
   * @param {((anchor: Node) => void)} children
   */
  constructor(t, r, n) {
    H(this, qe);
    /** @type {Boundary | null} */
    Pe(this, "parent");
    H(this, Et, !1);
    /** @type {TemplateNode} */
    H(this, Pt);
    /** @type {TemplateNode | null} */
    H(this, xs, null);
    /** @type {BoundaryProps} */
    H(this, Bt);
    /** @type {((anchor: Node) => void)} */
    H(this, Rr);
    /** @type {Effect} */
    H(this, Gt);
    /** @type {Effect | null} */
    H(this, Tt, null);
    /** @type {Effect | null} */
    H(this, vt, null);
    /** @type {Effect | null} */
    H(this, Ut, null);
    /** @type {DocumentFragment | null} */
    H(this, er, null);
    /** @type {TemplateNode | null} */
    H(this, mr, null);
    H(this, jr, 0);
    H(this, br, 0);
    H(this, Or, !1);
    /**
     * A source containing the number of pending async deriveds/expressions.
     * Only created if `$effect.pending()` is used inside the boundary,
     * otherwise updating the source results in needless `Batch.ensure()`
     * calls followed by no-op flushes
     * @type {Source<number> | null}
     */
    H(this, _r, null);
    H(this, bi, zs(() => (te(this, _r, Ar(v(this, jr))), () => {
      te(this, _r, null);
    })));
    te(this, Pt, t), te(this, Bt, r), te(this, Rr, n), this.parent = /** @type {Effect} */
    ve.b, te(this, Et, !!v(this, Bt).pending), te(this, Gt, Er(() => {
      ve.b = this;
      {
        var i = be(this, qe, Qi).call(this);
        try {
          te(this, Tt, xt(() => n(i)));
        } catch (s) {
          this.error(s);
        }
        v(this, br) > 0 ? be(this, qe, si).call(this) : te(this, Et, !1);
      }
      return () => {
        var s;
        (s = v(this, mr)) == null || s.remove();
      };
    }, cc));
  }
  /**
   * Returns `true` if the effect exists inside a boundary whose pending snippet is shown
   * @returns {boolean}
   */
  is_pending() {
    return v(this, Et) || !!this.parent && this.parent.is_pending();
  }
  has_pending_snippet() {
    return !!v(this, Bt).pending;
  }
  /**
   * Update the source that powers `$effect.pending()` inside this boundary,
   * and controls when the current `pending` snippet (if any) is removed.
   * Do not call from inside the class
   * @param {1 | -1} d
   */
  update_pending_count(t) {
    be(this, qe, $i).call(this, t), te(this, jr, v(this, jr) + t), v(this, _r) && fn(v(this, _r), v(this, jr));
  }
  get_effect_pending() {
    return v(this, bi).call(this), o(
      /** @type {Source<number>} */
      v(this, _r)
    );
  }
  /** @param {unknown} error */
  error(t) {
    var r = v(this, Bt).onerror;
    let n = v(this, Bt).failed;
    if (v(this, Or) || !r && !n)
      throw t;
    v(this, Tt) && (Je(v(this, Tt)), te(this, Tt, null)), v(this, vt) && (Je(v(this, vt)), te(this, vt, null)), v(this, Ut) && (Je(v(this, Ut)), te(this, Ut, null));
    var i = !1, s = !1;
    const a = () => {
      if (i) {
        ec();
        return;
      }
      i = !0, s && Gl(), sr.ensure(), te(this, jr, 0), v(this, Ut) !== null && Xr(v(this, Ut), () => {
        te(this, Ut, null);
      }), te(this, Et, this.has_pending_snippet()), te(this, Tt, be(this, qe, ii).call(this, () => (te(this, Or, !1), xt(() => v(this, Rr).call(this, v(this, Pt)))))), v(this, br) > 0 ? be(this, qe, si).call(this) : te(this, Et, !1);
    };
    var u = ue;
    try {
      ht(null), s = !0, r == null || r(t, a), s = !1;
    } catch (l) {
      un(l, v(this, Gt) && v(this, Gt).parent);
    } finally {
      ht(u);
    }
    n && Vr(() => {
      te(this, Ut, be(this, qe, ii).call(this, () => {
        sr.ensure(), te(this, Or, !0);
        try {
          return xt(() => {
            n(
              v(this, Pt),
              () => t,
              () => a
            );
          });
        } catch (l) {
          return un(
            l,
            /** @type {Effect} */
            v(this, Gt).parent
          ), null;
        } finally {
          te(this, Or, !1);
        }
      }));
    });
  }
}
Et = new WeakMap(), Pt = new WeakMap(), xs = new WeakMap(), Bt = new WeakMap(), Rr = new WeakMap(), Gt = new WeakMap(), Tt = new WeakMap(), vt = new WeakMap(), Ut = new WeakMap(), er = new WeakMap(), mr = new WeakMap(), jr = new WeakMap(), br = new WeakMap(), Or = new WeakMap(), _r = new WeakMap(), bi = new WeakMap(), qe = new WeakSet(), dc = function() {
  try {
    te(this, Tt, xt(() => v(this, Rr).call(this, v(this, Pt))));
  } catch (t) {
    this.error(t);
  }
  te(this, Et, !1);
}, vc = function() {
  const t = v(this, Bt).pending;
  t && (te(this, vt, xt(() => t(v(this, Pt)))), sr.enqueue(() => {
    var r = be(this, qe, Qi).call(this);
    te(this, Tt, be(this, qe, ii).call(this, () => (sr.ensure(), xt(() => v(this, Rr).call(this, r))))), v(this, br) > 0 ? be(this, qe, si).call(this) : (Xr(
      /** @type {Effect} */
      v(this, vt),
      () => {
        te(this, vt, null);
      }
    ), te(this, Et, !1));
  }));
}, Qi = function() {
  var t = v(this, Pt);
  return v(this, Et) && (te(this, mr, ur()), v(this, Pt).before(v(this, mr)), t = v(this, mr)), t;
}, /**
 * @param {() => Effect | null} fn
 */
ii = function(t) {
  var r = ve, n = ue, i = Ze;
  Ht(v(this, Gt)), ht(v(this, Gt)), cn(v(this, Gt).ctx);
  try {
    return t();
  } catch (s) {
    return $a(s), null;
  } finally {
    Ht(r), ht(n), cn(i);
  }
}, si = function() {
  const t = (
    /** @type {(anchor: Node) => void} */
    v(this, Bt).pending
  );
  v(this, Tt) !== null && (te(this, er, document.createDocumentFragment()), v(this, er).append(
    /** @type {TemplateNode} */
    v(this, mr)
  ), ko(v(this, Tt), v(this, er))), v(this, vt) === null && te(this, vt, xt(() => t(v(this, Pt))));
}, /**
 * Updates the pending count associated with the currently visible pending snippet,
 * if any, such that we can replace the snippet with content once work is done
 * @param {1 | -1} d
 */
$i = function(t) {
  var r;
  if (!this.has_pending_snippet()) {
    this.parent && be(r = this.parent, qe, $i).call(r, t);
    return;
  }
  te(this, br, v(this, br) + t), v(this, br) === 0 && (te(this, Et, !1), v(this, vt) && Xr(v(this, vt), () => {
    te(this, vt, null);
  }), v(this, er) && (v(this, Pt).before(v(this, er)), te(this, er, null)));
};
function io(e, t, r, n) {
  const i = Pi;
  if (r.length === 0 && e.length === 0) {
    n(t.map(i));
    return;
  }
  var s = Ge, a = (
    /** @type {Effect} */
    ve
  ), u = hc();
  function l() {
    Promise.all(r.map((c) => /* @__PURE__ */ gc(c))).then((c) => {
      u();
      try {
        n([...t.map(i), ...c]);
      } catch (f) {
        a.f & ar || un(f, a);
      }
      s == null || s.deactivate(), di();
    }).catch((c) => {
      un(c, a);
    });
  }
  e.length > 0 ? Promise.all(e).then(() => {
    u();
    try {
      return l();
    } finally {
      s == null || s.deactivate(), di();
    }
  }) : l();
}
function hc() {
  var e = ve, t = ue, r = Ze, n = Ge;
  return function(s = !0) {
    Ht(e), ht(t), cn(r), s && (n == null || n.activate());
  };
}
function di() {
  Ht(null), ht(null), cn(null);
}
// @__NO_SIDE_EFFECTS__
function Pi(e) {
  var t = it | St, r = ue !== null && ue.f & it ? (
    /** @type {Derived} */
    ue
  ) : null;
  return ve === null || r !== null && r.f & zt ? t |= zt : ve.f |= mn, {
    ctx: Ze,
    deps: null,
    effects: null,
    equals: Xa,
    f: t,
    fn: e,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      He
    ),
    wv: 0,
    parent: r ?? ve,
    ac: null
  };
}
// @__NO_SIDE_EFFECTS__
function gc(e, t) {
  let r = (
    /** @type {Effect | null} */
    ve
  );
  r === null && Rl();
  var n = (
    /** @type {Boundary} */
    r.b
  ), i = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), s = Ar(
    /** @type {V} */
    He
  ), a = !ue, u = /* @__PURE__ */ new Map();
  return Ec(() => {
    var g;
    var l = Ja();
    i = l.promise;
    try {
      Promise.resolve(e()).then(l.resolve, l.reject).then(() => {
        c === Ge && c.committed && c.deactivate(), di();
      });
    } catch (m) {
      l.reject(m), di();
    }
    var c = (
      /** @type {Batch} */
      Ge
    );
    if (a) {
      var f = !n.is_pending();
      n.update_pending_count(1), c.increment(f), (g = u.get(c)) == null || g.reject(Hr), u.delete(c), u.set(c, l);
    }
    const h = (m, d = void 0) => {
      if (c.activate(), d)
        d !== Hr && (s.f |= Fr, fn(s, d));
      else {
        s.f & Fr && (s.f ^= Fr), fn(s, m);
        for (const [p, b] of u) {
          if (u.delete(p), p === c) break;
          b.reject(Hr);
        }
      }
      a && (n.update_pending_count(-1), c.decrement(f));
    };
    l.promise.then(h, (m) => h(null, m || "unknown"));
  }), Ti(() => {
    for (const l of u.values())
      l.reject(Hr);
  }), new Promise((l) => {
    function c(f) {
      function h() {
        f === i ? l(s) : c(i);
      }
      f.then(h, h);
    }
    c(i);
  });
}
// @__NO_SIDE_EFFECTS__
function U(e) {
  const t = /* @__PURE__ */ Pi(e);
  return So(t), t;
}
// @__NO_SIDE_EFFECTS__
function so(e) {
  const t = /* @__PURE__ */ Pi(e);
  return t.equals = Za, t;
}
function ao(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var r = 0; r < t.length; r += 1)
      Je(
        /** @type {Effect} */
        t[r]
      );
  }
}
function pc(e) {
  for (var t = e.parent; t !== null; ) {
    if (!(t.f & it))
      return (
        /** @type {Effect} */
        t
      );
    t = t.parent;
  }
  return null;
}
function Ms(e) {
  var t, r = ve;
  Ht(pc(e));
  try {
    e.f &= ~fi, ao(e), t = Po(e);
  } finally {
    Ht(r);
  }
  return t;
}
function oo(e) {
  var t = Ms(e);
  if (e.equals(t) || (e.v = t, e.wv = Co()), !Dr)
    if (Xe !== null)
      Xe.set(e, e.v);
    else {
      var r = (wr || e.f & zt) && e.deps !== null ? vr : rt;
      nt(e, r);
    }
}
let es = /* @__PURE__ */ new Set();
const Sr = /* @__PURE__ */ new Map();
let lo = !1;
function Ar(e, t) {
  var r = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: e,
    reactions: null,
    equals: Xa,
    rv: 0,
    wv: 0
  };
  return r;
}
// @__NO_SIDE_EFFECTS__
function oe(e, t) {
  const r = Ar(e);
  return So(r), r;
}
// @__NO_SIDE_EFFECTS__
function mc(e, t = !1, r = !0) {
  const n = Ar(e);
  return t || (n.equals = Za), n;
}
function k(e, t, r = !1) {
  ue !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!It || ue.f & ua) && Qa() && ue.f & (it | fr | Es | ua) && !(ot != null && ot.includes(e)) && Bl();
  let n = r ? Fe(t) : t;
  return fn(e, n);
}
function fn(e, t) {
  if (!e.equals(t)) {
    var r = e.v;
    Dr ? Sr.set(e, t) : Sr.set(e, r), e.v = t;
    var n = sr.ensure();
    n.capture(e, r), e.f & it && (e.f & St && Ms(
      /** @type {Derived} */
      e
    ), nt(e, e.f & zt ? vr : rt)), e.wv = Co(), co(e, St), ve !== null && ve.f & rt && !(ve.f & (dr | Lr)) && (Ct === null ? zc([e]) : Ct.push(e)), !n.is_fork && es.size > 0 && !lo && bc();
  }
  return t;
}
function bc() {
  lo = !1;
  const e = Array.from(es);
  for (const t of e)
    t.f & rt && nt(t, vr), Jn(t) && zn(t);
  es.clear();
}
function Kt(e) {
  k(e, e.v + 1);
}
function co(e, t) {
  var r = e.reactions;
  if (r !== null)
    for (var n = r.length, i = 0; i < n; i++) {
      var s = r[i], a = s.f, u = (a & St) === 0;
      u && nt(s, t), a & it ? a & fi || (s.f |= fi, co(
        /** @type {Derived} */
        s,
        vr
      )) : u && (a & fr && Ot !== null && Ot.add(
        /** @type {Effect} */
        s
      ), Ir(
        /** @type {Effect} */
        s
      ));
    }
}
function Fe(e) {
  if (typeof e != "object" || e === null || kr in e)
    return e;
  const t = Wa(e);
  if (t !== Cl && t !== El)
    return e;
  var r = /* @__PURE__ */ new Map(), n = ks(e), i = /* @__PURE__ */ oe(0), s = or, a = (u) => {
    if (or === s)
      return u();
    var l = ue, c = or;
    ht(null), ma(s);
    var f = u();
    return ht(l), ma(c), f;
  };
  return n && r.set("length", /* @__PURE__ */ oe(
    /** @type {any[]} */
    e.length
  )), new Proxy(
    /** @type {any} */
    e,
    {
      defineProperty(u, l, c) {
        (!("value" in c) || c.configurable === !1 || c.enumerable === !1 || c.writable === !1) && Vl();
        var f = r.get(l);
        return f === void 0 ? f = a(() => {
          var h = /* @__PURE__ */ oe(c.value);
          return r.set(l, h), h;
        }) : k(f, c.value, !0), !0;
      },
      deleteProperty(u, l) {
        var c = r.get(l);
        if (c === void 0) {
          if (l in u) {
            const f = a(() => /* @__PURE__ */ oe(He));
            r.set(l, f), Kt(i);
          }
        } else
          k(c, He), Kt(i);
        return !0;
      },
      get(u, l, c) {
        var m;
        if (l === kr)
          return e;
        var f = r.get(l), h = l in u;
        if (f === void 0 && (!h || (m = xr(u, l)) != null && m.writable) && (f = a(() => {
          var d = Fe(h ? u[l] : He), p = /* @__PURE__ */ oe(d);
          return p;
        }), r.set(l, f)), f !== void 0) {
          var g = o(f);
          return g === He ? void 0 : g;
        }
        return Reflect.get(u, l, c);
      },
      getOwnPropertyDescriptor(u, l) {
        var c = Reflect.getOwnPropertyDescriptor(u, l);
        if (c && "value" in c) {
          var f = r.get(l);
          f && (c.value = o(f));
        } else if (c === void 0) {
          var h = r.get(l), g = h == null ? void 0 : h.v;
          if (h !== void 0 && g !== He)
            return {
              enumerable: !0,
              configurable: !0,
              value: g,
              writable: !0
            };
        }
        return c;
      },
      has(u, l) {
        var g;
        if (l === kr)
          return !0;
        var c = r.get(l), f = c !== void 0 && c.v !== He || Reflect.has(u, l);
        if (c !== void 0 || ve !== null && (!f || (g = xr(u, l)) != null && g.writable)) {
          c === void 0 && (c = a(() => {
            var m = f ? Fe(u[l]) : He, d = /* @__PURE__ */ oe(m);
            return d;
          }), r.set(l, c));
          var h = o(c);
          if (h === He)
            return !1;
        }
        return f;
      },
      set(u, l, c, f) {
        var E;
        var h = r.get(l), g = l in u;
        if (n && l === "length")
          for (var m = c; m < /** @type {Source<number>} */
          h.v; m += 1) {
            var d = r.get(m + "");
            d !== void 0 ? k(d, He) : m in u && (d = a(() => /* @__PURE__ */ oe(He)), r.set(m + "", d));
          }
        if (h === void 0)
          (!g || (E = xr(u, l)) != null && E.writable) && (h = a(() => /* @__PURE__ */ oe(void 0)), k(h, Fe(c)), r.set(l, h));
        else {
          g = h.v !== He;
          var p = a(() => Fe(c));
          k(h, p);
        }
        var b = Reflect.getOwnPropertyDescriptor(u, l);
        if (b != null && b.set && b.set.call(f, c), !g) {
          if (n && typeof l == "string") {
            var C = (
              /** @type {Source<number>} */
              r.get("length")
            ), O = Number(l);
            Number.isInteger(O) && O >= C.v && k(C, O + 1);
          }
          Kt(i);
        }
        return !0;
      },
      ownKeys(u) {
        o(i);
        var l = Reflect.ownKeys(u).filter((h) => {
          var g = r.get(h);
          return g === void 0 || g.v !== He;
        });
        for (var [c, f] of r)
          f.v !== He && !(c in u) && l.push(c);
        return l;
      },
      setPrototypeOf() {
        Dl();
      }
    }
  );
}
function va(e) {
  try {
    if (e !== null && typeof e == "object" && kr in e)
      return e[kr];
  } catch {
  }
  return e;
}
function _c(e, t) {
  return Object.is(va(e), va(t));
}
var ha, uo, fo, vo;
function yc() {
  if (ha === void 0) {
    ha = window, uo = /Firefox/.test(navigator.userAgent);
    var e = Element.prototype, t = Node.prototype, r = Text.prototype;
    fo = xr(t, "firstChild").get, vo = xr(t, "nextSibling").get, ca(e) && (e.__click = void 0, e.__className = void 0, e.__attributes = null, e.__style = void 0, e.__e = void 0), ca(r) && (r.__t = void 0);
  }
}
function ur(e = "") {
  return document.createTextNode(e);
}
// @__NO_SIDE_EFFECTS__
function dn(e) {
  return fo.call(e);
}
// @__NO_SIDE_EFFECTS__
function Wn(e) {
  return vo.call(e);
}
function V(e, t) {
  return /* @__PURE__ */ dn(e);
}
function $(e, t = !1) {
  {
    var r = (
      /** @type {DocumentFragment} */
      /* @__PURE__ */ dn(
        /** @type {Node} */
        e
      )
    );
    return r instanceof Comment && r.data === "" ? /* @__PURE__ */ Wn(r) : r;
  }
}
function K(e, t = 1, r = !1) {
  let n = e;
  for (; t--; )
    n = /** @type {TemplateNode} */
    /* @__PURE__ */ Wn(n);
  return n;
}
function wc(e) {
  e.textContent = "";
}
function ho() {
  return !1;
}
function xc(e, t) {
  if (t) {
    const r = document.body;
    e.autofocus = !0, Vr(() => {
      document.activeElement === r && e.focus();
    });
  }
}
function Ns(e) {
  var t = ue, r = ve;
  ht(null), Ht(null);
  try {
    return e();
  } finally {
    ht(t), Ht(r);
  }
}
function go(e) {
  ve === null && ue === null && Fl(), ue !== null && ue.f & zt && ve === null && Ol(), Dr && jl();
}
function kc(e, t) {
  var r = t.last;
  r === null ? t.last = t.first = e : (r.next = e, e.prev = r, t.last = e);
}
function Yt(e, t, r, n = !0) {
  var i = ve;
  i !== null && i.f & kt && (e |= kt);
  var s = {
    ctx: Ze,
    deps: null,
    nodes_start: null,
    nodes_end: null,
    f: e | St,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: i,
    b: i && i.b,
    prev: null,
    teardown: null,
    transitions: null,
    wv: 0,
    ac: null
  };
  if (r)
    try {
      zn(s), s.f |= Cs;
    } catch (l) {
      throw Je(s), l;
    }
  else t !== null && Ir(s);
  if (n) {
    var a = s;
    if (r && a.deps === null && a.teardown === null && a.nodes_start === null && a.first === a.last && // either `null`, or a singular child
    !(a.f & mn) && (a = a.first, e & fr && e & cr && a !== null && (a.f |= cr)), a !== null && (a.parent = i, i !== null && kc(a, i), ue !== null && ue.f & it && !(e & Lr))) {
      var u = (
        /** @type {Derived} */
        ue
      );
      (u.effects ?? (u.effects = [])).push(a);
    }
  }
  return s;
}
function Sc() {
  return ue !== null && !It;
}
function Ti(e) {
  const t = Yt(Si, null, !1);
  return nt(t, rt), t.teardown = e, t;
}
function Ye(e) {
  go();
  var t = (
    /** @type {Effect} */
    ve.f
  ), r = !ue && (t & dr) !== 0 && (t & Cs) === 0;
  if (r) {
    var n = (
      /** @type {ComponentContext} */
      Ze
    );
    (n.e ?? (n.e = [])).push(e);
  } else
    return po(e);
}
function po(e) {
  return Yt(As | qa, e, !1);
}
function Ac(e) {
  return go(), Yt(Si | qa, e, !0);
}
function Cc(e) {
  sr.ensure();
  const t = Yt(Lr | mn, e, !0);
  return (r = {}) => new Promise((n) => {
    r.outro ? Xr(t, () => {
      Je(t), n(void 0);
    }) : (Je(t), n(void 0));
  });
}
function Rs(e) {
  return Yt(As, e, !1);
}
function Ec(e) {
  return Yt(Es | mn, e, !0);
}
function mo(e, t = 0) {
  return Yt(Si | t, e, !0);
}
function ge(e, t = [], r = [], n = []) {
  io(n, t, r, (i) => {
    Yt(Si, () => e(...i.map(o)), !0);
  });
}
function Er(e, t = 0) {
  var r = Yt(fr | t, e, !0);
  return r;
}
function xt(e, t = !0) {
  return Yt(dr | mn, e, !0, t);
}
function bo(e) {
  var t = e.teardown;
  if (t !== null) {
    const r = Dr, n = ue;
    pa(!0), ht(null);
    try {
      t.call(null);
    } finally {
      pa(r), ht(n);
    }
  }
}
function _o(e, t = !1) {
  var r = e.first;
  for (e.first = e.last = null; r !== null; ) {
    const i = r.ac;
    i !== null && Ns(() => {
      i.abort(Hr);
    });
    var n = r.next;
    r.f & Lr ? r.parent = null : Je(r, t), r = n;
  }
}
function Pc(e) {
  for (var t = e.first; t !== null; ) {
    var r = t.next;
    t.f & dr || Je(t), t = r;
  }
}
function Je(e, t = !0) {
  var r = !1;
  (t || e.f & zl) && e.nodes_start !== null && e.nodes_end !== null && (Tc(
    e.nodes_start,
    /** @type {TemplateNode} */
    e.nodes_end
  ), r = !0), _o(e, t && !r), vi(e, 0), nt(e, ar);
  var n = e.transitions;
  if (n !== null)
    for (const s of n)
      s.stop();
  bo(e);
  var i = e.parent;
  i !== null && i.first !== null && yo(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes_start = e.nodes_end = e.ac = null;
}
function Tc(e, t) {
  for (; e !== null; ) {
    var r = e === t ? null : (
      /** @type {TemplateNode} */
      /* @__PURE__ */ Wn(e)
    );
    e.remove(), e = r;
  }
}
function yo(e) {
  var t = e.parent, r = e.prev, n = e.next;
  r !== null && (r.next = n), n !== null && (n.prev = r), t !== null && (t.first === e && (t.first = n), t.last === e && (t.last = r));
}
function Xr(e, t, r = !0) {
  var n = [];
  js(e, n, !0), wo(n, () => {
    r && Je(e), t && t();
  });
}
function wo(e, t) {
  var r = e.length;
  if (r > 0) {
    var n = () => --r || t();
    for (var i of e)
      i.out(n);
  } else
    t();
}
function js(e, t, r) {
  if (!(e.f & kt)) {
    if (e.f ^= kt, e.transitions !== null)
      for (const a of e.transitions)
        (a.is_global || r) && t.push(a);
    for (var n = e.first; n !== null; ) {
      var i = n.next, s = (n.f & cr) !== 0 || // If this is a branch effect without a block effect parent,
      // it means the parent block effect was pruned. In that case,
      // transparency information was transferred to the branch effect.
      (n.f & dr) !== 0 && (e.f & fr) !== 0;
      js(n, t, s ? r : !1), n = i;
    }
  }
}
function Os(e) {
  xo(e, !0);
}
function xo(e, t) {
  if (e.f & kt) {
    e.f ^= kt, e.f & rt || (nt(e, St), Ir(e));
    for (var r = e.first; r !== null; ) {
      var n = r.next, i = (r.f & cr) !== 0 || (r.f & dr) !== 0;
      xo(r, i ? t : !1), r = n;
    }
    if (e.transitions !== null)
      for (const s of e.transitions)
        (s.is_global || t) && s.in();
  }
}
function ko(e, t) {
  for (var r = e.nodes_start, n = e.nodes_end; r !== null; ) {
    var i = r === n ? null : (
      /** @type {TemplateNode} */
      /* @__PURE__ */ Wn(r)
    );
    t.append(r), r = i;
  }
}
let Zr = !1;
function ga(e) {
  Zr = e;
}
let Dr = !1;
function pa(e) {
  Dr = e;
}
let ue = null, It = !1;
function ht(e) {
  ue = e;
}
let ve = null;
function Ht(e) {
  ve = e;
}
let ot = null;
function So(e) {
  ue !== null && (ot === null ? ot = [e] : ot.push(e));
}
let at = null, _t = 0, Ct = null;
function zc(e) {
  Ct = e;
}
let Ao = 1, Tn = 0, or = Tn;
function ma(e) {
  or = e;
}
let wr = !1;
function Co() {
  return ++Ao;
}
function Jn(e) {
  var h;
  var t = e.f;
  if (t & St)
    return !0;
  if (t & vr) {
    var r = e.deps, n = (t & zt) !== 0;
    if (t & it && (e.f &= ~fi), r !== null) {
      var i, s, a = (t & ui) !== 0, u = n && ve !== null && !wr, l = r.length;
      if ((a || u) && (ve === null || !(ve.f & ar))) {
        var c = (
          /** @type {Derived} */
          e
        ), f = c.parent;
        for (i = 0; i < l; i++)
          s = r[i], (a || !((h = s == null ? void 0 : s.reactions) != null && h.includes(c))) && (s.reactions ?? (s.reactions = [])).push(c);
        a && (c.f ^= ui), u && f !== null && !(f.f & zt) && (c.f ^= zt);
      }
      for (i = 0; i < l; i++)
        if (s = r[i], Jn(
          /** @type {Derived} */
          s
        ) && oo(
          /** @type {Derived} */
          s
        ), s.wv > e.wv)
          return !0;
    }
    (!n || ve !== null && !wr) && nt(e, rt);
  }
  return !1;
}
function Eo(e, t, r = !0) {
  var n = e.reactions;
  if (n !== null && !(ot != null && ot.includes(e)))
    for (var i = 0; i < n.length; i++) {
      var s = n[i];
      s.f & it ? Eo(
        /** @type {Derived} */
        s,
        t,
        !1
      ) : t === s && (r ? nt(s, St) : s.f & rt && nt(s, vr), Ir(
        /** @type {Effect} */
        s
      ));
    }
}
function Po(e) {
  var p;
  var t = at, r = _t, n = Ct, i = ue, s = wr, a = ot, u = Ze, l = It, c = or, f = e.f;
  at = /** @type {null | Value[]} */
  null, _t = 0, Ct = null, wr = (f & zt) !== 0 && (It || !Zr || ue === null), ue = f & (dr | Lr) ? null : e, ot = null, cn(e.ctx), It = !1, or = ++Tn, e.ac !== null && (Ns(() => {
    e.ac.abort(Hr);
  }), e.ac = null);
  try {
    e.f |= Yi;
    var h = (
      /** @type {Function} */
      e.fn
    ), g = h(), m = e.deps;
    if (at !== null) {
      var d;
      if (vi(e, _t), m !== null && _t > 0)
        for (m.length = _t + at.length, d = 0; d < at.length; d++)
          m[_t + d] = at[d];
      else
        e.deps = m = at;
      if (!wr || // Deriveds that already have reactions can cleanup, so we still add them as reactions
      f & it && /** @type {import('#client').Derived} */
      e.reactions !== null)
        for (d = _t; d < m.length; d++)
          ((p = m[d]).reactions ?? (p.reactions = [])).push(e);
    } else m !== null && _t < m.length && (vi(e, _t), m.length = _t);
    if (Qa() && Ct !== null && !It && m !== null && !(e.f & (it | vr | St)))
      for (d = 0; d < /** @type {Source[]} */
      Ct.length; d++)
        Eo(
          Ct[d],
          /** @type {Effect} */
          e
        );
    return i !== null && i !== e && (Tn++, Ct !== null && (n === null ? n = Ct : n.push(.../** @type {Source[]} */
    Ct))), e.f & Fr && (e.f ^= Fr), g;
  } catch (b) {
    return $a(b);
  } finally {
    e.f ^= Yi, at = t, _t = r, Ct = n, ue = i, wr = s, ot = a, cn(u), It = l, or = c;
  }
}
function Mc(e, t) {
  let r = t.reactions;
  if (r !== null) {
    var n = kl.call(r, e);
    if (n !== -1) {
      var i = r.length - 1;
      i === 0 ? r = t.reactions = null : (r[n] = r[i], r.pop());
    }
  }
  r === null && t.f & it && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (at === null || !at.includes(t)) && (nt(t, vr), t.f & (zt | ui) || (t.f ^= ui), ao(
    /** @type {Derived} **/
    t
  ), vi(
    /** @type {Derived} **/
    t,
    0
  ));
}
function vi(e, t) {
  var r = e.deps;
  if (r !== null)
    for (var n = t; n < r.length; n++)
      Mc(e, r[n]);
}
function zn(e) {
  var t = e.f;
  if (!(t & ar)) {
    nt(e, rt);
    var r = ve, n = Zr;
    ve = e, Zr = !0;
    try {
      t & fr ? Pc(e) : _o(e), bo(e);
      var i = Po(e);
      e.teardown = typeof i == "function" ? i : null, e.wv = Ao;
      var s;
    } finally {
      Zr = n, ve = r;
    }
  }
}
function o(e) {
  var t = e.f, r = (t & it) !== 0;
  if (ue !== null && !It) {
    var n = ve !== null && (ve.f & ar) !== 0;
    if (!n && !(ot != null && ot.includes(e))) {
      var i = ue.deps;
      if (ue.f & Yi)
        e.rv < Tn && (e.rv = Tn, at === null && i !== null && i[_t] === e ? _t++ : at === null ? at = [e] : (!wr || !at.includes(e)) && at.push(e));
      else {
        (ue.deps ?? (ue.deps = [])).push(e);
        var s = e.reactions;
        s === null ? e.reactions = [ue] : s.includes(ue) || s.push(ue);
      }
    }
  } else if (r && /** @type {Derived} */
  e.deps === null && /** @type {Derived} */
  e.effects === null) {
    var a = (
      /** @type {Derived} */
      e
    ), u = a.parent;
    u !== null && !(u.f & zt) && (a.f ^= zt);
  }
  if (Dr) {
    if (Sr.has(e))
      return Sr.get(e);
    if (r) {
      a = /** @type {Derived} */
      e;
      var l = a.v;
      return (!(a.f & rt) && a.reactions !== null || To(a)) && (l = Ms(a)), Sr.set(a, l), l;
    }
  } else if (r) {
    if (a = /** @type {Derived} */
    e, Xe != null && Xe.has(a))
      return Xe.get(a);
    Jn(a) && oo(a);
  }
  if (Xe != null && Xe.has(e))
    return Xe.get(e);
  if (e.f & Fr)
    throw e.v;
  return e.v;
}
function To(e) {
  if (e.v === He) return !0;
  if (e.deps === null) return !1;
  for (const t of e.deps)
    if (Sr.has(t) || t.f & it && To(
      /** @type {Derived} */
      t
    ))
      return !0;
  return !1;
}
function vn(e) {
  var t = It;
  try {
    return It = !0, e();
  } finally {
    It = t;
  }
}
const Nc = -7169;
function nt(e, t) {
  e.f = e.f & Nc | t;
}
function Rc() {
  return Symbol(Ya);
}
function jc(e) {
  return e.endsWith("capture") && e !== "gotpointercapture" && e !== "lostpointercapture";
}
const Oc = [
  "beforeinput",
  "click",
  "change",
  "dblclick",
  "contextmenu",
  "focusin",
  "focusout",
  "input",
  "keydown",
  "keyup",
  "mousedown",
  "mousemove",
  "mouseout",
  "mouseover",
  "mouseup",
  "pointerdown",
  "pointermove",
  "pointerout",
  "pointerover",
  "pointerup",
  "touchend",
  "touchmove",
  "touchstart"
];
function Fc(e) {
  return Oc.includes(e);
}
const Ic = {
  // no `class: 'className'` because we handle that separately
  formnovalidate: "formNoValidate",
  ismap: "isMap",
  nomodule: "noModule",
  playsinline: "playsInline",
  readonly: "readOnly",
  defaultvalue: "defaultValue",
  defaultchecked: "defaultChecked",
  srcobject: "srcObject",
  novalidate: "noValidate",
  allowfullscreen: "allowFullscreen",
  disablepictureinpicture: "disablePictureInPicture",
  disableremoteplayback: "disableRemotePlayback"
};
function Lc(e) {
  return e = e.toLowerCase(), Ic[e] ?? e;
}
const Vc = ["touchstart", "touchmove"];
function Dc(e) {
  return Vc.includes(e);
}
const zo = /* @__PURE__ */ new Set(), ts = /* @__PURE__ */ new Set();
function Fs(e, t, r, n = {}) {
  function i(s) {
    if (n.capture || An.call(t, s), !s.cancelBubble)
      return Ns(() => r == null ? void 0 : r.call(this, s));
  }
  return e.startsWith("pointer") || e.startsWith("touch") || e === "wheel" ? Vr(() => {
    t.addEventListener(e, i, n);
  }) : t.addEventListener(e, i, n), i;
}
function ba(e, t, r, n = {}) {
  var i = Fs(t, e, r, n);
  return () => {
    e.removeEventListener(t, i, n);
  };
}
function _a(e, t, r, n, i) {
  var s = { capture: n, passive: i }, a = Fs(e, t, r, s);
  (t === document.body || // @ts-ignore
  t === window || // @ts-ignore
  t === document || // Firefox has quirky behavior, it can happen that we still get "canplay" events when the element is already removed
  t instanceof HTMLMediaElement) && Ti(() => {
    t.removeEventListener(e, a, s);
  });
}
function zi(e) {
  for (var t = 0; t < e.length; t++)
    zo.add(e[t]);
  for (var r of ts)
    r(e);
}
let ya = null;
function An(e) {
  var b;
  var t = this, r = (
    /** @type {Node} */
    t.ownerDocument
  ), n = e.type, i = ((b = e.composedPath) == null ? void 0 : b.call(e)) || [], s = (
    /** @type {null | Element} */
    i[0] || e.target
  );
  ya = e;
  var a = 0, u = ya === e && e.__root;
  if (u) {
    var l = i.indexOf(u);
    if (l !== -1 && (t === document || t === /** @type {any} */
    window)) {
      e.__root = t;
      return;
    }
    var c = i.indexOf(t);
    if (c === -1)
      return;
    l <= c && (a = l);
  }
  if (s = /** @type {Element} */
  i[a] || e.target, s !== t) {
    Sl(e, "currentTarget", {
      configurable: !0,
      get() {
        return s || r;
      }
    });
    var f = ue, h = ve;
    ht(null), Ht(null);
    try {
      for (var g, m = []; s !== null; ) {
        var d = s.assignedSlot || s.parentNode || /** @type {any} */
        s.host || null;
        try {
          var p = s["__" + n];
          p != null && (!/** @type {any} */
          s.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          e.target === s) && p.call(s, e);
        } catch (C) {
          g ? m.push(C) : g = C;
        }
        if (e.cancelBubble || d === t || d === null)
          break;
        s = d;
      }
      if (g) {
        for (let C of m)
          queueMicrotask(() => {
            throw C;
          });
        throw g;
      }
    } finally {
      e.__root = t, delete e.currentTarget, ht(f), Ht(h);
    }
  }
}
function Mo(e) {
  var t = document.createElement("template");
  return t.innerHTML = e.replaceAll("<!>", "<!---->"), t.content;
}
function hn(e, t) {
  var r = (
    /** @type {Effect} */
    ve
  );
  r.nodes_start === null && (r.nodes_start = e, r.nodes_end = t);
}
// @__NO_SIDE_EFFECTS__
function W(e, t) {
  var r = (t & Yl) !== 0, n = (t & Xl) !== 0, i, s = !e.startsWith("<!>");
  return () => {
    i === void 0 && (i = Mo(s ? e : "<!>" + e), r || (i = /** @type {Node} */
    /* @__PURE__ */ dn(i)));
    var a = (
      /** @type {TemplateNode} */
      n || uo ? document.importNode(i, !0) : i.cloneNode(!0)
    );
    if (r) {
      var u = (
        /** @type {TemplateNode} */
        /* @__PURE__ */ dn(a)
      ), l = (
        /** @type {TemplateNode} */
        a.lastChild
      );
      hn(u, l);
    } else
      hn(a, a);
    return a;
  };
}
// @__NO_SIDE_EFFECTS__
function Bc(e, t, r = "svg") {
  var n = !e.startsWith("<!>"), i = `<${r}>${n ? e : "<!>" + e}</${r}>`, s;
  return () => {
    if (!s) {
      var a = (
        /** @type {DocumentFragment} */
        Mo(i)
      ), u = (
        /** @type {Element} */
        /* @__PURE__ */ dn(a)
      );
      s = /** @type {Element} */
      /* @__PURE__ */ dn(u);
    }
    var l = (
      /** @type {TemplateNode} */
      s.cloneNode(!0)
    );
    return hn(l, l), l;
  };
}
// @__NO_SIDE_EFFECTS__
function Gc(e, t) {
  return /* @__PURE__ */ Bc(e, t, "svg");
}
function Te(e = "") {
  {
    var t = ur(e + "");
    return hn(t, t), t;
  }
}
function _e() {
  var e = document.createDocumentFragment(), t = document.createComment(""), r = ur();
  return e.append(t, r), hn(t, r), e;
}
function S(e, t) {
  e !== null && e.before(
    /** @type {Node} */
    t
  );
}
function Mi() {
  var e;
  return (e = window.__svelte ?? (window.__svelte = {})).uid ?? (e.uid = 1), `c${window.__svelte.uid++}`;
}
function ye(e, t) {
  var r = t == null ? "" : typeof t == "object" ? t + "" : t;
  r !== (e.__t ?? (e.__t = e.nodeValue)) && (e.__t = r, e.nodeValue = r + "");
}
function Uc(e, t) {
  return Wc(e, t);
}
const qr = /* @__PURE__ */ new Map();
function Wc(e, { target: t, anchor: r, props: n = {}, events: i, context: s, intro: a = !0 }) {
  yc();
  var u = /* @__PURE__ */ new Set(), l = (h) => {
    for (var g = 0; g < h.length; g++) {
      var m = h[g];
      if (!u.has(m)) {
        u.add(m);
        var d = Dc(m);
        t.addEventListener(m, An, { passive: d });
        var p = qr.get(m);
        p === void 0 ? (document.addEventListener(m, An, { passive: d }), qr.set(m, 1)) : qr.set(m, p + 1);
      }
    }
  };
  l(Ss(zo)), ts.add(l);
  var c = void 0, f = Cc(() => {
    var h = r ?? t.appendChild(ur());
    return uc(
      /** @type {TemplateNode} */
      h,
      {
        pending: () => {
        }
      },
      (g) => {
        if (s) {
          Ae({});
          var m = (
            /** @type {ComponentContext} */
            Ze
          );
          m.c = s;
        }
        i && (n.$$events = i), c = e(g, n) || {}, s && Ce();
      }
    ), () => {
      var d;
      for (var g of u) {
        t.removeEventListener(g, An);
        var m = (
          /** @type {number} */
          qr.get(g)
        );
        --m === 0 ? (document.removeEventListener(g, An), qr.delete(g)) : qr.set(g, m);
      }
      ts.delete(l), h !== r && ((d = h.parentNode) == null || d.removeChild(h));
    };
  });
  return rs.set(c, f), c;
}
let rs = /* @__PURE__ */ new WeakMap();
function Jc(e, t) {
  const r = rs.get(e);
  return r ? (rs.delete(e), r(t)) : Promise.resolve();
}
var Ft, Wt, yt, Rn, jn, _i;
class Ni {
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(t, r = !0) {
    /** @type {TemplateNode} */
    Pe(this, "anchor");
    /** @type {Map<Batch, Key>} */
    H(this, Ft, /* @__PURE__ */ new Map());
    /** @type {Map<Key, Effect>} */
    H(this, Wt, /* @__PURE__ */ new Map());
    /** @type {Map<Key, Branch>} */
    H(this, yt, /* @__PURE__ */ new Map());
    /**
     * Whether to pause (i.e. outro) on change, or destroy immediately.
     * This is necessary for `<svelte:element>`
     */
    H(this, Rn, !0);
    H(this, jn, () => {
      var t = (
        /** @type {Batch} */
        Ge
      );
      if (v(this, Ft).has(t)) {
        var r = (
          /** @type {Key} */
          v(this, Ft).get(t)
        ), n = v(this, Wt).get(r);
        if (n)
          Os(n);
        else {
          var i = v(this, yt).get(r);
          i && (v(this, Wt).set(r, i.effect), v(this, yt).delete(r), i.fragment.lastChild.remove(), this.anchor.before(i.fragment), n = i.effect);
        }
        for (const [s, a] of v(this, Ft)) {
          if (v(this, Ft).delete(s), s === t)
            break;
          const u = v(this, yt).get(a);
          u && (Je(u.effect), v(this, yt).delete(a));
        }
        for (const [s, a] of v(this, Wt)) {
          if (s === r) continue;
          const u = () => {
            if (Array.from(v(this, Ft).values()).includes(s)) {
              var c = document.createDocumentFragment();
              ko(a, c), c.append(ur()), v(this, yt).set(s, { effect: a, fragment: c });
            } else
              Je(a);
            v(this, Wt).delete(s);
          };
          v(this, Rn) || !n ? Xr(a, u, !1) : u();
        }
      }
    });
    /**
     * @param {Batch} batch
     */
    H(this, _i, (t) => {
      v(this, Ft).delete(t);
      const r = Array.from(v(this, Ft).values());
      for (const [n, i] of v(this, yt))
        r.includes(n) || (Je(i.effect), v(this, yt).delete(n));
    });
    this.anchor = t, te(this, Rn, r);
  }
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(t, r) {
    var n = (
      /** @type {Batch} */
      Ge
    ), i = ho();
    if (r && !v(this, Wt).has(t) && !v(this, yt).has(t))
      if (i) {
        var s = document.createDocumentFragment(), a = ur();
        s.append(a), v(this, yt).set(t, {
          effect: xt(() => r(a)),
          fragment: s
        });
      } else
        v(this, Wt).set(
          t,
          xt(() => r(this.anchor))
        );
    if (v(this, Ft).set(n, t), i) {
      for (const [u, l] of v(this, Wt))
        u === t ? n.skipped_effects.delete(l) : n.skipped_effects.add(l);
      for (const [u, l] of v(this, yt))
        u === t ? n.skipped_effects.delete(l.effect) : n.skipped_effects.add(l.effect);
      n.oncommit(v(this, jn)), n.ondiscard(v(this, _i));
    } else
      v(this, jn).call(this);
  }
}
Ft = new WeakMap(), Wt = new WeakMap(), yt = new WeakMap(), Rn = new WeakMap(), jn = new WeakMap(), _i = new WeakMap();
function ee(e, t, r = !1) {
  var n = new Ni(e), i = r ? cr : 0;
  function s(a, u) {
    n.ensure(a, u);
  }
  Er(() => {
    var a = !1;
    t((u, l = !0) => {
      a = !0, s(l, u);
    }), a || s(!1, null);
  }, i);
}
function No(e, t) {
  return t;
}
function qc(e, t, r) {
  for (var n = e.items, i = [], s = t.length, a = 0; a < s; a++)
    js(t[a].e, i, !0);
  var u = s > 0 && i.length === 0 && r !== null;
  if (u) {
    var l = (
      /** @type {Element} */
      /** @type {Element} */
      r.parentNode
    );
    wc(l), l.append(
      /** @type {Element} */
      r
    ), n.clear(), Dt(e, t[0].prev, t[s - 1].next);
  }
  wo(i, () => {
    for (var c = 0; c < s; c++) {
      var f = t[c];
      u || (n.delete(f.k), Dt(e, f.prev, f.next)), Je(f.e, !u);
    }
  });
}
function Ro(e, t, r, n, i, s = null) {
  var a = e, u = { flags: t, items: /* @__PURE__ */ new Map(), first: null }, l = (t & Ha) !== 0;
  if (l) {
    var c = (
      /** @type {Element} */
      e
    );
    a = c.appendChild(ur());
  }
  var f = null, h = !1, g = /* @__PURE__ */ new Map(), m = /* @__PURE__ */ so(() => {
    var C = r();
    return ks(C) ? C : C == null ? [] : Ss(C);
  }), d, p;
  function b() {
    Kc(
      p,
      d,
      u,
      g,
      a,
      i,
      t,
      n,
      r
    ), s !== null && (d.length === 0 ? f ? Os(f) : f = xt(() => s(a)) : f !== null && Xr(f, () => {
      f = null;
    }));
  }
  Er(() => {
    p ?? (p = /** @type {Effect} */
    ve), d = /** @type {V[]} */
    o(m);
    var C = d.length;
    if (!(h && C === 0)) {
      h = C === 0;
      var O, E, x, M;
      if (ho()) {
        var P = /* @__PURE__ */ new Set(), j = (
          /** @type {Batch} */
          Ge
        );
        for (E = 0; E < C; E += 1) {
          x = d[E], M = n(x, E);
          var N = u.items.get(M) ?? g.get(M);
          N ? t & (Ci | Ei) && jo(N, x, E, t) : (O = Oo(
            null,
            u,
            null,
            null,
            x,
            M,
            E,
            i,
            t,
            r,
            !0
          ), g.set(M, O)), P.add(M);
        }
        for (const [I, ne] of u.items)
          P.has(I) || j.skipped_effects.add(ne.e);
        j.oncommit(b);
      } else
        b();
      o(m);
    }
  });
}
function Kc(e, t, r, n, i, s, a, u, l) {
  var z, F, L, D;
  var c = (a & Ul) !== 0, f = (a & (Ci | Ei)) !== 0, h = t.length, g = r.items, m = r.first, d = m, p, b = null, C, O = [], E = [], x, M, P, j;
  if (c)
    for (j = 0; j < h; j += 1)
      x = t[j], M = u(x, j), P = g.get(M), P !== void 0 && ((z = P.a) == null || z.measure(), (C ?? (C = /* @__PURE__ */ new Set())).add(P));
  for (j = 0; j < h; j += 1) {
    if (x = t[j], M = u(x, j), P = g.get(M), P === void 0) {
      var N = n.get(M);
      if (N !== void 0) {
        n.delete(M), g.set(M, N);
        var I = b ? b.next : d;
        Dt(r, b, N), Dt(r, N, I), Gi(N, I, i), b = N;
      } else {
        var ne = d ? (
          /** @type {TemplateNode} */
          d.e.nodes_start
        ) : i;
        b = Oo(
          ne,
          r,
          b,
          b === null ? r.first : b.next,
          x,
          M,
          j,
          s,
          a,
          l
        );
      }
      g.set(M, b), O = [], E = [], d = b.next;
      continue;
    }
    if (f && jo(P, x, j, a), P.e.f & kt && (Os(P.e), c && ((F = P.a) == null || F.unfix(), (C ?? (C = /* @__PURE__ */ new Set())).delete(P))), P !== d) {
      if (p !== void 0 && p.has(P)) {
        if (O.length < E.length) {
          var Z = E[0], ie;
          b = Z.prev;
          var fe = O[0], R = O[O.length - 1];
          for (ie = 0; ie < O.length; ie += 1)
            Gi(O[ie], Z, i);
          for (ie = 0; ie < E.length; ie += 1)
            p.delete(E[ie]);
          Dt(r, fe.prev, R.next), Dt(r, b, fe), Dt(r, R, Z), d = Z, b = R, j -= 1, O = [], E = [];
        } else
          p.delete(P), Gi(P, d, i), Dt(r, P.prev, P.next), Dt(r, P, b === null ? r.first : b.next), Dt(r, b, P), b = P;
        continue;
      }
      for (O = [], E = []; d !== null && d.k !== M; )
        d.e.f & kt || (p ?? (p = /* @__PURE__ */ new Set())).add(d), E.push(d), d = d.next;
      if (d === null)
        continue;
      P = d;
    }
    O.push(P), b = P, d = P.next;
  }
  if (d !== null || p !== void 0) {
    for (var _ = p === void 0 ? [] : Ss(p); d !== null; )
      d.e.f & kt || _.push(d), d = d.next;
    var w = _.length;
    if (w > 0) {
      var A = a & Ha && h === 0 ? i : null;
      if (c) {
        for (j = 0; j < w; j += 1)
          (L = _[j].a) == null || L.measure();
        for (j = 0; j < w; j += 1)
          (D = _[j].a) == null || D.fix();
      }
      qc(r, _, A);
    }
  }
  c && Vr(() => {
    var G;
    if (C !== void 0)
      for (P of C)
        (G = P.a) == null || G.apply();
  }), e.first = r.first && r.first.e, e.last = b && b.e;
  for (var y of n.values())
    Je(y.e);
  n.clear();
}
function jo(e, t, r, n) {
  n & Ci && fn(e.v, t), n & Ei ? fn(
    /** @type {Value<number>} */
    e.i,
    r
  ) : e.i = r;
}
function Oo(e, t, r, n, i, s, a, u, l, c, f) {
  var h = (l & Ci) !== 0, g = (l & Wl) === 0, m = h ? g ? /* @__PURE__ */ mc(i, !1, !1) : Ar(i) : i, d = l & Ei ? Ar(a) : a, p = {
    i: d,
    v: m,
    k: s,
    a: null,
    // @ts-expect-error
    e: null,
    prev: r,
    next: n
  };
  try {
    if (e === null) {
      var b = document.createDocumentFragment();
      b.append(e = ur());
    }
    return p.e = xt(() => u(
      /** @type {Node} */
      e,
      m,
      d,
      c
    ), tc), p.e.prev = r && r.e, p.e.next = n && n.e, r === null ? f || (t.first = p) : (r.next = p, r.e.next = p.e), n !== null && (n.prev = p, n.e.prev = p.e), p;
  } finally {
  }
}
function Gi(e, t, r) {
  for (var n = e.next ? (
    /** @type {TemplateNode} */
    e.next.e.nodes_start
  ) : r, i = t ? (
    /** @type {TemplateNode} */
    t.e.nodes_start
  ) : r, s = (
    /** @type {TemplateNode} */
    e.e.nodes_start
  ); s !== null && s !== n; ) {
    var a = (
      /** @type {TemplateNode} */
      /* @__PURE__ */ Wn(s)
    );
    i.before(s), s = a;
  }
}
function Dt(e, t, r) {
  t === null ? e.first = r : (t.next = r, t.e.next = r && r.e), r !== null && (r.prev = t, r.e.prev = t && t.e);
}
function Ve(e, t, ...r) {
  var n = new Ni(e);
  Er(() => {
    const i = t() ?? null;
    n.ensure(i, i && ((s) => i(s, ...r)));
  }, cr);
}
function ze(e, t, r) {
  var n = new Ni(e);
  Er(() => {
    var i = t() ?? null;
    n.ensure(i, i && ((s) => r(s, i)));
  }, cr);
}
function Is(e, t, r, n, i, s) {
  var a = null, u = (
    /** @type {TemplateNode} */
    e
  ), l = new Ni(u, !1);
  Er(() => {
    const c = t() || null;
    var f = r || c === "svg" ? Ql : null;
    if (c === null) {
      l.ensure(null, null);
      return;
    }
    return l.ensure(c, (h) => {
      if (c) {
        if (a = f ? document.createElementNS(f, c) : document.createElement(c), hn(a, a), n) {
          var g = (
            /** @type {TemplateNode} */
            a.appendChild(ur())
          );
          n(a, g);
        }
        ve.nodes_end = a, h.before(a);
      }
    }), () => {
    };
  }, cr), Ti(() => {
  });
}
function Hc(e, t) {
  var r = void 0, n;
  Er(() => {
    r !== (r = t()) && (n && (Je(n), n = null), r && (n = xt(() => {
      Rs(() => (
        /** @type {(node: Element) => void} */
        r(e)
      ));
    })));
  });
}
function Fo(e) {
  var t, r, n = "";
  if (typeof e == "string" || typeof e == "number") n += e;
  else if (typeof e == "object") if (Array.isArray(e)) {
    var i = e.length;
    for (t = 0; t < i; t++) e[t] && (r = Fo(e[t])) && (n && (n += " "), n += r);
  } else for (r in e) e[r] && (n && (n += " "), n += r);
  return n;
}
function Qr() {
  for (var e, t, r = 0, n = "", i = arguments.length; r < i; r++) (e = arguments[r]) && (t = Fo(e)) && (n && (n += " "), n += t);
  return n;
}
function Io(e) {
  return typeof e == "object" ? Qr(e) : e ?? "";
}
const wa = [...` 	
\r\f \v\uFEFF`];
function Yc(e, t, r) {
  var n = e == null ? "" : "" + e;
  if (t && (n = n ? n + " " + t : t), r) {
    for (var i in r)
      if (r[i])
        n = n ? n + " " + i : i;
      else if (n.length)
        for (var s = i.length, a = 0; (a = n.indexOf(i, a)) >= 0; ) {
          var u = a + s;
          (a === 0 || wa.includes(n[a - 1])) && (u === n.length || wa.includes(n[u])) ? n = (a === 0 ? "" : n.substring(0, a)) + n.substring(u + 1) : a = u;
        }
  }
  return n === "" ? null : n;
}
function xa(e, t = !1) {
  var r = t ? " !important;" : ";", n = "";
  for (var i in e) {
    var s = e[i];
    s != null && s !== "" && (n += " " + i + ": " + s + r);
  }
  return n;
}
function Ui(e) {
  return e[0] !== "-" || e[1] !== "-" ? e.toLowerCase() : e;
}
function Xc(e, t) {
  if (t) {
    var r = "", n, i;
    if (Array.isArray(t) ? (n = t[0], i = t[1]) : n = t, e) {
      e = String(e).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
      var s = !1, a = 0, u = !1, l = [];
      n && l.push(...Object.keys(n).map(Ui)), i && l.push(...Object.keys(i).map(Ui));
      var c = 0, f = -1;
      const p = e.length;
      for (var h = 0; h < p; h++) {
        var g = e[h];
        if (u ? g === "/" && e[h - 1] === "*" && (u = !1) : s ? s === g && (s = !1) : g === "/" && e[h + 1] === "*" ? u = !0 : g === '"' || g === "'" ? s = g : g === "(" ? a++ : g === ")" && a--, !u && s === !1 && a === 0) {
          if (g === ":" && f === -1)
            f = h;
          else if (g === ";" || h === p - 1) {
            if (f !== -1) {
              var m = Ui(e.substring(c, f).trim());
              if (!l.includes(m)) {
                g !== ";" && h++;
                var d = e.substring(c, h).trim();
                r += " " + d + ";";
              }
            }
            c = h + 1, f = -1;
          }
        }
      }
    }
    return n && (r += xa(n)), i && (r += xa(i, !0)), r = r.trim(), r === "" ? null : r;
  }
  return e == null ? null : String(e);
}
function wt(e, t, r, n, i, s) {
  var a = e.__className;
  if (a !== r || a === void 0) {
    var u = Yc(r, n, s);
    u == null ? e.removeAttribute("class") : t ? e.className = u : e.setAttribute("class", u), e.__className = r;
  } else if (s && i !== s)
    for (var l in s) {
      var c = !!s[l];
      (i == null || c !== !!i[l]) && e.classList.toggle(l, c);
    }
  return s;
}
function Wi(e, t = {}, r, n) {
  for (var i in r) {
    var s = r[i];
    t[i] !== s && (r[i] == null ? e.style.removeProperty(i) : e.style.setProperty(i, s, n));
  }
}
function Zc(e, t, r, n) {
  var i = e.__style;
  if (i !== t) {
    var s = Xc(t, n);
    s == null ? e.removeAttribute("style") : e.style.cssText = s, e.__style = t;
  } else n && (Array.isArray(n) ? (Wi(e, r == null ? void 0 : r[0], n[0]), Wi(e, r == null ? void 0 : r[1], n[1], "important")) : Wi(e, r, n));
  return n;
}
function ns(e, t, r = !1) {
  if (e.multiple) {
    if (t == null)
      return;
    if (!ks(t))
      return $l();
    for (var n of e.options)
      n.selected = t.includes(ka(n));
    return;
  }
  for (n of e.options) {
    var i = ka(n);
    if (_c(i, t)) {
      n.selected = !0;
      return;
    }
  }
  (!r || t !== void 0) && (e.selectedIndex = -1);
}
function Qc(e) {
  var t = new MutationObserver(() => {
    ns(e, e.__value);
  });
  t.observe(e, {
    // Listen to option element changes
    childList: !0,
    subtree: !0,
    // because of <optgroup>
    // Listen to option element value attribute changes
    // (doesn't get notified of select value changes,
    // because that property is not reflected as an attribute)
    attributes: !0,
    attributeFilter: ["value"]
  }), Ti(() => {
    t.disconnect();
  });
}
function ka(e) {
  return "__value" in e ? e.__value : e.value;
}
const xn = Symbol("class"), kn = Symbol("style"), Lo = Symbol("is custom element"), Vo = Symbol("is html");
function $c(e, t) {
  var r = Ls(e);
  r.value === (r.value = // treat null and undefined the same for the initial value
  t ?? void 0) || // @ts-expect-error
  // `progress` elements always need their value set when it's `0`
  e.value === t && (t !== 0 || e.nodeName !== "PROGRESS") || (e.value = t ?? "");
}
function eu(e, t) {
  t ? e.hasAttribute("selected") || e.setAttribute("selected", "") : e.removeAttribute("selected");
}
function gn(e, t, r, n) {
  var i = Ls(e);
  i[t] !== (i[t] = r) && (t === "loading" && (e[Ml] = r), r == null ? e.removeAttribute(t) : typeof r != "string" && Do(e).includes(t) ? e[t] = r : e.setAttribute(t, r));
}
function tu(e, t, r, n, i = !1, s = !1) {
  var a = Ls(e), u = a[Lo], l = !a[Vo], c = t || {}, f = e.tagName === "OPTION";
  for (var h in t)
    h in r || (r[h] = null);
  r.class ? r.class = Io(r.class) : r[xn] && (r.class = null), r[kn] && (r.style ?? (r.style = null));
  var g = Do(e);
  for (const E in r) {
    let x = r[E];
    if (f && E === "value" && x == null) {
      e.value = e.__value = "", c[E] = x;
      continue;
    }
    if (E === "class") {
      var m = e.namespaceURI === "http://www.w3.org/1999/xhtml";
      wt(e, m, x, n, t == null ? void 0 : t[xn], r[xn]), c[E] = x, c[xn] = r[xn];
      continue;
    }
    if (E === "style") {
      Zc(e, x, t == null ? void 0 : t[kn], r[kn]), c[E] = x, c[kn] = r[kn];
      continue;
    }
    var d = c[E];
    if (!(x === d && !(x === void 0 && e.hasAttribute(E)))) {
      c[E] = x;
      var p = E[0] + E[1];
      if (p !== "$$")
        if (p === "on") {
          const M = {}, P = "$$" + E;
          let j = E.slice(2);
          var b = Fc(j);
          if (jc(j) && (j = j.slice(0, -7), M.capture = !0), !b && d) {
            if (x != null) continue;
            e.removeEventListener(j, c[P], M), c[P] = null;
          }
          if (x != null)
            if (b)
              e[`__${j}`] = x, zi([j]);
            else {
              let N = function(I) {
                c[E].call(this, I);
              };
              c[P] = Fs(j, e, N, M);
            }
          else b && (e[`__${j}`] = void 0);
        } else if (E === "style")
          gn(e, E, x);
        else if (E === "autofocus")
          xc(
            /** @type {HTMLElement} */
            e,
            !!x
          );
        else if (!u && (E === "__value" || E === "value" && x != null))
          e.value = e.__value = x;
        else if (E === "selected" && f)
          eu(
            /** @type {HTMLOptionElement} */
            e,
            x
          );
        else {
          var C = E;
          l || (C = Lc(C));
          var O = C === "defaultValue" || C === "defaultChecked";
          if (x == null && !u && !O)
            if (a[E] = null, C === "value" || C === "checked") {
              let M = (
                /** @type {HTMLInputElement} */
                e
              );
              const P = t === void 0;
              if (C === "value") {
                let j = M.defaultValue;
                M.removeAttribute(C), M.defaultValue = j, M.value = M.__value = P ? j : null;
              } else {
                let j = M.defaultChecked;
                M.removeAttribute(C), M.defaultChecked = j, M.checked = P ? j : !1;
              }
            } else
              e.removeAttribute(E);
          else O || g.includes(C) && (u || typeof x != "string") ? (e[C] = x, C in a && (a[C] = He)) : typeof x != "function" && gn(e, C, x);
        }
    }
  }
  return c;
}
function gt(e, t, r = [], n = [], i = [], s, a = !1, u = !1) {
  io(i, r, n, (l) => {
    var c = void 0, f = {}, h = e.nodeName === "SELECT", g = !1;
    if (Er(() => {
      var d = t(...l.map(o)), p = tu(
        e,
        c,
        d,
        s,
        a,
        u
      );
      g && h && "value" in d && ns(
        /** @type {HTMLSelectElement} */
        e,
        d.value
      );
      for (let C of Object.getOwnPropertySymbols(f))
        d[C] || Je(f[C]);
      for (let C of Object.getOwnPropertySymbols(d)) {
        var b = d[C];
        C.description === Ya && (!c || b !== c[C]) && (f[C] && Je(f[C]), f[C] = xt(() => Hc(e, () => b))), p[C] = b;
      }
      c = p;
    }), h) {
      var m = (
        /** @type {HTMLSelectElement} */
        e
      );
      Rs(() => {
        ns(
          m,
          /** @type {Record<string | symbol, any>} */
          c.value,
          !0
        ), Qc(m);
      });
    }
    g = !0;
  });
}
function Ls(e) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    e.__attributes ?? (e.__attributes = {
      [Lo]: e.nodeName.includes("-"),
      [Vo]: e.namespaceURI === Zl
    })
  );
}
var Sa = /* @__PURE__ */ new Map();
function Do(e) {
  var t = e.getAttribute("is") || e.nodeName, r = Sa.get(t);
  if (r) return r;
  Sa.set(t, r = []);
  for (var n, i = e, s = Element.prototype; s !== i; ) {
    n = Al(i);
    for (var a in n)
      n[a].set && r.push(a);
    i = Wa(i);
  }
  return r;
}
function Aa(e, t) {
  return e === t || (e == null ? void 0 : e[kr]) === t;
}
function Br(e = {}, t, r, n) {
  return Rs(() => {
    var i, s;
    return mo(() => {
      i = s, s = [], vn(() => {
        e !== r(...s) && (t(e, ...s), i && Aa(r(...i), e) && t(null, ...i));
      });
    }), () => {
      Vr(() => {
        s && Aa(r(...s), e) && t(null, ...s);
      });
    };
  }), e;
}
let Zn = !1;
function ru(e) {
  var t = Zn;
  try {
    return Zn = !1, [e(), Zn];
  } finally {
    Zn = t;
  }
}
const nu = {
  get(e, t) {
    if (!e.exclude.includes(t))
      return e.props[t];
  },
  set(e, t) {
    return !1;
  },
  getOwnPropertyDescriptor(e, t) {
    if (!e.exclude.includes(t) && t in e.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: e.props[t]
      };
  },
  has(e, t) {
    return e.exclude.includes(t) ? !1 : t in e.props;
  },
  ownKeys(e) {
    return Reflect.ownKeys(e.props).filter((t) => !e.exclude.includes(t));
  }
};
// @__NO_SIDE_EFFECTS__
function De(e, t, r) {
  return new Proxy(
    { props: e, exclude: t },
    nu
  );
}
const iu = {
  get(e, t) {
    let r = e.props.length;
    for (; r--; ) {
      let n = e.props[r];
      if (wn(n) && (n = n()), typeof n == "object" && n !== null && t in n) return n[t];
    }
  },
  set(e, t, r) {
    let n = e.props.length;
    for (; n--; ) {
      let i = e.props[n];
      wn(i) && (i = i());
      const s = xr(i, t);
      if (s && s.set)
        return s.set(r), !0;
    }
    return !1;
  },
  getOwnPropertyDescriptor(e, t) {
    let r = e.props.length;
    for (; r--; ) {
      let n = e.props[r];
      if (wn(n) && (n = n()), typeof n == "object" && n !== null && t in n) {
        const i = xr(n, t);
        return i && !i.configurable && (i.configurable = !0), i;
      }
    }
  },
  has(e, t) {
    if (t === kr || t === Ka) return !1;
    for (let r of e.props)
      if (wn(r) && (r = r()), r != null && t in r) return !0;
    return !1;
  },
  ownKeys(e) {
    const t = [];
    for (let r of e.props)
      if (wn(r) && (r = r()), !!r) {
        for (const n in r)
          t.includes(n) || t.push(n);
        for (const n of Object.getOwnPropertySymbols(r))
          t.includes(n) || t.push(n);
      }
    return t;
  }
};
function Gr(...e) {
  return new Proxy({ props: e }, iu);
}
function Y(e, t, r, n) {
  var O;
  var i = (r & Kl) !== 0, s = (r & Hl) !== 0, a = (
    /** @type {V} */
    n
  ), u = !0, l = () => (u && (u = !1, a = s ? vn(
    /** @type {() => V} */
    n
  ) : (
    /** @type {V} */
    n
  )), a), c;
  if (i) {
    var f = kr in e || Ka in e;
    c = ((O = xr(e, t)) == null ? void 0 : O.set) ?? (f && t in e ? (E) => e[t] = E : void 0);
  }
  var h, g = !1;
  i ? [h, g] = ru(() => (
    /** @type {V} */
    e[t]
  )) : h = /** @type {V} */
  e[t], h === void 0 && n !== void 0 && (h = l(), c && (Ll(), c(h)));
  var m;
  if (m = () => {
    var E = (
      /** @type {V} */
      e[t]
    );
    return E === void 0 ? l() : (u = !0, E);
  }, !(r & ql))
    return m;
  if (c) {
    var d = e.$$legacy;
    return (
      /** @type {() => V} */
      function(E, x) {
        return arguments.length > 0 ? ((!x || d || g) && c(x ? m() : E), E) : m();
      }
    );
  }
  var p = !1, b = (r & Jl ? Pi : so)(() => (p = !1, m()));
  i && o(b);
  var C = (
    /** @type {Effect} */
    ve
  );
  return (
    /** @type {() => V} */
    function(E, x) {
      if (arguments.length > 0) {
        const M = x ? o(b) : i ? Fe(E) : E;
        return k(b, M), p = !0, a !== void 0 && (a = M), E;
      }
      return Dr && p || C.f & ar ? b.v : o(b);
    }
  );
}
var Jt, qt, tr, yi, Lt, Cn, ai;
const ra = class ra extends Map {
  /**
   * @param {Iterable<readonly [K, V]> | null | undefined} [value]
   */
  constructor(r) {
    super();
    H(this, Lt);
    /** @type {Map<K, Source<number>>} */
    H(this, Jt, /* @__PURE__ */ new Map());
    H(this, qt, /* @__PURE__ */ oe(0));
    H(this, tr, /* @__PURE__ */ oe(0));
    H(this, yi, or || -1);
    if (r) {
      for (var [n, i] of r)
        super.set(n, i);
      v(this, tr).v = super.size;
    }
  }
  /** @param {K} key */
  has(r) {
    var n = v(this, Jt), i = n.get(r);
    if (i === void 0) {
      var s = super.get(r);
      if (s !== void 0)
        i = be(this, Lt, Cn).call(this, 0), n.set(r, i);
      else
        return o(v(this, qt)), !1;
    }
    return o(i), !0;
  }
  /**
   * @param {(value: V, key: K, map: Map<K, V>) => void} callbackfn
   * @param {any} [this_arg]
   */
  forEach(r, n) {
    be(this, Lt, ai).call(this), super.forEach(r, n);
  }
  /** @param {K} key */
  get(r) {
    var n = v(this, Jt), i = n.get(r);
    if (i === void 0) {
      var s = super.get(r);
      if (s !== void 0)
        i = be(this, Lt, Cn).call(this, 0), n.set(r, i);
      else {
        o(v(this, qt));
        return;
      }
    }
    return o(i), super.get(r);
  }
  /**
   * @param {K} key
   * @param {V} value
   * */
  set(r, n) {
    var h;
    var i = v(this, Jt), s = i.get(r), a = super.get(r), u = super.set(r, n), l = v(this, qt);
    if (s === void 0)
      s = be(this, Lt, Cn).call(this, 0), i.set(r, s), k(v(this, tr), super.size), Kt(l);
    else if (a !== n) {
      Kt(s);
      var c = l.reactions === null ? null : new Set(l.reactions), f = c === null || !((h = s.reactions) != null && h.every(
        (g) => (
          /** @type {NonNullable<typeof v_reactions>} */
          c.has(g)
        )
      ));
      f && Kt(l);
    }
    return u;
  }
  /** @param {K} key */
  delete(r) {
    var n = v(this, Jt), i = n.get(r), s = super.delete(r);
    return i !== void 0 && (n.delete(r), k(v(this, tr), super.size), k(i, -1), Kt(v(this, qt))), s;
  }
  clear() {
    if (super.size !== 0) {
      super.clear();
      var r = v(this, Jt);
      k(v(this, tr), 0);
      for (var n of r.values())
        k(n, -1);
      Kt(v(this, qt)), r.clear();
    }
  }
  keys() {
    return o(v(this, qt)), super.keys();
  }
  values() {
    return be(this, Lt, ai).call(this), super.values();
  }
  entries() {
    return be(this, Lt, ai).call(this), super.entries();
  }
  [Symbol.iterator]() {
    return this.entries();
  }
  get size() {
    return o(v(this, tr)), super.size;
  }
};
Jt = new WeakMap(), qt = new WeakMap(), tr = new WeakMap(), yi = new WeakMap(), Lt = new WeakSet(), /**
 * If the source is being created inside the same reaction as the SvelteMap instance,
 * we use `state` so that it will not be a dependency of the reaction. Otherwise we
 * use `source` so it will be.
 *
 * @template T
 * @param {T} value
 * @returns {Source<T>}
 */
Cn = function(r) {
  return or === v(this, yi) ? /* @__PURE__ */ oe(r) : Ar(r);
}, ai = function() {
  o(v(this, qt));
  var r = v(this, Jt);
  if (v(this, tr).v !== r.size) {
    for (var n of la(ra.prototype, this, "keys").call(this))
      if (!r.has(n)) {
        var i = be(this, Lt, Cn).call(this, 0);
        r.set(n, i);
      }
  }
  for ([, i] of v(this, Jt))
    o(i);
};
let hi = ra;
function su(e) {
  let t = {};
  return new Proxy(
    /** @type{any} */
    {},
    {
      get(r, n) {
        return n in t || (t[n] = zs((i) => (e.on(`change:${n}`, i), () => e.off(`change:${n}`, i)))), t[n](), e.get(n);
      },
      set(r, n, i) {
        return e.set(n, i), e.save_changes(), !0;
      }
    }
  );
}
function au(e) {
  return () => {
    let t;
    return {
      initialize({ model: r }) {
        t = su(r);
      },
      /** @type {import("@anywidget/types").Render<T>} */
      render({ model: r, el: n }) {
        let i = Uc(e, {
          target: n,
          props: { model: r, bindings: t }
        });
        return () => Jc(i);
      }
    };
  };
}
const ou = "5";
var Ua;
typeof window < "u" && ((Ua = window.__svelte ?? (window.__svelte = {})).v ?? (Ua.v = /* @__PURE__ */ new Set())).add(ou);
function lu(e) {
  return typeof e == "function";
}
function cu(e) {
  return e !== null && typeof e == "object";
}
const uu = ["string", "number", "bigint", "boolean"];
function is(e) {
  return e == null || uu.includes(typeof e) ? !0 : Array.isArray(e) ? e.every((t) => is(t)) : typeof e == "object" ? Object.getPrototypeOf(e) === Object.prototype : !1;
}
const pn = Symbol("box"), Ri = Symbol("is-writable");
function We(e, t) {
  const r = /* @__PURE__ */ U(e);
  return t ? {
    [pn]: !0,
    [Ri]: !0,
    get current() {
      return o(r);
    },
    set current(n) {
      t(n);
    }
  } : {
    [pn]: !0,
    get current() {
      return e();
    }
  };
}
function qn(e) {
  return cu(e) && pn in e;
}
function Vs(e) {
  return qn(e) && Ri in e;
}
function fu(e) {
  return qn(e) ? e : lu(e) ? We(e) : hu(e);
}
function du(e) {
  return Object.entries(e).reduce(
    (t, [r, n]) => qn(n) ? (Vs(n) ? Object.defineProperty(t, r, {
      get() {
        return n.current;
      },
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      set(i) {
        n.current = i;
      }
    }) : Object.defineProperty(t, r, {
      get() {
        return n.current;
      }
    }), t) : Object.assign(t, { [r]: n }),
    {}
  );
}
function vu(e) {
  return Vs(e) ? {
    [pn]: !0,
    get current() {
      return e.current;
    }
  } : e;
}
function hu(e) {
  let t = /* @__PURE__ */ oe(Fe(e));
  return {
    [pn]: !0,
    [Ri]: !0,
    get current() {
      return o(t);
    },
    set current(r) {
      k(t, r, !0);
    }
  };
}
function Ur(e) {
  let t = /* @__PURE__ */ oe(Fe(e));
  return {
    [pn]: !0,
    [Ri]: !0,
    get current() {
      return o(t);
    },
    set current(r) {
      k(t, r, !0);
    }
  };
}
Ur.from = fu;
Ur.with = We;
Ur.flatten = du;
Ur.readonly = vu;
Ur.isBox = qn;
Ur.isWritableBox = Vs;
function gu(...e) {
  return function(t) {
    var r;
    for (const n of e)
      if (n) {
        if (t.defaultPrevented)
          return;
        typeof n == "function" ? n.call(this, t) : (r = n.current) == null || r.call(this, t);
      }
  };
}
var Ca = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//g, pu = /\n/g, mu = /^\s*/, bu = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/, _u = /^:\s*/, yu = /^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/, wu = /^[;\s]*/, xu = /^\s+|\s+$/g, ku = `
`, Ea = "/", Pa = "*", zr = "", Su = "comment", Au = "declaration";
function Cu(e, t) {
  if (typeof e != "string")
    throw new TypeError("First argument must be a string");
  if (!e) return [];
  t = t || {};
  var r = 1, n = 1;
  function i(d) {
    var p = d.match(pu);
    p && (r += p.length);
    var b = d.lastIndexOf(ku);
    n = ~b ? d.length - b : n + d.length;
  }
  function s() {
    var d = { line: r, column: n };
    return function(p) {
      return p.position = new a(d), c(), p;
    };
  }
  function a(d) {
    this.start = d, this.end = { line: r, column: n }, this.source = t.source;
  }
  a.prototype.content = e;
  function u(d) {
    var p = new Error(
      t.source + ":" + r + ":" + n + ": " + d
    );
    if (p.reason = d, p.filename = t.source, p.line = r, p.column = n, p.source = e, !t.silent) throw p;
  }
  function l(d) {
    var p = d.exec(e);
    if (p) {
      var b = p[0];
      return i(b), e = e.slice(b.length), p;
    }
  }
  function c() {
    l(mu);
  }
  function f(d) {
    var p;
    for (d = d || []; p = h(); )
      p !== !1 && d.push(p);
    return d;
  }
  function h() {
    var d = s();
    if (!(Ea != e.charAt(0) || Pa != e.charAt(1))) {
      for (var p = 2; zr != e.charAt(p) && (Pa != e.charAt(p) || Ea != e.charAt(p + 1)); )
        ++p;
      if (p += 2, zr === e.charAt(p - 1))
        return u("End of comment missing");
      var b = e.slice(2, p - 2);
      return n += 2, i(b), e = e.slice(p), n += 2, d({
        type: Su,
        comment: b
      });
    }
  }
  function g() {
    var d = s(), p = l(bu);
    if (p) {
      if (h(), !l(_u)) return u("property missing ':'");
      var b = l(yu), C = d({
        type: Au,
        property: Ta(p[0].replace(Ca, zr)),
        value: b ? Ta(b[0].replace(Ca, zr)) : zr
      });
      return l(wu), C;
    }
  }
  function m() {
    var d = [];
    f(d);
    for (var p; p = g(); )
      p !== !1 && (d.push(p), f(d));
    return d;
  }
  return c(), m();
}
function Ta(e) {
  return e ? e.replace(xu, zr) : zr;
}
function Eu(e, t) {
  let r = null;
  if (!e || typeof e != "string")
    return r;
  const n = Cu(e), i = typeof t == "function";
  return n.forEach((s) => {
    if (s.type !== "declaration")
      return;
    const { property: a, value: u } = s;
    i ? t(a, u, s) : u && (r = r || {}, r[a] = u);
  }), r;
}
const Pu = /\d/, Tu = ["-", "_", "/", "."];
function zu(e = "") {
  if (!Pu.test(e))
    return e !== e.toLowerCase();
}
function Mu(e) {
  const t = [];
  let r = "", n, i;
  for (const s of e) {
    const a = Tu.includes(s);
    if (a === !0) {
      t.push(r), r = "", n = void 0;
      continue;
    }
    const u = zu(s);
    if (i === !1) {
      if (n === !1 && u === !0) {
        t.push(r), r = s, n = u;
        continue;
      }
      if (n === !0 && u === !1 && r.length > 1) {
        const l = r.at(-1);
        t.push(r.slice(0, Math.max(0, r.length - 1))), r = l + s, n = u;
        continue;
      }
    }
    r += s, n = u, i = a;
  }
  return t.push(r), t;
}
function Bo(e) {
  return e ? Mu(e).map((t) => Ru(t)).join("") : "";
}
function Nu(e) {
  return ju(Bo(e || ""));
}
function Ru(e) {
  return e ? e[0].toUpperCase() + e.slice(1) : "";
}
function ju(e) {
  return e ? e[0].toLowerCase() + e.slice(1) : "";
}
function Qn(e) {
  if (!e)
    return {};
  const t = {};
  function r(n, i) {
    if (n.startsWith("-moz-") || n.startsWith("-webkit-") || n.startsWith("-ms-") || n.startsWith("-o-")) {
      t[Bo(n)] = i;
      return;
    }
    if (n.startsWith("--")) {
      t[n] = i;
      return;
    }
    t[Nu(n)] = i;
  }
  return Eu(e, r), t;
}
function Ou(...e) {
  return (...t) => {
    for (const r of e)
      typeof r == "function" && r(...t);
  };
}
function Fu(e, t) {
  const r = RegExp(e, "g");
  return (n) => {
    if (typeof n != "string")
      throw new TypeError(`expected an argument of type string, but got ${typeof n}`);
    return n.match(r) ? n.replace(r, t) : n;
  };
}
const Iu = Fu(/[A-Z]/, (e) => `-${e.toLowerCase()}`);
function Lu(e) {
  if (!e || typeof e != "object" || Array.isArray(e))
    throw new TypeError(`expected an argument of type object, but got ${typeof e}`);
  return Object.keys(e).map((t) => `${Iu(t)}: ${e[t]};`).join(`
`);
}
function Vu(e = {}) {
  return Lu(e).replace(`
`, " ");
}
const Du = [
  "onabort",
  "onanimationcancel",
  "onanimationend",
  "onanimationiteration",
  "onanimationstart",
  "onauxclick",
  "onbeforeinput",
  "onbeforetoggle",
  "onblur",
  "oncancel",
  "oncanplay",
  "oncanplaythrough",
  "onchange",
  "onclick",
  "onclose",
  "oncompositionend",
  "oncompositionstart",
  "oncompositionupdate",
  "oncontextlost",
  "oncontextmenu",
  "oncontextrestored",
  "oncopy",
  "oncuechange",
  "oncut",
  "ondblclick",
  "ondrag",
  "ondragend",
  "ondragenter",
  "ondragleave",
  "ondragover",
  "ondragstart",
  "ondrop",
  "ondurationchange",
  "onemptied",
  "onended",
  "onerror",
  "onfocus",
  "onfocusin",
  "onfocusout",
  "onformdata",
  "ongotpointercapture",
  "oninput",
  "oninvalid",
  "onkeydown",
  "onkeypress",
  "onkeyup",
  "onload",
  "onloadeddata",
  "onloadedmetadata",
  "onloadstart",
  "onlostpointercapture",
  "onmousedown",
  "onmouseenter",
  "onmouseleave",
  "onmousemove",
  "onmouseout",
  "onmouseover",
  "onmouseup",
  "onpaste",
  "onpause",
  "onplay",
  "onplaying",
  "onpointercancel",
  "onpointerdown",
  "onpointerenter",
  "onpointerleave",
  "onpointermove",
  "onpointerout",
  "onpointerover",
  "onpointerup",
  "onprogress",
  "onratechange",
  "onreset",
  "onresize",
  "onscroll",
  "onscrollend",
  "onsecuritypolicyviolation",
  "onseeked",
  "onseeking",
  "onselect",
  "onselectionchange",
  "onselectstart",
  "onslotchange",
  "onstalled",
  "onsubmit",
  "onsuspend",
  "ontimeupdate",
  "ontoggle",
  "ontouchcancel",
  "ontouchend",
  "ontouchmove",
  "ontouchstart",
  "ontransitioncancel",
  "ontransitionend",
  "ontransitionrun",
  "ontransitionstart",
  "onvolumechange",
  "onwaiting",
  "onwebkitanimationend",
  "onwebkitanimationiteration",
  "onwebkitanimationstart",
  "onwebkittransitionend",
  "onwheel"
], Bu = new Set(Du);
function Gu(e) {
  return Bu.has(e);
}
function ji(...e) {
  const t = { ...e[0] };
  for (let r = 1; r < e.length; r++) {
    const n = e[r];
    if (n) {
      for (const i of Object.keys(n)) {
        const s = t[i], a = n[i], u = typeof s == "function", l = typeof a == "function";
        if (u && Gu(i)) {
          const c = s, f = a;
          t[i] = gu(c, f);
        } else if (u && l)
          t[i] = Ou(s, a);
        else if (i === "class") {
          const c = is(s), f = is(a);
          c && f ? t[i] = Qr(s, a) : c ? t[i] = Qr(s) : f && (t[i] = Qr(a));
        } else if (i === "style") {
          const c = typeof s == "object", f = typeof a == "object", h = typeof s == "string", g = typeof a == "string";
          if (c && f)
            t[i] = { ...s, ...a };
          else if (c && g) {
            const m = Qn(a);
            t[i] = { ...s, ...m };
          } else if (h && f) {
            const m = Qn(s);
            t[i] = { ...m, ...a };
          } else if (h && g) {
            const m = Qn(s), d = Qn(a);
            t[i] = { ...m, ...d };
          } else c ? t[i] = s : f ? t[i] = a : h ? t[i] = s : g && (t[i] = a);
        } else
          t[i] = a !== void 0 ? a : s;
      }
      for (const i of Object.getOwnPropertySymbols(n)) {
        const s = t[i], a = n[i];
        t[i] = a !== void 0 ? a : s;
      }
    }
  }
  return typeof t.style == "object" && (t.style = Vu(t.style).replaceAll(`
`, " ")), t.hidden === !1 && (t.hidden = void 0, delete t.hidden), t.disabled === !1 && (t.disabled = void 0, delete t.disabled), t;
}
const Uu = typeof window < "u" ? window : void 0;
function Wu(e) {
  let t = e.activeElement;
  for (; t != null && t.shadowRoot; ) {
    const r = t.shadowRoot.activeElement;
    if (r === t)
      break;
    t = r;
  }
  return t;
}
var nn, On;
class Ju {
  constructor(t = {}) {
    H(this, nn);
    H(this, On);
    const { window: r = Uu, document: n = r == null ? void 0 : r.document } = t;
    r !== void 0 && (te(this, nn, n), te(this, On, zs((i) => {
      const s = ba(r, "focusin", i), a = ba(r, "focusout", i);
      return () => {
        s(), a();
      };
    })));
  }
  get current() {
    var t;
    return (t = v(this, On)) == null || t.call(this), v(this, nn) ? Wu(v(this, nn)) : null;
  }
}
nn = new WeakMap(), On = new WeakMap();
new Ju();
var Fn, rr;
class qu {
  /**
   * @param name The name of the context.
   * This is used for generating the context key and error messages.
   */
  constructor(t) {
    H(this, Fn);
    H(this, rr);
    te(this, Fn, t), te(this, rr, Symbol(t));
  }
  /**
   * The key used to get and set the context.
   *
   * It is not recommended to use this value directly.
   * Instead, use the methods provided by this class.
   */
  get key() {
    return v(this, rr);
  }
  /**
   * Checks whether this has been set in the context of a parent component.
   *
   * Must be called during component initialisation.
   */
  exists() {
    return ic(v(this, rr));
  }
  /**
   * Retrieves the context that belongs to the closest parent component.
   *
   * Must be called during component initialisation.
   *
   * @throws An error if the context does not exist.
   */
  get() {
    const t = fa(v(this, rr));
    if (t === void 0)
      throw new Error(`Context "${v(this, Fn)}" not found`);
    return t;
  }
  /**
   * Retrieves the context that belongs to the closest parent component,
   * or the given fallback value if the context does not exist.
   *
   * Must be called during component initialisation.
   */
  getOr(t) {
    const r = fa(v(this, rr));
    return r === void 0 ? t : r;
  }
  /**
   * Associates the given value with the current component and returns it.
   *
   * Must be called during component initialisation.
   */
  set(t) {
    return nc(v(this, rr), t);
  }
}
Fn = new WeakMap(), rr = new WeakMap();
function Ku(e, t) {
  switch (e) {
    case "post":
      Ye(t);
      break;
    case "pre":
      Ac(t);
      break;
  }
}
function Go(e, t, r, n = {}) {
  const { lazy: i = !1 } = n;
  let s = !i, a = Array.isArray(e) ? [] : void 0;
  Ku(t, () => {
    const u = Array.isArray(e) ? e.map((c) => c()) : e();
    if (!s) {
      s = !0, a = u;
      return;
    }
    const l = vn(() => r(u, a));
    return a = u, l;
  });
}
function Ds(e, t, r) {
  Go(e, "post", t, r);
}
function Hu(e, t, r) {
  Go(e, "pre", t, r);
}
Ds.pre = Hu;
function Oi(e, t) {
  return {
    [Rc()]: (r) => qn(e) ? (e.current = r, vn(() => t == null ? void 0 : t(r)), () => {
      "isConnected" in r && r.isConnected || (e.current = null);
    }) : (e(r), vn(() => t == null ? void 0 : t(r)), () => {
      "isConnected" in r && r.isConnected || e(null);
    })
  };
}
function Yu(e) {
  return e ? "true" : "false";
}
function Uo(e) {
  return e ? "" : void 0;
}
function Wo(e) {
  return e ? !0 : void 0;
}
var sn, In;
class Xu {
  constructor(t) {
    H(this, sn);
    H(this, In);
    Pe(this, "attrs");
    te(this, sn, t.getVariant ? t.getVariant() : null), te(this, In, v(this, sn) ? `data-${v(this, sn)}-` : `data-${t.component}-`), this.getAttr = this.getAttr.bind(this), this.selector = this.selector.bind(this), this.attrs = Object.fromEntries(t.parts.map((r) => [r, this.getAttr(r)]));
  }
  getAttr(t, r) {
    return r ? `data-${r}-${t}` : `${v(this, In)}${t}`;
  }
  selector(t, r) {
    return `[${this.getAttr(t, r)}]`;
  }
}
sn = new WeakMap(), In = new WeakMap();
function Zu(e) {
  const t = new Xu(e);
  return {
    ...t.attrs,
    selector: t.selector,
    getAttr: t.getAttr
  };
}
const ss = "ArrowDown", Bs = "ArrowLeft", Gs = "ArrowRight", as = "ArrowUp", Qu = "End", $u = "Enter", ef = "Home", tf = " ";
function rf(e) {
  return window.getComputedStyle(e).getPropertyValue("direction");
}
function nf(e = "ltr", t = "horizontal") {
  return {
    horizontal: e === "rtl" ? Bs : Gs,
    vertical: ss
  }[t];
}
function sf(e = "ltr", t = "horizontal") {
  return {
    horizontal: e === "rtl" ? Gs : Bs,
    vertical: as
  }[t];
}
function af(e = "ltr", t = "horizontal") {
  return ["ltr", "rtl"].includes(e) || (e = "ltr"), ["horizontal", "vertical"].includes(t) || (t = "horizontal"), {
    nextKey: nf(e, t),
    prevKey: sf(e, t)
  };
}
function of(e) {
  return e instanceof HTMLElement;
}
var et, nr;
class lf {
  constructor(t) {
    H(this, et);
    H(this, nr, Ur(null));
    te(this, et, t);
  }
  getCandidateNodes() {
    return v(this, et).rootNode.current ? v(this, et).candidateSelector ? Array.from(v(this, et).rootNode.current.querySelectorAll(v(this, et).candidateSelector)) : v(this, et).candidateAttr ? Array.from(v(this, et).rootNode.current.querySelectorAll(`[${v(this, et).candidateAttr}]:not([data-disabled])`)) : [] : [];
  }
  focusFirstCandidate() {
    var r;
    const t = this.getCandidateNodes();
    t.length && ((r = t[0]) == null || r.focus());
  }
  handleKeydown(t, r, n = !1) {
    var d, p;
    const i = v(this, et).rootNode.current;
    if (!i || !t)
      return;
    const s = this.getCandidateNodes();
    if (!s.length)
      return;
    const a = s.indexOf(t), u = rf(i), { nextKey: l, prevKey: c } = af(u, v(this, et).orientation.current), f = v(this, et).loop.current, h = {
      [l]: a + 1,
      [c]: a - 1,
      [ef]: 0,
      [Qu]: s.length - 1
    };
    if (n) {
      const b = l === ss ? Gs : ss, C = c === as ? Bs : as;
      h[b] = a + 1, h[C] = a - 1;
    }
    let g = h[r.key];
    if (g === void 0)
      return;
    r.preventDefault(), g < 0 && f ? g = s.length - 1 : g === s.length && f && (g = 0);
    const m = s[g];
    if (m)
      return m.focus(), v(this, nr).current = m.id, (p = (d = v(this, et)).onCandidateFocus) == null || p.call(d, m), m;
  }
  getTabIndex(t) {
    const r = this.getCandidateNodes(), n = v(this, nr).current !== null;
    return t && !n && r[0] === t ? (v(this, nr).current = t.id, 0) : (t == null ? void 0 : t.id) === v(this, nr).current ? 0 : -1;
  }
  setCurrentTabStopId(t) {
    v(this, nr).current = t;
  }
  focusCurrentTabStop() {
    var n;
    const t = v(this, nr).current;
    if (!t)
      return;
    const r = (n = v(this, et).rootNode.current) == null ? void 0 : n.querySelector(`#${t}`);
    !r || !of(r) || r.focus();
  }
}
et = new WeakMap(), nr = new WeakMap();
function cf() {
}
function Fi(e, t) {
  return `bits-${e}`;
}
globalThis.bitsIdCounter ?? (globalThis.bitsIdCounter = { current: 0 });
function uf(e = "bits") {
  return globalThis.bitsIdCounter.current++, `${e}-${globalThis.bitsIdCounter.current}`;
}
const Mn = Zu({
  component: "tabs",
  parts: ["root", "list", "trigger", "content"]
}), Ii = new qu("Tabs.Root");
var Ln, Vn;
const na = class na {
  constructor(t) {
    Pe(this, "opts");
    Pe(this, "attachment");
    Pe(this, "rovingFocusGroup");
    H(this, Ln, /* @__PURE__ */ oe(Fe([])));
    Pe(this, "valueToTriggerId", new hi());
    Pe(this, "valueToContentId", new hi());
    H(this, Vn, /* @__PURE__ */ U(() => ({
      id: this.opts.id.current,
      "data-orientation": this.opts.orientation.current,
      [Mn.root]: "",
      ...this.attachment
    })));
    this.opts = t, this.attachment = Oi(t.ref), this.rovingFocusGroup = new lf({
      candidateAttr: Mn.trigger,
      rootNode: this.opts.ref,
      loop: this.opts.loop,
      orientation: this.opts.orientation
    });
  }
  static create(t) {
    return Ii.set(new na(t));
  }
  get triggerIds() {
    return o(v(this, Ln));
  }
  set triggerIds(t) {
    k(v(this, Ln), t, !0);
  }
  registerTrigger(t, r) {
    return this.triggerIds.push(t), this.valueToTriggerId.set(r, t), () => {
      this.triggerIds = this.triggerIds.filter((n) => n !== t), this.valueToTriggerId.delete(r);
    };
  }
  registerContent(t, r) {
    return this.valueToContentId.set(r, t), () => {
      this.valueToContentId.delete(r);
    };
  }
  setValue(t) {
    this.opts.value.current = t;
  }
  get props() {
    return o(v(this, Vn));
  }
  set props(t) {
    k(v(this, Vn), t);
  }
};
Ln = new WeakMap(), Vn = new WeakMap();
let os = na;
var wi, Dn;
const ia = class ia {
  constructor(t, r) {
    Pe(this, "opts");
    Pe(this, "root");
    Pe(this, "attachment");
    H(this, wi, /* @__PURE__ */ U(() => this.root.opts.disabled.current));
    H(this, Dn, /* @__PURE__ */ U(() => ({
      id: this.opts.id.current,
      role: "tablist",
      "aria-orientation": this.root.opts.orientation.current,
      "data-orientation": this.root.opts.orientation.current,
      [Mn.list]: "",
      "data-disabled": Uo(o(v(this, wi))),
      ...this.attachment
    })));
    this.opts = t, this.root = r, this.attachment = Oi(t.ref);
  }
  static create(t) {
    return new ia(t, Ii.get());
  }
  get props() {
    return o(v(this, Dn));
  }
  set props(t) {
    k(v(this, Dn), t);
  }
};
wi = new WeakMap(), Dn = new WeakMap();
let ls = ia;
var an, on, yr, xi, ln, oi, Bn;
const sa = class sa {
  constructor(t, r) {
    H(this, ln);
    Pe(this, "opts");
    Pe(this, "root");
    Pe(this, "attachment");
    H(this, an, /* @__PURE__ */ oe(0));
    H(this, on, /* @__PURE__ */ U(() => this.root.opts.value.current === this.opts.value.current));
    H(this, yr, /* @__PURE__ */ U(() => this.opts.disabled.current || this.root.opts.disabled.current));
    H(this, xi, /* @__PURE__ */ U(() => this.root.valueToContentId.get(this.opts.value.current)));
    H(this, Bn, /* @__PURE__ */ U(() => ({
      id: this.opts.id.current,
      role: "tab",
      "data-state": Jo(o(v(this, on))),
      "data-value": this.opts.value.current,
      "data-orientation": this.root.opts.orientation.current,
      "data-disabled": Uo(o(v(this, yr))),
      "aria-selected": Yu(o(v(this, on))),
      "aria-controls": o(v(this, xi)),
      [Mn.trigger]: "",
      disabled: Wo(o(v(this, yr))),
      tabindex: o(v(this, an)),
      //
      onclick: this.onclick,
      onfocus: this.onfocus,
      onkeydown: this.onkeydown,
      ...this.attachment
    })));
    this.opts = t, this.root = r, this.attachment = Oi(t.ref), Ds([() => this.opts.id.current, () => this.opts.value.current], ([n, i]) => this.root.registerTrigger(n, i)), Ye(() => {
      this.root.triggerIds.length, o(v(this, on)) || !this.root.opts.value.current ? k(v(this, an), 0) : k(v(this, an), -1);
    }), this.onfocus = this.onfocus.bind(this), this.onclick = this.onclick.bind(this), this.onkeydown = this.onkeydown.bind(this);
  }
  static create(t) {
    return new sa(t, Ii.get());
  }
  onfocus(t) {
    this.root.opts.activationMode.current !== "automatic" || o(v(this, yr)) || be(this, ln, oi).call(this);
  }
  onclick(t) {
    o(v(this, yr)) || be(this, ln, oi).call(this);
  }
  onkeydown(t) {
    if (!o(v(this, yr))) {
      if (t.key === tf || t.key === $u) {
        t.preventDefault(), be(this, ln, oi).call(this);
        return;
      }
      this.root.rovingFocusGroup.handleKeydown(this.opts.ref.current, t);
    }
  }
  get props() {
    return o(v(this, Bn));
  }
  set props(t) {
    k(v(this, Bn), t);
  }
};
an = new WeakMap(), on = new WeakMap(), yr = new WeakMap(), xi = new WeakMap(), ln = new WeakSet(), oi = function() {
  this.root.opts.value.current !== this.opts.value.current && this.root.setValue(this.opts.value.current);
}, Bn = new WeakMap();
let cs = sa;
var Gn, ki, Un;
const aa = class aa {
  constructor(t, r) {
    Pe(this, "opts");
    Pe(this, "root");
    Pe(this, "attachment");
    H(this, Gn, /* @__PURE__ */ U(() => this.root.opts.value.current === this.opts.value.current));
    H(this, ki, /* @__PURE__ */ U(() => this.root.valueToTriggerId.get(this.opts.value.current)));
    H(this, Un, /* @__PURE__ */ U(() => ({
      id: this.opts.id.current,
      role: "tabpanel",
      hidden: Wo(!o(v(this, Gn))),
      tabindex: 0,
      "data-value": this.opts.value.current,
      "data-state": Jo(o(v(this, Gn))),
      "aria-labelledby": o(v(this, ki)),
      "data-orientation": this.root.opts.orientation.current,
      [Mn.content]: "",
      ...this.attachment
    })));
    this.opts = t, this.root = r, this.attachment = Oi(t.ref), Ds([() => this.opts.id.current, () => this.opts.value.current], ([n, i]) => this.root.registerContent(n, i));
  }
  static create(t) {
    return new aa(t, Ii.get());
  }
  get props() {
    return o(v(this, Un));
  }
  set props(t) {
    k(v(this, Un), t);
  }
};
Gn = new WeakMap(), ki = new WeakMap(), Un = new WeakMap();
let us = aa;
function Jo(e) {
  return e ? "active" : "inactive";
}
var ff = /* @__PURE__ */ W("<div><!></div>");
function df(e, t) {
  const r = Mi();
  Ae(t, !0);
  let n = Y(t, "id", 19, () => Fi(r)), i = Y(t, "ref", 15, null), s = Y(t, "value", 15, ""), a = Y(t, "onValueChange", 3, cf), u = Y(t, "orientation", 3, "horizontal"), l = Y(t, "loop", 3, !0), c = Y(t, "activationMode", 3, "automatic"), f = Y(t, "disabled", 3, !1), h = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "id",
    "ref",
    "value",
    "onValueChange",
    "orientation",
    "loop",
    "activationMode",
    "disabled",
    "children",
    "child"
  ]);
  const g = os.create({
    id: We(() => n()),
    value: We(() => s(), (O) => {
      s(O), a()(O);
    }),
    orientation: We(() => u()),
    loop: We(() => l()),
    activationMode: We(() => c()),
    disabled: We(() => f()),
    ref: We(() => i(), (O) => i(O))
  }), m = /* @__PURE__ */ U(() => ji(h, g.props));
  var d = _e(), p = $(d);
  {
    var b = (O) => {
      var E = _e(), x = $(E);
      Ve(x, () => t.child, () => ({ props: o(m) })), S(O, E);
    }, C = (O) => {
      var E = ff();
      gt(E, () => ({ ...o(m) }));
      var x = V(E);
      Ve(x, () => t.children ?? lt), S(O, E);
    };
    ee(p, (O) => {
      t.child ? O(b) : O(C, !1);
    });
  }
  S(e, d), Ce();
}
var vf = /* @__PURE__ */ W("<div><!></div>");
function hf(e, t) {
  const r = Mi();
  Ae(t, !0);
  let n = Y(t, "id", 19, () => Fi(r)), i = Y(t, "ref", 15, null), s = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "children",
    "child",
    "id",
    "ref",
    "value"
  ]);
  const a = us.create({
    value: We(() => t.value),
    id: We(() => n()),
    ref: We(() => i(), (g) => i(g))
  }), u = /* @__PURE__ */ U(() => ji(s, a.props));
  var l = _e(), c = $(l);
  {
    var f = (g) => {
      var m = _e(), d = $(m);
      Ve(d, () => t.child, () => ({ props: o(u) })), S(g, m);
    }, h = (g) => {
      var m = vf();
      gt(m, () => ({ ...o(u) }));
      var d = V(m);
      Ve(d, () => t.children ?? lt), S(g, m);
    };
    ee(c, (g) => {
      t.child ? g(f) : g(h, !1);
    });
  }
  S(e, l), Ce();
}
var gf = /* @__PURE__ */ W("<div><!></div>");
function pf(e, t) {
  const r = Mi();
  Ae(t, !0);
  let n = Y(t, "id", 19, () => Fi(r)), i = Y(t, "ref", 15, null), s = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "child",
    "children",
    "id",
    "ref"
  ]);
  const a = ls.create({
    id: We(() => n()),
    ref: We(() => i(), (g) => i(g))
  }), u = /* @__PURE__ */ U(() => ji(s, a.props));
  var l = _e(), c = $(l);
  {
    var f = (g) => {
      var m = _e(), d = $(m);
      Ve(d, () => t.child, () => ({ props: o(u) })), S(g, m);
    }, h = (g) => {
      var m = gf();
      gt(m, () => ({ ...o(u) }));
      var d = V(m);
      Ve(d, () => t.children ?? lt), S(g, m);
    };
    ee(c, (g) => {
      t.child ? g(f) : g(h, !1);
    });
  }
  S(e, l), Ce();
}
var mf = /* @__PURE__ */ W("<button><!></button>");
function bf(e, t) {
  const r = Mi();
  Ae(t, !0);
  let n = Y(t, "disabled", 3, !1), i = Y(t, "id", 19, () => Fi(r)), s = Y(t, "type", 3, "button"), a = Y(t, "ref", 15, null), u = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "child",
    "children",
    "disabled",
    "id",
    "type",
    "value",
    "ref"
  ]);
  const l = cs.create({
    id: We(() => i()),
    disabled: We(() => n() ?? !1),
    value: We(() => t.value),
    ref: We(() => a(), (d) => a(d))
  }), c = /* @__PURE__ */ U(() => ji(u, l.props, { type: s() }));
  var f = _e(), h = $(f);
  {
    var g = (d) => {
      var p = _e(), b = $(p);
      Ve(b, () => t.child, () => ({ props: o(c) })), S(d, p);
    }, m = (d) => {
      var p = mf();
      gt(p, () => ({ ...o(c) }));
      var b = V(p);
      Ve(b, () => t.children ?? lt), S(d, p);
    };
    ee(h, (d) => {
      t.child ? d(g) : d(m, !1);
    });
  }
  S(e, f), Ce();
}
const Us = "-", _f = (e) => {
  const t = wf(e), {
    conflictingClassGroups: r,
    conflictingClassGroupModifiers: n
  } = e;
  return {
    getClassGroupId: (a) => {
      const u = a.split(Us);
      return u[0] === "" && u.length !== 1 && u.shift(), qo(u, t) || yf(a);
    },
    getConflictingClassGroupIds: (a, u) => {
      const l = r[a] || [];
      return u && n[a] ? [...l, ...n[a]] : l;
    }
  };
}, qo = (e, t) => {
  var a;
  if (e.length === 0)
    return t.classGroupId;
  const r = e[0], n = t.nextPart.get(r), i = n ? qo(e.slice(1), n) : void 0;
  if (i)
    return i;
  if (t.validators.length === 0)
    return;
  const s = e.join(Us);
  return (a = t.validators.find(({
    validator: u
  }) => u(s))) == null ? void 0 : a.classGroupId;
}, za = /^\[(.+)\]$/, yf = (e) => {
  if (za.test(e)) {
    const t = za.exec(e)[1], r = t == null ? void 0 : t.substring(0, t.indexOf(":"));
    if (r)
      return "arbitrary.." + r;
  }
}, wf = (e) => {
  const {
    theme: t,
    classGroups: r
  } = e, n = {
    nextPart: /* @__PURE__ */ new Map(),
    validators: []
  };
  for (const i in r)
    fs(r[i], n, i, t);
  return n;
}, fs = (e, t, r, n) => {
  e.forEach((i) => {
    if (typeof i == "string") {
      const s = i === "" ? t : Ma(t, i);
      s.classGroupId = r;
      return;
    }
    if (typeof i == "function") {
      if (xf(i)) {
        fs(i(n), t, r, n);
        return;
      }
      t.validators.push({
        validator: i,
        classGroupId: r
      });
      return;
    }
    Object.entries(i).forEach(([s, a]) => {
      fs(a, Ma(t, s), r, n);
    });
  });
}, Ma = (e, t) => {
  let r = e;
  return t.split(Us).forEach((n) => {
    r.nextPart.has(n) || r.nextPart.set(n, {
      nextPart: /* @__PURE__ */ new Map(),
      validators: []
    }), r = r.nextPart.get(n);
  }), r;
}, xf = (e) => e.isThemeGetter, kf = (e) => {
  if (e < 1)
    return {
      get: () => {
      },
      set: () => {
      }
    };
  let t = 0, r = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
  const i = (s, a) => {
    r.set(s, a), t++, t > e && (t = 0, n = r, r = /* @__PURE__ */ new Map());
  };
  return {
    get(s) {
      let a = r.get(s);
      if (a !== void 0)
        return a;
      if ((a = n.get(s)) !== void 0)
        return i(s, a), a;
    },
    set(s, a) {
      r.has(s) ? r.set(s, a) : i(s, a);
    }
  };
}, ds = "!", vs = ":", Sf = vs.length, Af = (e) => {
  const {
    prefix: t,
    experimentalParseClassName: r
  } = e;
  let n = (i) => {
    const s = [];
    let a = 0, u = 0, l = 0, c;
    for (let d = 0; d < i.length; d++) {
      let p = i[d];
      if (a === 0 && u === 0) {
        if (p === vs) {
          s.push(i.slice(l, d)), l = d + Sf;
          continue;
        }
        if (p === "/") {
          c = d;
          continue;
        }
      }
      p === "[" ? a++ : p === "]" ? a-- : p === "(" ? u++ : p === ")" && u--;
    }
    const f = s.length === 0 ? i : i.substring(l), h = Cf(f), g = h !== f, m = c && c > l ? c - l : void 0;
    return {
      modifiers: s,
      hasImportantModifier: g,
      baseClassName: h,
      maybePostfixModifierPosition: m
    };
  };
  if (t) {
    const i = t + vs, s = n;
    n = (a) => a.startsWith(i) ? s(a.substring(i.length)) : {
      isExternal: !0,
      modifiers: [],
      hasImportantModifier: !1,
      baseClassName: a,
      maybePostfixModifierPosition: void 0
    };
  }
  if (r) {
    const i = n;
    n = (s) => r({
      className: s,
      parseClassName: i
    });
  }
  return n;
}, Cf = (e) => e.endsWith(ds) ? e.substring(0, e.length - 1) : e.startsWith(ds) ? e.substring(1) : e, Ef = (e) => {
  const t = Object.fromEntries(e.orderSensitiveModifiers.map((n) => [n, !0]));
  return (n) => {
    if (n.length <= 1)
      return n;
    const i = [];
    let s = [];
    return n.forEach((a) => {
      a[0] === "[" || t[a] ? (i.push(...s.sort(), a), s = []) : s.push(a);
    }), i.push(...s.sort()), i;
  };
}, Pf = (e) => ({
  cache: kf(e.cacheSize),
  parseClassName: Af(e),
  sortModifiers: Ef(e),
  ..._f(e)
}), Tf = /\s+/, zf = (e, t) => {
  const {
    parseClassName: r,
    getClassGroupId: n,
    getConflictingClassGroupIds: i,
    sortModifiers: s
  } = t, a = [], u = e.trim().split(Tf);
  let l = "";
  for (let c = u.length - 1; c >= 0; c -= 1) {
    const f = u[c], {
      isExternal: h,
      modifiers: g,
      hasImportantModifier: m,
      baseClassName: d,
      maybePostfixModifierPosition: p
    } = r(f);
    if (h) {
      l = f + (l.length > 0 ? " " + l : l);
      continue;
    }
    let b = !!p, C = n(b ? d.substring(0, p) : d);
    if (!C) {
      if (!b) {
        l = f + (l.length > 0 ? " " + l : l);
        continue;
      }
      if (C = n(d), !C) {
        l = f + (l.length > 0 ? " " + l : l);
        continue;
      }
      b = !1;
    }
    const O = s(g).join(":"), E = m ? O + ds : O, x = E + C;
    if (a.includes(x))
      continue;
    a.push(x);
    const M = i(C, b);
    for (let P = 0; P < M.length; ++P) {
      const j = M[P];
      a.push(E + j);
    }
    l = f + (l.length > 0 ? " " + l : l);
  }
  return l;
};
function Mf() {
  let e = 0, t, r, n = "";
  for (; e < arguments.length; )
    (t = arguments[e++]) && (r = Ko(t)) && (n && (n += " "), n += r);
  return n;
}
const Ko = (e) => {
  if (typeof e == "string")
    return e;
  let t, r = "";
  for (let n = 0; n < e.length; n++)
    e[n] && (t = Ko(e[n])) && (r && (r += " "), r += t);
  return r;
};
function hs(e, ...t) {
  let r, n, i, s = a;
  function a(l) {
    const c = t.reduce((f, h) => h(f), e());
    return r = Pf(c), n = r.cache.get, i = r.cache.set, s = u, u(l);
  }
  function u(l) {
    const c = n(l);
    if (c)
      return c;
    const f = zf(l, r);
    return i(l, f), f;
  }
  return function() {
    return s(Mf.apply(null, arguments));
  };
}
const Be = (e) => {
  const t = (r) => r[e] || [];
  return t.isThemeGetter = !0, t;
}, Ho = /^\[(?:(\w[\w-]*):)?(.+)\]$/i, Yo = /^\((?:(\w[\w-]*):)?(.+)\)$/i, Nf = /^\d+\/\d+$/, Rf = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/, jf = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/, Of = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/, Ff = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/, If = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/, Kr = (e) => Nf.test(e), ce = (e) => !!e && !Number.isNaN(Number(e)), gr = (e) => !!e && Number.isInteger(Number(e)), Ji = (e) => e.endsWith("%") && ce(e.slice(0, -1)), Qt = (e) => Rf.test(e), Lf = () => !0, Vf = (e) => (
  // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
  // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
  // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
  jf.test(e) && !Of.test(e)
), Xo = () => !1, Df = (e) => Ff.test(e), Bf = (e) => If.test(e), Gf = (e) => !J(e) && !q(e), Uf = (e) => bn(e, $o, Xo), J = (e) => Ho.test(e), Pr = (e) => bn(e, el, Vf), qi = (e) => bn(e, Hf, ce), Na = (e) => bn(e, Zo, Xo), Wf = (e) => bn(e, Qo, Bf), $n = (e) => bn(e, tl, Df), q = (e) => Yo.test(e), Sn = (e) => _n(e, el), Jf = (e) => _n(e, Yf), Ra = (e) => _n(e, Zo), qf = (e) => _n(e, $o), Kf = (e) => _n(e, Qo), ei = (e) => _n(e, tl, !0), bn = (e, t, r) => {
  const n = Ho.exec(e);
  return n ? n[1] ? t(n[1]) : r(n[2]) : !1;
}, _n = (e, t, r = !1) => {
  const n = Yo.exec(e);
  return n ? n[1] ? t(n[1]) : r : !1;
}, Zo = (e) => e === "position" || e === "percentage", Qo = (e) => e === "image" || e === "url", $o = (e) => e === "length" || e === "size" || e === "bg-size", el = (e) => e === "length", Hf = (e) => e === "number", Yf = (e) => e === "family-name", tl = (e) => e === "shadow", gs = () => {
  const e = Be("color"), t = Be("font"), r = Be("text"), n = Be("font-weight"), i = Be("tracking"), s = Be("leading"), a = Be("breakpoint"), u = Be("container"), l = Be("spacing"), c = Be("radius"), f = Be("shadow"), h = Be("inset-shadow"), g = Be("text-shadow"), m = Be("drop-shadow"), d = Be("blur"), p = Be("perspective"), b = Be("aspect"), C = Be("ease"), O = Be("animate"), E = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"], x = () => [
    "center",
    "top",
    "bottom",
    "left",
    "right",
    "top-left",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "left-top",
    "top-right",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "right-top",
    "bottom-right",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "right-bottom",
    "bottom-left",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "left-bottom"
  ], M = () => [...x(), q, J], P = () => ["auto", "hidden", "clip", "visible", "scroll"], j = () => ["auto", "contain", "none"], N = () => [q, J, l], I = () => [Kr, "full", "auto", ...N()], ne = () => [gr, "none", "subgrid", q, J], Z = () => ["auto", {
    span: ["full", gr, q, J]
  }, gr, q, J], ie = () => [gr, "auto", q, J], fe = () => ["auto", "min", "max", "fr", q, J], R = () => ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline", "center-safe", "end-safe"], _ = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"], w = () => ["auto", ...N()], A = () => [Kr, "auto", "full", "dvw", "dvh", "lvw", "lvh", "svw", "svh", "min", "max", "fit", ...N()], y = () => [e, q, J], z = () => [...x(), Ra, Na, {
    position: [q, J]
  }], F = () => ["no-repeat", {
    repeat: ["", "x", "y", "space", "round"]
  }], L = () => ["auto", "cover", "contain", qf, Uf, {
    size: [q, J]
  }], D = () => [Ji, Sn, Pr], G = () => [
    // Deprecated since Tailwind CSS v4.0.0
    "",
    "none",
    "full",
    c,
    q,
    J
  ], X = () => ["", ce, Sn, Pr], le = () => ["solid", "dashed", "dotted", "double"], ae = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"], se = () => [ce, Ji, Ra, Na], me = () => [
    // Deprecated since Tailwind CSS v4.0.0
    "",
    "none",
    d,
    q,
    J
  ], we = () => ["none", ce, q, J], xe = () => ["none", ce, q, J], Me = () => [ce, q, J], Qe = () => [Kr, "full", ...N()];
  return {
    cacheSize: 500,
    theme: {
      animate: ["spin", "ping", "pulse", "bounce"],
      aspect: ["video"],
      blur: [Qt],
      breakpoint: [Qt],
      color: [Lf],
      container: [Qt],
      "drop-shadow": [Qt],
      ease: ["in", "out", "in-out"],
      font: [Gf],
      "font-weight": ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"],
      "inset-shadow": [Qt],
      leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
      perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"],
      radius: [Qt],
      shadow: [Qt],
      spacing: ["px", ce],
      text: [Qt],
      "text-shadow": [Qt],
      tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"]
    },
    classGroups: {
      // --------------
      // --- Layout ---
      // --------------
      /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */
      aspect: [{
        aspect: ["auto", "square", Kr, J, q, b]
      }],
      /**
       * Container
       * @see https://tailwindcss.com/docs/container
       * @deprecated since Tailwind CSS v4.0.0
       */
      container: ["container"],
      /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */
      columns: [{
        columns: [ce, J, q, u]
      }],
      /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */
      "break-after": [{
        "break-after": E()
      }],
      /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */
      "break-before": [{
        "break-before": E()
      }],
      /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */
      "break-inside": [{
        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
      }],
      /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */
      "box-decoration": [{
        "box-decoration": ["slice", "clone"]
      }],
      /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */
      box: [{
        box: ["border", "content"]
      }],
      /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */
      display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
      /**
       * Screen Reader Only
       * @see https://tailwindcss.com/docs/display#screen-reader-only
       */
      sr: ["sr-only", "not-sr-only"],
      /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */
      float: [{
        float: ["right", "left", "none", "start", "end"]
      }],
      /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */
      clear: [{
        clear: ["left", "right", "both", "none", "start", "end"]
      }],
      /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */
      isolation: ["isolate", "isolation-auto"],
      /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */
      "object-fit": [{
        object: ["contain", "cover", "fill", "none", "scale-down"]
      }],
      /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */
      "object-position": [{
        object: M()
      }],
      /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */
      overflow: [{
        overflow: P()
      }],
      /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-x": [{
        "overflow-x": P()
      }],
      /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-y": [{
        "overflow-y": P()
      }],
      /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      overscroll: [{
        overscroll: j()
      }],
      /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-x": [{
        "overscroll-x": j()
      }],
      /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-y": [{
        "overscroll-y": j()
      }],
      /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */
      position: ["static", "fixed", "absolute", "relative", "sticky"],
      /**
       * Top / Right / Bottom / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      inset: [{
        inset: I()
      }],
      /**
       * Right / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-x": [{
        "inset-x": I()
      }],
      /**
       * Top / Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-y": [{
        "inset-y": I()
      }],
      /**
       * Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      start: [{
        start: I()
      }],
      /**
       * End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      end: [{
        end: I()
      }],
      /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      top: [{
        top: I()
      }],
      /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      right: [{
        right: I()
      }],
      /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      bottom: [{
        bottom: I()
      }],
      /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      left: [{
        left: I()
      }],
      /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */
      visibility: ["visible", "invisible", "collapse"],
      /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */
      z: [{
        z: [gr, "auto", q, J]
      }],
      // ------------------------
      // --- Flexbox and Grid ---
      // ------------------------
      /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */
      basis: [{
        basis: [Kr, "full", "auto", u, ...N()]
      }],
      /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */
      "flex-direction": [{
        flex: ["row", "row-reverse", "col", "col-reverse"]
      }],
      /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */
      "flex-wrap": [{
        flex: ["nowrap", "wrap", "wrap-reverse"]
      }],
      /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */
      flex: [{
        flex: [ce, Kr, "auto", "initial", "none", J]
      }],
      /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */
      grow: [{
        grow: ["", ce, q, J]
      }],
      /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */
      shrink: [{
        shrink: ["", ce, q, J]
      }],
      /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */
      order: [{
        order: [gr, "first", "last", "none", q, J]
      }],
      /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */
      "grid-cols": [{
        "grid-cols": ne()
      }],
      /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start-end": [{
        col: Z()
      }],
      /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start": [{
        "col-start": ie()
      }],
      /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-end": [{
        "col-end": ie()
      }],
      /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */
      "grid-rows": [{
        "grid-rows": ne()
      }],
      /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start-end": [{
        row: Z()
      }],
      /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start": [{
        "row-start": ie()
      }],
      /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-end": [{
        "row-end": ie()
      }],
      /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */
      "grid-flow": [{
        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
      }],
      /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */
      "auto-cols": [{
        "auto-cols": fe()
      }],
      /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */
      "auto-rows": [{
        "auto-rows": fe()
      }],
      /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */
      gap: [{
        gap: N()
      }],
      /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-x": [{
        "gap-x": N()
      }],
      /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-y": [{
        "gap-y": N()
      }],
      /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */
      "justify-content": [{
        justify: [...R(), "normal"]
      }],
      /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */
      "justify-items": [{
        "justify-items": [..._(), "normal"]
      }],
      /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */
      "justify-self": [{
        "justify-self": ["auto", ..._()]
      }],
      /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */
      "align-content": [{
        content: ["normal", ...R()]
      }],
      /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */
      "align-items": [{
        items: [..._(), {
          baseline: ["", "last"]
        }]
      }],
      /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */
      "align-self": [{
        self: ["auto", ..._(), {
          baseline: ["", "last"]
        }]
      }],
      /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */
      "place-content": [{
        "place-content": R()
      }],
      /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */
      "place-items": [{
        "place-items": [..._(), "baseline"]
      }],
      /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */
      "place-self": [{
        "place-self": ["auto", ..._()]
      }],
      // Spacing
      /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */
      p: [{
        p: N()
      }],
      /**
       * Padding X
       * @see https://tailwindcss.com/docs/padding
       */
      px: [{
        px: N()
      }],
      /**
       * Padding Y
       * @see https://tailwindcss.com/docs/padding
       */
      py: [{
        py: N()
      }],
      /**
       * Padding Start
       * @see https://tailwindcss.com/docs/padding
       */
      ps: [{
        ps: N()
      }],
      /**
       * Padding End
       * @see https://tailwindcss.com/docs/padding
       */
      pe: [{
        pe: N()
      }],
      /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */
      pt: [{
        pt: N()
      }],
      /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */
      pr: [{
        pr: N()
      }],
      /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */
      pb: [{
        pb: N()
      }],
      /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */
      pl: [{
        pl: N()
      }],
      /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */
      m: [{
        m: w()
      }],
      /**
       * Margin X
       * @see https://tailwindcss.com/docs/margin
       */
      mx: [{
        mx: w()
      }],
      /**
       * Margin Y
       * @see https://tailwindcss.com/docs/margin
       */
      my: [{
        my: w()
      }],
      /**
       * Margin Start
       * @see https://tailwindcss.com/docs/margin
       */
      ms: [{
        ms: w()
      }],
      /**
       * Margin End
       * @see https://tailwindcss.com/docs/margin
       */
      me: [{
        me: w()
      }],
      /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */
      mt: [{
        mt: w()
      }],
      /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */
      mr: [{
        mr: w()
      }],
      /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */
      mb: [{
        mb: w()
      }],
      /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */
      ml: [{
        ml: w()
      }],
      /**
       * Space Between X
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-x": [{
        "space-x": N()
      }],
      /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-x-reverse": ["space-x-reverse"],
      /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-y": [{
        "space-y": N()
      }],
      /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-y-reverse": ["space-y-reverse"],
      // --------------
      // --- Sizing ---
      // --------------
      /**
       * Size
       * @see https://tailwindcss.com/docs/width#setting-both-width-and-height
       */
      size: [{
        size: A()
      }],
      /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */
      w: [{
        w: [u, "screen", ...A()]
      }],
      /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-w": [{
        "min-w": [
          u,
          "screen",
          /** Deprecated. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          "none",
          ...A()
        ]
      }],
      /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-w": [{
        "max-w": [
          u,
          "screen",
          "none",
          /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          "prose",
          /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          {
            screen: [a]
          },
          ...A()
        ]
      }],
      /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */
      h: [{
        h: ["screen", "lh", ...A()]
      }],
      /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-h": [{
        "min-h": ["screen", "lh", "none", ...A()]
      }],
      /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-h": [{
        "max-h": ["screen", "lh", ...A()]
      }],
      // ------------------
      // --- Typography ---
      // ------------------
      /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */
      "font-size": [{
        text: ["base", r, Sn, Pr]
      }],
      /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */
      "font-smoothing": ["antialiased", "subpixel-antialiased"],
      /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */
      "font-style": ["italic", "not-italic"],
      /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */
      "font-weight": [{
        font: [n, q, qi]
      }],
      /**
       * Font Stretch
       * @see https://tailwindcss.com/docs/font-stretch
       */
      "font-stretch": [{
        "font-stretch": ["ultra-condensed", "extra-condensed", "condensed", "semi-condensed", "normal", "semi-expanded", "expanded", "extra-expanded", "ultra-expanded", Ji, J]
      }],
      /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */
      "font-family": [{
        font: [Jf, J, t]
      }],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-normal": ["normal-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-ordinal": ["ordinal"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-slashed-zero": ["slashed-zero"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-figure": ["lining-nums", "oldstyle-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-spacing": ["proportional-nums", "tabular-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
      /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */
      tracking: [{
        tracking: [i, q, J]
      }],
      /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */
      "line-clamp": [{
        "line-clamp": [ce, "none", q, qi]
      }],
      /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */
      leading: [{
        leading: [
          /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          s,
          ...N()
        ]
      }],
      /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */
      "list-image": [{
        "list-image": ["none", q, J]
      }],
      /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */
      "list-style-position": [{
        list: ["inside", "outside"]
      }],
      /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */
      "list-style-type": [{
        list: ["disc", "decimal", "none", q, J]
      }],
      /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */
      "text-alignment": [{
        text: ["left", "center", "right", "justify", "start", "end"]
      }],
      /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://v3.tailwindcss.com/docs/placeholder-color
       */
      "placeholder-color": [{
        placeholder: y()
      }],
      /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */
      "text-color": [{
        text: y()
      }],
      /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */
      "text-decoration": ["underline", "overline", "line-through", "no-underline"],
      /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */
      "text-decoration-style": [{
        decoration: [...le(), "wavy"]
      }],
      /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */
      "text-decoration-thickness": [{
        decoration: [ce, "from-font", "auto", q, Pr]
      }],
      /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */
      "text-decoration-color": [{
        decoration: y()
      }],
      /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */
      "underline-offset": [{
        "underline-offset": [ce, "auto", q, J]
      }],
      /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */
      "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
      /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */
      "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
      /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */
      "text-wrap": [{
        text: ["wrap", "nowrap", "balance", "pretty"]
      }],
      /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */
      indent: [{
        indent: N()
      }],
      /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */
      "vertical-align": [{
        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", q, J]
      }],
      /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */
      whitespace: [{
        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
      }],
      /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */
      break: [{
        break: ["normal", "words", "all", "keep"]
      }],
      /**
       * Overflow Wrap
       * @see https://tailwindcss.com/docs/overflow-wrap
       */
      wrap: [{
        wrap: ["break-word", "anywhere", "normal"]
      }],
      /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */
      hyphens: [{
        hyphens: ["none", "manual", "auto"]
      }],
      /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */
      content: [{
        content: ["none", q, J]
      }],
      // -------------------
      // --- Backgrounds ---
      // -------------------
      /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */
      "bg-attachment": [{
        bg: ["fixed", "local", "scroll"]
      }],
      /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */
      "bg-clip": [{
        "bg-clip": ["border", "padding", "content", "text"]
      }],
      /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */
      "bg-origin": [{
        "bg-origin": ["border", "padding", "content"]
      }],
      /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */
      "bg-position": [{
        bg: z()
      }],
      /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */
      "bg-repeat": [{
        bg: F()
      }],
      /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */
      "bg-size": [{
        bg: L()
      }],
      /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */
      "bg-image": [{
        bg: ["none", {
          linear: [{
            to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
          }, gr, q, J],
          radial: ["", q, J],
          conic: [gr, q, J]
        }, Kf, Wf]
      }],
      /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */
      "bg-color": [{
        bg: y()
      }],
      /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from-pos": [{
        from: D()
      }],
      /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via-pos": [{
        via: D()
      }],
      /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to-pos": [{
        to: D()
      }],
      /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from": [{
        from: y()
      }],
      /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via": [{
        via: y()
      }],
      /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to": [{
        to: y()
      }],
      // ---------------
      // --- Borders ---
      // ---------------
      /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */
      rounded: [{
        rounded: G()
      }],
      /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-s": [{
        "rounded-s": G()
      }],
      /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-e": [{
        "rounded-e": G()
      }],
      /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-t": [{
        "rounded-t": G()
      }],
      /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-r": [{
        "rounded-r": G()
      }],
      /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-b": [{
        "rounded-b": G()
      }],
      /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-l": [{
        "rounded-l": G()
      }],
      /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ss": [{
        "rounded-ss": G()
      }],
      /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-se": [{
        "rounded-se": G()
      }],
      /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ee": [{
        "rounded-ee": G()
      }],
      /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-es": [{
        "rounded-es": G()
      }],
      /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tl": [{
        "rounded-tl": G()
      }],
      /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tr": [{
        "rounded-tr": G()
      }],
      /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-br": [{
        "rounded-br": G()
      }],
      /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-bl": [{
        "rounded-bl": G()
      }],
      /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w": [{
        border: X()
      }],
      /**
       * Border Width X
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-x": [{
        "border-x": X()
      }],
      /**
       * Border Width Y
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-y": [{
        "border-y": X()
      }],
      /**
       * Border Width Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-s": [{
        "border-s": X()
      }],
      /**
       * Border Width End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-e": [{
        "border-e": X()
      }],
      /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-t": [{
        "border-t": X()
      }],
      /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-r": [{
        "border-r": X()
      }],
      /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-b": [{
        "border-b": X()
      }],
      /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-l": [{
        "border-l": X()
      }],
      /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-x": [{
        "divide-x": X()
      }],
      /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-x-reverse": ["divide-x-reverse"],
      /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-y": [{
        "divide-y": X()
      }],
      /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-y-reverse": ["divide-y-reverse"],
      /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */
      "border-style": [{
        border: [...le(), "hidden", "none"]
      }],
      /**
       * Divide Style
       * @see https://tailwindcss.com/docs/border-style#setting-the-divider-style
       */
      "divide-style": [{
        divide: [...le(), "hidden", "none"]
      }],
      /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color": [{
        border: y()
      }],
      /**
       * Border Color X
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-x": [{
        "border-x": y()
      }],
      /**
       * Border Color Y
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-y": [{
        "border-y": y()
      }],
      /**
       * Border Color S
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-s": [{
        "border-s": y()
      }],
      /**
       * Border Color E
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-e": [{
        "border-e": y()
      }],
      /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-t": [{
        "border-t": y()
      }],
      /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-r": [{
        "border-r": y()
      }],
      /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-b": [{
        "border-b": y()
      }],
      /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-l": [{
        "border-l": y()
      }],
      /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */
      "divide-color": [{
        divide: y()
      }],
      /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */
      "outline-style": [{
        outline: [...le(), "none", "hidden"]
      }],
      /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */
      "outline-offset": [{
        "outline-offset": [ce, q, J]
      }],
      /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */
      "outline-w": [{
        outline: ["", ce, Sn, Pr]
      }],
      /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */
      "outline-color": [{
        outline: y()
      }],
      // ---------------
      // --- Effects ---
      // ---------------
      /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */
      shadow: [{
        shadow: [
          // Deprecated since Tailwind CSS v4.0.0
          "",
          "none",
          f,
          ei,
          $n
        ]
      }],
      /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-shadow-color
       */
      "shadow-color": [{
        shadow: y()
      }],
      /**
       * Inset Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-shadow
       */
      "inset-shadow": [{
        "inset-shadow": ["none", h, ei, $n]
      }],
      /**
       * Inset Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-shadow-color
       */
      "inset-shadow-color": [{
        "inset-shadow": y()
      }],
      /**
       * Ring Width
       * @see https://tailwindcss.com/docs/box-shadow#adding-a-ring
       */
      "ring-w": [{
        ring: X()
      }],
      /**
       * Ring Width Inset
       * @see https://v3.tailwindcss.com/docs/ring-width#inset-rings
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */
      "ring-w-inset": ["ring-inset"],
      /**
       * Ring Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-ring-color
       */
      "ring-color": [{
        ring: y()
      }],
      /**
       * Ring Offset Width
       * @see https://v3.tailwindcss.com/docs/ring-offset-width
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */
      "ring-offset-w": [{
        "ring-offset": [ce, Pr]
      }],
      /**
       * Ring Offset Color
       * @see https://v3.tailwindcss.com/docs/ring-offset-color
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */
      "ring-offset-color": [{
        "ring-offset": y()
      }],
      /**
       * Inset Ring Width
       * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-ring
       */
      "inset-ring-w": [{
        "inset-ring": X()
      }],
      /**
       * Inset Ring Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-ring-color
       */
      "inset-ring-color": [{
        "inset-ring": y()
      }],
      /**
       * Text Shadow
       * @see https://tailwindcss.com/docs/text-shadow
       */
      "text-shadow": [{
        "text-shadow": ["none", g, ei, $n]
      }],
      /**
       * Text Shadow Color
       * @see https://tailwindcss.com/docs/text-shadow#setting-the-shadow-color
       */
      "text-shadow-color": [{
        "text-shadow": y()
      }],
      /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */
      opacity: [{
        opacity: [ce, q, J]
      }],
      /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */
      "mix-blend": [{
        "mix-blend": [...ae(), "plus-darker", "plus-lighter"]
      }],
      /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */
      "bg-blend": [{
        "bg-blend": ae()
      }],
      /**
       * Mask Clip
       * @see https://tailwindcss.com/docs/mask-clip
       */
      "mask-clip": [{
        "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"]
      }, "mask-no-clip"],
      /**
       * Mask Composite
       * @see https://tailwindcss.com/docs/mask-composite
       */
      "mask-composite": [{
        mask: ["add", "subtract", "intersect", "exclude"]
      }],
      /**
       * Mask Image
       * @see https://tailwindcss.com/docs/mask-image
       */
      "mask-image-linear-pos": [{
        "mask-linear": [ce]
      }],
      "mask-image-linear-from-pos": [{
        "mask-linear-from": se()
      }],
      "mask-image-linear-to-pos": [{
        "mask-linear-to": se()
      }],
      "mask-image-linear-from-color": [{
        "mask-linear-from": y()
      }],
      "mask-image-linear-to-color": [{
        "mask-linear-to": y()
      }],
      "mask-image-t-from-pos": [{
        "mask-t-from": se()
      }],
      "mask-image-t-to-pos": [{
        "mask-t-to": se()
      }],
      "mask-image-t-from-color": [{
        "mask-t-from": y()
      }],
      "mask-image-t-to-color": [{
        "mask-t-to": y()
      }],
      "mask-image-r-from-pos": [{
        "mask-r-from": se()
      }],
      "mask-image-r-to-pos": [{
        "mask-r-to": se()
      }],
      "mask-image-r-from-color": [{
        "mask-r-from": y()
      }],
      "mask-image-r-to-color": [{
        "mask-r-to": y()
      }],
      "mask-image-b-from-pos": [{
        "mask-b-from": se()
      }],
      "mask-image-b-to-pos": [{
        "mask-b-to": se()
      }],
      "mask-image-b-from-color": [{
        "mask-b-from": y()
      }],
      "mask-image-b-to-color": [{
        "mask-b-to": y()
      }],
      "mask-image-l-from-pos": [{
        "mask-l-from": se()
      }],
      "mask-image-l-to-pos": [{
        "mask-l-to": se()
      }],
      "mask-image-l-from-color": [{
        "mask-l-from": y()
      }],
      "mask-image-l-to-color": [{
        "mask-l-to": y()
      }],
      "mask-image-x-from-pos": [{
        "mask-x-from": se()
      }],
      "mask-image-x-to-pos": [{
        "mask-x-to": se()
      }],
      "mask-image-x-from-color": [{
        "mask-x-from": y()
      }],
      "mask-image-x-to-color": [{
        "mask-x-to": y()
      }],
      "mask-image-y-from-pos": [{
        "mask-y-from": se()
      }],
      "mask-image-y-to-pos": [{
        "mask-y-to": se()
      }],
      "mask-image-y-from-color": [{
        "mask-y-from": y()
      }],
      "mask-image-y-to-color": [{
        "mask-y-to": y()
      }],
      "mask-image-radial": [{
        "mask-radial": [q, J]
      }],
      "mask-image-radial-from-pos": [{
        "mask-radial-from": se()
      }],
      "mask-image-radial-to-pos": [{
        "mask-radial-to": se()
      }],
      "mask-image-radial-from-color": [{
        "mask-radial-from": y()
      }],
      "mask-image-radial-to-color": [{
        "mask-radial-to": y()
      }],
      "mask-image-radial-shape": [{
        "mask-radial": ["circle", "ellipse"]
      }],
      "mask-image-radial-size": [{
        "mask-radial": [{
          closest: ["side", "corner"],
          farthest: ["side", "corner"]
        }]
      }],
      "mask-image-radial-pos": [{
        "mask-radial-at": x()
      }],
      "mask-image-conic-pos": [{
        "mask-conic": [ce]
      }],
      "mask-image-conic-from-pos": [{
        "mask-conic-from": se()
      }],
      "mask-image-conic-to-pos": [{
        "mask-conic-to": se()
      }],
      "mask-image-conic-from-color": [{
        "mask-conic-from": y()
      }],
      "mask-image-conic-to-color": [{
        "mask-conic-to": y()
      }],
      /**
       * Mask Mode
       * @see https://tailwindcss.com/docs/mask-mode
       */
      "mask-mode": [{
        mask: ["alpha", "luminance", "match"]
      }],
      /**
       * Mask Origin
       * @see https://tailwindcss.com/docs/mask-origin
       */
      "mask-origin": [{
        "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"]
      }],
      /**
       * Mask Position
       * @see https://tailwindcss.com/docs/mask-position
       */
      "mask-position": [{
        mask: z()
      }],
      /**
       * Mask Repeat
       * @see https://tailwindcss.com/docs/mask-repeat
       */
      "mask-repeat": [{
        mask: F()
      }],
      /**
       * Mask Size
       * @see https://tailwindcss.com/docs/mask-size
       */
      "mask-size": [{
        mask: L()
      }],
      /**
       * Mask Type
       * @see https://tailwindcss.com/docs/mask-type
       */
      "mask-type": [{
        "mask-type": ["alpha", "luminance"]
      }],
      /**
       * Mask Image
       * @see https://tailwindcss.com/docs/mask-image
       */
      "mask-image": [{
        mask: ["none", q, J]
      }],
      // ---------------
      // --- Filters ---
      // ---------------
      /**
       * Filter
       * @see https://tailwindcss.com/docs/filter
       */
      filter: [{
        filter: [
          // Deprecated since Tailwind CSS v3.0.0
          "",
          "none",
          q,
          J
        ]
      }],
      /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */
      blur: [{
        blur: me()
      }],
      /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */
      brightness: [{
        brightness: [ce, q, J]
      }],
      /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */
      contrast: [{
        contrast: [ce, q, J]
      }],
      /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */
      "drop-shadow": [{
        "drop-shadow": [
          // Deprecated since Tailwind CSS v4.0.0
          "",
          "none",
          m,
          ei,
          $n
        ]
      }],
      /**
       * Drop Shadow Color
       * @see https://tailwindcss.com/docs/filter-drop-shadow#setting-the-shadow-color
       */
      "drop-shadow-color": [{
        "drop-shadow": y()
      }],
      /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */
      grayscale: [{
        grayscale: ["", ce, q, J]
      }],
      /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */
      "hue-rotate": [{
        "hue-rotate": [ce, q, J]
      }],
      /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */
      invert: [{
        invert: ["", ce, q, J]
      }],
      /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */
      saturate: [{
        saturate: [ce, q, J]
      }],
      /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */
      sepia: [{
        sepia: ["", ce, q, J]
      }],
      /**
       * Backdrop Filter
       * @see https://tailwindcss.com/docs/backdrop-filter
       */
      "backdrop-filter": [{
        "backdrop-filter": [
          // Deprecated since Tailwind CSS v3.0.0
          "",
          "none",
          q,
          J
        ]
      }],
      /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */
      "backdrop-blur": [{
        "backdrop-blur": me()
      }],
      /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */
      "backdrop-brightness": [{
        "backdrop-brightness": [ce, q, J]
      }],
      /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */
      "backdrop-contrast": [{
        "backdrop-contrast": [ce, q, J]
      }],
      /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */
      "backdrop-grayscale": [{
        "backdrop-grayscale": ["", ce, q, J]
      }],
      /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */
      "backdrop-hue-rotate": [{
        "backdrop-hue-rotate": [ce, q, J]
      }],
      /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */
      "backdrop-invert": [{
        "backdrop-invert": ["", ce, q, J]
      }],
      /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */
      "backdrop-opacity": [{
        "backdrop-opacity": [ce, q, J]
      }],
      /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */
      "backdrop-saturate": [{
        "backdrop-saturate": [ce, q, J]
      }],
      /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */
      "backdrop-sepia": [{
        "backdrop-sepia": ["", ce, q, J]
      }],
      // --------------
      // --- Tables ---
      // --------------
      /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */
      "border-collapse": [{
        border: ["collapse", "separate"]
      }],
      /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing": [{
        "border-spacing": N()
      }],
      /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-x": [{
        "border-spacing-x": N()
      }],
      /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-y": [{
        "border-spacing-y": N()
      }],
      /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */
      "table-layout": [{
        table: ["auto", "fixed"]
      }],
      /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */
      caption: [{
        caption: ["top", "bottom"]
      }],
      // ---------------------------------
      // --- Transitions and Animation ---
      // ---------------------------------
      /**
       * Transition Property
       * @see https://tailwindcss.com/docs/transition-property
       */
      transition: [{
        transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", q, J]
      }],
      /**
       * Transition Behavior
       * @see https://tailwindcss.com/docs/transition-behavior
       */
      "transition-behavior": [{
        transition: ["normal", "discrete"]
      }],
      /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */
      duration: [{
        duration: [ce, "initial", q, J]
      }],
      /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */
      ease: [{
        ease: ["linear", "initial", C, q, J]
      }],
      /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */
      delay: [{
        delay: [ce, q, J]
      }],
      /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */
      animate: [{
        animate: ["none", O, q, J]
      }],
      // ------------------
      // --- Transforms ---
      // ------------------
      /**
       * Backface Visibility
       * @see https://tailwindcss.com/docs/backface-visibility
       */
      backface: [{
        backface: ["hidden", "visible"]
      }],
      /**
       * Perspective
       * @see https://tailwindcss.com/docs/perspective
       */
      perspective: [{
        perspective: [p, q, J]
      }],
      /**
       * Perspective Origin
       * @see https://tailwindcss.com/docs/perspective-origin
       */
      "perspective-origin": [{
        "perspective-origin": M()
      }],
      /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */
      rotate: [{
        rotate: we()
      }],
      /**
       * Rotate X
       * @see https://tailwindcss.com/docs/rotate
       */
      "rotate-x": [{
        "rotate-x": we()
      }],
      /**
       * Rotate Y
       * @see https://tailwindcss.com/docs/rotate
       */
      "rotate-y": [{
        "rotate-y": we()
      }],
      /**
       * Rotate Z
       * @see https://tailwindcss.com/docs/rotate
       */
      "rotate-z": [{
        "rotate-z": we()
      }],
      /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */
      scale: [{
        scale: xe()
      }],
      /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-x": [{
        "scale-x": xe()
      }],
      /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-y": [{
        "scale-y": xe()
      }],
      /**
       * Scale Z
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-z": [{
        "scale-z": xe()
      }],
      /**
       * Scale 3D
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-3d": ["scale-3d"],
      /**
       * Skew
       * @see https://tailwindcss.com/docs/skew
       */
      skew: [{
        skew: Me()
      }],
      /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-x": [{
        "skew-x": Me()
      }],
      /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-y": [{
        "skew-y": Me()
      }],
      /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */
      transform: [{
        transform: [q, J, "", "none", "gpu", "cpu"]
      }],
      /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */
      "transform-origin": [{
        origin: M()
      }],
      /**
       * Transform Style
       * @see https://tailwindcss.com/docs/transform-style
       */
      "transform-style": [{
        transform: ["3d", "flat"]
      }],
      /**
       * Translate
       * @see https://tailwindcss.com/docs/translate
       */
      translate: [{
        translate: Qe()
      }],
      /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-x": [{
        "translate-x": Qe()
      }],
      /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-y": [{
        "translate-y": Qe()
      }],
      /**
       * Translate Z
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-z": [{
        "translate-z": Qe()
      }],
      /**
       * Translate None
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-none": ["translate-none"],
      // ---------------------
      // --- Interactivity ---
      // ---------------------
      /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */
      accent: [{
        accent: y()
      }],
      /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */
      appearance: [{
        appearance: ["none", "auto"]
      }],
      /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */
      "caret-color": [{
        caret: y()
      }],
      /**
       * Color Scheme
       * @see https://tailwindcss.com/docs/color-scheme
       */
      "color-scheme": [{
        scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"]
      }],
      /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */
      cursor: [{
        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", q, J]
      }],
      /**
       * Field Sizing
       * @see https://tailwindcss.com/docs/field-sizing
       */
      "field-sizing": [{
        "field-sizing": ["fixed", "content"]
      }],
      /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */
      "pointer-events": [{
        "pointer-events": ["auto", "none"]
      }],
      /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */
      resize: [{
        resize: ["none", "", "y", "x"]
      }],
      /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */
      "scroll-behavior": [{
        scroll: ["auto", "smooth"]
      }],
      /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-m": [{
        "scroll-m": N()
      }],
      /**
       * Scroll Margin X
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mx": [{
        "scroll-mx": N()
      }],
      /**
       * Scroll Margin Y
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-my": [{
        "scroll-my": N()
      }],
      /**
       * Scroll Margin Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ms": [{
        "scroll-ms": N()
      }],
      /**
       * Scroll Margin End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-me": [{
        "scroll-me": N()
      }],
      /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mt": [{
        "scroll-mt": N()
      }],
      /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mr": [{
        "scroll-mr": N()
      }],
      /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mb": [{
        "scroll-mb": N()
      }],
      /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ml": [{
        "scroll-ml": N()
      }],
      /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-p": [{
        "scroll-p": N()
      }],
      /**
       * Scroll Padding X
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-px": [{
        "scroll-px": N()
      }],
      /**
       * Scroll Padding Y
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-py": [{
        "scroll-py": N()
      }],
      /**
       * Scroll Padding Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-ps": [{
        "scroll-ps": N()
      }],
      /**
       * Scroll Padding End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pe": [{
        "scroll-pe": N()
      }],
      /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pt": [{
        "scroll-pt": N()
      }],
      /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pr": [{
        "scroll-pr": N()
      }],
      /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pb": [{
        "scroll-pb": N()
      }],
      /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pl": [{
        "scroll-pl": N()
      }],
      /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */
      "snap-align": [{
        snap: ["start", "end", "center", "align-none"]
      }],
      /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */
      "snap-stop": [{
        snap: ["normal", "always"]
      }],
      /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-type": [{
        snap: ["none", "x", "y", "both"]
      }],
      /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-strictness": [{
        snap: ["mandatory", "proximity"]
      }],
      /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */
      touch: [{
        touch: ["auto", "none", "manipulation"]
      }],
      /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-x": [{
        "touch-pan": ["x", "left", "right"]
      }],
      /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-y": [{
        "touch-pan": ["y", "up", "down"]
      }],
      /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-pz": ["touch-pinch-zoom"],
      /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */
      select: [{
        select: ["none", "text", "all", "auto"]
      }],
      /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */
      "will-change": [{
        "will-change": ["auto", "scroll", "contents", "transform", q, J]
      }],
      // -----------
      // --- SVG ---
      // -----------
      /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */
      fill: [{
        fill: ["none", ...y()]
      }],
      /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */
      "stroke-w": [{
        stroke: [ce, Sn, Pr, qi]
      }],
      /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */
      stroke: [{
        stroke: ["none", ...y()]
      }],
      // ---------------------
      // --- Accessibility ---
      // ---------------------
      /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */
      "forced-color-adjust": [{
        "forced-color-adjust": ["auto", "none"]
      }]
    },
    conflictingClassGroups: {
      overflow: ["overflow-x", "overflow-y"],
      overscroll: ["overscroll-x", "overscroll-y"],
      inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
      "inset-x": ["right", "left"],
      "inset-y": ["top", "bottom"],
      flex: ["basis", "grow", "shrink"],
      gap: ["gap-x", "gap-y"],
      p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
      px: ["pr", "pl"],
      py: ["pt", "pb"],
      m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
      mx: ["mr", "ml"],
      my: ["mt", "mb"],
      size: ["w", "h"],
      "font-size": ["leading"],
      "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
      "fvn-ordinal": ["fvn-normal"],
      "fvn-slashed-zero": ["fvn-normal"],
      "fvn-figure": ["fvn-normal"],
      "fvn-spacing": ["fvn-normal"],
      "fvn-fraction": ["fvn-normal"],
      "line-clamp": ["display", "overflow"],
      rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
      "rounded-s": ["rounded-ss", "rounded-es"],
      "rounded-e": ["rounded-se", "rounded-ee"],
      "rounded-t": ["rounded-tl", "rounded-tr"],
      "rounded-r": ["rounded-tr", "rounded-br"],
      "rounded-b": ["rounded-br", "rounded-bl"],
      "rounded-l": ["rounded-tl", "rounded-bl"],
      "border-spacing": ["border-spacing-x", "border-spacing-y"],
      "border-w": ["border-w-x", "border-w-y", "border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
      "border-w-x": ["border-w-r", "border-w-l"],
      "border-w-y": ["border-w-t", "border-w-b"],
      "border-color": ["border-color-x", "border-color-y", "border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
      "border-color-x": ["border-color-r", "border-color-l"],
      "border-color-y": ["border-color-t", "border-color-b"],
      translate: ["translate-x", "translate-y", "translate-none"],
      "translate-none": ["translate", "translate-x", "translate-y", "translate-z"],
      "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
      "scroll-mx": ["scroll-mr", "scroll-ml"],
      "scroll-my": ["scroll-mt", "scroll-mb"],
      "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
      "scroll-px": ["scroll-pr", "scroll-pl"],
      "scroll-py": ["scroll-pt", "scroll-pb"],
      touch: ["touch-x", "touch-y", "touch-pz"],
      "touch-x": ["touch"],
      "touch-y": ["touch"],
      "touch-pz": ["touch"]
    },
    conflictingClassGroupModifiers: {
      "font-size": ["leading"]
    },
    orderSensitiveModifiers: ["*", "**", "after", "backdrop", "before", "details-content", "file", "first-letter", "first-line", "marker", "placeholder", "selection"]
  };
}, Xf = (e, {
  cacheSize: t,
  prefix: r,
  experimentalParseClassName: n,
  extend: i = {},
  override: s = {}
}) => (En(e, "cacheSize", t), En(e, "prefix", r), En(e, "experimentalParseClassName", n), ti(e.theme, s.theme), ti(e.classGroups, s.classGroups), ti(e.conflictingClassGroups, s.conflictingClassGroups), ti(e.conflictingClassGroupModifiers, s.conflictingClassGroupModifiers), En(e, "orderSensitiveModifiers", s.orderSensitiveModifiers), ri(e.theme, i.theme), ri(e.classGroups, i.classGroups), ri(e.conflictingClassGroups, i.conflictingClassGroups), ri(e.conflictingClassGroupModifiers, i.conflictingClassGroupModifiers), rl(e, i, "orderSensitiveModifiers"), e), En = (e, t, r) => {
  r !== void 0 && (e[t] = r);
}, ti = (e, t) => {
  if (t)
    for (const r in t)
      En(e, r, t[r]);
}, ri = (e, t) => {
  if (t)
    for (const r in t)
      rl(e, t, r);
}, rl = (e, t, r) => {
  const n = t[r];
  n !== void 0 && (e[r] = e[r] ? e[r].concat(n) : n);
}, Zf = (e, ...t) => typeof e == "function" ? hs(gs, e, ...t) : hs(() => Xf(gs(), e), ...t), Ws = /* @__PURE__ */ hs(gs);
function Xt(...e) {
  return Ws(Qr(e));
}
function Qf(e, t) {
  Ae(t, !0);
  let r = Y(t, "ref", 15, null), n = Y(t, "value", 15, ""), i = /* @__PURE__ */ De(t, ["$$slots", "$$events", "$$legacy", "ref", "value", "class"]);
  var s = _e(), a = $(s);
  {
    let u = /* @__PURE__ */ U(() => Xt("flex flex-col gap-2", t.class));
    ze(a, () => df, (l, c) => {
      c(l, Gr(
        {
          "data-slot": "tabs",
          get class() {
            return o(u);
          }
        },
        () => i,
        {
          get ref() {
            return r();
          },
          set ref(f) {
            r(f);
          },
          get value() {
            return n();
          },
          set value(f) {
            n(f);
          }
        }
      ));
    });
  }
  S(e, s), Ce();
}
function ja(e, t) {
  Ae(t, !0);
  let r = Y(t, "ref", 15, null), n = /* @__PURE__ */ De(t, ["$$slots", "$$events", "$$legacy", "ref", "class"]);
  var i = _e(), s = $(i);
  {
    let a = /* @__PURE__ */ U(() => Xt("flex-1 outline-none", t.class));
    ze(s, () => hf, (u, l) => {
      l(u, Gr(
        {
          "data-slot": "tabs-content",
          get class() {
            return o(a);
          }
        },
        () => n,
        {
          get ref() {
            return r();
          },
          set ref(c) {
            r(c);
          }
        }
      ));
    });
  }
  S(e, i), Ce();
}
function $f(e, t) {
  Ae(t, !0);
  let r = Y(t, "ref", 15, null), n = /* @__PURE__ */ De(t, ["$$slots", "$$events", "$$legacy", "ref", "class"]);
  var i = _e(), s = $(i);
  {
    let a = /* @__PURE__ */ U(() => Xt("bg-muted text-muted-foreground inline-flex h-9 w-fit items-center justify-center rounded-lg p-[3px]", t.class));
    ze(s, () => pf, (u, l) => {
      l(u, Gr(
        {
          "data-slot": "tabs-list",
          get class() {
            return o(a);
          }
        },
        () => n,
        {
          get ref() {
            return r();
          },
          set ref(c) {
            r(c);
          }
        }
      ));
    });
  }
  S(e, i), Ce();
}
function Oa(e, t) {
  Ae(t, !0);
  let r = Y(t, "ref", 15, null), n = /* @__PURE__ */ De(t, ["$$slots", "$$events", "$$legacy", "ref", "class"]);
  var i = _e(), s = $(i);
  {
    let a = /* @__PURE__ */ U(() => Xt("data-[state=active]:bg-background dark:data-[state=active]:text-foreground focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring dark:data-[state=active]:border-input dark:data-[state=active]:bg-input/30 text-foreground dark:text-muted-foreground inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 whitespace-nowrap rounded-md border border-transparent px-2 py-1 text-sm font-medium transition-[color,box-shadow] focus-visible:outline-1 focus-visible:ring-[3px] disabled:pointer-events-none disabled:opacity-50 data-[state=active]:shadow-sm [&_svg:not([class*='size-'])]:size-4 [&_svg]:pointer-events-none [&_svg]:shrink-0", t.class));
    ze(s, () => bf, (u, l) => {
      l(u, Gr(
        {
          "data-slot": "tabs-trigger",
          get class() {
            return o(a);
          }
        },
        () => n,
        {
          get ref() {
            return r();
          },
          set ref(c) {
            r(c);
          }
        }
      ));
    });
  }
  S(e, i), Ce();
}
var ed = /\s+/g, ps = (e) => typeof e != "string" || !e ? e : e.replace(ed, " ").trim(), gi = (...e) => {
  let t = [], r = (n) => {
    if (!n && n !== 0 && n !== 0n) return;
    if (Array.isArray(n)) {
      for (let s = 0, a = n.length; s < a; s++) r(n[s]);
      return;
    }
    let i = typeof n;
    if (i === "string" || i === "number" || i === "bigint") {
      if (i === "number" && n !== n) return;
      t.push(String(n));
    } else if (i === "object") {
      let s = Object.keys(n);
      for (let a = 0, u = s.length; a < u; a++) {
        let l = s[a];
        n[l] && t.push(l);
      }
    }
  };
  for (let n = 0, i = e.length; n < i; n++) {
    let s = e[n];
    s != null && r(s);
  }
  return t.length > 0 ? ps(t.join(" ")) : void 0;
}, Fa = (e) => e === !1 ? "false" : e === !0 ? "true" : e === 0 ? "0" : e, dt = (e) => {
  if (!e || typeof e != "object") return !0;
  for (let t in e) return !1;
  return !0;
}, td = (e, t) => {
  if (e === t) return !0;
  if (!e || !t) return !1;
  let r = Object.keys(e), n = Object.keys(t);
  if (r.length !== n.length) return !1;
  for (let i = 0; i < r.length; i++) {
    let s = r[i];
    if (!n.includes(s) || e[s] !== t[s]) return !1;
  }
  return !0;
}, Ia = (e, t) => {
  for (let r in t) if (Object.prototype.hasOwnProperty.call(t, r)) {
    let n = t[r];
    r in e ? e[r] = gi(e[r], n) : e[r] = n;
  }
  return e;
}, nl = (e, t) => {
  for (let r = 0; r < e.length; r++) {
    let n = e[r];
    Array.isArray(n) ? nl(n, t) : n && t.push(n);
  }
}, il = (...e) => {
  let t = [];
  nl(e, t);
  let r = [];
  for (let n = 0; n < t.length; n++) t[n] && r.push(t[n]);
  return r;
}, ms = (e, t) => {
  let r = {};
  for (let n in e) {
    let i = e[n];
    if (n in t) {
      let s = t[n];
      Array.isArray(i) || Array.isArray(s) ? r[n] = il(s, i) : typeof i == "object" && typeof s == "object" && i && s ? r[n] = ms(i, s) : r[n] = s + " " + i;
    } else r[n] = i;
  }
  for (let n in t) n in e || (r[n] = t[n]);
  return r;
}, rd = { twMerge: !0, twMergeConfig: {}, responsiveVariants: !1 };
function nd() {
  let e = null, t = {}, r = !1;
  return { get cachedTwMerge() {
    return e;
  }, set cachedTwMerge(n) {
    e = n;
  }, get cachedTwMergeConfig() {
    return t;
  }, set cachedTwMergeConfig(n) {
    t = n;
  }, get didTwMergeConfigChange() {
    return r;
  }, set didTwMergeConfigChange(n) {
    r = n;
  }, reset() {
    e = null, t = {}, r = !1;
  } };
}
var $t = nd(), id = (e) => {
  let t = (r, n) => {
    let { extend: i = null, slots: s = {}, variants: a = {}, compoundVariants: u = [], compoundSlots: l = [], defaultVariants: c = {} } = r, f = { ...rd, ...n }, h = i != null && i.base ? gi(i.base, r == null ? void 0 : r.base) : r == null ? void 0 : r.base, g = i != null && i.variants && !dt(i.variants) ? ms(a, i.variants) : a, m = i != null && i.defaultVariants && !dt(i.defaultVariants) ? { ...i.defaultVariants, ...c } : c;
    !dt(f.twMergeConfig) && !td(f.twMergeConfig, $t.cachedTwMergeConfig) && ($t.didTwMergeConfigChange = !0, $t.cachedTwMergeConfig = f.twMergeConfig);
    let d = dt(i == null ? void 0 : i.slots), p = dt(s) ? {} : { base: gi(r == null ? void 0 : r.base, d && (i == null ? void 0 : i.base)), ...s }, b = d ? p : Ia({ ...i == null ? void 0 : i.slots }, dt(p) ? { base: r == null ? void 0 : r.base } : p), C = dt(i == null ? void 0 : i.compoundVariants) ? u : il(i == null ? void 0 : i.compoundVariants, u), O = (x) => {
      if (dt(g) && dt(s) && d) return e(h, x == null ? void 0 : x.class, x == null ? void 0 : x.className)(f);
      if (C && !Array.isArray(C)) throw new TypeError(`The "compoundVariants" prop must be an array. Received: ${typeof C}`);
      if (l && !Array.isArray(l)) throw new TypeError(`The "compoundSlots" prop must be an array. Received: ${typeof l}`);
      let M = (R, _, w = [], A) => {
        let y = w;
        if (typeof _ == "string") {
          let z = ps(_).split(" ");
          for (let F = 0; F < z.length; F++) y.push(`${R}:${z[F]}`);
        } else if (Array.isArray(_)) for (let z = 0; z < _.length; z++) y.push(`${R}:${_[z]}`);
        else if (typeof _ == "object" && typeof A == "string" && A in _) {
          let z = _[A];
          if (z && typeof z == "string") {
            let F = ps(z).split(" "), L = [];
            for (let D = 0; D < F.length; D++) L.push(`${R}:${F[D]}`);
            y[A] = y[A] ? y[A].concat(L) : L;
          } else if (Array.isArray(z) && z.length > 0) {
            let F = [];
            for (let L = 0; L < z.length; L++) F.push(`${R}:${z[L]}`);
            y[A] = F;
          }
        }
        return y;
      }, P = (R, _ = g, w = null, A = null) => {
        let y = _[R];
        if (!y || dt(y)) return null;
        let z = (A == null ? void 0 : A[R]) ?? (x == null ? void 0 : x[R]);
        if (z === null) return null;
        let F = Fa(z), L = Array.isArray(f.responsiveVariants) && f.responsiveVariants.length > 0 || f.responsiveVariants === !0, D = m == null ? void 0 : m[R], G = [];
        if (typeof F == "object" && L) for (let [ae, se] of Object.entries(F)) {
          let me = y[se];
          if (ae === "initial") {
            D = se;
            continue;
          }
          Array.isArray(f.responsiveVariants) && !f.responsiveVariants.includes(ae) || (G = M(ae, me, G, w));
        }
        let X = F != null && typeof F != "object" ? F : Fa(D), le = y[X || "false"];
        return typeof G == "object" && typeof w == "string" && G[w] ? Ia(G, le) : G.length > 0 ? (G.push(le), w === "base" ? G.join(" ") : G) : le;
      }, j = () => {
        if (!g) return null;
        let R = Object.keys(g), _ = [];
        for (let w = 0; w < R.length; w++) {
          let A = P(R[w], g);
          A && _.push(A);
        }
        return _;
      }, N = (R, _) => {
        if (!g || typeof g != "object") return null;
        let w = [];
        for (let A in g) {
          let y = P(A, g, R, _), z = R === "base" && typeof y == "string" ? y : y && y[R];
          z && w.push(z);
        }
        return w;
      }, I = {};
      for (let R in x) {
        let _ = x[R];
        _ !== void 0 && (I[R] = _);
      }
      let ne = (R, _) => {
        var A;
        let w = typeof (x == null ? void 0 : x[R]) == "object" ? { [R]: (A = x[R]) == null ? void 0 : A.initial } : {};
        return { ...m, ...I, ...w, ..._ };
      }, Z = (R = [], _) => {
        let w = [], A = R.length;
        for (let y = 0; y < A; y++) {
          let { class: z, className: F, ...L } = R[y], D = !0, G = ne(null, _);
          for (let X in L) {
            let le = L[X], ae = G[X];
            if (Array.isArray(le)) {
              if (!le.includes(ae)) {
                D = !1;
                break;
              }
            } else {
              if ((le == null || le === !1) && (ae == null || ae === !1)) continue;
              if (ae !== le) {
                D = !1;
                break;
              }
            }
          }
          D && (z && w.push(z), F && w.push(F));
        }
        return w;
      }, ie = (R) => {
        let _ = Z(C, R);
        if (!Array.isArray(_)) return _;
        let w = {}, A = e;
        for (let y = 0; y < _.length; y++) {
          let z = _[y];
          if (typeof z == "string") w.base = A(w.base, z)(f);
          else if (typeof z == "object") for (let F in z) w[F] = A(w[F], z[F])(f);
        }
        return w;
      }, fe = (R) => {
        if (l.length < 1) return null;
        let _ = {}, w = ne(null, R);
        for (let A = 0; A < l.length; A++) {
          let { slots: y = [], class: z, className: F, ...L } = l[A];
          if (!dt(L)) {
            let D = !0;
            for (let G in L) {
              let X = w[G], le = L[G];
              if (X === void 0 || (Array.isArray(le) ? !le.includes(X) : le !== X)) {
                D = !1;
                break;
              }
            }
            if (!D) continue;
          }
          for (let D = 0; D < y.length; D++) {
            let G = y[D];
            _[G] || (_[G] = []), _[G].push([z, F]);
          }
        }
        return _;
      };
      if (!dt(s) || !d) {
        let R = {};
        if (typeof b == "object" && !dt(b)) {
          let _ = e;
          for (let w in b) R[w] = (A) => {
            let y = ie(A), z = fe(A);
            return _(b[w], N(w, A), y ? y[w] : void 0, z ? z[w] : void 0, A == null ? void 0 : A.class, A == null ? void 0 : A.className)(f);
          };
        }
        return R;
      }
      return e(h, j(), Z(C), x == null ? void 0 : x.class, x == null ? void 0 : x.className)(f);
    }, E = () => {
      if (!(!g || typeof g != "object")) return Object.keys(g);
    };
    return O.variantKeys = E(), O.extend = i, O.base = h, O.slots = b, O.variants = g, O.defaultVariants = m, O.compoundSlots = l, O.compoundVariants = C, O;
  };
  return { tv: t, createTV: (r) => (n, i) => t(n, i ? ms(r, i) : r) };
}, sd = (e) => dt(e) ? Ws : Zf({ ...e, extend: { theme: e.theme, classGroups: e.classGroups, conflictingClassGroupModifiers: e.conflictingClassGroupModifiers, conflictingClassGroups: e.conflictingClassGroups, ...e.extend } }), ad = (...e) => (t) => {
  let r = gi(e);
  return !r || !t.twMerge ? r : ((!$t.cachedTwMerge || $t.didTwMergeConfigChange) && ($t.didTwMergeConfigChange = !1, $t.cachedTwMerge = sd($t.cachedTwMergeConfig)), $t.cachedTwMerge(r) || void 0);
}, { tv: sl } = id(ad);
function al(...e) {
  return Ws(Qr(e));
}
/**
 * @license @lucide/svelte v0.544.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * ---
 * 
 * The MIT License (MIT) (for portions derived from Feather)
 * 
 * Copyright (c) 2013-2023 Cole Bemis
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 */
const od = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  "stroke-width": 2,
  "stroke-linecap": "round",
  "stroke-linejoin": "round"
};
var ld = /* @__PURE__ */ Gc("<svg><!><!></svg>");
function Js(e, t) {
  Ae(t, !0);
  const r = Y(t, "color", 3, "currentColor"), n = Y(t, "size", 3, 24), i = Y(t, "strokeWidth", 3, 2), s = Y(t, "absoluteStrokeWidth", 3, !1), a = Y(t, "iconNode", 19, () => []), u = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "name",
    "color",
    "size",
    "strokeWidth",
    "absoluteStrokeWidth",
    "iconNode",
    "children"
  ]);
  var l = ld();
  gt(
    l,
    (h) => ({
      ...od,
      ...u,
      width: n(),
      height: n(),
      stroke: r(),
      "stroke-width": h,
      class: [
        "lucide-icon lucide",
        t.name && `lucide-${t.name}`,
        t.class
      ]
    }),
    [
      () => s() ? Number(i()) * 24 / Number(n()) : i()
    ]
  );
  var c = V(l);
  Ro(c, 17, a, No, (h, g) => {
    var m = /* @__PURE__ */ U(() => Tl(o(g), 2));
    let d = () => o(m)[0], p = () => o(m)[1];
    var b = _e(), C = $(b);
    Is(C, d, !0, (O, E) => {
      gt(O, () => ({ ...p() }));
    }), S(h, b);
  });
  var f = K(c);
  Ve(f, () => t.children ?? lt), S(e, l), Ce();
}
function cd(e, t) {
  Ae(t, !0);
  /**
   * @license @lucide/svelte v0.544.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   * ---
   *
   * The MIT License (MIT) (for portions derived from Feather)
   *
   * Copyright (c) 2013-2023 Cole Bemis
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   *
   */
  let r = /* @__PURE__ */ De(t, ["$$slots", "$$events", "$$legacy"]);
  const n = [["path", { d: "M21 12a9 9 0 1 1-6.219-8.56" }]];
  Js(e, Gr(
    { name: "loader-circle" },
    () => r,
    {
      get iconNode() {
        return n;
      },
      children: (i, s) => {
        var a = _e(), u = $(a);
        Ve(u, () => t.children ?? lt), S(i, a);
      },
      $$slots: { default: !0 }
    }
  )), Ce();
}
const ud = sl({
  base: "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive focus-visible:border-ring focus-visible:ring-ring/50 relative inline-flex shrink-0 items-center justify-center gap-2 overflow-hidden rounded-md text-sm font-medium whitespace-nowrap outline-hidden transition-all select-none focus-visible:ring-[3px] disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
  variants: {
    variant: {
      default: "bg-primary text-primary-foreground hover:bg-primary/90 shadow-2xs",
      destructive: "bg-destructive hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:bg-destructive/60 dark:focus-visible:ring-destructive/40 text-white shadow-2xs",
      outline: "bg-background hover:bg-accent hover:text-accent-foreground dark:border-input dark:bg-input/30 dark:hover:bg-input/50 border shadow-2xs",
      secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 shadow-2xs",
      ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
      link: "text-primary underline-offset-4 hover:underline"
    },
    size: {
      default: "h-9 px-4 py-2 has-[>svg]:px-3",
      sm: "h-8 gap-1.5 rounded-md px-3 has-[>svg]:px-2.5",
      lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
      icon: "size-9"
    }
  },
  defaultVariants: { variant: "default", size: "default" }
});
var fd = /* @__PURE__ */ W('<div class="absolute flex size-full place-items-center justify-center bg-inherit"><div class="flex animate-spin place-items-center justify-center"><!></div></div> <span class="sr-only">Loading</span>', 1), dd = /* @__PURE__ */ W("<!> <!>", 1);
function lr(e, t) {
  Ae(t, !0);
  let r = Y(t, "ref", 15, null), n = Y(t, "variant", 3, "default"), i = Y(t, "size", 3, "default"), s = Y(t, "href", 3, void 0), a = Y(t, "type", 3, "button"), u = Y(t, "loading", 7, !1), l = Y(t, "disabled", 3, !1), c = Y(t, "tabindex", 3, 0), f = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "ref",
    "variant",
    "size",
    "href",
    "type",
    "loading",
    "disabled",
    "tabindex",
    "onclick",
    "onClickPromise",
    "class",
    "children"
  ]);
  var h = _e(), g = $(h);
  Is(g, () => s() ? "a" : "button", !1, (m, d) => {
    Br(m, (x) => r(x), () => r());
    var p = async (x) => {
      var M;
      (M = t.onclick) == null || M.call(t, x), a() !== void 0 && t.onClickPromise && (u(!0), await t.onClickPromise(x), u(!1));
    };
    gt(
      m,
      (x) => ({
        ...f,
        "data-slot": "button",
        type: s() ? void 0 : a(),
        href: s() && !l() ? s() : void 0,
        disabled: s() ? void 0 : l() || u(),
        "aria-disabled": s() ? l() : void 0,
        role: s() && l() ? "link" : void 0,
        tabindex: s() && l() ? -1 : c(),
        class: x,
        onclick: p
      }),
      [
        () => al(ud({ variant: n(), size: i() }), t.class)
      ]
    );
    var b = dd(), C = $(b);
    {
      var O = (x) => {
        var M = fd(), P = $(M), j = V(P), N = V(j);
        cd(N, { class: "size-4" }), S(x, M);
      };
      ee(C, (x) => {
        a() !== void 0 && u() && x(O);
      });
    }
    var E = K(C, 2);
    Ve(E, () => t.children ?? lt), S(d, b);
  }), S(e, h), Ce();
}
const vd = sl({
  base: "focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive inline-flex w-fit shrink-0 items-center justify-center gap-1 overflow-hidden whitespace-nowrap rounded-full border px-2 py-0.5 text-xs font-medium transition-[color,box-shadow] focus-visible:ring-[3px] [&>svg]:pointer-events-none [&>svg]:size-3",
  variants: {
    variant: {
      default: "bg-primary text-primary-foreground [a&]:hover:bg-primary/90 border-transparent",
      secondary: "bg-secondary text-secondary-foreground [a&]:hover:bg-secondary/90 border-transparent",
      destructive: "bg-destructive [a&]:hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/70 border-transparent text-white",
      outline: "text-foreground [a&]:hover:bg-accent [a&]:hover:text-accent-foreground"
    }
  },
  defaultVariants: { variant: "default" }
});
function Cr(e, t) {
  Ae(t, !0);
  let r = Y(t, "ref", 15, null), n = Y(t, "variant", 3, "default"), i = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "ref",
    "href",
    "class",
    "variant",
    "children"
  ]);
  var s = _e(), a = $(s);
  Is(a, () => t.href ? "a" : "span", !1, (u, l) => {
    Br(u, (h) => r(h), () => r()), gt(
      u,
      (h) => ({
        "data-slot": "badge",
        href: t.href,
        class: h,
        ...i
      }),
      [
        () => Xt(vd({ variant: n() }), t.class)
      ]
    );
    var c = _e(), f = $(c);
    Ve(f, () => t.children ?? lt), S(l, c);
  }), S(e, s), Ce();
}
var hd = /* @__PURE__ */ W("<div><!></div>");
function qs(e, t) {
  Ae(t, !0);
  let r = Y(t, "ref", 15, null), n = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "ref",
    "class",
    "children"
  ]);
  var i = hd();
  gt(i, (a) => ({ "data-slot": "card", class: a, ...n }), [
    () => Xt("bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm", t.class)
  ]);
  var s = V(i);
  Ve(s, () => t.children ?? lt), Br(i, (a) => r(a), () => r()), S(e, i), Ce();
}
var gd = /* @__PURE__ */ W("<div><!></div>");
function Ks(e, t) {
  Ae(t, !0);
  let r = Y(t, "ref", 15, null), n = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "ref",
    "class",
    "children"
  ]);
  var i = gd();
  gt(i, (a) => ({ "data-slot": "card-content", class: a, ...n }), [() => Xt("px-6", t.class)]);
  var s = V(i);
  Ve(s, () => t.children ?? lt), Br(i, (a) => r(a), () => r()), S(e, i), Ce();
}
var pd = /* @__PURE__ */ W("<p><!></p>");
function Hs(e, t) {
  Ae(t, !0);
  let r = Y(t, "ref", 15, null), n = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "ref",
    "class",
    "children"
  ]);
  var i = pd();
  gt(i, (a) => ({ "data-slot": "card-description", class: a, ...n }), [() => Xt("text-muted-foreground text-sm", t.class)]);
  var s = V(i);
  Ve(s, () => t.children ?? lt), Br(i, (a) => r(a), () => r()), S(e, i), Ce();
}
var md = /* @__PURE__ */ W("<div><!></div>");
function Ys(e, t) {
  Ae(t, !0);
  let r = Y(t, "ref", 15, null), n = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "ref",
    "class",
    "children"
  ]);
  var i = md();
  gt(i, (a) => ({ "data-slot": "card-header", class: a, ...n }), [
    () => Xt("@container/card-header has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6 grid auto-rows-min grid-rows-[auto_auto] items-start gap-1.5 px-6", t.class)
  ]);
  var s = V(i);
  Ve(s, () => t.children ?? lt), Br(i, (a) => r(a), () => r()), S(e, i), Ce();
}
var bd = /* @__PURE__ */ W("<div><!></div>");
function Xs(e, t) {
  Ae(t, !0);
  let r = Y(t, "ref", 15, null), n = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "ref",
    "class",
    "children"
  ]);
  var i = bd();
  gt(i, (a) => ({ "data-slot": "card-title", class: a, ...n }), [() => Xt("font-semibold leading-none", t.class)]);
  var s = V(i);
  Ve(s, () => t.children ?? lt), Br(i, (a) => r(a), () => r()), S(e, i), Ce();
}
function _d(e, t) {
  Ae(t, !0);
  /**
   * @license @lucide/svelte v0.544.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   * ---
   *
   * The MIT License (MIT) (for portions derived from Feather)
   *
   * Copyright (c) 2013-2023 Cole Bemis
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   *
   */
  let r = /* @__PURE__ */ De(t, ["$$slots", "$$events", "$$legacy"]);
  const n = [
    ["path", { d: "M12 3v12" }],
    ["path", { d: "m17 8-5-5-5 5" }],
    ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }]
  ];
  Js(e, Gr(
    { name: "upload" },
    () => r,
    {
      get iconNode() {
        return n;
      },
      children: (i, s) => {
        var a = _e(), u = $(a);
        Ve(u, () => t.children ?? lt), S(i, a);
      },
      $$slots: { default: !0 }
    }
  )), Ce();
}
var yd = /* @__PURE__ */ W("<span> </span>"), wd = /* @__PURE__ */ W("<span> </span>"), xd = /* @__PURE__ */ W("<span> </span>"), kd = /* @__PURE__ */ W('<span class="text-muted-foreground/75 text-sm"><!> <!> <!></span>'), Sd = /* @__PURE__ */ W(`<div class="flex flex-col place-items-center justify-center gap-2"><div class="border-border text-muted-foreground flex size-14 place-items-center justify-center rounded-full border border-dashed"><!></div> <div class="flex flex-col gap-0.5 text-center"><span class="text-muted-foreground font-medium">Drag 'n' drop files here, or click to select files</span> <!></div></div>`), Ad = /* @__PURE__ */ W("<label><!> <input/></label>");
function Cd(e, t) {
  Ae(t, !0);
  let r = Y(t, "id", 19, uf), n = Y(t, "disabled", 3, !1), i = /* @__PURE__ */ De(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "id",
    "children",
    "maxFiles",
    "maxFileSize",
    "fileCount",
    "disabled",
    "onUpload",
    "onFileRejected",
    "accept",
    "class"
  ]);
  t.maxFiles !== void 0 && t.fileCount === void 0 && console.warn("Make sure to provide FileDropZone with `fileCount` when using the `maxFiles` prompt");
  let s = /* @__PURE__ */ oe(!1);
  const a = async (b) => {
    var O;
    if (n() || !o(f)) return;
    b.preventDefault();
    const C = Array.from(((O = b.dataTransfer) == null ? void 0 : O.files) ?? []);
    await c(C);
  }, u = async (b) => {
    if (n()) return;
    const C = b.currentTarget.files;
    C && (await c(Array.from(C)), b.target && (b.target.value = ""));
  }, l = (b, C) => {
    if (t.maxFileSize !== void 0 && b.size > t.maxFileSize) return "Maximum file size exceeded";
    if (t.maxFiles !== void 0 && C > t.maxFiles) return "Maximum files uploaded";
    if (!t.accept) return;
    const O = t.accept.split(",").map((P) => P.trim().toLowerCase()), E = b.type.toLowerCase(), x = b.name.toLowerCase();
    if (!O.some((P) => {
      if (E.startsWith("."))
        return x.endsWith(P);
      if (P.endsWith("/*")) {
        const j = P.slice(0, P.indexOf("/*"));
        return E.startsWith(j + "/");
      }
      return E === P;
    })) return "File type not allowed";
  }, c = async (b) => {
    var O;
    k(s, !0);
    const C = [];
    for (let E = 0; E < b.length; E++) {
      const x = b[E], M = l(x, (t.fileCount ?? 0) + E + 1);
      if (M) {
        (O = t.onFileRejected) == null || O.call(t, { file: x, reason: M });
        continue;
      }
      C.push(x);
    }
    await t.onUpload(C), k(s, !1);
  }, f = /* @__PURE__ */ U(() => !n() && !o(s) && !(t.maxFiles !== void 0 && t.fileCount !== void 0 && t.fileCount >= t.maxFiles));
  var h = Ad(), g = V(h);
  {
    var m = (b) => {
      var C = _e(), O = $(C);
      Ve(O, () => t.children), S(b, C);
    }, d = (b) => {
      var C = Sd(), O = V(C), E = V(O);
      _d(E, { class: "size-7" });
      var x = K(O, 2), M = K(V(x), 2);
      {
        var P = (j) => {
          var N = kd(), I = V(N);
          {
            var ne = (_) => {
              var w = yd(), A = V(w);
              ge(() => ye(A, `You can upload ${t.maxFiles ?? ""} files`)), S(_, w);
            };
            ee(I, (_) => {
              t.maxFiles && _(ne);
            });
          }
          var Z = K(I, 2);
          {
            var ie = (_) => {
              var w = wd(), A = V(w);
              ge((y) => ye(A, `(up to ${y ?? ""} each)`), [() => pi(t.maxFileSize)]), S(_, w);
            };
            ee(Z, (_) => {
              t.maxFiles && t.maxFileSize && _(ie);
            });
          }
          var fe = K(Z, 2);
          {
            var R = (_) => {
              var w = xd(), A = V(w);
              ge((y) => ye(A, `Maximum size ${y ?? ""}`), [() => pi(t.maxFileSize)]), S(_, w);
            };
            ee(fe, (_) => {
              t.maxFileSize && !t.maxFiles && _(R);
            });
          }
          S(j, N);
        };
        ee(M, (j) => {
          (t.maxFiles || t.maxFileSize) && j(P);
        });
      }
      S(b, C);
    };
    ee(g, (b) => {
      t.children ? b(m) : b(d, !1);
    });
  }
  var p = K(g, 2);
  gt(
    p,
    () => ({
      ...i,
      disabled: !o(f),
      id: r(),
      accept: t.accept,
      multiple: t.maxFiles === void 0 || t.maxFiles - (t.fileCount ?? 0) > 1,
      type: "file",
      onchange: u,
      class: "hidden"
    }),
    void 0,
    void 0,
    void 0,
    void 0,
    !0
  ), ge(
    (b) => {
      gn(h, "for", r()), gn(h, "aria-disabled", !o(f)), wt(h, 1, b);
    },
    [
      () => Io(al("border-border hover:bg-accent/25 flex h-48 w-full place-items-center justify-center rounded-lg border-2 border-dashed p-6 transition-all hover:cursor-pointer aria-disabled:opacity-50 aria-disabled:hover:cursor-not-allowed", t.class))
    ]
  ), _a("dragover", h, (b) => b.preventDefault()), _a("drop", h, a), S(e, h), Ce();
}
const pi = (e) => e < bs ? `${e.toFixed(0)} B` : e < _s ? `${(e / bs).toFixed(0)} KB` : e < La ? `${(e / _s).toFixed(0)} MB` : `${(e / La).toFixed(0)} GB`, bs = 1024, _s = 1024 * bs, La = 1024 * _s;
var Ed = /* @__PURE__ */ W('<div class="flex h-80 w-full items-center justify-center rounded-md border border-dashed border-zinc-200 bg-zinc-50 text-sm text-zinc-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-400"><p>No JSON selected.</p></div>'), Pd = /* @__PURE__ */ W('<span class="_jsonSep svelte-yhps85">,</span>'), Td = /* @__PURE__ */ W("<span> </span><!>", 1), zd = /* @__PURE__ */ W('<span class="_jsonSep svelte-yhps85">,</span>'), Md = /* @__PURE__ */ W('<span role="button" tabindex="0"> </span><!>', 1), Nd = /* @__PURE__ */ W('<span> </span> <span class="_jsonSep svelte-yhps85">:</span>', 1), Rd = /* @__PURE__ */ W('<span class="diff-previous-label svelte-yhps85">Updated from</span> <span> </span>', 1), jd = /* @__PURE__ */ W('<span class="_jsonSep svelte-yhps85">,</span>'), Od = /* @__PURE__ */ W("<span> </span><!><!>", 1), Fd = /* @__PURE__ */ W('<span> </span> <span class="diff-previous-label svelte-yhps85">Removed</span>', 1), Id = /* @__PURE__ */ W("<li><!> <!></li>"), Ld = /* @__PURE__ */ W('<span class="_jsonSep svelte-yhps85">,</span>'), Vd = /* @__PURE__ */ W('<span role="button" tabindex="0"> </span> <ul class="_jsonList svelte-yhps85"></ul> <span role="button" tabindex="0"> </span><!>', 1);
function ol(e, t) {
  Ae(t, !0);
  const r = Y(t, "dirty", 3, !1), n = Y(t, "diffContext", 3, "unchanged"), i = Y(t, "depth", 3, 2), s = Y(t, "currentDepth", 3, 0), a = Y(t, "isLast", 3, !0), u = Y(t, "preserveKeyOrder", 3, !1);
  let l = /* @__PURE__ */ oe(Fe([])), c = /* @__PURE__ */ oe(!1), f = /* @__PURE__ */ oe(Fe(["{", "}"])), h = /* @__PURE__ */ oe(!1), g = /* @__PURE__ */ oe(Fe({}));
  const m = (I) => I === null ? "null" : typeof I, d = (I) => typeof I == "object" && I !== null, p = (I, ne) => {
    if (I === ne) return !0;
    if (typeof I != typeof ne) return !1;
    if (Array.isArray(I) && Array.isArray(ne))
      return I.length !== ne.length ? !1 : I.every((Z, ie) => p(Z, ne[ie]));
    if (d(I) && d(ne)) {
      const Z = Object.keys(I), ie = Object.keys(ne);
      return Z.length !== ie.length ? !1 : Z.every((fe) => p(I[fe], ne[fe]));
    }
    return !1;
  }, b = (I) => {
    var ne;
    for (let Z = I + 1; Z < o(l).length; Z += 1)
      if ((ne = o(g)[o(l)[Z]]) != null && ne.hasCurrent)
        return !0;
    return !1;
  }, C = (I) => JSON.stringify(I), O = (I) => {
    const ne = m(I);
    return ne === "string" ? C(I) : ne === "number" || ne === "bigint" ? String(I) : ne === "boolean" ? I ? "true" : "false" : I === null ? "null" : I === void 0 ? "undefined" : String(I);
  }, E = () => {
    k(h, !o(h));
  }, x = (I) => {
    ["Enter", " "].includes(I.key) && (I.preventDefault(), E());
  };
  Ye(() => {
    const I = t.data ?? t.baseline;
    if (m(I) === "object") {
      const Z = d(t.data) ? t.data : void 0, ie = d(t.baseline) ? t.baseline : void 0, fe = Z ? Object.keys(Z) : [], R = ie ? Object.keys(ie) : [], _ = [], w = /* @__PURE__ */ new Set(), A = (z) => {
        for (const F of z)
          w.has(F) || (_.push(F), w.add(F));
      };
      A(fe), r() && ie && A(R), u() || (Array.isArray(I) ? (F) => F.sort((L, D) => Number(L) - Number(D)) : (F) => F.sort((L, D) => L.localeCompare(D, void 0, { numeric: !0 })))(_);
      const y = {};
      for (const z of _) {
        const F = !!(Z && z in Z), L = !!(ie && z in ie), D = F ? Z == null ? void 0 : Z[z] : void 0, G = L ? ie == null ? void 0 : ie[z] : void 0;
        let X = "unchanged";
        r() && ie && (F && !L ? X = "added" : !F && L ? X = "removed" : p(D, G) || (X = "changed")), y[z] = { status: X, hasCurrent: F, hasPrevious: L, currentValue: D, previousValue: G };
      }
      k(l, _, !0), k(g, y, !0), k(c, Array.isArray(I), !0), k(f, o(c) ? ["[", "]"] : ["{", "}"], !0);
    } else
      k(l, [], !0), k(c, !1), k(f, ["{", "}"], !0), k(g, {}, !0);
  }), Ye(() => {
    k(h, i() < s());
  });
  var M = _e(), P = $(M);
  {
    var j = (I) => {
      var ne = Ed();
      S(I, ne);
    }, N = (I) => {
      var ne = _e(), Z = $(ne);
      {
        var ie = (R) => {
          var _ = Td(), w = $(_);
          let A;
          var y = V(w), z = K(w);
          {
            var F = (L) => {
              var D = Pd();
              S(L, D);
            };
            ee(z, (L) => {
              a() || L(F);
            });
          }
          ge(() => {
            A = wt(w, 1, "_jsonBkt empty svelte-yhps85", null, A, { isArray: o(c) }), ye(y, `${o(f)[0] ?? ""}${o(f)[1] ?? ""}`);
          }), S(R, _);
        }, fe = (R) => {
          var _ = _e(), w = $(_);
          {
            var A = (z) => {
              var F = Md(), L = $(F);
              let D;
              L.__click = E, L.__keydown = x;
              var G = V(L), X = K(L);
              {
                var le = (ae) => {
                  var se = zd();
                  S(ae, se);
                };
                ee(X, (ae) => {
                  !a() && o(h) && ae(le);
                });
              }
              ge(() => {
                D = wt(L, 1, "_jsonBkt svelte-yhps85", null, D, { isArray: o(c) }), ye(G, `${o(f)[0] ?? ""}...${o(f)[1] ?? ""}`);
              }), S(z, F);
            }, y = (z) => {
              var F = Vd(), L = $(F);
              let D;
              L.__click = E, L.__keydown = x;
              var G = V(L), X = K(L, 2);
              Ro(X, 21, () => o(l), No, (xe, Me, Qe) => {
                const Q = /* @__PURE__ */ U(() => o(g)[o(Me)]);
                var je = _e(), $e = $(je);
                {
                  var ut = (T) => {
                    const B = /* @__PURE__ */ U(() => o(Q).currentValue), re = /* @__PURE__ */ U(() => o(Q).previousValue), ke = /* @__PURE__ */ U(() => m(o(Q).hasCurrent ? o(B) : o(re)));
                    var Ie = Id();
                    let Re;
                    var Ue = V(Ie);
                    {
                      var Ke = (Se) => {
                        var Mt = Nd(), st = $(Mt);
                        let ft;
                        var pt = V(st);
                        ge(
                          (Ne) => {
                            ft = wt(st, 1, "_jsonKey svelte-yhps85", null, ft, { "diff-removed-text": o(Q).status === "removed" }), ye(pt, Ne);
                          },
                          [() => C(o(Me))]
                        ), S(Se, Mt);
                      };
                      ee(Ue, (Se) => {
                        o(c) || Se(Ke);
                      });
                    }
                    var de = K(Ue, 2);
                    {
                      var pe = (Se) => {
                        {
                          let Mt = /* @__PURE__ */ U(() => o(Q).hasCurrent ? o(B) : void 0), st = /* @__PURE__ */ U(() => o(Q).hasPrevious ? o(re) : void 0), ft = /* @__PURE__ */ U(() => s() + 1), pt = /* @__PURE__ */ U(() => !b(Qe));
                          ol(Se, {
                            get data() {
                              return o(Mt);
                            },
                            get baseline() {
                              return o(st);
                            },
                            get depth() {
                              return i();
                            },
                            get dirty() {
                              return r();
                            },
                            get diffContext() {
                              return o(Q).status;
                            },
                            get currentDepth() {
                              return o(ft);
                            },
                            get isLast() {
                              return o(pt);
                            }
                          });
                        }
                      }, Ee = (Se) => {
                        var Mt = _e(), st = $(Mt);
                        {
                          var ft = (Ne) => {
                            var Oe = Od(), Le = $(Oe);
                            let Nt;
                            var mt = V(Le), Rt = K(Le);
                            {
                              var At = (jt) => {
                                var Zt = Rd(), Hn = K($(Zt), 2), Li = V(Hn);
                                ge(
                                  (Vi, bt) => {
                                    wt(Hn, 1, `_jsonVal ${Vi ?? ""} diff-removed`, "svelte-yhps85"), ye(Li, bt);
                                  },
                                  [
                                    () => m(o(re)),
                                    () => O(o(re))
                                  ]
                                ), S(jt, Zt);
                              };
                              ee(Rt, (jt) => {
                                o(Q).status === "changed" && o(Q).hasPrevious && jt(At);
                              });
                            }
                            var hr = K(Rt);
                            {
                              var Vt = (jt) => {
                                var Zt = jd();
                                S(jt, Zt);
                              };
                              ee(hr, (jt) => {
                                o(Q).hasCurrent && b(Qe) && jt(Vt);
                              });
                            }
                            ge(
                              (jt, Zt) => {
                                Nt = wt(Le, 1, `_jsonVal ${jt ?? ""}`, "svelte-yhps85", Nt, {
                                  "diff-added": o(Q).status === "added" || o(Q).status === "changed"
                                }), ye(mt, Zt);
                              },
                              [
                                () => m(o(B)),
                                () => O(o(B))
                              ]
                            ), S(Ne, Oe);
                          }, pt = (Ne) => {
                            var Oe = _e(), Le = $(Oe);
                            {
                              var Nt = (mt) => {
                                var Rt = Fd(), At = $(Rt), hr = V(At);
                                ge(
                                  (Vt) => {
                                    wt(At, 1, `_jsonVal ${o(ke) ?? ""} diff-removed`, "svelte-yhps85"), ye(hr, Vt);
                                  },
                                  [() => O(o(re))]
                                ), S(mt, Rt);
                              };
                              ee(
                                Le,
                                (mt) => {
                                  o(Q).hasPrevious && mt(Nt);
                                },
                                !0
                              );
                            }
                            S(Ne, Oe);
                          };
                          ee(
                            st,
                            (Ne) => {
                              o(Q).hasCurrent ? Ne(ft) : Ne(pt, !1);
                            },
                            !0
                          );
                        }
                        S(Se, Mt);
                      };
                      ee(de, (Se) => {
                        (o(Q).hasCurrent ? m(o(B)) : m(o(re))) === "object" ? Se(pe) : Se(Ee, !1);
                      });
                    }
                    ge(() => Re = wt(Ie, 1, "svelte-yhps85", null, Re, { "diff-removed-row": o(Q).status === "removed" })), S(T, Ie);
                  };
                  ee($e, (T) => {
                    o(Q) && T(ut);
                  });
                }
                S(xe, je);
              });
              var le = K(X, 2);
              let ae;
              le.__click = E, le.__keydown = x;
              var se = V(le), me = K(le);
              {
                var we = (xe) => {
                  var Me = Ld();
                  S(xe, Me);
                };
                ee(me, (xe) => {
                  !a() && n() !== "removed" && xe(we);
                });
              }
              ge(() => {
                D = wt(L, 1, "_jsonBkt svelte-yhps85", null, D, {
                  isArray: o(c),
                  "diff-block-added": n() === "added",
                  "diff-block-removed": n() === "removed"
                }), ye(G, o(f)[0]), ae = wt(le, 1, "_jsonBkt svelte-yhps85", null, ae, {
                  isArray: o(c),
                  "diff-block-added": n() === "added",
                  "diff-block-removed": n() === "removed"
                }), ye(se, o(f)[1]);
              }), S(z, F);
            };
            ee(
              w,
              (z) => {
                o(h) ? z(A) : z(y, !1);
              },
              !0
            );
          }
          S(R, _);
        };
        ee(Z, (R) => {
          o(l).length ? R(fe, !1) : R(ie);
        });
      }
      S(I, ne);
    };
    ee(P, (I) => {
      t.data === void 0 && (!r() || t.baseline === void 0) ? I(j) : I(N, !1);
    });
  }
  S(e, M), Ce();
}
zi(["click", "keydown"]);
var he = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Kn = Symbol.for("react.element"), Dd = Symbol.for("react.portal"), Bd = Symbol.for("react.fragment"), Gd = Symbol.for("react.strict_mode"), Ud = Symbol.for("react.profiler"), Wd = Symbol.for("react.provider"), Jd = Symbol.for("react.context"), qd = Symbol.for("react.forward_ref"), Kd = Symbol.for("react.suspense"), Hd = Symbol.for("react.memo"), Yd = Symbol.for("react.lazy"), Va = Symbol.iterator;
function Xd(e) {
  return e === null || typeof e != "object" ? null : (e = Va && e[Va] || e["@@iterator"], typeof e == "function" ? e : null);
}
var ll = { isMounted: function() {
  return !1;
}, enqueueForceUpdate: function() {
}, enqueueReplaceState: function() {
}, enqueueSetState: function() {
} }, cl = Object.assign, ul = {};
function yn(e, t, r) {
  this.props = e, this.context = t, this.refs = ul, this.updater = r || ll;
}
yn.prototype.isReactComponent = {};
yn.prototype.setState = function(e, t) {
  if (typeof e != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
  this.updater.enqueueSetState(this, e, t, "setState");
};
yn.prototype.forceUpdate = function(e) {
  this.updater.enqueueForceUpdate(this, e, "forceUpdate");
};
function fl() {
}
fl.prototype = yn.prototype;
function Zs(e, t, r) {
  this.props = e, this.context = t, this.refs = ul, this.updater = r || ll;
}
var Qs = Zs.prototype = new fl();
Qs.constructor = Zs;
cl(Qs, yn.prototype);
Qs.isPureReactComponent = !0;
var Da = Array.isArray, dl = Object.prototype.hasOwnProperty, $s = { current: null }, vl = { key: !0, ref: !0, __self: !0, __source: !0 };
function hl(e, t, r) {
  var n, i = {}, s = null, a = null;
  if (t != null) for (n in t.ref !== void 0 && (a = t.ref), t.key !== void 0 && (s = "" + t.key), t) dl.call(t, n) && !vl.hasOwnProperty(n) && (i[n] = t[n]);
  var u = arguments.length - 2;
  if (u === 1) i.children = r;
  else if (1 < u) {
    for (var l = Array(u), c = 0; c < u; c++) l[c] = arguments[c + 2];
    i.children = l;
  }
  if (e && e.defaultProps) for (n in u = e.defaultProps, u) i[n] === void 0 && (i[n] = u[n]);
  return { $$typeof: Kn, type: e, key: s, ref: a, props: i, _owner: $s.current };
}
function Zd(e, t) {
  return { $$typeof: Kn, type: e.type, key: t, ref: e.ref, props: e.props, _owner: e._owner };
}
function ea(e) {
  return typeof e == "object" && e !== null && e.$$typeof === Kn;
}
function Qd(e) {
  var t = { "=": "=0", ":": "=2" };
  return "$" + e.replace(/[=:]/g, function(r) {
    return t[r];
  });
}
var Ba = /\/+/g;
function Ki(e, t) {
  return typeof e == "object" && e !== null && e.key != null ? Qd("" + e.key) : t.toString(36);
}
function li(e, t, r, n, i) {
  var s = typeof e;
  (s === "undefined" || s === "boolean") && (e = null);
  var a = !1;
  if (e === null) a = !0;
  else switch (s) {
    case "string":
    case "number":
      a = !0;
      break;
    case "object":
      switch (e.$$typeof) {
        case Kn:
        case Dd:
          a = !0;
      }
  }
  if (a) return a = e, i = i(a), e = n === "" ? "." + Ki(a, 0) : n, Da(i) ? (r = "", e != null && (r = e.replace(Ba, "$&/") + "/"), li(i, t, r, "", function(c) {
    return c;
  })) : i != null && (ea(i) && (i = Zd(i, r + (!i.key || a && a.key === i.key ? "" : ("" + i.key).replace(Ba, "$&/") + "/") + e)), t.push(i)), 1;
  if (a = 0, n = n === "" ? "." : n + ":", Da(e)) for (var u = 0; u < e.length; u++) {
    s = e[u];
    var l = n + Ki(s, u);
    a += li(s, t, r, l, i);
  }
  else if (l = Xd(e), typeof l == "function") for (e = l.call(e), u = 0; !(s = e.next()).done; ) s = s.value, l = n + Ki(s, u++), a += li(s, t, r, l, i);
  else if (s === "object") throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
  return a;
}
function ni(e, t, r) {
  if (e == null) return e;
  var n = [], i = 0;
  return li(e, n, "", "", function(s) {
    return t.call(r, s, i++);
  }), n;
}
function $d(e) {
  if (e._status === -1) {
    var t = e._result;
    t = t(), t.then(function(r) {
      (e._status === 0 || e._status === -1) && (e._status = 1, e._result = r);
    }, function(r) {
      (e._status === 0 || e._status === -1) && (e._status = 2, e._result = r);
    }), e._status === -1 && (e._status = 0, e._result = t);
  }
  if (e._status === 1) return e._result.default;
  throw e._result;
}
var ct = { current: null }, ci = { transition: null }, ev = { ReactCurrentDispatcher: ct, ReactCurrentBatchConfig: ci, ReactCurrentOwner: $s };
he.Children = { map: ni, forEach: function(e, t, r) {
  ni(e, function() {
    t.apply(this, arguments);
  }, r);
}, count: function(e) {
  var t = 0;
  return ni(e, function() {
    t++;
  }), t;
}, toArray: function(e) {
  return ni(e, function(t) {
    return t;
  }) || [];
}, only: function(e) {
  if (!ea(e)) throw Error("React.Children.only expected to receive a single React element child.");
  return e;
} };
he.Component = yn;
he.Fragment = Bd;
he.Profiler = Ud;
he.PureComponent = Zs;
he.StrictMode = Gd;
he.Suspense = Kd;
he.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ev;
he.cloneElement = function(e, t, r) {
  if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
  var n = cl({}, e.props), i = e.key, s = e.ref, a = e._owner;
  if (t != null) {
    if (t.ref !== void 0 && (s = t.ref, a = $s.current), t.key !== void 0 && (i = "" + t.key), e.type && e.type.defaultProps) var u = e.type.defaultProps;
    for (l in t) dl.call(t, l) && !vl.hasOwnProperty(l) && (n[l] = t[l] === void 0 && u !== void 0 ? u[l] : t[l]);
  }
  var l = arguments.length - 2;
  if (l === 1) n.children = r;
  else if (1 < l) {
    u = Array(l);
    for (var c = 0; c < l; c++) u[c] = arguments[c + 2];
    n.children = u;
  }
  return { $$typeof: Kn, type: e.type, key: i, ref: s, props: n, _owner: a };
};
he.createContext = function(e) {
  return e = { $$typeof: Jd, _currentValue: e, _currentValue2: e, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null }, e.Provider = { $$typeof: Wd, _context: e }, e.Consumer = e;
};
he.createElement = hl;
he.createFactory = function(e) {
  var t = hl.bind(null, e);
  return t.type = e, t;
};
he.createRef = function() {
  return { current: null };
};
he.forwardRef = function(e) {
  return { $$typeof: qd, render: e };
};
he.isValidElement = ea;
he.lazy = function(e) {
  return { $$typeof: Yd, _payload: { _status: -1, _result: e }, _init: $d };
};
he.memo = function(e, t) {
  return { $$typeof: Hd, type: e, compare: t === void 0 ? null : t };
};
he.startTransition = function(e) {
  var t = ci.transition;
  ci.transition = {};
  try {
    e();
  } finally {
    ci.transition = t;
  }
};
he.unstable_act = function() {
  throw Error("act(...) is not supported in production builds of React.");
};
he.useCallback = function(e, t) {
  return ct.current.useCallback(e, t);
};
he.useContext = function(e) {
  return ct.current.useContext(e);
};
he.useDebugValue = function() {
};
he.useDeferredValue = function(e) {
  return ct.current.useDeferredValue(e);
};
he.useEffect = function(e, t) {
  return ct.current.useEffect(e, t);
};
he.useId = function() {
  return ct.current.useId();
};
he.useImperativeHandle = function(e, t, r) {
  return ct.current.useImperativeHandle(e, t, r);
};
he.useInsertionEffect = function(e, t) {
  return ct.current.useInsertionEffect(e, t);
};
he.useLayoutEffect = function(e, t) {
  return ct.current.useLayoutEffect(e, t);
};
he.useMemo = function(e, t) {
  return ct.current.useMemo(e, t);
};
he.useReducer = function(e, t, r) {
  return ct.current.useReducer(e, t, r);
};
he.useRef = function(e) {
  return ct.current.useRef(e);
};
he.useState = function(e) {
  return ct.current.useState(e);
};
he.useSyncExternalStore = function(e, t, r) {
  return ct.current.useSyncExternalStore(e, t, r);
};
he.useTransition = function() {
  return ct.current.useTransition();
};
he.version = "18.2.0";
var tv = /* @__PURE__ */ W('<div class="mt-2 inline-flex rounded-md border border-zinc-200 bg-white p-0.5 text-xs dark:border-zinc-800 dark:bg-zinc-900"><button type="button">Editable Data</button> <button type="button">Saved Payload</button></div>'), rv = /* @__PURE__ */ W('<p class="text-xs font-medium text-red-500">Clipboard copy failed. Try copying manually.</p>'), nv = /* @__PURE__ */ W('<div class="flex flex-col gap-3 md:flex-row md:items-start md:justify-between"><div><!> <!> <!></div> <div class="flex flex-col items-stretch gap-2 sm:flex-row sm:items-center"><!> <!></div></div> <!>', 1), iv = /* @__PURE__ */ W('<div class="viewer-shell rounded-xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 svelte-1dq45ol"><!></div>'), sv = /* @__PURE__ */ W('<div class="diff-legend svelte-1dq45ol" role="note"><span class="legend-item svelte-1dq45ol"><span class="legend-swatch legend-swatch-added svelte-1dq45ol"></span> New value</span> <span class="legend-item svelte-1dq45ol"><span class="legend-swatch legend-swatch-removed svelte-1dq45ol"></span> Removed value</span></div>'), av = /* @__PURE__ */ W("<!> <!>", 1), ov = /* @__PURE__ */ W("<!> <!>", 1);
function ta(e, t) {
  Ae(t, !0);
  const r = Y(t, "dirty", 3, !1);
  Y(t, "initialMode", 3, "simple");
  let n = /* @__PURE__ */ oe(Fe("simple")), i = /* @__PURE__ */ oe("data"), s = /* @__PURE__ */ oe("idle");
  const a = /* @__PURE__ */ U(() => !!(t.wrappedJson || t.wrappedData)), u = (p) => {
    if (!o(a)) {
      k(i, "data");
      return;
    }
    k(i, p, !0);
  };
  Ye(() => {
    o(a) || k(i, "data");
  });
  const l = /* @__PURE__ */ U(() => o(i) === "data" ? t.rawJson : t.wrappedJson ?? t.rawJson), c = /* @__PURE__ */ U(() => o(i) === "data" ? t.data : t.wrappedData ?? t.data), f = /* @__PURE__ */ U(() => o(i) === "data" ? r() : !1), h = /* @__PURE__ */ U(() => o(i) === "data" ? t.baselineData : void 0), g = async () => {
    const p = o(l) ?? (o(c) !== void 0 ? JSON.stringify(o(c), null, 2) : void 0);
    if (p)
      try {
        await navigator.clipboard.writeText(p), k(s, "copied"), setTimeout(
          () => {
            k(s, "idle");
          },
          1800
        );
      } catch {
        k(s, "error");
      }
  };
  var m = _e(), d = $(m);
  ze(d, () => qs, (p, b) => {
    b(p, {
      children: (C, O) => {
        var E = ov(), x = $(E);
        ze(x, () => Ys, (P, j) => {
          j(P, {
            children: (N, I) => {
              var ne = nv(), Z = $(ne), ie = V(Z), fe = V(ie);
              ze(fe, () => Xs, (D, G) => {
                G(D, {
                  children: (X, le) => {
                    var ae = Te("Config Preview");
                    S(X, ae);
                  },
                  $$slots: { default: !0 }
                });
              });
              var R = K(fe, 2);
              ze(R, () => Hs, (D, G) => {
                G(D, {
                  children: (X, le) => {
                    var ae = Te("Inspect the selected file in a formatted tree.");
                    S(X, ae);
                  },
                  $$slots: { default: !0 }
                });
              });
              var _ = K(R, 2);
              {
                var w = (D) => {
                  var G = tv(), X = V(G);
                  let le;
                  X.__click = () => u("data");
                  var ae = K(X, 2);
                  let se;
                  ae.__click = () => u("wrapped"), ge(() => {
                    le = wt(X, 1, "viewer-toggle svelte-1dq45ol", null, le, { "viewer-toggle-active": o(i) === "data" }), se = wt(ae, 1, "viewer-toggle svelte-1dq45ol", null, se, { "viewer-toggle-active": o(i) === "wrapped" });
                  }), S(D, G);
                };
                ee(_, (D) => {
                  o(a) && D(w);
                });
              }
              var A = K(ie, 2), y = V(A);
              ee(y, (D) => {
              });
              var z = K(y, 2);
              {
                let D = /* @__PURE__ */ U(() => o(c) === void 0 && !o(l));
                lr(z, {
                  variant: "outline",
                  size: "sm",
                  onclick: g,
                  get disabled() {
                    return o(D);
                  },
                  children: (G, X) => {
                    var le = Te();
                    ge(() => ye(le, o(s) === "copied" ? "Copied!" : "Copy JSON")), S(G, le);
                  },
                  $$slots: { default: !0 }
                });
              }
              var F = K(Z, 2);
              {
                var L = (D) => {
                  var G = rv();
                  S(D, G);
                };
                ee(F, (D) => {
                  o(s) === "error" && D(L);
                });
              }
              S(N, ne);
            },
            $$slots: { default: !0 }
          });
        });
        var M = K(x, 2);
        ze(M, () => Ks, (P, j) => {
          j(P, {
            class: "space-y-4",
            children: (N, I) => {
              var ne = av(), Z = $(ne);
              {
                var ie = (_) => {
                  var w = iv(), A = V(w);
                  {
                    let y = /* @__PURE__ */ U(() => o(f) ? o(h) : void 0), z = /* @__PURE__ */ U(() => o(i) === "wrapped");
                    ol(A, {
                      get data() {
                        return o(c);
                      },
                      get baseline() {
                        return o(y);
                      },
                      get dirty() {
                        return o(f);
                      },
                      depth: 3,
                      get preserveKeyOrder() {
                        return o(z);
                      }
                    });
                  }
                  S(_, w);
                };
                ee(Z, (_) => {
                  o(n), _(ie);
                });
              }
              var fe = K(Z, 2);
              {
                var R = (_) => {
                  var w = sv();
                  S(_, w);
                };
                ee(fe, (_) => {
                  o(f) && o(h) && _(R);
                });
              }
              S(N, ne);
            },
            $$slots: { default: !0 }
          });
        }), S(C, E);
      },
      $$slots: { default: !0 }
    });
  }), S(e, m), Ce();
}
zi(["click"]);
function lv(e, t) {
  Ae(t, !0);
  /**
   * @license @lucide/svelte v0.544.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   * ---
   *
   * The MIT License (MIT) (for portions derived from Feather)
   *
   * Copyright (c) 2013-2023 Cole Bemis
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   *
   */
  let r = /* @__PURE__ */ De(t, ["$$slots", "$$events", "$$legacy"]);
  const n = [
    ["path", { d: "M18 6 6 18" }],
    ["path", { d: "m6 6 12 12" }]
  ];
  Js(e, Gr(
    { name: "x" },
    () => r,
    {
      get iconNode() {
        return n;
      },
      children: (i, s) => {
        var a = _e(), u = $(a);
        Ve(u, () => t.children ?? lt), S(i, a);
      },
      $$slots: { default: !0 }
    }
  )), Ce();
}
var cv = /* @__PURE__ */ W("<!> <!>", 1), uv = /* @__PURE__ */ W("<span> </span>"), fv = /* @__PURE__ */ W('<div class="mt-1 flex flex-wrap items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400"><!> <!> <!> <span> </span></div>'), dv = /* @__PURE__ */ W('<p class="text-xs text-zinc-500 dark:text-zinc-400"> </p>'), vv = /* @__PURE__ */ W('<span class="sr-only">Remove</span> <!>', 1), hv = /* @__PURE__ */ W('<div class="space-y-3"><div class="flex items-center justify-between rounded-lg border border-zinc-200 bg-white p-3 text-sm shadow-sm dark:border-zinc-700 dark:bg-zinc-900"><div><p class="font-medium text-zinc-800 dark:text-zinc-100"> </p> <!></div> <div class="flex gap-2"><!> <!></div></div> <!></div>'), gv = /* @__PURE__ */ W('<div class="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-600 dark:border-red-500/40 dark:bg-red-950/40 dark:text-red-200"><strong class="font-semibold">Upload error:</strong> <span class="ml-2"> </span></div>'), pv = /* @__PURE__ */ W('<div class="space-y-4"><!> <!></div>'), mv = /* @__PURE__ */ W("<!> <!>", 1);
function bv(e, t) {
  Ae(t, !0);
  var r = _e(), n = $(r);
  ze(n, () => qs, (i, s) => {
    s(i, {
      children: (a, u) => {
        var l = mv(), c = $(l);
        ze(c, () => Ys, (h, g) => {
          g(h, {
            children: (m, d) => {
              var p = cv(), b = $(p);
              ze(b, () => Xs, (O, E) => {
                E(O, {
                  children: (x, M) => {
                    var P = Te("Browse Configs");
                    S(x, P);
                  },
                  $$slots: { default: !0 }
                });
              });
              var C = K(b, 2);
              ze(C, () => Hs, (O, E) => {
                E(O, {
                  children: (x, M) => {
                    var P = Te("Select a config file to view before loading.");
                    S(x, P);
                  },
                  $$slots: { default: !0 }
                });
              }), S(m, p);
            },
            $$slots: { default: !0 }
          });
        });
        var f = K(c, 2);
        ze(f, () => Ks, (h, g) => {
          g(h, {
            children: (m, d) => {
              var p = pv(), b = V(p);
              {
                var C = (M) => {
                  {
                    let P = /* @__PURE__ */ U(() => t.file ? 1 : 0);
                    Cd(M, {
                      get maxFiles() {
                        return t.maxFiles;
                      },
                      get fileCount() {
                        return o(P);
                      },
                      get onUpload() {
                        return t.onUpload;
                      },
                      get onFileRejected() {
                        return t.onFileRejected;
                      }
                    });
                  }
                }, O = (M) => {
                  var P = hv(), j = V(P), N = V(j), I = V(N), ne = V(I), Z = K(I, 2);
                  {
                    var ie = (y) => {
                      var z = fv(), F = V(z);
                      {
                        var L = (me) => {
                          var we = uv(), xe = V(we);
                          ge(() => ye(xe, `Saved ${t.savedAtLabel ?? ""}`)), S(me, we);
                        };
                        ee(F, (me) => {
                          t.savedAtLabel && me(L);
                        });
                      }
                      var D = K(F, 2);
                      {
                        var G = (me) => {
                          Cr(me, {
                            variant: "secondary",
                            class: "px-2 py-0.5 text-[0.65rem]",
                            children: (we, xe) => {
                              var Me = Te();
                              ge(() => ye(Me, t.versionLabel)), S(we, Me);
                            },
                            $$slots: { default: !0 }
                          });
                        };
                        ee(D, (me) => {
                          t.versionLabel && me(G);
                        });
                      }
                      var X = K(D, 2);
                      {
                        var le = (me) => {
                          Cr(me, {
                            variant: "secondary",
                            class: "bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-200",
                            children: (we, xe) => {
                              var Me = Te("Unsaved changes");
                              S(we, Me);
                            },
                            $$slots: { default: !0 }
                          });
                        };
                        ee(X, (me) => {
                          t.dirty && me(le);
                        });
                      }
                      var ae = K(X, 2), se = V(ae);
                      ge((me) => ye(se, me), [() => pi(t.file.size)]), S(y, z);
                    }, fe = (y) => {
                      var z = dv(), F = V(z);
                      ge((L) => ye(F, `${L ?? ""} · ${(t.file.type || "unknown type") ?? ""}`), [() => pi(t.file.size)]), S(y, z);
                    };
                    ee(Z, (y) => {
                      t.savedAtLabel || t.versionLabel ? y(ie) : y(fe, !1);
                    });
                  }
                  var R = K(N, 2), _ = V(R);
                  {
                    let y = /* @__PURE__ */ U(() => !t.rawContents || t.disableLoad);
                    lr(_, {
                      variant: "ghost",
                      class: "w-30 bg-slate-50 shadow-sm",
                      get onclick() {
                        return t.onLoad;
                      },
                      get disabled() {
                        return o(y);
                      },
                      children: (z, F) => {
                        var L = Te();
                        ge(() => ye(L, t.disableLoad ? "Loaded" : "Load")), S(z, L);
                      },
                      $$slots: { default: !0 }
                    });
                  }
                  var w = K(_, 2);
                  lr(w, {
                    variant: "ghost",
                    size: "icon",
                    class: "bg-red-100 shadow-sm",
                    get onclick() {
                      return t.onRemove;
                    },
                    children: (y, z) => {
                      var F = vv(), L = K($(F), 2);
                      lv(L, { class: "size-4" }), S(y, F);
                    },
                    $$slots: { default: !0 }
                  });
                  var A = K(j, 2);
                  ta(A, {
                    get data() {
                      return t.parsedContents;
                    },
                    get rawJson() {
                      return t.rawContents;
                    },
                    get baselineData() {
                      return t.baselineContents;
                    },
                    get dirty() {
                      return t.dirty;
                    },
                    get wrappedJson() {
                      return t.wrappedContents;
                    },
                    get wrappedData() {
                      return t.wrappedParsed;
                    }
                  }), ge(() => ye(ne, t.file.name)), S(M, P);
                };
                ee(b, (M) => {
                  t.file ? M(O, !1) : M(C);
                });
              }
              var E = K(b, 2);
              {
                var x = (M) => {
                  var P = gv(), j = K(V(P), 2), N = V(j);
                  ge(() => ye(N, t.error)), S(M, P);
                };
                ee(E, (M) => {
                  t.error && M(x);
                });
              }
              S(m, p);
            },
            $$slots: { default: !0 }
          });
        }), S(a, l);
      },
      $$slots: { default: !0 }
    });
  }), S(e, r), Ce();
}
var _v = /* @__PURE__ */ W("<span> </span>"), yv = /* @__PURE__ */ W('<div class="mt-1 flex flex-wrap items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400"><!> <!> <!></div>'), wv = /* @__PURE__ */ W('<div class="space-y-3 rounded-lg border border-zinc-200 bg-white p-4 shadow-sm dark:border-zinc-800 dark:bg-zinc-900"><div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><p class="text-base font-semibold text-zinc-900 dark:text-zinc-100"> </p> <!></div> <div class="flex gap-2"><!> <!></div></div> <!></div>');
function xv(e, t) {
  var r = wv(), n = V(r), i = V(n), s = V(i), a = V(s), u = K(s, 2);
  {
    var l = (d) => {
      var p = yv(), b = V(p);
      {
        var C = (P) => {
          var j = _v(), N = V(j);
          ge(() => ye(N, `Saved ${t.savedAtLabel ?? ""}`)), S(P, j);
        };
        ee(b, (P) => {
          t.savedAtLabel && P(C);
        });
      }
      var O = K(b, 2);
      {
        var E = (P) => {
          Cr(P, {
            variant: "secondary",
            class: "px-2 py-0.5 text-[0.65rem]",
            children: (j, N) => {
              var I = Te();
              ge(() => ye(I, t.versionLabel)), S(j, I);
            },
            $$slots: { default: !0 }
          });
        };
        ee(O, (P) => {
          t.versionLabel && P(E);
        });
      }
      var x = K(O, 2);
      {
        var M = (P) => {
          Cr(P, {
            variant: "secondary",
            class: "bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-200",
            children: (j, N) => {
              var I = Te("Unsaved changes");
              S(j, I);
            },
            $$slots: { default: !0 }
          });
        };
        ee(x, (P) => {
          t.dirty && P(M);
        });
      }
      S(d, p);
    };
    ee(u, (d) => {
      (t.savedAtLabel || t.versionLabel) && d(l);
    });
  }
  var c = K(i, 2), f = V(c);
  {
    var h = (d) => {
      lr(d, {
        variant: "outline",
        get onclick() {
          return t.onManage;
        },
        children: (p, b) => {
          var C = Te("Manage Configs");
          S(p, C);
        },
        $$slots: { default: !0 }
      });
    };
    ee(f, (d) => {
      t.onManage && d(h);
    });
  }
  var g = K(f, 2);
  lr(g, {
    variant: "outline",
    get onclick() {
      return t.onClose;
    },
    children: (d, p) => {
      var b = Te("Close");
      S(d, b);
    },
    $$slots: { default: !0 }
  });
  var m = K(n, 2);
  ta(m, {
    get data() {
      return t.parsedContents;
    },
    get rawJson() {
      return t.rawContents;
    },
    get baselineData() {
      return t.baselineContents;
    },
    get dirty() {
      return t.dirty;
    },
    get wrappedJson() {
      return t.wrappedContents;
    },
    get wrappedData() {
      return t.wrappedParsed;
    }
  }), ge(() => ye(a, t.fileName ?? "Loaded configuration")), S(e, r);
}
function Ga(e) {
  if (!e || typeof e != "object" || Array.isArray(e))
    return { data: {}, metadata: {} };
  const t = e, r = t.data;
  let n;
  const i = t.metadata, s = i && typeof i == "object" && !Array.isArray(i) ? { ...i } : {};
  r && typeof r == "object" && !Array.isArray(r) ? n = r : t.selections && typeof t.selections == "object" && !Array.isArray(t.selections) ? n = { selections: t.selections } : n = Object.fromEntries(
    Object.entries(t).filter(
      ([f]) => f !== "version" && f !== "saved_at" && f !== "metadata"
    )
  );
  const a = s.version ?? t.version, u = s.saved_at ?? t.saved_at, l = typeof a == "string" ? a : typeof a == "number" ? String(a) : void 0;
  return {
    data: n,
    metadata: s,
    version: l,
    savedAt: typeof u == "string" ? u : void 0
  };
}
function Pn({
  data: e,
  version: t,
  savedAt: r,
  metadata: n
}) {
  const i = n ? { ...n } : {};
  return t && t.trim().length > 0 && (i.version = t), r && r.trim().length > 0 && (i.saved_at = r), {
    metadata: i,
    data: e
  };
}
function Hi(e) {
  if (typeof e != "string" || e.trim().length === 0)
    return;
  const t = new Date(e);
  return Number.isNaN(t.getTime()) ? e : new Intl.DateTimeFormat(void 0, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(t);
}
const Wr = (e) => typeof e == "string" ? e : e ?? "", gl = (e, t) => {
  if (!Array.isArray(e)) return [];
  const r = e.filter(
    (i) => i && typeof i.name == "string" && typeof i.size == "number" && typeof i.type == "string"
  ).map((i) => ({
    name: i.name,
    size: i.size,
    type: i.type
  })), n = r.length;
  return r.slice(0, n);
}, kv = (e) => {
  if (!(e != null && e.files)) return [];
  try {
    const t = JSON.parse(e.files);
    return gl(t);
  } catch {
    return [];
  }
}, Sv = (e, t) => {
  const r = gl(t);
  e.files = JSON.stringify(r), e.file_count = r.length;
}, Av = (e, t) => {
  e.current_state = Wr(t);
}, pl = (e, t) => {
  e.baseline_state = Wr(t);
}, ys = (e, t) => {
  e.version = Wr(t);
}, ml = (e, t) => {
  e.config_file = Wr(t);
}, ws = (e, t) => {
  e.config_file_display = Wr(t);
}, bl = (e, t) => {
  e.saved_at = Wr(t);
}, ir = (e, t) => {
  e.error = Wr(t);
};
function Cv({
  bindings: e,
  maxFiles: t
}) {
  const r = Number.isFinite(t) ? t : void 0, n = (c) => r ? c.slice(0, r) : c, i = () => kv(e), s = (c) => {
    Sv(e, n(c));
  };
  return {
    bindings: e,
    readBoundFiles: i,
    writeBoundFiles: s,
    handleUpload: async (c) => {
      const f = c.slice(0, r ?? c.length).map((h) => ({
        name: h.name,
        size: h.size,
        type: h.type
      }));
      f.length !== 0 && (s(f), ir(e, ""));
    },
    handleFileRejected: ({ reason: c, file: f }) => {
      ir(e, `${f.name}: ${c}`);
    },
    removeFile: (c) => {
      const f = i();
      f.splice(c, 1), s(f), f.length === 0 && ir(e, "");
    },
    writeCurrentState: (c) => Av(e, c),
    writeBaselineState: (c) => pl(e, c),
    writeVersion: (c) => ys(e, c),
    writeConfigFile: (c) => ml(e, c),
    writeConfigFileDisplay: (c) => ws(e, c),
    writeSavedAt: (c) => bl(e, c),
    writeError: (c) => ir(e, c)
  };
}
var Ev = /* @__PURE__ */ W("<!> <!>", 1), Pv = /* @__PURE__ */ W(`<p>Default file name: <span class="font-medium text-zinc-900 dark:text-zinc-100"> </span>. You'll choose the folder after clicking <span class="font-medium">Save</span>.</p>`), Tv = /* @__PURE__ */ W('<p>Download name: <span class="font-medium text-zinc-900 dark:text-zinc-100"> </span>. Your browser will download the file directly.</p>'), zv = /* @__PURE__ */ W('<p class="text-sm text-emerald-600 dark:text-emerald-400"> </p>'), Mv = /* @__PURE__ */ W('<p class="text-sm text-red-500 dark:text-red-400"> </p>'), Nv = /* @__PURE__ */ W('<div class="space-y-2"><label class="text-sm font-medium text-zinc-600 dark:text-zinc-300">Version</label> <input class="w-full rounded-md border border-zinc-200 bg-white px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:cursor-not-allowed disabled:opacity-70 dark:border-zinc-700 dark:bg-zinc-900" placeholder="e.g. 1.0.0"/></div> <div class="rounded-md border border-zinc-100 bg-zinc-50 px-3 py-2 text-xs text-zinc-600 dark:border-zinc-800 dark:bg-zinc-900/60 dark:text-zinc-300"><!></div> <div class="flex flex-wrap items-center gap-3"><!></div> <div class="flex flex-wrap gap-2"><!></div> <!> <!> <!>', 1), Rv = /* @__PURE__ */ W("<!> <!>", 1);
function jv(e, t) {
  Ae(t, !0);
  const r = Y(t, "defaultFileName", 3, "config.json"), n = Y(t, "dirty", 3, !1), i = Y(t, "currentVersion", 3, ""), s = Y(t, "canEditVersion", 3, !1), a = (_) => {
    if (!_) return !1;
    const w = _.trim();
    return w ? w.startsWith("/") || w.startsWith("\\") || /^[A-Za-z]:[\\/]/.test(w) : !1;
  }, u = (_) => {
    if (!_) return;
    const w = _.trim();
    if (!w) return;
    const A = w.split(/[\\/]+/).filter(Boolean);
    return A.length > 0 ? A[A.length - 1] : w;
  }, l = (_) => {
    var D;
    if (!_) return "";
    const w = _.trim();
    if (!w) return "";
    const A = (D = w.match(/^[A-Za-z]:[\\/]/)) == null ? void 0 : D[0], y = w.includes("\\") && !w.includes("/") ? "\\" : "/", z = w.replace(/[\\/]+/g, y), F = z.split(y);
    if (F.length <= 1)
      return A ?? (z.startsWith(y) ? y : "");
    F.pop();
    let L = F.join(y);
    return A && !L.startsWith(A) ? L = `${A}${L}` : z.startsWith(y) && !L.startsWith(y) && (L = `${y}${L}`), L;
  }, c = (_, w) => {
    if (!_) return w;
    const A = _.includes("\\") && !_.includes("/") ? "\\" : "/";
    return `${_ === A || _.endsWith(A) ? _ : `${_}${A}`}${w}`;
  }, f = (_, w) => {
    const A = _ == null ? void 0 : _.trim();
    if (!A)
      return (w == null ? void 0 : w.trim()) ?? "";
    if (a(A))
      return A;
    const y = (w == null ? void 0 : w.trim()) ?? "";
    if (y && a(y)) {
      const z = l(y);
      if (z)
        return c(z, A);
    }
    return A;
  };
  let h = /* @__PURE__ */ oe(Fe(r())), g = /* @__PURE__ */ oe(""), m = /* @__PURE__ */ oe(""), d = /* @__PURE__ */ oe(!1), p = /* @__PURE__ */ oe(Fe(i()));
  const b = /* @__PURE__ */ U(() => {
    if (t.rawConfig)
      try {
        return JSON.parse(t.rawConfig);
      } catch {
        return;
      }
  }), C = (_) => {
    const w = _ == null ? void 0 : _.trim();
    if (w && a(w))
      return w;
  }, O = (_, w) => {
    const A = C(_);
    if (A)
      return { save_path: A };
    const y = w == null ? void 0 : w.trim();
    if (y)
      return { save_path: y };
  }, E = /* @__PURE__ */ U(() => {
    var z, F;
    if (!o(b) || typeof o(b) != "object" || Array.isArray(o(b)))
      return;
    const _ = ((z = o(p)) == null ? void 0 : z.trim()) || ((F = i()) == null ? void 0 : F.trim()) || void 0, w = t.bindings.config_file_display || t.bindings.config_file || r() || o(h), A = O(t.bindings.config_file, w), y = Pn({
      data: o(b),
      version: _,
      savedAt: void 0,
      metadata: A
    });
    return { json: JSON.stringify(y, null, 2), data: y };
  }), x = typeof window < "u" ? window : void 0, M = !!(x != null && x.showSaveFilePicker), P = `config-version-${Math.random().toString(36).slice(2)}`, j = /* @__PURE__ */ U(() => {
    var A, y;
    const _ = (A = t.saveTargetLabel) == null ? void 0 : A.trim();
    if (_) return _;
    const w = (y = r()) == null ? void 0 : y.trim();
    return w || "config.json";
  });
  Ye(() => {
    r() && !o(h) && k(h, r());
  });
  let N = /* @__PURE__ */ oe(Fe(r()));
  Ye(() => {
    r() !== o(N) && (k(h, r()), k(N, r()));
  }), Ye(() => {
    k(p, i() ?? "", !0);
  });
  const I = () => ({ suggestedName: o(h) || r() }), ne = async () => {
    if (!M || !(x != null && x.showSaveFilePicker)) return null;
    try {
      const _ = await x.showSaveFilePicker(I());
      return _.name && k(h, _.name, !0), k(m, ""), _;
    } catch (_) {
      if (_.name === "AbortError")
        return null;
      const w = (_ == null ? void 0 : _.message) ?? "Unable to choose file location.";
      return k(m, w, !0), ir(t.bindings, w), null;
    }
  }, Z = (_, w) => {
    const A = new Blob([_], { type: "application/json" }), y = URL.createObjectURL(A), z = document.createElement("a");
    z.href = y, z.download = w, z.click(), URL.revokeObjectURL(y);
  }, ie = async () => {
    var xe, Me, Qe;
    const _ = t.bindings.current_state ?? t.rawConfig;
    if (!_) {
      k(m, "No config data available to save."), ir(t.bindings, o(m));
      return;
    }
    const w = o(b) && typeof o(b) == "object" && !Array.isArray(o(b)) ? o(b) : void 0;
    if (!w) {
      k(m, "Config JSON must be an object."), ir(t.bindings, o(m));
      return;
    }
    k(m, ""), k(g, "");
    const A = (/* @__PURE__ */ new Date()).toISOString(), y = (xe = o(p)) == null ? void 0 : xe.trim(), z = (Me = i()) == null ? void 0 : Me.trim(), F = y || z || "default_v0";
    (t.bindings.version ?? "") !== F && (ys(t.bindings, F), k(p, F, !0));
    const L = o(h) || r(), D = f(L, t.bindings.config_file ?? void 0), G = D || "config.json", X = u(D) ?? L ?? G, le = (Q) => {
      const je = O(D, Q ?? X), $e = Pn({
        data: w,
        version: F,
        savedAt: A,
        metadata: je
      });
      return {
        metadataEntry: je,
        label: Q ?? X,
        serialized: `${JSON.stringify($e, null, 2)}
`
      };
    };
    let { serialized: ae, label: se } = le(X);
    const me = se || G, we = (Q) => {
      const je = t.bindings.current_state ?? _ ?? "";
      pl(t.bindings, je);
      const $e = (Q == null ? void 0 : Q.absolutePath) ?? D, ut = (Q == null ? void 0 : Q.label) ?? ($e ? u($e) : void 0) ?? me;
      return $e && a($e) ? (ml(t.bindings, $e), ws(t.bindings, ut)) : ut && ws(t.bindings, ut), bl(t.bindings, A), ir(t.bindings, ""), ut;
    };
    if (!M) {
      Z(ae, me);
      const Q = we({ label: se });
      k(g, `Downloaded ${Q}`);
      return;
    }
    try {
      k(d, !0);
      const Q = await ne();
      if (!Q) {
        k(d, !1);
        return;
      }
      await ((Qe = Q.requestPermission) == null ? void 0 : Qe.call(Q, { mode: "readwrite" })), se = Q.name ?? se, { serialized: ae } = le(se);
      const je = await Q.createWritable();
      try {
        const T = new Blob([ae], { type: "application/json" });
        await je.write(T), await je.close();
      } catch (T) {
        throw typeof je.abort == "function" && await je.abort(), T;
      }
      const ut = we({ label: se }) ?? se ?? me;
      k(g, `Saved ${ut} at ${new Date(A).toLocaleString()}`), Q.name && k(h, Q.name, !0), k(m, "");
    } catch (Q) {
      const je = (Q == null ? void 0 : Q.message) ?? "Failed to save config.";
      k(m, je, !0), ir(t.bindings, je);
    } finally {
      k(d, !1);
    }
  };
  var fe = _e(), R = $(fe);
  ze(R, () => qs, (_, w) => {
    w(_, {
      children: (A, y) => {
        var z = Rv(), F = $(z);
        ze(F, () => Ys, (D, G) => {
          G(D, {
            children: (X, le) => {
              var ae = Ev(), se = $(ae);
              ze(se, () => Xs, (we, xe) => {
                xe(we, {
                  children: (Me, Qe) => {
                    var Q = Te("Save Config");
                    S(Me, Q);
                  },
                  $$slots: { default: !0 }
                });
              });
              var me = K(se, 2);
              ze(me, () => Hs, (we, xe) => {
                xe(we, {
                  children: (Me, Qe) => {
                    var Q = _e(), je = $(Q);
                    {
                      var $e = (T) => {
                        var B = Te("Choose where to write the modified configuration.");
                        S(T, B);
                      }, ut = (T) => {
                        var B = Te("Config matches the last saved version.");
                        S(T, B);
                      };
                      ee(je, (T) => {
                        n() ? T($e) : T(ut, !1);
                      });
                    }
                    S(Me, Q);
                  },
                  $$slots: { default: !0 }
                });
              }), S(X, ae);
            },
            $$slots: { default: !0 }
          });
        });
        var L = K(F, 2);
        ze(L, () => Ks, (D, G) => {
          G(D, {
            class: "space-y-4",
            children: (X, le) => {
              var ae = Nv(), se = $(ae), me = V(se), we = K(me, 2);
              we.__input = (de) => {
                const pe = de.target.value;
                k(p, pe, !0);
                const Ee = pe.trim();
                ys(t.bindings, Ee || "");
              };
              var xe = K(se, 2), Me = V(xe);
              {
                var Qe = (de) => {
                  var pe = Pv(), Ee = K(V(pe)), Se = V(Ee);
                  ge(() => ye(Se, o(j))), S(de, pe);
                }, Q = (de) => {
                  var pe = Tv(), Ee = K(V(pe)), Se = V(Ee);
                  ge(() => ye(Se, o(j))), S(de, pe);
                };
                ee(Me, (de) => {
                  M ? de(Qe) : de(Q, !1);
                });
              }
              var je = K(xe, 2), $e = V(je);
              {
                var ut = (de) => {
                  Cr(de, {
                    variant: "secondary",
                    class: "bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-200",
                    children: (pe, Ee) => {
                      var Se = Te("Unsaved changes");
                      S(pe, Se);
                    },
                    $$slots: { default: !0 }
                  });
                }, T = (de) => {
                  Cr(de, {
                    variant: "secondary",
                    children: (pe, Ee) => {
                      var Se = Te("Up to date");
                      S(pe, Se);
                    },
                    $$slots: { default: !0 }
                  });
                };
                ee($e, (de) => {
                  n() ? de(ut) : de(T, !1);
                });
              }
              var B = K(je, 2), re = V(B);
              {
                let de = /* @__PURE__ */ U(() => !t.rawConfig || o(d));
                lr(re, {
                  onclick: ie,
                  get disabled() {
                    return o(de);
                  },
                  children: (pe, Ee) => {
                    var Se = Te();
                    ge(() => ye(Se, o(d) ? "Saving…" : M ? "Save" : "Download")), S(pe, Se);
                  },
                  $$slots: { default: !0 }
                });
              }
              var ke = K(B, 2);
              {
                var Ie = (de) => {
                  var pe = zv(), Ee = V(pe);
                  ge(() => ye(Ee, o(g))), S(de, pe);
                };
                ee(ke, (de) => {
                  o(g) && de(Ie);
                });
              }
              var Re = K(ke, 2);
              {
                var Ue = (de) => {
                  var pe = Mv(), Ee = V(pe);
                  ge(() => ye(Ee, o(m))), S(de, pe);
                };
                ee(Re, (de) => {
                  o(m) && de(Ue);
                });
              }
              var Ke = K(Re, 2);
              {
                let de = /* @__PURE__ */ U(() => {
                  var Ee;
                  return (Ee = o(E)) == null ? void 0 : Ee.json;
                }), pe = /* @__PURE__ */ U(() => {
                  var Ee;
                  return (Ee = o(E)) == null ? void 0 : Ee.data;
                });
                ta(Ke, {
                  get data() {
                    return o(b);
                  },
                  get rawJson() {
                    return t.rawConfig;
                  },
                  get baselineData() {
                    return t.baselineConfig;
                  },
                  get dirty() {
                    return n();
                  },
                  get wrappedJson() {
                    return o(de);
                  },
                  get wrappedData() {
                    return o(pe);
                  }
                });
              }
              ge(() => {
                gn(me, "for", P), gn(we, "id", P), $c(we, o(p)), we.disabled = !s() || !t.rawConfig;
              }), S(X, ae);
            },
            $$slots: { default: !0 }
          });
        }), S(A, z);
      },
      $$slots: { default: !0 }
    });
  }), S(e, fe), Ce();
}
zi(["input"]);
var Ov = /* @__PURE__ */ W("<!> <!>", 1), Fv = /* @__PURE__ */ W("<!> <!> <!>", 1), Iv = /* @__PURE__ */ W('<div class="space-y-4 rounded-lg border border-zinc-200 bg-white p-4 shadow-sm dark:border-zinc-800 dark:bg-zinc-900"><div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div><p class="text-lg font-semibold text-zinc-900 dark:text-zinc-100">Manage Configs</p> <p class="text-sm text-zinc-500 dark:text-zinc-400">Load a JSON config or prepare a notebook save.</p></div> <!></div> <!></div>'), Lv = /* @__PURE__ */ W("<span> </span>"), Vv = /* @__PURE__ */ W('<div class="flex flex-wrap items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400"><!> <!> <!></div>'), Dv = /* @__PURE__ */ W('<p class="text-base font-semibold text-zinc-900 dark:text-zinc-100"> </p> <!>', 1), Bv = /* @__PURE__ */ W('<p class="text-base text-zinc-600 dark:text-zinc-300">No config loaded.</p>'), Gv = /* @__PURE__ */ W('<div class="flex flex-col gap-3 rounded-lg border border-zinc-200 bg-white p-4 shadow-sm dark:border-zinc-800 dark:bg-zinc-900"><div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><div class="space-y-1"><p class="text-sm font-medium text-zinc-500 dark:text-zinc-400">Configuration</p> <!></div> <div class="flex gap-2"><!> <!></div></div></div>'), Uv = /* @__PURE__ */ W('<div class="space-y-6"><!></div>');
function Wv(e, t) {
  Ae(t, !0);
  const r = 1, n = Cv({ bindings: t.bindings, maxFiles: r }), i = (T) => {
    if (T)
      try {
        const B = JSON.parse(T);
        if (B && typeof B == "object" && !Array.isArray(B))
          return B;
      } catch {
        return;
      }
  }, s = (T) => {
    const B = i(T);
    if (B)
      try {
        return JSON.stringify(B);
      } catch {
        return (T ?? "").trim();
      }
    return (T ?? "").trim();
  }, a = () => {
    var re;
    const T = {}, B = (re = t.bindings.version) == null ? void 0 : re.trim();
    return B && (T.version = B), T;
  }, u = (T) => {
    if (!T) return "";
    const B = Object.entries(T).map(([re, ke]) => [re, typeof ke == "string" ? ke.trim() : ke]).filter((re) => !!(re[1] && re[1].length > 0));
    return B.length === 0 ? "" : (B.sort(([re], [ke]) => re.localeCompare(ke)), JSON.stringify(Object.fromEntries(B)));
  }, l = (T) => {
    if (!T) return;
    const B = T.split(/[\\/]+/).filter(Boolean);
    return B.length === 0 ? T : B[B.length - 1];
  }, c = (T) => !!(T && Object.keys(T).length > 0), f = /* @__PURE__ */ U(() => n.readBoundFiles()), h = /* @__PURE__ */ U(() => i(t.bindings.baseline_state)), g = /* @__PURE__ */ U(() => a());
  let m = /* @__PURE__ */ oe(Fe(a())), d = /* @__PURE__ */ oe(Fe(t.bindings.baseline_state ?? ""));
  const p = /* @__PURE__ */ U(() => u(o(g)) !== u(o(m))), b = /* @__PURE__ */ U(() => s(t.bindings.current_state) !== s(t.bindings.baseline_state) || o(p)), C = /* @__PURE__ */ U(() => t.bindings.version ?? ""), O = /* @__PURE__ */ U(() => !!(t.bindings.current_state && t.bindings.current_state.trim().length > 0)), E = /* @__PURE__ */ U(() => t.bindings.config_file_display || l(t.bindings.config_file) || void 0);
  let x = /* @__PURE__ */ oe(void 0), M = /* @__PURE__ */ oe(Fe(t.bindings.current_state ?? void 0)), P = /* @__PURE__ */ oe(() => {
    if (t.bindings.current_state)
      try {
        return JSON.parse(t.bindings.current_state);
      } catch {
        return;
      }
  }), j = /* @__PURE__ */ oe(Fe({}));
  const N = /* @__PURE__ */ U(() => {
    if (!(!o(P) || typeof o(P) != "object"))
      return Ga(o(P));
  }), I = /* @__PURE__ */ U(() => {
    if (o(N))
      return JSON.stringify(o(N).data, null, 2);
  }), ne = /* @__PURE__ */ U(() => {
    var T;
    return (T = o(N)) == null ? void 0 : T.data;
  });
  let Z = /* @__PURE__ */ oe(!1), ie = /* @__PURE__ */ oe("find"), fe = /* @__PURE__ */ oe(void 0), R = /* @__PURE__ */ oe(void 0), _ = /* @__PURE__ */ oe(!1), w = /* @__PURE__ */ oe(!1), A = /* @__PURE__ */ oe(void 0), y = /* @__PURE__ */ oe(Fe(t.bindings.saved_at ?? void 0));
  const z = /* @__PURE__ */ U(() => t.bindings.config_file_display || t.bindings.config_file || o(A) || o(fe) || "config.json"), F = /* @__PURE__ */ U(() => t.bindings.config_file || o(A) || o(z)), L = () => {
    var ke, Ie;
    const T = (ke = t.bindings.config_file_display) == null ? void 0 : ke.trim();
    if (T)
      return { save_path: T };
    const B = (Ie = t.bindings.config_file) == null ? void 0 : Ie.trim();
    if (B)
      return { save_path: B };
    const re = o(A) || o(fe);
    if (re)
      return { save_path: re };
  }, D = /* @__PURE__ */ U(() => c(o(j)) ? o(j) : L()), G = /* @__PURE__ */ U(() => {
    if (!o(N)) return;
    const T = c(o(N).metadata) ? o(N).metadata : o(D);
    return Pn({
      data: o(N).data,
      version: o(N).version ?? t.bindings.version ?? void 0,
      savedAt: o(N).savedAt ?? t.bindings.saved_at ?? void 0,
      metadata: T
    });
  }), X = /* @__PURE__ */ U(() => o(G) ? JSON.stringify(o(G), null, 2) : void 0);
  Ye(() => {
    var B;
    const T = (B = t.bindings.config_file) == null ? void 0 : B.trim();
    T && T !== o(A) && k(A, T, !0);
  }), Ye(() => {
    var B;
    const T = (B = t.bindings.config_file_display) == null ? void 0 : B.trim();
    T && T !== o(fe) && k(fe, T, !0);
  }), Ye(() => {
    var B, re, ke;
    const T = ((B = t.bindings.saved_at) == null ? void 0 : B.trim()) ?? "";
    if (T && T !== o(y)) {
      k(w, !1), k(_, !1), n.writeError(""), k(y, T, !0), k(m, a(), !0);
      const Ie = L();
      k(j, Ie ?? {}, !0);
      const Re = ((re = t.bindings.config_file) == null ? void 0 : re.trim()) || ((ke = t.bindings.config_file_display) == null ? void 0 : ke.trim());
      Re && k(A, Re, !0);
    } else !T && o(y) && (k(y, void 0), k(m, a(), !0), k(j, {}, !0));
  }), Ye(() => {
    const T = t.bindings.baseline_state ?? "";
    T !== o(d) && (k(d, T, !0), k(m, a(), !0));
  });
  const le = (T) => typeof TextEncoder < "u" ? new TextEncoder().encode(T).byteLength : T.length, ae = () => {
    k(x, void 0), k(M, void 0), k(P, void 0);
  };
  Ye(() => {
    if (!o(M)) {
      k(P, void 0);
      return;
    }
    try {
      k(P, JSON.parse(o(M)), !0);
    } catch {
      k(P, void 0);
    }
  }), Ye(() => {
    o(f).length === 0 && o(x) && !o(w) && ae();
  });
  const se = /* @__PURE__ */ U(() => {
    var T;
    return Hi(((T = o(N)) == null ? void 0 : T.savedAt) ?? t.bindings.saved_at);
  }), me = /* @__PURE__ */ U(() => {
    var T;
    return (T = o(N)) == null ? void 0 : T.version;
  });
  Ye(() => {
    o(Z) && k(ie, o(b) ? "save" : "find", !0);
  }), Ye(() => {
    var Ke;
    const T = t.bindings.current_state;
    if (!T || T.trim().length === 0) {
      k(R, void 0), k(j, {}, !0), k(w, !1), k(_, !1), k(fe, void 0), k(A, void 0), o(Z) || ae();
      return;
    }
    const B = i(T) ?? {}, re = (() => {
      var pe;
      const de = (pe = t.bindings.saved_at) == null ? void 0 : pe.trim();
      return de || void 0;
    })(), ke = o(D), Ie = Pn({
      data: B,
      version: t.bindings.version ?? void 0,
      savedAt: re,
      metadata: ke
    }), Re = JSON.stringify(Ie, null, 2), Ue = re ? Hi(re) : void 0;
    k(
      R,
      {
        name: o(E) || o(fe) || ((Ke = o(R)) == null ? void 0 : Ke.name) || "Config loaded",
        savedAt: Ue,
        version: t.bindings.version ?? void 0,
        rawText: T,
        parsed: B,
        wrappedRawText: Re,
        wrappedParsed: Ie
      },
      !0
    ), !o(w) && !o(Z) && (k(M, T, !0), k(P, B, !0));
  });
  const we = async (T) => {
    const [B] = T;
    if (!B) return;
    const re = await B.text();
    await n.handleUpload([B]), k(x, { name: B.name, size: B.size, type: B.type }, !0), k(M, re, !0), n.writeError(""), k(w, !1), k(j, {}, !0);
  }, xe = () => {
    if (o(w)) {
      n.writeCurrentState(""), n.writeBaselineState(""), n.writeVersion(""), n.writeConfigFile(""), n.writeConfigFileDisplay(""), n.writeSavedAt(""), k(R, void 0), k(w, !1), k(_, !1), k(fe, void 0), k(A, void 0), k(j, {}, !0), n.writeError(""), ae();
      return;
    }
    o(f).length > 0 && n.removeFile(0), n.writeError(""), ae(), k(A, void 0), n.writeConfigFileDisplay(""), n.writeSavedAt(""), k(j, {}, !0);
  }, Me = () => {
    var Ue, Ke;
    if (!o(M)) {
      n.writeError("Unable to load config: missing file contents.");
      return;
    }
    k(fe, ((Ue = o(x)) == null ? void 0 : Ue.name) ?? o(fe), !0);
    const T = o(fe) ?? ((Ke = o(x)) == null ? void 0 : Ke.name) ?? "Config loaded";
    let B;
    try {
      B = JSON.parse(o(M));
    } catch {
      n.writeError("Config is not valid JSON.");
      return;
    }
    if (!B || typeof B != "object" || Array.isArray(B)) {
      n.writeError("Config must be a JSON object.");
      return;
    }
    const re = Ga(B), ke = JSON.stringify(re.data, null, 2), Ie = Pn({
      data: re.data,
      version: re.version ?? t.bindings.version ?? void 0,
      savedAt: re.savedAt ?? void 0
    }), Re = JSON.stringify(Ie, null, 2);
    k(j, re.metadata ?? {}, !0), n.writeCurrentState(ke), n.writeBaselineState(ke), re.version && n.writeVersion(re.version), T && (n.writeConfigFile(T), n.writeConfigFileDisplay(l(T) ?? T)), n.writeSavedAt(re.savedAt ?? ""), k(
      R,
      {
        name: T,
        savedAt: re.savedAt ? Hi(re.savedAt) : void 0,
        version: re.version,
        rawText: ke,
        parsed: re.data,
        wrappedRawText: Re,
        wrappedParsed: Ie
      },
      !0
    ), k(A, T, !0), o(f).length > 0 && n.removeFile(0), n.writeError(""), ae(), k(Z, !1), k(_, !1), k(w, !1);
  };
  Ye(() => {
    var T;
    o(Z) ? (k(_, !1), !o(x) && ((T = o(R)) != null && T.rawText) && (k(w, !0), k(M, o(R).rawText, !0), k(
      x,
      {
        name: o(R).name ?? "Loaded config",
        size: le(o(R).rawText),
        type: "application/json"
      },
      !0
    ), k(P, o(R).parsed, !0))) : o(w) && (ae(), k(w, !1));
  });
  const Qe = /* @__PURE__ */ U(() => {
    var B;
    if (!((B = o(R)) != null && B.rawText)) return !1;
    const T = o(I) ?? o(M);
    return T ? T.trim() === o(R).rawText.trim() : !1;
  });
  var Q = Uv(), je = V(Q);
  {
    var $e = (T) => {
      var B = Iv(), re = V(B), ke = K(V(re), 2);
      lr(ke, {
        variant: "outline",
        onclick: () => k(Z, !1),
        children: (Re, Ue) => {
          var Ke = Te("Close");
          S(Re, Ke);
        },
        $$slots: { default: !0 }
      });
      var Ie = K(re, 2);
      ze(Ie, () => Qf, (Re, Ue) => {
        Ue(Re, {
          get value() {
            return o(ie);
          },
          set value(Ke) {
            k(ie, Ke, !0);
          },
          children: (Ke, de) => {
            var pe = Fv(), Ee = $(pe);
            ze(Ee, () => $f, (st, ft) => {
              ft(st, {
                children: (pt, Ne) => {
                  var Oe = Ov(), Le = $(Oe);
                  ze(Le, () => Oa, (mt, Rt) => {
                    Rt(mt, {
                      value: "find",
                      children: (At, hr) => {
                        var Vt = Te("Browse Configs");
                        S(At, Vt);
                      },
                      $$slots: { default: !0 }
                    });
                  });
                  var Nt = K(Le, 2);
                  ze(Nt, () => Oa, (mt, Rt) => {
                    Rt(mt, {
                      value: "save",
                      children: (At, hr) => {
                        var Vt = Te("Save Config");
                        S(At, Vt);
                      },
                      $$slots: { default: !0 }
                    });
                  }), S(pt, Oe);
                },
                $$slots: { default: !0 }
              });
            });
            var Se = K(Ee, 2);
            ze(Se, () => ja, (st, ft) => {
              ft(st, {
                value: "find",
                children: (pt, Ne) => {
                  {
                    let Oe = /* @__PURE__ */ U(() => o(I) ?? o(M)), Le = /* @__PURE__ */ U(() => o(X) ?? o(M)), Nt = /* @__PURE__ */ U(() => o(G) ?? o(P));
                    bv(pt, {
                      get file() {
                        return o(x);
                      },
                      get rawContents() {
                        return o(Oe);
                      },
                      get parsedContents() {
                        return o(ne);
                      },
                      get baselineContents() {
                        return o(h);
                      },
                      get savedAtLabel() {
                        return o(se);
                      },
                      get versionLabel() {
                        return o(me);
                      },
                      get dirty() {
                        return o(b);
                      },
                      get error() {
                        return t.bindings.error;
                      },
                      maxFiles: r,
                      onUpload: we,
                      get onFileRejected() {
                        return n.handleFileRejected;
                      },
                      onRemove: xe,
                      onLoad: Me,
                      get disableLoad() {
                        return o(Qe);
                      },
                      get wrappedContents() {
                        return o(Le);
                      },
                      get wrappedParsed() {
                        return o(Nt);
                      }
                    });
                  }
                },
                $$slots: { default: !0 }
              });
            });
            var Mt = K(Se, 2);
            ze(Mt, () => ja, (st, ft) => {
              ft(st, {
                value: "save",
                children: (pt, Ne) => {
                  jv(pt, {
                    get bindings() {
                      return t.bindings;
                    },
                    get rawConfig() {
                      return t.bindings.current_state;
                    },
                    get baselineConfig() {
                      return o(h);
                    },
                    get defaultFileName() {
                      return o(z);
                    },
                    get saveTargetLabel() {
                      return o(F);
                    },
                    get dirty() {
                      return o(b);
                    },
                    get currentVersion() {
                      return o(C);
                    },
                    get canEditVersion() {
                      return o(O);
                    }
                  });
                },
                $$slots: { default: !0 }
              });
            }), S(Ke, pe);
          },
          $$slots: { default: !0 }
        });
      }), S(T, B);
    }, ut = (T) => {
      var B = _e(), re = $(B);
      {
        var ke = (Re) => {
          xv(Re, {
            get fileName() {
              return o(R).name;
            },
            get savedAtLabel() {
              return o(R).savedAt;
            },
            get versionLabel() {
              return o(R).version;
            },
            get rawContents() {
              return o(R).rawText;
            },
            get parsedContents() {
              return o(R).parsed;
            },
            get baselineContents() {
              return o(h);
            },
            get dirty() {
              return o(b);
            },
            onClose: () => k(_, !1),
            get wrappedContents() {
              return o(R).wrappedRawText;
            },
            get wrappedParsed() {
              return o(R).wrappedParsed;
            },
            onManage: () => {
              k(_, !1), k(Z, !0);
            }
          });
        }, Ie = (Re) => {
          var Ue = Gv(), Ke = V(Ue), de = V(Ke), pe = K(V(de), 2);
          {
            var Ee = (Ne) => {
              var Oe = Dv(), Le = $(Oe), Nt = V(Le), mt = K(Le, 2);
              {
                var Rt = (At) => {
                  var hr = Vv(), Vt = V(hr);
                  {
                    var jt = (bt) => {
                      var Jr = Lv(), Di = V(Jr);
                      ge(() => ye(Di, `Saved ${o(R).savedAt ?? ""}`)), S(bt, Jr);
                    };
                    ee(Vt, (bt) => {
                      o(R).savedAt && bt(jt);
                    });
                  }
                  var Zt = K(Vt, 2);
                  {
                    var Hn = (bt) => {
                      Cr(bt, {
                        variant: "secondary",
                        class: "px-2 py-0.5 text-[0.65rem]",
                        children: (Jr, Di) => {
                          var Yn = Te();
                          ge(() => ye(Yn, t.bindings.version)), S(Jr, Yn);
                        },
                        $$slots: { default: !0 }
                      });
                    };
                    ee(Zt, (bt) => {
                      t.bindings.version && bt(Hn);
                    });
                  }
                  var Li = K(Zt, 2);
                  {
                    var Vi = (bt) => {
                      Cr(bt, {
                        variant: "secondary",
                        class: "bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-200",
                        children: (Jr, Di) => {
                          var Yn = Te("Unsaved changes");
                          S(Jr, Yn);
                        },
                        $$slots: { default: !0 }
                      });
                    };
                    ee(Li, (bt) => {
                      o(b) && bt(Vi);
                    });
                  }
                  S(At, hr);
                };
                ee(mt, (At) => {
                  (o(R).savedAt || t.bindings.version) && At(Rt);
                });
              }
              ge(() => ye(Nt, o(E) || o(R).name)), S(Ne, Oe);
            }, Se = (Ne) => {
              var Oe = Bv();
              S(Ne, Oe);
            };
            ee(pe, (Ne) => {
              o(R) ? Ne(Ee) : Ne(Se, !1);
            });
          }
          var Mt = K(de, 2), st = V(Mt);
          lr(st, {
            variant: "outline",
            onclick: () => k(Z, !0),
            children: (Ne, Oe) => {
              var Le = Te("Manage Configs");
              S(Ne, Le);
            },
            $$slots: { default: !0 }
          });
          var ft = K(st, 2);
          {
            var pt = (Ne) => {
              {
                let Oe = /* @__PURE__ */ U(() => {
                  var Le;
                  return !((Le = o(R)) != null && Le.rawText);
                });
                lr(Ne, {
                  variant: "outline",
                  get disabled() {
                    return o(Oe);
                  },
                  onclick: () => k(_, !0),
                  children: (Le, Nt) => {
                    var mt = Te("View Config");
                    S(Le, mt);
                  },
                  $$slots: { default: !0 }
                });
              }
            };
            ee(ft, (Ne) => {
              var Oe;
              (Oe = o(R)) != null && Oe.rawText && Ne(pt);
            });
          }
          S(Re, Ue);
        };
        ee(
          re,
          (Re) => {
            var Ue;
            o(_) && ((Ue = o(R)) != null && Ue.rawText) ? Re(ke) : Re(Ie, !1);
          },
          !0
        );
      }
      S(T, B);
    };
    ee(je, (T) => {
      o(Z) ? T($e) : T(ut, !1);
    });
  }
  S(e, Q), Ce();
}
const Kv = au(Wv);
export {
  Kv as default
};
