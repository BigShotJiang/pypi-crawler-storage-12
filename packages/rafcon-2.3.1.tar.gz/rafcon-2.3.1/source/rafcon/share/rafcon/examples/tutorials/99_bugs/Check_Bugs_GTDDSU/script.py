

def execute(self, inputs, outputs, gvm):
    if inputs["Bugs"] == 0:
        return '==0'
    return '>0'

