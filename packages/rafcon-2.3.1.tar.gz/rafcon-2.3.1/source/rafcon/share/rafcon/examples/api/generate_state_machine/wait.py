import time

def execute(self, inputs, outputs, gvm):
    time.sleep(1.0)
    return 0
