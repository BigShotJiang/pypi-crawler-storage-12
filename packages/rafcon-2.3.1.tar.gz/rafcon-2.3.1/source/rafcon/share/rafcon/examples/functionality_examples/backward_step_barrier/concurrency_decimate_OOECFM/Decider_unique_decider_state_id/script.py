

def execute(self, inputs, outputs, gvm):
    self.logger.debug("Nothing to decide :-)")
    import time
    time.sleep(1.0)
    return 0

