

def execute(self, inputs, outputs, gvm):
    self.logger.info("Handling execution abortion ...")
    
    if "error" in inputs:
        self.logger.error(inputs["error"])

    number1 = 0
    number2 = 1 / number1
    
    return 0

