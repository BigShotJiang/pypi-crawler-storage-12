# import hooks per default to be able to run the pre and post init functions automatically
from . import hooks
