import time

def execute(self, inputs, outputs, gvm):
    time.sleep(2.0)
    return 0
