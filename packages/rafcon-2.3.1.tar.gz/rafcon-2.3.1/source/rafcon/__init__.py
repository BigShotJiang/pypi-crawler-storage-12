# Copyright (C) 2014-2017 DLR
#
# All rights reserved. This program and the accompanying materials are made
# available under the terms of the Eclipse Public License v1.0 which
# accompanies this distribution, and is available at
# http://www.eclipse.org/legal/epl-v10.html
#
# Contributors:
# Franz Steinmetz <franz.steinmetz@dlr.de>
# Rico Belder <rico.belder@dlr.de>
# Sebastian Brunner <sebastian.brunner@dlr.de>

from importlib.metadata import version, PackageNotFoundError


try:
    __version__ = version("rafcon")
except PackageNotFoundError:
    # the version cannot be found via pip which means rafcon was not installed yet on the system.
    # thus try to parse it from the version.py file directly

    import os
    file_path = os.path.join(os.path.dirname(__file__), "../../VERSION")
    try:
        with open(file_path, "r") as f:
            content = f.read().splitlines()
            # append a1 to signal that this is not a release version but a alpha/develop version
            # a1 is used as e.g. dev1 is not supported by the StrictVersion class
            __version__ = content[0] + "a1"
    except Exception as e:
        from rafcon.utils import log
        logger = log.get_logger(__name__)
        logger.error(str(e))
        logger.error("Setting the rafcon version to 'unknown' ... ")
        # this case must not happen, else state machines cannot be loaded from the file system
        __version__ = "unknown"

# If the version is unset try to use importlib as this case is only accessed on only rafcon-core installation
if __version__ == "unknown":
    try:
        from importlib.metadata import PackageNotFoundError, version
        __version__ = version("rafcon-core")
        logger.info(f"rafcon-core version is: {__version__}")
    except Exception as error:
        from rafcon.utils import log
        logger = log.get_logger(__name__)
        logger.info(f"Isolated rafcon core installation failed, please check your rafcon installation again: {str(error)}")
        __version__ = "unknown"
