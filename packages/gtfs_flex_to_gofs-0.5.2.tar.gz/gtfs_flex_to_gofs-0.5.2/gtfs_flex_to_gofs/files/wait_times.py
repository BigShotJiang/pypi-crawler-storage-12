from ..gofs_file import GofsFile

FILENAME = 'wait_times'


def create(gtfs, pickup_booking_rule_ids):
    # Implement to support this file
    return GofsFile(FILENAME, created=False)
