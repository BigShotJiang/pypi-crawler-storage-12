from ..gofs_file import GofsFile

FILENAME = 'fares'


def create(gtfs):
    # Implement to support this file

    return GofsFile(FILENAME, created=False)
