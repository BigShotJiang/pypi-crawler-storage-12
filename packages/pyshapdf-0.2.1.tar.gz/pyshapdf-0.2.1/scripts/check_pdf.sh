#!/bin/sh

# qpdf should be installed
qpdf --check $1
