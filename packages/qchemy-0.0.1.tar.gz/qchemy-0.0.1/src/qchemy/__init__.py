"""QChemy: Python library for basic quantum chemistry calculations."""
