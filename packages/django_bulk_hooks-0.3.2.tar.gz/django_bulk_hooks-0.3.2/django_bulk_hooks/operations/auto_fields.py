from django_bulk_hooks.operations.field_utils import (
    handle_auto_now_fields,
)

__all__ = ["handle_auto_now_fields"]





