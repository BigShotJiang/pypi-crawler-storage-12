# nanowakeword/resources/models/__init__.py

import os
from pathlib import Path

from ._registry import models

__all__ = ['models']