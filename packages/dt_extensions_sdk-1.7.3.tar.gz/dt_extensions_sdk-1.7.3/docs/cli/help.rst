Help
====

.. command-output:: dt-sdk --help
