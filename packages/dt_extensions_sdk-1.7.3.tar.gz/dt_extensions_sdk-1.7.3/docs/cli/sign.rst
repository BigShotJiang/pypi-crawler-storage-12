Sign
====

.. command-output:: dt-sdk sign --help
