Run
===

.. command-output:: dt-sdk run --help
