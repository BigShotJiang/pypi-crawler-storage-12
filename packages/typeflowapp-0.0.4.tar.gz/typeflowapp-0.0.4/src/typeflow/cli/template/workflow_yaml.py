# workflow_yaml.py

content = """\
name: {workflow_name}
version: 1.0.0
description: "Describe your workflow here"
python: "{python_version}"
dependencies:
- typeflow
- numpy
- pillow
nodes: []
classes: []
"""
