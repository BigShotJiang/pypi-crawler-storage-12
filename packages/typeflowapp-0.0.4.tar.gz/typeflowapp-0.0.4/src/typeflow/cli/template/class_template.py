content = """from typeflow import node_class

@node_class
class {class_name}:
    pass
"""
