"""Fans definition"""

from enum import Enum


class FanType(Enum):
    FUMES = 1
    MAIN = 2
    LEFT = 3
    RIGHT = 4
