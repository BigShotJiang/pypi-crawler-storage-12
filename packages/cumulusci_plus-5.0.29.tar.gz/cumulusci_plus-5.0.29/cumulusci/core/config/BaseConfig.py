from cumulusci.utils.deprecation import warn_moved

from .base_config import *  # noqa

warn_moved(".base_config", ".BaseConfig")
