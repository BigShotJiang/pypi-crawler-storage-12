# django-new

It's like `django-admin startproject mysite djangotutorial`, but better.

```
This is just a placeholder project. If you have ideas for what `django-new` should be, please reach out!

- start a new discussion at https://github.com/adamghill/django-new
- DM me at https://indieweb.social/@adamghill
- email me at MY_FIRST_NAME [at] MY_USERNAME_EVERYWHERE.com
```
