"""StoreKit tests"""
