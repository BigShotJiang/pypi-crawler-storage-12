import logging

logging.basicConfig(level=logging.DEBUG)
log = logging.getLogger("bobtail")
