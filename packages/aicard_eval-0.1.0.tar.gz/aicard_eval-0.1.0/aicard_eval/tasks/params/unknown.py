def main(data, preds, target_column, num_classes_model, anns):
    raise NotImplemented("Unknown parameters for the task")