.. currentmodule:: py3dframe.manipulations

py3dframe.manipulations.rotate_around_axis
============================================

.. autofunction:: rotate_around_axis