.. currentmodule:: py3dframe.manipulations

py3dframe.manipulations.translate
==================================

.. autofunction:: translate