.. currentmodule:: py3dframe.manipulations

py3dframe.manipulations.mirror_across_plane
============================================

.. autofunction:: mirror_across_plane