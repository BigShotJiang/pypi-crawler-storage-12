convention
==========

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.convention