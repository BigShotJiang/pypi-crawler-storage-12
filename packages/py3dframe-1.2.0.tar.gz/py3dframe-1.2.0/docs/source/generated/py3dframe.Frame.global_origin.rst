global\_origin
==============

.. currentmodule:: py3dframe

.. autoproperty:: Frame.global_origin