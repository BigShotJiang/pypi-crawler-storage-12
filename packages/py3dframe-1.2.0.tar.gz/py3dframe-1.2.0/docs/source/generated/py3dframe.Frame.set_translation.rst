set\_translation
================

.. currentmodule:: py3dframe

.. automethod:: Frame.set_translation