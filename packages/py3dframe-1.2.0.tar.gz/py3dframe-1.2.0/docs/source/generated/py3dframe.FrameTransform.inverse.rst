inverse
=======

.. currentmodule:: py3dframe

.. automethod:: FrameTransform.inverse