get\_global\_frame
==================

.. currentmodule:: py3dframe

.. automethod:: Frame.get_global_frame