output\_frame
=============

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.output_frame