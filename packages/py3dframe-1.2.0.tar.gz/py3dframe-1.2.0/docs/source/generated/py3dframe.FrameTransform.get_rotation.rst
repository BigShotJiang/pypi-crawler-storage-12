get\_rotation
=============

.. currentmodule:: py3dframe

.. automethod:: FrameTransform.get_rotation