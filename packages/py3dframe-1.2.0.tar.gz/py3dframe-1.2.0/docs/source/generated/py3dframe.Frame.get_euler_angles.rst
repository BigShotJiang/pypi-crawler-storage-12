get\_euler\_angles
==================

.. currentmodule:: py3dframe

.. automethod:: Frame.get_euler_angles