global\_translation
===================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.global_translation