convention
==========

.. currentmodule:: py3dframe

.. autoproperty:: Frame.convention