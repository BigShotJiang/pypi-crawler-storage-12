get\_global\_euler\_angles
==========================

.. currentmodule:: py3dframe

.. automethod:: Frame.get_global_euler_angles