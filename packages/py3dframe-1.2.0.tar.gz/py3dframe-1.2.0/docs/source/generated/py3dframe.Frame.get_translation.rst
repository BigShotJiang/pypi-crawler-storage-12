get\_translation
================

.. currentmodule:: py3dframe

.. automethod:: Frame.get_translation