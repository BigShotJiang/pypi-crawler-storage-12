"""WebDesignTaal

Een programma gemaakt om .wdt bestanden of strings om te zetten naar ondersteunde varianten.

"""

from .file_handler import file_conversion
from .wdt_parser import render_code
