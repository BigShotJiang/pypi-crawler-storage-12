from django.apps import AppConfig


class BlogsConfig(AppConfig):
    name = 'blogs'
    verbose_name = 'ブログ'
