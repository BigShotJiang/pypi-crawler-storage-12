# 頭はDjangoのモデルに合わせる
__version__ = "2.2.3"
