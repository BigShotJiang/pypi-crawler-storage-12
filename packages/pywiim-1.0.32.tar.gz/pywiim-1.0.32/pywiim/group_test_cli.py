"""CLI tool for testing group join/unjoin operations and metadata propagation.

This tool tests:
- Creating groups
- Joining players to groups
- Leaving groups
- Metadata propagation from master to slaves
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from typing import Any

from .client import WiiMClient
from .player import Player

_LOGGER = logging.getLogger(__name__)


class GroupTester:
    """Test group operations and metadata propagation."""

    def __init__(self, master: Player, slaves: list[Player], verbose: bool = False) -> None:
        """Initialize group tester.

        Args:
            master: Master player for the group.
            slaves: List of slave players to join.
            verbose: Enable verbose output.
        """
        self.master = master
        self.slaves = slaves
        self.verbose = verbose
        self.results: dict[str, Any] = {
            "tests": [],
            "passed": 0,
            "failed": 0,
            "skipped": 0,
        }

    def _log(self, message: str, level: str = "info") -> None:
        """Log a message."""
        if self.verbose or level in ("error", "warning"):
            print(f"[{level.upper()}] {message}")
        if level == "error":
            _LOGGER.error(message)
        elif level == "warning":
            _LOGGER.warning(message)
        elif level == "debug":
            _LOGGER.debug(message)
        else:
            _LOGGER.info(message)

    def _record_test(self, name: str, passed: bool, message: str = "", skipped: bool = False) -> None:
        """Record a test result."""
        status = "SKIPPED" if skipped else ("PASS" if passed else "FAIL")
        self.results["tests"].append(
            {
                "name": name,
                "status": status,
                "message": message,
            }
        )
        if skipped:
            self.results["skipped"] += 1
        elif passed:
            self.results["passed"] += 1
        else:
            self.results["failed"] += 1

        icon = "✓" if passed else ("⊘" if skipped else "✗")
        print(f"  {icon} {name}: {message or status}")

    async def test_initial_state(self) -> None:
        """Test initial state - all players should be solo."""
        self._log("Testing initial state...")
        try:
            # Refresh all players
            await asyncio.gather(
                self.master.refresh(),
                *[slave.refresh() for slave in self.slaves],
                return_exceptions=True,
            )

            # Check master is solo
            if self.master.is_solo:
                self._record_test("Master is solo", True)
            else:
                self._record_test(
                    "Master is solo",
                    False,
                    f"Master is {self.master.role} (expected solo)",
                )

            # Check slaves are solo
            for i, slave in enumerate(self.slaves):
                if slave.is_solo:
                    self._record_test(f"Slave {i+1} is solo", True)
                else:
                    self._record_test(
                        f"Slave {i+1} is solo",
                        False,
                        f"Slave {i+1} is {slave.role} (expected solo)",
                    )
        except Exception as e:
            self._record_test("Initial state check", False, str(e))

    async def test_create_group(self) -> None:
        """Test creating a group."""
        self._log("Testing group creation...")
        try:
            group = await self.master.create_group()
            await asyncio.sleep(1)  # Give device time to update

            if group is not None and self.master.is_master:
                self._record_test("Create group", True, f"Group created with master {self.master.host}")
            else:
                self._record_test("Create group", False, "Group creation failed or master role not set")
        except Exception as e:
            self._record_test("Create group", False, str(e))

    async def test_join_slaves(self) -> None:
        """Test joining slaves to the group."""
        self._log("Testing slave join operations...")
        if not self.master.group:
            self._record_test("Join slaves", False, "No group exists (create group first)", skipped=True)
            return

        for i, slave in enumerate(self.slaves):
            try:
                await slave.join_group(self.master)
                await asyncio.sleep(1)  # Give device time to update

                # Refresh to check role
                await slave.refresh()

                if slave.is_slave and slave.group == self.master.group:
                    self._record_test(f"Join slave {i+1}", True, f"Slave {i+1} joined group")
                else:
                    self._record_test(
                        f"Join slave {i+1}",
                        False,
                        f"Slave {i+1} role: {slave.role}, in group: {slave.group is not None}",
                    )
            except Exception as e:
                self._record_test(f"Join slave {i+1}", False, str(e))

    async def test_group_state(self) -> None:
        """Test group state after all slaves joined."""
        self._log("Testing group state...")
        if not self.master.group:
            self._record_test("Group state", False, "No group exists", skipped=True)
            return

        try:
            group = self.master.group
            expected_size = 1 + len(self.slaves)

            if group.size == expected_size:
                self._record_test("Group size", True, f"Group has {group.size} players")
            else:
                self._record_test(
                    "Group size",
                    False,
                    f"Expected {expected_size} players, got {group.size}",
                )

            # Check all players are in the group
            all_players = group.all_players
            if len(all_players) == expected_size:
                self._record_test("All players in group", True)
            else:
                self._record_test(
                    "All players in group",
                    False,
                    f"Expected {expected_size} players, got {len(all_players)}",
                )
        except Exception as e:
            self._record_test("Group state", False, str(e))

    async def test_metadata_propagation(self) -> None:
        """Test metadata propagation from master to slaves."""
        self._log("Testing metadata propagation...")
        if not self.master.group:
            self._record_test("Metadata propagation", False, "No group exists", skipped=True)
            return

        try:
            # Refresh all players to get latest state
            await asyncio.gather(
                self.master.refresh(),
                *[slave.refresh() for slave in self.slaves],
                return_exceptions=True,
            )

            # Get master metadata
            master_metadata = {
                "title": self.master.media_title,
                "artist": self.master.media_artist,
                "album": self.master.media_album,
                "position": self.master.media_position,
                "duration": self.master.media_duration,
                "play_state": self.master.play_state,
            }

            self._log(f"Master metadata: {master_metadata}", "debug")

            # Check if master has metadata
            has_metadata = any(
                [
                    master_metadata["title"],
                    master_metadata["artist"],
                    master_metadata["album"],
                ]
            )

            if not has_metadata:
                self._record_test(
                    "Metadata propagation",
                    True,
                    "Skipped - master has no metadata to propagate",
                    skipped=True,
                )
                return

            # Wait a bit for propagation (metadata sync can take time)
            await asyncio.sleep(2)

            # Refresh slaves again to get propagated metadata
            await asyncio.gather(
                *[slave.refresh() for slave in self.slaves],
                return_exceptions=True,
            )

            # Check each slave's metadata
            all_match = True
            for i, slave in enumerate(self.slaves):
                slave_metadata = {
                    "title": slave.media_title,
                    "artist": slave.media_artist,
                    "album": slave.media_album,
                    "position": slave.media_position,
                    "play_state": slave.play_state,
                }

                self._log(f"Slave {i+1} metadata: {slave_metadata}", "debug")

                # Compare metadata (position may differ slightly due to timing)
                title_match = slave_metadata["title"] == master_metadata["title"]
                artist_match = slave_metadata["artist"] == master_metadata["artist"]
                album_match = slave_metadata["album"] == master_metadata["album"]
                play_state_match = slave_metadata["play_state"] == master_metadata["play_state"]

                if title_match and artist_match and album_match and play_state_match:
                    self._record_test(
                        f"Metadata propagation slave {i+1}",
                        True,
                        "Title/Artist/Album/State match",
                    )
                else:
                    all_match = False
                    mismatches = []
                    if not title_match:
                        mismatches.append(f"title: '{slave_metadata['title']}' != '{master_metadata['title']}'")
                    if not artist_match:
                        mismatches.append(f"artist: '{slave_metadata['artist']}' != '{master_metadata['artist']}'")
                    if not album_match:
                        mismatches.append(f"album: '{slave_metadata['album']}' != '{master_metadata['album']}'")
                    if not play_state_match:
                        mismatches.append(
                            f"play_state: '{slave_metadata['play_state']}' != '{master_metadata['play_state']}'"
                        )
                    self._record_test(
                        f"Metadata propagation slave {i+1}",
                        False,
                        f"Mismatches: {', '.join(mismatches)}",
                    )

            if all_match:
                self._record_test("Metadata propagation (all slaves)", True, "All slaves match master metadata")
        except Exception as e:
            self._record_test("Metadata propagation", False, str(e))

    async def test_leave_group_slaves(self) -> None:
        """Test leaving group as slaves."""
        self._log("Testing slave leave operations...")
        if not self.master.group:
            self._record_test("Leave group (slaves)", False, "No group exists", skipped=True)
            return

        # Leave in reverse order
        for i, slave in enumerate(reversed(self.slaves)):
            try:
                if not slave.is_slave:
                    self._record_test(
                        f"Leave slave {len(self.slaves) - i}",
                        True,
                        "Already not in group",
                        skipped=True,
                    )
                    continue

                await slave.leave_group()
                await asyncio.sleep(1)  # Give device time to update

                # Refresh to check role
                await slave.refresh()

                if slave.is_solo:
                    self._record_test(
                        f"Leave slave {len(self.slaves) - i}", True, f"Slave {len(self.slaves) - i} left group"
                    )
                else:
                    self._record_test(
                        f"Leave slave {len(self.slaves) - i}",
                        False,
                        f"Slave {len(self.slaves) - i} role: {slave.role} (expected solo)",
                    )
            except Exception as e:
                self._record_test(f"Leave slave {len(self.slaves) - i}", False, str(e))

    async def test_leave_group_master(self) -> None:
        """Test leaving group as master (disbands group)."""
        self._log("Testing master leave (disband group)...")
        if not self.master.group:
            self._record_test("Leave group (master)", True, "No group exists", skipped=True)
            return

        try:
            await self.master.leave_group()
            await asyncio.sleep(1)  # Give device time to update

            # Refresh to check role
            await self.master.refresh()

            if self.master.is_solo:
                self._record_test("Leave group (master)", True, "Master left, group disbanded")
            else:
                self._record_test(
                    "Leave group (master)",
                    False,
                    f"Master role: {self.master.role} (expected solo)",
                )
        except Exception as e:
            self._record_test("Leave group (master)", False, str(e))

    async def test_final_state(self) -> None:
        """Test final state - all players should be solo again."""
        self._log("Testing final state...")
        try:
            # Refresh all players
            await asyncio.gather(
                self.master.refresh(),
                *[slave.refresh() for slave in self.slaves],
                return_exceptions=True,
            )

            # Check master is solo
            if self.master.is_solo:
                self._record_test("Final state - master solo", True)
            else:
                self._record_test(
                    "Final state - master solo",
                    False,
                    f"Master is {self.master.role} (expected solo)",
                )

            # Check slaves are solo
            for i, slave in enumerate(self.slaves):
                if slave.is_solo:
                    self._record_test(f"Final state - slave {i+1} solo", True)
                else:
                    self._record_test(
                        f"Final state - slave {i+1} solo",
                        False,
                        f"Slave {i+1} is {slave.role} (expected solo)",
                    )
        except Exception as e:
            self._record_test("Final state check", False, str(e))

    async def run_all_tests(self) -> dict[str, Any]:
        """Run all group tests."""
        print("\n" + "=" * 60)
        print("Group Join/Unjoin Test Suite")
        print("=" * 60)
        print(f"Master: {self.master.host}")
        print(f"Slaves: {[s.host for s in self.slaves]}")
        print("=" * 60 + "\n")

        # Test sequence
        await self.test_initial_state()
        await self.test_create_group()
        await self.test_join_slaves()
        await self.test_group_state()
        await self.test_metadata_propagation()
        await self.test_leave_group_slaves()
        await self.test_leave_group_master()
        await self.test_final_state()

        return self.results

    def print_summary(self) -> None:
        """Print test summary."""
        print("\n" + "=" * 60)
        print("Test Summary")
        print("=" * 60)
        print(f"Total tests: {len(self.results['tests'])}")
        print(f"Passed: {self.results['passed']}")
        print(f"Failed: {self.results['failed']}")
        print(f"Skipped: {self.results['skipped']}")
        print("=" * 60)

        if self.results["failed"] > 0:
            print("\nFailed tests:")
            for test in self.results["tests"]:
                if test["status"] == "FAIL":
                    print(f"  ✗ {test['name']}: {test['message']}")


async def main() -> int:
    """Main entry point for group test CLI."""
    parser = argparse.ArgumentParser(
        description="Test group join/unjoin operations and metadata propagation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Test with one master and one slave
  wiim-group-test 192.168.1.100 192.168.1.101

  # Test with one master and multiple slaves
  wiim-group-test 192.168.1.100 192.168.1.101 192.168.1.102

  # Verbose output
  wiim-group-test 192.168.1.100 192.168.1.101 --verbose

  # HTTPS devices
  wiim-group-test 192.168.1.100 192.168.1.101 --port 443
        """,
    )
    parser.add_argument(
        "master_ip",
        help="Master device IP address or hostname",
    )
    parser.add_argument(
        "slave_ips",
        nargs="+",
        help="Slave device IP addresses or hostnames",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=80,
        help="Device port (default: 80, use 443 for HTTPS)",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose logging",
    )

    args = parser.parse_args()

    # Configure logging
    level = logging.DEBUG if args.verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    # Create clients and players
    master_client = WiiMClient(host=args.master_ip, port=args.port)
    master = Player(master_client)

    slave_clients = [WiiMClient(host=ip, port=args.port) for ip in args.slave_ips]
    slaves = [Player(client) for client in slave_clients]

    tester = GroupTester(master, slaves, verbose=args.verbose)

    try:
        summary = await tester.run_all_tests()
        tester.print_summary()

        # Return exit code based on results
        if summary["failed"] > 0:
            return 1
        return 0

    except KeyboardInterrupt:
        print("\n\n⚠️  Testing interrupted by user")
        return 1
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        if args.verbose:
            import traceback

            traceback.print_exc()
        return 1
    finally:
        # Cleanup
        await master_client.close()
        for client in slave_clients:
            await client.close()


def cli_main() -> None:
    """CLI entry point."""
    sys.exit(asyncio.run(main()))


if __name__ == "__main__":
    cli_main()
