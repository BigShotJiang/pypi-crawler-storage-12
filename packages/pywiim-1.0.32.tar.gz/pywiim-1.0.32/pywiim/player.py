"""Player class - represents a single device that can be solo, master, or slave.

This module provides the Player class, which is a thin wrapper around WiiMClient
that adds group awareness, role management, and cached state with getter methods.

# pragma: allow-long-file player-cohesive-class
# This file exceeds the 400 LOC soft limit (~1476 lines) but is kept as a single
# cohesive unit because:
# 1. Single responsibility: Player class wraps WiiMClient with state caching
# 2. Well-organized: Clear sections, easy to navigate
# 3. Tight coupling: All methods/properties are Player-specific
# 4. Maintainable: Clear structure, good documentation
# 5. Natural unit: Represents one concept (a device player)
# Splitting would add complexity without clear benefit.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from typing import TYPE_CHECKING, Any, Literal

from .client import WiiMClient
from .exceptions import WiiMError
from .models import DeviceInfo, PlayerStatus
from .state import StateSynchronizer

if TYPE_CHECKING:
    from .group import Group
    from .upnp.client import UpnpClient
else:
    Group = None  # Will be imported when needed to avoid circular import

_LOGGER = logging.getLogger(__name__)


class Player:
    """Represents a single WiiM/LinkPlay device that can be solo, master, or slave.

    A Player is a thin wrapper around WiiMClient that adds group awareness,
    cached state, and convenient getter methods for accessing device information.
    The role (solo/master/slave) is computed from group membership, not stored.

    When a slave calls set_volume() or set_mute(), the command propagates to
    the master, which then syncs it to all slaves in the group automatically
    via the LinkPlay protocol.

    The Player caches status and device_info for efficient access via getter
    methods. Use refresh() to update the cache. The Player integrates with
    StateSynchronizer to merge HTTP polling and UPnP event data.

    State Management:
    - Player caches state from HTTP polling (via refresh())
    - Player receives UPnP events via update_from_upnp()
    - StateSynchronizer merges HTTP + UPnP data with conflict resolution
    - Only play() and resume() auto-refresh after command (to get metadata/position)
    - Other control methods let adaptive polling handle sync

    Example:
        ```python
        # Create a player with state change callback
        def on_state_changed():
            print(f"State updated: {player.volume_level}")

        player = Player(WiiMClient("192.168.1.100"), on_state_changed=on_state_changed)

        # Refresh state cache
        await player.refresh()

        # Access cached state (synchronous, fast)
        print(player.volume_level)  # 0.5
        print(player.is_muted)  # False
        print(player.media_title)  # "Song Title"
        print(player.play_state)  # "play"
        print(player.available)  # True

        # Check role
        print(player.role)  # "solo", "master", or "slave"

        # Individual device control
        await player.set_volume(0.5)  # No auto-refresh
        await player.set_mute(False)  # No auto-refresh
        await player.play()  # Auto-refreshes to get metadata/position
        ```

    Args:
        client: WiiMClient instance for this device.
        on_state_changed: Optional callback function called when state is updated
            (via refresh() or update_from_upnp()).
    """

    def __init__(
        self,
        client: WiiMClient,
        upnp_client: UpnpClient | None = None,
        on_state_changed: Callable[[], None] | None = None,
    ) -> None:
        """Initialize a Player instance.

        Args:
            client: WiiMClient instance for this device.
            upnp_client: Optional UPnP client for queue management and events.
                If provided, enables queue management methods (add_to_queue, insert_next).
            on_state_changed: Optional callback function called when state is updated.
        """
        self.client = client
        self._upnp_client = upnp_client
        self._group: Group | None = None

        # State management
        self._state_synchronizer = StateSynchronizer()
        self._on_state_changed = on_state_changed

        # Cached state (updated via refresh())
        self._status_model: PlayerStatus | None = None
        self._device_info: DeviceInfo | None = None
        self._last_refresh: float | None = None

        # Cached audio output status (updated via refresh())
        self._audio_output_status: dict[str, Any] | None = None

        # Availability tracking
        self._available: bool = True  # Assume available until proven otherwise

        # Position tracking (for position_updated_at)
        self._last_position_update: float | None = None
        self._last_position: int | None = None
        self._last_track_signature: str | None = None

        # Hybrid position estimation (for smooth updates between polls)
        self._estimated_position: int | None = None
        self._estimation_start_time: float | None = None
        self._estimation_base_position: int | None = None

    @property
    def role(self) -> str:
        """Current role: 'solo', 'master', or 'slave'.

        Role is computed from group membership - always correct, never stale.

        Returns:
            'solo' if not in a group, 'master' if this player is the group master,
            'slave' if this player is a slave in a group.
        """
        if self._group is None:
            return "solo"
        if self._group.master == self:
            return "master"
        return "slave"

    @property
    def is_solo(self) -> bool:
        """True if this player is not in a group."""
        return self._group is None

    @property
    def is_master(self) -> bool:
        """True if this player is the master of a group."""
        return self._group is not None and self._group.master == self

    @property
    def is_slave(self) -> bool:
        """True if this player is a slave in a group."""
        return self._group is not None and self._group.master != self

    @property
    def group(self) -> Group | None:
        """Group this player belongs to, or None if solo.

        Returns:
            Group instance if in a group, None if solo.
        """
        return self._group

    @property
    def host(self) -> str:
        """Device hostname or IP address."""
        return self.client.host

    @property
    def name(self) -> str | None:
        """Device name from cached device_info."""
        if self._device_info:
            return self._device_info.name
        return None

    @property
    def model(self) -> str | None:
        """Device model from cached device_info."""
        if self._device_info:
            return self._device_info.model
        return None

    @property
    def firmware(self) -> str | None:
        """Firmware version from cached device_info."""
        if self._device_info:
            return self._device_info.firmware
        return None

    @property
    def mac_address(self) -> str | None:
        """MAC address from cached device_info."""
        if self._device_info:
            return self._device_info.mac
        return None

    @property
    def uuid(self) -> str | None:
        """Device UUID from cached device_info."""
        if self._device_info:
            return self._device_info.uuid
        return None

    @property
    def available(self) -> bool:
        """Device availability status.

        Returns:
            True if device is available (last refresh succeeded), False otherwise.
        """
        return self._available

    # ===== State Refresh and UPnP Integration =====

    def apply_diff(self, changes: dict[str, Any]) -> bool:
        """Apply state changes from UPnP events (interface for UpnpEventer).

        This method is called by UpnpEventer when UPnP events are received.
        It wraps update_from_upnp() and returns True if state changed.

        Args:
            changes: Dictionary with state fields from UPnP event.

        Returns:
            True if state changed, False otherwise.
        """
        if not changes:
            return False

        # Track if state actually changed
        old_state = {
            "play_state": self.play_state,
            "volume": self.volume_level,
            "muted": self.is_muted,
            "title": self.media_title,
            "position": self.media_position,
        }

        # Update from UPnP (this will merge with HTTP state via StateSynchronizer)
        self.update_from_upnp(changes)

        # Check if state changed
        new_state = {
            "play_state": self.play_state,
            "volume": self.volume_level,
            "muted": self.is_muted,
            "title": self.media_title,
            "position": self.media_position,
        }

        return old_state != new_state

    def update_from_upnp(self, data: dict[str, Any]) -> None:
        """Update state from UPnP event data.

        This method is called internally by apply_diff() or can be called directly.
        The StateSynchronizer merges UPnP data with HTTP polling data.

        Args:
            data: Dictionary with state fields from UPnP event.
        """
        self._state_synchronizer.update_from_upnp(data)

        # Get merged state and update cached models
        merged = self._state_synchronizer.get_merged_state()

        # Update cached status_model with merged state
        if self._status_model:
            # Update fields from merged state
            for field_name in ["play_state", "position", "duration", "source"]:
                if field_name in merged and merged[field_name] is not None:
                    setattr(self._status_model, field_name, merged[field_name])

            # Update volume and mute (convert from 0.0-1.0 to 0-100 if needed)
            if "volume" in merged and merged["volume"] is not None:
                vol = merged["volume"]
                if isinstance(vol, float) and 0.0 <= vol <= 1.0:
                    self._status_model.volume = int(vol * 100)
                else:
                    self._status_model.volume = int(vol) if vol is not None else None

            if "muted" in merged and merged["muted"] is not None:
                self._status_model.mute = merged["muted"]

            # Update metadata
            for field_name in ["title", "artist", "album"]:
                if field_name in merged:
                    setattr(self._status_model, field_name, merged.get(field_name))

            if "image_url" in merged:
                self._status_model.entity_picture = merged.get("image_url")
                self._status_model.cover_url = merged.get("image_url")

        # Note: Callback is handled by UpnpEventer when called via apply_diff()
        # If update_from_upnp() is called directly, we should notify callback
        # But typically it's called via apply_diff() from UpnpEventer

    async def _get_master_name(self, device_info: DeviceInfo | None, status: PlayerStatus | None) -> str | None:
        """Get master device name, using Group object or master_ip from device_info.

        Args:
            device_info: Current device_info (may contain master_ip)
            status: Current status (may contain master_ip)

        Returns:
            Master device name, or None if not available
        """
        # First try: Use Group object if available (when explicitly joined)
        if self._group is not None and self._group.master is not None and self._group.master != self:
            # Ensure master's device_info is loaded
            if self._group.master._device_info is None or self._group.master.name is None:
                try:
                    await self._group.master.refresh()
                except Exception:
                    pass  # Fallback to host if refresh fails
            return self._group.master.name or self._group.master.host

        # Second try: Use master_ip from device_info/status (when detected as slave)
        if device_info:
            master_ip = device_info.master_ip or (status.master_ip if status else None)
            if master_ip:
                # Create a temporary client to get master's name
                master_client = None
                try:
                    from .client import WiiMClient

                    master_client = WiiMClient(master_ip)
                    master_name = await master_client.get_device_name()
                    return master_name
                except Exception as e:
                    _LOGGER.debug("Failed to get master name from IP %s: %s", master_ip, e)
                    return master_ip  # Fallback to IP
                finally:
                    # Ensure temporary client is properly closed to avoid unclosed session warnings
                    if master_client is not None:
                        try:
                            await master_client.close()
                        except Exception:
                            pass  # Ignore errors during cleanup

        return None

    async def refresh(self) -> None:
        """Refresh cached state from device.

        Updates both status_model and device_info caches.
        Also updates StateSynchronizer with HTTP polling data.
        Fetches audio output status if device supports it.
        Call this periodically to keep state up-to-date.
        """
        try:
            status = await self.client.get_player_status_model()
            device_info = await self.client.get_device_info_model()

            # Update StateSynchronizer with HTTP data
            # Don't exclude_none for metadata fields - we need to know when they're None
            # to properly update/clear them in StateSynchronizer
            status_dict = status.model_dump(exclude_none=False) if status else {}
            # Map entity_picture to image_url for StateSynchronizer
            if "entity_picture" in status_dict:
                status_dict["image_url"] = status_dict.pop("entity_picture")
            # Ensure metadata fields are always present (even if None) for proper state tracking
            for field_name in ["title", "artist", "album", "image_url"]:
                if field_name not in status_dict:
                    status_dict[field_name] = None

            # For slaves, replace "multiroom" placeholder with master's name
            if status_dict.get("source") == "multiroom":
                master_name = await self._get_master_name(device_info, status)
                if master_name:
                    status_dict["source"] = master_name
                    _LOGGER.debug(
                        "Replacing 'multiroom' with master name '%s' for slave %s",
                        master_name,
                        self.host,
                    )

            self._state_synchronizer.update_from_http(status_dict)

            # Update cached models
            self._status_model = status
            # For slaves, also update the status model source if it's "multiroom"
            if self._status_model and self._status_model.source == "multiroom":
                master_name = await self._get_master_name(device_info, status)
                if master_name:
                    self._status_model.source = master_name
                    _LOGGER.debug(
                        "Updated status_model source to master name '%s' for slave %s",
                        master_name,
                        self.host,
                    )
            self._device_info = device_info
            self._last_refresh = time.time()
            self._available = True

            # Clear source if device is no longer a slave
            # Check if source was set to master name or "multiroom" but device is now solo
            if self._status_model and self._status_model.source:
                current_source = self._status_model.source
                # Check if device is currently solo (no longer a slave)
                is_currently_solo = (
                    # No group object
                    self._group is None
                    # No master info in device_info
                    and (not device_info.master_ip and not device_info.master_uuid)
                    # Group field indicates solo
                    and (device_info.group == "0" or not device_info.group)
                    # No master info in status
                    and (not status.master_ip and not status.master_uuid)
                )

                # Check if source is "multiroom" or looks like a master name
                # Standard sources we shouldn't clear
                standard_sources = {
                    "spotify",
                    "tidal",
                    "amazon",
                    "qobuz",
                    "deezer",
                    "wifi",
                    "bluetooth",
                    "linein",
                    "coax",
                    "optical",
                    "usb",
                    "airplay",
                    "dlna",
                    "unknown",
                }
                source_is_multiroom_or_master = current_source == "multiroom" or (
                    current_source not in standard_sources and current_source is not None
                )

                if is_currently_solo and source_is_multiroom_or_master:
                    # Device is no longer a slave - clear the source
                    self._status_model.source = None
                    self._status_model._multiroom_mode = None
                    # Also clear from state synchronizer to prevent refresh() from restoring it
                    self._state_synchronizer.update_from_http({"source": None})
                    _LOGGER.debug(
                        "Cleared source for device %s - no longer a slave (was: %s)",
                        self.host,
                        current_source,
                    )

            # Update cached status_model from merged state (to get latest metadata from both HTTP and UPnP)
            # This ensures media_title, media_artist, etc. reflect the merged state, not just HTTP
            merged = self._state_synchronizer.get_merged_state()
            if self._status_model:
                # Update fields from merged state
                for field_name in ["play_state", "position", "duration", "source"]:
                    if field_name in merged and merged[field_name] is not None:
                        value = merged[field_name]
                        # For slaves, preserve master name if source is "multiroom" placeholder
                        if field_name == "source" and value == "multiroom":
                            master_name = await self._get_master_name(self._device_info, self._status_model)
                            if master_name:
                                value = master_name
                                # Update state synchronizer with master name
                                self._state_synchronizer.update_from_http({"source": master_name})
                                _LOGGER.debug(
                                    "Replaced 'multiroom' with master name '%s' in merged state for slave %s",
                                    master_name,
                                    self.host,
                                )
                        setattr(self._status_model, field_name, value)

                # After merged state update, check again if source should be cleared
                # (merged state might have set "multiroom" or master name)
                if self._status_model.source:
                    current_source = self._status_model.source
                    is_currently_solo = (
                        self._group is None
                        and (not device_info.master_ip and not device_info.master_uuid)
                        and (device_info.group == "0" or not device_info.group)
                        and (not status.master_ip and not status.master_uuid)
                    )
                    standard_sources = {
                        "spotify",
                        "tidal",
                        "amazon",
                        "qobuz",
                        "deezer",
                        "wifi",
                        "bluetooth",
                        "linein",
                        "coax",
                        "optical",
                        "usb",
                        "airplay",
                        "dlna",
                        "unknown",
                    }
                    source_is_multiroom_or_master = current_source == "multiroom" or (
                        current_source not in standard_sources and current_source is not None
                    )
                    if is_currently_solo and source_is_multiroom_or_master:
                        self._status_model.source = None
                        self._status_model._multiroom_mode = None
                        self._state_synchronizer.update_from_http({"source": None})
                        _LOGGER.debug(
                            "Cleared source for device %s after merged state update - no longer a slave (was: %s)",
                            self.host,
                            current_source,
                        )

                # Update volume and mute (convert from 0.0-1.0 to 0-100 if needed)
                if "volume" in merged and merged["volume"] is not None:
                    vol = merged["volume"]
                    if isinstance(vol, float) and 0.0 <= vol <= 1.0:
                        self._status_model.volume = int(vol * 100)
                    else:
                        self._status_model.volume = int(vol) if vol is not None else None

                if "muted" in merged and merged["muted"] is not None:
                    self._status_model.mute = merged["muted"]

                # Update metadata from merged state (this is the key fix!)
                # Always update metadata fields from merged state (to_dict() always includes these fields)
                # This ensures we get the latest metadata from either HTTP or UPnP
                for field_name in ["title", "artist", "album"]:
                    # to_dict() always includes metadata fields, so this should always work
                    value = merged.get(field_name)
                    # Only update if value is different (avoid unnecessary updates)
                    current_value = getattr(self._status_model, field_name, None)
                    if value != current_value:
                        setattr(self._status_model, field_name, value)
                        if _LOGGER.isEnabledFor(logging.DEBUG):
                            _LOGGER.debug(
                                "Updated %s from merged state: %s -> %s",
                                field_name,
                                current_value,
                                value,
                            )

                if "image_url" in merged:
                    self._status_model.entity_picture = merged.get("image_url")
                    self._status_model.cover_url = merged.get("image_url")

            # Fetch audio output status if device supports it
            if self.client.capabilities.get("supports_audio_output", False):
                try:
                    audio_output_status = await self.client.get_audio_output_status()
                    self._audio_output_status = audio_output_status
                except Exception as err:
                    # Don't fail refresh if audio output status fails
                    _LOGGER.debug(
                        "Failed to fetch audio output status for %s: %s",
                        self.host,
                        err,
                    )
                    self._audio_output_status = None

            # Notify callback
            if self._on_state_changed:
                try:
                    self._on_state_changed()
                except Exception as err:
                    _LOGGER.debug(
                        "Error calling on_state_changed callback for %s: %s",
                        self.host,
                        err,
                    )
        except Exception as err:
            device_context = f"host={self.host}"
            if self._device_info:
                device_context += f", model={self._device_info.model}, firmware={self._device_info.firmware}"
            _LOGGER.warning("Failed to refresh state for %s: %s", device_context, err)
            self._available = False
            raise

    # ===== Device Information =====

    async def get_device_info(self) -> DeviceInfo:
        """Get device information (always queries device, doesn't use cache).

        Returns:
            DeviceInfo model with device details.
        """
        return await self.client.get_device_info_model()

    async def get_status(self) -> PlayerStatus:
        """Get current player status (always queries device, doesn't use cache).

        Returns:
            PlayerStatus model with current playback state.
        """
        return await self.client.get_player_status_model()

    @property
    def status_model(self) -> PlayerStatus | None:
        """Cached PlayerStatus model (None if not refreshed yet)."""
        return self._status_model

    @property
    def device_info(self) -> DeviceInfo | None:
        """Cached DeviceInfo model (None if not refreshed yet)."""
        return self._device_info

    # ===== Volume and Mute Control =====

    async def set_volume(self, volume: float) -> None:
        """Set volume level (0.0-1.0).

        Sets volume on THIS device only. Volumes do NOT propagate between devices.
        Each device (master and slaves) maintains independent volume.

        Behavior:
        - Solo player: Sets this device's volume
        - Master in group: Sets master's volume only (does NOT sync to slaves)
        - Slave in group: Sets this slave's volume only (does NOT propagate to master)

        Note: Virtual master volume (group.volume_level) is always the MAX of
        all device volumes and updates automatically when any device volume changes.

        Args:
            volume: Volume level from 0.0 (muted) to 1.0 (maximum).

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.set_volume(volume)

    async def set_mute(self, mute: bool) -> None:
        """Set mute state.

        Sets mute on THIS device only. Mute states do NOT propagate between devices.
        Each device (master and slaves) maintains independent mute state.

        Behavior:
        - Solo player: Sets this device's mute
        - Master in group: Sets master's mute only (does NOT sync to slaves)
        - Slave in group: Sets this slave's mute only (does NOT propagate to master)

        Note: Virtual master mute (group.is_muted) is True only when ALL devices
        are muted and updates automatically when any device mute state changes.

        Args:
            mute: True to mute, False to unmute.

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.set_mute(mute)

    @property
    def volume_level(self) -> float | None:
        """Current volume level (0.0-1.0) from cached status.

        Returns:
            Volume level or None if not cached or unknown.
        """
        if self._status_model is None or self._status_model.volume is None:
            return None
        return max(0.0, min(float(self._status_model.volume), 100.0)) / 100.0

    @property
    def is_muted(self) -> bool | None:
        """Current mute state from cached status.

        Returns:
            True if muted, False if not muted, None if not cached or unknown.
        """
        if self._status_model is None:
            return None

        mute_val = self._status_model.mute
        if mute_val is None:
            return None

        # Convert to boolean for various encodings
        if isinstance(mute_val, (bool, int)):
            return bool(int(mute_val))

        mute_str = str(mute_val).strip().lower()
        if mute_str in ("1", "true", "yes", "on"):
            return True
        if mute_str in ("0", "false", "no", "off"):
            return False
        return None

    async def get_volume(self) -> float | None:
        """Get current volume level (0.0-1.0) by querying device.

        Returns:
            Volume level or None if unknown.
        """
        status = await self.get_status()
        return status.volume / 100.0 if status.volume is not None else None

    async def get_muted(self) -> bool | None:
        """Get current mute state by querying device.

        Returns:
            True if muted, False if not muted, None if unknown.
        """
        status = await self.get_status()
        return status.mute

    # ===== Playback Control =====

    async def play(self) -> None:
        """Start playback.

        If in a group and this is the master, playback syncs to all slaves.
        If in a group and this is a slave, command propagates to master.

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.play()
        # Refresh to get updated metadata/position when starting playback
        try:
            await self.refresh()
        except Exception:
            pass  # Don't fail if refresh fails

    async def pause(self) -> None:
        """Pause playback.

        If in a group, command goes to master which syncs to slaves.

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.pause()
        # Let adaptive polling handle sync (no immediate refresh needed)

    async def resume(self) -> None:
        """Resume playback from paused state.

        If in a group, command goes to master which syncs to slaves.

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.resume()
        # Refresh to get updated metadata/position when resuming playback
        try:
            await self.refresh()
        except Exception:
            pass  # Don't fail if refresh fails

    async def stop(self) -> None:
        """Stop playback.

        If in a group, command goes to master which syncs to slaves.

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.stop()

    async def next_track(self) -> None:
        """Skip to next track.

        If in a group, command goes to master which syncs to slaves.

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.next_track()

    async def previous_track(self) -> None:
        """Skip to previous track.

        If in a group, command goes to master which syncs to slaves.

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.previous_track()

    async def seek(self, position: int) -> None:
        """Seek to position in current track.

        If in a group, command goes to master which syncs to slaves.

        Args:
            position: Position in seconds to seek to.

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.seek(position)
        # Refresh to get updated position after seeking
        try:
            await self.refresh()
        except Exception:
            pass  # Don't fail if refresh fails

    async def play_url(
        self,
        url: str,
        enqueue: Literal["add", "next", "replace", "play"] = "replace",
    ) -> None:
        """Play a URL directly with optional enqueue support.

        If in a group and this is the master, playback syncs to all slaves.
        If in a group and this is a slave, command propagates to master.

        Args:
            url: URL to play.
            enqueue: How to enqueue the media:
                - "replace": Replace current (default, uses HTTP API)
                - "play": Play immediately (uses HTTP API)
                - "add": Add to end of queue (requires UPnP client)
                - "next": Insert after current (requires UPnP client)

        Raises:
            WiiMError: If the request fails or UPnP client required but not available.
        """
        if enqueue in ("add", "next"):
            if not self._upnp_client:
                raise WiiMError(
                    f"Queue management (enqueue='{enqueue}') requires UPnP client. "
                    "Create UpnpClient and pass to Player.__init__()"
                )
            # Type narrowing: enqueue is "add" or "next" at this point
            await self._enqueue_via_upnp(url, enqueue)  # type: ignore[arg-type]
        else:
            # Use HTTP API for replace/play (existing behavior)
            await self.client.play_url(url)
            # Refresh to get updated metadata/position when starting playback
            try:
                await self.refresh()
            except Exception:
                pass  # Don't fail if refresh fails

    async def play_playlist(self, playlist_url: str) -> None:
        """Play a playlist (M3U) URL.

        If in a group and this is the master, playback syncs to all slaves.
        If in a group and this is a slave, command propagates to master.

        Args:
            playlist_url: URL to M3U playlist file.

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.play_playlist(playlist_url)
        # Refresh to get updated metadata/position when starting playback
        try:
            await self.refresh()
        except Exception:
            pass  # Don't fail if refresh fails

    async def play_notification(self, url: str) -> None:
        """Play a notification sound from URL.

        Args:
            url: URL to notification audio file.

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.play_notification(url)

    async def add_to_queue(self, url: str, metadata: str = "") -> None:
        """Add URL to end of queue (requires UPnP client).

        If in a group and this is the master, queue operation syncs to all slaves.
        If in a group and this is a slave, command propagates to master.

        Args:
            url: URL to add to queue.
            metadata: Optional DIDL-Lite metadata (empty string if not provided).

        Raises:
            WiiMError: If UPnP client not available or request fails.
        """
        if not self._upnp_client:
            raise WiiMError("Queue management requires UPnP client. " "Create UpnpClient and pass to Player.__init__()")

        await self._upnp_client.async_call_action(
            "AVTransport",
            "AddURIToQueue",
            {
                "InstanceID": 0,
                "EnqueuedURI": url,
                "EnqueuedURIMetaData": metadata,
                "DesiredFirstTrackNumberEnqueued": 0,
                "EnqueueAsNext": False,
            },
        )

    async def insert_next(self, url: str, metadata: str = "") -> None:
        """Insert URL after current track (requires UPnP client).

        If in a group and this is the master, queue operation syncs to all slaves.
        If in a group and this is a slave, command propagates to master.

        Args:
            url: URL to insert.
            metadata: Optional DIDL-Lite metadata (empty string if not provided).

        Raises:
            WiiMError: If UPnP client not available or request fails.
        """
        if not self._upnp_client:
            raise WiiMError("Queue management requires UPnP client. " "Create UpnpClient and pass to Player.__init__()")

        await self._upnp_client.async_call_action(
            "AVTransport",
            "InsertURIToQueue",
            {
                "InstanceID": 0,
                "EnqueuedURI": url,
                "EnqueuedURIMetaData": metadata,
                "DesiredTrackNumber": 0,  # 0 = after current track
            },
        )

    async def _enqueue_via_upnp(
        self,
        url: str,
        enqueue: Literal["add", "next"],
    ) -> None:
        """Internal helper for UPnP queue operations.

        Args:
            url: URL to enqueue.
            enqueue: Enqueue type ("add" or "next").

        Raises:
            WiiMError: If request fails.
        """
        if enqueue == "add":
            await self.add_to_queue(url)
        elif enqueue == "next":
            await self.insert_next(url)

    async def play_preset(self, preset: int) -> None:
        """Play a preset by number.

        If in a group and this is the master, playback syncs to all slaves.
        If in a group and this is a slave, command propagates to master.

        Args:
            preset: Preset number (1-based, must be within device's supported range).

        Raises:
            ValueError: If preset number is outside valid range for this device.
            WiiMError: If the request fails or presets are not supported.
        """
        await self.client.play_preset(preset)
        # Refresh to get updated metadata/position when starting playback
        try:
            await self.refresh()
        except Exception:
            pass  # Don't fail if refresh fails

    async def set_source(self, source: str) -> None:
        """Set audio input source.

        Args:
            source: Source to switch to (e.g., "wifi", "bluetooth", "line_in", "optical").

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.set_source(source)
        # Refresh to get updated source state
        try:
            await self.refresh()
        except Exception:
            pass  # Don't fail if refresh fails

    async def set_audio_output_mode(self, mode: str | int) -> None:
        """Set audio output mode by friendly name or integer.

        This is a convenience method that accepts either a friendly name string
        (e.g., "Line Out", "Optical Out") or a mode integer (0-4).

        Args:
            mode: Either a friendly name string or mode integer (0-4).

        Raises:
            ValueError: If mode string is not recognized.
            WiiMError: If the request fails.

        Example:
            ```python
            # Using friendly name
            await player.set_audio_output_mode("Line Out")
            await player.set_audio_output_mode("Optical Out")

            # Using integer
            await player.set_audio_output_mode(0)  # Line Out
            await player.set_audio_output_mode(1)  # Optical Out
            ```
        """
        await self.client.set_audio_output_mode(mode)
        # Refresh to get updated output mode state
        try:
            await self.refresh()
        except Exception:
            pass  # Don't fail if refresh fails

    # ===== Equalizer Control =====

    async def set_eq_preset(self, preset: str) -> None:
        """Set equalizer preset.

        Args:
            preset: Preset name (e.g., "flat", "classical", "jazz", "rock", "pop").

        Raises:
            ValueError: If preset name is invalid.
            WiiMError: If the request fails.
        """
        await self.client.set_eq_preset(preset)
        # Refresh to get updated EQ state
        try:
            await self.refresh()
        except Exception:
            pass  # Don't fail if refresh fails

    async def set_eq_custom(self, eq_values: list[int]) -> None:
        """Set custom 10-band equalizer values.

        Args:
            eq_values: List of exactly 10 integer values for the EQ bands.

        Raises:
            ValueError: If eq_values doesn't have exactly 10 bands.
            WiiMError: If the request fails.
        """
        await self.client.set_eq_custom(eq_values)
        # Refresh to get updated EQ state
        try:
            await self.refresh()
        except Exception:
            pass  # Don't fail if refresh fails

    async def set_eq_enabled(self, enabled: bool) -> None:
        """Enable or disable the equalizer.

        Args:
            enabled: True to enable EQ, False to disable.

        Raises:
            WiiMError: If the request fails.
        """
        await self.client.set_eq_enabled(enabled)
        # Refresh to get updated EQ state
        try:
            await self.refresh()
        except Exception:
            pass  # Don't fail if refresh fails

    async def get_eq(self) -> dict[str, Any]:
        """Get current equalizer band values.

        Returns:
            Dictionary containing current EQ band values.

        Raises:
            WiiMError: If the request fails.
        """
        return await self.client.get_eq()

    async def get_eq_presets(self) -> list[str]:
        """Get list of available equalizer presets.

        Returns:
            List of preset names available on the device.

        Raises:
            WiiMError: If the request fails.
        """
        return await self.client.get_eq_presets()

    async def get_eq_status(self) -> bool:
        """Get current equalizer enabled status.

        Returns:
            True if EQ is enabled, False if disabled.

        Raises:
            WiiMError: If the request fails.
        """
        return await self.client.get_eq_status()

    # ===== Device Management =====

    async def reboot(self) -> None:
        """Reboot the device.

        Note: This command may not return a response as the device will restart.
        The device will be unavailable for a short time after rebooting.

        Raises:
            WiiMError: If the request fails before the device reboots.
        """
        await self.client.reboot()
        # Mark as unavailable since device is rebooting
        self._available = False

    @property
    def play_state(self) -> str | None:
        """Current playback state from cached status.

        Returns:
            Play state string (e.g., 'play', 'pause', 'stop', 'idle') or None.
        """
        if self._status_model is None:
            return None
        return self._status_model.play_state

    async def get_play_state(self) -> str:
        """Get current playback state by querying device.

        Returns:
            Play state string (e.g., 'play', 'pause', 'stop').
        """
        status = await self.get_status()
        return status.play_state or "stop"

    # ===== Media Metadata Getters =====

    def _status_field(self, *names: str) -> str | None:
        """Return the first non-empty attribute from cached PlayerStatus."""
        if self._status_model is None:
            return None

        for n in names:
            if hasattr(self._status_model, n):
                val = getattr(self._status_model, n)
                if isinstance(val, str) and val.strip().lower() in {"unknown", "unknow", "none"}:
                    continue
                if val not in (None, ""):
                    return str(val) if val is not None else None
        return None

    @property
    def media_title(self) -> str | None:
        """Current track title from cached status."""
        return self._status_field("title")

    @property
    def media_artist(self) -> str | None:
        """Current track artist from cached status."""
        return self._status_field("artist")

    @property
    def media_album(self) -> str | None:
        """Current track album from cached status."""
        return self._status_field("album", "album_name")

    @property
    def media_duration(self) -> int | None:
        """Current track duration in seconds from cached status."""
        duration = self._status_field("duration")
        try:
            if duration is not None:
                result = int(float(duration))
                # Return None for zero duration (streaming services)
                if result == 0:
                    return None
                return result
            return None
        except (TypeError, ValueError):
            return None

    @property
    def media_position(self) -> int | None:
        """Current playback position in seconds with hybrid estimation.

        Uses hybrid approach:
        - When playing: Estimates position locally based on elapsed time
        - When paused/stopped: Returns actual position from device
        - Automatically corrects on seeks (position jumps >2 seconds)
        - Resets estimation on track changes

        This provides smooth position updates between polls while maintaining
        accuracy through periodic polling corrections.
        """
        # Get actual position from device
        position = self._status_field("position", "seek")
        try:
            if position is not None:
                pos_value = int(float(position))
                # Ensure position is non-negative
                if pos_value < 0:
                    return None

                # Clamp to known duration if available
                duration_value = self.media_duration
                if duration_value is not None and duration_value > 0:
                    if pos_value > duration_value:
                        pos_value = duration_value
            else:
                pos_value = None
        except (TypeError, ValueError):
            pos_value = None

        # Determine if actively playing
        play_state = self.play_state
        is_playing = play_state and play_state.lower() in ("play", "playing", "load")

        # Get track signature to detect track changes
        try:
            title = self._status_field("title") or ""
            artist = self._status_field("artist") or ""
            album = self._status_field("album") or ""
            current_signature = f"{title}|{artist}|{album}"
        except Exception:
            current_signature = ""

        # Detect track changes
        track_changed = (
            current_signature and self._last_track_signature and current_signature != self._last_track_signature
        )

        # Detect seeks (position jumps >2 seconds backward or >10 seconds forward)
        position_jumped = False
        if pos_value is not None and self._last_position is not None:
            jump_backward = pos_value + 2 < self._last_position
            jump_forward = pos_value > self._last_position + 10
            position_jumped = jump_backward or jump_forward

        # Reset estimation on track changes, seeks, or when position becomes None
        if track_changed or position_jumped or pos_value is None:
            self._estimated_position = None
            self._estimation_start_time = None
            self._estimation_base_position = None

        # Update estimation base when we get a new position from device
        if pos_value is not None:
            # If estimation not started or base changed significantly, reset
            if self._estimation_base_position is None or abs(pos_value - self._estimation_base_position) > 2:
                self._estimation_base_position = pos_value
                self._estimation_start_time = time.time()
                self._estimated_position = pos_value

        # Estimate position while playing
        if is_playing and self._estimation_base_position is not None and self._estimation_start_time is not None:
            elapsed = time.time() - self._estimation_start_time
            estimated = self._estimation_base_position + int(elapsed)

            # Clamp to duration if available
            duration_value = self.media_duration
            if duration_value is not None and duration_value > 0:
                estimated = min(estimated, duration_value)

            # Only use estimation if it's reasonable (not too far from base)
            # This prevents drift from accumulating too much
            max_drift = 30  # Allow up to 30 seconds of estimation
            if estimated <= self._estimation_base_position + max_drift:
                self._estimated_position = estimated
                return estimated

        # Return actual position (not playing, or estimation not available)
        if pos_value is not None:
            self._estimated_position = pos_value
            return pos_value

        # Fallback to last estimated position if available
        return self._estimated_position

    @property
    def media_position_updated_at(self) -> float | None:
        """Timestamp when media position was last updated.

        Updates timestamp when:
        - Track changes (metadata changes)
        - Position increases while playing
        - Position decreases significantly (track switch)
        """
        current_position = self.media_position

        # Derive track signature from metadata
        try:
            title = self._status_field("title") or ""
            artist = self._status_field("artist") or ""
            album = self._status_field("album") or ""
            current_signature = f"{title}|{artist}|{album}"
        except Exception:
            current_signature = ""

        previous_position = self._last_position
        previous_signature = self._last_track_signature

        # Determine if actively playing
        play_state = self.play_state
        is_playing = play_state and play_state.lower() in ("play", "playing", "load")

        # Update timestamp on new track or position change while playing
        track_changed = current_signature and current_signature != previous_signature
        position_decreased = (
            current_position is not None and previous_position is not None and current_position + 2 < previous_position
        )

        # Update tracking when position changes (from device or estimation)
        if (track_changed or position_decreased) and current_position is not None:
            self._last_position_update = time.time()
            self._last_position = current_position
            self._last_track_signature = current_signature
        elif (
            is_playing
            and current_position is not None
            and previous_position is not None
            and current_position > previous_position
        ):
            # Position increased while playing - update timestamp
            # Note: With hybrid estimation, this may be estimated position
            self._last_position_update = time.time()
            self._last_position = current_position
            self._last_track_signature = current_signature or previous_signature
        elif previous_position is None and current_position is not None:
            self._last_position_update = time.time()
            self._last_position = current_position
            self._last_track_signature = current_signature or previous_signature
        elif is_playing and current_position is not None:
            # Playing with position - update timestamp even if position didn't change
            # (estimation may be providing same value, but time is passing)
            self._last_position_update = time.time()
            self._last_position = current_position
            self._last_track_signature = current_signature or previous_signature

        # Ensure we always return a valid timestamp
        if self._last_position_update is None:
            self._last_position_update = time.time()

        return self._last_position_update

    @property
    def media_image_url(self) -> str | None:
        """Media image URL from cached status."""
        return self._status_field("entity_picture", "cover_url")

    @property
    def source(self) -> str | None:
        """Current source from cached status."""
        if self._status_model is None:
            return None
        return self._status_model.source

    @property
    def shuffle_state(self) -> bool | None:
        """Shuffle state from cached status."""
        if self._status_model is None:
            return None

        # Check specific shuffle field first
        shuffle_val = getattr(self._status_model, "shuffle", None)
        if shuffle_val is not None:
            if isinstance(shuffle_val, (bool, int)):
                return bool(int(shuffle_val))
            shuffle_str = str(shuffle_val).strip().lower()
            return shuffle_str in {"1", "true", "shuffle"}

        # Check loop_mode bit flags directly (more accurate than play_mode)
        # loop_mode: bit 0=repeat_one, bit 1=repeat_all, bit 2=shuffle
        loop_mode = getattr(self._status_model, "loop_mode", None)
        if loop_mode is not None:
            try:
                loop_val = int(loop_mode)
                is_shuffle = bool(loop_val & 4)  # bit 2
                return is_shuffle
            except (TypeError, ValueError):
                pass  # Fall through to play_mode check

        # Check play_mode field (fallback)
        play_mode = getattr(self._status_model, "play_mode", None)
        if play_mode is not None:
            mode_str = str(play_mode).strip().lower()
            return "shuffle" in mode_str

        return None

    @property
    def repeat_mode(self) -> str | None:
        """Repeat mode from cached status: 'one', 'all', or 'off'."""
        if self._status_model is None:
            return None

        # Check specific repeat field first
        repeat_val = getattr(self._status_model, "repeat", None)
        if repeat_val is not None:
            repeat_str = str(repeat_val).strip().lower()
            if repeat_str in {"one", "single", "repeat_one", "repeatone", "1"}:
                return "one"
            elif repeat_str in {"all", "repeat_all", "repeatall", "2"}:
                return "all"
            else:
                return "off"

        # Check loop_mode bit flags directly (more accurate than play_mode)
        # loop_mode: bit 0=repeat_one, bit 1=repeat_all, bit 2=shuffle
        loop_mode = getattr(self._status_model, "loop_mode", None)
        if loop_mode is not None:
            try:
                loop_val = int(loop_mode)
                is_repeat_one = bool(loop_val & 1)  # bit 0
                is_repeat_all = bool(loop_val & 2)  # bit 1
                if is_repeat_one:
                    return "one"
                elif is_repeat_all:
                    return "all"
            except (TypeError, ValueError):
                pass  # Fall through to play_mode check

        # Check play_mode field (fallback)
        play_mode = getattr(self._status_model, "play_mode", None)
        if play_mode is not None:
            mode_str = str(play_mode).strip().lower()
            if "repeat_one" in mode_str or mode_str in {"one", "single"}:
                return "one"
            elif "repeat_all" in mode_str or mode_str in {"all"}:
                return "all"
            elif "repeat" in mode_str and "shuffle" not in mode_str:
                return "all"

        return "off"

    @property
    def eq_preset(self) -> str | None:
        """Current EQ preset from cached status."""
        if self._status_model is None:
            return None
        return self._status_model.eq_preset

    @property
    def shuffle(self) -> bool | None:
        """Shuffle state from cached status (alias for shuffle_state).

        Returns:
            True if shuffle is enabled, False if disabled, None if unknown.
        """
        return self.shuffle_state

    @property
    def repeat(self) -> str | None:
        """Repeat mode from cached status (alias for repeat_mode).

        Returns:
            Repeat mode: 'one', 'all', or 'off'.
        """
        return self.repeat_mode

    @property
    def wifi_rssi(self) -> int | None:
        """Wi-Fi signal strength (RSSI) from cached status.

        Returns:
            RSSI value in dBm (typically negative, e.g., -70) or None if unknown.
        """
        if self._status_model is None:
            return None
        return self._status_model.wifi_rssi

    @property
    def available_sources(self) -> list[str] | None:
        """Available input sources from cached device info.

        Returns:
            List of available source names (e.g., ["bluetooth", "line_in", "optical"])
            or None if device info is not available.
            Note: WiFi is excluded as it's not a selectable source (it's the network
            connection that enables other services).
        """
        if self._device_info is None:
            return None
        if self._device_info.input_list is None:
            return None
        # Filter out wifi as it's not a selectable source
        return [source for source in self._device_info.input_list if source and source.lower() != "wifi"]

    @property
    def audio_output_mode(self) -> str | None:
        """Current audio output mode as friendly name.

        Returns:
            Friendly name string (e.g., "Line Out", "Optical Out", "Bluetooth Out")
            or None if output status is not available or not supported.
        """
        if self._audio_output_status is None:
            return None

        hardware_mode = self._audio_output_status.get("hardware")
        if hardware_mode is None:
            return None

        # Check if Bluetooth output is active (takes precedence)
        source = self._audio_output_status.get("source")
        # Handle both string and int source values
        if source == 1 or source == "1":  # Bluetooth output active
            return "Bluetooth Out"

        # Convert hardware_mode to int if it's a string
        try:
            mode_int = int(hardware_mode) if isinstance(hardware_mode, str) else hardware_mode
        except (ValueError, TypeError):
            return None

        # Otherwise use hardware mode
        return self.client.audio_output_mode_to_name(mode_int)

    @property
    def audio_output_mode_int(self) -> int | None:
        """Current audio output mode as integer.

        Returns:
            Mode integer (0-4) or None if output status is not available.
        """
        if self._audio_output_status is None:
            return None

        # Check if Bluetooth output is active (takes precedence)
        source = self._audio_output_status.get("source")
        # Handle both string and int source values
        if source == 1 or source == "1":  # Bluetooth output active
            return 4  # Bluetooth Out

        # Otherwise use hardware mode (convert to int if string)
        hardware_mode = self._audio_output_status.get("hardware")
        if hardware_mode is None:
            return None

        try:
            return int(hardware_mode) if isinstance(hardware_mode, str) else hardware_mode
        except (ValueError, TypeError):
            return None

    @property
    def available_output_modes(self) -> list[str]:
        """Available audio output modes for this device.

        Determines available modes based on device model and capabilities.
        Different WiiM models support different output combinations:
        - WiiM Pro: Line Out, Optical Out, Coax Out, Bluetooth Out
        - WiiM Mini: Line Out, Optical Out (no Coax, Bluetooth Out is input-only)
        - WiiM Amp: Line Out (integrated amplifier, no digital outputs)
        - WiiM Ultra: Line Out, Optical Out, Coax Out, Bluetooth Out, HDMI Out

        Returns:
            List of available output mode friendly names.
            Returns empty list if audio output is not supported.
        """
        # Check if device supports audio output
        if not self.client.capabilities.get("supports_audio_output", False):
            return []

        # Get device model to determine available modes
        model = None
        if self._device_info:
            model = self._device_info.model

        if not model:
            # Fallback: return all standard modes if model unknown
            return ["Line Out", "Optical Out", "Coax Out", "Bluetooth Out"]

        model_lower = model.lower()

        # Determine available modes based on device model
        if "wiim amp" in model_lower:
            # WiiM Amp: Only Line Out (integrated amplifier)
            return ["Line Out"]
        elif "wiim mini" in model_lower:
            # WiiM Mini: Line Out, Optical Out (no Coax, Bluetooth is input-only)
            return ["Line Out", "Optical Out"]
        elif "wiim ultra" in model_lower:
            # WiiM Ultra: All outputs including HDMI
            return ["Line Out", "Optical Out", "Coax Out", "Bluetooth Out", "HDMI Out"]
        elif "wiim pro" in model_lower or "wiim" in model_lower:
            # WiiM Pro and variants: Line Out, Optical Out, Coax Out, Bluetooth Out
            return ["Line Out", "Optical Out", "Coax Out", "Bluetooth Out"]
        else:
            # Unknown WiiM device or other LinkPlay device - return standard modes
            # Most LinkPlay devices support at least Line Out and Optical Out
            return ["Line Out", "Optical Out", "Coax Out", "Bluetooth Out"]

    @property
    def is_bluetooth_output_active(self) -> bool:
        """Check if Bluetooth output is currently active.

        Returns:
            True if Bluetooth output is active, False otherwise.
        """
        if self._audio_output_status is None:
            return False

        source = self._audio_output_status.get("source")
        return source == 1  # 1 = Bluetooth output active

    # ===== Group Operations (Role-Specific) =====

    async def create_group(self) -> Group:
        """Create a new group with this player as master.

        This player must be solo to create a group.

        Returns:
            Group instance with this player as master.

        Raises:
            RuntimeError: If this player is already in a group.
            WiiMError: If the group creation fails.
        """
        if not self.is_solo:
            raise RuntimeError(f"Cannot create group: player is {self.role}")

        # Create group via API
        await self.client.create_group()

        # Create Group object (will be populated with slaves via discovery)
        # Import here to avoid circular import
        from .group import Group as GroupClass

        group = GroupClass(self)
        self._group = group

        return group

    async def join_group(self, master: Player) -> None:
        """Join an existing group.

        This player must be solo to join a group.

        Args:
            master: The master player of the group to join.

        Raises:
            RuntimeError: If this player is already in a group.
            WiiMError: If joining fails.
        """
        if not self.is_solo:
            raise RuntimeError(f"Cannot join group: player is {self.role}")

        if master.group is None:
            raise ValueError("Master player is not in a group")

        # Join group via API
        await self.client.join_slave(master.host)

        # Ensure master's device_info is loaded so we can get its name
        # Refresh if device_info is missing or name is not available
        if master._device_info is None or master.name is None:
            try:
                await master.refresh()
            except Exception:
                # If refresh fails, we'll use host as fallback in add_slave
                pass

        # Add to group
        master.group.add_slave(self)

    async def leave_group(self) -> None:
        """Leave the current group.

        If this player is the master, the group is disbanded.
        If this player is a slave, it leaves the group.

        Raises:
            RuntimeError: If this player is not in a group.
            WiiMError: If leaving fails.
        """
        if self.is_solo:
            raise RuntimeError("Player is not in a group")

        group = self._group
        if group is None:
            raise RuntimeError("Group reference is None")

        if self.is_master:
            # Disband the group
            await group.disband()
        else:
            # Leave as slave
            await self.client.leave_group()
            group.remove_slave(self)
            # Note: remove_slave() will clear the multiroom source

            # If group is now empty (no slaves), auto-disband it
            # A group with only a master is effectively a solo device
            if len(group.slaves) == 0:
                _LOGGER.debug("Group is now empty, auto-disbanding (master: %s)", group.master.host)
                await group.disband()

    async def get_diagnostics(self) -> dict[str, Any]:
        """Get comprehensive diagnostic information for this player.

        This method collects all available diagnostic data including device info,
        status, capabilities, multiroom information, UPnP statistics, and API metrics.

        Returns:
            Dictionary with complete diagnostic information:
            - device: Device information (model, firmware, MAC, IP, etc.)
            - status: Current playback state
            - capabilities: Device capabilities
            - multiroom: Multiroom group information (if in a group)
            - group_info: Detailed group membership info
            - upnp: UPnP event statistics (if UPnP is enabled)
            - api_stats: API request statistics
            - connection_stats: Connection quality metrics
            - audio_output: Audio output mode status
            - eq: Current EQ settings (if available)
        """
        diagnostics: dict[str, Any] = {
            "timestamp": time.time(),
            "host": self.host,
        }

        # Device information
        try:
            if self._device_info:
                diagnostics["device"] = {
                    "uuid": self._device_info.uuid,
                    "name": self._device_info.name,
                    "model": self._device_info.model,
                    "firmware": self._device_info.firmware,
                    "mac": self._device_info.mac,
                    "ip": self._device_info.ip,
                    "preset_key": self._device_info.preset_key,
                    "input_list": self._device_info.input_list,
                    "hardware": self._device_info.hardware,
                    "wmrm_version": self._device_info.wmrm_version,
                    "mcu_ver": self._device_info.mcu_ver,
                    "dsp_ver": self._device_info.dsp_ver,
                }
            else:
                # Fetch if not cached
                device_info = await self.get_device_info()
                diagnostics["device"] = {
                    "uuid": device_info.uuid,
                    "name": device_info.name,
                    "model": device_info.model,
                    "firmware": device_info.firmware,
                    "mac": device_info.mac,
                    "ip": device_info.ip,
                    "preset_key": device_info.preset_key,
                    "input_list": device_info.input_list,
                    "hardware": device_info.hardware,
                    "wmrm_version": device_info.wmrm_version,
                    "mcu_ver": device_info.mcu_ver,
                    "dsp_ver": device_info.dsp_ver,
                }
        except Exception as err:
            diagnostics["device"] = {"error": str(err)}

        # Current status
        try:
            if self._status_model:
                diagnostics["status"] = {
                    "play_state": self._status_model.play_state,
                    "volume": self._status_model.volume,
                    "mute": self._status_model.mute,
                    "source": self._status_model.source,
                    "position": self._status_model.position,
                    "duration": self._status_model.duration,
                    "title": self._status_model.title,
                    "artist": self._status_model.artist,
                    "album": self._status_model.album,
                }
            else:
                status = await self.get_status()
                diagnostics["status"] = {
                    "play_state": status.play_state,
                    "volume": status.volume,
                    "mute": status.mute,
                    "source": status.source,
                    "position": status.position,
                    "duration": status.duration,
                    "title": status.title,
                    "artist": status.artist,
                    "album": status.album,
                }
        except Exception as err:
            diagnostics["status"] = {"error": str(err)}

        # Capabilities
        try:
            diagnostics["capabilities"] = self.client.capabilities.copy()
        except Exception as err:
            diagnostics["capabilities"] = {"error": str(err)}

        # Multiroom information
        try:
            multiroom = await self.client.get_multiroom_status()
            diagnostics["multiroom"] = multiroom
        except Exception:
            diagnostics["multiroom"] = None

        # Group info
        try:
            group_info = await self.client.get_device_group_info()
            diagnostics["group_info"] = {
                "role": group_info.role,
                "master_host": group_info.master_host,
                "master_uuid": group_info.master_uuid,
                "slave_hosts": group_info.slave_hosts,
                "slave_count": group_info.slave_count,
            }
        except Exception:
            diagnostics["group_info"] = None

        # UPnP statistics (if available)
        try:
            # Check if Player has UPnP eventer attached (via monitor scripts, etc.)
            # This is optional - not all Players have UPnP enabled
            if hasattr(self, "_upnp_eventer") and self._upnp_eventer:
                diagnostics["upnp"] = self._upnp_eventer.statistics
            else:
                diagnostics["upnp"] = None
        except Exception:
            diagnostics["upnp"] = None

        # API statistics
        try:
            diagnostics["api_stats"] = self.client.api_stats
        except Exception:
            diagnostics["api_stats"] = None

        # Connection statistics
        try:
            diagnostics["connection_stats"] = self.client.connection_stats
        except Exception:
            diagnostics["connection_stats"] = None

        # Audio output status
        try:
            if self._audio_output_status:
                diagnostics["audio_output"] = self._audio_output_status
            else:
                if self.client.capabilities.get("supports_audio_output", False):
                    audio_output = await self.client.get_audio_output_status()
                    diagnostics["audio_output"] = audio_output
                else:
                    diagnostics["audio_output"] = None
        except Exception:
            diagnostics["audio_output"] = None

        # EQ settings
        try:
            if self.client.capabilities.get("supports_eq", False):
                eq = await self.client.get_eq()
                diagnostics["eq"] = eq
            else:
                diagnostics["eq"] = None
        except Exception:
            diagnostics["eq"] = None

        # Role
        diagnostics["role"] = self.role
        diagnostics["available"] = self.available

        return diagnostics

    def __repr__(self) -> str:
        """String representation."""
        role = self.role
        return f"Player(host={self.host!r}, role={role!r})"
