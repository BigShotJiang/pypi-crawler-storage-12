=======
Credits
=======

Development Lead
----------------

* Valery Melou <me@valerymelou.com>

Maintainers
----------------
* Frederich Pedersen <frodo@hobbits.dk>

Contributors
------------

* Paulo Reis <paulovitin@gmail.com>
* Mike Nitchie <mikenitchie@gmail.com>