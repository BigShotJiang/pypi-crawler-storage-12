# -*- coding: utf-8
from django.apps import AppConfig


class ActiveLinkConfig(AppConfig):
    name = "active_link"
