# Exceptions

```{eval-rst}
.. automodule:: ape_etherscan.exceptions
    :members:
    :show-inheritance:
```
