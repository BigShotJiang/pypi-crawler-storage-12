"""Reusable optimization constraints (mobilisation, sequencing, etc.)."""
