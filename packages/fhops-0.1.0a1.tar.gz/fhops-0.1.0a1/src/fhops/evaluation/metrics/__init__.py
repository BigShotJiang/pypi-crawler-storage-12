"""KPI calculations and reporting aggregations."""
