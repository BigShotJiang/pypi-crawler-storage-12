"""Reporting helpers (writers, visualisation hooks)."""
