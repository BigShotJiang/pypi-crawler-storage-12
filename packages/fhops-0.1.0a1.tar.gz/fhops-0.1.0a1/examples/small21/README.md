# FHOPS Small21

Half-scale variant of the med42 scenario (21 days, 4 machines, 10 blocks).

Use this for quick MIP baselines and convergence diagnostics.
