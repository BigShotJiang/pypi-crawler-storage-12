Roadmap Summary
===============

FHOPS maintains its authoritative roadmap in ``FHOPS_ROADMAP.md`` at the repository root. The key
phases are mirrored below; consult the markdown file for live checklists and detailed next steps.

.. literalinclude:: ../FHOPS_ROADMAP.md
   :language: markdown
   :start-after: # FHOPS Roadmap
