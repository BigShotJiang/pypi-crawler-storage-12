``fhops.evaluation`` Package
============================

.. automodule:: fhops.evaluation
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: fhops.evaluation.metrics.kpis
   :members:
   :undoc-members:
   :show-inheritance:
