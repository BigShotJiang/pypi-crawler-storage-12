| Algorithm | Scenario | Best Objective | Mean Objective | Runs | Summary Best | Configurations |
| --- | --- | --- | --- | --- | --- | --- |
| bayes | FHOPS MiniToy | 3.000 | 3.000 | 1 |  |  |
| grid | FHOPS MiniToy | 9.000 | 9.000 | 1 |  |  |
| random | FHOPS MiniToy | -6.000 | -6.000 | 1 |  |  |
