| Algorithm | Scenario | Best (baseline) | Mean (baseline) | Runs (baseline) | Best (experiment) | Δ Best (experiment) | Mean (experiment) | Runs (experiment) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| bayes | FHOPS MiniToy | 3.000 | 3.000 | 1 | 3.000 | +0.000 | 3.000 | 1 |
| grid | FHOPS MiniToy | 9.000 | 9.000 | 1 | 9.000 | +0.000 | 9.000 | 1 |
| random | FHOPS MiniToy | -6.000 | -6.000 | 1 | -6.000 | +0.000 | -6.000 | 1 |
