Aggregation Helpers
===================

The module :mod:`fhops.evaluation.playback.aggregates` provides convenience functions to transform
playback summaries into Pandas dataframes and higher-level KPI-ready rollups.

API summary
-----------

.. automodule:: fhops.evaluation.playback.aggregates
   :members:
   :undoc-members:
   :show-inheritance:
