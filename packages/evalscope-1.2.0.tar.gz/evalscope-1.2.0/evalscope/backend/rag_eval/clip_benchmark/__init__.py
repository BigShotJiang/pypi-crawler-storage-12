from evalscope.backend.rag_eval.clip_benchmark.arguments import Arguments
from evalscope.backend.rag_eval.clip_benchmark.task_template import evaluate
