"""Contains all the data models used in inputs/outputs"""

from .search_avg import SearchAVG

__all__ = ("SearchAVG",)
