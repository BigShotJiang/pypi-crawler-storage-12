from enum import StrEnum


class GraphQlMethodType(StrEnum):
    query = "query"
    mutation = "mutation"
