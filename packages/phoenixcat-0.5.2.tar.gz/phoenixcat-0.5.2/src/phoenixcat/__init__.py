from ._init import _init_fn


__version__ = "0.5.2"


def init():
    _init_fn()
