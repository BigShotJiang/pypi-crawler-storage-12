"""Authorization for VW IDK servers."""
