"""Supabase MCP Server package."""

from supabase_mcp._version import __version__, version, version_tuple

__all__ = ["__version__", "version", "version_tuple"]
