-- Create a migration
INSERT INTO supabase_migrations.schema_migrations
(version, name, statements)
VALUES ('{version}', '{name}', ARRAY['{statements}']);
