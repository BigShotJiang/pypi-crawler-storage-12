class BaseLogger:
    def __init__(self, config):
        self.config = config


class BaseFinder:
    def __init__(self, config):
        self.config = config