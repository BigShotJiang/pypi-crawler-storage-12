"""Expected data definitions for NBA Stats API endpoints."""
