# Playwright Stealth Plugin

Playwright Plugin for Anti-Bot Stealth.

_Easy to work - No need for extra documentation !_

**(Chromium Browser Support -- ASYNC METHOD)**
