
typedef struct SymbolicBranchMeta {
    uint64_t pc;
} SymbolicBranchMeta;

