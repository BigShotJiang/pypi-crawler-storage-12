"""
Structures to support the taint subsystem.
"""
from .TaintQuery import TaintQuery
