from __future__ import annotations

from ..constants import Subunit
from ..subunit import SubunitBase


class Uaw(
    SubunitBase,
):
    id = Subunit.UAW
