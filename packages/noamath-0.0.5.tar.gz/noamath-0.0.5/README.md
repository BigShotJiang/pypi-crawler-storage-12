The License is a source available license[LICENSE](LICENSE), there is very importent information inside of the license,
please check the license.

To request something to me ask GanonBlasterTheGrey@gmail.com or NoahHolmen8@hotmail.com

The current version is 0.0.4.1

The entire 0.0.4 is just info updates

Please report any bugs,issues and feedback to me.

The name of the library is noamath.

noamath installation:
pip install noamath

how to use noamath:

The functions for calculating area are squareArea, circleArea and rectArea.

squareArea calculates the area of a square, there is one argument, it should be the length of one side of the square.

circleArea calculates the area of a circle, there is one argument, it should be the radius of the circle.

rectArea calculates the area of a rectangle, there is two arguments, the first one should be one side and the second argument should be the side right next to, it should not be the opposite side.

The other functions add, remove, divide, multiply, pow, sqrt, dot.

In the add function you have atleast two arguments it can be infinite, it just adds the numbers.

In the remove function you have atleast two arguments it can be infinite, it just removes the numbers.

In the divide function you have atleast two arguments it can be infinite, it just divides the numbers.

In the multiply function you have atleast two arguments it can be infinite, it just multiplys the numbers.

In the pow function there are two arguments, both arguments has to have the same shape and they both have to be vectors, it dot products the two vectors.

In the sqrt function there is one argument, it returns the square root of the number.

The class is value
remember its lowercase

You just put a value inside of value