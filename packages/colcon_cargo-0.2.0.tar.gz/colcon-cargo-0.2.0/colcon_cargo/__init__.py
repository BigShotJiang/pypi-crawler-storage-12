# Copyright 2018 Easymov Robotics
# Licensed under the Apache License, Version 2.0

__version__ = '0.2.0'
