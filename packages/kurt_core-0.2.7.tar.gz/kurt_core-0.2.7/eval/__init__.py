"""Kurt Evaluation Framework - Automated testing for Kurt agent behavior."""
