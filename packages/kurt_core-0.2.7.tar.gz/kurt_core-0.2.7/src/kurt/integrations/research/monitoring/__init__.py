"""Monitoring adapters for research signal detection."""

from kurt.integrations.research.monitoring.models import Signal

__all__ = ["Signal"]
