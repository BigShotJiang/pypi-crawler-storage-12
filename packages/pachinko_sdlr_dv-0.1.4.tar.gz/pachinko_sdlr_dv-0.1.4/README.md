##PACHINKO##

Reglas del juego: Es una máquina de pachinko! Para quien no sepa cómo funciona, pachinko es una versión japonesa de las máquinas tragaperras, pero con bolas.
El objetivo es meter 20 bolas en agujeros que suman puntos. Puedes meter hasta 10 bolas por tiro, y tienes 8 tiros.
Cuando llegues a 20 bolas acertadas, girará el tambor tipo tragaperras. Si el 1º y 3º número coinciden, entrarás en modo fiebre.
En modo fiebre puedes meter hasta 20 bolas por intento durante 5 rondas, y dependiendo de tus aciertos verás cinemáticas visuales con bonificaciones.
Buena suerte!