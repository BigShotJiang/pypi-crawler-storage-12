# upver

## Overview
`upver` was created to help with updating the version numbers in flutter projects.