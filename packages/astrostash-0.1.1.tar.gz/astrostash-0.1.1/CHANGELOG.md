# v0.1.1

- Removed f-string queries from Heasarc #13
- Refactor `SQLiteDB.fetch sync()` to clean up and abstract out some code in #12
- Included `schema/base.sql` in package data in #11
