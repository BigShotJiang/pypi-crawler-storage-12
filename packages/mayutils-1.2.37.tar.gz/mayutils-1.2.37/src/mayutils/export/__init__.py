from mayutils.environment.filesystem import get_root


OUTPUT_FOLDER = get_root() / "Outputs"
