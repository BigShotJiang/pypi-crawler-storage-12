#!/usr/bin/env python


from .core import ASGIMiddlewarePath, ASGIMiddlewareStaticFile  # noqa: F401

VERSION = "0.6.2"
