from django.apps import AppConfig


class MapEntityConfig(AppConfig):
    name = "mapentity"
