"""Compatibility wrapper for running the Subnet Calculator MCP server."""

from subnet_calculator_mcp.server import main


if __name__ == "__main__":  # pragma: no cover - convenience wrapper
    main()