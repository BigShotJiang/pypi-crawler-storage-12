BASE_URL = "https://dhruva-api.bhashini.gov.in/services/inference/pipeline"
DEFAULT_HEADERS = {
    "Content-Type": "application/json",
    "Accept": "*/*",
    "User-Agent": "bhashini-python-client"
}
