"""Auto-generated file containing build-time git tag and hash."""

GIT_TAG = "latest"
GIT_HASH = "2b13e96"
