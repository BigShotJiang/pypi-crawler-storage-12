# WindowsLinuxMac Clear
A simple solution, to clear the screen in all 3 major operating systems, with a simple command:

```
# Import
from wlmclear import clear
# Use it
clear()