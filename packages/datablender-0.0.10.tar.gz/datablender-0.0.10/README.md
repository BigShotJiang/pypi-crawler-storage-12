

# Data blender
Data utils is a python package for data utilities.
## Develop
### Install
* Install anaconda
```conda create --name dev```
```conda install pip```
```pip install --user -e .[dev]```


### Publish package
```python -m build```
```python -m twine upload dist/*```




# Install the package locally
```pip install -r requirements.txt --user```

on the VM 
"C:/Program Files/INRO/Emme/Emme 4/Emme-23.00.01.23/Python37/python.exe" -m pip install -r requirements.txt --user
