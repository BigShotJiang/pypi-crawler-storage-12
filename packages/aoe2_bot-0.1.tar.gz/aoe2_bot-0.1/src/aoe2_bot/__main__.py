from aoe2_bot._bot import main

main()
