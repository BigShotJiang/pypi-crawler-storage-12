v4_sql = 'UPDATE properties SET type = "text" WHERE type="string";'
