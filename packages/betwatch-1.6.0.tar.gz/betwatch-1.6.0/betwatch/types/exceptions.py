class NotEntitledError(Exception):
    """Raised when a user is not entitled to a resource"""

    pass
