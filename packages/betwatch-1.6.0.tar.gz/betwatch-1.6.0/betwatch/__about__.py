# SPDX-FileCopyrightText: 2022-present Jamie Watts <jamie@betwatch.com>
#
# SPDX-License-Identifier: MIT
import importlib.metadata

__version__ = importlib.metadata.version("betwatch")
