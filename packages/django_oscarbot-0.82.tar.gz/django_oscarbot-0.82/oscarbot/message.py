class Message:
    pass  # TODO: make message to send in response
