class Result:
    pass
