
These changes are listed in decreasing version number order.


Release 0.1.3
-------------

Release date was |today|

* added tests and docs


Release 0.1.2
-------------

Release date was Thursday, 10 October 2024

* fixed imports


Release 0.1.1
-------------

Release date was Thursday, 10 October 2024

* fixed 'matplotlib' dependency


Release 0.1
-----------

Release date was Thursday, 10 October 2024

* initial release