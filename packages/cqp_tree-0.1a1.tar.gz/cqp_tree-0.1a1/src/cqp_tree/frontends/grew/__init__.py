from cqp_tree.frontends.grew.translator import translate_grew
