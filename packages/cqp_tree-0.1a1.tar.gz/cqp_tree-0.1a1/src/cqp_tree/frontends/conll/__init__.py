from .translator import translate_conll
