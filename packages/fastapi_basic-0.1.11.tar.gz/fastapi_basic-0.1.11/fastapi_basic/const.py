LOG_DEFAULT_LOGGER_NAME = "uvicorn"
LOG_FMT = '%(asctime)s %(filename)s %(levelname)s: %(message)s'

CELERY_CONFIG = ["CELERY_APP", "CELERY_BROKER_URL", "CELERY_BACKEND_URL"]