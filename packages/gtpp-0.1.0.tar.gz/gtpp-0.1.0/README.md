# Game To PyPI (gtpp)

Virtual pet game with GUI, market, daily rewards, and battles.
Install: `pip install gtpp`

Usage:
```python
from game_to_pypi import launch_gui
launch_gui()
