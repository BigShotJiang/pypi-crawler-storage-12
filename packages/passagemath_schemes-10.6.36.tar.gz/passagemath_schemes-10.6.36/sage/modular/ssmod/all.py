# sage_setup: distribution = sagemath-schemes
from sage.misc.lazy_import import lazy_import

lazy_import("sage.modular.ssmod.ssmod", ['dimension_supersingular_module',
                                         'supersingular_j',
                                         'SupersingularModule',
                                         'supersingular_D'])
del lazy_import
