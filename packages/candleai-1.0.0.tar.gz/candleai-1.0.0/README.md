# CandleAI Python Client

Python клиент для работы с CandleAI API.

## Установка

```bash
pip install candleai