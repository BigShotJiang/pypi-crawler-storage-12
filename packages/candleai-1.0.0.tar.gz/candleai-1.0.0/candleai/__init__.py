"""
CandleAI Python Client
Универсальный клиент для CandleAI API
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

# Импортируем все необходимое
from .client import CandleAIClient
from .exceptions import (
    CandleAIError,
    AuthenticationError,
    RateLimitError,
    ConnectionError,
    APIError
)

# Определяем что импортировать при from candleai import *
__all__ = [
    'CandleAIClient',
    'CandleAIError',
    'AuthenticationError',
    'RateLimitError',
    'ConnectionError',
    'APIError'
]