"""Tests for eonapi."""
