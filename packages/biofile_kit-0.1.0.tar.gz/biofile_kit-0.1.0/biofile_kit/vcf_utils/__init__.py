from biofile_kit.vcf_utils.vcf2gt import run as vcf2gt

__version__ = '0.1.0'

__all__ = [
    'vcf2gt',
    __version__
]