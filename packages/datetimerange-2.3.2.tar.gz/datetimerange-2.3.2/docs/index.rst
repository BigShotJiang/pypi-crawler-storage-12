Welcome to DateTimeRange's documentation!
=========================================

.. raw:: html

    <div class='ghscard' src='//raw.githubusercontent.com/thombashi/thombashi.github.io/master/data/thombashi_DateTimeRange.json'></div>
    <script src='//cdn.jsdelivr.net/gh/thombashi/ghscard@master/dist/ghscard.min.js'></script>
    <br />
    <br />

.. toctree::
   :caption: Table of Contents
   :maxdepth: 4
   :numbered:

   pages/introduction/index
   pages/examples/index
   pages/reference/index
   pages/changelog_ref
   pages/links


Indices and tables
==================

* :ref:`genindex`
