DateTimeRange class
-------------------

.. autoclass:: datetimerange.DateTimeRange
    :members:
    :special-members:
    :show-inheritance:
