.. include:: sponsors.rst


.. include:: genindex.rst


Links
=====
- `GitHub repository <https://github.com/thombashi/DateTimeRange>`__
- `Issue tracker <https://github.com/thombashi/DateTimeRange/issues>`__
- `pip: A tool for installing python packages <https://pip.pypa.io/en/stable/>`__
