Features
============
Features of ``DateTimeRange`` class include:

- Supported operations:
    - Equation
    - Addition
    - Subtraction
    - Intersection
    - Union
    - Contains
    - Truncate
    - Split
    - Iteration
- Timezone support
- Daylight saving time support
