Installation
============

Installation: pip
------------------------------
::

    pip install DateTimeRange


Installation: conda
------------------------------
::

    conda install -c conda-forge datetimerange


Dependencies
============
- Python 3.9+
- `Python package dependencies (automatically installed) <https://github.com/thombashi/DateTimeRange/network/dependencies>`__
