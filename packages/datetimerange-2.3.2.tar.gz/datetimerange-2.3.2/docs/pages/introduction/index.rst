DateTimeRange
=============

.. include:: badges.txt


Summary
-------

.. include:: summary.txt


.. include:: installation.rst

.. include:: features.rst
