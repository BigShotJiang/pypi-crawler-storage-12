Changelog
==================

`Reference <https://github.com/thombashi/DateTimeRange/blob/master/CHANGELOG.md>`__

.. literalinclude:: CHANGELOG.md
