﻿sf\_quant.optimizer.FullInvestment
==================================

.. currentmodule:: sf_quant.optimizer

.. autoclass:: FullInvestment

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FullInvestment.__init__
   
   

   
   
   