﻿sf\_quant.optimizer.ZeroBeta
============================

.. currentmodule:: sf_quant.optimizer

.. autoclass:: ZeroBeta

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ZeroBeta.__init__
   
   

   
   
   