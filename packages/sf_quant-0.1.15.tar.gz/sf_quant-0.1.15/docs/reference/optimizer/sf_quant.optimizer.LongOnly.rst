﻿sf\_quant.optimizer.LongOnly
============================

.. currentmodule:: sf_quant.optimizer

.. autoclass:: LongOnly

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LongOnly.__init__
   
   

   
   
   