﻿sf\_quant.data.load\_assets\_by\_date
=====================================

.. currentmodule:: sf_quant.data

.. autofunction:: load_assets_by_date