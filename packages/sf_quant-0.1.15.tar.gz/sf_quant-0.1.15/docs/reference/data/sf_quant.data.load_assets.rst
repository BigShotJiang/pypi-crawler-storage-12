﻿sf\_quant.data.load\_assets
===========================

.. currentmodule:: sf_quant.data

.. autofunction:: load_assets