# -*- coding: utf-8 -*-

"""Top-level package for Bonus Click."""

__author__ = """Devon Bray"""
__email__ = "dev@esologic.com"
