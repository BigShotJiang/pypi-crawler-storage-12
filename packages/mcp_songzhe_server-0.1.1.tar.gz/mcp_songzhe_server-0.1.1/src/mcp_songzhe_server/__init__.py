def main() -> None:
    print("Hello from mcp-songzhe-server!")
