## 介绍

这是一个使用高德地图的天气接口，获取当前城市天气的demo。

## 使用方法

## MCP 配置

### uvx

```json

{

  "mcpServers": {

    "duckduckgo": {

      "command": "uvx",

      "args": [

        "mcp-gaodeweather-server"

      ]

    }

  }

}