## cdf 

### Improved

- Interactive onboarding in cdf init

## templates

No changes.