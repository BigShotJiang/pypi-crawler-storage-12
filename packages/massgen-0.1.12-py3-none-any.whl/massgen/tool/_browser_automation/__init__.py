# -*- coding: utf-8 -*-
"""Browser automation tools for MassGen."""

from .browser_automation_tool import browser_automation, simple_browser_automation

__all__ = ["browser_automation", "simple_browser_automation"]
