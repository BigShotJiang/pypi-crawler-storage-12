# -*- coding: utf-8 -*-
"""Claude Computer Use tool for MassGen framework."""

from .claude_computer_use_tool import claude_computer_use

__all__ = ["claude_computer_use"]
