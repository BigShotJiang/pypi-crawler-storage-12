from gymnasium.envs.registration import register

register(id="Parking-v0", entry_point="parking_env.parking:Parking")
