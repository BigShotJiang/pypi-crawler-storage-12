from .time import get_current_timestamp

__all__ = ["get_current_timestamp"]