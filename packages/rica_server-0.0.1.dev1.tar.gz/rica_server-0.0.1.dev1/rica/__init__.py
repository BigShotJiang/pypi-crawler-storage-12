"""
Copyright(c)MINIOpenSource 2025

RiCA Server for Python
"""

from __future__ import annotations

import asyncio
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

from . import connector
from .server import Application, CallBack, RiCA

__all__ = ["RiCA", "Application", "CallBack", "connector"]

try:
    _loop = asyncio.get_running_loop()
except RuntimeError:
    _loop = asyncio.new_event_loop()
    asyncio.set_event_loop(_loop)

_DISTRIBUTION_NAME = "rica-server"


def _read_version_fallback() -> str:
    try:
        import tomllib

        root = Path(__file__).resolve().parent.parent
        pyproject = root / "pyproject.toml"
        if pyproject.is_file():
            with pyproject.open("rb") as f:
                data = tomllib.load(f)
                v = data.get("project", {}).get("version")
                if isinstance(v, str) and v:
                    return v
    except Exception:
        pass
    return "unspecified"


try:
    __version__ = version(_DISTRIBUTION_NAME)
except PackageNotFoundError:
    __version__ = _read_version_fallback()
