from . import prompt

__all__ = ["prompt"]
