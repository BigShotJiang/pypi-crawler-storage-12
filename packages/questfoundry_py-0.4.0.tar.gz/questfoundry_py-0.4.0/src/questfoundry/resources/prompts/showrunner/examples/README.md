# Showrunner Examples

- `hook_harvest_coordination.json` - Orchestrating Hook Harvest loop
- `gatecheck_orchestration.json` - Coordinating gatecheck validation
- `checkpoint_approval.json` - TU checkpoint approval workflow
- `project_init.json` - Project initialization with project_metadata creation
