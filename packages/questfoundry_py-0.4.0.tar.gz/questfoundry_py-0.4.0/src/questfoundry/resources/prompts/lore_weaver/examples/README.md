# Lore Weaver Examples

- hook_to_canon.json
- continuity_check.json
- stakes_analysis.json
