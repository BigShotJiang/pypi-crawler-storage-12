# Style Lead Examples

- `style_audit.json` - Style consistency audit workflow
- `register_guidance.json` - Providing register/voice guidance
- `style_manifest_delivery.json` - Typography stabilization with style_manifest delivery
