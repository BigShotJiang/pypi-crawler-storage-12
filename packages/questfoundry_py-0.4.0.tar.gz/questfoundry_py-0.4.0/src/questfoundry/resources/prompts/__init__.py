"""
Bundled prompt templates.

This package contains prompt templates for QuestFoundry roles, organized by
role type. Prompts are loaded via the utils.get_prompt() function.
"""
