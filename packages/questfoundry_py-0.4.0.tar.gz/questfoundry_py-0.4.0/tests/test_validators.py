
def test_validate_instance():
    """Test validation (placeholder until schemas are bundled)"""
    # instance = {"type": "hook_card", "data": {}}
    # Will need actual schema for full test
    # is_valid = validate_instance(instance, "hook_card")
    # assert is_valid
    pass
