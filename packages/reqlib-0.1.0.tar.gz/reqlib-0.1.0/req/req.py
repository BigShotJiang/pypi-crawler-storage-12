# req.py
import http.client
import json as jsonlib
from urllib.parse import urlencode, urlparse
from html.parser import HTMLParser

class _FormParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.values = {}

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "input":
            name = attrs.get("name")
            value = attrs.get("value", "")
            if name:
                self.values[name] = value
        elif tag == "textarea":
            name = attrs.get("name")
            value = attrs.get("value", "")
            if name:
                self.values[name] = value
        elif tag == "select":
            name = attrs.get("name")
            if name:
                # نحفظ أول خيار افتراضي إذا موجود
                self.values[name] = attrs.get("value", "")
class Response:
    def __init__(self, res, url):
        self.status = res.status
        self.headers = dict(res.getheaders())
        self._body = res.read()
        self.url = url
        self.cookies = {}

        if "Set-Cookie" in self.headers:
            raw_cookie = self.headers["Set-Cookie"]
            for part in raw_cookie.split(";"):
                if "=" in part:
                    k, v = part.strip().split("=", 1)
                    self.cookies[k] = v
    @property
    def html(self):
        """إرجاع dict فيه names و values من عناصر HTML"""
        parser = _FormParser()
        parser.feed(self.text)
        return parser.values
    @property
    def text(self):
        return self._body.decode("utf-8", errors="ignore")

    def json(self):
        try:
            return jsonlib.loads(self.text)
        except jsonlib.JSONDecodeError:
            raise ValueError("Response body is not valid JSON")

    @property
    def content(self):
        return self._body

    @property
    def ok(self):
        return 200 <= self.status < 300


def _request(method, url, headers=None, cookies=None, data=None, json=None, params=None, timeout=10, proxies=None):
    if headers is not None and not isinstance(headers, dict):
        raise TypeError("Headers must be a dict")
    if cookies is not None and not isinstance(cookies, dict):
        raise TypeError("Cookies must be a dict")
    if proxies is not None and not isinstance(proxies, dict):
        raise TypeError("Proxies must be a dict")

    headers = headers or {}

    # إضافة الكوكيز
    if cookies:
        cookie = "; ".join([f"{k}={v}" for k, v in cookies.items()])
        headers["Cookie"] = cookie

    # إضافة params
    if params:
        query = urlencode(params)
        if "?" in url:
            url += "&" + query
        else:
            url += "?" + query

    # تجهيز البيانات
    body = None
    if json is not None:
        body = jsonlib.dumps(json)
        headers["Content-Type"] = "application/json"
    elif data is not None:
        if isinstance(data, dict):
            body = urlencode(data)
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        else:
            body = data

    if isinstance(body, str):
        body = body.encode("utf-8")

    # تحليل الرابط
    parsed = urlparse(url)
    scheme = parsed.scheme
    host = parsed.netloc
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query

    # بروكسي
    if proxies and scheme in proxies:
        proxy_url = urlparse(proxies[scheme])
        proxy_host = proxy_url.hostname
        proxy_port = proxy_url.port
        if scheme == "https":
            conn = http.client.HTTPSConnection(proxy_host, proxy_port, timeout=timeout)
            conn.set_tunnel(host)
        else:
            conn = http.client.HTTPConnection(proxy_host, proxy_port, timeout=timeout)
            conn.set_tunnel(host)
    else:
        if scheme == "https":
            conn = http.client.HTTPSConnection(host, timeout=timeout)
        elif scheme == "http":
            conn = http.client.HTTPConnection(host, timeout=timeout)
        elif scheme == "wss":
            raise ValueError("WebSocket (wss://) is not supported")
        else:
            raise ValueError("Unsupported URL scheme")

    conn.request(method, path, body=body, headers=headers)
    res = conn.getresponse()
    return Response(res, url)


# دوال عامة مثل requests
def get(url, headers=None, cookies=None, params=None, timeout=10, proxies=None):
    return _request("GET", url, headers=headers, cookies=cookies, params=params, timeout=timeout, proxies=proxies)

def post(url, headers=None, cookies=None, data=None, json=None, params=None, timeout=10, proxies=None):
    return _request("POST", url, headers=headers, cookies=cookies, data=data, json=json, params=params, timeout=timeout, proxies=proxies)

def put(url, headers=None, cookies=None, data=None, json=None, params=None, timeout=10, proxies=None):
    return _request("PUT", url, headers=headers, cookies=cookies, data=data, json=json, params=params, timeout=timeout, proxies=proxies)

def delete(url, headers=None, cookies=None, data=None, params=None, timeout=10, proxies=None):
    return _request("DELETE", url, headers=headers, cookies=cookies, data=data, params=params, timeout=timeout, proxies=proxies)
