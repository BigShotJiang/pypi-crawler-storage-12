"""Tests for Claude Code integration with ReAlign config."""

import os
from pathlib import Path
import pytest
import yaml
from src.realign.config import ReAlignConfig


def test_config_default_auto_detect_claude():
    """Test that auto_detect_claude defaults to True."""
    config = ReAlignConfig()
    assert config.auto_detect_claude is True


def test_config_load_with_auto_detect_claude(temp_dir):
    """Test loading config with auto_detect_claude setting."""
    # Create config file
    config_path = temp_dir / "config.yaml"
    config_data = {
        "local_history_path": "~/.local/share/realign/histories",
        "auto_detect_claude": False,
    }
    with open(config_path, "w") as f:
        yaml.dump(config_data, f)

    config = ReAlignConfig.load(config_path)
    assert config.auto_detect_claude is False


def test_config_env_var_override_auto_detect_claude(temp_dir, monkeypatch):
    """Test that REALIGN_AUTO_DETECT_CLAUDE env var overrides config."""
    # Create config file with auto_detect_claude=True
    config_path = temp_dir / "config.yaml"
    config_data = {"auto_detect_claude": True}
    with open(config_path, "w") as f:
        yaml.dump(config_data, f)

    # Override with env var
    monkeypatch.setenv("REALIGN_AUTO_DETECT_CLAUDE", "false")

    config = ReAlignConfig.load(config_path)
    assert config.auto_detect_claude is False


def test_config_save_includes_auto_detect_claude(temp_dir):
    """Test that saving config includes auto_detect_claude."""
    config = ReAlignConfig(auto_detect_claude=False)
    config_path = temp_dir / "config.yaml"

    config.save(config_path)

    # Read back and verify
    with open(config_path, "r") as f:
        saved_data = yaml.safe_load(f)

    assert "auto_detect_claude" in saved_data
    assert saved_data["auto_detect_claude"] is False


def test_get_effective_history_path_without_claude(temp_dir, monkeypatch):
    """Test get_effective_history_path when Claude directory doesn't exist."""
    monkeypatch.setenv("HOME", str(temp_dir))

    config = ReAlignConfig(local_history_path="~/.local/share/realign/histories")
    project_path = temp_dir / "Projects" / "TestApp"
    project_path.mkdir(parents=True)

    result = config.get_effective_history_path(project_path)
    expected = temp_dir / ".local" / "share" / "realign" / "histories"
    assert result == expected


def test_get_effective_history_path_with_claude(temp_dir, monkeypatch):
    """Test get_effective_history_path finds Claude directory."""
    monkeypatch.setenv("HOME", str(temp_dir))

    # Create project
    project_path = temp_dir / "Projects" / "TestApp"
    project_path.mkdir(parents=True)

    # Create Claude sessions directory
    from src.realign.claude_detector import get_claude_project_name

    claude_base = temp_dir / ".claude" / "projects"
    project_name = get_claude_project_name(project_path)
    claude_project_dir = claude_base / project_name
    claude_project_dir.mkdir(parents=True)

    config = ReAlignConfig(auto_detect_claude=True)
    result = config.get_effective_history_path(project_path)
    assert result == claude_project_dir


def test_get_effective_history_path_auto_detect_disabled(temp_dir, monkeypatch):
    """Test get_effective_history_path when auto-detection is disabled."""
    monkeypatch.setenv("HOME", str(temp_dir))

    # Create project
    project_path = temp_dir / "Projects" / "TestApp"
    project_path.mkdir(parents=True)

    # Create Claude sessions directory (should be ignored)
    from src.realign.claude_detector import get_claude_project_name

    claude_base = temp_dir / ".claude" / "projects"
    project_name = get_claude_project_name(project_path)
    claude_project_dir = claude_base / project_name
    claude_project_dir.mkdir(parents=True)

    # Disable auto-detection
    config = ReAlignConfig(
        auto_detect_claude=False, local_history_path="~/.local/share/realign/histories"
    )
    result = config.get_effective_history_path(project_path)

    # Should use configured path, not Claude directory
    expected = temp_dir / ".local" / "share" / "realign" / "histories"
    assert result == expected
    assert result != claude_project_dir


def test_get_effective_history_path_without_project_path(temp_dir):
    """Test get_effective_history_path without project_path falls back."""
    config = ReAlignConfig(local_history_path="~/.local/share/realign/histories")

    # Without project_path, should return configured path
    result = config.get_effective_history_path(None)
    assert result == config.expanded_local_history_path


def test_default_config_content_includes_auto_detect_claude():
    """Test that default config content includes auto_detect_claude."""
    from src.realign.config import get_default_config_content

    content = get_default_config_content()
    assert "auto_detect_claude" in content
    assert "true" in content.lower()  # Default should be true
