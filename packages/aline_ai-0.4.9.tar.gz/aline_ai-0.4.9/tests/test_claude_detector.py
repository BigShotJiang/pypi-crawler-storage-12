"""Tests for Claude Code session directory detection."""

import os
from pathlib import Path
import pytest
from src.realign.claude_detector import (
    get_claude_project_name,
    find_claude_sessions_dir,
    auto_detect_sessions_path,
)


def test_get_claude_project_name_basic():
    """Test Claude project name conversion for basic paths."""
    # Test basic path conversion
    project_path = Path("/Users/alice/Projects/MyApp")
    expected = "-Users-alice-Projects-MyApp"
    assert get_claude_project_name(project_path) == expected


def test_get_claude_project_name_nested(temp_dir):
    """Test Claude project name conversion for deeply nested paths."""
    # Use temp_dir to avoid symlink resolution issues on macOS
    project_path = temp_dir / "user" / "dev" / "work" / "team" / "project"
    result = get_claude_project_name(project_path)
    # Should start with - and have path components separated by -
    assert result.startswith("-")
    assert "user-dev-work-team-project" in result


def test_get_claude_project_name_single_level():
    """Test Claude project name conversion for single-level paths."""
    project_path = Path("/projects")
    expected = "-projects"
    assert get_claude_project_name(project_path) == expected


def test_get_claude_project_name_with_spaces():
    """Test Claude project name conversion for paths with spaces."""
    project_path = Path("/Users/alice/My Projects/Test App")
    expected = "-Users-alice-My Projects-Test App"
    assert get_claude_project_name(project_path) == expected


def test_find_claude_sessions_dir_exists(temp_dir, monkeypatch):
    """Test finding Claude sessions directory when it exists."""
    # Mock the home directory
    monkeypatch.setenv("HOME", str(temp_dir))

    # Create project directory
    project_path = temp_dir / "Projects" / "TestApp"
    project_path.mkdir(parents=True)

    # Create Claude sessions directory
    claude_base = temp_dir / ".claude" / "projects"
    project_name = get_claude_project_name(project_path)
    claude_project_dir = claude_base / project_name
    claude_project_dir.mkdir(parents=True)

    # Test finding the directory
    result = find_claude_sessions_dir(project_path)
    assert result == claude_project_dir
    assert result.exists()


def test_find_claude_sessions_dir_not_exists(temp_dir, monkeypatch):
    """Test finding Claude sessions directory when it doesn't exist."""
    monkeypatch.setenv("HOME", str(temp_dir))

    project_path = temp_dir / "Projects" / "NonExistent"
    project_path.mkdir(parents=True)

    # Don't create Claude directory
    result = find_claude_sessions_dir(project_path)
    assert result is None


def test_find_claude_sessions_dir_no_claude_base(temp_dir, monkeypatch):
    """Test finding Claude sessions directory when ~/.claude doesn't exist."""
    monkeypatch.setenv("HOME", str(temp_dir))

    project_path = temp_dir / "Projects" / "TestApp"
    project_path.mkdir(parents=True)

    # Don't create ~/.claude directory
    result = find_claude_sessions_dir(project_path)
    assert result is None


def test_auto_detect_sessions_path_with_env_var(temp_dir, monkeypatch):
    """Test auto-detection prioritizes REALIGN_LOCAL_HISTORY_PATH env var."""
    monkeypatch.setenv("HOME", str(temp_dir))
    custom_path = "/custom/history/path"
    monkeypatch.setenv("REALIGN_LOCAL_HISTORY_PATH", custom_path)

    project_path = temp_dir / "Projects" / "TestApp"
    project_path.mkdir(parents=True)

    # Create Claude directory (should be ignored)
    claude_base = temp_dir / ".claude" / "projects"
    project_name = get_claude_project_name(project_path)
    claude_project_dir = claude_base / project_name
    claude_project_dir.mkdir(parents=True)

    result = auto_detect_sessions_path(project_path)
    assert result == Path(custom_path)


def test_auto_detect_sessions_path_with_claude(temp_dir, monkeypatch):
    """Test auto-detection finds Claude directory when no env var set."""
    monkeypatch.setenv("HOME", str(temp_dir))
    # Make sure env var is not set
    monkeypatch.delenv("REALIGN_LOCAL_HISTORY_PATH", raising=False)

    project_path = temp_dir / "Projects" / "TestApp"
    project_path.mkdir(parents=True)

    # Create Claude directory
    claude_base = temp_dir / ".claude" / "projects"
    project_name = get_claude_project_name(project_path)
    claude_project_dir = claude_base / project_name
    claude_project_dir.mkdir(parents=True)

    result = auto_detect_sessions_path(project_path)
    assert result == claude_project_dir


def test_auto_detect_sessions_path_with_fallback(temp_dir, monkeypatch):
    """Test auto-detection uses fallback when Claude not found."""
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.delenv("REALIGN_LOCAL_HISTORY_PATH", raising=False)

    project_path = temp_dir / "Projects" / "TestApp"
    project_path.mkdir(parents=True)

    # Don't create Claude directory
    fallback = "~/.local/share/realign/histories"

    result = auto_detect_sessions_path(project_path, fallback)
    expected = Path(temp_dir) / ".local" / "share" / "realign" / "histories"
    assert result == expected


def test_auto_detect_sessions_path_default_fallback(temp_dir, monkeypatch):
    """Test auto-detection uses default fallback when nothing else available."""
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.delenv("REALIGN_LOCAL_HISTORY_PATH", raising=False)

    project_path = temp_dir / "Projects" / "TestApp"
    project_path.mkdir(parents=True)

    result = auto_detect_sessions_path(project_path)
    expected = Path(temp_dir) / ".local" / "share" / "realign" / "histories"
    assert result == expected


def test_auto_detect_sessions_path_no_project_path(temp_dir, monkeypatch):
    """Test auto-detection without project path falls back to default."""
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.delenv("REALIGN_LOCAL_HISTORY_PATH", raising=False)

    fallback = "~/.custom/fallback"
    result = auto_detect_sessions_path(None, fallback)
    expected = Path(temp_dir) / ".custom" / "fallback"
    assert result == expected
