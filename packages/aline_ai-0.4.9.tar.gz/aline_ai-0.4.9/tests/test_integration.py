"""Integration tests for complete ReAlign workflow."""

import subprocess
import re
from pathlib import Path
import pytest


def test_full_workflow(git_repo, sample_session, monkeypatch, temp_dir):
    """Test complete workflow: init -> commit -> search -> show."""
    # Setup
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.setenv("REALIGN_LOCAL_HISTORY_PATH", str(sample_session.parent))
    monkeypatch.chdir(git_repo)

    from typer.testing import CliRunner
    from src.realign.cli import app

    runner = CliRunner()

    # Step 1: Initialize ReAlign
    result = runner.invoke(app, ["init", "--yes", "--skip-commit"])
    assert result.exit_code == 0

    # Verify structure created
    assert (git_repo / ".realign" / "hooks" / "prepare-commit-msg").exists()

    # Step 2: Make a commit (this should trigger the hook)
    test_file = git_repo / "test.py"
    test_file.write_text("def hello():\n    print('Hello, world!')\n")

    subprocess.run(["git", "add", "test.py"], cwd=git_repo, check=True, capture_output=True)

    # Commit (hook should run)
    result = subprocess.run(
        ["git", "commit", "-m", "Add hello function"],
        cwd=git_repo,
        capture_output=True,
        text=True,
    )

    # Step 3: Verify commit message includes agent summary
    log_result = subprocess.run(
        ["git", "log", "-1", "--pretty=%B"],
        cwd=git_repo,
        capture_output=True,
        text=True,
        check=True,
    )

    commit_msg = log_result.stdout
    assert "Agent-Summary:" in commit_msg or "Add hello function" in commit_msg
    # Note: If hook didn't run, we still have the commit message

    # Step 4: Verify session file was copied (if hook ran successfully)
    sessions_dir = git_repo / ".realign" / "sessions"
    if sessions_dir.exists():
        session_files = list(sessions_dir.glob("*.jsonl"))
        # May or may not have session depending on hook execution


def test_commit_with_session(git_repo, sample_session, monkeypatch, temp_dir):
    """Test that commits properly integrate session data."""
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.setenv("REALIGN_LOCAL_HISTORY_PATH", str(sample_session.parent))
    monkeypatch.chdir(git_repo)

    # Initialize
    from typer.testing import CliRunner
    from src.realign.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["init", "--yes"])

    # Test hooks module integration
    from realign import hooks

    # Run process_sessions
    result = hooks.process_sessions(pre_commit_mode=False)

    # Verify session was copied
    sessions_dir = git_repo / ".realign" / "sessions"
    assert sessions_dir.exists()

    session_files = list(sessions_dir.glob("*.jsonl"))
    assert len(session_files) > 0

    # Verify content
    assert result["summary"] != ""
    assert len(result["session_relpaths"]) > 0


def test_search_and_show_integration(git_repo, sample_session, monkeypatch, temp_dir):
    """Test search and show commands work together."""
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.chdir(git_repo)

    from typer.testing import CliRunner
    from src.realign.cli import app

    runner = CliRunner()

    # Create a commit with agent data manually
    test_file = git_repo / "code.py"
    test_file.write_text("# Binary search implementation\n")

    subprocess.run(["git", "add", "code.py"], cwd=git_repo, check=True, capture_output=True)

    # Create commit with agent footer
    commit_msg = """Add binary search

Agent-Summary: Discussion about implementing binary search in Python with comments
Agent-Session-Path: .realign/sessions/test_session.jsonl
Agent-Redacted: false
"""

    subprocess.run(
        ["git", "commit", "-m", commit_msg],
        cwd=git_repo,
        capture_output=True,
        text=True,
        check=True,
    )

    # Copy session file
    sessions_dir = git_repo / ".realign" / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    session_dest = sessions_dir / "test_session.jsonl"
    import shutil
    shutil.copy2(sample_session, session_dest)

    # Add and commit the session
    subprocess.run(["git", "add", ".realign/"], cwd=git_repo, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "Add session", "--no-verify"],
        cwd=git_repo,
        capture_output=True,
        check=True,
    )

    # Test search
    result = runner.invoke(app, ["search", "binary"])
    assert "binary" in result.output.lower() or "search" in result.output.lower()

    # Test show
    # Get the commit hash
    log_result = subprocess.run(
        ["git", "log", "--format=%H", "-n", "1", "--grep=binary"],
        cwd=git_repo,
        capture_output=True,
        text=True,
    )
    if log_result.stdout.strip():
        commit_hash = log_result.stdout.strip()[:8]
        result = runner.invoke(app, ["show", commit_hash])
        # Show might work or not depending on session availability


def test_hook_doesnt_block_commit_on_failure(git_repo, monkeypatch, temp_dir):
    """Test that hook doesn't block commits when it fails."""
    monkeypatch.setenv("HOME", str(temp_dir))
    # Set invalid history path
    monkeypatch.setenv("REALIGN_LOCAL_HISTORY_PATH", "/nonexistent/path")
    monkeypatch.chdir(git_repo)

    from typer.testing import CliRunner
    from src.realign.cli import app

    runner = CliRunner()

    # Initialize
    result = runner.invoke(app, ["init", "--yes"])

    # Make a commit (should succeed even with no session)
    test_file = git_repo / "test.txt"
    test_file.write_text("test content\n")

    subprocess.run(["git", "add", "test.txt"], cwd=git_repo, check=True, capture_output=True)

    result = subprocess.run(
        ["git", "commit", "-m", "Test commit"],
        cwd=git_repo,
        capture_output=True,
        text=True,
    )

    # Should succeed (hook doesn't block)
    assert result.returncode == 0
