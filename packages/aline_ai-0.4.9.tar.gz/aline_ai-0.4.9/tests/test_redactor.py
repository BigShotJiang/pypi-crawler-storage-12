"""Tests for the redactor module."""

import pytest
from pathlib import Path
from realign.redactor import (
    detect_secrets,
    redact_content,
    check_and_redact_session,
    SecretMatch,
)


# Sample content with secrets
SAMPLE_SESSION_WITH_SECRETS = """{"role": "user", "content": "How do I use this API key?"}
{"role": "assistant", "content": "You can use the API key like this: api_key = 'sk-1234567890abcdefghijklmnopqrstuvwxyz'"}
{"role": "user", "content": "What about AWS credentials?"}
{"role": "assistant", "content": "Here's an example: AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"}
"""

SAMPLE_SESSION_NO_SECRETS = """{"role": "user", "content": "Hello, how are you?"}
{"role": "assistant", "content": "I'm doing well, thank you!"}
"""


def test_detect_secrets_with_secrets():
    """Test that secrets are detected in content."""
    secrets, available = detect_secrets(SAMPLE_SESSION_WITH_SECRETS)

    if not available:
        pytest.skip("detect-secrets not installed")

    # Should detect at least one secret
    assert len(secrets) > 0
    assert all(isinstance(s, SecretMatch) for s in secrets)


def test_detect_secrets_no_secrets():
    """Test that no secrets are detected in clean content."""
    secrets, available = detect_secrets(SAMPLE_SESSION_NO_SECRETS)

    if not available:
        pytest.skip("detect-secrets not installed")

    # Should not detect any secrets
    assert len(secrets) == 0


def test_detect_secrets_empty_content():
    """Test handling of empty content."""
    secrets, available = detect_secrets("")

    if not available:
        pytest.skip("detect-secrets not installed")

    assert len(secrets) == 0


def test_redact_content_with_secrets():
    """Test that content is redacted when secrets are present."""
    secrets = [
        SecretMatch("Base64 High Entropy String", 2, "hash1"),
        SecretMatch("Secret Keyword", 4, "hash2"),
    ]

    content = """Line 1
Line 2 with secret
Line 3
Line 4 with another secret
Line 5"""

    redacted = redact_content(content, secrets)

    # Check that redaction markers are present
    assert "[REDACTED" in redacted
    # Original content should be modified
    assert redacted != content


def test_redact_content_no_secrets():
    """Test that content is unchanged when no secrets are present."""
    content = "Hello world\nThis is a test\n"
    redacted = redact_content(content, [])

    assert redacted == content


def test_check_and_redact_session_off_mode():
    """Test that redaction is skipped when mode is 'off'."""
    content, has_secrets, secrets = check_and_redact_session(
        SAMPLE_SESSION_WITH_SECRETS,
        redact_mode="off"
    )

    assert content == SAMPLE_SESSION_WITH_SECRETS
    assert has_secrets is False
    assert len(secrets) == 0


def test_check_and_redact_session_detect_mode():
    """Test that secrets are detected but not redacted in 'detect' mode."""
    content, has_secrets, secrets = check_and_redact_session(
        SAMPLE_SESSION_WITH_SECRETS,
        redact_mode="detect"
    )

    try:
        import detect_secrets
        # If detect_secrets is available, check results
        assert content == SAMPLE_SESSION_WITH_SECRETS  # Not redacted
        # has_secrets depends on whether detect-secrets found anything
    except ImportError:
        # If detect_secrets not available, should return original
        assert content == SAMPLE_SESSION_WITH_SECRETS
        assert has_secrets is False


def test_check_and_redact_session_auto_mode():
    """Test that secrets are detected and redacted in 'auto' mode."""
    content, has_secrets, secrets = check_and_redact_session(
        SAMPLE_SESSION_WITH_SECRETS,
        redact_mode="auto"
    )

    try:
        import detect_secrets
        # If detect_secrets is available and found secrets, content should be different
        if has_secrets:
            assert content != SAMPLE_SESSION_WITH_SECRETS
            assert "[REDACTED" in content or len(secrets) > 0
    except ImportError:
        # If detect_secrets not available, should return original
        assert content == SAMPLE_SESSION_WITH_SECRETS
        assert has_secrets is False


def test_secret_match_representation():
    """Test SecretMatch string representation."""
    match = SecretMatch("API Key", 42, "abc123")

    assert "API Key" in repr(match)
    assert "42" in repr(match)
    assert match.type == "API Key"
    assert match.line == 42
    assert match.hash == "abc123"


def test_detect_secrets_without_library():
    """Test graceful handling when detect-secrets is not installed."""
    # This test ensures the function doesn't crash
    secrets, available = detect_secrets("some content")

    # Should return empty list and availability status
    assert isinstance(secrets, list)
    assert isinstance(available, bool)
