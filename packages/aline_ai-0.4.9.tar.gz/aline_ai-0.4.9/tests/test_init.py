"""Tests for realign init command."""

import subprocess
from pathlib import Path
import pytest


def test_init_creates_structure(git_repo, monkeypatch, temp_dir):
    """Test that init creates required directory structure."""
    # Set home to temp dir for config
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.chdir(git_repo)

    # Run init (we'll use subprocess since we're testing the installed command)
    # For now, test the directory structure manually
    from src.realign.commands.init import init_command
    from typer.testing import CliRunner
    from src.realign.cli import app

    runner = CliRunner()

    # Change to git repo directory
    result = runner.invoke(app, ["init", "--yes", "--skip-commit"])

    # Check directory structure
    assert (git_repo / ".realign").exists()
    assert (git_repo / ".realign" / "hooks").exists()
    assert (git_repo / ".realign" / "sessions").exists()
    # Note: tools directory is no longer created in new architecture


def test_init_creates_hook(git_repo, monkeypatch, temp_dir):
    """Test that init creates the prepare-commit-msg hook."""
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.chdir(git_repo)

    from typer.testing import CliRunner
    from src.realign.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["init", "--yes"])

    hook_path = git_repo / ".realign" / "hooks" / "prepare-commit-msg"
    assert hook_path.exists()
    assert hook_path.stat().st_mode & 0o111  # Check executable bit


def test_init_sets_git_config(git_repo, monkeypatch, temp_dir):
    """Test that init sets core.hooksPath."""
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.chdir(git_repo)

    from typer.testing import CliRunner
    from src.realign.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["init", "--yes"])

    # Check git config
    config_result = subprocess.run(
        ["git", "config", "--local", "core.hooksPath"],
        cwd=git_repo,
        capture_output=True,
        text=True,
        check=True,
    )
    assert config_result.stdout.strip() == ".realign/hooks"


def test_init_creates_global_config(git_repo, monkeypatch, temp_dir):
    """Test that init creates global config if not exists."""
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.chdir(git_repo)

    from typer.testing import CliRunner
    from src.realign.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["init", "--yes"])

    config_path = temp_dir / ".config" / "realign" / "config.yaml"
    assert config_path.exists()

    content = config_path.read_text()
    assert "local_history_path" in content
    assert "summary_max_chars" in content


def test_init_backs_up_existing_hooks_path(git_repo, monkeypatch, temp_dir):
    """Test that init backs up existing core.hooksPath."""
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.chdir(git_repo)

    # Set an existing hooks path
    subprocess.run(
        ["git", "config", "--local", "core.hooksPath", "/old/hooks"],
        cwd=git_repo,
        check=True,
    )

    from typer.testing import CliRunner
    from src.realign.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["init", "--yes"])

    # Check backup file
    backup_file = git_repo / ".realign" / "backup_hook_config.yaml"
    assert backup_file.exists()

    import yaml
    with open(backup_file) as f:
        backup = yaml.safe_load(f)
    assert backup["original_hooks_path"] == "/old/hooks"


def test_init_not_in_git_repo_user_declines(temp_dir, monkeypatch):
    """Test that init auto-initializes git repo (no longer prompts user)."""
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.chdir(temp_dir)

    from typer.testing import CliRunner
    from src.realign.cli import app

    runner = CliRunner()
    # Init now auto-initializes git repo without prompting
    result = runner.invoke(app, ["init"])

    # Should succeed and auto-initialize git
    assert result.exit_code == 0
    assert "SUCCESS" in result.output
    assert "Git Initialized: True" in result.output


def test_init_auto_initializes_git_repo(temp_dir, monkeypatch):
    """Test that init automatically initializes git repo without prompting."""
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.chdir(temp_dir)

    from typer.testing import CliRunner
    from src.realign.cli import app

    runner = CliRunner()
    # Init now auto-initializes git repo without prompting
    result = runner.invoke(app, ["init"])

    # Should succeed and create git repo
    assert result.exit_code == 0
    assert (temp_dir / ".git").exists()
    assert "Git Initialized: True" in result.output
    assert (temp_dir / ".realign").exists()


def test_init_auto_initializes_git_repo_with_yes_flag(temp_dir, monkeypatch):
    """Test that init auto-initializes git repo with --yes flag."""
    monkeypatch.setenv("HOME", str(temp_dir))
    monkeypatch.chdir(temp_dir)

    from typer.testing import CliRunner
    from src.realign.cli import app

    runner = CliRunner()
    # Use --yes flag to skip all prompts
    result = runner.invoke(app, ["init", "--yes"])

    # Should succeed and create git repo without prompting
    assert result.exit_code == 0
    assert (temp_dir / ".git").exists()
    assert (temp_dir / ".realign").exists()
