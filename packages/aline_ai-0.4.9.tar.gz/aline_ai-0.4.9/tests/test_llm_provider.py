"""Tests for LLM provider selection.

Note: These tests focus on configuration and parameter passing.
Full integration tests with actual API mocking are more complex and
would require mocking the dynamic imports inside generate_summary_with_llm.
"""

import os
import pytest
from src.realign.config import ReAlignConfig
from src.realign.hooks import generate_summary_with_llm


@pytest.fixture
def sample_content():
    """Sample content for testing."""
    return "User asked about implementing authentication. Assistant explained JWT tokens and provided code examples."


def test_llm_provider_parameter_passed_correctly():
    """Test that provider parameter is properly accepted."""
    # Make sure no API keys are set for this test
    old_anthropic = os.environ.get("ANTHROPIC_API_KEY")
    old_openai = os.environ.get("OPENAI_API_KEY")

    try:
        if old_anthropic:
            del os.environ["ANTHROPIC_API_KEY"]
        if old_openai:
            del os.environ["OPENAI_API_KEY"]

        # Test with different provider values
        # These will return None because no API keys are set, but we can verify the parameter is accepted
        result = generate_summary_with_llm("test", provider="auto")
        assert result is None  # No API keys, so returns None

        result = generate_summary_with_llm("test", provider="claude")
        assert result is None  # No API keys, so returns None

        result = generate_summary_with_llm("test", provider="openai")
        assert result is None  # No API keys, so returns None
    finally:
        # Restore original values
        if old_anthropic:
            os.environ["ANTHROPIC_API_KEY"] = old_anthropic
        if old_openai:
            os.environ["OPENAI_API_KEY"] = old_openai


def test_generate_summary_no_api_keys(sample_content):
    """Test behavior when no API keys are set for all providers."""
    # Make sure no API keys are set
    old_anthropic = os.environ.get("ANTHROPIC_API_KEY")
    old_openai = os.environ.get("OPENAI_API_KEY")

    try:
        if old_anthropic:
            del os.environ["ANTHROPIC_API_KEY"]
        if old_openai:
            del os.environ["OPENAI_API_KEY"]

        result = generate_summary_with_llm(sample_content, provider="auto")
        assert result is None

        result = generate_summary_with_llm(sample_content, provider="claude")
        assert result is None

        result = generate_summary_with_llm(sample_content, provider="openai")
        assert result is None
    finally:
        # Restore original values
        if old_anthropic:
            os.environ["ANTHROPIC_API_KEY"] = old_anthropic
        if old_openai:
            os.environ["OPENAI_API_KEY"] = old_openai


def test_generate_summary_empty_content():
    """Test with empty content."""
    result = generate_summary_with_llm("", provider="auto")
    assert result == "No new content in this session"

    result = generate_summary_with_llm("   ", provider="auto")
    assert result == "No new content in this session"

    result = generate_summary_with_llm("", provider="claude")
    assert result == "No new content in this session"

    result = generate_summary_with_llm("", provider="openai")
    assert result == "No new content in this session"


def test_generate_summary_default_provider():
    """Test that default provider is 'auto'."""
    # When provider is not specified, it should default to "auto"
    # This test verifies the function signature
    import inspect
    sig = inspect.signature(generate_summary_with_llm)
    assert sig.parameters['provider'].default == "auto"


def test_config_llm_provider_integration(config_file):
    """Test that ReAlignConfig properly stores and loads llm_provider."""
    # Create config with different providers
    for provider in ["auto", "claude", "openai"]:
        config = ReAlignConfig(llm_provider=provider)
        config.save(config_file)

        loaded_config = ReAlignConfig.load(config_file)
        assert loaded_config.llm_provider == provider


def test_config_llm_provider_with_use_llm(config_file):
    """Test llm_provider works together with use_LLM setting."""
    config_content = """use_LLM: true
llm_provider: "claude"
"""
    config_file.write_text(config_content)

    config = ReAlignConfig.load(config_file)
    assert config.use_LLM is True
    assert config.llm_provider == "claude"

    # Test with LLM disabled
    config_content = """use_LLM: false
llm_provider: "openai"
"""
    config_file.write_text(config_content)

    config = ReAlignConfig.load(config_file)
    assert config.use_LLM is False
    assert config.llm_provider == "openai"


def test_generate_summary_respects_max_chars():
    """Test that summary respects max_chars parameter regardless of provider."""
    # The function should return a result that respects max_chars
    # Note: For empty content, it returns "No new content in this session" which is 30 chars
    # So we test with larger max_chars values
    result = generate_summary_with_llm("", max_chars=100, provider="auto")
    assert len(result) <= 100
    assert result == "No new content in this session"

    result = generate_summary_with_llm("", max_chars=50, provider="claude")
    assert len(result) <= 50
    assert result == "No new content in this session"


def test_provider_env_variable_override(config_file, monkeypatch):
    """Test that REALIGN_LLM_PROVIDER environment variable works."""
    config_content = """llm_provider: "auto"
"""
    config_file.write_text(config_content)

    # Override with environment variable
    monkeypatch.setenv("REALIGN_LLM_PROVIDER", "claude")

    config = ReAlignConfig.load(config_file)
    assert config.llm_provider == "claude"

    # Change to openai
    monkeypatch.setenv("REALIGN_LLM_PROVIDER", "openai")
    config = ReAlignConfig.load(config_file)
    assert config.llm_provider == "openai"
