"""Tests for configuration management."""

import os
from pathlib import Path
import pytest
from src.realign.config import ReAlignConfig, get_default_config_content


def test_default_config():
    """Test default configuration values."""
    config = ReAlignConfig()
    assert config.local_history_path == "~/.local/share/realign/histories"
    assert config.summary_max_chars == 500
    assert config.redact_on_match is True  # Now enabled by default
    assert config.hooks_installation == "repo"
    assert config.use_LLM is True
    assert config.llm_provider == "auto"


def test_config_load_from_file(config_file):
    """Test loading configuration from file."""
    config_content = """local_history_path: "/custom/path"
summary_max_chars: 300
redact_on_match: true
use_LLM: false
"""
    config_file.write_text(config_content)

    config = ReAlignConfig.load(config_file)
    assert config.local_history_path == "/custom/path"
    assert config.summary_max_chars == 300
    assert config.redact_on_match is True
    assert config.use_LLM is False


def test_config_env_override(config_file, monkeypatch):
    """Test environment variable overrides."""
    config_content = """local_history_path: "/file/path"
summary_max_chars: 300
"""
    config_file.write_text(config_content)

    # Set environment overrides
    monkeypatch.setenv("REALIGN_LOCAL_HISTORY_PATH", "/env/path")
    monkeypatch.setenv("REALIGN_SUMMARY_MAX_CHARS", "600")
    monkeypatch.setenv("REALIGN_USE_LLM", "false")

    config = ReAlignConfig.load(config_file)
    assert config.local_history_path == "/env/path"
    assert config.summary_max_chars == 600
    assert config.use_LLM is False


def test_config_save(config_file):
    """Test saving configuration to file."""
    config = ReAlignConfig(
        local_history_path="/my/path",
        summary_max_chars=400,
        redact_on_match=True,
    )
    config.save(config_file)

    assert config_file.exists()

    # Load and verify
    loaded_config = ReAlignConfig.load(config_file)
    assert loaded_config.local_history_path == "/my/path"
    assert loaded_config.summary_max_chars == 400
    assert loaded_config.redact_on_match is True


def test_expanded_local_history_path(monkeypatch):
    """Test path expansion."""
    monkeypatch.setenv("HOME", "/home/testuser")
    config = ReAlignConfig(local_history_path="~/my/histories")

    expanded = config.expanded_local_history_path
    assert str(expanded) == "/home/testuser/my/histories"


def test_get_default_config_content():
    """Test default config content generation."""
    content = get_default_config_content()
    assert "local_history_path" in content
    assert "summary_max_chars" in content
    assert "redact_on_match" in content
    assert "use_LLM" in content
    assert "llm_provider" in content


def test_llm_provider_config():
    """Test llm_provider configuration."""
    # Test default value
    config = ReAlignConfig()
    assert config.llm_provider == "auto"

    # Test setting different providers
    config_claude = ReAlignConfig(llm_provider="claude")
    assert config_claude.llm_provider == "claude"

    config_openai = ReAlignConfig(llm_provider="openai")
    assert config_openai.llm_provider == "openai"


def test_llm_provider_from_file(config_file):
    """Test loading llm_provider from config file."""
    config_content = """llm_provider: "claude"
use_LLM: true
"""
    config_file.write_text(config_content)

    config = ReAlignConfig.load(config_file)
    assert config.llm_provider == "claude"
    assert config.use_LLM is True


def test_llm_provider_env_override(config_file, monkeypatch):
    """Test llm_provider environment variable override."""
    config_content = """llm_provider: "auto"
"""
    config_file.write_text(config_content)

    # Set environment override
    monkeypatch.setenv("REALIGN_LLM_PROVIDER", "openai")

    config = ReAlignConfig.load(config_file)
    assert config.llm_provider == "openai"


def test_llm_provider_save(config_file):
    """Test saving llm_provider to config file."""
    config = ReAlignConfig(llm_provider="claude")
    config.save(config_file)

    assert config_file.exists()

    # Load and verify
    loaded_config = ReAlignConfig.load(config_file)
    assert loaded_config.llm_provider == "claude"
