"""Aline - AI Agent Chat Session Tracker."""

__version__ = "0.4.9"
