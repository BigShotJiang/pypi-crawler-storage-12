.. :changelog:

History
-------

0.3 (2020-08-02)
++++++++++++++++

This update just contains a version bump of django-osm-field.

* Known to be working on Django 2.1
* Bumped dependency django-osm-field for 0.4.1
* Wagtail 2.3, 2.4 support (later versions to be tested)

0.2 (2018-09-21)
++++++++++++++++

* Wagtail 2 support

0.1.0 (2015-12-26)
++++++++++++++++++

* First release on PyPI.
