"""Utility modules for django-bulk-hooks."""

