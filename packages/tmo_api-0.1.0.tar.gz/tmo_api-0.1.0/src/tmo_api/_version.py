"""Package version information."""

__all__ = ["__version__"]

# Keep this in sync with pyproject.toml
__version__ = "0.1.0"
