This module extends the Fleet module allowing the registration of
vehicle entry and exit inspections. Add Cost vehicle inspections. Once
is confirmed, service vehicle is created. If inspection is cancelled,
service vehicle is deleted.
