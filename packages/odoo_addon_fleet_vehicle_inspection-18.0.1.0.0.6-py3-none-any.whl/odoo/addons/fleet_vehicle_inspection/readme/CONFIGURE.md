To configure this module, you will need to set up inspection items for
vehicle inspections.

1.  Go to Fleet \> Configuration \> Inspection Items
2.  Create or edit inspection items
