from . import (
    animal_species,
    animal_breed,
    animal_color,
    animal,
)
