from ._integer import Integer
from ._odd_integer import OddInteger
