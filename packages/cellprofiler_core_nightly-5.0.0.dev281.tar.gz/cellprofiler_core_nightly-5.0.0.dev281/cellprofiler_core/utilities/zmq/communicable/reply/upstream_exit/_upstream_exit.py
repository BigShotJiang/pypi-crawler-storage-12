from cellprofiler_core.utilities.zmq.communicable.reply._reply import Reply


class UpstreamExit(Reply):
    pass
