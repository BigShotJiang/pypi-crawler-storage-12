The configuration of the rules is done in "Inventory \> Configuration \>
Stock Reservation Rules".

Creation of a rule:

Properties that define where the rule will be applied:

- Location: Define where the rule will look for goods (a parent of the
  move's source location).
- Rule Domain: The rule is used only if the Stock Move matches the
  domain.

Removal rules for the locations:

- Quants Domain: this domain includes/excludes quants based on a domain.
- Advanced Removal Strategy: the strategy that will be used for this
  location and sub-location when the rule is used.

The sequences have to be sorted in the view list to define the
reservation priorities.
