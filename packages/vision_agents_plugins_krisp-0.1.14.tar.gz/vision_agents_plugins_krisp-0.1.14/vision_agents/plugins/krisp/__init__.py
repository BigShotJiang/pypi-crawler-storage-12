"""Krisp turn detection plugin for Vision Agents."""

from .turn_detection import TurnDetection

__all__ = ["TurnDetection"]

