"""阶段7将实现执行器与步骤循环集成；当前为占位模块。"""

from __future__ import annotations

from typing import List


def plan_from_description(user_context: dict, description: str) -> List[str]:
    """占位：后续由模型生成执行计划。"""
    return []