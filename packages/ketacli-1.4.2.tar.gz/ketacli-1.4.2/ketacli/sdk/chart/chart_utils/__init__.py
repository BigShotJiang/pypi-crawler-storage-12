"""Base components for chart module"""

from .spl_textarea import SPLTextArea

__all__ = ['SPLTextArea']