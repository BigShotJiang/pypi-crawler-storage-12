# Predicates

---

::: maypy.predicates
    options:
        show_docstring_classes: false
        show_category_heading: false
        filters:
            - "!^_"
