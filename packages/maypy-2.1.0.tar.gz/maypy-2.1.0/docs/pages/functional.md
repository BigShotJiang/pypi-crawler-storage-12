# Functionals 

--- 

::: maypy._functional
