# Welcome to MayPy
<figure markdown>
  ![Logo](./assets/img/logo.png){ width="300" }

  _Pythonic Java Optional API_
</figure>
<div markdown="1" align="center">
    
--8<-- "README.md:overview-header"
</div>

---

Source Code: [https://github.com/MLetrone/maypy](https://github.com/MLetrone/maypy)

documentation: [https://mletrone.github.io/maypy/](https://mletrone.github.io/maypy/)

---
--8<-- "README.md:overview-body"


## Description 
--8<-- "README.md:description"
