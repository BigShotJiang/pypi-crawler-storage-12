import maypy


def test_package() -> None:
    assert maypy.__version__
