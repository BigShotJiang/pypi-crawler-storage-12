from __future__ import annotations

# filestate: python-constant-sort
REGISTRY_KERNEL_COMMAND_RESOLVER: str = "command_resolvers"
REGISTRY_KERNEL_COMMAND_RUNNERS: str = "command_runners"
