from pathlib import Path


ARTEFACTS_DEFAULT_OUTPUT_DIR = Path("artefacts")
