class TaskUniqueException(Exception):
    """Задача уже в очереди или выполняется."""
