"""
This is the local MCP tool implementation.
Works well for minor deployment, but relatively slow & some performance consume & might hit captchas.
"""
requires = []
from maica.mtools.mcp import asearch