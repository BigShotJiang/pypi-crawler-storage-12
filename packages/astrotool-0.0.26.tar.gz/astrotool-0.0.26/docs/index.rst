.. astrotool documentation master file, created by
   sphinx-quickstart on Sun Mar 21 11:01:08 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to astrotool's documentation!
=====================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:
   
   astrotool



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
