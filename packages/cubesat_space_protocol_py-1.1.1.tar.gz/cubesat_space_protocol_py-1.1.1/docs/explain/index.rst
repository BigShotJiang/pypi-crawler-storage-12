Explain
=======

.. toctree:: 
    :maxdepth: 1

    why_python
    libcsp_compare
    filters
    interfaces
    router_task
