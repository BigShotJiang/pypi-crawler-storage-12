Comparison to LibCSP
====================

TODO