Why Python implementation?
==========================

TODO