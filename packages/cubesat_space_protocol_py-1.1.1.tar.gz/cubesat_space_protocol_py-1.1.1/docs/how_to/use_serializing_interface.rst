Use serializing interface
=========================

TODO