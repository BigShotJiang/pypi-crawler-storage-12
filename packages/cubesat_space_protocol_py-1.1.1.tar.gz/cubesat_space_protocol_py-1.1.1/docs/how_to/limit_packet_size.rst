Limit packet size using filters
===============================

TODO