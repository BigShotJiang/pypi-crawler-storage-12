---
title: Changelog
weight: 3
---

---

## Version 2.0.0

First release of CoMLRL.
