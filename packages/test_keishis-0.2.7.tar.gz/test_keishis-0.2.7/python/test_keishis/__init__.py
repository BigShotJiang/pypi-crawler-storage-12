from ._test_keishis import sum_as_string


def mysum(a: int, b: int) -> int:
    return a + b


__all__ = ["mysum", "sum_as_string"]
