"""
Computer control tools for AI agents.

This package contains modular tool implementations organized by functionality.
"""
