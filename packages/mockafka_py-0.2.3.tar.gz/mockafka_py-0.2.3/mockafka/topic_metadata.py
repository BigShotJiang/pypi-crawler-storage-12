from __future__ import annotations

from collections.abc import Collection

from mockafka.partition_metadata import PartitionMetadata


class TopicMetadata(object):
    """
    Provides information about a Kafka topic.

    This class is typically not user instantiated.
    """

    # The dash in "-topic" and "-error" is needed to circumvent a
    # Sphinx issue where it tries to reference the same instance variable
    # on other classes which raises a warning/error.

    def __init__(self, topic_name: str, partition_num: Collection[int] = ()) -> None:
        self.topic = topic_name
        """Topic name"""
        self.partitions = {num: PartitionMetadata(id=num) for num in partition_num}
        """Map of partitions indexed by partition id. Value is a PartitionMetadata object."""
        self.error = None
        """Topic error, or None. Value is a KafkaError object."""

    def __str__(self) -> str:
        return self.topic

    def __len__(self) -> int:
        return len(self.partitions)
