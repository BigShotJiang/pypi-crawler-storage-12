# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import config
from . import intrastat_statement_section
from . import intrastat_statement
from . import intrastat_statement_purchase_section
from . import intrastat_statement_purchase_section1
from . import intrastat_statement_purchase_section2
from . import intrastat_statement_purchase_section3
from . import intrastat_statement_purchase_section4
from . import intrastat_statement_sale_section
from . import intrastat_statement_sale_section1
from . import intrastat_statement_sale_section2
from . import intrastat_statement_sale_section3
from . import intrastat_statement_sale_section4
