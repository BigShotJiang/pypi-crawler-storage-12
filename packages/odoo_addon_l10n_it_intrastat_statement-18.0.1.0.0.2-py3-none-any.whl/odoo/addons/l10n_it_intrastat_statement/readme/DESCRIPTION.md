**Italiano**

Questo modulo si occupa di generare la dichiarazione Intrastat e le
relative stampe.

Le specifiche per tali stampe e i file da inviare sono in
<https://www.adm.gov.it/portale/-/determinazione-n-c2-b0-493869-del-23-dicembre-2021-nuovi-modelli-degli-elenchi-riepilogativi-delle-cessioni-e-degli-acquisti-intracomunitari-di-beni-e-delle-prestazioni-di-servizio-rese-e-ricevute-in-ambito-comunitario-periodi-di-riferimento-decorrenti-da>.
