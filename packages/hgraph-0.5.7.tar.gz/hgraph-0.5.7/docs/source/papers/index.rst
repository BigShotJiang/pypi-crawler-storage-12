Papers
======

This section contains more academic style papers describing HGraph.

.. toctree::
    positioning_paper