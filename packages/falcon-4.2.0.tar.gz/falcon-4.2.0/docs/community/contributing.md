% NOTE(vytas): This document is in MyST markdown (unlike others) in order to be
%   able to share CONTRIBUTING.md verbatim.

(contribute)=

```{include} ../../CONTRIBUTING.md

```
