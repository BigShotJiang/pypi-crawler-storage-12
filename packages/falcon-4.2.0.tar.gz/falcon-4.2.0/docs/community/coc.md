% NOTE(vytas): This document is in MyST markdown (unlike others) in order to be
%   able to share CODEOFCONDUCT.md verbatim.

(coc)=

```{include} ../../CODEOFCONDUCT.md

```
