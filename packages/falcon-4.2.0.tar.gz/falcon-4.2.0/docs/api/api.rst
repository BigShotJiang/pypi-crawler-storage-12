:orphan:

.. autoclass:: falcon.API
    :members:
    :inherited-members:
