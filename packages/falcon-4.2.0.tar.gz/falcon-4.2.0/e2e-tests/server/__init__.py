from .app import create_app

__all__ = ['app']

app = create_app()
