from ._anonymask import Anonymizer, Entity

__version__ = "0.1.0"