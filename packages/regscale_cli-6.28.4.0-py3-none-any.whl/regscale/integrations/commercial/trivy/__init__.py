"""
Module for processing Trivy scan results and loading them into RegScale.
"""

from .commands import import_scans
