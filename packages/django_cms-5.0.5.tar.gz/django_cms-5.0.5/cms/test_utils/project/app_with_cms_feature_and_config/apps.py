from django.apps import AppConfig


class CMSFeatureAndConfigConfig(AppConfig):
    name = 'cms.test_utils.project.app_with_cms_feature_and_config'
    label = 'app_with_cms_feature_and_config'
