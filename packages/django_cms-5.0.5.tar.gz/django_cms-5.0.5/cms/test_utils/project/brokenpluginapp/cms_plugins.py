import nonexistingmodule  # noqa: F401
