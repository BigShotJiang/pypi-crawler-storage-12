maturin 的 Cargo.toml 和 pyproject.toml 配置查https://github.com/PyO3/maturin/tree/a2d38e1d067fccf1b6e1b6aae1b0740dc9fc84f4/guide/src

在项目下创建项目执行：maturin new example_rust

在 python 脚本 import 调用
