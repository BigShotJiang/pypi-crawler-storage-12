"""
docker_ops.py - Functional Docker Compose operations library
High-level Docker operations with Docker SDK and CLI fallback.
"""
from __future__ import annotations
import subprocess
import json
import os
import logging
import re
import tarfile
import tempfile
import uuid
from pathlib import Path
from typing import Optional, List, Dict, Any, Iterator, Union, Callable
from dataclasses import dataclass, field
import concurrent.futures

# Core imports
from utils_devops.core import logs, files, systems, strings, envs, datetimes as dt_ops

# Optional imports
try:
    import docker
    from docker.errors import DockerException
    DOCKER_AVAILABLE = True
except ImportError:
    docker = None
    DOCKER_AVAILABLE = False

try:
    from tenacity import retry, stop_after_attempt, wait_exponential
    TENACITY_AVAILABLE = True
except ImportError:
    TENACITY_AVAILABLE = False
    # Simple retry decorator fallback
    def retry(*args, **kwargs):
        def decorator(f):
            return f
        return decorator

# Module logger
logger = logs.get_library_logger()

# Constants
DEFAULT_DOCKER_TIMEOUT = 300
DEFAULT_CONCURRENCY_LIMIT = 4
DEFAULT_PULL_RETRIES = 3

# Exceptions
class DockerOpsError(Exception):
    pass

class ComposeConflictError(DockerOpsError):
    pass

class HealthCheckFailed(DockerOpsError):
    pass

# Data structures for type hints
@dataclass
class ExecResult:
    rc: int
    stdout: str
    stderr: str

@dataclass
class LogLine:
    timestamp: Optional[str] = None
    service: Optional[str] = None
    message: str = ""

@dataclass
class ContainerInfo:
    id: str
    name: str
    image: str
    status: str
    service: Optional[str] = None

# Core Docker operations
def get_docker_client():
    """Get Docker client, fallback to None if not available"""
    if not DOCKER_AVAILABLE:
        return None
    
    try:
        return docker.from_env(timeout=DEFAULT_DOCKER_TIMEOUT)
    except DockerException as e:
        logger.warning(f"Docker client unavailable: {e}")
        return None

def _detect_compose_command() -> str:
    """
    Detect available compose command: 'docker compose' or 'docker-compose'
    Returns: 'compose' for modern, 'compose-legacy' for legacy, or raises error if neither available
    """
    # First try modern 'docker compose'
    try:
        result = run_docker_command(["docker", "compose", "version"], capture=True)
        if result.rc == 0:
            logger.debug("Using modern 'docker compose' command")
            return "compose"
    except Exception:
        pass
    
    # Try legacy 'docker-compose'
    try:
        result = run_docker_command(["docker-compose", "version"], capture=True)
        if result.rc == 0:
            logger.debug("Using legacy 'docker-compose' command")
            return "compose-legacy"
    except Exception:
        pass
    
    # Neither available
    raise DockerOpsError("Neither 'docker compose' nor 'docker-compose' is available. Please install Docker Compose.")

def run_docker_command(cmd: List[str], capture: bool = True, timeout: Optional[int] = None, 
                      input_text: Optional[str] = None) -> ExecResult:
    """Run docker command and return result"""
    try:
        logger.debug(f"Running: {' '.join(cmd)}")
        
        # Use systems.run with input text support
        if input_text:
            result = systems.run(cmd, capture=capture, input_text=input_text)
        else:
            result = systems.run(cmd, capture=capture)
            
        return ExecResult(rc=result.returncode, stdout=result.stdout, stderr=result.stderr)
    except Exception as e:
        raise DockerOpsError(f"Command failed: {' '.join(cmd)} - {e}")

def run_compose_command(compose_file: str, cmd: List[str], project_name: Optional[str] = None) -> ExecResult:
    """Run docker compose command with automatic command detection"""
    # Detect compose command once and cache it
    if not hasattr(run_compose_command, '_compose_command'):
        run_compose_command._compose_command = _detect_compose_command()
    
    compose_cmd = run_compose_command._compose_command
    
    # Build base command
    if compose_cmd == "compose":
        base_cmd = ["docker", "compose", "-f", compose_file]
    else:  # compose-legacy
        base_cmd = ["docker-compose", "-f", compose_file]
    
    if project_name:
        base_cmd.extend(["-p", project_name])
    
    base_cmd.extend(cmd)
    return run_docker_command(base_cmd)

# Alternative version with explicit command preference
def run_compose_command_v2(compose_file: str, cmd: List[str], project_name: Optional[str] = None,
                          prefer_modern: bool = True) -> ExecResult:
    """
    Run docker compose command with configurable preference.
    
    Args:
        compose_file: Path to compose file
        cmd: Compose command and arguments
        project_name: Project name
        prefer_modern: Prefer 'docker compose' over 'docker-compose'
    """
    # Try preferred command first
    if prefer_modern:
        commands_to_try = [
            (["docker", "compose", "-f", compose_file], "modern"),
            (["docker-compose", "-f", compose_file], "legacy")
        ]
    else:
        commands_to_try = [
            (["docker-compose", "-f", compose_file], "legacy"),
            (["docker", "compose", "-f", compose_file], "modern")
        ]
    
    last_error = None
    for base_cmd, cmd_type in commands_to_try:
        try:
            full_cmd = base_cmd.copy()
            if project_name:
                full_cmd.extend(["-p", project_name])
            full_cmd.extend(cmd)
            
            logger.debug(f"Trying {cmd_type} compose: {' '.join(full_cmd)}")
            result = run_docker_command(full_cmd)
            
            if result.rc == 0:
                logger.debug(f"Success with {cmd_type} compose command")
                return result
            else:
                # Command exists but failed - don't try the other one
                return result
                
        except Exception as e:
            last_error = e
            logger.debug(f"{cmd_type} compose failed: {e}")
            continue
    
    # Both commands failed
    raise DockerOpsError(f"All compose commands failed. Last error: {last_error}")

# Image operations
@retry(stop=stop_after_attempt(DEFAULT_PULL_RETRIES), wait=wait_exponential(multiplier=1, min=4, max=10)) if TENACITY_AVAILABLE else retry
def pull_image(image_name: str, auth: Optional[Dict] = None, logger: Optional[logging.Logger] = None) -> bool:
    """Pull Docker image with retry logic"""
    logger = logger or logging.getLogger(__name__)
    
    client = get_docker_client()
    if client:
        try:
            logger.info(f"Pulling image: {image_name}")
            client.images.pull(image_name, auth_config=auth)
            return True
        except DockerException as e:
            logger.warning(f"SDK pull failed, falling back to CLI: {e}")
    
    # Fallback to CLI
    result = run_docker_command(["docker", "pull", image_name])
    return result.rc == 0

def push_image(image_name: str, auth: Optional[Dict] = None) -> bool:
    """Push Docker image"""
    client = get_docker_client()
    if client:
        try:
            client.images.push(image_name, auth_config=auth)
            return True
        except DockerException:
            pass
    
    result = run_docker_command(["docker", "push", image_name])
    return result.rc == 0

def build_image(context: str, dockerfile: str = "Dockerfile", tag: Optional[str] = None, 
                build_args: Optional[Dict] = None, nocache: bool = False) -> bool:
    """Build Docker image"""
    client = get_docker_client()
    
    if client:
        try:
            build_kwargs = {
                "path": context,
                "dockerfile": dockerfile,
                "nocache": nocache,
            }
            if tag:
                build_kwargs["tag"] = tag
            if build_args:
                build_kwargs["buildargs"] = build_args
            
            client.images.build(**build_kwargs)
            return True
        except DockerException:
            pass
    
    # CLI fallback
    cmd = ["docker", "build", "-f", dockerfile, context]
    if tag:
        cmd.extend(["-t", tag])
    if nocache:
        cmd.append("--no-cache")
    if build_args:
        for k, v in build_args.items():
            cmd.extend(["--build-arg", f"{k}={v}"])
    
    result = run_docker_command(cmd)
    return result.rc == 0

# Container operations
def list_containers(all: bool = False, filters: Optional[Dict] = None) -> List[ContainerInfo]:
    """List containers"""
    client = get_docker_client()
    containers = []
    
    if client:
        try:
            docker_containers = client.containers.list(all=all, filters=filters or {})
            for c in docker_containers:
                containers.append(ContainerInfo(
                    id=c.id,
                    name=c.name,
                    image=c.image.tags[0] if c.image.tags else c.image.id,
                    status=c.status
                ))
            return containers
        except DockerException:
            pass
    
    # CLI fallback
    cmd = ["docker", "ps"]
    if all:
        cmd.append("-a")
    cmd.extend(["--format", "{{.ID}}|{{.Names}}|{{.Image}}|{{.Status}}"])
    
    result = run_docker_command(cmd)
    for line in result.stdout.strip().splitlines():
        if line.strip():
            parts = line.split("|", 3)
            if len(parts) == 4:
                containers.append(ContainerInfo(
                    id=parts[0],
                    name=parts[1],
                    image=parts[2],
                    status=parts[3]
                ))
    
    return containers

def get_container_logs(container_id: str, follow: bool = False, tail: int = 100, 
                      since: Optional[str] = None) -> Iterator[LogLine]:
    """Get container logs"""
    client = get_docker_client()
    
    if client and not follow:  # SDK doesn't handle follow well in this context
        try:
            container = client.containers.get(container_id)
            logs = container.logs(tail=tail, since=since, timestamps=True).decode('utf-8')
            for line in logs.splitlines():
                yield parse_log_line(line)
            return
        except DockerException:
            pass
    
    # CLI approach
    cmd = ["docker", "logs", container_id, "--tail", str(tail)]
    if since:
        cmd.extend(["--since", since])
    if follow:
        cmd.append("-f")
    
    result = run_docker_command(cmd, capture=not follow)
    
    if not follow:
        for line in result.stdout.splitlines():
            yield parse_log_line(line)
    else:
        # For follow mode, we'd need to handle streaming properly
        logger.warning("Follow mode requires proper stream handling")

def parse_log_line(line: str) -> LogLine:
    """Parse log line into structured format"""
    # Try to extract timestamp and message
    timestamp_match = re.match(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z)\s+(.*)', line)
    if timestamp_match:
        return LogLine(timestamp=timestamp_match.group(1), message=timestamp_match.group(2))
    return LogLine(message=line)

def exec_in_container(container_id: str, command: List[str], user: Optional[str] = None) -> ExecResult:
    """Execute command in container"""
    client = get_docker_client()
    
    if client:
        try:
            container = client.containers.get(container_id)
            result = container.exec_run(command, user=user)
            return ExecResult(
                rc=result.exit_code,
                stdout=result.output.decode('utf-8') if isinstance(result.output, bytes) else result.output,
                stderr=""
            )
        except DockerException:
            pass
    
    # CLI fallback
    cmd = ["docker", "exec"]
    if user:
        cmd.extend(["-u", user])
    cmd.append(container_id)
    cmd.extend(command)
    
    result = run_docker_command(cmd)
    return result

# Compose file operations
def read_compose_file(compose_file: str) -> Dict[str, Any]:
    """Read and parse docker-compose file"""
    try:
        content = files.read_file(compose_file)
        return strings.safe_parse_yaml(content, default={})
    except Exception as e:
        raise DockerOpsError(f"Failed to read compose file {compose_file}: {e}")

def write_compose_file(compose_file: str, data: Dict[str, Any], backup: bool = True) -> None:
    """Write docker-compose file"""
    if backup and files.file_exists(compose_file):
        files.backup_file(compose_file)
    
    try:
        files.write_yaml_file(compose_file, data)
    except Exception as e:
        raise DockerOpsError(f"Failed to write compose file {compose_file}: {e}")

def validate_compose_file(compose_file: str) -> List[str]:
    """Validate compose file structure"""
    errors = []
    try:
        data = read_compose_file(compose_file)
        
        # Basic validation
        if 'version' not in data:
            errors.append("Missing 'version' field")
        
        services = data.get('services', {})
        if not services:
            errors.append("No services defined")
        
        for name, service in services.items():
            if not service.get('image') and not service.get('build'):
                errors.append(f"Service '{name}' has neither image nor build")
            
            # Validate ports format
            for port in service.get('ports', []):
                if not isinstance(port, str) and not isinstance(port, dict):
                    errors.append(f"Service '{name}' has invalid port format: {port}")
    
    except Exception as e:
        errors.append(f"Failed to parse compose file: {e}")
    
    return errors

# Compose operations
def compose_up(compose_file: str, services: Optional[List[str]] = None, 
              build: bool = False, pull: bool = False, detach: bool = True,
              project_name: Optional[str] = None) -> bool:
    """Start compose services using detected compose command"""
    cmd = ["up"]
    if detach:
        cmd.append("-d")
    if build:
        cmd.append("--build")
    if pull:
        cmd.append("--pull")
    if services:
        cmd.extend(services)
    
    result = run_compose_command(compose_file, cmd, project_name)
    return result.rc == 0

def compose_down(compose_file: str, remove_volumes: bool = False, 
                remove_images: Optional[str] = None, project_name: Optional[str] = None) -> bool:
    """Stop compose services using detected compose command"""
    cmd = ["down"]
    if remove_volumes:
        cmd.append("-v")
    if remove_images:
        cmd.extend(["--rmi", remove_images])
    
    result = run_compose_command(compose_file, cmd, project_name)
    return result.rc == 0

def compose_ps(compose_file: str, project_name: Optional[str] = None) -> List[ContainerInfo]:
    """List compose services status using detected compose command"""
    result = run_compose_command(compose_file, ["ps", "--format", "json"], project_name)
    
    containers = []
    try:
        data = json.loads(result.stdout)
        for item in data if isinstance(data, list) else [data]:
            containers.append(ContainerInfo(
                id=item.get('ID', ''),
                name=item.get('Name', ''),
                image=item.get('Image', ''),
                status=item.get('State', ''),
                service=item.get('Service', '')
            ))
    except json.JSONDecodeError:
        # Fallback to text parsing
        lines = result.stdout.strip().splitlines()[1:]  # Skip header
        for line in lines:
            parts = line.split()
            if len(parts) >= 4:
                containers.append(ContainerInfo(
                    id=parts[0],
                    name=parts[1],
                    image=parts[2],
                    status=' '.join(parts[3:])
                ))
    
    return containers

# Add a function to check compose version
def get_compose_version() -> Dict[str, str]:
    """Get detected compose command and version"""
    try:
        result = run_compose_command("", ["version"])  # Empty compose file for version check
        version_info = {
            "command": run_compose_command._compose_command if hasattr(run_compose_command, '_compose_command') else "unknown",
            "output": result.stdout.strip()
        }
        return version_info
    except Exception as e:
        return {
            "command": "unknown", 
            "error": str(e)
        }

def compose_ps(compose_file: str, project_name: Optional[str] = None) -> List[ContainerInfo]:
    """List compose services status"""
    result = run_compose_command(compose_file, ["ps", "--format", "json"], project_name)
    
    containers = []
    try:
        data = json.loads(result.stdout)
        for item in data if isinstance(data, list) else [data]:
            containers.append(ContainerInfo(
                id=item.get('ID', ''),
                name=item.get('Name', ''),
                image=item.get('Image', ''),
                status=item.get('State', ''),
                service=item.get('Service', '')
            ))
    except json.JSONDecodeError:
        # Fallback to text parsing
        lines = result.stdout.strip().splitlines()[1:]  # Skip header
        for line in lines:
            parts = line.split()
            if len(parts) >= 4:
                containers.append(ContainerInfo(
                    id=parts[0],
                    name=parts[1],
                    image=parts[2],
                    status=' '.join(parts[3:])
                ))
    
    return containers

def compose_logs(compose_file: str, services: Optional[List[str]] = None, 
                follow: bool = False, tail: int = 100, project_name: Optional[str] = None) -> Iterator[LogLine]:
    """Get compose services logs"""
    cmd = ["logs", "--tail", str(tail)]
    if follow:
        cmd.append("-f")
    if services:
        cmd.extend(services)
    
    result = run_compose_command(compose_file, cmd, project_name)
    
    for line in result.stdout.splitlines():
        yield parse_compose_log_line(line)

def parse_compose_log_line(line: str) -> LogLine:
    """Parse compose log line"""
    # Format: service_name | timestamp message
    parts = line.split('|', 2)
    if len(parts) == 3:
        return LogLine(
            service=parts[0].strip(),
            timestamp=parts[1].strip(),
            message=parts[2].strip()
        )
    return LogLine(message=line)

def compose_pull(compose_file: str, services: Optional[List[str]] = None, 
                project_name: Optional[str] = None) -> Dict[str, bool]:
    """Pull images for compose services"""
    cmd = ["pull"]
    if services:
        cmd.extend(services)
    
    result = run_compose_command(compose_file, cmd, project_name)
    
    # Parse results
    pull_results = {}
    for line in result.stdout.splitlines():
        if "Pulling" in line and "..." in line:
            service = line.split("Pulling")[1].split("...")[0].strip()
            pull_results[service] = "done" in line.lower() or "complete" in line.lower()
    
    return pull_results

def compose_build(compose_file: str, services: Optional[List[str]] = None, 
                 nocache: bool = False, project_name: Optional[str] = None) -> Dict[str, bool]:
    """Build compose services"""
    cmd = ["build"]
    if nocache:
        cmd.append("--no-cache")
    if services:
        cmd.extend(services)
    
    result = run_compose_command(compose_file, cmd, project_name)
    
    build_results = {}
    for line in result.stdout.splitlines():
        if "Building" in line:
            service = line.split("Building")[1].strip()
            build_results[service] = "done" in line.lower() or "success" in line.lower()
    
    return build_results

# Health checks
def check_service_health(compose_file: str, service: str, 
                        check_command: Optional[List[str]] = None,
                        timeout: int = 30) -> Dict[str, Any]:
    """Check service health"""
    containers = compose_ps(compose_file)
    service_container = next((c for c in containers if c.service == service), None)
    
    if not service_container:
        return {"status": "not_running", "details": "Service not found"}
    
    # Try container health status first
    client = get_docker_client()
    if client:
        try:
            container = client.containers.get(service_container.id)
            health = container.attrs.get('State', {}).get('Health', {})
            if health:
                return {
                    "status": health.get('Status', 'unknown'),
                    "details": health
                }
        except DockerException:
            pass
    
    # Fallback to custom check
    if check_command:
        try:
            result = exec_in_container(service_container.id, check_command)
            return {
                "status": "healthy" if result.rc == 0 else "unhealthy",
                "details": f"Command exit code: {result.rc}"
            }
        except Exception as e:
            return {"status": "unhealthy", "details": str(e)}
    
    # Final fallback - check if container is running
    return {
        "status": "healthy" if "running" in service_container.status.lower() else "unhealthy",
        "details": f"Container status: {service_container.status}"
    }

def wait_for_healthy(compose_file: str, services: Optional[List[str]] = None,
                    timeout: int = 300, interval: int = 5) -> bool:
    """Wait for services to become healthy"""
    import time
    
    start_time = time.time()
    services_to_check = services or get_services_from_compose(compose_file)
    
    while time.time() - start_time < timeout:
        all_healthy = True
        unhealthy_services = []
        
        for service in services_to_check:
            health = check_service_health(compose_file, service)
            if health.get('status') != 'healthy':
                all_healthy = False
                unhealthy_services.append(service)
        
        if all_healthy:
            return True
        
        logger.info(f"Waiting for unhealthy services: {unhealthy_services}")
        time.sleep(interval)
    
    return False

def get_services_from_compose(compose_file: str) -> List[str]:
    """Get list of services from compose file"""
    data = read_compose_file(compose_file)
    return list(data.get('services', {}).keys())

# Backup and restore
def backup_compose(compose_file: str, backup_dir: str, include_images: bool = False, 
                  services: Optional[List[str]] = None) -> str:
    """Backup compose project"""
    backup_dir = Path(backup_dir)
    backup_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = dt_ops.current_datetime().strftime("%Y%m%d_%H%M%S")
    backup_name = f"compose_backup_{timestamp}"
    backup_path = backup_dir / backup_name
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Backup compose file
        files.copy(compose_file, str(temp_path / "docker-compose.yml"))
        
        # Backup environment files
        env_files = find_env_files(compose_file)
        for env_file in env_files:
            files.copy(env_file, str(temp_path / "env" / Path(env_file).name))
        
        # Backup images if requested
        if include_images:
            images_dir = temp_path / "images"
            images_dir.mkdir()
            services_to_backup = services or get_services_from_compose(compose_file)
            
            for service_name in services_to_backup:
                image_name = get_service_image(compose_file, service_name)
                if image_name:
                    image_path = images_dir / f"{service_name}.tar"
                    save_image_to_file(image_name, str(image_path))
        
        # Create archive
        archive_path = backup_path.with_suffix('.tar.gz')
        with tarfile.open(archive_path, 'w:gz') as tar:
            tar.add(temp_path, arcname=backup_name)
    
    logger.info(f"Backup created: {archive_path}")
    return str(archive_path)

def find_env_files(compose_file: str) -> List[str]:
    """Find environment files referenced in compose file"""
    data = read_compose_file(compose_file)
    env_files = set()
    
    for service in data.get('services', {}).values():
        env_file = service.get('env_file')
        if env_file:
            if isinstance(env_file, str):
                env_files.add(env_file)
            elif isinstance(env_file, list):
                env_files.update(env_file)
    
    return [f for f in env_files if files.file_exists(f)]

def get_service_image(compose_file: str, service: str) -> Optional[str]:
    """Get image name for service"""
    data = read_compose_file(compose_file)
    service_config = data.get('services', {}).get(service, {})
    return service_config.get('image')

def save_image_to_file(image_name: str, output_path: str) -> bool:
    """Save Docker image to file"""
    result = run_docker_command(["docker", "save", "-o", output_path, image_name])
    return result.rc == 0

def load_image_from_file(image_path: str) -> bool:
    """Load Docker image from file"""
    result = run_docker_command(["docker", "load", "-i", image_path])
    return result.rc == 0

# Enhanced Deployment workflow
def deploy_compose(
    compose_file: str,
    # Environment configuration
    env_file: str = '.env',
    env_new_file: Optional[str] = '.env.new',
    env_update_keys: Optional[List[str]] = None,  # None=all keys, []=no update
    env_backup: bool = True,
    
    # Deployment strategy
    deployment_strategy: str = 'rolling',  # 'rolling', 'recreate', 'blue-green'
    pull_images: bool = True,
    health_check: bool = True,
    health_timeout: int = 300,
    
    # Rollback configuration
    auto_rollback: bool = True,
    rollback_on_health_failure: bool = True,
    max_rollback_attempts: int = 3,
    
    # Backup configuration
    backup_enabled: bool = True,
    backup_dir: str = 'deploy_backups',
    backup_images: bool = True,
    
    # Cleanup configuration
    keep_image_versions: int = 3,
    cleanup_old_backups: bool = True,
    keep_backup_versions: int = 5,
    
    # Additional options
    project_name: Optional[str] = None,
    dry_run: bool = False,
    logger: Optional[logging.Logger] = None
    
) -> Dict[str, Any]:
    """
    Enhanced deployment workflow with robust rollback and environment management.
    
    Steps:
    1. Validate environment files and compose configuration
    2. Create comprehensive backup (compose + images)
    3. Update environment variables with backup
    4. Pull new images
    5. Deploy with selected strategy
    6. Health check with automatic rollback on failure
    7. Cleanup old images and backups
    
    Returns: Detailed deployment result with rollback capability
    """
    logger = logger or logging.getLogger(__name__)
    deployment_id = str(uuid.uuid4())[:8]
    
    result = {
        "deployment_id": deployment_id,
        "success": False,
        "steps": {},
        "rollback_performed": False,
        "error": None,
        "duration": 0.0
    }
    
    # Track deployment state for rollback
    deployment_state = {
        "backup_created": False,
        "env_updated": False,
        "images_pulled": False,
        "services_started": False,
        "backup_path": None,
        "env_backup_path": None,
        "original_env_content": None,
        "updated_env_keys": []
    }
    
    start_time = dt_ops.current_datetime()
    
    try:
        logger.info(f"🚀 Starting deployment {deployment_id}")
        logger.info(f"   Compose: {compose_file}")
        logger.info(f"   Strategy: {deployment_strategy}, Rollback: {auto_rollback}")
        logger.info(f"   Environment: {env_file} ← {env_new_file} (keys: {env_update_keys})")
        
        # Step 1: Pre-deployment validation
        logger.info("📋 Step 1: Validating configuration...")
        validation_errors = _validate_deployment_preconditions(
            compose_file, env_file, env_new_file, logger
        )
        if validation_errors:
            raise DockerOpsError(f"Pre-deployment validation failed: {validation_errors}")
        
        result["steps"]["validation"] = {"status": "passed", "checks": validation_errors}
        
        # Step 2: Create comprehensive backup
        if backup_enabled and not dry_run:
            logger.info("💾 Step 2: Creating backup...")
            backup_path = backup_compose(
                compose_file=compose_file,
                backup_dir=backup_dir,
                include_images=backup_images,
                project_name=project_name
            )
            deployment_state["backup_created"] = True
            deployment_state["backup_path"] = backup_path
            result["steps"]["backup"] = {"path": backup_path, "images_included": backup_images}
        
        # Step 3: Update environment file
        if env_new_file and files.file_exists(env_new_file) and not dry_run:
            logger.info("🔧 Step 3: Updating environment...")
            update_success, updated_keys = _update_environment_file(
                current_env_file=env_file,
                new_env_file=env_new_file,
                update_keys=env_update_keys or ['GIT_TAG'],  # Default to GIT_TAG
                backup=env_backup,
                logger=logger
            )
            
            if update_success:
                deployment_state["env_updated"] = True
                deployment_state["updated_env_keys"] = updated_keys
                result["steps"]["environment_update"] = {
                    "status": "success", 
                    "updated_keys": updated_keys,
                    "strategy": "selective" if env_update_keys else "full"
                }
                # Reload environment
                envs.load_env_file(env_file)
            else:
                logger.warning("Environment update failed or no changes needed")
        
        # Step 4: Pull new images
        if pull_images and not dry_run:
            logger.info("⬇️  Step 4: Pulling new images...")
            pull_results = compose_pull(compose_file, project_name=project_name)
            deployment_state["images_pulled"] = True
            result["steps"]["pull"] = pull_results
            
            # Check for pull failures
            failed_pulls = [svc for svc, success in pull_results.items() if not success]
            if failed_pulls:
                logger.warning(f"Failed to pull images for: {failed_pulls}")
        
        # Step 5: Deploy using selected strategy
        logger.info("🚀 Step 5: Deploying services...")
        deploy_result = _execute_deployment_strategy(
            compose_file=compose_file,
            strategy=deployment_strategy,
            project_name=project_name,
            dry_run=dry_run,
            logger=logger
        )
        
        if not dry_run:
            deployment_state["services_started"] = True
            result["steps"]["deploy"] = deploy_result
        
        # Step 6: Health checks with automatic rollback
        if health_check and not dry_run:
            logger.info("🏥 Step 6: Performing health checks...")
            health_success = wait_for_healthy(
                compose_file=compose_file,
                services=None,  # All services
                timeout=health_timeout,
                project_name=project_name
            )
            
            if health_success:
                result["steps"]["health_check"] = {"status": "healthy", "duration": health_timeout}
                logger.info("✅ All services healthy!")
            else:
                result["steps"]["health_check"] = {"status": "failed", "duration": health_timeout}
                
                if auto_rollback and rollback_on_health_failure:
                    logger.error("❌ Health checks failed! Initiating rollback...")
                    rollback_success = _perform_rollback(
                        deployment_state=deployment_state,
                        compose_file=compose_file,
                        env_file=env_file,
                        project_name=project_name,
                        max_attempts=max_rollback_attempts,
                        logger=logger
                    )
                    
                    result["rollback_performed"] = rollback_success
                    
                    if rollback_success:
                        logger.info("✅ Rollback completed successfully")
                        # Verify rollback health
                        rollback_health = wait_for_healthy(
                            compose_file=compose_file,
                            timeout=health_timeout // 2,  # Shorter timeout for rollback verification
                            project_name=project_name
                        )
                        result["steps"]["rollback_verification"] = {
                            "status": "healthy" if rollback_health else "unhealthy"
                        }
                    else:
                        logger.error("💥 Rollback failed! Manual intervention required!")
                        raise DockerOpsError("Deployment failed and rollback also failed")
                
                raise HealthCheckFailed("Services failed health checks after deployment")
        
        # Step 7: Cleanup and retention
        if not dry_run:
            logger.info("🧹 Step 7: Cleaning up old resources...")
            cleanup_results = _perform_post_deployment_cleanup(
                compose_file=compose_file,
                keep_image_versions=keep_image_versions,
                cleanup_old_backups=cleanup_old_backups,
                backup_dir=backup_dir,
                keep_backup_versions=keep_backup_versions,
                logger=logger
            )
            result["steps"]["cleanup"] = cleanup_results
        
        # Success!
        result["success"] = True
        result["duration"] = (dt_ops.current_datetime() - start_time).total_seconds()
        
        logger.info(f"🎉 Deployment {deployment_id} completed successfully!")
        logger.info(f"   Duration: {result['duration']:.1f}s")
        logger.info(f"   Updated: {len(deployment_state['updated_env_keys'])} environment keys")
        
        return result
        
    except Exception as e:
        # Failure handling
        result["duration"] = (dt_ops.current_datetime() - start_time).total_seconds()
        result["error"] = str(e)
        
        logger.error(f"💥 Deployment {deployment_id} failed: {e}")
        
        # Automatic rollback on any failure
        if auto_rollback and not dry_run:
            logger.info("🔄 Automatic rollback triggered due to failure...")
            try:
                rollback_success = _perform_rollback(
                    deployment_state=deployment_state,
                    compose_file=compose_file,
                    env_file=env_file,
                    project_name=project_name,
                    max_attempts=max_rollback_attempts,
                    logger=logger
                )
                result["rollback_performed"] = rollback_success
                
                if rollback_success:
                    logger.info("✅ Automatic rollback completed")
                else:
                    logger.error("💥 Automatic rollback failed!")
            except Exception as rollback_error:
                logger.error(f"💥 Rollback procedure failed: {rollback_error}")
                result["rollback_error"] = str(rollback_error)
        
        return result

def _validate_deployment_preconditions(
    compose_file: str,
    env_file: str,
    env_new_file: Optional[str],
    logger: logging.Logger
) -> List[str]:
    """Validate all deployment preconditions"""
    errors = []
    
    # Validate compose file exists and is valid
    if not files.file_exists(compose_file):
        errors.append(f"Compose file not found: {compose_file}")
    else:
        compose_errors = validate_compose_file(compose_file)
        if compose_errors:
            errors.extend(compose_errors)
    
    # Validate environment files
    if not files.file_exists(env_file):
        logger.warning(f"Main environment file not found: {env_file}")
        # This might be OK if we're creating it
    
    if env_new_file and not files.file_exists(env_new_file):
        errors.append(f"New environment file not found: {env_new_file}")
    elif env_new_file:
        # Validate new environment file format
        try:
            new_env_content = files.read_file(env_new_file)
            # Basic validation - check for common issues
            if "=" not in new_env_content.split('\n')[0] and len(new_env_content.split('\n')) > 1:
                logger.warning(f"New environment file {env_new_file} might have formatting issues")
        except Exception as e:
            errors.append(f"Failed to read new environment file: {e}")
    
    # Validate Docker availability
    client = get_docker_client()
    if not client:
        # Test CLI fallback
        result = run_docker_command(["docker", "version"])
        if result.rc != 0:
            errors.append("Docker is not available (SDK and CLI both failed)")
    
    return errors

def _update_environment_file(
    current_env_file: str,
    new_env_file: str,
    update_keys: List[str],
    backup: bool = True,
    logger: logging.Logger = None
) -> Tuple[bool, List[str]]:
    """
    Update environment file with selective key updates.
    Returns: (success, list_of_updated_keys)
    """
    logger = logger or logging.getLogger(__name__)
    
    try:
        # Read current environment
        current_env = {}
        if files.file_exists(current_env_file):
            current_env = envs.load_env_file(current_env_file)
        
        # Read new environment
        new_env = envs.load_env_file(new_env_file)
        
        # Create backup if requested
        if backup and files.file_exists(current_env_file):
            backup_path = files.backup_file(current_env_file)
            logger.info(f"Backed up environment to: {backup_path}")
        
        # Determine which keys to update
        keys_to_update = update_keys if update_keys else list(new_env.keys())
        updated_keys = []
        
        # Update selected keys
        for key in keys_to_update:
            if key in new_env:
                old_value = current_env.get(key)
                new_value = new_env[key]
                
                if old_value != new_value:
                    current_env[key] = new_value
                    updated_keys.append(key)
                    logger.debug(f"Updated {key}: {old_value} -> {new_value}")
            else:
                logger.warning(f"Key {key} not found in new environment file")
        
        # Write updated environment
        if updated_keys:
            envs.write_env_file(current_env_file, current_env)
            logger.info(f"Updated {len(updated_keys)} environment variables: {updated_keys}")
            return True, updated_keys
        else:
            logger.info("No environment variables needed updating")
            return False, []
            
    except Exception as e:
        logger.error(f"Failed to update environment file: {e}")
        return False, []

def _execute_deployment_strategy(
    compose_file: str,
    strategy: str,
    project_name: Optional[str],
    dry_run: bool,
    logger: logging.Logger
) -> Dict[str, Any]:
    """Execute deployment using selected strategy"""
    
    if dry_run:
        logger.info(f"Dry-run: Would deploy using {strategy} strategy")
        return {"strategy": strategy, "dry_run": True}
    
    if strategy == 'rolling':
        # Stop old, start new (minimal downtime)
        logger.info("Using rolling deployment strategy...")
        compose_down(compose_file, project_name=project_name)
        success =  compose_up_with_conflict_resolution(
            compose_file=compose_file,
            resolve_conflicts=True,
            remove_conflicting_containers=True,
            project_name=project_name,
            detach=True
        )
        return {"strategy": "rolling", "success": success}
    
    elif strategy == 'recreate':
        # Complete tear down and rebuild
        logger.info("Using recreate deployment strategy...")
        compose_down(compose_file, remove_volumes=True, project_name=project_name)
        success =  compose_up_with_conflict_resolution(
            compose_file=compose_file,
            resolve_conflicts=True,
            remove_conflicting_containers=True,
            project_name=project_name,
            detach=True
        )
        return {"strategy": "recreate", "success": success}
    
    elif strategy == 'blue-green':
        # Simplified blue-green (would need more infrastructure)
        logger.warning("Blue-green deployment requires additional setup, using rolling instead")
        return _execute_deployment_strategy(compose_file, 'rolling', project_name, dry_run, logger)
    
    else:
        logger.warning(f"Unknown strategy {strategy}, using rolling")
        return _execute_deployment_strategy(compose_file, 'rolling', project_name, dry_run, logger)

def _perform_rollback(
    deployment_state: Dict[str, Any],
    compose_file: str,
    env_file: str,
    project_name: Optional[str],
    max_attempts: int,
    logger: logging.Logger
) -> bool:
    """Perform comprehensive rollback"""
    
    for attempt in range(1, max_attempts + 1):
        try:
            logger.info(f"Rollback attempt {attempt}/{max_attempts}...")
            
            rollback_actions = []
            
            # 1. Rollback environment if it was updated
            if deployment_state.get("env_updated"):
                if deployment_state.get("env_backup_path"):
                    files.copy(deployment_state["env_backup_path"], env_file)
                    rollback_actions.append("environment")
                    logger.info("Restored environment from backup")
                elif deployment_state.get("original_env_content") is not None:
                    files.write_file(env_file, deployment_state["original_env_content"])
                    rollback_actions.append("environment")
                    logger.info("Restored environment from memory")
            
            # 2. Rollback services using backup
            if deployment_state.get("backup_created") and deployment_state.get("backup_path"):
                try:
                    # Stop current services
                    compose_down(compose_file, project_name=project_name)
                    
                    # Restore from backup
                    restore_compose(
                        backup_path=deployment_state["backup_path"],
                        restore_dir=Path(compose_file).parent,
                        load_images=True,
                        project_name=project_name
                    )
                    rollback_actions.append("services")
                    logger.info("Restored services from backup")
                except Exception as restore_error:
                    logger.error(f"Service restoration failed: {restore_error}")
                    # Continue with other rollback actions
            
            # 3. Alternative: Simple compose restart
            if not rollback_actions and deployment_state.get("services_started"):
                compose_down(compose_file, project_name=project_name)
                compose_up(compose_file, project_name=project_name)
                rollback_actions.append("services_restart")
                logger.info("Restarted services as fallback")
            
            if rollback_actions:
                logger.info(f"Rollback completed: {rollback_actions}")
                return True
            else:
                logger.warning("No rollback actions were performed")
                
        except Exception as e:
            logger.error(f"Rollback attempt {attempt} failed: {e}")
            if attempt < max_attempts:
                logger.info("Waiting before retry...")
                dt_ops.sleep(5)  # Wait before retry
    
    logger.error(f"All {max_attempts} rollback attempts failed")
    return False

def _perform_post_deployment_cleanup(
    compose_file: str,
    keep_image_versions: int,
    cleanup_old_backups: bool,
    backup_dir: str,
    keep_backup_versions: int,
    logger: logging.Logger
) -> Dict[str, Any]:
    """Cleanup old resources after successful deployment"""
    cleanup_results = {}
    
    try:
        # Cleanup old images
        removed_images = cleanup_old_images(keep_count=keep_image_versions)
        cleanup_results["images_removed"] = removed_images
        logger.info(f"Cleaned up {len(removed_images)} old images")
        
        # Cleanup old backups
        if cleanup_old_backups:
            removed_backups = _cleanup_old_backups(backup_dir, keep=keep_backup_versions)
            cleanup_results["backups_removed"] = removed_backups
            logger.info(f"Cleaned up {len(removed_backups)} old backups")
    
    except Exception as e:
        logger.warning(f"Cleanup operations partially failed: {e}")
        cleanup_results["cleanup_errors"] = str(e)
    
    return cleanup_results

def _cleanup_old_backups(backup_dir: str, keep: int = 5) -> List[str]:
    """Remove old backup files, keeping only the most recent ones"""
    try:
        import glob
        backup_files = sorted(
            glob.glob(f"{backup_dir}/*.tar*"), 
            key=os.path.getmtime, 
            reverse=True
        )
        
        removed = []
        for old_backup in backup_files[keep:]:
            try:
                os.remove(old_backup)
                removed.append(Path(old_backup).name)
            except Exception as e:
                logger.warning(f"Failed to remove backup {old_backup}: {e}")
        
        return removed
    except Exception as e:
        logger.warning(f"Backup cleanup failed: {e}")
        return []

# Additional helper functions
def restore_compose(
    backup_path: str,
    restore_dir: str,
    load_images: bool = True,
    project_name: Optional[str] = None
) -> bool:
    """Restore compose project from backup"""
    try:
        restore_dir = Path(restore_dir)
        restore_dir.mkdir(parents=True, exist_ok=True)
        
        # Extract backup
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            with tarfile.open(backup_path, 'r') as tar:
                tar.extractall(temp_path)
            
            # Find compose file
            compose_files = list(temp_path.rglob("docker-compose*.yml"))
            if not compose_files:
                compose_files = list(temp_path.rglob("*.yml"))
            
            if compose_files:
                compose_file = compose_files[0]
                # Copy to restore directory
                target_compose = restore_dir / compose_file.name
                files.copy(str(compose_file), str(target_compose))
                
                # Load images if requested
                if load_images:
                    images_dir = temp_path / "images"
                    if images_dir.exists():
                        for image_file in images_dir.glob("*.tar"):
                            load_image_from_file(str(image_file))
                
                # Start services
                return compose_up(str(target_compose), project_name=project_name)
        
        return False
    except Exception as e:
        logger.error(f"Restore failed: {e}")
        return False

# Enhanced backup function
def backup_compose(
    compose_file: str,
    backup_dir: str,
    include_images: bool = False,
    project_name: Optional[str] = None
) -> str:
    """Create comprehensive backup of compose project"""
    backup_dir = Path(backup_dir)
    backup_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = dt_ops.current_datetime().strftime("%Y%m%d_%H%M%S")
    project = project_name or Path(compose_file).stem
    backup_name = f"{project}_backup_{timestamp}"
    backup_path = backup_dir / f"{backup_name}.tar.gz"
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Backup compose file and related files
        compose_dir = Path(compose_file).parent
        for file in compose_dir.glob("docker-compose*.yml"):
            files.copy(str(file), str(temp_path / file.name))
        
        # Backup environment files
        env_files = find_env_files(compose_file)
        env_dir = temp_path / "env"
        env_dir.mkdir(exist_ok=True)
        for env_file in env_files:
            files.copy(env_file, str(env_dir / Path(env_file).name))
        
        # Backup images
        if include_images:
            images_dir = temp_path / "images"
            images_dir.mkdir(exist_ok=True)
            services = get_services_from_compose(compose_file)
            
            for service in services:
                image_name = get_service_image(compose_file, service)
                if image_name:
                    image_path = images_dir / f"{service}.tar"
                    save_image_to_file(image_name, str(image_path))
        
        # Create archive
        with tarfile.open(backup_path, 'w:gz') as tar:
            tar.add(temp_path, arcname=backup_name)
    
    logger.info(f"Backup created: {backup_path}")
    return str(backup_path)

# Bulk operations
def bulk_compose_operation(compose_files: List[str], operation: Callable, 
                          max_workers: int = 4, **kwargs) -> Dict[str, Any]:
    """Perform operation on multiple compose files in parallel"""
    results = {}
    
    def process_compose(compose_file):
        try:
            return compose_file, operation(compose_file, **kwargs)
        except Exception as e:
            return compose_file, {"error": str(e)}
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_file = {
            executor.submit(process_compose, file): file 
            for file in compose_files
        }
        
        for future in concurrent.futures.as_completed(future_to_file):
            file = future_to_file[future]
            try:
                results[file] = future.result()[1]
            except Exception as e:
                results[file] = {"error": str(e)}
    
    return results

# Utility functions
def get_compose_status(compose_file: str) -> Dict[str, Any]:
    """Get comprehensive status of compose project"""
    containers = compose_ps(compose_file)
    services = get_services_from_compose(compose_file)
    
    status = {
        "compose_file": compose_file,
        "services_defined": services,
        "containers_running": [],
        "health_status": {}
    }
    
    for container in containers:
        status["containers_running"].append({
            "service": container.service,
            "name": container.name,
            "image": container.image,
            "status": container.status
        })
        
        if container.service:
            status["health_status"][container.service] = check_service_health(
                compose_file, container.service
            )
    
    return status

def cleanup_old_images(keep_count: int = 3, dry_run: bool = False) -> List[str]:
    """Clean up old Docker images"""
    removed = []
    
    try:
        # Get all images
        result = run_docker_command(["docker", "images", "--format", "{{.ID}}|{{.Repository}}|{{.Tag}}|{{.CreatedAt}}"])
        
        images = []
        for line in result.stdout.strip().splitlines():
            if line.strip():
                parts = line.split('|', 3)
                if len(parts) == 4:
                    images.append({
                        'id': parts[0],
                        'repository': parts[1],
                        'tag': parts[2],
                        'created': parts[3]
                    })
        
        # Group by repository and keep only latest
        repos = {}
        for img in images:
            repo = img['repository']
            if repo not in repos:
                repos[repo] = []
            repos[repo].append(img)
        
        for repo, repo_images in repos.items():
            # Sort by creation date (newest first)
            repo_images.sort(key=lambda x: x['created'], reverse=True)
            
            # Remove old images
            for old_img in repo_images[keep_count:]:
                if dry_run:
                    logger.info(f"Would remove: {old_img['repository']}:{old_img['tag']}")
                else:
                    remove_result = run_docker_command(["docker", "rmi", old_img['id']])
                    if remove_result.rc == 0:
                        removed.append(f"{old_img['repository']}:{old_img['tag']}")
    
    except Exception as e:
        logger.error(f"Image cleanup failed: {e}")
    
    return removed

# ==================== AUTHENTICATION ====================
def docker_login(
    registry: str, 
    username: str, 
    password: str, 
    email: Optional[str] = None,
    logger: Optional[logging.Logger] = None
) -> bool:
    """
    Login to Docker registry.
    
    Args:
        registry: Registry URL (e.g., docker.io, ghcr.io)
        username: Registry username
        password: Registry password/token
        email: Optional email
        logger: Custom logger
        
    Returns:
        Success status
    """
    logger = logger or logging.getLogger(__name__)
    
    client = get_docker_client()
    if client:
        try:
            client.login(
                username=username,
                password=password,
                registry=registry,
                email=email
            )
            logger.info(f"Successfully logged into {registry}")
            return True
        except DockerException as e:
            logger.error(f"SDK login failed: {e}")
    
    # CLI fallback
    cmd = ["docker", "login", registry, "--username", username, "--password-stdin"]
    result = run_docker_command(cmd, capture=True, input_text=password)
    
    if result.rc == 0:
        logger.info(f"CLI login successful to {registry}")
        return True
    else:
        logger.error(f"Login failed: {result.stderr}")
        return False

# ==================== CONTAINER SHELL ACCESS ====================
def run_container_shell(
    container_id: str,
    shell: str = "bash",
    command: Optional[str] = None,
    user: Optional[str] = None,
    workdir: Optional[str] = None,
    env: Optional[Dict[str, str]] = None
) -> ExecResult:
    """
    Run interactive shell in container.
    
    Args:
        container_id: Container ID or name
        shell: Shell to use (bash, sh, powershell, cmd)
        command: Optional command to execute in shell
        user: Optional user to run as
        workdir: Optional working directory
        env: Optional environment variables
        
    Returns:
        ExecResult with command output
    """
    # Determine shell command based on shell type
    shell_commands = {
        "bash": ["/bin/bash", "-c"],
        "sh": ["/bin/sh", "-c"], 
        "powershell": ["powershell", "-Command"],
        "cmd": ["cmd", "/c"]
    }
    
    if shell not in shell_commands:
        raise DockerOpsError(f"Unsupported shell: {shell}. Available: {list(shell_commands.keys())}")
    
    shell_cmd = shell_commands[shell]
    
    # Build command
    if command:
        full_cmd = shell_cmd + [command]
    else:
        # Interactive mode - just start the shell
        full_cmd = shell_cmd[0:1]  # Just the shell executable
    
    # Build docker exec command
    cmd = ["docker", "exec", "-i"]
    
    if user:
        cmd.extend(["-u", user])
    
    if workdir:
        cmd.extend(["-w", workdir])
    
    if env:
        for k, v in env.items():
            cmd.extend(["-e", f"{k}={v}"])
    
    # Add TTY for interactive sessions if no command provided
    if not command:
        cmd.append("-t")
    
    cmd.append(container_id)
    cmd.extend(full_cmd)
    
    return run_docker_command(cmd, capture=bool(command))

# ==================== CONTAINER MANAGEMENT ====================
def container_commit(
    container_id: str,
    repository: str,
    tag: str = "latest",
    message: Optional[str] = None,
    author: Optional[str] = None,
    changes: Optional[List[str]] = None
) -> bool:
    """
    Commit container to new image.
    
    Args:
        container_id: Container to commit
        repository: Repository name for new image
        tag: Image tag
        message: Commit message
        author: Author information
        changes: Dockerfile instructions to apply
        
    Returns:
        Success status
    """
    client = get_docker_client()
    if client:
        try:
            container = client.containers.get(container_id)
            container.commit(
                repository=repository,
                tag=tag,
                message=message,
                author=author,
                changes=changes
            )
            return True
        except DockerException:
            pass
    
    # CLI fallback
    cmd = ["docker", "commit"]
    if message:
        cmd.extend(["-m", message])
    if author:
        cmd.extend(["--author", author])
    if changes:
        for change in changes:
            cmd.extend(["--change", change])
    cmd.extend([container_id, f"{repository}:{tag}"])
    
    result = run_docker_command(cmd)
    return result.rc == 0

def container_kill(
    container_id: str,
    signal: str = "SIGKILL"
) -> bool:
    """
    Kill container with specified signal.
    
    Args:
        container_id: Container to kill
        signal: Signal to send (SIGKILL, SIGTERM, etc.)
        
    Returns:
        Success status
    """
    client = get_docker_client()
    if client:
        try:
            container = client.containers.get(container_id)
            container.kill(signal=signal)
            return True
        except DockerException:
            pass
    
    # CLI fallback
    result = run_docker_command(["docker", "kill", "-s", signal, container_id])
    return result.rc == 0

def container_remove(
    container_id: str,
    force: bool = False,
    remove_volumes: bool = False
) -> bool:
    """
    Remove container.
    
    Args:
        container_id: Container to remove
        force: Force removal if running
        remove_volumes: Remove associated volumes
        
    Returns:
        Success status
    """
    client = get_docker_client()
    if client:
        try:
            container = client.containers.get(container_id)
            container.remove(force=force, v=remove_volumes)
            return True
        except DockerException:
            pass
    
    # CLI fallback
    cmd = ["docker", "rm"]
    if force:
        cmd.append("-f")
    if remove_volumes:
        cmd.append("-v")
    cmd.append(container_id)
    
    result = run_docker_command(cmd)
    return result.rc == 0

def container_restart(
    container_id: str,
    timeout: int = 10
) -> bool:
    """
    Restart container.
    
    Args:
        container_id: Container to restart
        timeout: Timeout before killing container
        
    Returns:
        Success status
    """
    client = get_docker_client()
    if client:
        try:
            container = client.containers.get(container_id)
            container.restart(timeout=timeout)
            return True
        except DockerException:
            pass
    
    # CLI fallback
    result = run_docker_command(["docker", "restart", "-t", str(timeout), container_id])
    return result.rc == 0

# ==================== IMAGE MANAGEMENT ====================
def image_tag(
    source_image: str,
    target_image: str,
    force: bool = False
) -> bool:
    """
    Tag an image with new name/tag.
    
    Args:
        source_image: Source image name:tag
        target_image: Target image name:tag
        force: Force tag even if target exists
        
    Returns:
        Success status
    """
    client = get_docker_client()
    if client:
        try:
            image = client.images.get(source_image)
            image.tag(target_image, force=force)
            return True
        except DockerException:
            pass
    
    # CLI fallback
    cmd = ["docker", "tag", source_image, target_image]
    if force:
        # Docker CLI doesn't have force flag for tag, we'll remove existing first
        run_docker_command(["docker", "rmi", target_image])
    
    result = run_docker_command(cmd)
    return result.rc == 0

# ==================== PRUNE OPERATIONS ====================
def prune_system(
    all_resources: bool = True,
    volumes: bool = False,
    filters: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Prune unused Docker resources.
    
    Args:
        all_resources: Prune containers, images, networks
        volumes: Also prune volumes (be careful!)
        filters: Prune filters
        
    Returns:
        Prune results summary
    """
    result = {}
    
    if all_resources:
        # Prune containers
        cmd = ["docker", "container", "prune", "-f"]
        if filters:
            for k, v in filters.items():
                cmd.extend(["--filter", f"{k}={v}"])
        container_result = run_docker_command(cmd)
        result["containers"] = container_result.stdout
        
        # Prune images
        cmd = ["docker", "image", "prune", "-f"]
        if filters:
            for k, v in filters.items():
                cmd.extend(["--filter", f"{k}={v}"])
        image_result = run_docker_command(cmd)
        result["images"] = image_result.stdout
        
        # Prune networks
        cmd = ["docker", "network", "prune", "-f"]
        if filters:
            for k, v in filters.items():
                cmd.extend(["--filter", f"{k}={v}"])
        network_result = run_docker_command(cmd)
        result["networks"] = network_result.stdout
    
    if volumes:
        cmd = ["docker", "volume", "prune", "-f"]
        if filters:
            for k, v in filters.items():
                cmd.extend(["--filter", f"{k}={v}"])
        volume_result = run_docker_command(cmd)
        result["volumes"] = volume_result.stdout
    
    return result

# ==================== NETWORK MANAGEMENT ====================
def create_network(
    name: str,
    driver: str = "bridge",
    attachable: bool = True,
    labels: Optional[Dict[str, str]] = None,
    options: Optional[Dict[str, str]] = None
) -> bool:
    """
    Create Docker network.
    
    Args:
        name: Network name
        driver: Network driver (bridge, overlay, etc.)
        attachable: Whether containers can connect later
        labels: Network labels
        options: Driver-specific options
        
    Returns:
        Success status
    """
    client = get_docker_client()
    if client:
        try:
            client.networks.create(
                name=name,
                driver=driver,
                attachable=attachable,
                labels=labels or {},
                options=options or {}
            )
            return True
        except DockerException:
            pass
    
    # CLI fallback
    cmd = ["docker", "network", "create"]
    if driver != "bridge":
        cmd.extend(["--driver", driver])
    if attachable:
        cmd.append("--attachable")
    if labels:
        for k, v in labels.items():
            cmd.extend(["--label", f"{k}={v}"])
    if options:
        for k, v in options.items():
            cmd.extend(["--opt", f"{k}={v}"])
    cmd.append(name)
    
    result = run_docker_command(cmd)
    return result.rc == 0

def ensure_network(
    name: str,
    driver: str = "bridge",
    attachable: bool = True,
    labels: Optional[Dict[str, str]] = None
) -> bool:
    """
    Ensure network exists, create if missing.
    
    Args:
        name: Network name
        driver: Network driver
        attachable: Whether network is attachable
        labels: Network labels
        
    Returns:
        True if network exists or was created
    """
    client = get_docker_client()
    
    # Check if network exists
    if client:
        try:
            client.networks.get(name)
            return True  # Network exists
        except DockerException:
            pass  # Network doesn't exist
    
    # CLI check
    result = run_docker_command(["docker", "network", "ls", "--format", "{{.Name}}"])
    if name in result.stdout.splitlines():
        return True
    
    # Create network
    return create_network(name, driver, attachable, labels)

# ==================== VOLUME MANAGEMENT ====================
def create_volume(
    name: str,
    driver: str = "local",
    labels: Optional[Dict[str, str]] = None,
    options: Optional[Dict[str, str]] = None
) -> bool:
    """
    Create Docker volume.
    
    Args:
        name: Volume name
        driver: Volume driver
        labels: Volume labels
        options: Driver-specific options
        
    Returns:
        Success status
    """
    client = get_docker_client()
    if client:
        try:
            client.volumes.create(
                name=name,
                driver=driver,
                labels=labels or {},
                driver_opts=options or {}
            )
            return True
        except DockerException:
            pass
    
    # CLI fallback
    cmd = ["docker", "volume", "create"]
    if driver != "local":
        cmd.extend(["--driver", driver])
    if labels:
        for k, v in labels.items():
            cmd.extend(["--label", f"{k}={v}"])
    if options:
        for k, v in options.items():
            cmd.extend(["--opt", f"{k}={v}"])
    cmd.append(name)
    
    result = run_docker_command(cmd)
    return result.rc == 0

def ensure_volume(
    name: str,
    driver: str = "local",
    labels: Optional[Dict[str, str]] = None
) -> bool:
    """
    Ensure volume exists, create if missing.
    
    Args:
        name: Volume name
        driver: Volume driver
        labels: Volume labels
        
    Returns:
        True if volume exists or was created
    """
    client = get_docker_client()
    
    # Check if volume exists
    if client:
        try:
            client.volumes.get(name)
            return True  # Volume exists
        except DockerException:
            pass  # Volume doesn't exist
    
    # CLI check
    result = run_docker_command(["docker", "volume", "ls", "--format", "{{.Name}}"])
    if name in result.stdout.splitlines():
        return True
    
    # Create volume
    return create_volume(name, driver, labels)

# ==================== CONFLICT DETECTION ====================
def check_conflicts(
    compose_file: str,
    check_ports: bool = True,
    check_networks: bool = True,
    check_volumes: bool = False,
    project_name: Optional[str] = None
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Check for potential conflicts with existing Docker resources.
    
    Args:
        compose_file: Compose file to check
        check_ports: Check for port conflicts
        check_networks: Check for network conflicts  
        check_volumes: Check for volume conflicts
        project_name: Project name for scoping
        
    Returns:
        Dictionary of conflicts by type
    """
    conflicts = {
        "port_conflicts": [],
        "network_conflicts": [], 
        "volume_conflicts": [],
        "container_conflicts": []
    }
    
    # Read compose configuration
    compose_config = read_compose_file(compose_file)
    services = compose_config.get('services', {})
    
    # Get all running containers
    all_containers = list_containers(all=False)
    
    # Check port conflicts
    if check_ports:
        used_ports = _get_used_ports(all_containers)
        for service_name, service_config in services.items():
            service_ports = service_config.get('ports', [])
            for port_mapping in service_ports:
                host_port = _extract_host_port(port_mapping)
                if host_port and host_port in used_ports:
                    conflicts["port_conflicts"].append({
                        "service": service_name,
                        "port": host_port,
                        "conflicting_container": used_ports[host_port]
                    })
    
    # Check network conflicts
    if check_networks:
        compose_networks = compose_config.get('networks', {})
        existing_networks = _get_existing_networks()
        for network_name in compose_networks.keys():
            if network_name in existing_networks:
                conflicts["network_conflicts"].append({
                    "network": network_name,
                    "existing": True
                })
    
    # Check container name conflicts
    for service_name, service_config in services.items():
        container_name = service_config.get('container_name')
        if container_name:
            for container in all_containers:
                if container.name == container_name or container.name == f"/{container_name}":
                    conflicts["container_conflicts"].append({
                        "service": service_name,
                        "container_name": container_name,
                        "conflicting_container": container.id
                    })
    
    return conflicts

def _get_used_ports(containers: List[ContainerInfo]) -> Dict[int, str]:
    """Get used host ports from containers"""
    used_ports = {}
    for container in containers:
        # This would require container inspection to get port mappings
        # Simplified version - we'd need to inspect each container
        pass
    return used_ports

def _extract_host_port(port_mapping: Union[str, Dict]) -> Optional[int]:
    """Extract host port from port mapping"""
    if isinstance(port_mapping, str):
        # Format: "host:container" or "host:container/protocol"
        parts = port_mapping.split(':')
        if len(parts) >= 2:
            return int(parts[0])
    elif isinstance(port_mapping, dict):
        return port_mapping.get('published')
    return None

def _get_existing_networks() -> List[str]:
    """Get list of existing Docker networks"""
    result = run_docker_command(["docker", "network", "ls", "--format", "{{.Name}}"])
    return result.stdout.splitlines()

def resolve_conflicts(
    compose_file: str,
    remove_conflicting_containers: bool = False,
    force: bool = False,
    project_name: Optional[str] = None
) -> Dict[str, Any]:
    """
    Detect and resolve conflicts for compose deployment.
    
    Args:
        compose_file: Compose file to check
        remove_conflicting_containers: Remove conflicting containers
        force: Force removal without confirmation
        project_name: Project name
        
    Returns:
        Resolution results
    """
    conflicts = check_conflicts(compose_file, project_name=project_name)
    resolution = {
        "conflicts_found": conflicts,
        "resolved": [],
        "errors": []
    }
    
    # Resolve container conflicts
    for conflict in conflicts.get("container_conflicts", []):
        container_id = conflict["conflicting_container"]
        try:
            if remove_conflicting_containers:
                if container_remove(container_id, force=force):
                    resolution["resolved"].append(f"container:{container_id}")
                else:
                    resolution["errors"].append(f"Failed to remove container {container_id}")
        except Exception as e:
            resolution["errors"].append(str(e))
    
    return resolution

# ==================== COMPOSE ENHANCEMENTS ====================
def compose_up_with_conflict_resolution(
    compose_file: str,
    resolve_conflicts: bool = True,
    remove_conflicting_containers: bool = True,
    project_name: Optional[str] = None,
    **kwargs
) -> bool:
    """
    Compose up with automatic conflict resolution.
    
    Args:
        compose_file: Compose file
        resolve_conflicts: Enable conflict resolution
        remove_conflicting_containers: Remove conflicting containers
        project_name: Project name
        **kwargs: Additional compose_up arguments
        
    Returns:
        Success status
    """
    if resolve_conflicts:
        logger.info("Checking for conflicts...")
        resolution = resolve_conflicts(
            compose_file,
            remove_conflicting_containers=remove_conflicting_containers,
            force=True,
            project_name=project_name
        )
        
        if resolution["resolved"]:
            logger.info(f"Resolved conflicts: {resolution['resolved']}")
        if resolution["errors"]:
            logger.warning(f"Conflict resolution errors: {resolution['errors']}")
    
    return compose_up(compose_file, project_name=project_name, **kwargs)

# Main execution for testing
if __name__ == "__main__":
    # Example usage
    compose_file = "docker-compose.yml"
    
    if files.file_exists(compose_file):
        status = get_compose_status(compose_file)
        print(json.dumps(status, indent=2))
    else:
        print("No docker-compose.yml found")

# Complete __all__ exports
__all__ = [
    # Core
    "get_docker_client", "run_docker_command", "run_compose_command",
    # Images
    "pull_image", "push_image", "build_image", "save_image_to_file", "load_image_from_file",
    # Containers
    "list_containers", "get_container_logs", "exec_in_container", "parse_log_line",
    # Compose files
    "read_compose_file", "write_compose_file", "validate_compose_file",
    "get_services_from_compose", "get_service_image", "find_env_files",
    # Compose operations
    "compose_up", "compose_down", "compose_restart", "compose_ps",
    "compose_logs", "compose_pull", "compose_build", "parse_compose_log_line",
    # Health
    "check_service_health", "wait_for_healthy",
    # Backup & restore
    "backup_compose", "restore_compose",
    # Deployment
    "deploy_compose",
    # Utilities
    "get_compose_status", "cleanup_old_images",
    # Data classes
    "ExecResult", "LogLine", "ContainerInfo",
    # Exceptions
    "DockerOpsError", "ComposeConflictError", "HealthCheckFailed",
    
     # New authentication
    "docker_login",
    
    # New container operations  
    "run_container_shell","container_commit", "container_kill","container_remove","container_restart",
    
    # New image operations
    "image_tag",
    
    # New prune operations
    "prune_system",
    
    # New network/volume operations
    "create_network","ensure_network", "create_volume","ensure_volume",
    
    # New conflict detection
    "check_conflicts","resolve_conflicts","compose_up_with_conflict_resolution",
    
    # Help
    "help"
]

def help(function_name: Optional[str] = None) -> str:
    """
    DockerOps - Functional Docker Compose Operations Library
    
    Quick help: help() for overview, help('function_name') for details, help('category') for groups
    """
    
    categories = {
        "core": ["get_docker_client", "run_docker_command", "run_compose_command"],
        "images": ["pull_image", "push_image", "build_image", "save_image_to_file", "load_image_from_file"],
        "containers": ["list_containers", "get_container_logs", "exec_in_container"],
        "compose_files": ["read_compose_file", "write_compose_file", "validate_compose_file", "get_services_from_compose"],
        "compose_ops": ["compose_up", "compose_down", "compose_ps", "compose_logs", "compose_pull", "compose_build"],
        "health": ["check_service_health", "wait_for_healthy"],
        "backup": ["backup_compose", "restore_compose"],
        "deployment": ["deploy_compose"],
        "utils": ["get_compose_status", "cleanup_old_images"]
    }
    
    function_short_help = {
        # Core
        "Compose Detection": "Automatically uses 'docker compose' (modern) or 'docker-compose' (legacy)",
        "get_docker_client": "Get Docker client with CLI fallback -> DockerClient|None",
        "run_docker_command": "Run docker command -> ExecResult(rc,stdout,stderr)",
        "run_compose_command": "Run docker-compose command -> ExecResult",
        
        # Images
        "pull_image": "Pull image with retry logic -> bool",
        "push_image": "Push image to registry -> bool", 
        "build_image": "Build image from context -> bool",
        "save_image_to_file": "Save image to tar file -> bool",
        "load_image_from_file": "Load image from tar file -> bool",
        
        # Containers
        "list_containers": "List containers with filters -> List[ContainerInfo]",
        "get_container_logs": "Get container logs -> Iterator[LogLine]",
        "exec_in_container": "Execute command in container -> ExecResult",
        "parse_log_line": "Parse log line -> LogLine",
        
        # Compose files
        "read_compose_file": "Read compose file -> Dict",
        "write_compose_file": "Write compose file -> None", 
        "validate_compose_file": "Validate compose file -> List[str] (errors)",
        "get_services_from_compose": "Get service names -> List[str]",
        "get_service_image": "Get image for service -> str|None",
        "find_env_files": "Find env files in compose -> List[str]",
        
        # Compose operations
        "compose_up": "Start compose services -> bool",
        "compose_down": "Stop compose services -> bool",
        "compose_restart": "Restart compose services -> bool",
        "compose_ps": "Get compose status -> List[ContainerInfo]",
        "compose_logs": "Get compose logs -> Iterator[LogLine]", 
        "compose_pull": "Pull compose images -> Dict[service->bool]",
        "compose_build": "Build compose images -> Dict[service->bool]",
        "parse_compose_log_line": "Parse compose log -> LogLine",
        
        # Health
        "check_service_health": "Check service health -> Dict[status,details]",
        "wait_for_healthy": "Wait for healthy services -> bool",
        
        # Backup
        "backup_compose": "Backup compose project -> str (backup_path)",
        "restore_compose": "Restore from backup -> bool",
        
        # Deployment
        "deploy_compose": "Deploy with rollback & env updates -> Dict[deployment_result]",
        
        # Utilities
        "get_compose_status": "Get comprehensive status -> Dict",
        "cleanup_old_images": "Cleanup old images -> List[removed_tags]",
        
        "docker_login": "Login to Docker registry -> bool",
        "run_container_shell": "Run interactive shell in container -> ExecResult",
        "container_commit": "Commit container to image -> bool", 
        "container_kill": "Kill container with signal -> bool",
        "container_remove": "Remove container -> bool",
        "container_restart": "Restart container -> bool",
        "image_tag": "Tag image with new name -> bool",
        "prune_system": "Prune unused Docker resources -> Dict",
        "create_network": "Create Docker network -> bool",
        "ensure_network": "Ensure network exists -> bool", 
        "create_volume": "Create Docker volume -> bool",
        "ensure_volume": "Ensure volume exists -> bool",
        "check_conflicts": "Check for deployment conflicts -> Dict",
        "resolve_conflicts": "Resolve deployment conflicts -> Dict",
        "compose_up_with_conflict_resolution": "Compose up with conflict resolution -> bool",
    }
    
    if function_name is None:
        # General help
        help_text = """DockerOps - Docker Compose Operations Library

Core Features:
• Docker SDK + CLI fallback • Deployment with rollback • Environment management
• Health monitoring • Backup/restore • Bulk operations

Quick Examples:
>>> compose_up("docker-compose.yml")
>>> deploy_compose("compose.yml", env_new_file=".env.new")
>>> wait_for_healthy("compose.yml", timeout=300)

Categories: core, images, containers, compose_files, compose_ops, health, backup, deployment, utils

Data: ExecResult(rc,stdout,stderr), LogLine(timestamp,service,message), ContainerInfo(id,name,image,status)

Use help('category') or help('function') for details"""
        return help_text
    
    if function_name in categories:
        # Category help
        funcs = categories[function_name]
        help_text = f"Category: {function_name}\n\n"
        for func in funcs:
            if func in function_short_help:
                help_text += f"• {func}: {function_short_help[func]}\n"
        return help_text
    
    if function_name == "categories":
        return "Available categories: " + ", ".join(categories.keys())
    
    if function_name in function_short_help:
        return f"{function_name}: {function_short_help[function_name]}"
    
    return f"Unknown: {function_name}. Use help() for categories and functions."