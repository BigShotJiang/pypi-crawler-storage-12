uv sync --frozen
source .venv/bin/activate
echo "source .venv/bin/activate" >> ~/.bashrc
