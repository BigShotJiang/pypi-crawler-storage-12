"""git-zap package."""

from .cli import zap

__all__ = ["zap"]
