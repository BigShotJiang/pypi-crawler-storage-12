## 24.6.0.20251116 (2025-11-16)

[pycountry] Add stubs for pycountry ([#15002](https://github.com/python/typeshed/pull/15002))

