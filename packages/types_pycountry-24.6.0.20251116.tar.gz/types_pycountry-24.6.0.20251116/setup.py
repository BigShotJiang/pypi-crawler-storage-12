
from setuptools import setup

setup(package_data={'pycountry-stubs': ['__init__.pyi', 'db.pyi', 'METADATA.toml', 'py.typed']})
