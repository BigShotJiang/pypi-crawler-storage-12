
# Mechanistic Explorer



# Install
```
pip install 
```

## Modeling requires COPASI
https://copasi.org/Download/

