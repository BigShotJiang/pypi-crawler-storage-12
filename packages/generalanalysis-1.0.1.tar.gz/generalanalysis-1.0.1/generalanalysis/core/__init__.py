"""Core functionality for the General Analysis SDK."""
