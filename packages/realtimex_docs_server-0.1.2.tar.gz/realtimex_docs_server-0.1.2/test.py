from realtimex_docs_server.server import list_documents

print(list_documents())
