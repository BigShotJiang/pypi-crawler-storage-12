"""Entry point for the RealTimeX documentation MCP server."""

from .server import main

__all__ = ["main"]
