"""Check the latest version at https://pypi.org/project/zvolv-sdk-corp/"""
__version__ = "0.0.63"
