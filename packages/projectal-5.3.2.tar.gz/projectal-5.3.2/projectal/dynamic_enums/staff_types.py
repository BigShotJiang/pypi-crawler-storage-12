from projectal.dynamic_enum import DynamicEnum


class StaffTypes(DynamicEnum):
    _name = "StaffTypeEnum"
