from projectal.dynamic_enum import DynamicEnum


class ComplexityLevels(DynamicEnum):
    _name = "GanttComplexityEnum"
