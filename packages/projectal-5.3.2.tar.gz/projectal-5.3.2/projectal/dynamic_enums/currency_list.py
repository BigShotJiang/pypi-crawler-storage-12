from projectal.dynamic_enum import DynamicEnum


class CurrencyList(DynamicEnum):
    _name = "CurrencyEnum"
