from projectal.dynamic_enum import DynamicEnum


class PriorityLevels(DynamicEnum):
    _name = "GanttPriorityEnum"
