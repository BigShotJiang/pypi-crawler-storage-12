from projectal.dynamic_enum import DynamicEnum


class SkillLevels(DynamicEnum):
    _name = "SkillLevelEnum"
