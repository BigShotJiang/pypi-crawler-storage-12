from projectal.dynamic_enum import DynamicEnum


class CompanyTypes(DynamicEnum):
    _name = "CompanyTypeEnum"
