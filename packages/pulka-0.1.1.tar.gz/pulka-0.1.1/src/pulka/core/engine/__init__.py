"""Core engine adapters."""

__all__ = []
