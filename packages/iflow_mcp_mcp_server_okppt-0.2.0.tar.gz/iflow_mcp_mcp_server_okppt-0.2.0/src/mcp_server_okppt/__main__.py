#!/usr/bin/env python3
"""
主模块入口点
"""
from mcp_server_okppt.cli import main

if __name__ == "__main__":
    main() 