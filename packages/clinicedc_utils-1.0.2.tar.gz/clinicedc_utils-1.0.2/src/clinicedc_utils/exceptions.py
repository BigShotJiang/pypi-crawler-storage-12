class ConversionNotHandled(Exception):  # noqa: N818
    pass


class EgfrCalculatorError(Exception):
    pass
