# wrapper for helm 

class Deployer():
    pass

class HelmDeployer(Deployer):
    pass

class KustomizeDeployer(Deployer):
    pass

class KubectlDeployer(Deployer):
    pass

class AnsibleDeployer(Deployer):
    pass

class KubernetesJobDeployer(Deployer):
    pass
