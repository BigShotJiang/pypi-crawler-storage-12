"""
init all response typing of payme provider
"""
from .webhook import * # noqa
