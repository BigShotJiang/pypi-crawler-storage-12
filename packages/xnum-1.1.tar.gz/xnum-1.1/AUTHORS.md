# Core Developers
----------
- Sepand Haghighi - Open Science Laboratory ([Github](https://github.com/sepandhaghighi)) **
- Sadra Sabouri - Open Science Laboratory ([Github](https://github.com/sadrasabouri))
- AmirHosein Rostami  - Open Science Laboratory ([Github](https://github.com/AHReccese))

** **Maintainer**

# Other Contributors
----------
- [ChatGPT](https://chat.openai.com/) ++

++ Graphic designer

