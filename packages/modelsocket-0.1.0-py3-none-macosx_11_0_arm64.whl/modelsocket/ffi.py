# auto-generated file
import _cffi_backend

ffi = _cffi_backend.FFI('ffi',
    _version = 0x2601,
    _types = b'',
)
