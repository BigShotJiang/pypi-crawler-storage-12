class WebSocketFetcher:
    pass
