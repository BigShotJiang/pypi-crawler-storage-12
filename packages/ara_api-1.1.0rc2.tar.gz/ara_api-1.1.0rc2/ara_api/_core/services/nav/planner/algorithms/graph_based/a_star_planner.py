from ara_api._utils import BasePlanner


class AStarPlanner(BasePlanner):
    def __init__(self):
        pass
