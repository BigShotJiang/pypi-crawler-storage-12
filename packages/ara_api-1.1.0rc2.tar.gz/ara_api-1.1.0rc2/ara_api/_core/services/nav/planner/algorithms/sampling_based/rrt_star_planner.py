from ara_api._utils import BasePlanner


class RRTStarPlanner(BasePlanner):
    def __init__(self):
        pass
