import asyncio
from typing import Dict, Set, Callable


class NavigationCommandProcessor: ...
