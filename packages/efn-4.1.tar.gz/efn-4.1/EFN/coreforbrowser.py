from BrowserCreator.core import fullgui, halfguiconsole, fullconsole

def fullgui(url, windowtitle):
    fullgui(url, windowtitle)

def halfguiconsole(urltext, windowtitle):
    halfguiconsole(urltext, windowtitle)

def fullconsole(urltext):
    fullconsole(urltext)
