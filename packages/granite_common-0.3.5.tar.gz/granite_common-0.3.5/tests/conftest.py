# SPDX-License-Identifier: Apache-2.0

__doc__ = """
Shared test fixtures and global pytest configuration hooks go here.
"""
