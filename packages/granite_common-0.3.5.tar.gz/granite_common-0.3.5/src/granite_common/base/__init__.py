# SPDX-License-Identifier: Apache-2.0

__doc__ = f"""
{__name__} data structures and functions that are shared across multiple releases of the
Granite models.
"""
