# Retry utilities reference

-----

::: dda.utils.retry.wait_for

::: dda.utils.retry.FailFastError
    options:
      members: []

::: dda.utils.retry.DelayedError
    options:
      members: []

::: dda.utils.retry.backoff_delays
