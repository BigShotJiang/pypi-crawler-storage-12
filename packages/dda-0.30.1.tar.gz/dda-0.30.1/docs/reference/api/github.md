# GitHub utilities reference

-----

::: dda.github.core.GitHub
    options:
      members:
      - http

::: dda.github.http.GitHubHTTPClientManager
    options:
      members: []
