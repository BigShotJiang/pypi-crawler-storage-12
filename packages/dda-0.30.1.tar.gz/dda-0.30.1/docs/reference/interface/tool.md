# Tool interface

-----

::: dda.tools.base.ExecutionContext

::: dda.tools.base.Tool
    options:
      show_labels: true
      show_if_no_docstring: false
