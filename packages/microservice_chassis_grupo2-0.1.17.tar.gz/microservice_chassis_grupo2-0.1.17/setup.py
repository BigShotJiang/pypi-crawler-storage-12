from setuptools import setup, find_packages

setup(
    name="microservice_chassis_grupo2",
    version="0.1.17",
    packages=find_packages(),
    install_requires=[],
    author="Grupo 2",
    author_email="",
    description="A reusable library for microservices",
    url="https://github.com/Grupo-MACC/Chassis",
)