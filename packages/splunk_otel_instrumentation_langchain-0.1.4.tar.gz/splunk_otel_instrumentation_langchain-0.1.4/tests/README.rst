Adding an .env file to set up the environment variables to run the tests.
The test is running by calling LLM APIs provided by Circuit.
There is an sample .env file in this directory.
