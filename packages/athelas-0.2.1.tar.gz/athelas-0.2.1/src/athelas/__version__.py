"""Version information for Athelas."""

__version__ = "0.2.1"
