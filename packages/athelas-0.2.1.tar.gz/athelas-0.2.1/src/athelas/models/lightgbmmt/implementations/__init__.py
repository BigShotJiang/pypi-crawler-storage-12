"""Model implementations."""

from .mtgbm_model import MtgbmModel

__all__ = ["MtgbmModel"]
