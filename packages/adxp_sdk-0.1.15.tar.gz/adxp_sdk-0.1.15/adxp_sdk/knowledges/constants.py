AX_ADVANCED_QUERY_URI = "/api/v1/knowledge/queries/advanced"
AX_SIMPLE_QUERY_URI = "/api/v1/knowledge/queries"
AX_ADVANCED_QUERY_WEB_URI = "/api/v1/knowledge/queries/test"
AX_SIMPLE_QUERY_WEB_URI = "/api/v1/knowledge/queries/test"


# INDEX_FIELDS = {
#     "contributor": "string",
#     "language": "string",
#     "document_release_date": "datetime",
# }
#
#
# FIELD_DESCRIPTIONS = {
#     "contributor": "문서를 집필한 사람",
#     "language": "언어",
#     "document_release_date": "문서 발행일",
# }
#
# FILTERABLE_FIELDS = ["contributor", "language", "document_release_date"]
# SORTABLE_FIELDS = ["document_release_date"]
