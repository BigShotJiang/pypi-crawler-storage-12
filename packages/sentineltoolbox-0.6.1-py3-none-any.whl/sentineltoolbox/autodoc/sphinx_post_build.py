from sentineltoolbox.sphinxenv import run_after_build

run_after_build()
