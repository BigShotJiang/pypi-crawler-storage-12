from .data_loader import load_data

__all__ = ['load_data']

__version__ = '0.0.2'