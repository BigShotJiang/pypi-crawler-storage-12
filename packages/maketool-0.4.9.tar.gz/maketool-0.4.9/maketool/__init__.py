from .build import main as build
from .clean import main as clean
from .compile import main as compile
from .run import main as run