
from importlib.metadata import version

VERSION = version("AgentService")
print(f"Current AgentService version: {VERSION}")
