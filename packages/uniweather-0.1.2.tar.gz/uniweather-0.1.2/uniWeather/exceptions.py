"""
Exception classes for uniWeather client
"""


class UniWeatherError(Exception):
    """Base exception for uniWeather client"""
    pass


class AuthenticationError(UniWeatherError):
    """Authentication failed"""
    pass


class NotFoundError(UniWeatherError):
    """Resource not found"""
    pass


class APIError(UniWeatherError):
    """Generic API error"""
    pass


class ConnectionError(UniWeatherError):
    """Failed to connect to API"""
    pass

