def test_protocols() -> None:
    """Just to make sure they're imported somewhere"""
    from anywidget import _protocols  # noqa: F401
