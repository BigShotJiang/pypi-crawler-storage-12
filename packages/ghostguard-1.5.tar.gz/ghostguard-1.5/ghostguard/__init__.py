# Ghost Package
__version__ = "1.5"
