# Utilities subpackage for Ghost CLI
# Contains helper functions like animated banner and menu rendering
