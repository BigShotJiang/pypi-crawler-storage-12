class ConsoleEmail:
    EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
