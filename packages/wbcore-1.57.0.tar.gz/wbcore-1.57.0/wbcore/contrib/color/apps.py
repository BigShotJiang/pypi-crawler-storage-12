from django.apps import AppConfig


class ColorAppConfig(AppConfig):
    name = "wbcore.contrib.color"
