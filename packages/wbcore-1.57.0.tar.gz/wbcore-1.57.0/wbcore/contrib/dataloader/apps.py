from django.apps import AppConfig


class WBDataAppConfig(AppConfig):
    name = "wbcore.contrib.dataloader"
