docs = [
    {
        "path": "../docs/releases",
    },
    {
        "path": "../docs/releases/one.md",
    },
]
