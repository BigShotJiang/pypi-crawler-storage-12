from dataflow.utils.log import Logger

_logger = Logger('dataflowx.context.stream')

_logger.DEBUG('加载Stream模块')