"""
{project_name} - FastAPI ML/AI Application
"""

__version__ = "0.1.0"
