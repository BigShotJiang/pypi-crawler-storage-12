"""
Test suite for {project_name}
"""
