class NoSuchTopicException(Exception):
    pass


class SignatureException(Exception):
    pass
