"""Constants for presence sensor devices."""

BATTERY_LEVEL_MAP = {
    0: "<10%",
    1: "10-19%",
    2: "20-59%",
    3: ">=60%",
}
