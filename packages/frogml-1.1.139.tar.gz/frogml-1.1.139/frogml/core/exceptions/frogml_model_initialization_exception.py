class FrogmlModelInitializationException(RuntimeError):
    """
    Signals an error occurred when trying to initialize a frogml model at build time
    """
