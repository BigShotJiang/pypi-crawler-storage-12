"""Probabilistic solvers for differential equations."""

from probdiffeq._version import version as __version__  # noqa: F401
