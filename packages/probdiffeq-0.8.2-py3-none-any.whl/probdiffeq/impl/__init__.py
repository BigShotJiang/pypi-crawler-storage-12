"""State-space model implementations."""
