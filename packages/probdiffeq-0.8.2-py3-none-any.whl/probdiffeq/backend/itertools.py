"""Itertools."""

import itertools


def accumulate(iterable, /):
    return itertools.accumulate(iterable)
