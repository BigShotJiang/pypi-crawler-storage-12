"""Test fixtures for MCP Docker."""
