from typing import TypedDict


class TimeStamp(TypedDict):
    seconds: int
    nanos: int
