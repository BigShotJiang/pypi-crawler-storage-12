"""FastAPI routers for the marketplace example."""
