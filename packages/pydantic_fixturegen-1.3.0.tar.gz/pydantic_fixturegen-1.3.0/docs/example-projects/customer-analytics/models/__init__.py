"""Customer analytics example models package."""
