"""sh-ocr-client: A Python client library for OCR service."""

from .client import process_ocr

__version__ = "0.1.0"
__all__ = ["process_ocr"]
