# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------

VERSION = "11.6.0"  # type: str

SDK_MONIKER = "search-documents/{}".format(VERSION)  # type: str
