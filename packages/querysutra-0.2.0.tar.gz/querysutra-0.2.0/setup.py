from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="QuerySUTRA",
    version="0.2.0",
    author="Aditya Batta",
    author_email="b05aditya@gmail.com",
    description="SUTRA: Structured-Unstructured-Text-Retrieval-Architecture | AI-powered entity extraction, Natural Language to SQL, MySQL/PostgreSQL export",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/adityabatta/QuerySUTRA",
    packages=find_packages(exclude=["tests", "tests.*", "venv", "data", "__pycache__"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Database",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Text Processing :: Linguistic",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords="natural-language sql database query nlp ai openai mysql postgresql pdf docx entity-extraction text-retrieval embeddings semantic-search",
    python_requires=">=3.8",
    install_requires=[
        "openai>=1.12.0",
        "pandas>=2.0.0",
        "numpy>=1.24.0",
        "plotly>=5.0.0",
        "matplotlib>=3.7.0",
        "PyPDF2>=3.0.0",
        "python-docx>=1.0.0",
        "openpyxl>=3.1.0",
        "sqlalchemy>=2.0.0",
        "sentence-transformers>=2.0.0",
    ],
    extras_require={
        "mysql": ["mysql-connector-python>=8.0.0"],
        "postgres": ["psycopg2-binary>=2.9.0"],
        "all": ["mysql-connector-python>=8.0.0", "psycopg2-binary>=2.9.0"],
    },
    project_urls={
        "Bug Reports": "https://github.com/adityabatta/QuerySUTRA/issues",
        "Source": "https://github.com/adityabatta/QuerySUTRA",
    },
)
