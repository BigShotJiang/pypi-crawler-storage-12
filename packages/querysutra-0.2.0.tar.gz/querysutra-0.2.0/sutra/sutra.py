"""
QuerySUTRA v0.2.0 - INTELLIGENT VERSION
SUTRA: Structured-Unstructured-Text-Retrieval-Architecture

Major Update:
- Smart entity extraction from PDF/DOCX/TXT
- Automatic schema generation with relationships
- Semantic embeddings for better query matching
- Multi-table creation from unstructured data

Author: Aditya Batta
License: MIT
Version: 0.2.0
"""

__version__ = "0.2.0"
__author__ = "Aditya Batta"
__title__ = "QuerySUTRA: Structured-Unstructured-Text-Retrieval-Architecture"
__all__ = ["SUTRA", "QueryResult", "quick_start"]

import os
import sqlite3
import pandas as pd
import numpy as np
from typing import Optional, Union, Dict, Any, List, Tuple
from pathlib import Path
import json
import hashlib
import warnings
import shutil
import datetime
import re
from io import StringIO
warnings.filterwarnings('ignore')

try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

try:
    import plotly.express as px
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

try:
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

try:
    import PyPDF2
    HAS_PYPDF2 = True
except ImportError:
    HAS_PYPDF2 = False

try:
    import docx
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False

try:
    from sentence_transformers import SentenceTransformer
    HAS_EMBEDDINGS = True
except ImportError:
    HAS_EMBEDDINGS = False


class SUTRA:
    """
    SUTRA: Structured-Unstructured-Text-Retrieval-Architecture
    
    Intelligent system for:
    - Entity extraction from unstructured documents
    - Automatic schema generation
    - Semantic query matching with embeddings
    - Multi-table relationship mapping
    """
    
    def __init__(self, api_key: Optional[str] = None, db: str = "sutra.db"):
        print("🚀 Initializing QuerySUTRA v0.2.0 - INTELLIGENT MODE")
        print("   SUTRA: Structured-Unstructured-Text-Retrieval-Architecture")
        
        if api_key:
            os.environ["OPENAI_API_KEY"] = api_key
        
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.client = OpenAI(api_key=self.api_key) if self.api_key and HAS_OPENAI else None
        
        self.db_path = db
        self.conn = sqlite3.connect(db, check_same_thread=False)
        self.cursor = self.conn.cursor()
        
        self.current_table = None
        self.schema = {}
        self.cache = {}
        self.embeddings_model = None
        self.column_embeddings = {}
        
        # Initialize embeddings if available
        if HAS_EMBEDDINGS:
            try:
                print("   🧠 Loading embeddings model...")
                self.embeddings_model = SentenceTransformer('all-MiniLM-L6-v2')
                print("   ✅ Embeddings ready for semantic search")
            except:
                print("   ⚠️  Embeddings model failed to load")
        
        print(f"✅ Ready! Database: {db}")
        if not self.api_key:
            print("⚠️  No API key - use .sql() for direct queries only")
    
    # ========================================================================
    # INTELLIGENT DATA UPLOAD WITH ENTITY EXTRACTION
    # ========================================================================
    
    def upload(self, data: Union[str, pd.DataFrame], name: Optional[str] = None, 
               smart_parse: bool = True) -> 'SUTRA':
        """
        Upload data with intelligent entity extraction.
        
        Args:
            data: File path or DataFrame
            name: Table name (auto-generated if None)
            smart_parse: Use AI to extract entities (True) or simple parse (False)
        
        Returns:
            self
        """
        print(f"\n📤 Uploading data...")
        
        if isinstance(data, pd.DataFrame):
            name = name or "data"
            self._store_dataframe(data, name)
            return self
        
        path = Path(data)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {data}")
        
        name = name or path.stem.replace(" ", "_").replace("-", "_")
        ext = path.suffix.lower()
        
        print(f"   📄 File: {path.name}")
        
        # Load based on format
        if ext == ".csv":
            df = pd.read_csv(path)
            self._store_dataframe(df, name)
        
        elif ext in [".xlsx", ".xls"]:
            df = pd.read_excel(path)
            self._store_dataframe(df, name)
        
        elif ext == ".json":
            df = pd.read_json(path)
            self._store_dataframe(df, name)
        
        elif ext == ".sql":
            with open(path) as f:
                self.cursor.executescript(f.read())
            self.conn.commit()
            self._refresh_schema()
            print(f"✅ SQL executed!")
        
        elif ext == ".pdf":
            if smart_parse and self.client:
                self._smart_upload_pdf(path, name)
            else:
                df = self._load_pdf_simple(path)
                self._store_dataframe(df, name)
        
        elif ext == ".docx":
            if smart_parse and self.client:
                self._smart_upload_docx(path, name)
            else:
                df = self._load_docx_simple(path)
                self._store_dataframe(df, name)
        
        elif ext == ".txt":
            if smart_parse and self.client:
                self._smart_upload_txt(path, name)
            else:
                df = self._load_txt_simple(path)
                self._store_dataframe(df, name)
        
        else:
            raise ValueError(f"Unsupported format: {ext}")
        
        return self
    
    # ========================================================================
    # SMART PARSING WITH AI
    # ========================================================================
    
    def _smart_upload_pdf(self, path: Path, base_name: str):
        """Intelligently parse PDF with entity extraction."""
        if not HAS_PYPDF2:
            raise ImportError("PyPDF2 not installed. Run: pip install PyPDF2")
        
        print("   📑 Extracting text from PDF...")
        
        # Extract text
        with open(path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            text = ""
            for page_num, page in enumerate(pdf_reader.pages, 1):
                text += page.extract_text() + "\n"
                print(f"      Extracted page {page_num}/{len(pdf_reader.pages)}")
        
        print("   🧠 AI: Analyzing content and extracting entities...")
        
        # Use AI to analyze and structure the data
        structured_data = self._extract_entities_with_ai(text, base_name)
        
        if structured_data:
            print(f"   ✅ Created {len(structured_data)} structured tables")
            for table_name, df in structured_data.items():
                self._store_dataframe(df, table_name)
        else:
            # Fallback to simple parsing
            print("   ⚠️  AI extraction failed, using simple parse")
            df = self._parse_text_to_dataframe(text)
            self._store_dataframe(df, base_name)
    
    def _smart_upload_docx(self, path: Path, base_name: str):
        """Intelligently parse DOCX with entity extraction."""
        if not HAS_DOCX:
            raise ImportError("python-docx not installed. Run: pip install python-docx")
        
        print("   📄 Extracting text from DOCX...")
        
        doc = docx.Document(path)
        
        # Check for tables first
        if doc.tables:
            print(f"   📊 Found {len(doc.tables)} table(s) in document")
            for i, table in enumerate(doc.tables):
                data = [[cell.text.strip() for cell in row.cells] for row in table.rows]
                if data and len(data) > 1:
                    df = pd.DataFrame(data[1:], columns=data[0])
                    table_name = f"{base_name}_table_{i+1}" if len(doc.tables) > 1 else base_name
                    self._store_dataframe(df, table_name)
            return
        
        # Extract text and use AI
        text = "\n".join([para.text for para in doc.paragraphs])
        
        print("   🧠 AI: Analyzing content and extracting entities...")
        structured_data = self._extract_entities_with_ai(text, base_name)
        
        if structured_data:
            print(f"   ✅ Created {len(structured_data)} structured tables")
            for table_name, df in structured_data.items():
                self._store_dataframe(df, table_name)
        else:
            df = self._parse_text_to_dataframe(text)
            self._store_dataframe(df, base_name)
    
    def _smart_upload_txt(self, path: Path, base_name: str):
        """Intelligently parse TXT with entity extraction."""
        print("   📝 Reading TXT file...")
        
        with open(path, 'r', encoding='utf-8') as file:
            text = file.read()
        
        print("   🧠 AI: Analyzing content and extracting entities...")
        structured_data = self._extract_entities_with_ai(text, base_name)
        
        if structured_data:
            print(f"   ✅ Created {len(structured_data)} structured tables")
            for table_name, df in structured_data.items():
                self._store_dataframe(df, table_name)
        else:
            df = self._parse_text_to_dataframe(text)
            self._store_dataframe(df, base_name)
    
    def _extract_entities_with_ai(self, text: str, base_name: str) -> Dict[str, pd.DataFrame]:
        """
        Use OpenAI to intelligently extract entities and create structured tables.
        """
        if not self.client:
            return None
        
        try:
            # Ask AI to analyze the text and suggest schema
            analysis_prompt = f"""Analyze this text and extract structured data.

Text:
{text[:3000]}  # First 3000 chars for analysis

Task: Identify entities and suggest database tables.

Return a JSON with this structure:
{{
    "tables": [
        {{
            "name": "people",
            "description": "Information about people",
            "columns": ["id", "name", "address", "city", "email", "phone"],
            "extraction_pattern": "regex or description of how to extract"
        }},
        ...
    ]
}}

Focus on: people, contacts, addresses, events, organizations, dates, phone numbers, emails.
Return ONLY valid JSON, no explanations."""

            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a data structuring expert. Extract entities and suggest database schemas. Return only JSON."},
                    {"role": "user", "content": analysis_prompt}
                ],
                temperature=0
            )
            
            schema_suggestion = response.choices[0].message.content.strip()
            schema_suggestion = schema_suggestion.replace("```json", "").replace("```", "").strip()
            schema_data = json.loads(schema_suggestion)
            
            print(f"   🎯 AI identified {len(schema_data.get('tables', []))} entity types")
            
            # Now extract actual data using AI
            extracted_tables = {}
            
            for table_info in schema_data.get('tables', []):
                table_name = f"{base_name}_{table_info['name']}"
                print(f"   📊 Extracting {table_info['name']}...")
                
                # Use AI to extract entities
                extraction_prompt = f"""Extract all {table_info['name']} from this text.

Text:
{text}

Columns: {', '.join(table_info['columns'])}

Return a JSON array of objects with these exact column names.
Example: [{{"id": 1, "name": "John", "email": "john@email.com"}}, ...]

Return ONLY valid JSON array, no explanations."""

                extract_response = self.client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[
                        {"role": "system", "content": "You are a data extraction expert. Extract structured data from text. Return only JSON."},
                        {"role": "user", "content": extraction_prompt}
                    ],
                    temperature=0
                )
                
                extracted_json = extract_response.choices[0].message.content.strip()
                extracted_json = extracted_json.replace("```json", "").replace("```", "").strip()
                
                try:
                    records = json.loads(extracted_json)
                    if records and isinstance(records, list):
                        df = pd.DataFrame(records)
                        extracted_tables[table_name] = df
                        print(f"      ✅ Extracted {len(df)} records")
                except:
                    print(f"      ⚠️  Failed to extract {table_info['name']}")
            
            return extracted_tables if extracted_tables else None
        
        except Exception as e:
            print(f"   ⚠️  AI extraction error: {e}")
            return None
    
    # ========================================================================
    # SIMPLE PARSING (FALLBACK)
    # ========================================================================
    
    def _load_pdf_simple(self, path: Path) -> pd.DataFrame:
        """Simple PDF text extraction (fallback)."""
        if not HAS_PYPDF2:
            raise ImportError("PyPDF2 not installed. Run: pip install PyPDF2")
        
        with open(path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            text = "".join([page.extract_text() + "\n" for page in pdf_reader.pages])
        
        return self._parse_text_to_dataframe(text)
    
    def _load_docx_simple(self, path: Path) -> pd.DataFrame:
        """Simple DOCX extraction (fallback)."""
        if not HAS_DOCX:
            raise ImportError("python-docx not installed. Run: pip install python-docx")
        
        doc = docx.Document(path)
        
        if doc.tables:
            table = doc.tables[0]
            data = [[cell.text.strip() for cell in row.cells] for row in table.rows]
            if data:
                return pd.DataFrame(data[1:], columns=data[0])
        
        text = "\n".join([para.text for para in doc.paragraphs])
        return self._parse_text_to_dataframe(text)
    
    def _load_txt_simple(self, path: Path) -> pd.DataFrame:
        """Simple TXT extraction (fallback)."""
        with open(path, 'r', encoding='utf-8') as file:
            text = file.read()
        return self._parse_text_to_dataframe(text)
    
    def _parse_text_to_dataframe(self, text: str) -> pd.DataFrame:
        """Parse text into DataFrame."""
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        
        if not lines:
            return pd.DataFrame({'content': ['No content found']})
        
        sample = lines[:min(10, len(lines))]
        
        for delimiter in ['\t', ',', '|', ';']:
            if all(delimiter in line for line in sample):
                try:
                    df = pd.read_csv(StringIO('\n'.join(lines)), sep=delimiter)
                    if len(df.columns) > 1:
                        return df
                except:
                    continue
        
        return pd.DataFrame({
            'line_number': range(1, len(lines) + 1),
            'content': lines
        })
    
    def _store_dataframe(self, df: pd.DataFrame, name: str):
        """Store DataFrame in database."""
        df.columns = [str(c).strip().replace(" ", "_").replace("-", "_") for c in df.columns]
        df.to_sql(name, self.conn, if_exists='replace', index=False)
        self.current_table = name
        self._refresh_schema()
        
        # Generate embeddings for columns
        if self.embeddings_model:
            self._generate_column_embeddings(name)
        
        print(f"✅ Uploaded to table: {name}")
        print(f"   📊 {len(df)} rows × {len(df.columns)} columns")
        print(f"   🔤 Columns: {', '.join(df.columns[:10].tolist())}{' ...' if len(df.columns) > 10 else ''}")
    
    def _generate_column_embeddings(self, table_name: str):
        """Generate embeddings for column names for semantic search."""
        try:
            columns = list(self.schema[table_name].keys())
            # Create descriptive text for each column
            col_descriptions = [f"{col} {self.schema[table_name][col]}" for col in columns]
            embeddings = self.embeddings_model.encode(col_descriptions)
            self.column_embeddings[table_name] = {
                'columns': columns,
                'embeddings': embeddings
            }
        except:
            pass
    
    # ========================================================================
    # VIEW DATABASE
    # ========================================================================
    
    def tables(self) -> list:
        """List all tables."""
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        return [r[0] for r in self.cursor.fetchall()]
    
    def schema(self, table: Optional[str] = None):
        """Show database schema."""
        if not self.schema:
            self._refresh_schema()
        
        print("\n" + "="*70)
        print("📋 DATABASE SCHEMA")
        print("="*70)
        
        tables_to_show = [table] if table else self.schema.keys()
        
        for tbl in tables_to_show:
            if tbl in self.schema:
                # Get row count
                count = pd.read_sql_query(f"SELECT COUNT(*) FROM {tbl}", self.conn).iloc[0, 0]
                print(f"\n📊 Table: {tbl}")
                print(f"   Records: {count}")
                print(f"   Columns:")
                for col, dtype in self.schema[tbl].items():
                    print(f"     - {col:<25} ({dtype})")
        
        print("="*70)
        return self
    
    def peek(self, table: Optional[str] = None, n: int = 5) -> pd.DataFrame:
        """View sample data."""
        tbl = table or self.current_table
        if not tbl:
            print("❌ No table specified")
            return pd.DataFrame()
        
        df = pd.read_sql_query(f"SELECT * FROM {tbl} LIMIT {n}", self.conn)
        print(f"\n📊 Sample from '{tbl}' ({n} rows):")
        print(df.to_string(index=False))
        return df
    
    def info(self):
        """Show complete database information."""
        print("\n" + "="*80)
        print("📊 DATABASE INFORMATION")
        print("="*80)
        
        all_tables = self.tables()
        print(f"\n📁 Tables ({len(all_tables)}):")
        
        for i, tbl in enumerate(all_tables, 1):
            count = pd.read_sql_query(f"SELECT COUNT(*) FROM {tbl}", self.conn).iloc[0, 0]
            col_count = len(self.schema.get(tbl, {}))
            marker = "👉" if tbl == self.current_table else "  "
            print(f"{marker} {i}. {tbl:<40} ({count} rows, {col_count} columns)")
        
        print("\n" + "="*80)
        return self
    
    # ========================================================================
    # QUERY METHODS
    # ========================================================================
    
    def sql(self, query: str, viz: bool = False) -> 'QueryResult':
        """Execute SQL directly (no API cost)."""
        print(f"\n⚡ Executing SQL...")
        
        try:
            df = pd.read_sql_query(query, self.conn)
            print(f"✅ Success! {len(df)} rows returned")
            
            fig = None
            if viz and not df.empty:
                fig = self._visualize(df, "SQL Query Result")
            
            return QueryResult(True, query, df, fig)
        except Exception as e:
            print(f"❌ Error: {e}")
            return QueryResult(False, query, pd.DataFrame(), None, str(e))
    
    def ask(self, question: str, viz: bool = False, table: Optional[str] = None) -> 'QueryResult':
        """Ask question with improved semantic matching."""
        if not self.client:
            print("❌ No API key configured")
            return QueryResult(False, "", pd.DataFrame(), None, "No API key")
        
        print(f"\n🔍 Question: {question}")
        
        tbl = table or self.current_table
        if not tbl:
            # Try to find best table using embeddings
            tbl = self._find_best_table(question)
            if not tbl:
                print("❌ No table specified. Upload data first!")
                return QueryResult(False, "", pd.DataFrame(), None, "No table")
        
        cache_key = hashlib.md5(f"{question}:{tbl}".encode()).hexdigest()
        if cache_key in self.cache:
            sql_query = self.cache[cache_key]
            print("   💾 From cache")
        else:
            sql_query = self._generate_sql(question, tbl)
            self.cache[cache_key] = sql_query
        
        print(f"   📝 SQL: {sql_query}")
        
        try:
            df = pd.read_sql_query(sql_query, self.conn)
            print(f"✅ Success! {len(df)} rows")
            
            fig = None
            if viz and not df.empty:
                fig = self._visualize(df, question)
            
            return QueryResult(True, sql_query, df, fig)
        except Exception as e:
            print(f"❌ Error: {e}")
            return QueryResult(False, sql_query, pd.DataFrame(), None, str(e))
    
    def _find_best_table(self, question: str) -> Optional[str]:
        """Find best matching table using embeddings."""
        if not self.embeddings_model or not self.schema:
            tables = list(self.schema.keys())
            return tables[0] if tables else None
        
        try:
            question_emb = self.embeddings_model.encode([question])[0]
            
            best_table = None
            best_score = -1
            
            for table_name, emb_data in self.column_embeddings.items():
                # Calculate similarity
                from numpy.linalg import norm
                similarities = [
                    np.dot(question_emb, col_emb) / (norm(question_emb) * norm(col_emb))
                    for col_emb in emb_data['embeddings']
                ]
                max_sim = max(similarities) if similarities else 0
                
                if max_sim > best_score:
                    best_score = max_sim
                    best_table = table_name
            
            if best_table:
                print(f"   🎯 Auto-selected table: {best_table} (relevance: {best_score:.2f})")
                return best_table
        except:
            pass
        
        return list(self.schema.keys())[0] if self.schema else None
    
    def interactive(self, question: str) -> 'QueryResult':
        """Ask question and prompt user for visualization."""
        print(f"\n🔍 Question: {question}")
        choice = input("💡 Do you want visualization? (yes/no): ").strip().lower()
        viz = choice in ['yes', 'y', 'yeah', 'yep', 'sure']
        return self.ask(question, viz=viz)
    
    # ========================================================================
    # DATABASE EXPORT & MIGRATION
    # ========================================================================
    
    def export_db(self, path: str, format: str = "sqlite"):
        """Export entire database."""
        print(f"\n💾 Exporting database to {format}...")
        
        format = format.lower()
        
        if format == "sqlite":
            shutil.copy2(self.db_path, path)
            print(f"✅ Database copied to {path}")
        
        elif format == "sql":
            with open(path, 'w', encoding='utf-8') as f:
                for line in self.conn.iterdump():
                    f.write(f'{line}\n')
            print(f"✅ SQL dump saved to {path}")
        
        elif format == "json":
            data = {}
            for table in self.tables():
                df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
                data[table] = df.to_dict(orient='records')
            
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, default=str)
            print(f"✅ JSON export saved to {path}")
        
        elif format == "excel":
            with pd.ExcelWriter(path, engine='openpyxl') as writer:
                for table in self.tables():
                    df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
                    df.to_excel(writer, sheet_name=table[:31], index=False)
            print(f"✅ Excel export saved to {path}")
        
        else:
            raise ValueError(f"Unsupported format: {format}")
        
        return self
    
    def save_to_mysql(self, host: str, user: str, password: str, database: str,
                      port: int = 3306, tables: Optional[List[str]] = None):
        """Save tables to MySQL database (local or cloud)."""
        try:
            from sqlalchemy import create_engine
        except ImportError:
            raise ImportError("Run: pip install 'QuerySUTRA[mysql]' or pip install sqlalchemy mysql-connector-python")
        
        print(f"\n🔄 Connecting to MySQL at {host}:{port}...")
        
        connection_string = f"mysql+mysqlconnector://{user}:{password}@{host}:{port}/{database}"
        engine = create_engine(connection_string)
        
        tables_to_export = tables or self.tables()
        
        print(f"📤 Exporting {len(tables_to_export)} tables to MySQL...")
        
        for table in tables_to_export:
            print(f"   Exporting {table}...", end=" ")
            df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
            df.to_sql(table, engine, if_exists='replace', index=False)
            print(f"✅ ({len(df)} rows)")
        
        print(f"✅ All tables exported to MySQL database '{database}'")
        return self
    
    def save_to_postgres(self, host: str, user: str, password: str, database: str,
                         port: int = 5432, tables: Optional[List[str]] = None):
        """Save tables to PostgreSQL database (local or cloud)."""
        try:
            from sqlalchemy import create_engine
        except ImportError:
            raise ImportError("Run: pip install 'QuerySUTRA[postgres]' or pip install sqlalchemy psycopg2-binary")
        
        print(f"\n🔄 Connecting to PostgreSQL at {host}:{port}...")
        
        connection_string = f"postgresql://{user}:{password}@{host}:{port}/{database}"
        engine = create_engine(connection_string)
        
        tables_to_export = tables or self.tables()
        
        print(f"📤 Exporting {len(tables_to_export)} tables to PostgreSQL...")
        
        for table in tables_to_export:
            print(f"   Exporting {table}...", end=" ")
            df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
            df.to_sql(table, engine, if_exists='replace', index=False)
            print(f"✅ ({len(df)} rows)")
        
        print(f"✅ All tables exported to PostgreSQL database '{database}'")
        return self
    
    def save_schema(self, path: str, format: str = "sql"):
        """Export only database schema."""
        print(f"\n📋 Exporting schema to {format}...")
        
        if not self.schema:
            self._refresh_schema()
        
        format = format.lower()
        
        if format == "sql":
            with open(path, 'w', encoding='utf-8') as f:
                for table in self.tables():
                    self.cursor.execute(f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table}'")
                    result = self.cursor.fetchone()
                    if result:
                        create_stmt = result[0]
                        f.write(f"{create_stmt};\n\n")
            print(f"✅ SQL schema saved to {path}")
        
        elif format == "json":
            schema_data = {}
            for table, columns in self.schema.items():
                count = pd.read_sql_query(f"SELECT COUNT(*) FROM {table}", self.conn).iloc[0, 0]
                schema_data[table] = {
                    "columns": columns,
                    "row_count": count
                }
            
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(schema_data, f, indent=2)
            print(f"✅ JSON schema saved to {path}")
        
        elif format == "markdown":
            with open(path, 'w', encoding='utf-8') as f:
                f.write("# Database Schema\n\n")
                
                for table in self.schema:
                    count = pd.read_sql_query(f"SELECT COUNT(*) FROM {table}", self.conn).iloc[0, 0]
                    f.write(f"## Table: `{table}`\n\n")
                    f.write(f"**Rows:** {count}\n\n")
                    f.write("| Column | Type |\n|--------|------|\n")
                    
                    for col, dtype in self.schema[table].items():
                        f.write(f"| {col} | {dtype} |\n")
                    f.write("\n")
            
            print(f"✅ Markdown schema saved to {path}")
        else:
            raise ValueError(f"Unsupported format: {format}")
        
        return self
    
    def backup(self, backup_path: str = None):
        """Create complete backup."""
        if backup_path:
            backup_dir = Path(backup_path)
            backup_dir.mkdir(parents=True, exist_ok=True)
        else:
            backup_dir = Path(".")
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        print(f"\n💾 Creating backup...")
        
        db_backup = backup_dir / f"sutra_backup_{timestamp}.db"
        self.export_db(str(db_backup), format="sqlite")
        
        schema_backup = backup_dir / f"sutra_schema_{timestamp}.sql"
        self.save_schema(str(schema_backup), format="sql")
        
        json_backup = backup_dir / f"sutra_data_{timestamp}.json"
        self.export_db(str(json_backup), format="json")
        
        print(f"\n✅ Backup complete!")
        print(f"   📁 Database: {db_backup}")
        print(f"   📋 Schema: {schema_backup}")
        print(f"   📊 Data: {json_backup}")
        
        return self
    
    # ========================================================================
    # UTILITIES
    # ========================================================================
    
    def export(self, data: pd.DataFrame, path: str, format: str = "csv"):
        """Export results to file."""
        fmt = format.lower()
        if fmt == "csv":
            data.to_csv(path, index=False)
        elif fmt in ["excel", "xlsx"]:
            data.to_excel(path, index=False)
        elif fmt == "json":
            data.to_json(path, orient="records", indent=2)
        else:
            raise ValueError(f"Unknown format: {format}")
        
        print(f"✅ Exported to {path}")
        return self
    
    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            print("✅ SUTRA closed")
    
    def _refresh_schema(self):
        """Refresh schema information."""
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [r[0] for r in self.cursor.fetchall()]
        
        self.schema = {}
        for tbl in tables:
            self.cursor.execute(f"PRAGMA table_info({tbl})")
            self.schema[tbl] = {r[1]: r[2] for r in self.cursor.fetchall()}
    
    def _generate_sql(self, question: str, table: str) -> str:
        """Generate SQL using OpenAI with better context."""
        schema_info = self.schema.get(table, {})
        
        # Get sample data for better context
        sample_df = pd.read_sql_query(f"SELECT * FROM {table} LIMIT 3", self.conn)
        sample_text = sample_df.to_string(index=False)
        
        schema_str = ", ".join([f"{col} ({dtype})" for col, dtype in schema_info.items()])
        
        prompt = f"""Convert this question to SQL.

Database: SQLite
Table: {table}
Columns: {schema_str}

Sample Data:
{sample_text}

Question: {question}

Return ONLY the SQL query. No explanations, no markdown. Use SQLite syntax."""
        
        response = self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a SQL expert. Generate precise SQL queries. Return only SQL code, no explanations."},
                {"role": "user", "content": prompt}
            ],
            temperature=0
        )
        
        sql = response.choices[0].message.content.strip()
        return sql.replace("```sql", "").replace("```", "").strip()
    
    def _visualize(self, df: pd.DataFrame, title: str):
        """Create visualization."""
        if not HAS_PLOTLY and not HAS_MATPLOTLIB:
            print("⚠️  Install plotly or matplotlib for visualizations")
            return None
        
        print("📊 Creating visualization...")
        
        if HAS_PLOTLY:
            return self._plotly_viz(df, title)
        else:
            return self._matplotlib_viz(df, title)
    
    def _plotly_viz(self, df: pd.DataFrame, title: str):
        """Create Plotly chart."""
        try:
            numeric = df.select_dtypes(include=[np.number]).columns.tolist()
            categorical = df.select_dtypes(include=['object']).columns.tolist()
            
            if len(df) == 1 or not numeric:
                fig = go.Figure(data=[go.Table(
                    header=dict(values=list(df.columns)),
                    cells=dict(values=[df[c] for c in df.columns])
                )])
            elif categorical and numeric:
                fig = px.bar(df, x=categorical[0], y=numeric[0], title=title)
            elif len(numeric) >= 2:
                fig = px.line(df, y=numeric[0], title=title)
            else:
                fig = px.bar(df, y=df.columns[0], title=title)
            
            fig.show()
            print("✅ Chart displayed")
            return fig
        except Exception as e:
            print(f"⚠️  Viz error: {e}")
            return None
    
    def _matplotlib_viz(self, df: pd.DataFrame, title: str):
        """Create Matplotlib chart."""
        try:
            plt.figure(figsize=(10, 6))
            numeric = df.select_dtypes(include=[np.number]).columns
            
            if len(numeric) > 0:
                df[numeric[0]].plot(kind='bar')
            else:
                df.iloc[:, 0].value_counts().plot(kind='bar')
            
            plt.title(title)
            plt.tight_layout()
            plt.show()
            print("✅ Chart displayed")
            return plt.gcf()
        except Exception as e:
            print(f"⚠️  Viz error: {e}")
            return None
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()
    
    def __repr__(self):
        return f"SUTRA(tables={len(self.schema)}, current='{self.current_table}')"


class QueryResult:
    """Result from a query."""
    
    def __init__(self, success: bool, sql: str, data: pd.DataFrame, viz, error: str = None):
        self.success = success
        self.sql = sql
        self.data = data
        self.viz = viz
        self.error = error
    
    def __repr__(self):
        if self.success:
            return f"QueryResult(rows={len(self.data)}, cols={len(self.data.columns)})"
        return f"QueryResult(error='{self.error}')"
    
    def show(self):
        """Display the data."""
        if self.success:
            print(self.data)
        else:
            print(f"Error: {self.error}")
        return self


def quick_start(api_key: str, data_path: str, question: str, viz: bool = False):
    """One-liner for quick queries."""
    with SUTRA(api_key=api_key) as sutra:
        sutra.upload(data_path)
        return sutra.ask(question, viz=viz)


if __name__ == "__main__":
    print("""
╔══════════════════════════════════════════════════════════════╗
║                   QuerySUTRA v0.2.0                          ║
║   Structured-Unstructured-Text-Retrieval-Architecture        ║
║                  INTELLIGENT MODE                            ║
╚══════════════════════════════════════════════════════════════╝

NEW in v0.2.0:
✨ Smart entity extraction from PDF/DOCX/TXT
✨ Automatic multi-table schema generation
✨ Semantic embeddings for better relevancy
✨ AI-powered data structuring

Installation:
    pip install QuerySUTRA
    
Quick Start:
    from sutra import SUTRA
    
    sutra = SUTRA(api_key="your-key")
    sutra.upload("document.pdf")  # AI extracts entities!
    sutra.info()  # See all created tables
    result = sutra.ask("Show all people from New York", viz=True)
    
    # Export to cloud
    sutra.save_to_mysql("host", "user", "pass", "db")
    sutra.save_to_postgres("host", "user", "pass", "db")

Supported: CSV, Excel, JSON, SQL, PDF, DOCX, TXT, DataFrame
Export to: SQLite, MySQL, PostgreSQL, JSON, Excel
""")
