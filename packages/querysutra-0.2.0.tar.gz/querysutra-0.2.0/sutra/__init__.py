"""
QuerySUTRA v0.2.0: Structured-Unstructured-Text-Retrieval-Architecture

INTELLIGENT VERSION with:
- Smart entity extraction from unstructured documents
- Automatic multi-table schema generation
- Semantic embeddings for query relevancy
- AI-powered data structuring

Author: Aditya Batta
Version: 0.2.0
"""

__version__ = "0.2.0"
__author__ = "Aditya Batta"
__title__ = "QuerySUTRA: Structured-Unstructured-Text-Retrieval-Architecture"

from .sutra import SUTRA, QueryResult, quick_start

__all__ = ["SUTRA", "QueryResult", "quick_start"]
