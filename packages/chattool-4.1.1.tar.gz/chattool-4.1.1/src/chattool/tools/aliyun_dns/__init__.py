from .client import AliyunDNSClient

# 导出的公共接口
__all__ = [
    'AliyunDNSClient'
]