from .widget import SkWidget


class SkMultiLineInput(SkWidget):
    """A multi-line input box【多行输入框】"""

    ...
