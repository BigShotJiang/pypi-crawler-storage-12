RAM = """
------------------------------------------
#  ####  ####  ####    ####__####__####  #
#  ####  ####  ####    ##| SKHynix  |##  #
>  ####  ####  ####    ###=--====--=###  <
#                                        #
|||||||||||||||||^||||||||||||||||||||||||
"""


class SkHynix:
    """Ester egg from the very beginning, by rgzz666."""
    def __init__(self):
        """Ester egg from the very beginning, by rgzz666.
        
        Example
        -------
        DO NOT try to create any object from SkHynix class, unless u wanna blow up ur program.
        """
        print(RAM)
        raise RuntimeError(
            "Why you want a SKHynix here??? Out of RAM bro? Then go fxxk ur backend code."
        )


if __name__ == "__main__":
    ur_brand_new_ram_stick = SkHynix()


# [2025/10/27] I came back to this file, with the worst memories of struggling with RAM overflow 
#              bug of the re-written event module.     ——rgzz666