CMS_QE_USER_ACCES_API_PERMISSION = "cms_qe_auth.accessapi_user"
