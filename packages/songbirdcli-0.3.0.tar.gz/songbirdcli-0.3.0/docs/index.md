# songbirdcli 🐦 Music Downloading Client Featuring mp3 or m4a Tagging

## Getting Started

Hello, and welcome to `songbirdcli`.

Get started by installing the `songbirdcli` package

```bash
pip install songbirdcli
```

See [the github repository](https://github.com/cboin1996/songbird)
for detailed installation instructions!

## API Documentation

To view our API documentation, click [here](https://cboin1996.github.io/songbird/)