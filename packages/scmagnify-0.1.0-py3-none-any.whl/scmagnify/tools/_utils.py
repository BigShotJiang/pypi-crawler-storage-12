from __future__ import annotations

from typing import TYPE_CHECKING

## import other packages

## from scmagnify import ..

if TYPE_CHECKING:
    pass

__all__: list[str] = []
