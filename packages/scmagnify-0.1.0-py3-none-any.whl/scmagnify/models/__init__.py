# ------------------ Importing the modules ------------------

# -----------------------------------
# MAGNI model training and inference
# -----------------------------------
from ._modules import *
from ._train import MAGNI
from ._utils import *
