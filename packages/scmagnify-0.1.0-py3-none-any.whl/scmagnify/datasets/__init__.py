from scmagnify.datasets._datasets import *
