from .types import RecursiveHijackingType
from .template import RecursiveHijackingTemplate
