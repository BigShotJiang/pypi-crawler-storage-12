from .template import CustomVulnerabilityTemplate
from .custom import CustomVulnerability
