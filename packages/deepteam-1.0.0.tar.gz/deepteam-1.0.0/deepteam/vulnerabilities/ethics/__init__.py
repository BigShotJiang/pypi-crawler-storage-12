from .types import EthicsType
from .template import EthicsTemplate
