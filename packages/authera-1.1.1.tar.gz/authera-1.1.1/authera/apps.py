from django.apps import AppConfig


class AutheraConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "authera"
