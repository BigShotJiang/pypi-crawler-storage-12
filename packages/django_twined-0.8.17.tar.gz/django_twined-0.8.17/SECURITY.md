# Security Policy

## Reporting a Vulnerability

If you find a security vulnerability, please don't report it in the issues here. Report it privately to us at www.octue.com/contact and we'll get to it. Thank you 💙.
