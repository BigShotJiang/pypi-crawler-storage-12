default_app_config = "django_twined.apps.DjangoTwinedAppConfig"
