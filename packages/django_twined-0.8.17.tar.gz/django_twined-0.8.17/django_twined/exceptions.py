class ConsistencyError(Exception):
    """Raised when the store data is found to be in conflict with reflected database values"""
