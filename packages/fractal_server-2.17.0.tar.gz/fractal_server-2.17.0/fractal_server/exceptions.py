class UnreachableBranchError(RuntimeError):
    pass
