__version__ = '0.0.1'

from pyterrier_flake8_ext.java_check import JavaCheck

__all__ = ['JavaCheck']
