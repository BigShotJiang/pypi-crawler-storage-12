# mycodes
My ML scripts bundled as a Python package.
