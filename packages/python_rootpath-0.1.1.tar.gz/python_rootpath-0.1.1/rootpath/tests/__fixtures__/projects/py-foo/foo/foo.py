
print('foo', __file__)
