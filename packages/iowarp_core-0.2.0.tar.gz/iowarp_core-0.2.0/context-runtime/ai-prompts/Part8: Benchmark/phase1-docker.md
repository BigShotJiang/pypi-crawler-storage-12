@CLAUDE.md Create a docker container under docker called benchmark.Dockerfile. This 
should launch the wrp_run_thrpt_benchmark file.

It will inherit from the iowarp/iowarp-runtime:latest.

It should be added to local.sh for building.

The benchmark 