# Fault Tolerance

What if a node goes down? Then all of the containers on that node become inaccessable. 

There are two cases:
1. The node is down temporarily
2. The node is down forever

## Node is temporarily down

Add a new 

Admin We broadcast a "node down" event. 

We mark the containers belonging to th
