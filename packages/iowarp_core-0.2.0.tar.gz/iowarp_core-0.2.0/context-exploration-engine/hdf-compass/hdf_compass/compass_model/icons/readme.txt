This folder contains icons from the KDE Oxygen project, used as the default
icons for various Node classes.  They are packaged up into a .py file by
the "package_icons.py" script which comes with HDFCompass.

Refer to "license.txt" for the icon licensing terms.