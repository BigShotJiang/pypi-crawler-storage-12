How to freeze `[developer]`
===========================

TBD