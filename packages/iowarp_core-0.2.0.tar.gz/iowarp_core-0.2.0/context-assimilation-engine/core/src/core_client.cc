#include <wrp_cae/core/core_client.h>

// This file can contain additional client implementation if needed
// For now, all implementation is in the header file
