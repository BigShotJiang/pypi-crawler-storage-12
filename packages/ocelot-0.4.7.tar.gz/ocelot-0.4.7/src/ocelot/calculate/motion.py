"""Tools for calculating values based on proper motions and/or velocities."""


def radial_velocity(velocities, with_frame_correction=False):
    # Todo
    pass


def proper_motion(proper_motions, with_frame_correction=False):
    # Todo
    pass
