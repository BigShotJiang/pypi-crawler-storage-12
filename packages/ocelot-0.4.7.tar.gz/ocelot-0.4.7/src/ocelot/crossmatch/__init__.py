from ._catalogue import Catalogue
import warnings
warnings.warn(
    "ocelot.crossmatch API will change soon. Most objects will move, change, or be "
    "deprecated.",
    DeprecationWarning,
)