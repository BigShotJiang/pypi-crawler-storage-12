from ._base import BaseClusterDistributionModel


class Plummer(BaseClusterDistributionModel):
    pass
