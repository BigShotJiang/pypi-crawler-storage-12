from ._base import BaseClusterDistributionModel


class King64(BaseClusterDistributionModel):
    pass
