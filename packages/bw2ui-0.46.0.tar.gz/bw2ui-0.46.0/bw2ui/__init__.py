"""bw2ui."""

__all__ = (
    "__version__",
    # Add functions and variables you want exposed in `bw2ui.` namespace here
)

__version__ = "0.46.0"
