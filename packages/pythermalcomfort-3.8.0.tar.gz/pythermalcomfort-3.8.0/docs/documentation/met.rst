Metabolic Rate
==============

Met typical tasks, [met]
------------------------

.. autodata:: pythermalcomfort.utilities.met_typical_tasks

**Example**

.. code-block:: python

    from pythermalcomfort.utilities import met_typical_tasks

    print(met_typical_tasks["Filing, standing"])
    # 1.4
