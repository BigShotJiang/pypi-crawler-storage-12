"""CLI utilities for pydantic-work."""

