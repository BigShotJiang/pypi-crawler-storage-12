from .path import DataPathConfig as dpc

__all__ = ['dpc']