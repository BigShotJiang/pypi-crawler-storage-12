# pygbm-package
A package dealing with Geometric Brownian Motions
