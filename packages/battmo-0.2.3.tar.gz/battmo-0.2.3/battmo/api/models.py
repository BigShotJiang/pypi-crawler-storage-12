from ..julia_import import jl


def LithiumIonBattery(*arg, **kwargs):
    return jl.LithiumIonBattery(*arg, **kwargs)


def SodiumIonBattery(*arg, **kwargs):
    return jl.SodiumIonBattery(*arg, **kwargs)
