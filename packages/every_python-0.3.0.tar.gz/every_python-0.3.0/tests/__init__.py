"""Tests for every-python."""
