"""every-python - A utility for building and running any commit of CPython."""

__version__ = "0.3.0"
