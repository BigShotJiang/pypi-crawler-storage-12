curl -H 'Content-Type:application/json' -d @druid_spec.json http://coordinator:8081/druid/indexer/v1/task
