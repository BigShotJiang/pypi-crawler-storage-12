# Execution Environment Project

## This is a sample execution environment project to build and publish your EE

## Included content/ Directory Structure

The directory structure follows best practices recommended by the Ansible
community. Feel free to customize this template according to your specific
project requirements.

```shell
├── .github
│   └── workflows
│       └── ci.yml
├── .gitignore
├── README.md
└── execution-environment.yml
```
