"""Unit tests for testorg.testcol."""


def test_basic() -> None:
    """Dummy unit test that always passes."""
    assert bool(1) is True
