---
name: "✨ Feature request"
about: Suggest an idea for this project
labels: enhancement, new
---

##### ISSUE TYPE

- Feature Idea

##### SUMMARY

<!-- Briefly describe the problem or desired enhancement. -->
