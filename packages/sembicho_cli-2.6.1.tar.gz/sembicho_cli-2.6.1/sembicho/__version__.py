"""Version information for SemBicho CLI"""

__version__ = "2.6.1"
