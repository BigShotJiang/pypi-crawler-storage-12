* Single database mode
* Multiple schema mode
* Local mode
