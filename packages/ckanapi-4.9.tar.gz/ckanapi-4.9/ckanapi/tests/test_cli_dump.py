from ckanapi.cli.dump import dump_things, dump_things_worker
from ckanapi.errors import NotFound
import json
import tempfile
import shutil
from os.path import exists

try:
    import unittest2 as unittest
except ImportError:
    import unittest
from io import BytesIO


class MockCKAN(object):
    def call_action(self, name, data_dict, requests_kwargs=None):
        try:
            return {
                'package_list': {
                    None: ['12', '34', 'dp']},
                'package_show': {
                    '12': {
                        'id': '12',
                        'name': 'twelve',
                        'title': "Twelve"},
                    '34': {
                        'id': '34',
                        'name': 'thirtyfour',
                        'title': "Thirty-four"},
                    'dp': {
                        'id': 'dp',
                        'name': 'dp',
                        'title': 'Test for datapackage',
                        'resources': [
                            {'name': 'resource1',
                             'id': 'd902fafc-5717-4dd0-87f2-7a6fc96989b7',
                             'format': 'csv',
                             'datastore_active': True,
                             'url': 'https://google.com'}]}},
                'group_show': {
                    'ab': {'title': "ABBA"}},
                'organization_show': {
                    'cd': {'title': "Super Trouper"}},
                'datastore_search': {
                    'd902fafc-5717-4dd0-87f2-7a6fc96989b7':
                        {'fields': [{
                            'id': 'col1',
                            'type': 'text',
                            'info': {
                                'label': 'Column One',
                                'notes': 'Description One',
                            }}]}},
                'resource_view_list': {
                    'd902fafc-5717-4dd0-87f2-7a6fc96989b7': [{
                            'description': 'Test view',
                            'filterable': True,
                            'id': 'd902fafc-5717-4dd0-87f2-7a6fc96989d9',
                            'package_id': 'dp',
                            'resource_id': 'd902fafc-5717-4dd0-87f2-7a6fc96989b7',
                            'responsive': True,
                            'show_fields': ['_id']}]},
            }[name][data_dict.get('id') or data_dict.get('resource_id')]
        except KeyError:
            raise NotFound()


class TestCLIDump(unittest.TestCase):
    def setUp(self):
        self.ckan = MockCKAN()
        self.stdout = BytesIO()
        self.stderr = BytesIO()

    def test_worker_one(self):
        rval = dump_things_worker(self.ckan, 'datasets',
            {'--datastore-fields': False,
             '--resource-views': False,
             '--insecure': False},
            stdin=BytesIO(b'"34"\n'), stdout=self.stdout)
        response = self.stdout.getvalue()
        self.assertEqual(response[-1:], b'\n')
        timstamp, error, data = json.loads(response.decode('UTF-8'))
        self.assertEqual(error, None)
        self.assertEqual(data["title"], "Thirty-four")

    def test_worker_two(self):
        rval = dump_things_worker(self.ckan, 'datasets',
            {'--datastore-fields': False,
             '--resource-views': False,
             '--insecure': False},
            stdin=BytesIO(b'"12"\n"34"\n'), stdout=self.stdout)
        response = self.stdout.getvalue()
        self.assertEqual(response.count(b'\n'), 2, response)
        self.assertEqual(response[-1:], b'\n')
        r1, r2 = response.split(b'\n', 1)
        timstamp, error, data = json.loads(r1.decode('UTF-8'))
        self.assertEqual(error, None)
        self.assertEqual(data["title"], "Twelve")
        timstamp, error, data = json.loads(r2.decode('UTF-8'))
        self.assertEqual(error, None)
        self.assertEqual(data["title"], "Thirty-four")

    def test_worker_error(self):
        dump_things_worker(self.ckan, 'datasets',
            {'--insecure': False},
            stdin=BytesIO(b'"99"\n'), stdout=self.stdout)
        response = self.stdout.getvalue()
        self.assertEqual(response[-1:], b'\n')
        timstamp, error, data = json.loads(response.decode('UTF-8'))
        self.assertEqual(error, "NotFound")
        self.assertEqual(data, None)

    def test_worker_group(self):
        dump_things_worker(self.ckan, 'groups',
            {'--insecure': False},
            stdin=BytesIO(b'"ab"\n'), stdout=self.stdout)
        response = self.stdout.getvalue()
        self.assertEqual(response[-1:], b'\n')
        timstamp, error, data = json.loads(response.decode('UTF-8'))
        self.assertEqual(error, None)
        self.assertEqual(data, {"title":"ABBA"})

    def test_worker_organization(self):
        dump_things_worker(self.ckan, 'organizations',
            {'--insecure': False},
            stdin=BytesIO(b'"cd"\n'), stdout=self.stdout)
        response = self.stdout.getvalue()
        self.assertEqual(response[-1:], b'\n')
        timstamp, error, data = json.loads(response.decode('UTF-8'))
        self.assertEqual(error, None)
        self.assertEqual(data, {"title":"Super Trouper"})

    def test_parent_dump_all(self):
        dump_things(self.ckan, 'datasets', {
                '--quiet': False,
                '--ckan-user': None,
                '--config': None,
                '--remote': None,
                '--apikey': None,
                '--worker': False,
                '--log': None,
                '--output': None,
                '--datapackages': None,
                '--gzip': False,
                '--all': True,
                '--processes': '1',
                '--get-request': False,
                '--datastore-fields': False,
                '--resource-views': False,
                '--insecure': False,
                '--include-users': False,
            },
            worker_pool=self._mock_worker_pool,
            stdout=self.stdout,
            stderr=self.stderr)
        self.assertEqual(self.worker_cmd, [
            'ckanapi', 'dump', 'datasets', '--worker',
            'value-here-to-make-docopt-happy'])
        self.assertEqual(self.worker_processes, 1)
        self.assertEqual(self.worker_jobs,
            [(0, b'"12"\n'), (1, b'"34"\n'), (2, b'"dp"\n')])

    def test_parent_parallel_limit(self):
        self.ckan.parallel_limit = 2
        dump_things(self.ckan, 'datasets', {
                '--quiet': False,
                '--ckan-user': None,
                '--config': None,
                '--remote': None,
                '--apikey': None,
                '--worker': False,
                '--log': None,
                '--output': None,
                '--datapackages': None,
                '--gzip': False,
                '--all': False,
                'ID_OR_NAME': ['12'],
                '--processes': '5',
                '--get-request': False,
                '--datastore-fields': False,
                '--resource-views': False,
                '--insecure': False,
                '--include-users': False,
            },
            worker_pool=self._mock_worker_pool,
            stdout=self.stdout,
            stderr=self.stderr)
        self.assertEqual(self.worker_cmd, [
            'ckanapi', 'dump', 'datasets', '--worker',
            'value-here-to-make-docopt-happy'])
        self.assertEqual(self.worker_processes, 2)

    def test_parent_id_argument(self):
        dump_things(self.ckan, 'groups', {
                '--quiet': False,
                '--ckan-user': None,
                '--config': None,
                '--remote': None,
                '--apikey': None,
                '--worker': False,
                '--log': None,
                '--output': None,
                '--datapackages': None,
                '--gzip': False,
                '--all': False,
                'ID_OR_NAME': ['ab'],
                '--processes': '1',
                '--get-request': False,
                '--datastore-fields': False,
                '--resource-views': False,
                '--insecure': False,
                '--include-users': False,
            },

            worker_pool=self._mock_worker_pool,
            stdout=self.stdout,
            stderr=self.stderr)
        self.assertEqual(self.worker_cmd, [
            'ckanapi', 'dump', 'groups', '--worker',
            'value-here-to-make-docopt-happy'])
        self.assertEqual(self.worker_processes, 1)
        self.assertEqual(self.worker_jobs, [(0, b'"ab"\n')])

    def test_parent_maintain_order(self):
        dump_things(self.ckan, 'organizations', {
                '--quiet': False,
                '--ckan-user': None,
                '--config': None,
                '--remote': None,
                '--apikey': None,
                '--worker': False,
                '--log': None,
                '--output': None,
                '--datapackages': None,
                '--gzip': False,
                '--all': False,
                'ID_OR_NAME': ['P', 'Q', 'R', 'S'],
                '--processes': '1',
                '--get-request': False,
                '--datastore-fields': False,
                '--resource-views': False,
                '--insecure': False,
                '--include-users': False,
            },
            worker_pool=self._mock_worker_pool_reversed,
            stdout=self.stdout,
            stderr=self.stderr)
        self.assertEqual(self.worker_cmd, [
            'ckanapi', 'dump', 'organizations', '--worker',
            'value-here-to-make-docopt-happy'])
        self.assertEqual(self.worker_processes, 1)
        self.assertEqual(self.stdout.getvalue(),
            b'{"id":"P"}\n'
            b'{"id":"Q"}\n'
            b'{"id":"R"}\n'
            b'{"id":"S"}\n')

    def test_parent_datapackages(self):
        target = tempfile.mkdtemp()
        try:
            dump_things(self.ckan, 'datasets', {
                    '--quiet': False,
                    '--ckan-user': None,
                    '--config': None,
                    '--remote': None,
                    '--apikey': None,
                    '--worker': False,
                    '--log': None,
                    '--output': None,
                    '--datapackages': target,
                    '--gzip': False,
                    '--all': True,
                    '--processes': '1',
                    '--get-request': False,
                    '--datastore-fields': False,
                    '--resource-views': False,
                    '--insecure': False,
                    '--include-users': False,
                },
                worker_pool=self._worker_pool_with_data,
                stdout=self.stdout,
                stderr=self.stderr)
            assert exists(target + '/twelve/datapackage.json')
            assert exists(target + '/thirtyfour/datapackage.json')
            assert exists(target + '/dp/datapackage.json')
            assert exists(target + '/dp/data/resource1.csv')
            with open(target + '/dp/datapackage.json') as dpf:
                dp = json.load(dpf)
            self.assertEqual(dp, {
                'name': 'dp',
                'title': 'Test for datapackage',
                'resources': [{
                    'name': 'resource1',
                    'format': 'csv',
                    'path': 'data/resource1.csv',
                    'title': 'resource1',
                    'schema': {
                        'fields': [{
                            'name': 'col1',
                            'title': 'Column One',
                            'description': 'Description One',
                            'type': 'string',
                        }],
                    }
                }]
            })
        finally:
            shutil.rmtree(target)


    def test_resource_views(self):
        target = tempfile.mkdtemp()
        try:
            dump_things(self.ckan, 'datasets', {
                    'ID_OR_NAME': ['dp'],
                    '--quiet': False,
                    '--ckan-user': None,
                    '--config': None,
                    '--remote': None,
                    '--apikey': None,
                    '--worker': False,
                    '--log': None,
                    '--output': target + '/dpf.jsonl',
                    '--datapackages': None,
                    '--gzip': False,
                    '--all': False,
                    '--processes': '1',
                    '--get-request': False,
                    '--datastore-fields': False,
                    '--resource-views': True,
                    '--insecure': False,
                    '--include-users': False,
                },
                worker_pool=self._worker_pool_with_resource_views,
                stdout=self.stdout,
                stderr=self.stderr)
            assert exists(target + '/dpf.jsonl')
            with open(target + '/dpf.jsonl') as dpf:
                dp = json.load(dpf)
            self.assertEqual(dp, {
                'id': 'dp',
                'name': 'dp',
                'title': 'Test for datapackage',
                'resources': [{
                    'name': 'resource1',
                    'format': 'csv',
                    'id': 'd902fafc-5717-4dd0-87f2-7a6fc96989b7',
                    'url': 'https://google.com',
                    'datastore_active': True,
                    'resource_views': [{
                        'description': 'Test view',
                        'filterable': True,
                        'id': 'd902fafc-5717-4dd0-87f2-7a6fc96989d9',
                        'package_id': 'dp',
                        'resource_id': 'd902fafc-5717-4dd0-87f2-7a6fc96989b7',
                        'responsive': True,
                        'show_fields': ['_id']
                    }]
                }]
            })
        finally:
            shutil.rmtree(target)


    def _mock_worker_pool(self, cmd, processes, job_iter):
        self.worker_cmd = cmd
        self.worker_processes = processes
        self.worker_jobs = list(job_iter)
        for i, j in self.worker_jobs:
            jname = json.loads(j.decode('UTF-8'))
            yield [[], i, json.dumps(['some-date', None, {'id': jname}]
                ).encode('UTF-8') + b'\n']

    def _mock_worker_pool_reversed(self, cmd, processes, job_iter):
        return reversed(list(
            self._mock_worker_pool(cmd, processes, job_iter)))

    def _worker_pool_with_data(self, cmd, processes, job_iter):
        worker_stdin = BytesIO(b''.join(v for i, v in job_iter))
        worker_stdout = BytesIO()
        dump_things_worker(self.ckan, 'datasets', {
            '--datastore-fields': True,
            '--resource-views': False,
            '--insecure': False,
            '--include-users': False,},
            stdin=worker_stdin,
            stdout=worker_stdout)
        for i, v in enumerate(worker_stdout.getvalue().strip().split(b'\n')):
            yield [[], i, v]


    def _worker_pool_with_resource_views(self, cmd, proccesses, job_iter):
        worker_stdin = BytesIO(b''.join(v for i, v in job_iter))
        worker_stdout = BytesIO()
        dump_things_worker(self.ckan, 'datasets', {
            '--datastore-fields': False,
            '--resource-views': True,
            '--insecure': False,
            '--include-users': False,},
            stdin=worker_stdin,
            stdout=worker_stdout)
        for i, v in enumerate(worker_stdout.getvalue().strip().split(b'\n')):
            yield [[], i, v]
