"""Sandbox integrations for DeepAgents CLI."""
