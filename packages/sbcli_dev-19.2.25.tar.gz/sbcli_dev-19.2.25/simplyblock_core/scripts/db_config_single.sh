fdbcli --exec "configure new single ssd" --timeout 100
sleep 10