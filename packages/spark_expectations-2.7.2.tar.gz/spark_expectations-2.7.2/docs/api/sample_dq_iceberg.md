
::: examples.scripts.sample_dq_iceberg
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"
        