---
search:
  exclude: true
---

::: spark_expectations.notifications.plugins.teams
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"