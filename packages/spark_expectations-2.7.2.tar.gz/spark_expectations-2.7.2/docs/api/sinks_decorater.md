---
search:
  exclude: true
---

::: spark_expectations.sinks.utils.collect_statistics
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"