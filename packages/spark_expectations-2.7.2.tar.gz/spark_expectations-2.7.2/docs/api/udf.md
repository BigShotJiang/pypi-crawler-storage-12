---
search:
  exclude: true
---

::: spark_expectations.utils.udf
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"
        