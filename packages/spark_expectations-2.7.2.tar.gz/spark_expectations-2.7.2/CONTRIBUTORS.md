# Authors
* [Ashok Singamaneni](https://www.linkedin.com/in/ashok-singamaneni-193b1a32/)
* [Umesh](https://github.com/Umeshsp22)

# Contributors
Thanks to the contributors who helped on this project apart from the authors
* [Teja Dogiparthi](https://github.com/Tejadogiparthi)
* [Phani Kumar Vemuri](https://www.linkedin.com/in/vemuriphani/)
* [Sarath Chandra Bandaru](https://www.linkedin.com/in/sarath-chandra-bandaru/)
* [Holden Karau](https://www.linkedin.com/in/holdenkarau/)
* [Araveti Venkata Bharat Kumar](https://www.linkedin.com/in/bharat-kumar-araveti/)
* [Samy Coenen](https://github.com/SamyCoenen)
* [Jagadapi Sivanaga Krishnam Raja Reddy](www.linkedin.com/in/jskrajareddy/)
* [Vigneshwarr Venkatesan](https://www.linkedin.com/in/vignesh15)
* [Nishant Singh](https://www.linkedin.com/in/singh-nishant/)
* [Amaldev Kunnel](https://www.linkedin.com/in/amaldev-k-40222680)
* [Raghavendra H S](https://www.linkedin.com/in/raghavendra-h-s-01786332/)
* [Sudeepta pal](https://www.linkedin.com/in/sudeepta-pal-98b393217/)
* [Mallikarjunudu Tirumalasetti](https://www.linkedin.com/in/mtirumal/)
* [Tadakala sai vamsi goud](https://www.linkedin.com/in/sai-vamsi-goud-455737169/)
* [Lior Zadok](https://www.linkedin.com/in/lior-zadok-24ab5a7/)
* [Danny Meijer](https://www.linkedin.com/in/dannydatascientist/)
* [Sasa Mirkovic](https://www.linkedin.com/in/societysling/)
* [Maria Ovsyankina](https://www.linkedin.com/in/movsyankina/)
* [Patrick Miki](https://www.linkedin.com/in/pmiki)
* [Manasa Kanathur](https://www.linkedin.com/in/manasa-kanathur)
* [Keerthana Yakkati](https://www.linkedin.com/in/keerthana-yakkati-06941b214/)

# Honorary Mentions
Thanks to the team below for invaluable insights and support throughout the initial release of this project

* [Joe Hollow](https://www.linkedin.com/in/joe-hollow-23088b1/)
* [Rakesh Dikshit](https://www.linkedin.com/in/rakesh-dikshit-867209b/)
* [Aditya Chaturvedi](https://www.linkedin.com/in/chaturvediaditya/)
* [Scott Haines](https://www.linkedin.com/in/scotthaines/)
* [Arijit Banerjee](https://www.linkedin.com/in/massborn/)
