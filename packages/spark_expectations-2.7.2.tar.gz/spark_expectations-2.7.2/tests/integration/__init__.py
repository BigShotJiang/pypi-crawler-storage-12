import os

# setting up env for local
os.environ["SPARKEXPECTATIONS_ENV"] = "local"
