"""
Tests for Petrosa Data Manager.
"""
