"""Shared fixtures for router integration tests."""
