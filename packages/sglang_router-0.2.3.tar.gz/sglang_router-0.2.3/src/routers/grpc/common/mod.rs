//! Shared code for both regular and harmony routers

pub mod response_collection;
pub mod response_formatting;
pub mod responses;
pub mod stages;
