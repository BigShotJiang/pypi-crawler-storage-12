from vizro.models._action._action import Action

__all__ = ["Action"]
