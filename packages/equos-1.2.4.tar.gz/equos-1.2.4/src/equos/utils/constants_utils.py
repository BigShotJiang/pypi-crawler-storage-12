class ConstantUtils:
    API_VERSION = "v1"
    DEFAULT_BASE_URL = "https://api.equos.ai"
