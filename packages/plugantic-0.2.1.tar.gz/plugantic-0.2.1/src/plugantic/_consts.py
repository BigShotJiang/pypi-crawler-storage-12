# Single source of truth for information needed at runtime and build-time (i.e. version)
version = "0.2.1"
