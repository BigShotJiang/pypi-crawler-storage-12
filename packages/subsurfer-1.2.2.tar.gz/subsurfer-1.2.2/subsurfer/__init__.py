"""
SubSurfer - Red Teaming and Web Bug Bounty Fast Asset Identification Tool
"""

__version__ = "1.2.2"
