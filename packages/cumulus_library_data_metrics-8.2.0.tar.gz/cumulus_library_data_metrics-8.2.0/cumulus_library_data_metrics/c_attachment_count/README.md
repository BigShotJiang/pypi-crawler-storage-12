# c_attachment_count

**Count of attachment metadata**

### Fields

- status
- content_type
- language
- format
- content
