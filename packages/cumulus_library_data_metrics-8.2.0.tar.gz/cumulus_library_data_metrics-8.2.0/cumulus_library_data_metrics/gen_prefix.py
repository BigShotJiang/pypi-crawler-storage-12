#!/usr/bin/env python3

# TODO: once we implement study-cohort slicing,
#  uncomment this file to allow writing to a study-specific prefix.
#  But for now, just always use boring old data_metrics__.
print("data_metrics")

# import argparse
#
# parser = argparse.ArgumentParser()
# parser.add_argument("--study")
# args, _rest = parser.parse_known_args()
#
# if args.study:
#     print(f"data_metrics_{args.study}")
# else:
#     print("data_metrics")
