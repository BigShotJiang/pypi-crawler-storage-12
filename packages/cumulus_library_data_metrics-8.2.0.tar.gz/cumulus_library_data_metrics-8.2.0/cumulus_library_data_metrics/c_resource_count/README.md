# c_resource_count

**Basic Resource Stats**

This metric makes a new table for each target resource,
slicing and dicing that resource by category and time (if relevant).

### Fields

- category (depending on resource)
- month/year (depending on resource)
- status
