project = 'biolith'
extensions = ['sphinx.ext.autodoc', 'sphinx.ext.napoleon', 'myst_parser']
templates_path = ['_templates']
exclude_patterns = []
html_theme = 'sphinx_rtd_theme'
html_logo = '../assets/biolith.svg'
display_version = True