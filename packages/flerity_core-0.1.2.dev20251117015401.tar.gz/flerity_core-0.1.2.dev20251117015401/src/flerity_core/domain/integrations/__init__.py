"""Integrations domain - External service connections."""
