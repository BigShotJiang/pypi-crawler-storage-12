pydal.adapters package
==========================

Submodules
----------

pydal.adapters.base module
------------------------------

.. automodule:: pydal.adapters.base
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.couchdb module
---------------------------------

.. automodule:: pydal.adapters.couchdb
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.cubrid module
--------------------------------

.. automodule:: pydal.adapters.cubrid
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.db2 module
-----------------------------

.. automodule:: pydal.adapters.db2
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.firebird module
----------------------------------

.. automodule:: pydal.adapters.firebird
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.google_adapters module
-----------------------------------------

   Adapter for GAE

pydal.adapters.imap module
------------------------------

.. automodule:: pydal.adapters.imap
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.informix module
----------------------------------

.. automodule:: pydal.adapters.informix
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.ingres module
--------------------------------

.. automodule:: pydal.adapters.ingres
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.mongo module
-------------------------------

.. automodule:: pydal.adapters.mongo
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.mssql module
-------------------------------

.. automodule:: pydal.adapters.mssql
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.mysql module
-------------------------------

.. automodule:: pydal.adapters.mysql
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.oracle module
--------------------------------

.. automodule:: pydal.adapters.oracle
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.postgres module
---------------------------------

.. automodule:: pydal.adapters.postgres
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.sapdb module
-------------------------------

.. automodule:: pydal.adapters.sapdb
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.sqlite module
--------------------------------

.. automodule:: pydal.adapters.sqlite
    :members:
    :undoc-members:
    :show-inheritance:

pydal.adapters.teradata module
----------------------------------

.. automodule:: pydal.adapters.teradata
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: pydal.adapters
    :members:
    :undoc-members:
    :show-inheritance:
