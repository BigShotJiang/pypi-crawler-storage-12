from liblaf.cherries import core


def end() -> None:
    core.run.end()
