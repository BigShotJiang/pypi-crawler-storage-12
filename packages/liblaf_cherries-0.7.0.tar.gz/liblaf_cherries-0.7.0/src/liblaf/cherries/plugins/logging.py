from collections.abc import Mapping
from pathlib import Path
from typing import Any, override

import attrs
from liblaf.grapes.logging import depth_logger

from liblaf import grapes
from liblaf.cherries import core


@attrs.define
class Logging(core.PluginSchema):
    @property
    def log_file(self) -> Path:
        return self.run.logs_dir / self.run.entrypoint.with_suffix(".log").name

    @override
    @core.impl(before=("Comet",))
    def end(self, *args, **kwargs) -> None:
        self.run.log_asset(self.log_file)

    @override
    @core.impl
    def log_metric(
        self, name: str, value: Any, step: int | None = None, **kwargs
    ) -> None:
        __tracebackhide__ = True
        if step is None:
            depth_logger.info("%s: %s", name, value)
        else:
            depth_logger.info("step: %s, %s: %s", step, name, value)

    @override
    @core.impl
    def log_metrics(
        self, metrics: Mapping[str, Any], step: int | None = None, **kwargs
    ) -> None:
        __tracebackhide__ = True
        if step is None:
            depth_logger.info("%s", metrics)
        else:
            depth_logger.info("step: %s, %s", step, metrics)

    @override
    @core.impl
    def start(self, *args, **kwargs) -> None:
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        grapes.logging.init(file=self.log_file, force=True)
