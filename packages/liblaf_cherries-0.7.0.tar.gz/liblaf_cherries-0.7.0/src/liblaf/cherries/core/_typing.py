type MethodName = str
type PluginId = str
