Welcome to qiclib's documentation!
==================================

.. warning::

    Despite our best efforts, some of the provided contents herein is legacy and no longer correct.
    Please take this into consideration when reading th documentation.

.. toctree::
   :titlesonly:
   :hidden:

   getting_started
   qi_code
   experiments
   reference
   troubleshooting

.. toctree::
   :titlesonly:
   :hidden:
   :caption: API Docs

   qiclib/qiclib

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
