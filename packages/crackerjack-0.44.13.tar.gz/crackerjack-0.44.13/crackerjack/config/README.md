# Config

Configuration helpers and defaults. Prefer explicit types and minimal global state.
