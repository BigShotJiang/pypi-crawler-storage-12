# ABOUTME: cenv package initialization
# ABOUTME: Exports version information for the Claude environment manager
"""cenv - Claude environment manager"""

__version__ = "0.1.0"
