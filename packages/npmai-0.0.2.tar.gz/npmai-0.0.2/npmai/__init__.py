__version__ = "0.0.2"
from .npmai import GeminiAIMode, Gemini, ChatGPT, Grok, Perplexity
