JSON Spec
=========

TensorStore relies on a JSON ``Spec`` format for specifying all
parameters necessary for opening or creating a TensorStore.

.. json:schema:: TensorStore

.. json:schema:: TensorStoreUrl

.. json:schema:: dtype
