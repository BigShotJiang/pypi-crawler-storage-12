"""
Turboalias - Cross-workstation alias manager
"""

__version__ = "0.0.4"
__author__ = "mcdominik"
__license__ = "MIT"
