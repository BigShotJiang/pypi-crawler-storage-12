"""App Store Asset CLI - Download App Store logos and screenshots."""
