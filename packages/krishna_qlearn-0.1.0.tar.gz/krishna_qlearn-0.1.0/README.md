# krishna_qlearn

Tiny tabular Q-learning utilities for discrete environments.

## Features
- `qlearn_step`: one-step tabular Q-learning update
- `TabularQAgent`: easy-to-use tabular Q-learning agent with epsilon-greedy policy
- Minimal dependencies

## Installation
From PyPI (when published):
