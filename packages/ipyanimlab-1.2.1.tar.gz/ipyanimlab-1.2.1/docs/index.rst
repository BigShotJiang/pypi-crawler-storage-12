
Welcome to ipyanimlab documentation!
====================================

**ipyanimlab** is a Jupyter Lab library build on top of **ipywebgl** https://ipywebgl.readthedocs.io/
to quickly render character animation when doing animation research and development.

It uses Pixar OpenUSD library to load asset and animation, and it supports BVH animation also.

Contents
--------

.. toctree::

   Home <self>
   usage
   examples/index
   api


   