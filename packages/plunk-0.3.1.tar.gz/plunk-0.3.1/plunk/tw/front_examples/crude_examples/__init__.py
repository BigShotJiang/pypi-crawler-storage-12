"""Copied (and continued) from
https://github.com/i2mint/crude/tree/10e9eb220394c7bf2a6d6cb87d1c16eaf6dec6e0/crude/extrude_crude"""
