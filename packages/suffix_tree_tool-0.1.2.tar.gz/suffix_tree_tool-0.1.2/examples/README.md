# Examples

This directory contains rendered outputs generated with the command-line interface.

- `single_seq_tree.png` was produced with:
  ```bash
  generate-suffix-tree gatgaatgg
  ```
- `multi_seq_tree.png` was produced with:
  ```bash
  generate-suffix-tree gatgaatgg ggtaagtag --annotate-internal
  ```

