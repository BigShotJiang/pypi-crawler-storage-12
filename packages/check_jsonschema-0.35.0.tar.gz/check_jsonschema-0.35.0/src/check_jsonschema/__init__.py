from __future__ import annotations

from .cli import main

__all__ = ("main",)
