from check_jsonschema import main

main()
