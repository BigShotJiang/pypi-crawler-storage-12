import pytest


@pytest.fixture
def rename_me():
    """Your fixture goes here."""
    return 'itworks'
