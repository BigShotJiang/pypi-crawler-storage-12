
def test_basic(rename_me):
    assert rename_me == 'itworks'
