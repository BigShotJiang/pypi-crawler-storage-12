{% block imports %}{% endblock %}


VERSION = "0.0.0"
"""Application version number tuple."""

{% block body %}{% endblock %}
