# {{ app_name }}

{{ url }}

[![PyPI - Version](https://img.shields.io/pypi/v/{{ app_name }})](https://pypi.python.org/pypi/{{ app_name }})
[![License](https://img.shields.io/pypi/l/{{ app_name }})](https://pypi.python.org/pypi/{{ app_name }})
[![Docs](https://img.shields.io/readthedocs/{{ app_name }})](https://{{ app_name }}.readthedocs.io/)
{% block badges %}
{% endblock %}

**Work in progress. Stay tuned.**

## Description

*{{ description }}*

Here will be an introductory description.


## Documentation

https://{{ app_name }}.readthedocs.io/
