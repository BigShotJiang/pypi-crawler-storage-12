# This test suite relies pytest-djangoapp


def test_basic(settings):

    assert settings
