# from django.shortcuts import render
# from django.views.generic.base import View
# from django.shortcuts import redirect
# from django.shortcuts import get_object_or_404
# from django.contrib.auth.decorators import login_required
# from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage


# @login_required
# def index(request):
#     return render(request, '{{ package_name }}/index.html', {})
