
VERSION = '2.1.0'
"""Application version number tuple."""