"""DeepBrief - Video Analysis Application."""

__version__ = "0.4.1"
__author__ = "Michael Borck"
__description__ = "A video analysis application for presentation feedback"
