"""Report generation module."""
