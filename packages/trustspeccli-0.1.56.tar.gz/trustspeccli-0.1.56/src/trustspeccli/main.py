import sys
import trustspecpy

def run():
    trustspecpy.main(sys.argv)
