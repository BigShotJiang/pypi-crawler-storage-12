# This module is about extracting evidence from the given retrieval gt passage
