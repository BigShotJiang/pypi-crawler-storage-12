"""Deprecated code."""

from .deprecated import *  # noqa: F403

__all__ = [
    "handle_deprecated_model_args",
]

