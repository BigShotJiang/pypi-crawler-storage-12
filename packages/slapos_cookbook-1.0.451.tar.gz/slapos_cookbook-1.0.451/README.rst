slapos.cookbook
===============

Cookbook of SlapOS recipes.


testing
=======

Unit tests for recipes can be found under ``slapos/test/recipe``. To run the
tests use provided unittest.defaultTestLoader inside ``slapos/test/test_recipe``
by invoking 

    python setup.py test --test-suite slapos.test.test_recipe.additional_tests

