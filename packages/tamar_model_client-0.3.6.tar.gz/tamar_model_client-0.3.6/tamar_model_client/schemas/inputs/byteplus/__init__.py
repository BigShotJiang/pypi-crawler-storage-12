from tamar_model_client.schemas.inputs.byteplus.omnihuman_video import BytePlusOmniHumanVideoInput

__all__ = [
    "BytePlusOmniHumanVideoInput",
]
