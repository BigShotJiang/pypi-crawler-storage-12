from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="QuerySUTRA",
    version="0.1.2",
    author="Aditya Batta",
    author_email="b05aditya@gmail.com",
    description="Natural Language to SQL with MySQL/PostgreSQL export - Supports CSV, Excel, JSON, SQL, PDF, DOCX, TXT",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/adityabatta/sutra",
    packages=find_packages(exclude=["tests", "tests.*", "venv", "data"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Database",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "openai>=1.12.0",
        "pandas>=2.0.0",
        "numpy>=1.24.0",
        "plotly",
        "matplotlib>=3.7.0",
        "PyPDF2>=3.0.0",
        "python-docx>=1.0.0",
        "openpyxl>=3.1.0",
        "sqlalchemy>=2.0.0",
    ],
    extras_require={
        "mysql": ["mysql-connector-python"],
        "postgres": ["psycopg2-binary"],
        "all": ["mysql-connector-python", "psycopg2-binary"],
    },
)
