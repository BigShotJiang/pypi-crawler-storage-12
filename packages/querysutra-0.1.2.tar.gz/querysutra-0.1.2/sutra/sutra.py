"""
SUTRA - Simple Unified Tool for Relational Analysis
A single-file natural language to SQL query system with visualization.

Installation:
    pip install QuerySUTRA

Usage:
    from sutra import SUTRA
    
    sutra = SUTRA(api_key="your-openai-key")
    sutra.upload("data.csv")
    result = sutra.ask("Show me total sales", viz=True)

Author: Aditya Batta
License: MIT
Version: 0.1.2
"""

__version__ = "0.1.2"
__author__ = "Aditya Batta"
__all__ = ["SUTRA", "QueryResult", "quick_start"]

import os
import sqlite3
import pandas as pd
import numpy as np
from typing import Optional, Union, Dict, Any, List
from pathlib import Path
import json
import hashlib
import warnings
import shutil
import datetime
warnings.filterwarnings('ignore')

try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

try:
    import plotly.express as px
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

try:
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

try:
    import PyPDF2
    HAS_PYPDF2 = True
except ImportError:
    HAS_PYPDF2 = False

try:
    import docx
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False


class SUTRA:
    """
    SUTRA - Natural Language to SQL Query System
    
    Features:
    - Upload: CSV, Excel, JSON, SQL, PDF, DOCX, TXT, DataFrame
    - Query: Natural language or direct SQL
    - Export: SQLite, MySQL, PostgreSQL, JSON, Excel
    - Visualize: Auto charts with Plotly/Matplotlib
    """
    
    def __init__(self, api_key: Optional[str] = None, db: str = "sutra.db"):
        print("🚀 Initializing SUTRA v0.1.2...")
        
        if api_key:
            os.environ["OPENAI_API_KEY"] = api_key
        
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.client = OpenAI(api_key=self.api_key) if self.api_key and HAS_OPENAI else None
        
        self.db_path = db
        self.conn = sqlite3.connect(db, check_same_thread=False)
        self.cursor = self.conn.cursor()
        
        self.current_table = None
        self.schema = {}
        self.cache = {}
        
        print(f"✅ Ready! Database: {db}")
        if not self.api_key:
            print("⚠️  No API key - use .sql() for direct queries only")
    
    def upload(self, data: Union[str, pd.DataFrame], name: Optional[str] = None) -> 'SUTRA':
        """Upload data from various sources."""
        print(f"\n📤 Uploading data...")
        
        if isinstance(data, pd.DataFrame):
            name = name or "data"
            df = data
        else:
            path = Path(data)
            if not path.exists():
                raise FileNotFoundError(f"File not found: {data}")
            
            name = name or path.stem.replace(" ", "_").replace("-", "_")
            ext = path.suffix.lower()
            
            print(f"   📄 File: {path.name}")
            
            if ext == ".csv":
                df = pd.read_csv(path)
            elif ext in [".xlsx", ".xls"]:
                df = pd.read_excel(path)
            elif ext == ".json":
                df = pd.read_json(path)
            elif ext == ".sql":
                with open(path) as f:
                    self.cursor.executescript(f.read())
                self.conn.commit()
                self._refresh_schema()
                print(f"✅ SQL executed!")
                return self
            elif ext == ".pdf":
                df = self._load_pdf(path)
            elif ext == ".docx":
                df = self._load_docx(path)
            elif ext == ".txt":
                df = self._load_txt(path)
            else:
                raise ValueError(f"Unsupported format: {ext}")
        
        df.columns = [str(c).strip().replace(" ", "_") for c in df.columns]
        df.to_sql(name, self.conn, if_exists='replace', index=False)
        self.current_table = name
        self._refresh_schema()
        
        print(f"✅ Uploaded to table: {name}")
        print(f"   📊 {len(df)} rows × {len(df.columns)} columns")
        return self
    
    def _load_pdf(self, path: Path) -> pd.DataFrame:
        if not HAS_PYPDF2:
            raise ImportError("PyPDF2 not installed. Run: pip install PyPDF2")
        
        with open(path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            text = "".join([page.extract_text() + "\n" for page in pdf_reader.pages])
        
        return self._parse_text_to_dataframe(text)
    
    def _load_docx(self, path: Path) -> pd.DataFrame:
        if not HAS_DOCX:
            raise ImportError("python-docx not installed. Run: pip install python-docx")
        
        doc = docx.Document(path)
        
        if doc.tables:
            table = doc.tables[0]
            data = [[cell.text.strip() for cell in row.cells] for row in table.rows]
            if data:
                return pd.DataFrame(data[1:], columns=data[0])
        
        text = "\n".join([para.text for para in doc.paragraphs])
        return self._parse_text_to_dataframe(text)
    
    def _load_txt(self, path: Path) -> pd.DataFrame:
        with open(path, 'r', encoding='utf-8') as file:
            text = file.read()
        return self._parse_text_to_dataframe(text)
    
    def _parse_text_to_dataframe(self, text: str) -> pd.DataFrame:
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        
        if not lines:
            return pd.DataFrame({'content': ['No content found']})
        
        sample = lines[:min(10, len(lines))]
        
        for delimiter in ['\t', ',', '|', ';']:
            if all(delimiter in line for line in sample):
                try:
                    from io import StringIO
                    df = pd.read_csv(StringIO('\n'.join(lines)), sep=delimiter)
                    if len(df.columns) > 1:
                        return df
                except:
                    continue
        
        return pd.DataFrame({
            'line_number': range(1, len(lines) + 1),
            'content': lines
        })
    
    def tables(self) -> list:
        """List all tables."""
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        return [r[0] for r in self.cursor.fetchall()]
    
    def schema(self, table: Optional[str] = None):
        """Show database schema."""
        if not self.schema:
            self._refresh_schema()
        
        print("\n" + "="*70)
        print("📋 DATABASE SCHEMA")
        print("="*70)
        
        tables_to_show = [table] if table else self.schema.keys()
        
        for tbl in tables_to_show:
            if tbl in self.schema:
                print(f"\n📊 {tbl}")
                for col, dtype in self.schema[tbl].items():
                    print(f"   • {col:<25} {dtype}")
        
        print("="*70)
        return self
    
    def peek(self, table: Optional[str] = None, n: int = 5) -> pd.DataFrame:
        """View sample data."""
        tbl = table or self.current_table
        if not tbl:
            print("❌ No table specified")
            return pd.DataFrame()
        
        df = pd.read_sql_query(f"SELECT * FROM {tbl} LIMIT {n}", self.conn)
        print(f"\n📊 Sample from '{tbl}' ({n} rows):")
        print(df.to_string(index=False))
        return df
    
    def sql(self, query: str, viz: bool = False) -> 'QueryResult':
        """Execute SQL directly (no API cost)."""
        print(f"\n⚡ Executing SQL...")
        
        try:
            df = pd.read_sql_query(query, self.conn)
            print(f"✅ Success! {len(df)} rows returned")
            
            fig = None
            if viz and not df.empty:
                fig = self._visualize(df, "SQL Query Result")
            
            return QueryResult(True, query, df, fig)
        except Exception as e:
            print(f"❌ Error: {e}")
            return QueryResult(False, query, pd.DataFrame(), None, str(e))
    
    def ask(self, question: str, viz: bool = False, table: Optional[str] = None) -> 'QueryResult':
        """Ask a question in natural language."""
        if not self.client:
            print("❌ No API key configured")
            return QueryResult(False, "", pd.DataFrame(), None, "No API key")
        
        print(f"\n🔍 Question: {question}")
        
        tbl = table or self.current_table
        if not tbl:
            print("❌ No table specified. Upload data first!")
            return QueryResult(False, "", pd.DataFrame(), None, "No table")
        
        cache_key = hashlib.md5(f"{question}:{tbl}".encode()).hexdigest()
        if cache_key in self.cache:
            sql_query = self.cache[cache_key]
            print("   💾 From cache")
        else:
            sql_query = self._generate_sql(question, tbl)
            self.cache[cache_key] = sql_query
        
        print(f"   📝 SQL: {sql_query}")
        
        try:
            df = pd.read_sql_query(sql_query, self.conn)
            print(f"✅ Success! {len(df)} rows")
            
            fig = None
            if viz and not df.empty:
                fig = self._visualize(df, question)
            
            return QueryResult(True, sql_query, df, fig)
        except Exception as e:
            print(f"❌ Error: {e}")
            return QueryResult(False, sql_query, pd.DataFrame(), None, str(e))
    
    def interactive(self, question: str) -> 'QueryResult':
        """Ask question and prompt user for visualization."""
        print(f"\n🔍 Question: {question}")
        choice = input("💡 Do you want visualization? (yes/no): ").strip().lower()
        viz = choice in ['yes', 'y', 'yeah', 'yep', 'sure']
        return self.ask(question, viz=viz)
    
    # ========================================================================
    # DATABASE EXPORT & MIGRATION
    # ========================================================================
    
    def export_db(self, path: str, format: str = "sqlite"):
        """
        Export entire database.
        
        Args:
            path: Output file path
            format: sqlite, sql, json, or excel
        
        Examples:
            >>> sutra.export_db("backup.db", format="sqlite")
            >>> sutra.export_db("schema.sql", format="sql")
        """
        print(f"\n💾 Exporting database to {format}...")
        
        format = format.lower()
        
        if format == "sqlite":
            shutil.copy2(self.db_path, path)
            print(f"✅ Database copied to {path}")
        
        elif format == "sql":
            with open(path, 'w', encoding='utf-8') as f:
                for line in self.conn.iterdump():
                    f.write(f'{line}\n')
            print(f"✅ SQL dump saved to {path}")
        
        elif format == "json":
            data = {}
            for table in self.tables():
                df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
                data[table] = df.to_dict(orient='records')
            
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, default=str)
            print(f"✅ JSON export saved to {path}")
        
        elif format == "excel":
            with pd.ExcelWriter(path, engine='openpyxl') as writer:
                for table in self.tables():
                    df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
                    df.to_excel(writer, sheet_name=table[:31], index=False)
            print(f"✅ Excel export saved to {path}")
        
        else:
            raise ValueError(f"Unsupported format: {format}")
        
        return self
    
    def save_to_mysql(self, host: str, user: str, password: str, database: str,
                      port: int = 3306, tables: Optional[List[str]] = None):
        """
        Save tables to MySQL database.
        
        Examples:
            >>> sutra.save_to_mysql("localhost", "root", "pass", "mydb")
            >>> sutra.save_to_mysql("aws-rds.com", "admin", "pass", "prod")
        """
        try:
            from sqlalchemy import create_engine
        except ImportError:
            raise ImportError("Run: pip install sqlalchemy mysql-connector-python")
        
        print(f"\n🔄 Connecting to MySQL at {host}:{port}...")
        
        connection_string = f"mysql+mysqlconnector://{user}:{password}@{host}:{port}/{database}"
        engine = create_engine(connection_string)
        
        tables_to_export = tables or self.tables()
        
        print(f"📤 Exporting {len(tables_to_export)} tables to MySQL...")
        
        for table in tables_to_export:
            print(f"   Exporting {table}...", end=" ")
            df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
            df.to_sql(table, engine, if_exists='replace', index=False)
            print(f"✅ ({len(df)} rows)")
        
        print(f"✅ All tables exported to MySQL database '{database}'")
        return self
    
    def save_to_postgres(self, host: str, user: str, password: str, database: str,
                         port: int = 5432, tables: Optional[List[str]] = None):
        """
        Save tables to PostgreSQL database.
        
        Examples:
            >>> sutra.save_to_postgres("localhost", "postgres", "pass", "mydb")
            >>> sutra.save_to_postgres("heroku-pg.com", "user", "pass", "prod")
        """
        try:
            from sqlalchemy import create_engine
        except ImportError:
            raise ImportError("Run: pip install sqlalchemy psycopg2-binary")
        
        print(f"\n🔄 Connecting to PostgreSQL at {host}:{port}...")
        
        connection_string = f"postgresql://{user}:{password}@{host}:{port}/{database}"
        engine = create_engine(connection_string)
        
        tables_to_export = tables or self.tables()
        
        print(f"📤 Exporting {len(tables_to_export)} tables to PostgreSQL...")
        
        for table in tables_to_export:
            print(f"   Exporting {table}...", end=" ")
            df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
            df.to_sql(table, engine, if_exists='replace', index=False)
            print(f"✅ ({len(df)} rows)")
        
        print(f"✅ All tables exported to PostgreSQL database '{database}'")
        return self
    
    def save_schema(self, path: str, format: str = "sql"):
        """
        Export only database schema (no data).
        
        Examples:
            >>> sutra.save_schema("schema.sql")
            >>> sutra.save_schema("schema.json", format="json")
        """
        print(f"\n📋 Exporting schema to {format}...")
        
        if not self.schema:
            self._refresh_schema()
        
        format = format.lower()
        
        if format == "sql":
            with open(path, 'w', encoding='utf-8') as f:
                for table in self.tables():
                    self.cursor.execute(f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table}'")
                    create_stmt = self.cursor.fetchone()[0]
                    f.write(f"{create_stmt};\n\n")
            print(f"✅ SQL schema saved to {path}")
        
        elif format == "json":
            schema_data = {}
            for table, columns in self.schema.items():
                count = pd.read_sql_query(f"SELECT COUNT(*) FROM {table}", self.conn).iloc[0, 0]
                schema_data[table] = {
                    "columns": columns,
                    "row_count": count
                }
            
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(schema_data, f, indent=2)
            print(f"✅ JSON schema saved to {path}")
        
        elif format == "markdown":
            with open(path, 'w', encoding='utf-8') as f:
                f.write("# Database Schema\n\n")
                
                for table in self.schema:
                    count = pd.read_sql_query(f"SELECT COUNT(*) FROM {table}", self.conn).iloc[0, 0]
                    f.write(f"## Table: `{table}`\n\n")
                    f.write(f"**Rows:** {count}\n\n")
                    f.write("| Column | Type |\n|--------|------|\n")
                    
                    for col, dtype in self.schema[table].items():
                        f.write(f"| {col} | {dtype} |\n")
                    f.write("\n")
            
            print(f"✅ Markdown schema saved to {path}")
        else:
            raise ValueError(f"Unsupported format: {format}")
        
        return self
    
    def backup(self, backup_path: str = None):
        """
        Create complete backup of database and schema.
        
        Example:
            >>> sutra.backup()
            >>> sutra.backup("/path/to/backups")
        """
        if backup_path:
            backup_dir = Path(backup_path)
            backup_dir.mkdir(parents=True, exist_ok=True)
        else:
            backup_dir = Path(".")
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        print(f"\n💾 Creating backup...")
        
        db_backup = backup_dir / f"sutra_backup_{timestamp}.db"
        self.export_db(str(db_backup), format="sqlite")
        
        schema_backup = backup_dir / f"sutra_schema_{timestamp}.sql"
        self.save_schema(str(schema_backup), format="sql")
        
        json_backup = backup_dir / f"sutra_data_{timestamp}.json"
        self.export_db(str(json_backup), format="json")
        
        print(f"\n✅ Backup complete!")
        print(f"   📁 Database: {db_backup}")
        print(f"   📋 Schema: {schema_backup}")
        print(f"   📊 Data: {json_backup}")
        
        return self
    
    # ========================================================================
    # UTILITIES
    # ========================================================================
    
    def export(self, data: pd.DataFrame, path: str, format: str = "csv"):
        """Export results to file."""
        fmt = format.lower()
        if fmt == "csv":
            data.to_csv(path, index=False)
        elif fmt in ["excel", "xlsx"]:
            data.to_excel(path, index=False)
        elif fmt == "json":
            data.to_json(path, orient="records", indent=2)
        else:
            raise ValueError(f"Unknown format: {format}")
        
        print(f"✅ Exported to {path}")
        return self
    
    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            print("✅ SUTRA closed")
    
    def _refresh_schema(self):
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [r[0] for r in self.cursor.fetchall()]
        
        self.schema = {}
        for tbl in tables:
            self.cursor.execute(f"PRAGMA table_info({tbl})")
            self.schema[tbl] = {r[1]: r[2] for r in self.cursor.fetchall()}
    
    def _generate_sql(self, question: str, table: str) -> str:
        schema_info = self.schema.get(table, {})
        schema_str = ", ".join([f"{col} ({dtype})" for col, dtype in schema_info.items()])
        
        prompt = f"""Convert this question to SQL.

Table: {table}
Columns: {schema_str}
Question: {question}

Return ONLY the SQL query. No explanations. Use SQLite syntax."""
        
        response = self.client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a SQL expert. Return only SQL queries."},
                {"role": "user", "content": prompt}
            ],
            temperature=0
        )
        
        sql = response.choices[0].message.content.strip()
        return sql.replace("```sql", "").replace("```", "").strip()
    
    def _visualize(self, df: pd.DataFrame, title: str):
        if not HAS_PLOTLY and not HAS_MATPLOTLIB:
            print("⚠️  Install plotly or matplotlib for visualizations")
            return None
        
        print("📊 Creating visualization...")
        
        if HAS_PLOTLY:
            return self._plotly_viz(df, title)
        else:
            return self._matplotlib_viz(df, title)
    
    def _plotly_viz(self, df: pd.DataFrame, title: str):
        try:
            numeric = df.select_dtypes(include=[np.number]).columns.tolist()
            categorical = df.select_dtypes(include=['object']).columns.tolist()
            
            if len(df) == 1 or not numeric:
                fig = go.Figure(data=[go.Table(
                    header=dict(values=list(df.columns)),
                    cells=dict(values=[df[c] for c in df.columns])
                )])
            elif categorical and numeric:
                fig = px.bar(df, x=categorical[0], y=numeric[0], title=title)
            elif len(numeric) >= 2:
                fig = px.line(df, y=numeric[0], title=title)
            else:
                fig = px.bar(df, y=df.columns[0], title=title)
            
            fig.show()
            print("✅ Chart displayed")
            return fig
        except Exception as e:
            print(f"⚠️  Viz error: {e}")
            return None
    
    def _matplotlib_viz(self, df: pd.DataFrame, title: str):
        try:
            plt.figure(figsize=(10, 6))
            numeric = df.select_dtypes(include=[np.number]).columns
            
            if len(numeric) > 0:
                df[numeric[0]].plot(kind='bar')
            else:
                df.iloc[:, 0].value_counts().plot(kind='bar')
            
            plt.title(title)
            plt.tight_layout()
            plt.show()
            print("✅ Chart displayed")
            return plt.gcf()
        except Exception as e:
            print(f"⚠️  Viz error: {e}")
            return None
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()
    
    def __repr__(self):
        return f"SUTRA(tables={len(self.schema)}, current='{self.current_table}')"


class QueryResult:
    """Result from a query."""
    
    def __init__(self, success: bool, sql: str, data: pd.DataFrame, viz, error: str = None):
        self.success = success
        self.sql = sql
        self.data = data
        self.viz = viz
        self.error = error
    
    def __repr__(self):
        if self.success:
            return f"QueryResult(rows={len(self.data)}, cols={len(self.data.columns)})"
        return f"QueryResult(error='{self.error}')"
    
    def show(self):
        """Display the data."""
        if self.success:
            print(self.data)
        else:
            print(f"Error: {self.error}")
        return self


def quick_start(api_key: str, data_path: str, question: str, viz: bool = False):
    """One-liner for quick queries."""
    with SUTRA(api_key=api_key) as sutra:
        sutra.upload(data_path)
        return sutra.ask(question, viz=viz)


if __name__ == "__main__":
    print("""
╔══════════════════════════════════════════════════════════════╗
║                      SUTRA v0.1.2                            ║
║          Simple Unified Tool for Relational Analysis         ║
╚══════════════════════════════════════════════════════════════╝

Quick Start:
    pip install QuerySUTRA
    
    from sutra import SUTRA
    
    sutra = SUTRA(api_key="your-key")
    sutra.upload("data.csv")
    result = sutra.ask("Show me total sales", viz=True)
    
    # Export to MySQL/PostgreSQL
    sutra.save_to_mysql("host", "user", "pass", "db")
    sutra.backup()

Supported: CSV, Excel, JSON, SQL, PDF, DOCX, TXT, DataFrame
Export to: SQLite, MySQL, PostgreSQL, JSON, Excel
""")
