__version__ = '1.6.2.6'
__commit_hash__ = '461db5ab57a1a89afeab5740f5631a90cee9291f'
findlibs_dependencies = ["eckitlib"]
