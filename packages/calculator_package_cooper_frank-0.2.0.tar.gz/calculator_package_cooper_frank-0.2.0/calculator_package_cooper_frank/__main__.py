from .calculator import Calculator

def main():
    print("This is the main function running")
    print(Calculator().add(3, 3))

if __name__ == "__main__":
    main()
