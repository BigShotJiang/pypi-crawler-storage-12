API
---

.. autosummary::
    :toctree: generated

    hollowfoot.hollowfoot
    hollowfoot.hollowfoot.Hollowfoot
