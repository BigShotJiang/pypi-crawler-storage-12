Welcome to hollowfoot's documentation!
===========================================================

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    api

.. toctree::
    :maxdepth: 1
    :caption: Links
    :hidden:

    Github Repository <https://github.com/spc-group/hollowfoot>



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
