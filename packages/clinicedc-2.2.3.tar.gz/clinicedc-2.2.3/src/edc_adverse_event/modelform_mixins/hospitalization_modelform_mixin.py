from django import forms

from ..form_validators import HospitalizationFormValidator
from .ae_modelform_mixin import AeModelFormMixin


class HospitalizationModelFormMixin(AeModelFormMixin):
    form_validator_cls = HospitalizationFormValidator

    class Meta:
        help_text = {
            "subject_identifier": "(read-only)",
            "action_identifier": "(read-only)",
        }
        widgets = {
            "subject_identifier": forms.TextInput(attrs={"readonly": "readonly"}),
            "action_identifier": forms.TextInput(attrs={"readonly": "readonly"}),
        }
