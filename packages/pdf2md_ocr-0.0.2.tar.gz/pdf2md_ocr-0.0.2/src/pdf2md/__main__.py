"""Main entry point for python -m pdf2md execution."""

from .cli import main

if __name__ == "__main__":
    main()
