"""PYTEST_DONT_REWRITE"""
__version__ = "0.6.0"