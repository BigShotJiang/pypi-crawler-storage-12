from .struct import CStructType, CStruct


class CUnionType(CStructType):
    """This is a dummy yet"""

CUnion = CStruct
