
PYTEST_HEADLOCK_DIR = '.pytest-headlock'
