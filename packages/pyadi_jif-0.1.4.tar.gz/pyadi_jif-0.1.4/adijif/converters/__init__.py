"""ADI JIF converter models."""

supported_parts = [
    "ad9680",
    "adrv9009_rx",
    "adrv9009_tx",
    "ad9081_rx",
    "ad9081_tx",
    "ad9082_rx",
    "ad9082_tx",
    "ad9144",
    "ad9084_rx",
    "ad9088_rx",
]
