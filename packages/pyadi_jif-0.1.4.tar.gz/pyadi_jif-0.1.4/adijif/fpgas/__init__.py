"""ADI JIF FPGA Models and Utilities."""
