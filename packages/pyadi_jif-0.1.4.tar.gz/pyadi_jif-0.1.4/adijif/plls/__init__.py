"""ADI JIF PLL models."""

supported_parts = ["adf4371", "adf4382"]
