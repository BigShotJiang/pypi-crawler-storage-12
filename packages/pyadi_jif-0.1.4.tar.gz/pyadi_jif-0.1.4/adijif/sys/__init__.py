"""Helper methods for system level models."""
