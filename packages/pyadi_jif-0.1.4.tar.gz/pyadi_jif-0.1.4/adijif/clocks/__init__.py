"""ADI JIF clock chip models."""

supported_parts = [
    "ad9523_1",
    "ad9528",
    "ad9545",
    "hmc7044",
    "ltc6952",
    "ltc6953",
]
