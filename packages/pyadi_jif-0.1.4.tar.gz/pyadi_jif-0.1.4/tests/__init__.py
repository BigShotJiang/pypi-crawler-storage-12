"""Unit test package for adijif."""
