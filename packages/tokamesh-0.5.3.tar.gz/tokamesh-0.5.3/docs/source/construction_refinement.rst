Mesh Refinement
~~~~~~~~~~~~~~~

.. autofunction:: tokamesh.construction.refine_mesh


.. autofunction:: tokamesh.construction.trim_vertices