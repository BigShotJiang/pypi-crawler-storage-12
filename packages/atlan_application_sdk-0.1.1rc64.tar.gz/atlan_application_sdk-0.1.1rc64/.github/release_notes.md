## v0.1.1rc64 (November 14, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc63...v0.1.1rc64

### Bug Fixes

- Disable analytics tracking for DAFT (#820) (by @TechyMT in [c421233](https://github.com/atlanhq/application-sdk/commit/c421233))
