=======
Install
=======

.. _installation:

Installation
==============

Install and update using pip:

.. code-block:: console

   (.venv) $ pip install -U python-plugins



   
