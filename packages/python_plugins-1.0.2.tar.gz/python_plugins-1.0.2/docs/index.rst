Welcome to python-plugins's documentation!
============================================

**python-plugins** is a collection with common python utils.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   install
   api/index
   changes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
