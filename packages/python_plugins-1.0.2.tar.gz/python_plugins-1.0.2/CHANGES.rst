v1.0.2
------

Released 2025-11-16

- publish again

v1.0.0
------

Released 2025-11-16

- email
- sqlalchemy mixins
- crypto
- ospath.walk.remove
- examples

v0.1.0
------

Released 2024-08-27

- Init release
- set sphinx_rtd_theme as html_theme of docs
