from . import memmap2


def main() -> int:
    return memmap2.main()


if __name__ == "__main__":
    raise SystemExit(main())
