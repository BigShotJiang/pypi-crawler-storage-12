import BaseController from "./BaseController";
/**
 * @namespace com.optrabot.ui.controller
 */
export default class NotFoundController extends BaseController {
	public onInit(): void {
	}
}