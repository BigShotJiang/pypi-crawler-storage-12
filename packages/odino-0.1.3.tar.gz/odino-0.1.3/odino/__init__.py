"""
Odino - Local Semantic Search CLI

A local-only command-line tool for semantic search in code and text files.
"""

__version__ = "0.1.3"
__author__ = "Carlo Esposito"
__email__ = "carlo@aploi.de"
