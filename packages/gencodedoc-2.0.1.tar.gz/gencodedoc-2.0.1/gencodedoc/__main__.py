"""Entry point for python -m gencodedoc"""
from .cli.main import app

if __name__ == "__main__":
    app()
