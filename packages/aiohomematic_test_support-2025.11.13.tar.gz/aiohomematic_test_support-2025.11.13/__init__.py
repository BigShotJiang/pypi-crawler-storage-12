__version__ = "2025.11.13"
"""Module to support aiohomematic testing with a local client."""
