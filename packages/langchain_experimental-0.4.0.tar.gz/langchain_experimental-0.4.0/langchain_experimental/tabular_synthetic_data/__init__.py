"""Generate **tabular synthetic data** using LLM and few-shot template."""
