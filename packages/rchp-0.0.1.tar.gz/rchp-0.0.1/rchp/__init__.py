from core import parallel

__version__ = "0.0.1"