#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GUI 모듈 - 썸네일 생성 GUI 애플리케이션
"""

from .main_window import main

__all__ = ['main']

