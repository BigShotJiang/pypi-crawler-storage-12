"""
utils.js.xz contains a compressed version of the utils.js file
from Apify's fingerprint-injector:

https://github.com/apify/fingerprint-suite/blob/master/packages/fingerprint-injector/src/utils.js

Its purpose is to inject a Fingerprint object into a browser page.

Copyright 2018 Apify Technologies s.r.o.
"""
