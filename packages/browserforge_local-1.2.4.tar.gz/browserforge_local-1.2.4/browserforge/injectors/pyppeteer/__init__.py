from browserforge.injectors.utils import CheckIfInstalled

CheckIfInstalled('pyppeteer')

from .injector import NewPage
