import sys

from .cli import EntryPoint


EntryPoint()
sys.exit(0)
