import random

from .additive_simulation import SimpleNeighborhood, OmniSimulation
from .data import *
from .progress import ProgressBar


def run_mode(goal, dimension):
    simulation = OmniSimulation(SimpleNeighborhood(fcc_transform()), None, tuple([0] * (1 + dimension)))

    p = ProgressBar(goal, lambda: simulation.energy)

    for i in range(goal):
        p(i)
        simulation.add_atom(lambda l: random.randrange(l))

    simulation.interactive(dimension)
