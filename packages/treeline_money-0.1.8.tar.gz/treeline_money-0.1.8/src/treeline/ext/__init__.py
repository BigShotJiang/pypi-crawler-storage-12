"""Public API for user extensions."""

from treeline.ext.decorators import tagger

__all__ = ["tagger"]
