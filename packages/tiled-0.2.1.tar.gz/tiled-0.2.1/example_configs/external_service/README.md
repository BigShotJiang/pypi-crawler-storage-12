This is just an initial sketch.
