"""API module for HCLI."""
