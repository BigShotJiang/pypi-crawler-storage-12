# Unofficial Textverified API client in Python #

## ℹ️ About the Project
<b>This library is designed to access the <a href="https://www.textverified.com/docs/api/v2#overview">TextVerified API</a> using an asynchronous Python client.</b>

---

## 🏎 The difference between the official and my code
🐢 <a href = "https://pypi.org/project/textverified/">The official Python client</a> uses a <b>slow http.client</b>, and also stops the main stream (for example, the client.sms.incoming function)


🚀 My client uses <b>aiohttp</b> as a request handler, and also has support for <i>create_task</i> and <i>gather</i> processes without blocking the main flow.


🔐 This client also supports <b>Bearer tokens</b> and automatically generates them after they expire for secure access to the API (just like the official client, but <b>faster</b>)

## 💻 Installation
Library download is recommended for Python >= 3.9

```
pip install textverified_async
```

## 🛠 Usage
Current available methods:

- [x] Account Info
- [x] Bearer Token
- [ ] Service List
- [ ] Sales
- [ ] Billing Cycles
- [ ] Back order rental reservation
- [x] List Reservations
- [ ] Verifications (Soon)
- [ ] New Rental / Verification
- [x] Renewable Rentals
- [x] NonRenewable Rentals
- [x] SMS
- [ ] Calls and Voices
- [x] Wake Requests
- [ ] Webhook
- [ ] Legacy

There is no documentation yet, but it is quite easy to use.
You can also hold down CTRL on the client and view the available functions and models, or get the current mini-documentation by hovering over the function.

Import the library

```python
from textverified_async.api import TextVerifiedApi
```

Then create an API class (it will automatically create a session and token)

```python
api = TextVerifiedApi(“api-key”, “username”)
```

Next, you can safely use commands from the API using its class

For example:
```python
info = await api.get_account_info()
```

### Note: If you want to get the information you need right away, put the asynchronous function in parentheses ###
Example:
```python
balance = (await api.get_account_info()).currentBalance
```

All responses from the API will have the same value as in Textverified REST.API

## 📋 Example
Here is an example of code for using the client (you will also see this code in the api.py class of the library):

```python
from textverified_async.api import TextVerifiedApi

# Usage
async def main():
    api = TextVerifiedApi(“api”, “mail”)
    
    await api.generate_bearer ()
    status = await api.check_token_status()
    print(f“Token status: {status}”)

    try:
        # Get all rented numbers
        all_rentals = await api.get_rentals()
        print(f“Found {len(all_rentals)} rentals:”)

        for rental in all_rentals:
            print(f“- {rental.serviceName}: {rental.number} ({rental.state})”)
                
        # Example of getting detailed information about a specific number
        if all_rentals:
            first_rental = all_rentals[0]
            print(f“\nGetting details for rental: {first_rental.id}”)

            rental_details = await api.get_rental_by_id(first_rental.id)

			print(f“Detailed info for {rental_details.number}:”)
			print(f“  Service: {rental_details.serviceName}”)
			print(f“  State: {rental_details.state}”)
            print(f“  Always on: {rental_details.alwaysOn}”)
            print(f“  Can refund: {rental_details.refund.canRefund}”)
            print(f“  Billing cycle ID: {rental_details.billingCycleId}”)

        wake = await api.wake_up_reservation(first_rental.id)
        print(f“\nWoke up {wake.usageWindowStart} | Woke down {wake.usageWindowEnd} with wake ID {wake.id}”)
                
    except Exception as e:
        print(f“Error: {e}”)


if __name__ == “__main__”:
    asyncio.run(main())
```