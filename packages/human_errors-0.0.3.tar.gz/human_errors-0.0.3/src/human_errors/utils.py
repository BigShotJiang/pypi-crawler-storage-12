from typing import Literal

from rich.console import Console

renderer_type: Literal["default", "miette"] = "default"
console = Console()
