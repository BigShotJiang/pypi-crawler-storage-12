# Architecture

--8<-- "ARCH.md"

