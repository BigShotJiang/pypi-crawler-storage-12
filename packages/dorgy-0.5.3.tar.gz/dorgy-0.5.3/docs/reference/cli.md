# CLI Reference

::: mkdocs-click
    :module: dorgy.cli.app
    :command: cli

