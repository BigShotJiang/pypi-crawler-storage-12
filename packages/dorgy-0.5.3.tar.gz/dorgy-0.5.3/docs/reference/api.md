# API Reference

The public Python surface is primarily the CLI and helpers used by commands. The following index exposes module docstrings and callable signatures.

::: dorgy
    options:
      show_root_heading: true
      show_source: false
      docstring_style: google

