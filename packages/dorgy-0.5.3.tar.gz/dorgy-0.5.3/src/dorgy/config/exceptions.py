"""Exception types raised by the configuration subsystem."""


class ConfigError(Exception):
    """Raised when configuration data cannot be processed."""
