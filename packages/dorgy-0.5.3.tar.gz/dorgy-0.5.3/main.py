"""Console-script shim for invoking the Dorgy CLI."""

from dorgy.cli import main

if __name__ == "__main__":
    main()
