"""Brewse - An interactive TUI browser for Homebrew packages."""

__version__ = "0.1.2"
