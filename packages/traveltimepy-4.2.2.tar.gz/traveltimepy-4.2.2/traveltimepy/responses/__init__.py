"""Module with traveltime responses models."""
