"""Module with traveltime requests models."""
