import sys

if __name__ != '__init__':
    sys.path.append(__path__[0])
__version__ = 'V1'
