from flask import Flask, render_template, jsonify

app = Flask(__name__)

# Sample data for dropdown including labels
data = {
    "Option 1": {
        "label1": "Label for Input 1A",
        "label2": "Label for Input 1B",
        "input1": "Value 1A",
        "input2": "Value 1B",
    },
    "Option 2": {
        "label1": "Label for Input 2A",
        "label2": "Label for Input 2B",
        "input1": "Value 2A",
        "input2": "Value 2B",
    },
    "Option 3": {
        "label1": "Label for Input 3A",
        "label2": "Label for Input 3B",
        "input1": "Value 3A",
        "input2": "Value 3B",
    },
}

@app.route('/')
def index():
    return render_template('bbb.html', options=data.keys())

@app.route('/get_values/<option>')
def get_values(option):
    values = data.get(option, {})
    return jsonify(values)

if __name__ == '__main__':
    app.run(debug=True)
