"""Version information for myfy-core package."""

__version__ = "0.1.0a42"
