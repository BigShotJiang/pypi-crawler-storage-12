def main():
    print("Hello from mx-rec!")


if __name__ == "__main__":
    main()
