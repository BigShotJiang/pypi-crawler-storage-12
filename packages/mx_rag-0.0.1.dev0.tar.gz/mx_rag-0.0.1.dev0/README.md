*WARNING*:This project is not functional and is a placeholder form HUAWEI Ascend

Please refer to homepage https://gitcode.com/Ascend/RagSDK
