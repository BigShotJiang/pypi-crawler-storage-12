from pyuvm import uvm_sequencer

__ALL__ = ['Sequencer']


class Sequencer(uvm_sequencer):
    pass
