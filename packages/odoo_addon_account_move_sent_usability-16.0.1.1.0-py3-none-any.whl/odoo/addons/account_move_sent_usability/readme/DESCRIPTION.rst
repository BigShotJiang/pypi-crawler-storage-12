This module allows to search on Unsent or Sent moves and to display
the field on move form.

* Filter:

.. figure:: ../static/images/sent_filter.png
   :alt: Sent Filter

* Form:

.. figure:: ../static/images/sent_form.png
   :alt: Sent field on Form
