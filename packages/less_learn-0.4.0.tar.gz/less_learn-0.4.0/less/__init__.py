from .less import LESSBRegressor, LESSARegressor

__all__ = ["LESSBRegressor", "LESSARegressor"]
__version__ = "0.4.0"
