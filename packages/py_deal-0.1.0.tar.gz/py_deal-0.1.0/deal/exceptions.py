class EnvValidationError(Exception):
    """Raised when an environment variable is missing or has wrong type."""