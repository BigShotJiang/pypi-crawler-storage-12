# Installation

To install Matplotgl and all of its dependencies, use

`````{tab-set}
````{tab-item} pip
```sh
pip install matplotgl
```
````
````{tab-item} conda
```sh
conda install -c conda-forge matplotgl
```
````
`````
