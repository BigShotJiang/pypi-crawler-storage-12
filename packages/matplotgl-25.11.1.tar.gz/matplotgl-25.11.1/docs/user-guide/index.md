# User Guide

```{toctree}
---
maxdepth: 1
---

installation
plot
scatter
imshow
```
