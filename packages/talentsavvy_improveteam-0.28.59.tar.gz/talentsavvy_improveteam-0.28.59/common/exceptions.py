class DateInvalidError(RuntimeError):
    """Exception raised for custom error scenarios.

    Attributes:
        message -- explanation of the error
    """

    def __init__(self, message):
        self.message = message
        super().__init__(f"DateInvalid: {self.message}")


class NoDataToProcessError(RuntimeError):
    """Exception raised for custom error scenarios.

    Attributes:
        message -- explanation of the error
    """

    def __init__(self, message):
        self.message = message
        super().__init__(f"NoDataToProcess: {self.message}")


class IllegalArgumentError(ValueError):
    """Exception raised for custom error scenarios.

    Attributes:
        message -- explanation of the error
    """

    def __init__(self, message):
        self.message = message
        super().__init__(f"IllegalArgumentError: {self.message}")


class ProjectNotFoundError(RuntimeError):
    """Exception raised for custom error scenarios.

    Attributes:
        message -- explanation of the error
    """

    def __init__(self, message):
        self.message = message
        super().__init__(f"ProjectNotFound: {self.message}")

class StageNotFoundError(RuntimeError):
    """Exception raised for custom error scenarios.

    Attributes:
        message -- explanation of the error
    """

    def __init__(self, message):
        self.message = message
        super().__init__(f"StageNotFoundError: {self.message}")

