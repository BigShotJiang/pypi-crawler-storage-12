"""
Common utilities and classes for data extraction scripts.
"""

