tobiko.tripleo.pacemaker
------------------------

.. automodule:: tobiko.tripleo.pacemaker
    :members:
    :imported-members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
