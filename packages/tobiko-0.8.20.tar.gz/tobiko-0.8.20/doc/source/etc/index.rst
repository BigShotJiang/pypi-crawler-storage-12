.. _configuring:

===================
Configuration Files
===================

Tobiko accept below configuration files

.. toctree::
   :maxdepth: 2

   tobiko.conf
