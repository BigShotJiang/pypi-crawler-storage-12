This file is here only to make sure this folder exists on Git repository.
