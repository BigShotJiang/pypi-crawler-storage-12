# Factorio Randomizer

This python package creates Factorio mod files that randomizes the game, based on a JSON file.
Intended to be used by [Randovania](https://randovania.org/).