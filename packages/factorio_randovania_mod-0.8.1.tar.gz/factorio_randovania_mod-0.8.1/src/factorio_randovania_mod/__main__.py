import factorio_randovania_mod.cli

factorio_randovania_mod.cli.main()
