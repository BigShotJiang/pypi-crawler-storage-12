---@meta
---@class Blob
local Blob = {}

---Decodes a string via length prefix
---@param self Blob
---@return string
function Blob:prefixstring()
end