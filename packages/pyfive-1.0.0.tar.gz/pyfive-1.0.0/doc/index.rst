Welcome to Pyfive Documentation!
================================

.. include:: _sidebar.rst.inc

.. _fig_how_it_works:
.. figure:: /figures/Pyfive-logo.png
   :align: center
   :width: 80%

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
