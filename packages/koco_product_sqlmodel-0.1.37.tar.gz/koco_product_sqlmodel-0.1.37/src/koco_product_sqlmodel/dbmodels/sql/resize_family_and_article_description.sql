ALTER TABLE cfamily MODIFY description NVARCHAR(4096);
ALTER TABLE cfamily MODIFY short_description NVARCHAR(1024);
ALTER TABLE carticle MODIFY short_description NVARCHAR(1024);