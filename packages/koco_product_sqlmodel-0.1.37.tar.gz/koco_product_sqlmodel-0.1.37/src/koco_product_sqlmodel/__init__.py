def hello() -> str:
    return "Hello from koco-product-sqlmodel!"
