# tree-sitter-vie

[![Crates.io](https://img.shields.io/crates/v/tree-sitter-vie.svg?logo=rust&logoColor=white)](https://crates.io/crates/tree-sitter-vie)
[![npm](https://img.shields.io/npm/v/tree-sitter-vie.svg?logo=npm)](https://www.npmjs.com/package/tree-sitter-vie)
[![PyPI](https://img.shields.io/pypi/v/tree-sitter-vie.svg?logo=pypi)](https://pypi.org/project/tree-sitter-vie)

Vie grammar for [tree-sitter](https://tree-sitter.github.io/tree-sitter/index.html).

<img width="500" alt="1760093620_screenshot" src="https://github.com/user-attachments/assets/b557b160-7b08-4ee1-b3d7-ec0dd9e6a235" />
