"""
Core utilities and dependencies.
"""

from .dependencies import get_client_ip

__all__ = ["get_client_ip"]
