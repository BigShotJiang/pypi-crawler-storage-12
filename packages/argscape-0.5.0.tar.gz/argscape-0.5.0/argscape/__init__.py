"""
Argscape package initialization.
""" 

__version__ = "0.5.0"
