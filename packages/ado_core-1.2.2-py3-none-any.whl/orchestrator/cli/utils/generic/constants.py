# Copyright (c) IBM Corporation
# SPDX-License-Identifier: MIT

from __future__ import annotations

SECONDS_IN_A_MINUTE = 60
SECONDS_IN_AN_HOUR = 3600
SECONDS_IN_A_DAY = 86400
