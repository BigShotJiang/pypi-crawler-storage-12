This module adds to the database the nomenclature of localities from
Romania
