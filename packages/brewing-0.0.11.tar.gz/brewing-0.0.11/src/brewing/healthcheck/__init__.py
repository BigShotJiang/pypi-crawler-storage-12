"""An HTTP healthcheck implementation."""
