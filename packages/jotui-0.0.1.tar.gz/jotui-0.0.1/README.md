# jotui

A Textual TUI for quick, timestamped project notes (“jots”) stored in plain-text Markdown.

> The first usable MVP will follow soon.

## Install

```bash
pip install jotui
