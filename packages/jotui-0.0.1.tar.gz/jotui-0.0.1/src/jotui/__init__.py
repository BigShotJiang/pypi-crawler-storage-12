# src/jotui/__init__.py
"""jotui — a Textual TUI for timestamped project notes (placeholder 0.0.1)."""

__all__ = ["__version__"]

__version__ = "0.0.1"