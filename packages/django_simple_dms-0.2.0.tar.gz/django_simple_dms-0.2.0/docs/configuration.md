# Configuration

This section describes how to configure `django-simple-dms`.
