# Welcome to django-xchange

This is the documentation for the django-xchange library.

`django-simple-dms` is a Django library for simple document management.

## Features

*

## Demo

A demo Django application is provided in tests/demo folder.

To set it up run once `python manage.py demo`

To run the demo server: `python manage.py runserver` and go to http://127.0.0.1:8000/

### API

...

You can test it with [httpie](https://httpie.io/) (provided by the development dependencies).
