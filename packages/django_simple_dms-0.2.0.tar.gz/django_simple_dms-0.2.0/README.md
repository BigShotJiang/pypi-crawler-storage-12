Django Simple DMS
=================

[![Pypi](https://badge.fury.io/py/django-xchange.svg)](https://badge.fury.io/py/django-xchange)
[![coverage](https://codecov.io/github/k-tech-italy/django-xchange/coverage.svg?branch=develop)](https://codecov.io/github/k-tech-italy/django-xchange?branch=develop)
[![Test](https://github.com/k-tech-italy/django-xchange/actions/workflows/tests.yaml/badge.svg)](https://github.com/k-tech-italy/django-xchange/actions/workflows/tests.yaml)
[![Docs](https://img.shields.io/badge/stable-blue)](https://k-tech-italy.github.io/django-xchange/)
[![Django](https://img.shields.io/pypi/frameworkversions/django/django-xchange)](https://pypi.org/project/django-xchange/)
[![Supported Python versions](https://img.shields.io/pypi/pyversions/django-xchange.svg)](https://pypi.org/project/django-xchange/)

Django Simple DMS is a library providing a simple document management system.

How to use
----------


Third-party libraries
---------------------
