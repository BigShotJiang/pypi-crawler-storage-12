"""
Pydantic schemas for request/response validation.
Extracted from routers for better organization.
"""
