from pgtq import PGTQ

def test_import():
    assert PGTQ is not None
