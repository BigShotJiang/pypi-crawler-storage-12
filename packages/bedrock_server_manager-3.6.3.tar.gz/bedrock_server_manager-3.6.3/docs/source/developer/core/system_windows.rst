.. Bedrock Server Manager System Windows Core documentation file

System Windows Core Documentation
=================================

.. automodule:: bedrock_server_manager.core.system.windows
   :members:
   :undoc-members:
   :exclude-members: BEDROCK_EXECUTABLE_NAME, PIPE_NAME_TEMPLATE