.. Bedrock Server Manager Plugins API documentation file

Plugins API Documentation
=========================

.. automodule:: bedrock_server_manager.api.plugins
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource