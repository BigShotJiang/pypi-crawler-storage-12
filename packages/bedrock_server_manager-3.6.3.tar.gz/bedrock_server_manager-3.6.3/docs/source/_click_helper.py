from bedrock_server_manager.__main__ import create_cli_app

cli = create_cli_app()
