"""Workstack land-stack command: Land stacked PRs sequentially from bottom to top."""

from workstack.cli.commands.land_stack.command import land_stack

__all__ = ["land_stack"]
