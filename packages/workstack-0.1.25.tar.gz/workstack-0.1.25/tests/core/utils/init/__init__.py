"""Tests for init_utils module - pure business logic for init operations."""
