"""Tests for Graphite integration commands."""
