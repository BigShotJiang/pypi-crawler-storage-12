"""Tests for dot-agent-kit."""
