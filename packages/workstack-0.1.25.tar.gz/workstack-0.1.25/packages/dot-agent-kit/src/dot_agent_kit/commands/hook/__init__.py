"""Hook command group and commands."""

from dot_agent_kit.commands.hook.group import hook_group

__all__ = ["hook_group"]
