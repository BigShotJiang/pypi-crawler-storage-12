"""Artifact inspection commands."""

from dot_agent_kit.commands.artifact.group import artifact_group

__all__ = ["artifact_group"]
