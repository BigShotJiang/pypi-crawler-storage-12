Authors
=======

Xiaohao Yang and Billinge Group members

Contributors
------------

For a list of contributors, visit
https://github.com/diffpy/diffpy.srxplanar/graphs/contributors
