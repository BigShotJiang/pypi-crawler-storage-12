## History

### 0.1.0 (2020-03-02)
* First release on PyPI.
