from .alpha import ALPHA
from .sgwr import SGWR
from . import fastsgwr
