FastSGWR: "Enhancing the Computational Efficiency of the SGWR Model and Introducing Its Software Implementation." This article along the python packages (parallel & sequential), and a Graphic User Interface (GUI) tool named 'SGWR Model' is developed based on this article :SGWR: similarity and geographically weighted regression (https://doi.org/10.1080/13658816.2024.2342319).  

Author info
------------
- Code Author: M. Naser Lessani (GIBD)
- Realeased Year: 2025
- Affiliation: Geoinformation and Big Data Research Laboratory (GIBD), Department of Geography, The Pennsylvania State University, University Park, PA, USA

Overview
--------
The SGWR (Similarity and Geographically Weighted Regression) model is a novel local spatial regression model that extends the conventional GWR by incorporating both geographical proximity and attribute similarity into a composite spatial weight matrix. The  combination of spatial and attribute-based weights is governed by a parameter alpha, which is optimized based on AICc measure.

This Python package includes:
- MPI-enabled parallel implementations of the SGWR
- Serial version of the SGWR model
- Support for Gaussian and bi-square kernels
- Also, supports a combination of adaptive bisquare and gaussian

Key Features
------------
- Parallel Computation with MPI: Achieve substantial runtime reductions using multiple CPU cores.
- Alpha Optimization: Automatically tune the contribution of similarity and spatial proximity.
- Kernel Flexibility: Choose between Gaussian (default) and bi-square kernels.
- Also, users have the ability to either chose standardize or don't standardize their data
- Evaluation Metrics: Outputs include R², adjusted R², AICc, and other metrics
- Also, users can run the GWR model in both parallel and serial version of this library

Installation Requirements
-------------------------
Ensure the following dependencies are installed:

Standard Python Libraries:
- os
- argparse
- datetime
- math
- copy
- typing (Optional)
- itertools (combinations)

MPI and CLI:
- mpi4py
- click

Numerical and Data Handling:
- numpy
- pandas
- scipy (stats, linalg, spatial.distance)

Machine Learning and Metrics:
- scikit-learn (metrics)

Specialized Geospatial Modeling:
- spglm (family, glm, iwls, utils)


Data Format
-----------
Input data must be a CSV file with the following column order:

longitude, latitude, dependent_variable, independent_variable_1, ..., independent_variable_n

Categorical variables must be pre-processed into dummy variables.
Example: For a 3-class variable ("urban", "peri-urban", "rural"), create:
- urban_dummy: 1 if urban, else 0
- peri_urban_dummy: 1 if peri-urban, else 0
- Rural becomes the reference class (excluded)

Usage
-----
After preparing your dataset and ensuring all dependencies are installed, the model can be run via the command line:

MPI Commands (parallel):
----------------------------
- fastsgwr run -np x -data path_to_data (by default the kernel is Gaussian function, and doesn't standardize the data)
- fastsgwr run -np x -data path_to_data -standardize (using Gaussian function and standardize the input data)
- fastsgwr run -np x -data path_to_data -bisquare 
- fastsgwr run -np x -data path_to_data -bisquare -standardize
- fastsgwr run -np x -data path_to_data -biga (adaptive bisquare and gaussian)
- fastsgwr run -np x -data path__to_data -gwr (run gwr as well in parallel)
- x: Number of cores
- path_to_data: Path to the CSV dataset

The output will be a CSV file saved in the same input directory, and containing local coefficients and performance metrics.
PI Commands (parallel):

Serial commands:
----------------------------
- selector = ALPHA(g_coords, g_y, g_x, data, fixed=True, kernel='gaussian') ## for fixed bandwidth and gaussian kernel
- bw, alpha = selector.fit()
- sgwr_model = SGWR(g_coords, g_y, g_x, bw, data, alpha, fixed=True, kernel='gaussian') ## after bandwidth and alpha optimizationi
- result = sgwr_model.fit()
- selector = ALPHA(g_coords, g_y, g_x, data) ## for adaptive bandwidth and bisquare kernel
- bw, alpha = selector.fit()
- sgwr_model = SGWR(g_coords, g_y, g_x, bw, data, alpha) 
- result = sgwr_model.fit()

Parameter extraction when running in serial mode:
----------------------------
- result.R2
- result.adj_R2
- result.aicc
- result.aic
- result.params
- result.bse
- result.localR2
- result.filter_tvals()
- result.filter_tvals(alpha=0.05) ### t values with 95% confidence interval
- result.summary()

Citation
--------
If you use this package in your work, please cite the following articles:

1. Lessani, M. Naser, and Zhenlong Li. "SGWR: similarity and geographically weighted regression." International Journal of Geographical Information Science 38, no. 7 (2024): 1232-1255.
2. Lessani, M. Naser, and Zhenlong Li. "Enhancing the Computational Efficiency of the SGWR Model and Introducing Its Software Implementation." Annals of GIS (2025).
