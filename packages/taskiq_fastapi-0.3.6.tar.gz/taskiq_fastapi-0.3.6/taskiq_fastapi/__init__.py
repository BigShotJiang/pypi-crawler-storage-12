"""FastAPI integration for Taskiq project."""
from taskiq_fastapi.initializator import init, populate_dependency_context

__all__ = ["init", "populate_dependency_context"]
