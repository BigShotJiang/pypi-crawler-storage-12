"""
init for zapish_logger
"""

from zapish_logger.logger import (
    file_logger,
    console_logger,
    read_log_file,
    file_and_console_logger,
    custom_logger,
    LoggingConfig,
)
