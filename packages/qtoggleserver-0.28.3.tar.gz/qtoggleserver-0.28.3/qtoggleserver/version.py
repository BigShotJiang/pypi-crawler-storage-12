VERSION = "0.28.3"
VENDOR = "qtoggle/qtoggleserver"
