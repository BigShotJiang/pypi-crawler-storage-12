"""
Module listing all public method from the methodo modules

You should put here all methods doing some kind of algorithmic transformation of domain/db models.
"""
from ecodev_sankey.methodo.process_input_file import process_file

__all__ = ['process_file']


