//! integraton-style tests

mod compile;
mod parse;
