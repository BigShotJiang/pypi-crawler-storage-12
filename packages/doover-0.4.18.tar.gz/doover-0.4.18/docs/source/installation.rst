Getting Started
===============

For a quickstart and tutorials, please see the main Doover documentation at `docs.doover.com <https://docs.doover.com>`_.

Installing
----------

You can install the `pydoover` package using your preferred python package manager:


.. code-block:: bash

    # using UV
    uv add pydoover

    # using pip
    pip install pydoover
