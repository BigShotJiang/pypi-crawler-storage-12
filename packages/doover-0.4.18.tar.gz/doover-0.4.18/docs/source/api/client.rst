.. py:currentmodule:: pydoover

Client
======

.. autoclass:: pydoover.cloud.api.Client
   :members:
