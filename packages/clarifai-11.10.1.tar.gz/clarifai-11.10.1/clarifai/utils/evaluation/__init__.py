from .main import EvalResultCompare

__all__ = ["EvalResultCompare"]
