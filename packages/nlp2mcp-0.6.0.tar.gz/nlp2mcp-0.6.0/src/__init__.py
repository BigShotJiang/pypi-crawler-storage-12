"""NLP2MCP: Convert GAMS NLP models to MCP via KKT conditions."""

__version__ = "0.6.0"
