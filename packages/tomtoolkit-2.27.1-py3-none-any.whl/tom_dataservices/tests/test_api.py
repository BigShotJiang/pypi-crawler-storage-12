from django.test import TestCase


class TestRSP(TestCase):
    pass
