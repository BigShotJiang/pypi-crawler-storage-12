from django.apps import AppConfig


class TomObservationsConfig(AppConfig):
    name = 'tom_observations'
