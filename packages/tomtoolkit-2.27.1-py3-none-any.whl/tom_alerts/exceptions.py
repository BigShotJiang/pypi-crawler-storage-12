class AlertSubmissionException(Exception):
    """
    The AlertSubmissionException should be used when an alert fails to be submitted to an upstream broker.
    """
