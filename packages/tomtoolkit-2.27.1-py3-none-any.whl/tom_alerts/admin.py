from django.contrib import admin

from tom_alerts.models import BrokerQuery

admin.site.register(BrokerQuery)

# Register your models here.
