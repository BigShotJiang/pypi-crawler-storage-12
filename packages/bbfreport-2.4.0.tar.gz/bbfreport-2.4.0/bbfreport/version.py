# do not edit! this file was created from PROJECT.yaml by project-parser.py

__version__ = 'v2.4.0'
__version_date__ = '2025-11-11'
