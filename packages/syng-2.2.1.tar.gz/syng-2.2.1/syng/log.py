import logging

logger = logging.getLogger("Syng")
