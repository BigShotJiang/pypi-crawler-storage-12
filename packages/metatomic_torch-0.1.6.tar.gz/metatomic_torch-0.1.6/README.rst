metatensor-torch
================

This package contains the TorchScript bindings to the core API of metatensor.
