import django.dispatch

# Internal signal for event distribution
internal_signal = django.dispatch.Signal()


