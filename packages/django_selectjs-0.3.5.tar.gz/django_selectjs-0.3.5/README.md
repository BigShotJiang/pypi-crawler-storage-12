# Django SelectJS

A replacement for Select2 that uses plain HTML and Javascript

## Quick start


### Modify settings.py

```
INSTALLED_APPS = [
    ...
    'selectjs',
    ...
]
```

