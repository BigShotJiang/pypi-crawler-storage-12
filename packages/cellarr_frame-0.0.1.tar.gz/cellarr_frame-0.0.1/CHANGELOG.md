# Changelog

## Version 0.0.1

- Initial release of the classes with tests and documentation
