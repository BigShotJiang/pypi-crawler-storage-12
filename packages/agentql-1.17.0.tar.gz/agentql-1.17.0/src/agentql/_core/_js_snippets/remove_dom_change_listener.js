(() => {
  if (window.domUpdateObserver) {
    window.domUpdateObserver.disconnect();
    delete window.domUpdateObserver;
  }
})();
