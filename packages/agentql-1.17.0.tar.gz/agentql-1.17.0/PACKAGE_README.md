# Tiny Fish AgentQL Python Client

A Python client for Tiny Fish AgentQL - a new way to interact with the web.
