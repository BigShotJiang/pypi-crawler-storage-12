default_app_config = 'finance_sdk.apps.FinanceSdkConfig'
__version__ = '1.0.2'