# horsetalk

[![PyPI version](https://badge.fury.io/py/horsetalk.svg)](https://badge.fury.io/py/horsetalk)
![GitHub last commit (master)](https://img.shields.io/github/last-commit/peaky76/horsetalk/master)
[![Documentation Status](https://readthedocs.org/projects/horsetalk/badge/?version=latest)](https://horsetalk.readthedocs.io/en/latest/?badge=latest)
![GitHub repo size](https://img.shields.io/github/repo-size/peaky76/horsetalk)

A library of enums and parsers for common horseracing terminology
