
# aggregated_point_extraction module

::: skiba.aggregated_point_extraction