# buffer_method code

::: skiba.buffer_method