# Need help?

Do you have further questions or a problem with `HyperSHAP` and do not know how to continue?

1. Check the [examples](https://github.com/automl/HyperSHAP/tree/main/examples), maybe you can find a suitable solution.
2. Check the [GitHub issues](https://github.com/automl/hypershap/issues), maybe someone else has been in a similar situation already.
3. If you could not find anything related, please [create a help issue](https://github.com/automl/hypershap/issues).
