# License

This program is free software: you can redistribute it and/or modify it under the terms of the 3-clause BSD license
(please see the [LICENSE](https://github.com/automl/HyperSHAP/blob/main/LICENSE) file).
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
You should have received a copy of the 3-clause BSD license along with this program
(see [LICENSE](https://github.com/automl/HyperSHAP/blob/main/LICENSE) file). If not, see [BSD-3-Clause license](https://opensource.org/license/BSD-3-Clause).
