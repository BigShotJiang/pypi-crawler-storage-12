# Authors

## Core Development

- [Marcel Wever](https://www.marcelwever.de){target="_blank"}

## Contributions
- [Maximilian Muschalik](https://maxmuschalik.com/){target="_blank"}
- [Fabian Fumagalli](https://fabianfumagalli.com/){target="_blank"}
