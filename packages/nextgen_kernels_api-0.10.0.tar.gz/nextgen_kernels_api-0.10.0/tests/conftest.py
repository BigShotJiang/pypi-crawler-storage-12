"""Pytest configuration and fixtures for nextgen-kernels-api tests."""

import pytest

# Import pytest-jupyter fixtures for Jupyter Server
pytest_plugins = ["pytest_jupyter.jupyter_server"]
