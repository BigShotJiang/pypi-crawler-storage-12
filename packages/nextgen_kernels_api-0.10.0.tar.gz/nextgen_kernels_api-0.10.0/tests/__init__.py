"""Unit tests for nextgen-kernels-api."""
