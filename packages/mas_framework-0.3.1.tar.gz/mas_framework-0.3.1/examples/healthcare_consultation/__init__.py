"""Healthcare consultation example using gateway mode for HIPAA compliance."""
