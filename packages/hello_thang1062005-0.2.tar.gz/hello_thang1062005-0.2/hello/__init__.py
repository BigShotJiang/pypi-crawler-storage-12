from .main import hello
# __init__ tell python cả cái thư mục hello này coi là 1 package
# kiểm soát những gì có sẵn khi package được import
# bằng việc import hello function từ main , bạn cho phép user acess that function str8 from the package
# from hello import hello