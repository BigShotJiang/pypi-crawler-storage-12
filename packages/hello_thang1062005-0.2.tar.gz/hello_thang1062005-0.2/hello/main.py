def hello():
    print('you gay')