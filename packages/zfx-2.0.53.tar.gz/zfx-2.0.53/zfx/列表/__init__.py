from .取最大值 import 取最大值  # 获取列表中的最大值
from .取最小值 import 取最小值  # 获取列表中的最小值
from .取平均值 import 取平均值  # 计算列表中元素的平均值
from .去重 import 去重  # 去除列表中重复元素
from .反转 import 反转  # 将列表元素顺序颠倒
from .升序排序 import 升序排序  # 列表升序排列
from .降序排序 import 降序排序  # 列表降序排列
from .分割为固定大小 import 分割为固定大小  # 将列表分割成固定大小的小列表
