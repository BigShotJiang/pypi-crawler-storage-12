"""Top-level package for celltraj."""

__author__ = """Jeremy Copperman"""
__email__ = 'copperma@ohsu.edu'
__version__ = '0.1.0'
