"""Flerity Core - Shared domain logic and utilities."""

__version__ = "0.1.0"
