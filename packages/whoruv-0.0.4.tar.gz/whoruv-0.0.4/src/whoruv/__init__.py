from ._core import whoruv, PythonInfo

__all__ = ["whoruv", "PythonInfo"]
