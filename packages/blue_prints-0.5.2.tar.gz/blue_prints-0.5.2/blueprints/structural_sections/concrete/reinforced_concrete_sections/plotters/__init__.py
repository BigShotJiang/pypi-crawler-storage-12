"""Default plotters for Blueprint's reinforced concrete sections."""
