"""Structural sections package."""
