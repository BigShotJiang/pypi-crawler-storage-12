"""Default plotters for Blueprint's steel cross sections."""
