"""Module containing all formulas from EN 1992-2:2005: Chapter 5 - Structural Analysis."""
