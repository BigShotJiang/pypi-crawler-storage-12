"""Package containing all formulas from EN 1993-1-9:2005: Annex A - Determination of fatigue load parameters and verification formats."""
