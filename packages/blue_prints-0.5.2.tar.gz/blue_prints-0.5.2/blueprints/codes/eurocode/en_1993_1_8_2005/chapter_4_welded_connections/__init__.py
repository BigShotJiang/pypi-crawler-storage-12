"""Package containing all formulas from EN 1993-1-8:2005: Chapter 4 - Welded Connections."""
