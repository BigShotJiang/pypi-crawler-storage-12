"""Package contains the formulas of chapter 3: 'Materials' of EN 1993-1-1:2005."""
