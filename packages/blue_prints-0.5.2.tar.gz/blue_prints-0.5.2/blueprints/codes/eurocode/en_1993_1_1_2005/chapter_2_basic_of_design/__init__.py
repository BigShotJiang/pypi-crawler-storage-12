"""Package contains the formulas of chapter 2: 'Basic of design' of EN 1993-1-1:2005."""
