"""CUR-228 package."""

from blueprints.type_alias import M

CUR_228 = "CUR 228"

R_0: M = 0.3
