"""Module with scripts for generating documentation."""
