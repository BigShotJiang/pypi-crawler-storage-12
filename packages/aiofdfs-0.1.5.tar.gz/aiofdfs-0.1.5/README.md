[TOC]

# Async FastDFS Client 使用说明

本项目基于 `Async_Fdfs_Client` 实现 FastDFS 的 **异步文件上传与下载**。

本文介绍如何使用 `Async_Fdfs_Client` 实现 **本地和基于Fastapi的文件上传与下载**。

当前依赖仅上传了私服，所以安装，请先获取私服地址和相关认证信息，然后安装：
```bash
pip install aiofdfs
```

# 1. 本地文件的上传下载

在纯脚本环境下可直接使用 `Async_Fdfs_Client` 提供的异步方法实现 FastDFS 文件的上传与下载。
首先初始化配置。
```python
from aiofdfs import FastDfsConf

def get_fdfs_conf():
    return FastDfsConf(
        tracker_servers=['192.168.0.50:22122'],
        connect_timeout=3,
        network_timeout=3,
        # 第几个目录，如果不配置或配置为-1则表示不控制；
        # 大于等于0的值，将严格控制上传的目录
        store_path_index=1
    )
```
下面用单元测试的方式介绍本地文件上传与下载。

## 1.1. 文件上传

```python
@pytest.mark.asyncio
async def test_upload_file():
    conf = get_fdfs_conf()
    async with Async_Fdfs_Client(conf) as fdfs_client:
        # 要上传的本地文件
        local_file = 'E:/demo.zip'
        ret = await fdfs_client.upload_by_filename(local_file)
        print(ret)
```

返回示例：

```json
{
  "group_name": "group1",
  "file_id": "group1/M01/00/00/xxxxxx.zip",
  "file_name": "demo.zip",
  "file_size": "20MB",
  "storage_ip": "192.168.0.50"
}
```

## 1.2. 文件下载

```python
@pytest.mark.asyncio
async def test_download_file():
    conf = get_fdfs_conf()
    async with Async_Fdfs_Client(conf) as fdfs_client:
        # 下载到本地的文件路径
        local_file_name = 'E:/demo.zip'
        remote_file_id = 'group1/M01/00/00/xxxxxx.zip'
        ret = await fdfs_client.download_to_file(local_file_name, remote_file_id)
        print(ret)
```
结果示例如下：
```bash
{
    'file_id': 'group1/M01/00/00/xxxxxx.zip',
    # 本地文件路径
    'content': 'E:/demo.zip', 
    'download_size': '20MB', 
    'storage_ip': b'192.168.0.50'
}
```

# 2. 与 FastAPI 结合实现上传下载

提供更贴近业务的接口形式，可在实际服务中直接使用。

初始化客户端示例代码：
```python
from aiofdfs import FastDfsConf, Async_Fdfs_Client

def get_fdfs_conf():
    return FastDfsConf(
        tracker_servers=['192.168.0.50:22122'],
        connect_timeout=3,
        network_timeout=3,
        # 第几个目录，如果不配置或配置为-1则表示不控制；
        # 大于等于0的值，将严格控制上传的目录
        store_path_index=1
    )
# 初始化客户端
fdfs_client = Async_Fdfs_Client(get_fdfs_conf())
```

## 2.1. 文件上传接口

```python
@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    result = await fdfs_client.upload_by_upload_file(file)
    return result
```

返回示例：

```json
{
  "group_name": "group1",
  "file_id": "group1/M01/00/04/xxxxxx.pdf",
  "file_name": "example.pdf",
  "file_size": "100KB",
  "storage_ip": "192.168.0.50"
}
```


## 2.2. 文件下载接口

```python
@app.get("/download")
async def download(file_id: str):
    meta_data = await fdfs_client.get_meta_data(file_id)
    file_name = meta_data.get("OriginFileName")
    file_size = meta_data.get("OriginFileSize")
    headers = {
        "Content-Disposition": f'attachment; filename="{file_name}"',
        "Content-Length": str(file_size)
    }
    return StreamingResponse(fdfs_client.download_to_generator(file_id), 
                             headers=headers, 
                             media_type="application/octet-stream")
```

通过浏览器/客户端即可直接下载。


# 3. REST Client 测试脚本（VSCode）

支持使用 VS Code 的 REST Client 插件快速验证接口。

## 3.1. 上传文件

```bash
###
POST http://localhost:8000/upload
Content-Type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW

------WebKitFormBoundary7MA4YWxkTrZu0gW
Content-Disposition: form-data; name="file"; filename="example.pdf"
Content-Type: application/pdf

< E:\demo\example.pdf
------WebKitFormBoundary7MA4YWxkTrZu0gW
Content-Disposition: form-data; name="json_data"

{
  "demo": "hello"
}
------WebKitFormBoundary7MA4YWxkTrZu0gW--
```

## 3.2. 下载文件

```bash
###
GET http://localhost:8000/download?file_id=group1/M01/00/04/xxxxxx.pdf
```
