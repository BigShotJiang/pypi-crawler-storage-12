class Compute:
    # CPU Tiers
    CPU_SMALL = "cpu-small"
    CPU_MEDIUM = "cpu-medium"
    CPU_LARGE = "cpu-large"
    CPU_XL = "cpu-xl"

    # GPU Tiers
    H200_SMALL = "h200-small"
    H200_MEDIUM = "h200-medium"
    H200_LARGE = "h200-large"
    H200_XL = "h200-xl"
