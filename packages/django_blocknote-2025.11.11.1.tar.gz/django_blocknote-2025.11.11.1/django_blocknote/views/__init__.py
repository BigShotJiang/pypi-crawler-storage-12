from .views import (
    remove_image,
    upload_file,
    upload_image,
)

__all__ = [
    "remove_image",
    "upload_file",
    "upload_image",
]
