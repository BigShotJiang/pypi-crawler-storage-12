# django_blocknote/__init__.py
__version__ = "2025.11.11.1"