"""Mouc - Mapping Outcomes User stories and Capabilities."""

__version__ = "0.1.12"
