from . import hr_personal_equipment
from . import product_template
from . import hr_personal_equipment_request
