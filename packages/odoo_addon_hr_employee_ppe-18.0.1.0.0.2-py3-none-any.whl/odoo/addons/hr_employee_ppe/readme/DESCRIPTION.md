This module allows you to manage allocation of PPE to your employees. A
product can be marked as ppe and additional information as duration and
indications can also be added. If ppe products are selected in a
equipment request, a button to print a receipt of PPE will appear. In
addition, a chron will check every day if an allocation has been
expired.
