To install this module, you need to have HR module installed or it will
be requested during installation.
