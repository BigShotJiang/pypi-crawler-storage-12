"""
CLI module for wtu-mlflow-triton-plugin

This module provides the keynet command-line interface for managing
serverless functions and authentication.
"""

from .main import main

__all__ = ["main"]
