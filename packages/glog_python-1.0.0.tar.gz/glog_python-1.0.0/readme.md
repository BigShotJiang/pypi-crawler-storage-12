# glog - Python Logging Library

一个完全兼容 Go glog 格式的 Python 日志库，支持 Python 3.7+。

## 特性

✅ 完全兼容 Go glog 日志格式  
✅ 支持 Python 3.7+  
✅ 无外部依赖  
✅ 线程安全  
✅ 支持上下文日志追踪  
✅ 支持 Console 和 JSON 格式  
✅ 自动获取调用位置  
✅ 支持结构化字段  

## 安装

```bash
pip install glog-python
```

或从源码安装：

```bash
git clone https://github.com/gw123/glog.git
cd glog
pip install -e .
```

## 快速开始

```python
import glog

# 基础日志
glog.info("Application started")
glog.warn("High memory usage")
glog.error("Connection failed")

# 带 trace_id 的日志（完全匹配 Go glog 格式）
logger = glog.default_logger().named("Runner")
trace_id = "59d428f7843866bd2863561f23c0c657"
log = logger.with_field(trace_id, "")

log.info("🚀 Initializing Ollama model: gemma3:27b")
log.info("📤 Sending prompt to model...")
log.info("✅ Model response received (10 chars)")
```

输出：
```
[2025-11-15 17:10:29.461] [info] [Runner] main.py:10 [59d428f7843866bd2863561f23c0c657] 🚀 Initializing Ollama model: gemma3:27b
[2025-11-15 17:10:29.503] [info] [Runner] main.py:11 [59d428f7843866bd2863561f23c0c657] 📤 Sending prompt to model...
[2025-11-15 17:10:30.596] [info] [Runner] main.py:12 [59d428f7843866bd2863561f23c0c657] ✅ Model response received (10 chars)
```

## 日志格式

```
[时间戳] [级别] [日志器名称] 文件名:行号 [字段1] [字段2] ... 消息内容
```

- **时间戳**：精确到毫秒 `YYYY-MM-DD HH:MM:SS.mmm`
- **级别**：debug/info/warn/error/fatal/panic
- **日志器名称**：通过 `.named()` 设置
- **文件名:行号**：自动获取（仅文件名）
- **字段**：通过 `.with_field()` 添加
- **消息**：实际日志内容

## 更多示例

### 多个字段

```python
import glog

logger = glog.default_logger().named("Runner")
trace_id = "59d428f7843866bd2863561f23c0c657"
plugin_name = "Plugin langchain_ollama_python"

log = logger.with_field(trace_id, "").with_field(plugin_name, "")
log.info("🚀 Initializing Ollama model: gemma3:27b")
```

### 上下文日志器

```python
import glog

# 初始化上下文
logger = glog.default_logger().named("API")
glog.to_context(logger)

# 添加 trace_id
glog.add_trace_id("a1b2c3d4e5f6g7h8")

# 所有后续日志自动包含 trace_id
log = glog.extract_entry()
log.info("Request received")

# 动态添加更多字段
glog.add_field("user_id", "123")
glog.add_field("method", "POST")

log = glog.extract_entry()
log.info("Request completed")
```

### 格式化日志

```python
import glog

logger = glog.default_logger().named("Worker")
log = logger.with_field("trace-123", "")

log.infof("Processing %d items", 100)
log.infof("Completed in %d ms", 1234)
```

### JSON 格式

```python
import glog
from glog import Options

options = Options()
options.with_json_encoding().with_stdout_output_path()
glog.set_default_logger_config(options)

glog.info("JSON formatted log")
```

## 文档

- [完整文档](glog/README.md)
- [快速开始](QUICK_START.md)
- [发布指南](PUBLISH.md)

## 运行示例

```bash
# 运行完整示例
python3 example_usage.py

# 运行简单示例
python3 glog/examples/simple_usage.py

# 运行测试
python3 glog/tests/test_logger.py
python3 glog/tests/test_context_logger.py
```

## 与 Go glog 的对应关系

| Go glog | Python glog |
|---------|-------------|
| `glog.Info()` | `glog.info()` |
| `glog.Infof()` | `glog.infof()` |
| `glog.WithField()` | `glog.with_field()` |
| `glog.WithError()` | `glog.with_error()` |
| `glog.ToContext()` | `glog.to_context()` |
| `glog.ExtractEntry()` | `glog.extract_entry()` |
| `glog.AddTraceID()` | `glog.add_trace_id()` |

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request！
