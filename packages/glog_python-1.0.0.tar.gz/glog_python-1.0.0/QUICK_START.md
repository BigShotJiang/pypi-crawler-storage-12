# glog 快速开始

一个完全兼容 Go glog 格式的 Python 日志库，支持 Python 3.7+。

## 安装

将 `glog` 目录复制到你的项目中即可使用，无需任何外部依赖。

```bash
# 复制到你的项目
cp -r glog /path/to/your/project/
```

## 快速使用

### 1. 基础日志

```python
import glog

glog.info("Application started")
glog.warn("High memory usage")
glog.error("Connection failed")
```

输出：
```
[2025-11-15 17:10:29.461] [info] [] main.py:3 Application started
[2025-11-15 17:10:29.462] [warn] [] main.py:4 High memory usage
[2025-11-15 17:10:29.463] [error] [] main.py:5 Connection failed
```

### 2. 带 trace_id 的日志（完全匹配 Go glog）

```python
import glog

# 创建命名日志器
logger = glog.default_logger().named("Runner")

# 添加 trace_id
trace_id = "59d428f7843866bd2863561f23c0c657"
log = logger.with_field(trace_id, "")

log.info("🚀 Initializing Ollama model: gemma3:27b")
log.info("📤 Sending prompt to model...")
log.info("✅ Model response received (10 chars)")
```

输出：
```
[2025-11-15 17:10:29.461] [info] [Runner] main.py:10 [59d428f7843866bd2863561f23c0c657] 🚀 Initializing Ollama model: gemma3:27b
[2025-11-15 17:10:29.503] [info] [Runner] main.py:11 [59d428f7843866bd2863561f23c0c657] 📤 Sending prompt to model...
[2025-11-15 17:10:30.596] [info] [Runner] main.py:12 [59d428f7843866bd2863561f23c0c657] ✅ Model response received (10 chars)
```

### 3. 多个字段

```python
import glog

logger = glog.default_logger().named("Runner")

trace_id = "59d428f7843866bd2863561f23c0c657"
plugin_name = "Plugin langchain_ollama_python"

log = logger.with_field(trace_id, "").with_field(plugin_name, "")
log.info("🚀 Initializing Ollama model: gemma3:27b")
```

输出：
```
[2025-11-15 17:10:29.461] [info] [Runner] main.py:8 [59d428f7843866bd2863561f23c0c657] [Plugin langchain_ollama_python] 🚀 Initializing Ollama model: gemma3:27b
```

### 4. 上下文日志器（推荐用于请求追踪）

```python
import glog

# 初始化上下文
logger = glog.default_logger().named("API")
glog.to_context(logger)

# 添加 trace_id
glog.add_trace_id("a1b2c3d4e5f6g7h8")

# 所有后续日志自动包含 trace_id
log = glog.extract_entry()
log.info("Request received")

# 动态添加更多字段
glog.add_field("user_id", "123")
glog.add_field("method", "POST")

log = glog.extract_entry()
log.info("Request completed")
```

输出：
```
[2025-11-15 17:10:29.461] [info] [API] main.py:10 [trace_id] Request received
[2025-11-15 17:10:29.503] [info] [API] main.py:18 [trace_id] [user_id] [method] Request completed
```

### 5. 格式化日志

```python
import glog

logger = glog.default_logger().named("Worker")
trace_id = "worker-123"

log = logger.with_field(trace_id, "")

log.infof("Processing %d items", 100)
log.infof("Completed in %d ms", 1234)
log.infof("Success rate: %.2f%%", 98.5)
```

### 6. 配置日志级别

```python
import glog
from glog import Level, Options

# 配置为 DEBUG 级别
options = Options(level=Level.DEBUG)
options.with_console_encoding().with_stdout_output_path()
glog.set_default_logger_config(options)

glog.debug("Debug message now visible")
```

### 7. JSON 格式输出

```python
import glog
from glog import Options

options = Options()
options.with_json_encoding().with_stdout_output_path()
glog.set_default_logger_config(options)

glog.info("JSON formatted log")
```

输出：
```json
{"ts":"2025-11-15 17:10:29.461","level":"info","caller":"main.py:8","msg":"JSON formatted log"}
```

## 日志格式说明

Console 格式：
```
[时间戳] [级别] [日志器名称] 文件名:行号 [字段1] [字段2] ... 消息内容
```

- **时间戳**：精确到毫秒 `YYYY-MM-DD HH:MM:SS.mmm`
- **级别**：debug/info/warn/error/fatal/panic
- **日志器名称**：通过 `.named()` 设置，空则显示 `[]`
- **文件名:行号**：自动获取（仅文件名，不含路径）
- **字段**：通过 `.with_field()` 添加，显示在方括号中
- **消息**：实际日志内容

## 运行示例

```bash
# 运行完整示例
python3 example_usage.py

# 运行简单示例
python3 glog/examples/simple_usage.py

# 运行测试
python3 glog/tests/test_logger.py
python3 glog/tests/test_context_logger.py
```

## 主要特性

✅ 完全兼容 Go glog 日志格式  
✅ 支持 Python 3.7+  
✅ 无外部依赖  
✅ 线程安全  
✅ 支持上下文日志追踪  
✅ 支持 Console 和 JSON 格式  
✅ 自动获取调用位置  
✅ 支持结构化字段  

## 更多文档

查看 `glog/README.md` 获取完整 API 文档。
