# Demo 目录说明

这个目录包含了各种使用 glog 的示例程序。每个 demo 都在独立的子目录中，避免 main 函数冲突。

## 📁 目录结构

```
demo/
├── README.md              # 本文件
├── DEMO_GUIDE.md         # 详细使用文档
├── SUMMARY.md            # 总结文档
├── run_demos.sh          # 一键运行脚本
├── demo.go               # 原始简单示例
├── basic/                # 基础功能演示
│   └── main.go
├── webapp/               # Web 应用模拟
│   └── main.go
└── performance/          # 性能测试
    └── main.go
```

## 🚀 快速开始

### 方式 1: 使用运行脚本（推荐）

```bash
# 显示帮助
./demo/run_demos.sh

# 运行基础演示
./demo/run_demos.sh basic

# 运行 Web 应用演示
./demo/run_demos.sh webapp

# 运行性能测试
./demo/run_demos.sh performance

# 运行所有演示
./demo/run_demos.sh all
```

### 方式 2: 直接运行

```bash
# 基础演示
go run demo/basic/main.go

# Web 应用演示
go run demo/webapp/main.go

# 性能测试
go run demo/performance/main.go

# 原始简单示例
go run demo/demo.go
```

### 方式 3: 使用 Makefile

```bash
# 运行默认 demo（基础演示）
make demo

# 构建所有 demo 可执行文件
make build-demo

# 运行构建好的文件
./bin/basic-demo
./bin/webapp-demo
./bin/performance-demo
```

## 📚 Demo 详细说明

### 1. demo/basic/ - 基础功能演示

**包含 8 个核心场景：**

1. 基础日志 - Info, Warn, Error 基本用法
2. 字段日志 - WithField 和链式调用
3. Context 日志 - 完整的上下文日志示例
4. 错误日志 - 错误处理最佳实践
5. 命名日志器 - 不同组件的日志隔离
6. 自定义配置 - 日志级别和输出配置
7. 并发日志 - 多 goroutine 并发日志
8. 日志级别 - 不同级别的效果演示

```bash
go run demo/basic/main.go
```

**适合场景：** 学习基础用法、理解核心概念

### 2. demo/webapp/ - Web 应用模拟

**模拟完整 Web 服务器生命周期：**

- 应用启动和初始化
- 数据库连接日志
- 缓存连接日志
- API 服务器启动
- HTTP 请求处理（5个不同请求）
- 请求追踪和用户识别
- 业务逻辑日志
- 优雅关闭

每个请求都有独立的 trace ID 和上下文。

```bash
go run demo/webapp/main.go
```

**输出日志到：** `demo/webapp/web_app.log`

**适合场景：** 了解实际项目集成、学习最佳实践

### 3. demo/performance/ - 性能和压力测试

**包含 4 个性能测试场景：**

1. **高频日志测试** - 10,000 条连续日志
2. **并发压力测试** - 100 个 goroutine 并发
3. **大字段日志** - 处理大数据结构
4. **上下文累积** - 测试字段累积性能

```bash
go run demo/performance/main.go
```

**输出日志到：** `demo/performance/performance.log`

**适合场景：** 性能评估、压力测试、优化参考

### 4. demo/demo.go - 原始简单示例

**快速验证示例：**
- 基本日志输出
- 字段添加
- OTEL 集成

```bash
go run demo/demo.go
```

**适合场景：** 快速验证、入门体验

## 🎯 学习路径

### 初学者路径
```bash
1. go run demo/demo.go              # 快速体验
2. go run demo/basic/main.go        # 学习核心功能
3. 阅读代码注释                       # 理解实现
```

### 进阶路径
```bash
1. go run demo/basic/main.go        # 复习基础
2. go run demo/webapp/main.go       # 学习最佳实践
3. 修改代码实验                       # 动手实践
```

### 高级路径
```bash
1. go run demo/performance/main.go  # 了解性能特性
2. 查看性能报告                       # 分析结果
3. 编写自己的 benchmark              # 深入优化
```

## 📊 输出示例

### Console 格式
```
[2025-11-03 14:52:45.741] [info] [] demo/basic/main.go:46 []  Simple info message
[2025-11-03 14:52:45.743] [info] [database] demo/basic/main.go:149 []  Connection pool initialized {"pool_size": 10}
```

### 文件输出
生成的日志文件：
- `demo/basic/demo.log` - 基础演示日志
- `demo/webapp/web_app.log` - Web 应用日志
- `demo/performance/performance.log` - 性能测试日志

## 🔧 自定义 Demo

### 创建新的 Demo

```bash
# 1. 创建新目录
mkdir demo/myapp

# 2. 创建 main.go
cat > demo/myapp/main.go << 'EOF'
package main

import (
    "github.com/gw123/glog"
    "github.com/gw123/glog/common"
)

func main() {
    glog.SetDefaultLoggerConfig(
        common.Options{},
        common.WithLevel(common.DebugLevel),
    )
    
    glog.Info("Hello from my demo!")
}
EOF

# 3. 运行
go run demo/myapp/main.go
```

## 🧹 清理

```bash
# 清理所有日志文件
find demo -name "*.log" -delete

# 清理构建的二进制文件
rm -f bin/*-demo

# 或使用 make
make clean
```

## 📈 性能参考

基于 `demo/performance/` 的结果：

| 测试项 | 数量 | 性能 |
|-------|------|------|
| 高频日志 | 10,000 | ~50,000 msg/s |
| 并发日志 | 10,000 (100x100) | ~40,000 msg/s |
| 大字段日志 | 1 | <5ms |
| 字段累积 | 100 fields | <1ms |

## 💡 提示

1. **独立目录**：每个 demo 都在独立目录中，避免 main 函数冲突
2. **并发安全**：所有 demo 都展示了线程安全的用法
3. **日志输出**：日志会同时输出到 console 和各自目录的文件中
4. **实时查看**：可以使用 `tail -f demo/*/*.log` 实时查看日志

## 🐛 故障排除

### Demo 无法运行
```bash
# 确保在项目根目录
cd /path/to/glog

# 确保依赖已下载
go mod tidy
go mod download

# 尝试直接运行
go run demo/basic/main.go
```

### 权限错误
```bash
# 给脚本执行权限
chmod +x demo/run_demos.sh
```

### 日志文件写入失败
```bash
# 确保目录存在且可写
mkdir -p demo/basic demo/webapp demo/performance
chmod 755 demo/*/
```

## 📖 相关文档

- [DEMO_GUIDE.md](DEMO_GUIDE.md) - 完整详细文档
- [SUMMARY.md](SUMMARY.md) - Demo 总结
- [../README.md](../README.md) - 项目主文档
- [../MAKEFILE_GUIDE.md](../MAKEFILE_GUIDE.md) - Makefile 使用指南

## 🤝 贡献

欢迎贡献新的 demo 示例！创建新 demo 时：

1. 在 `demo/` 下创建新目录
2. 添加 `main.go` 文件
3. 更新本 README
4. 更新 `run_demos.sh` 脚本
5. 提交 PR
