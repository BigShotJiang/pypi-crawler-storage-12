Import-Module ./tasks/scripts/sh_runner.ps1

RunShFileWithGitBash -ShFilePath "./tasks/scripts/install_venv.sh"
