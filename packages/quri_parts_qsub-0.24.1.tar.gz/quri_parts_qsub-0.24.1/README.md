# QURI Parts Qsub

QURI Parts Qsub is a library to construct structured circuits especially for complex
FTQC algorithms.

## Documentation

[QURI Parts Documentation](https://quri-parts.qunasys.com)

## Installation

```
pip install quri-parts-qsub
```

## License

Apache License 2.0
