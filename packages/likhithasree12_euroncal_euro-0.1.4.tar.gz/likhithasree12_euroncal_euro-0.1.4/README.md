# Euroncal

A simple calculator package for Python.

## Installation

```bash
pip install euroncal-euro