"""Tests package for unique_swot."""
