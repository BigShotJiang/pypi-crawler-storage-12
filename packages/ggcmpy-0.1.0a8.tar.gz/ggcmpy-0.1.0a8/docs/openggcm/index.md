# OpenGGCM

```{note}
This isn't really the right place for general OpenGGCM documentation. It should be moved, eventually, but I gotta start somewhere. Things need to be consolidated, too (see https://openggcm.sr.unh.edu/?n=Main.Running)
```

```{toctree}
:maxdepth: 2
:hidden:

Installing and Running <quickstart>
```
