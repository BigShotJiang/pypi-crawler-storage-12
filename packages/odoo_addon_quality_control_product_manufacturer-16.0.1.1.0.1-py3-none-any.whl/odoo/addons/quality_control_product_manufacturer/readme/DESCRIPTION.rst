This module provides information related to Manufacturer and its code
based on the product_id available as part of selection made in the
Reference field in qc inspection form.
