canopy.util
===========

canopy.util.checks
------------------

.. automodule:: canopy.util.checks
   :members:
   :show-inheritance:
   :undoc-members:

canopy.util.compare\_ts
-----------------------

.. automodule:: canopy.util.compare_ts
   :members:
   :show-inheritance:
   :undoc-members:

canopy.util.fieldops
--------------------

.. automodule:: canopy.util.fieldops
   :members:
   :show-inheritance:
   :undoc-members:

canopy.util.sites
-----------------

.. automodule:: canopy.util.sites
   :members:
   :show-inheritance:
   :undoc-members:

canopy.util.overlap
-------------------

.. automodule:: canopy.util.overlap
   :members:
   :show-inheritance:
   :undoc-members:
