"""Version information for claude-lint."""

__version__ = "0.3.0"
