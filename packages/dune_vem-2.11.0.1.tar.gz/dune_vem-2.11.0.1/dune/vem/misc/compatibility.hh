#ifndef DUNE_VEM_MISC_COMPATIBILITY_HH
#define DUNE_VEM_MISC_COMPATIBILITY_HH

#include <utility>

#include <dune/grid/common/entity.hh>

namespace Dune
{

  namespace Vem
  {

  } // namespace Vem

} // namespace Dune

#endif // #ifndef DUNE_VEM_MISC_COMPATIBILITY_HH
