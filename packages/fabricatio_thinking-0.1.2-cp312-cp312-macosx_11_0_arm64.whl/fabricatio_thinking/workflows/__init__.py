"""Workflows defined in fabricatio-thinking."""
