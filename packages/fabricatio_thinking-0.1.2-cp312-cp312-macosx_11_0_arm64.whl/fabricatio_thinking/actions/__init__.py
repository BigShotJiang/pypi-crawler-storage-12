"""Actions defined in fabricatio-thinking."""
