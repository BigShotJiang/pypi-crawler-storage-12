#!/usr/bin/env python

"""
Exceptions for crawl4weibo
"""
