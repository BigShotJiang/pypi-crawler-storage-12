
LabelsDict = dict[str, str | list[str]]
