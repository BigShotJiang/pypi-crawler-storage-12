
from qt_dataviewer.data_file_browser import DataFileBrowser

browser = DataFileBrowser(r"test_data", gui_style="dark")
