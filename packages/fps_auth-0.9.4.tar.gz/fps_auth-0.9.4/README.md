# fps-auth

An FPS plugin for the authentication API.
