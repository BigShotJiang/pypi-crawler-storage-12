from .core import epsilon_greedy
__all__ = ["epsilon_greedy"]
__version__ = "0.1.0"
