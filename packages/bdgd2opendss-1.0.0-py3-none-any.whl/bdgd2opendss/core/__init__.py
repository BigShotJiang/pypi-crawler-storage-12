# -*- encoding: utf-8 -*-

from .Settings import Settings
