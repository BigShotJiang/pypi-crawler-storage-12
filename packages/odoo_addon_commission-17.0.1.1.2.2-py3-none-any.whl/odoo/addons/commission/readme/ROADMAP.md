- Make it totally multi-company aware.
- Set agent popup window with a kanban view with richer information and
  mobile friendly.
