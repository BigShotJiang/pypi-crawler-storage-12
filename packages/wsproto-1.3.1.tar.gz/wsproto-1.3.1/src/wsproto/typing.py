from __future__ import annotations

Headers = list[tuple[bytes, bytes]]
