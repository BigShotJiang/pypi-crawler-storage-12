Installation
============

wsproto is a pure Python project. To install it you can use pip like so:

.. code-block:: console

    $ pip install wsproto

Alternatively you can get either a release tarball or a development branch
from `our GitHub repository`_ and run:

.. code-block:: console

    $ python setup.py install

.. _our GitHub repository: https://github.com/python-hyper/wsproto
