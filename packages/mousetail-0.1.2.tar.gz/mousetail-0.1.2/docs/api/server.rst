MCP Server
==========

The main MCP server implementation that exposes Anki functionality to LLMs.

.. automodule:: mousetail.mcp.server
   :members:
   :undoc-members:
   :show-inheritance:

AnkiMCPServer Class
-------------------

.. autoclass:: mousetail.mcp.server.AnkiMCPServer
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
   :no-index:
