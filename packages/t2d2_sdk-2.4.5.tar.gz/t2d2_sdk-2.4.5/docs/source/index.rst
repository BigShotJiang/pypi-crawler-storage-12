Welcome to T2D2 SDK's documentation!
====================================
.. include:: ../../README.md
   :parser: myst_parser.sphinx_

.. automodule:: t2d2_sdk
    :members:

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
