# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'form.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QVBoxLayout, QWidget)
from neuro_mine.ui import resources_rc

class Ui_Widget(object):
    def setupUi(self, Widget):
        if not Widget.objectName():
            Widget.setObjectName(u"Widget")
        Widget.resize(604, 559)
        self.pushButton = QPushButton(Widget)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(510, 530, 91, 32))
        self.pushButton_2 = QPushButton(Widget)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(500, 40, 81, 32))
        self.pushButton_3 = QPushButton(Widget)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setGeometry(QRect(500, 70, 81, 32))
        self.pushButton_4 = QPushButton(Widget)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setGeometry(QRect(510, 500, 91, 32))
        self.pushButton_5 = QPushButton(Widget)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setGeometry(QRect(410, 120, 171, 32))
        self.widget = QWidget(Widget)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(260, 0, 251, 551))
        self.verticalLayout = QVBoxLayout(self.widget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.lineEdit = QLineEdit(self.widget)
        self.lineEdit.setObjectName(u"lineEdit")

        self.verticalLayout.addWidget(self.lineEdit)

        self.lineEdit_4 = QLineEdit(self.widget)
        self.lineEdit_4.setObjectName(u"lineEdit_4")

        self.verticalLayout.addWidget(self.lineEdit_4)

        self.lineEdit_2 = QLineEdit(self.widget)
        self.lineEdit_2.setObjectName(u"lineEdit_2")

        self.verticalLayout.addWidget(self.lineEdit_2)

        self.checkBox = QCheckBox(self.widget)
        self.checkBox.setObjectName(u"checkBox")

        self.verticalLayout.addWidget(self.checkBox)

        self.checkBox_2 = QCheckBox(self.widget)
        self.checkBox_2.setObjectName(u"checkBox_2")

        self.verticalLayout.addWidget(self.checkBox_2)

        self.lineEdit_3 = QLineEdit(self.widget)
        self.lineEdit_3.setObjectName(u"lineEdit_3")

        self.verticalLayout.addWidget(self.lineEdit_3)

        self.lineEdit_5 = QLineEdit(self.widget)
        self.lineEdit_5.setObjectName(u"lineEdit_5")

        self.verticalLayout.addWidget(self.lineEdit_5)

        self.lineEdit_11 = QLineEdit(self.widget)
        self.lineEdit_11.setObjectName(u"lineEdit_11")

        self.verticalLayout.addWidget(self.lineEdit_11)

        self.lineEdit_6 = QLineEdit(self.widget)
        self.lineEdit_6.setObjectName(u"lineEdit_6")

        self.verticalLayout.addWidget(self.lineEdit_6)

        self.lineEdit_7 = QLineEdit(self.widget)
        self.lineEdit_7.setObjectName(u"lineEdit_7")

        self.verticalLayout.addWidget(self.lineEdit_7)

        self.lineEdit_8 = QLineEdit(self.widget)
        self.lineEdit_8.setObjectName(u"lineEdit_8")

        self.verticalLayout.addWidget(self.lineEdit_8)

        self.checkBox_4 = QCheckBox(self.widget)
        self.checkBox_4.setObjectName(u"checkBox_4")

        self.verticalLayout.addWidget(self.checkBox_4)

        self.lineEdit_9 = QLineEdit(self.widget)
        self.lineEdit_9.setObjectName(u"lineEdit_9")

        self.verticalLayout.addWidget(self.lineEdit_9)

        self.lineEdit_12 = QLineEdit(self.widget)
        self.lineEdit_12.setObjectName(u"lineEdit_12")

        self.verticalLayout.addWidget(self.lineEdit_12)

        self.lineEdit_13 = QLineEdit(self.widget)
        self.lineEdit_13.setObjectName(u"lineEdit_13")

        self.verticalLayout.addWidget(self.lineEdit_13)

        self.checkBox_3 = QCheckBox(self.widget)
        self.checkBox_3.setObjectName(u"checkBox_3")

        self.verticalLayout.addWidget(self.checkBox_3)

        self.lineEdit_10 = QLineEdit(self.widget)
        self.lineEdit_10.setObjectName(u"lineEdit_10")

        self.verticalLayout.addWidget(self.lineEdit_10)

        self.pushButton_6 = QPushButton(Widget)
        self.pushButton_6.setObjectName(u"pushButton_6")
        self.pushButton_6.setGeometry(QRect(360, 530, 141, 32))
        self.layoutWidget = QWidget(Widget)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(0, 10, 261, 521))
        self.verticalLayout_2 = QVBoxLayout(self.layoutWidget)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.label_2 = QLabel(self.layoutWidget)
        self.label_2.setObjectName(u"label_2")

        self.verticalLayout_2.addWidget(self.label_2)

        self.label_3 = QLabel(self.layoutWidget)
        self.label_3.setObjectName(u"label_3")

        self.verticalLayout_2.addWidget(self.label_3)

        self.label_4 = QLabel(self.layoutWidget)
        self.label_4.setObjectName(u"label_4")

        self.verticalLayout_2.addWidget(self.label_4)

        self.label_5 = QLabel(self.layoutWidget)
        self.label_5.setObjectName(u"label_5")

        self.verticalLayout_2.addWidget(self.label_5)

        self.label_6 = QLabel(self.layoutWidget)
        self.label_6.setObjectName(u"label_6")

        self.verticalLayout_2.addWidget(self.label_6)

        self.label_7 = QLabel(self.layoutWidget)
        self.label_7.setObjectName(u"label_7")

        self.verticalLayout_2.addWidget(self.label_7)

        self.label_8 = QLabel(self.layoutWidget)
        self.label_8.setObjectName(u"label_8")

        self.verticalLayout_2.addWidget(self.label_8)

        self.label_13 = QLabel(self.layoutWidget)
        self.label_13.setObjectName(u"label_13")

        self.verticalLayout_2.addWidget(self.label_13)

        self.label_9 = QLabel(self.layoutWidget)
        self.label_9.setObjectName(u"label_9")

        self.verticalLayout_2.addWidget(self.label_9)

        self.label_10 = QLabel(self.layoutWidget)
        self.label_10.setObjectName(u"label_10")

        self.verticalLayout_2.addWidget(self.label_10)

        self.label_11 = QLabel(self.layoutWidget)
        self.label_11.setObjectName(u"label_11")

        self.verticalLayout_2.addWidget(self.label_11)

        self.label_14 = QLabel(self.layoutWidget)
        self.label_14.setObjectName(u"label_14")

        self.verticalLayout_2.addWidget(self.label_14)

        self.label_12 = QLabel(self.layoutWidget)
        self.label_12.setObjectName(u"label_12")

        self.verticalLayout_2.addWidget(self.label_12)

        self.label_16 = QLabel(self.layoutWidget)
        self.label_16.setObjectName(u"label_16")

        self.verticalLayout_2.addWidget(self.label_16)

        self.label_17 = QLabel(self.layoutWidget)
        self.label_17.setObjectName(u"label_17")

        self.verticalLayout_2.addWidget(self.label_17)

        self.label_18 = QLabel(self.layoutWidget)
        self.label_18.setObjectName(u"label_18")

        self.verticalLayout_2.addWidget(self.label_18)

        self.label_15 = QLabel(self.layoutWidget)
        self.label_15.setObjectName(u"label_15")

        self.verticalLayout_2.addWidget(self.label_15)

        self.label_19 = QLabel(Widget)
        self.label_19.setObjectName(u"label_19")
        self.label_19.setGeometry(QRect(500, 160, 58, 16))
        self.label_20 = QLabel(Widget)
        self.label_20.setObjectName(u"label_20")
        self.label_20.setGeometry(QRect(500, 200, 58, 16))
        self.label_21 = QLabel(Widget)
        self.label_21.setObjectName(u"label_21")
        self.label_21.setGeometry(QRect(500, 230, 58, 16))
        self.label_22 = QLabel(Widget)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setGeometry(QRect(500, 260, 58, 16))
        self.label_23 = QLabel(Widget)
        self.label_23.setObjectName(u"label_23")
        self.label_23.setGeometry(QRect(500, 290, 58, 16))
        self.label_24 = QLabel(Widget)
        self.label_24.setObjectName(u"label_24")
        self.label_24.setGeometry(QRect(500, 330, 58, 16))
        self.label_25 = QLabel(Widget)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setGeometry(QRect(500, 390, 58, 16))
        self.label_26 = QLabel(Widget)
        self.label_26.setObjectName(u"label_26")
        self.label_26.setGeometry(QRect(500, 420, 58, 16))
        self.label_27 = QLabel(Widget)
        self.label_27.setObjectName(u"label_27")
        self.label_27.setGeometry(QRect(500, 450, 58, 16))
        self.label = QLabel(Widget)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(530, 10, 41, 21))
        self.label.setPixmap(QPixmap(u":/logo.png"))
        self.label_28 = QLabel(Widget)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setGeometry(QRect(580, 50, 16, 16))
        self.label_28.setPixmap(QPixmap(u":/question.png"))
        self.label_29 = QLabel(Widget)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setGeometry(QRect(580, 80, 16, 16))
        self.label_29.setPixmap(QPixmap(u":/question.png"))
        self.pushButton.raise_()
        self.pushButton_2.raise_()
        self.pushButton_3.raise_()
        self.pushButton_4.raise_()
        self.widget.raise_()
        self.pushButton_6.raise_()
        self.layoutWidget.raise_()
        self.label_19.raise_()
        self.label_20.raise_()
        self.label_21.raise_()
        self.label_22.raise_()
        self.label_23.raise_()
        self.label_24.raise_()
        self.label_25.raise_()
        self.label_26.raise_()
        self.label_27.raise_()
        self.label.raise_()
        self.label_28.raise_()
        self.label_29.raise_()
        self.pushButton_5.raise_()

        self.retranslateUi(Widget)

        QMetaObject.connectSlotsByName(Widget)
    # setupUi

    def retranslateUi(self, Widget):
        Widget.setWindowTitle(QCoreApplication.translate("Widget", u"Neuro MINE", None))
        self.pushButton.setText(QCoreApplication.translate("Widget", u"Run Model", None))
        self.pushButton_2.setText(QCoreApplication.translate("Widget", u"Browse...", None))
        self.pushButton_3.setText(QCoreApplication.translate("Widget", u"Browse...", None))
        self.pushButton_4.setText(QCoreApplication.translate("Widget", u"Browse...", None))
        self.pushButton_5.setText(QCoreApplication.translate("Widget", u"Restore Preset Parameters", None))
        self.checkBox.setText(QCoreApplication.translate("Widget", u"Yes", None))
        self.checkBox_2.setText(QCoreApplication.translate("Widget", u"Yes", None))
        self.checkBox_4.setText(QCoreApplication.translate("Widget", u"Yes", None))
        self.checkBox_3.setText(QCoreApplication.translate("Widget", u"Yes", None))
        self.pushButton_6.setText(QCoreApplication.translate("Widget", u"Save Configuration", None))
        self.label_2.setText(QCoreApplication.translate("Widget", u"Model Name:", None))
        self.label_3.setText(QCoreApplication.translate("Widget", u"Predictor File Path:", None))
#if QT_CONFIG(tooltip)
        self.label_4.setToolTip(QCoreApplication.translate("Widget", u"Single delimiter-separated file with Time as first column", None))
#endif // QT_CONFIG(tooltip)
        self.label_4.setText(QCoreApplication.translate("Widget", u"Response File Path:", None))
        self.label_5.setText(QCoreApplication.translate("Widget", u"Use Time as a Predictor:", None))
        self.label_6.setText(QCoreApplication.translate("Widget", u"Run Shuffle:", None))
        self.label_7.setText(QCoreApplication.translate("Widget", u"Test Score Threshold:", None))
        self.label_8.setText(QCoreApplication.translate("Widget", u"Taylor Expansion Significance Threshold:", None))
        self.label_13.setText(QCoreApplication.translate("Widget", u"Taylor Expansion Look Ahead:", None))
        self.label_9.setText(QCoreApplication.translate("Widget", u"Taylor Cutoff", None))
        self.label_10.setText(QCoreApplication.translate("Widget", u"Linear Fit Variance Fraction:", None))
        self.label_11.setText(QCoreApplication.translate("Widget", u"Square Fit Variance Fraction:", None))
        self.label_14.setText(QCoreApplication.translate("Widget", u"Store Linear Receptive Fields (Jacobians):", None))
        self.label_12.setText(QCoreApplication.translate("Widget", u"Model History (seconds):", None))
        self.label_16.setText(QCoreApplication.translate("Widget", u"Number of Epochs:", None))
        self.label_17.setText(QCoreApplication.translate("Widget", u"Train Data Fraction:", None))
        self.label_18.setText(QCoreApplication.translate("Widget", u"Verbose:", None))
        self.label_15.setText(QCoreApplication.translate("Widget", u"Upload JSON File with Existing Parameters:", None))
        self.label_19.setText(QCoreApplication.translate("Widget", u"[0,1]", None))
        self.label_20.setText(QCoreApplication.translate("Widget", u"[0,1]", None))
        self.label_21.setText(QCoreApplication.translate("Widget", u"(0,4)", None))
        self.label_22.setText(QCoreApplication.translate("Widget", u"[0,1]", None))
        self.label_23.setText(QCoreApplication.translate("Widget", u"[0,1]", None))
        self.label_24.setText(QCoreApplication.translate("Widget", u"[0,1]", None))
        self.label_25.setText(QCoreApplication.translate("Widget", u"\u22651", None))
        self.label_26.setText(QCoreApplication.translate("Widget", u"[0,100]", None))
        self.label_27.setText(QCoreApplication.translate("Widget", u"[0,1]", None))
        self.label.setText("")
#if QT_CONFIG(tooltip)
        self.label_28.setToolTip(QCoreApplication.translate("Widget", u"Single delimiter-separated file with Time as first column", None))
#endif // QT_CONFIG(tooltip)
        self.label_28.setText("")
#if QT_CONFIG(tooltip)
        self.label_29.setToolTip(QCoreApplication.translate("Widget", u"Single delimiter-separated file with Time as first column", None))
#endif // QT_CONFIG(tooltip)
        self.label_29.setText("")
    # retranslateUi

