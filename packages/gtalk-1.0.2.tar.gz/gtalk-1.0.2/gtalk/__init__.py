"""GTalk CLI - Google AI Mode Terminal Query Tool"""

__version__ = "0.1.0"
__author__ = "Md. Sazzad Hissain Khan"
__email__ = "hissain.khan@gmail.com"

from .cli import main

__all__ = ["main"]