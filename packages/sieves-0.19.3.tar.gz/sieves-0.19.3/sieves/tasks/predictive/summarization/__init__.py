"""Information extraction task."""

from .core import FewshotExample, Summarization

__all__ = ["Summarization", "FewshotExample"]
