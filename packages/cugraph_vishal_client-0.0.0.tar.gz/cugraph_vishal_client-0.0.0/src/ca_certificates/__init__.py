__version__ = "0.0.0"

def info():
    return "This is a dummy cugraph-vishal-client package for PyPI."
