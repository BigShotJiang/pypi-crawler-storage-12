# Generating documentation
pip install pdoc
pdoc ./pystran/ -o html --math

# Handling of path in VS Code terminal

$ pwd
/c/Users/pkonl/Documents/00WIP/pystran
PYTHONPATH=. py tutorials/01_three_bars_tut.py

# Mass matrix of beam

2D does not have the second moment of area?
