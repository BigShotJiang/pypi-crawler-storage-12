# chuk_mcp_telnet_client/main.py
from chuk_mcp_runtime.entry import main

if __name__ == "__main__":
    # launch
    main()