from ._anonymask import Anonymizer, Entity

__version__ = "0.4.5"