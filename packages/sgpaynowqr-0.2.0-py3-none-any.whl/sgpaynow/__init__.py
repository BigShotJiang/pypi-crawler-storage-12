from .static import static_generator
from .dynamic import dynamic_generator
__version__ = "0.2.0"
__all__ = ['static_generator', 'dynamic_generator']