"""Tests for EasyEnv."""
