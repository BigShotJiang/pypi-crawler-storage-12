"""EasyEnv - Ephemeral, reproducible, cached development environments."""

__version__ = "0.1.3"
__author__ = "EasyEnv Contributors"
__all__ = ["__author__", "__version__"]
