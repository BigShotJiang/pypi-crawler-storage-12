#!/bin/bash
chatterlang_script --script Step_1_CreateSyntheticData.script 