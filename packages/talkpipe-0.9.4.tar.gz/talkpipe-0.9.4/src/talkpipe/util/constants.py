TALKPIPE_MODEL_NAME = "default_model_name"
TALKPIPE_SOURCE = "default_model_source"
OLLAMA_SERVER_URL = "OLLAMA_SERVER_URL"
