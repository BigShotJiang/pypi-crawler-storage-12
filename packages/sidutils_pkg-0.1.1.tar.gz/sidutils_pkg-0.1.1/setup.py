from setuptools import setup, find_packages

setup(
    name="sidutils_pkg",
    version="0.1.1",
    packages=["PipPackageTest"]
)