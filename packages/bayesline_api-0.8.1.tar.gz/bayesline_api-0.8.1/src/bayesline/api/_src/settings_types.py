from bayesline.api._src.equity.settings_types import (
    SETTINGS_TYPES as EQUITY_SETTINGS_TYPES,
)

SETTINGS_TYPES = [
    *EQUITY_SETTINGS_TYPES,
]
