"""
Build operations module for Micronaut applications.

Handles Gradle wrapper setup, JAR building, testing, and SAM template creation.
"""

import os
import subprocess
from typing import Optional
from dataclasses import dataclass

from .exceptions import BuildError
from .utils import run_command


@dataclass
class TemplateSpec:
    """Specification for SAM template generation."""
    app_name: str
    region: str
    proxy_all: bool = False
    requires_key: bool = True


@dataclass
class BuildResult:
    """Result of build operation."""
    success: bool
    jar_path: Optional[str] = None
    error_message: Optional[str] = None


class BuildManager:
    """Handles build operations for Micronaut projects."""
    
    def ensure_gradle_wrapper(self, project_dir: str) -> None:
        """
        Ensure Gradle wrapper exists and is executable.
        
        Args:
            project_dir: Path to project directory
            
        Raises:
            BuildError: If wrapper setup fails
        """
        print("\nChecking Gradle wrapper...")
        
        gradlew_path = os.path.join(project_dir, "gradlew")
        
        if not os.path.isfile(gradlew_path):
            print("Gradle wrapper not found, generating...")
            try:
                run_command(["gradle", "wrapper"], cwd=project_dir)
            except subprocess.CalledProcessError as e:
                raise BuildError(f"Failed to generate Gradle wrapper: {e}", "wrapper_generation")
        
        try:
            os.chmod(gradlew_path, 0o755)
            print("Set executable permissions on gradlew.")
        except OSError as e:
            raise BuildError(f"Failed to set gradlew permissions: {e}", "wrapper_permissions")
    
    def build_jar(self, project_dir: str) -> BuildResult:
        """
        Build the application JAR using Gradle.
        
        Args:
            project_dir: Path to project directory
            
        Returns:
            BuildResult with success status and JAR path
        """
        print("\nBuilding application JAR...")
        
        try:
            # Build the fat JAR
            run_command(["./gradlew", "shadowJar"], cwd=project_dir)
            
            # Find the generated JAR
            jar_pattern = os.path.join(project_dir, "build", "libs", "*-all.jar")
            import glob
            jar_files = glob.glob(jar_pattern)
            
            if jar_files:
                jar_path = jar_files[0]  # Take the first match
                print(f"JAR built successfully: {os.path.basename(jar_path)}")
                return BuildResult(success=True, jar_path=jar_path)
            else:
                return BuildResult(
                    success=False, 
                    error_message="JAR file not found after build"
                )
                
        except subprocess.CalledProcessError as e:
            return BuildResult(
                success=False,
                error_message=f"Gradle build failed: {e}"
            )
    
    def run_tests(self, project_dir: str) -> BuildResult:
        """
        Run tests using Gradle.
        
        Args:
            project_dir: Path to project directory
            
        Returns:
            BuildResult with test status
        """
        print("\nRunning tests...")
        
        try:
            run_command(["./gradlew", "test"], cwd=project_dir)
            print("Tests passed successfully.")
            return BuildResult(success=True)
            
        except subprocess.CalledProcessError as e:
            return BuildResult(
                success=False,
                error_message=f"Tests failed: {e}"
            )
    
    def create_sam_template(self, spec: TemplateSpec, project_dir: str) -> None:
        """
        Create SAM template for deployment.
        
        Args:
            spec: Template specification
            project_dir: Path to project directory
            
        Raises:
            BuildError: If template creation fails
        """
        print(f"\nCreating SAM template{' with API Key authentication' if spec.requires_key else ''}...")
        
        # Generate logical ID from app name
        logical_id = "".join(
            part.capitalize() 
            for part in spec.app_name.replace('_', '-').split('-') 
            if part
        ) + "Function"
        
        # The JAR name must match the project name created by 'mn create-app'
        jar_name_base = spec.app_name.replace('_', '').replace('-', '')
        
        # Precompute conditional blocks to avoid f-string issues
        auth_block = ""
        if spec.requires_key:
            auth_block = (
                "            Auth:\n"
                "              ApiKeyRequired: true\n"
            )
        
        api_key_resources = ""
        if spec.requires_key:
            api_key_resources = (
                "  MyUsagePlan:\n"
                "    Type: AWS::ApiGateway::UsagePlan\n"
                "    DependsOn: ServerlessRestApiProdStage\n"
                "    Properties:\n"
                "      UsagePlanName: !Sub \"${AWS::StackName}-usage-plan\"\n"
                "      ApiStages:\n"
                "        - ApiId: !Ref ServerlessRestApi\n"
                "          Stage: Prod\n\n"
                "  MyApiKey:\n"
                "    Type: AWS::ApiGateway::ApiKey\n"
                "    Properties:\n"
                "      Name: !Sub \"${AWS::StackName}-api-key\"\n"
                "      Enabled: true\n"
                "      GenerateDistinctId: true\n\n"
                "  MyUsagePlanKey:\n"
                "    Type: AWS::ApiGateway::UsagePlanKey\n"
                "    Properties:\n"
                "      KeyId: !Ref MyApiKey\n"
                "      KeyType: API_KEY\n"
                "      UsagePlanId: !Ref MyUsagePlan\n"
            )
        
        outputs_api_key_block = ""
        if spec.requires_key:
            outputs_api_key_block = (
                "  ApiKey:\n"
                "    Description: \"API Key Value\"\n"
                "    Value: !Ref MyApiKey\n"
            )
        
        # Generate template content
        template_content = f"""AWSTemplateFormatVersion: '2010-09-09'
Transform: AWS::Serverless-2016-10-31
Description: Micronaut Lambda function with REST API and API Key

Globals:
  Api:
    EndpointConfiguration: REGIONAL

Resources:
  {logical_id}:
    Type: AWS::Serverless::Function
    Properties:
      Handler: io.micronaut.function.aws.proxy.MicronautLambdaHandler
      Runtime: java17
      CodeUri: build/libs/{jar_name_base}-0.1-all.jar
      MemorySize: 512
      Timeout: 20
      Architectures:
        - x86_64
      Events:
        ApiEvent:
          Type: Api
          Properties:
            Path: {'/{proxy+}' if spec.proxy_all else '/hello'}
            Method: {'any' if spec.proxy_all else 'get'}
{auth_block}

{api_key_resources}

Outputs:
  ApiUrl:
    Description: "REST API endpoint URL"
    Value: !Sub "https://${{ServerlessRestApi}}.execute-api.${{AWS::Region}}.amazonaws.com/Prod{'/' if not spec.proxy_all else ''}"
{outputs_api_key_block}
"""
        
        template_path = os.path.join(project_dir, "template.yaml")
        try:
            with open(template_path, "w") as f:
                f.write(template_content)
            print("SAM template created.")
        except IOError as e:
            raise BuildError(f"Failed to create SAM template: {e}", "template_creation")
    
    def clean_build(self, project_dir: str) -> None:
        """
        Clean build artifacts.
        
        Args:
            project_dir: Path to project directory
            
        Raises:
            BuildError: If clean fails
        """
        print("\nCleaning build artifacts...")
        
        try:
            run_command(["./gradlew", "clean"], cwd=project_dir)
            print("Build artifacts cleaned.")
        except subprocess.CalledProcessError as e:
            raise BuildError(f"Failed to clean build: {e}", "clean")
