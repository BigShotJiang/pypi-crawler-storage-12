"""
Project generation module for Micronaut applications.

Handles Micronaut project creation, controller generation, and project setup.
"""

import os
import re
import subprocess
from typing import Optional
from dataclasses import dataclass

from .config import ApiConfig
from .exceptions import ProjectError
from .utils import ensure_directory, run_command


@dataclass
class ProjectSpec:
    """Specification for project generation."""
    app_name: str
    dest_dir: str
    package_name: Optional[str] = None
    
    @property
    def project_dir(self) -> str:
        """Full path to project directory."""
        return os.path.join(self.dest_dir, self.app_name)
    
    @property
    def java_package_name(self) -> str:
        """Java package name derived from app name."""
        if self.package_name:
            return self.package_name
        
        # Create a valid Java package name (no hyphens)
        package_name_part = re.sub(r'[^a-zA-Z0-9]', '', self.app_name)
        return f"com.example.{package_name_part}"


class ProjectGenerator:
    """Handles Micronaut project generation and setup."""
    
    def generate_micronaut_project(self, spec: ProjectSpec) -> None:
        """
        Generate a new Micronaut project.
        
        Args:
            spec: Project specification
            
        Raises:
            ProjectError: If project generation fails
        """
        print(f"\nGenerating Micronaut project '{spec.app_name}' in '{spec.project_dir}' ...")
        
        parent_dir = os.path.dirname(spec.project_dir)
        ensure_directory(parent_dir)
        
        # Create a valid Java package name (no hyphens)
        package_name_part = re.sub(r'[^a-zA-Z0-9]', '', spec.app_name)
        
        try:
            # mn create-app creates a directory from the last part of the package name
            run_command([
                "mn", "create-app", f"com.example.{package_name_part}",
                "--features", "amazon-api-gateway,aws-lambda",
                "--build", "gradle",
                "--lang", "java"
            ], cwd=parent_dir)
            
            # Rename the generated directory to the desired one
            generated_dir = os.path.join(parent_dir, package_name_part)
            if os.path.isdir(generated_dir) and generated_dir != spec.project_dir:
                os.rename(generated_dir, spec.project_dir)
            
            print("Project generated successfully.")
            
        except subprocess.CalledProcessError as e:
            raise ProjectError(f"Error generating Micronaut project: {e}")
        except OSError as e:
            raise ProjectError(f"Error setting up project directory: {e}")
    
    def patch_gradle_build(self, project_dir: str) -> None:
        """
        Patch Gradle build file for AWS Lambda compatibility.
        
        Args:
            project_dir: Path to project directory
            
        Raises:
            ProjectError: If patching fails
        """
        print("\nPatching build.gradle for AWS Lambda compatibility...")
        
        gradle_file = os.path.join(project_dir, "build.gradle")
        if not os.path.isfile(gradle_file):
            raise ProjectError("Cannot find build.gradle to patch.")
        
        try:
            with open(gradle_file, "r") as f:
                content = f.read()
            
            # 1. Add the Micronaut AWS dependency
            dependency = "io.micronaut.aws:micronaut-function-aws-api-proxy"
            if dependency not in content:
                content = content.replace(
                    "dependencies {",
                    f"""dependencies {{\n    implementation("{dependency}")"""
                )
            
            # 2. Remove existing java compatibility settings if they exist to avoid conflicts
            content = re.sub(r'java \{\n    sourceCompatibility = JavaVersion.toVersion\("[\d.]+"\)\n}', '', content)
            content = re.sub(r'sourceCompatibility = .*', '', content)
            content = re.sub(r'targetCompatibility = .*', '', content)
            
            # 3. Add the Java 17 toolchain to ensure the correct bytecode version is produced
            java_toolchain_config = """java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(17)
    }
}
"""
            
            # Replace empty java block or add after application block
            if re.search(r'java \{\s*\}', content):
                # Replace empty java block
                content = re.sub(r'java \{\s*\}', java_toolchain_config.strip(), content)
            elif "java {" not in content:
                # Find the application block and insert the java config after it
                content = re.sub(r'(application \{.*?\n})', r'\1\n' + java_toolchain_config, content, flags=re.DOTALL)
            
            with open(gradle_file, "w") as f:
                f.write(content)
            
            print("Patched build.gradle with Java 17 toolchain and AWS dependency.")
            
        except IOError as e:
            raise ProjectError(f"Error patching build.gradle: {e}")
    
    def create_default_controller(self, spec: ProjectSpec) -> None:
        """
        Create a default AppController for simple projects.
        
        Args:
            spec: Project specification
            
        Raises:
            ProjectError: If controller creation fails
        """
        print("\nCreating a unified AppController...")
        
        package_name_part = re.sub(r'[^a-zA-Z0-9]', '', spec.app_name)
        package_name = f"com.example.{package_name_part}"
        package_path = os.path.join(spec.project_dir, "src", "main", "java", "com", "example", package_name_part)
        
        ensure_directory(package_path)
        
        # This combined controller will be the single source file for the app logic
        controller_code = f"""package {package_name};

import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import java.util.Collections;
import java.util.Map;

@Controller("/hello")
public class AppController {{

    @Get
    public Map<String, String> index() {{
        return Collections.singletonMap("message", "Micronaut AWS API Gateway working!");
    }}
}}
"""
        
        controller_file = os.path.join(package_path, "AppController.java")
        try:
            with open(controller_file, "w") as f:
                f.write(controller_code)
            print(f"Unified AppController created at: {controller_file}")
        except IOError as e:
            raise ProjectError(f"Error creating AppController: {e}")
    
    def generate_controllers_from_config(self, api_config: ApiConfig, project_dir: str) -> None:
        """
        Generate Micronaut controllers from API configuration.
        
        Args:
            api_config: Parsed API configuration
            project_dir: Path to project directory
            
        Raises:
            ProjectError: If controller generation fails
        """
        print("Generating Micronaut controllers from API config...")
        
        try:
            from collections import defaultdict
            
            package = api_config.service.package
            routes = api_config.routes
            
            # Create package directory structure
            pkg_path = os.path.join(*package.split('.'))
            src_pkg_dir = os.path.join(project_dir, 'src', 'main', 'java', pkg_path)
            ensure_directory(src_pkg_dir)
            
            # Group routes by controller
            by_controller = defaultdict(list)
            for route in routes:
                by_controller[route.controller].append(route)
            
            # Generate each controller
            for controller_name, controller_routes in by_controller.items():
                self._generate_controller(
                    controller_name, 
                    controller_routes, 
                    package, 
                    src_pkg_dir
                )
            
            print("Generated Micronaut controllers from API config.")
            
        except Exception as e:
            raise ProjectError(f"Error generating controllers from config: {e}")
    
    def _generate_controller(self, controller_name: str, routes: list, package: str, output_dir: str) -> None:
        """Generate a single controller class."""
        class_name = re.sub(r'[^A-Za-z0-9]', '', controller_name)
        
        # Collect imports
        imports = {"io.micronaut.http.annotation.Controller"}
        method_imports = set()
        has_path_vars = False
        
        for route in routes:
            method_annotation = self._get_method_annotation(route.method)
            method_imports.add(f"io.micronaut.http.annotation.{method_annotation}")
            if self._extract_path_params(route.path):
                has_path_vars = True
        
        imports |= method_imports
        if has_path_vars:
            imports.add("io.micronaut.http.annotation.PathVariable")
        
        imports_block = "\n".join(sorted(f"import {imp};" for imp in imports))
        
        # Generate methods
        methods_src = []
        for route in routes:
            method_src = self._generate_method(route)
            methods_src.append(method_src)
        
        # Generate class
        class_src = f"""package {package};

{imports_block}

@Controller
public class {class_name} {{
{''.join(methods_src)}}}
"""
        
        # Write to file
        output_file = os.path.join(output_dir, f"{class_name}.java")
        with open(output_file, 'w') as f:
            f.write(class_src)
    
    def _generate_method(self, route) -> str:
        """Generate a single method for a route."""
        annotation = self._get_method_annotation(route.method)
        uri = route.path
        method_name = re.sub(r'[^A-Za-z0-9_]', '', route.method_name) or 'handler'
        
        # Extract path parameters and create method parameters
        path_params = self._extract_path_params(uri)
        method_params = []
        for param in path_params:
            # Sanitize parameter name for Java
            param_name = re.sub(r'[^A-Za-z0-9_]', '', param)
            method_params.append(f"@PathVariable String {param_name}")
        
        params_str = ", ".join(method_params)
        
        return f"""    @{annotation}("{uri}")
    public String {method_name}({params_str}) {{
        return "OK";
    }}

"""
    
    def _get_method_annotation(self, method: str) -> str:
        """Get Micronaut annotation for HTTP method."""
        return {
            'get': 'Get',
            'post': 'Post',
            'put': 'Put',
            'delete': 'Delete',
            'patch': 'Patch',
            'options': 'Options',
            'head': 'Head',
        }[method.lower()]
    
    def _extract_path_params(self, path: str) -> list:
        """Extract path parameters from a route path like /users/{id} -> ['id']"""
        return re.findall(r'\{([^}]+)\}', path)
    
    def remove_default_generated_files(self, project_dir: str) -> None:
        """
        Clean up default generated files from the standard 'com.example' package.
        
        Args:
            project_dir: Path to project directory
        """
        default_package_path = os.path.join(project_dir, "src", "main", "java", "com", "example")
        
        for file_name in ["Application.java", "HomeController.java"]:
            default_file = os.path.join(default_package_path, file_name)
            if os.path.exists(default_file):
                try:
                    os.remove(default_file)
                    print(f"Removed default file: {file_name}")
                except OSError as e:
                    print(f"Warning: Could not remove {file_name}: {e}")
    
    def generate_github_workflows(self, project_dir: str, app_name: str, aws_region: str, requires_key: bool = False) -> None:
        """
        Generate GitHub Actions workflows for the project.
        
        Args:
            project_dir: Path to project directory
            app_name: Application name
            aws_region: AWS region for deployment
            requires_key: Whether API key is required
            
        Raises:
            ProjectError: If workflow generation fails
        """
        print("\nGenerating GitHub Actions workflows...")
        
        try:
            # Create .github/workflows directory
            workflows_dir = os.path.join(project_dir, ".github", "workflows")
            ensure_directory(workflows_dir)
            
            # Read the CI/CD template
            template_path = os.path.join(
                os.path.dirname(__file__), 
                "templates", 
                "workflows", 
                "ci-cd.yml"
            )
            
            if not os.path.exists(template_path):
                raise ProjectError(f"Workflow template not found: {template_path}")
            
            with open(template_path, "r") as f:
                template_content = f.read()
            
            # Replace template variables
            workflow_content = template_content.replace("{{APP_NAME}}", app_name)
            workflow_content = workflow_content.replace("{{AWS_REGION}}", aws_region)
            
            # Handle conditional API key sections
            if requires_key:
                workflow_content = workflow_content.replace("{{#if REQUIRES_KEY}}", "")
                workflow_content = workflow_content.replace("{{/if}}", "")
            else:
                # Remove API key sections
                import re
                workflow_content = re.sub(
                    r'{{#if REQUIRES_KEY}}.*?{{/if}}', 
                    '', 
                    workflow_content, 
                    flags=re.DOTALL
                )
            
            # Write the workflow file
            workflow_file = os.path.join(workflows_dir, "ci-cd.yml")
            with open(workflow_file, "w") as f:
                f.write(workflow_content)
            
            print(f"Generated GitHub Actions workflow: {workflow_file}")
            
        except Exception as e:
            raise ProjectError(f"Error generating GitHub workflows: {e}")
