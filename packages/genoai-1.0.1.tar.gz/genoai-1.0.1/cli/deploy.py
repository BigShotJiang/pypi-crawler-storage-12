"""
Deployment operations module for AWS SAM.

Handles SAM deployment, stack management, and API details retrieval.
"""

import json
import subprocess
from typing import Optional, Dict, Any
from dataclasses import dataclass

from .exceptions import DeployError
from .utils import run_command


@dataclass
class DeploySpec:
    """Specification for deployment."""
    stack_name: str
    region: str
    aws_profile: Optional[str] = None
    use_profile: bool = True


@dataclass
class ApiDetails:
    """Details of deployed API."""
    api_url: str
    stack_name: str
    region: str
    api_key: Optional[str] = None


@dataclass
class DeployResult:
    """Result of deployment operation."""
    success: bool
    stack_name: Optional[str] = None
    api_details: Optional[ApiDetails] = None
    error_message: Optional[str] = None


class DeploymentManager:
    """Handles AWS SAM deployment operations."""
    
    def deploy_to_aws(self, spec: DeploySpec, project_dir: str) -> DeployResult:
        """
        Deploy application to AWS using SAM.
        
        Args:
            spec: Deployment specification
            project_dir: Path to project directory
            
        Returns:
            DeployResult with deployment status
        """
        print("\nDeploying to AWS via SAM...")
        
        try:
            # Build deployment command
            deploy_cmd = [
                "sam", "deploy", 
                "--stack-name", spec.stack_name, 
                "--capabilities", "CAPABILITY_IAM",
                "--region", spec.region, 
                "--resolve-s3",
                "--no-confirm-changeset", 
                "--no-fail-on-empty-changeset"
            ]
            
            if spec.use_profile and spec.aws_profile:
                deploy_cmd.extend(["--profile", spec.aws_profile])
            
            # Execute deployment
            run_command(deploy_cmd, cwd=project_dir)
            
            print("\nDeployment finished successfully!")
            return DeployResult(success=True, stack_name=spec.stack_name)
            
        except subprocess.CalledProcessError as e:
            error_msg = f"SAM deployment failed: {e}"
            if hasattr(e, 'stderr') and e.stderr:
                error_msg += f"\nError details: {e.stderr}"
            
            return DeployResult(
                success=False,
                error_message=error_msg
            )
    
    def get_api_details(
        self, 
        stack_name: str, 
        region: str, 
        aws_profile: Optional[str] = None,
        requires_key: bool = True, 
        use_profile: bool = True
    ) -> ApiDetails:
        """
        Get API Gateway URL and API key from deployed stack.
        
        Args:
            stack_name: CloudFormation stack name
            region: AWS region
            aws_profile: AWS profile name
            requires_key: Whether API key is required
            use_profile: Whether to use AWS profile
            
        Returns:
            ApiDetails object
            
        Raises:
            DeployError: If API details retrieval fails
        """
        print("\nFetching deployed API Gateway URL and API Key...")
        
        try:
            # Get stack outputs
            describe_cmd = [
                "aws", "cloudformation", "describe-stacks",
                "--stack-name", stack_name,
                "--region", region,
                "--query", "Stacks[0].Outputs",
                "--output", "json"
            ]
            
            if use_profile and aws_profile:
                describe_cmd.extend(["--profile", aws_profile])
            
            result = run_command(describe_cmd, capture_output=True)
            outputs = json.loads(result.stdout)
            
            # Extract API URL
            api_url = self._find_output_value(outputs, "ApiUrl")
            if not api_url:
                raise DeployError("Could not find ApiUrl in stack outputs", stack_name)
            
            # Extract API key if required
            api_key = None
            if requires_key:
                api_key_id = self._find_output_value(outputs, "ApiKey")
                if not api_key_id:
                    raise DeployError("Could not find ApiKey in stack outputs but API key was required", stack_name)
                
                api_key = self._get_api_key_value(api_key_id, region, aws_profile, use_profile)
            
            api_details = ApiDetails(
                api_url=api_url,
                api_key=api_key,
                stack_name=stack_name,
                region=region
            )
            
            self._print_api_details(api_details, requires_key)
            return api_details
            
        except subprocess.CalledProcessError as e:
            raise DeployError(f"Failed to fetch API details: {e}", stack_name)
        except (json.JSONDecodeError, KeyError) as e:
            raise DeployError(f"Error parsing AWS CLI output: {e}", stack_name)
    
    def delete_stack(
        self, 
        stack_name: str, 
        region: str, 
        aws_profile: Optional[str] = None,
        use_profile: bool = True
    ) -> None:
        """
        Delete CloudFormation stack.
        
        Args:
            stack_name: Stack name to delete
            region: AWS region
            aws_profile: AWS profile name
            use_profile: Whether to use AWS profile
            
        Raises:
            DeployError: If stack deletion fails
        """
        print(f"\nDeleting SAM stack '{stack_name}' in region '{region}'...")
        
        try:
            delete_cmd = [
                "sam", "delete",
                "--stack-name", stack_name,
                "--region", region,
                "--no-prompts"
            ]
            
            if use_profile and aws_profile:
                delete_cmd.extend(["--profile", aws_profile])
            
            run_command(delete_cmd)
            print("\nDeletion finished successfully!")
            
        except subprocess.CalledProcessError as e:
            error_msg = f"Stack deletion failed: {e}"
            if hasattr(e, 'stderr') and e.stderr:
                error_msg += f"\nError details: {e.stderr}"
            raise DeployError(error_msg, stack_name)
    
    def _find_output_value(self, outputs: list, key: str) -> Optional[str]:
        """Find output value by key in CloudFormation outputs."""
        for output in outputs:
            if output.get('OutputKey') == key:
                return output.get('OutputValue')
        return None
    
    def _get_api_key_value(
        self, 
        api_key_id: str, 
        region: str, 
        aws_profile: Optional[str],
        use_profile: bool
    ) -> str:
        """Get API key value from API Gateway."""
        get_key_cmd = [
            "aws", "apigateway", "get-api-key",
            "--api-key", api_key_id,
            "--include-value",
            "--region", region
        ]
        
        if use_profile and aws_profile:
            get_key_cmd.extend(["--profile", aws_profile])
        
        try:
            result = run_command(get_key_cmd, capture_output=True)
            key_data = json.loads(result.stdout)
            return key_data['value']
        except (subprocess.CalledProcessError, json.JSONDecodeError, KeyError) as e:
            raise DeployError(f"Failed to retrieve API key value: {e}")
    
    def _print_api_details(self, api_details: ApiDetails, requires_key: bool) -> None:
        """Print API details to console."""
        print("\n--- Deployment Details ---")
        print(f"API Gateway URL: {api_details.api_url}")
        
        if requires_key and api_details.api_key:
            print(f"API Key: {api_details.api_key}")
            print("\nTo test your API, use the following command:")
            print(f'curl --header "x-api-key: {api_details.api_key}" {api_details.api_url}')
        else:
            print("\nTo test your API, use the following command:")
            print(f"curl {api_details.api_url}")
    
    def list_stacks(
        self, 
        region: str, 
        aws_profile: Optional[str] = None,
        use_profile: bool = True,
        name_pattern: Optional[str] = None
    ) -> list[str]:
        """
        List CloudFormation stacks, optionally filtered by name pattern.
        
        Args:
            region: AWS region
            aws_profile: AWS profile name
            use_profile: Whether to use AWS profile
            name_pattern: Optional pattern to filter stack names
            
        Returns:
            List of stack names
            
        Raises:
            DeployError: If listing fails
        """
        try:
            list_cmd = [
                "aws", "cloudformation", "list-stacks",
                "--stack-status-filter", "CREATE_COMPLETE", "UPDATE_COMPLETE",
                "--region", region,
                "--query", "StackSummaries[].StackName",
                "--output", "text"
            ]
            
            if use_profile and aws_profile:
                list_cmd.extend(["--profile", aws_profile])
            
            result = run_command(list_cmd, capture_output=True)
            stack_names = result.stdout.strip().split()
            
            if name_pattern:
                stack_names = [name for name in stack_names if name_pattern in name]
            
            return stack_names
            
        except subprocess.CalledProcessError as e:
            raise DeployError(f"Failed to list stacks: {e}")
