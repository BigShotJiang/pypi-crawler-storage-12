"""
Configuration management for the Micronaut SAM CLI.

Handles loading and validation of environment configurations and API configs.
"""

import os
import yaml
from typing import Dict, Any, Optional
from dataclasses import dataclass

from .exceptions import ConfigError


@dataclass
class EnvironmentConfig:
    """Environment-specific configuration."""
    aws_region: str
    aws_profile: str
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'EnvironmentConfig':
        """Create EnvironmentConfig from dictionary."""
        try:
            return cls(
                aws_region=data['aws_region'],
                aws_profile=data['aws_profile']
            )
        except KeyError as e:
            raise ConfigError(f"Missing required configuration key: {e}")


@dataclass
class ServiceConfig:
    """Service configuration from API config."""
    name: str
    package: str


@dataclass
class RouteConfig:
    """Route configuration from API config."""
    path: str
    method: str
    controller: str
    method_name: str


@dataclass
class ApiConfig:
    """API configuration parsed from YAML."""
    service: ServiceConfig
    routes: list[RouteConfig]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ApiConfig':
        """Create ApiConfig from dictionary."""
        try:
            service_data = data['service']
            service = ServiceConfig(
                name=service_data['name'],
                package=service_data['package']
            )
            
            routes_data = data['routes']
            routes = []
            for route_data in routes_data:
                route = RouteConfig(
                    path=route_data['path'],
                    method=route_data['method'].lower(),
                    controller=route_data['controller'],
                    method_name=route_data['methodName']
                )
                routes.append(route)
            
            return cls(service=service, routes=routes)
        except KeyError as e:
            raise ConfigError(f"Missing required API config key: {e}")


class ConfigManager:
    """Manages configuration loading and validation."""
    
    def __init__(self, config_dir: str = "config"):
        """
        Initialize ConfigManager.
        
        Args:
            config_dir: Directory containing configuration files
        """
        self.config_dir = config_dir
    
    def load_environment_config(self, env: str) -> EnvironmentConfig:
        """
        Load environment-specific configuration.
        
        Args:
            env: Environment name (dev, stage, prod)
            
        Returns:
            EnvironmentConfig object
            
        Raises:
            ConfigError: If config file not found or invalid
        """
        config_path = os.path.join(self.config_dir, f"{env}.yaml")
        
        if not os.path.isfile(config_path):
            raise ConfigError(
                f"Configuration file not found for environment '{env}' at '{config_path}'",
                config_path
            )
        
        try:
            with open(config_path, "r") as f:
                data = yaml.safe_load(f)
                if not data:
                    raise ConfigError(f"Empty configuration file: {config_path}", config_path)
                
                config = EnvironmentConfig.from_dict(data)
                print(f"Loaded configuration for '{env}' environment.")
                return config
                
        except yaml.YAMLError as e:
            raise ConfigError(f"Error parsing YAML file {config_path}: {e}", config_path)
        except IOError as e:
            raise ConfigError(f"Error reading config file {config_path}: {e}", config_path)
    
    def parse_api_config(self, path: str) -> ApiConfig:
        """
        Parse API configuration from YAML file.
        
        Args:
            path: Path to API config file
            
        Returns:
            ApiConfig object
            
        Raises:
            ConfigError: If config file not found or invalid
        """
        if not path:
            raise ConfigError("Config path is empty")
        
        abs_path = os.path.abspath(os.path.expanduser(path))
        if not os.path.isfile(abs_path):
            raise ConfigError(f"Config file not found: {abs_path}", abs_path)
        
        try:
            with open(abs_path, "r") as f:
                data = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            raise ConfigError(f"YAML parse error in {abs_path}: {e}", abs_path)
        except IOError as e:
            raise ConfigError(f"Error reading API config file {abs_path}: {e}", abs_path)
        
        # Validate and parse the config
        self._validate_api_config(data, abs_path)
        return ApiConfig.from_dict(data)
    
    def _validate_api_config(self, cfg: Dict[str, Any], config_path: str) -> None:
        """
        Validate API configuration structure.
        
        Args:
            cfg: Configuration dictionary
            config_path: Path to config file (for error messages)
            
        Raises:
            ConfigError: If configuration is invalid
        """
        if not isinstance(cfg, dict):
            raise ConfigError("Config root must be a mapping", config_path)
        
        # Validate service block
        service = cfg.get("service")
        if not isinstance(service, dict):
            raise ConfigError("Missing required 'service' block", config_path)
        
        name = service.get("name")
        package = service.get("package")
        if not name or not isinstance(name, str):
            raise ConfigError("service.name must be a non-empty string", config_path)
        if not package or not isinstance(package, str):
            raise ConfigError("service.package must be a non-empty string", config_path)
        
        # Validate routes block
        routes = cfg.get("routes")
        if not isinstance(routes, list) or not routes:
            raise ConfigError("routes must be a non-empty list", config_path)
        
        # Validate each route
        for i, route in enumerate(routes):
            if not isinstance(route, dict):
                raise ConfigError(f"routes[{i}] must be a mapping", config_path)
            
            for key in ["path", "method", "controller", "methodName"]:
                if key not in route or not isinstance(route[key], str) or not route[key].strip():
                    raise ConfigError(f"routes[{i}].{key} must be a non-empty string", config_path)
            
            # Validate HTTP method
            method = route["method"].lower()
            valid_methods = ["get", "post", "put", "delete", "patch", "options", "head"]
            if method not in valid_methods:
                raise ConfigError(
                    f"routes[{i}].method '{method}' is not a supported HTTP method", 
                    config_path
                )
