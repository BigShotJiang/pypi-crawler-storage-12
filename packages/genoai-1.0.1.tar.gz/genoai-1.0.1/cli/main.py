"""
GenoAI CLI (click-based)

Command-line interface that orchestrates project generation, build, and deploy
workflows. Provides progress indicators, improved error messages, and helpers
like shell completion.
"""

import os
import sys
import click
from typing import Optional, List, Tuple, Callable

from .version import __version__
from . import (
    CLIError,
    ConfigError,
    ProjectError,
    BuildError,
    DeployError,
    ConfigManager,
    ProjectGenerator,
    BuildManager,
    DeploymentManager,
    sanitize_app_name,
    check_cli_tools,
)
from .config import ApiConfig, EnvironmentConfig
from .project import ProjectSpec
from .build import TemplateSpec
from .deploy import DeploySpec


class _Ctx:
    """Holds shared managers for commands."""

    def __init__(self):
        self.config_manager = ConfigManager()
        self.project_generator = ProjectGenerator()
        self.build_manager = BuildManager()
        self.deployment_manager = DeploymentManager()


pass_ctx = click.make_pass_decorator(_Ctx, ensure=True)


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(version=__version__)
@click.pass_context
def main(ctx: click.Context):
    """GenoAI command-line tool."""
    ctx.obj = _Ctx()


def _load_env(cfg_mgr: ConfigManager, env: str) -> EnvironmentConfig:
    return cfg_mgr.load_environment_config(env)


def _parse_api_config(cfg_mgr: ConfigManager, api_config: Optional[str]) -> Optional[ApiConfig]:
    if not api_config:
        return None
    return cfg_mgr.parse_api_config(api_config)


def _with_progress(label: str, steps: List[Tuple[str, Callable[[], None]]]):
    with click.progressbar(range(len(steps)), label=label) as bar:
        for i, (_, fn) in enumerate(steps):
            fn()
            bar.update(1)


@main.command("init")
@pass_ctx
@click.option("--env", "env_", required=True, type=click.Choice(["dev", "stage", "prod"]))
@click.option("--api-config", type=click.Path(exists=True, dir_okay=False))
@click.option("--requires-key", is_flag=True, help="Require API key for all routes")
@click.option("--non-interactive", is_flag=True, help="Run without prompts (CI mode)")
@click.option("--project-name", type=str)
@click.option("--dest-dir", type=click.Path(file_okay=False))
def cmd_init(ctx: _Ctx, env_: str, api_config: Optional[str], requires_key: bool, non_interactive: bool, project_name: Optional[str], dest_dir: Optional[str]):
    """Initialize, build and optionally deploy a project (no deploy here)."""
    try:
        if not non_interactive:
            check_cli_tools(interactive=True)

        # Resolve project details
        if non_interactive:
            if not project_name:
                raise CLIError("--project-name is required when using --non-interactive")
            app_name = sanitize_app_name(project_name)
            dest_dir_resolved = os.path.abspath(dest_dir) if dest_dir else os.getcwd()
        else:
            from .utils import ask_user_input

            app_name, dest_dir_resolved = ask_user_input()

        env_cfg = _load_env(ctx.config_manager, env_)
        api_cfg = _parse_api_config(ctx.config_manager, api_config)

        project_spec = ProjectSpec(app_name=app_name, dest_dir=dest_dir_resolved)

        steps = [
            ("Generate project", lambda: ctx.project_generator.generate_micronaut_project(project_spec)),
            ("Patch Gradle", lambda: ctx.project_generator.patch_gradle_build(project_spec.project_dir)),
            ("Gradle wrapper", lambda: ctx.build_manager.ensure_gradle_wrapper(project_spec.project_dir)),
            (
                "Controllers",
                lambda: (
                    ctx.project_generator.generate_controllers_from_config(api_cfg, project_spec.project_dir)
                    if api_cfg
                    else ctx.project_generator.create_default_controller(project_spec)
                ),
            ),
            ("Clean defaults", lambda: ctx.project_generator.remove_default_generated_files(project_spec.project_dir)),
            (
                "SAM template",
                lambda: ctx.build_manager.create_sam_template(
                    TemplateSpec(
                        app_name=app_name,
                        region=env_cfg.aws_region,
                        proxy_all=bool(api_cfg),
                        requires_key=requires_key,
                    ),
                    project_spec.project_dir,
                ),
            ),
            (
                "Workflows",
                lambda: ctx.project_generator.generate_github_workflows(
                    project_spec.project_dir, app_name, env_cfg.aws_region, requires_key
                ),
            ),
        ]

        _with_progress("Initializing project", steps)

        click.echo("\nProject initialized successfully.")
        click.echo(f"Location: {project_spec.project_dir}")
        click.echo("Next: build with 'genoai build' or deploy with 'genoai deploy'.")
    except (CLIError, ConfigError, ProjectError, BuildError) as e:
        raise click.ClickException(str(e))
    except KeyboardInterrupt:
        raise click.ClickException("Operation cancelled by user.")


@main.command("deploy")
@pass_ctx
@click.option("--env", "env_", required=True, type=click.Choice(["dev", "stage", "prod"]))
@click.option("--requires-key", is_flag=True)
@click.option("--non-interactive", is_flag=True)
@click.option("--project-name", type=str)
@click.option("--dest-dir", type=click.Path(file_okay=False))
def cmd_deploy(ctx: _Ctx, env_: str, requires_key: bool, non_interactive: bool, project_name: Optional[str], dest_dir: Optional[str]):
    """Build and deploy the current project directory to AWS."""
    try:
        env_cfg = _load_env(ctx.config_manager, env_)

        if non_interactive is False:
            check_cli_tools(interactive=True)

        # Determine project directory and app name
        project_dir = os.path.abspath(dest_dir) if dest_dir else os.getcwd()
        app_name = sanitize_app_name(project_name or os.path.basename(project_dir))
        stack_name = f"{app_name}-{env_}-stack"

        steps = [
            ("Build JAR", lambda: _assert_success(ctx.build_manager.build_jar(project_dir))),
            (
                "Deploy",
                lambda: _assert_success(
                    ctx.deployment_manager.deploy_to_aws(
                        DeploySpec(
                            stack_name=stack_name,
                            region=env_cfg.aws_region,
                            aws_profile=env_cfg.aws_profile,
                            use_profile=not non_interactive,
                        ),
                        project_dir,
                    )
                ),
            ),
        ]

        _with_progress("Deploying", steps)

        # Fetch API details after deploy
        ctx.deployment_manager.get_api_details(
            stack_name=stack_name,
            region=env_cfg.aws_region,
            aws_profile=env_cfg.aws_profile,
            requires_key=requires_key,
            use_profile=not non_interactive,
        )

        click.echo(f"\n🎉 Successfully deployed '{app_name}' to AWS!")
    except (CLIError, ConfigError, ProjectError, BuildError, DeployError) as e:
        raise click.ClickException(str(e))
    except KeyboardInterrupt:
        raise click.ClickException("Operation cancelled by user.")


def _assert_success(result):
    if hasattr(result, "success") and not result.success:
        raise BuildError(getattr(result, "error_message", None) or "Operation failed")
    return result


@main.command("delete-all")
@pass_ctx
@click.argument("project_path", type=click.Path(exists=True, file_okay=False))
@click.option("--env", "env_", required=True, type=click.Choice(["dev", "stage", "prod"]))
@click.option("--non-interactive", is_flag=True)
def cmd_delete_all(ctx: _Ctx, project_path: str, env_: str, non_interactive: bool):
    """Delete the stack and remove the given project directory."""
    try:
        env_cfg = _load_env(ctx.config_manager, env_)
        folder_name = os.path.basename(os.path.abspath(project_path))
        app_name = sanitize_app_name(folder_name)
        stack_name = f"{app_name}-{env_}-stack"

        ctx.deployment_manager.delete_stack(
            stack_name, env_cfg.aws_region, env_cfg.aws_profile, not non_interactive
        )

        import shutil

        click.echo(f"Removing project directory '{project_path}' ...")
        shutil.rmtree(project_path)
        click.echo("Directory removal finished successfully!")
    except DeployError as e:
        raise click.ClickException(f"Stack deletion failed: {e}")
    except Exception as e:
        raise click.ClickException(str(e))


@main.command("delete-stack")
@pass_ctx
@click.argument("app_name")
@click.option("--env", "env_", required=True, type=click.Choice(["dev", "stage", "prod"]))
@click.option("--non-interactive", is_flag=True)
def cmd_delete_stack(ctx: _Ctx, app_name: str, env_: str, non_interactive: bool):
    """Delete the SAM stack for the given app name."""
    try:
        env_cfg = _load_env(ctx.config_manager, env_)
        app_name_clean = sanitize_app_name(app_name)
        stack_name = f"{app_name_clean}-{env_}-stack"
        ctx.deployment_manager.delete_stack(
            stack_name, env_cfg.aws_region, env_cfg.aws_profile, not non_interactive
        )
        click.echo("Stack deletion initiated.")
    except DeployError as e:
        raise click.ClickException(f"Stack deletion failed: {e}")


@main.command("completion")
@click.argument("shell", type=click.Choice(["bash", "zsh", "fish"]))
def cmd_completion(shell: str):
    """Print shell completion script for the specified shell."""
    try:
        # Follow Click guidance for on-demand completion scripts
        prog = "genoai"
        if shell == "bash":
            click.echo(f'eval "$( _{prog.upper()}_COMPLETE=bash_source {prog} )"')
        elif shell == "zsh":
            click.echo(f'eval "$( _{prog.upper()}_COMPLETE=zsh_source {prog} )"')
        elif shell == "fish":
            click.echo(f'eval ( _{prog.upper()}_COMPLETE=fish_source {prog} )')
    except Exception as e:
        raise click.ClickException(str(e))


if __name__ == "__main__":
    main()
