"""
Version information for the Micronaut SAM CLI.
"""

__version__ = "1.0.3"
__version_info__ = (1, 0, 3)

# Version history
VERSION_HISTORY = {
    "1.0.3": {
        "date": "2025-11-16",
        "description": "Publish retry after adding PyPI Trusted Publisher; no code changes",
        "features": [
            "Release metadata only"
        ]
    },
    "1.0.2": {
        "date": "2025-11-16",
        "description": "Fix publish workflow action reference; OIDC release pipeline",
        "features": [
            "Correct pypa/gh-action-pypi-publish tag to release/v1",
            "Publish via PyPI Trusted Publishing (OIDC)"
        ]
    },
    "1.0.1": {
        "date": "2025-11-16",
        "description": "Refactor CLI to click, add version flag, progress indicators, and completion command",
        "features": [
            "Switched CLI from argparse to click",
            "Added --version flag",
            "Added progress bars for init/deploy steps",
            "Added shell completion helper command"
        ]
    },
    "1.0.0": {
        "date": "2025-11-16",
        "description": "Initial release with modular architecture",
        "features": [
            "Modular CLI architecture following SOLID principles",
            "Comprehensive test suite with 100+ tests",
            "Pipenv dependency management",
            "GitHub Actions workflow generation",
            "API config-driven controller generation",
            "Multi-environment deployment support",
            "SAM template generation with optional API keys",
            "Backward compatibility with original CLI"
        ]
    }
}

def get_version() -> str:
    """Get the current version string."""
    return __version__

def get_version_info() -> tuple:
    """Get the current version as a tuple."""
    return __version_info__

def get_version_details() -> dict:
    """Get detailed version information."""
    return {
        "version": __version__,
        "version_info": __version_info__,
        "history": VERSION_HISTORY.get(__version__, {})
    }
