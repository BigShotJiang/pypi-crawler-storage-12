"""
Micronaut + AWS SAM CLI Package

A modular CLI for generating, building, and deploying Micronaut applications
to AWS Lambda with API Gateway using SAM.
"""

from .version import __version__, __version_info__, get_version, get_version_details

__author__ = "Micronaut SAM CLI"

from .exceptions import (
    CLIError,
    ConfigError,
    ProjectError,
    BuildError,
    DeployError
)

from .config import ConfigManager
from .project import ProjectGenerator
from .build import BuildManager
from .deploy import DeploymentManager
from .utils import sanitize_app_name, check_cli_tools

__all__ = [
    "CLIError",
    "ConfigError", 
    "ProjectError",
    "BuildError",
    "DeployError",
    "ConfigManager",
    "ProjectGenerator", 
    "BuildManager",
    "DeploymentManager",
    "sanitize_app_name",
    "check_cli_tools"
]
