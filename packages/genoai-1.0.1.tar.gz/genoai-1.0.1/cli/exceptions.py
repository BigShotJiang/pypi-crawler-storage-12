"""
Custom exceptions for the Micronaut SAM CLI.

Provides specific exception types for different error categories
to enable better error handling and user feedback.
"""


class CLIError(Exception):
    """Base exception for all CLI-related errors."""
    
    def __init__(self, message: str, exit_code: int = 1):
        super().__init__(message)
        self.exit_code = exit_code


class ConfigError(CLIError):
    """Raised when configuration loading or validation fails."""
    
    def __init__(self, message: str, config_path: str = None):
        super().__init__(message)
        self.config_path = config_path


class ProjectError(CLIError):
    """Raised when project generation or setup fails."""
    
    def __init__(self, message: str, project_path: str = None):
        super().__init__(message)
        self.project_path = project_path


class BuildError(CLIError):
    """Raised when build operations fail."""
    
    def __init__(self, message: str, build_step: str = None):
        super().__init__(message)
        self.build_step = build_step


class DeployError(CLIError):
    """Raised when deployment operations fail."""
    
    def __init__(self, message: str, stack_name: str = None):
        super().__init__(message)
        self.stack_name = stack_name


class ToolNotFoundError(CLIError):
    """Raised when required CLI tools are not found."""
    
    def __init__(self, tool_name: str, install_url: str = None):
        message = f"{tool_name} not found."
        if install_url:
            message += f" Install: {install_url}"
        super().__init__(message)
        self.tool_name = tool_name
        self.install_url = install_url
