"""
Utility functions for the Micronaut SAM CLI.

Contains shared helper functions used across multiple modules.
"""

import os
import re
import subprocess
from typing import Tuple, Optional
from dataclasses import dataclass

from .exceptions import ToolNotFoundError, ProjectError


@dataclass
class ToolCheckResult:
    """Result of CLI tool availability check."""
    aws_cli: bool = False
    sam_cli: bool = False
    micronaut_cli: bool = False
    
    @property
    def all_available(self) -> bool:
        return self.aws_cli and self.sam_cli and self.micronaut_cli


def sanitize_app_name(name: str) -> str:
    """
    Sanitize application name for use in file paths and identifiers.
    
    Args:
        name: Raw application name
        
    Returns:
        Sanitized name with only alphanumeric characters and underscores
    """
    return re.sub(r'[^a-zA-Z0-9_]', '_', name.lower())


def check_cli_tools(interactive: bool = True) -> ToolCheckResult:
    """
    Check availability of required CLI tools.
    
    Args:
        interactive: If True, raise exceptions for missing tools.
                    If False, return status without raising.
                    
    Returns:
        ToolCheckResult with availability status
        
    Raises:
        ToolNotFoundError: If interactive=True and tools are missing
    """
    result = ToolCheckResult()
    
    # Check AWS CLI
    try:
        subprocess.run(
            ["aws", "--version"], 
            check=True, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE
        )
        result.aws_cli = True
    except (subprocess.CalledProcessError, FileNotFoundError):
        if interactive:
            raise ToolNotFoundError("AWS CLI", "https://aws.amazon.com/cli/")
    
    # Check SAM CLI
    try:
        subprocess.run(
            ["sam", "--version"], 
            check=True, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE
        )
        result.sam_cli = True
    except (subprocess.CalledProcessError, FileNotFoundError):
        if interactive:
            raise ToolNotFoundError(
                "AWS SAM CLI", 
                "https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/serverless-sam-cli-install.html"
            )
    
    # Check Micronaut CLI
    try:
        subprocess.run(
            ["mn", "--version"], 
            check=True, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE
        )
        result.micronaut_cli = True
    except (subprocess.CalledProcessError, FileNotFoundError):
        if interactive:
            raise ToolNotFoundError("Micronaut CLI", "https://micronaut.io/launch/")
    
    return result


def ask_user_input() -> Tuple[str, str]:
    """
    Prompt user for application name and destination directory.
    
    Returns:
        Tuple of (sanitized_app_name, absolute_dest_dir)
    """
    print("\n=== Micronaut + SAM App Generator CLI ===\n")
    
    app_name_raw = input("Enter your application name (default: hello-world): ").strip()
    if not app_name_raw:
        app_name_raw = "hello-world"
    
    app_name = sanitize_app_name(app_name_raw)
    
    dest_dir_input = input("Paste destination directory for the project (default: current directory): ").strip()
    dest_dir = os.path.abspath(os.path.expanduser(dest_dir_input)) if dest_dir_input else os.getcwd()
    
    return app_name, dest_dir


def init_git_repo(project_dir: str) -> None:
    """
    Initialize git repository in project directory.
    
    Args:
        project_dir: Absolute path to project directory
        
    Raises:
        ProjectError: If git initialization fails
    """
    print("\nInitializing git repository...")
    
    try:
        # Prefer creating main directly if supported
        subprocess.run(
            ["git", "init", "-b", "main"], 
            cwd=project_dir, 
            check=True, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
            text=True
        )
    except subprocess.CalledProcessError:
        # Fallback for older git versions
        try:
            subprocess.run(["git", "init"], cwd=project_dir, check=True)
            subprocess.run(["git", "checkout", "-b", "main"], cwd=project_dir, check=True)
        except subprocess.CalledProcessError as e:
            raise ProjectError(f"Failed to initialize git repository: {e}")
    
    try:
        subprocess.run(["git", "add", "."], cwd=project_dir, check=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], cwd=project_dir, check=True)
        print("Git repository initialized with initial commit on 'main'.")
    except subprocess.CalledProcessError as e:
        raise ProjectError(f"Failed to create initial git commit: {e}")


def ensure_directory(path: str) -> None:
    """
    Ensure directory exists, creating it if necessary.
    
    Args:
        path: Directory path to create
        
    Raises:
        ProjectError: If directory creation fails
    """
    try:
        os.makedirs(path, exist_ok=True)
    except OSError as e:
        raise ProjectError(f"Failed to create directory {path}: {e}")


def run_command(
    cmd: list, 
    cwd: Optional[str] = None, 
    capture_output: bool = False,
    check: bool = True
) -> subprocess.CompletedProcess:
    """
    Run a command with consistent error handling.
    
    Args:
        cmd: Command and arguments as list
        cwd: Working directory for command
        capture_output: Whether to capture stdout/stderr
        check: Whether to raise on non-zero exit code
        
    Returns:
        CompletedProcess result
        
    Raises:
        subprocess.CalledProcessError: If command fails and check=True
    """
    kwargs = {
        'cwd': cwd,
        'check': check
    }
    
    if capture_output:
        kwargs.update({
            'capture_output': True,
            'text': True
        })
    
    return subprocess.run(cmd, **kwargs)
