#!/usr/bin/env python3
"""
GenoAI - Project Generator

This is the command-line interface for the GenoAI tool.
"""

import sys
from cli.main import main

if __name__ == "__main__":
    sys.exit(main())
