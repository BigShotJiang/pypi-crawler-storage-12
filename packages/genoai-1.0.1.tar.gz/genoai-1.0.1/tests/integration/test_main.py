"""
Integration tests for the main CLI orchestrator.
"""

import os
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock
import pytest

from cli.main import MicronautSAMCLI
from cli.exceptions import CLIError, ConfigError


class TestMicronautSAMCLI:
    """Test MicronautSAMCLI main orchestrator."""
    
    def test_init(self):
        """Test CLI initialization."""
        cli = MicronautSAMCLI()
        
        assert cli.config_manager is not None
        assert cli.project_generator is not None
        assert cli.build_manager is not None
        assert cli.deployment_manager is not None
    
    def test_parse_arguments_basic(self):
        """Test basic argument parsing."""
        cli = MicronautSAMCLI()
        args = cli._parse_arguments(["--env", "dev"])
        
        assert args.env == "dev"
        assert args.api_config is None
        assert args.requires_key is False
        assert args.non_interactive is False
    
    def test_parse_arguments_full(self):
        """Test full argument parsing."""
        cli = MicronautSAMCLI()
        args = cli._parse_arguments([
            "--env", "prod",
            "--api-config", "config/api.yaml",
            "--requires-key",
            "--non-interactive",
            "--project-name", "test-app",
            "--dest-dir", "/tmp"
        ])
        
        assert args.env == "prod"
        assert args.api_config == "config/api.yaml"
        assert args.requires_key is True
        assert args.non_interactive is True
        assert args.project_name == "test-app"
        assert args.dest_dir == "/tmp"
    
    def test_parse_arguments_delete_operations(self):
        """Test argument parsing for delete operations."""
        cli = MicronautSAMCLI()
        
        # Test delete-all
        args = cli._parse_arguments(["--env", "dev", "--delete-all", "/path/to/project"])
        assert args.delete_all == "/path/to/project"
        
        # Test delete-stack
        args = cli._parse_arguments(["--env", "dev", "--delete-stack", "my-app"])
        assert args.delete_stack == "my-app"
    
    def test_parse_arguments_missing_env(self):
        """Test argument parsing with missing required env."""
        cli = MicronautSAMCLI()
        
        with pytest.raises(SystemExit):
            cli._parse_arguments([])
    
    def test_parse_arguments_invalid_env(self):
        """Test argument parsing with invalid env."""
        cli = MicronautSAMCLI()
        
        with pytest.raises(SystemExit):
            cli._parse_arguments(["--env", "invalid"])
    
    @patch('cli.main.MicronautSAMCLI._execute_workflow')
    @patch('cli.main.MicronautSAMCLI._get_project_details')
    @patch('cli.config.ConfigManager.load_environment_config')
    @patch('cli.utils.check_cli_tools')
    def test_run_success_interactive(self, mock_check_tools, mock_load_config, 
                                   mock_get_details, mock_execute, sample_env_config):
        """Test successful CLI run in interactive mode."""
        # Setup mocks
        mock_load_config.return_value = sample_env_config
        mock_get_details.return_value = ("test-app", "/tmp")
        mock_execute.return_value = 0
        
        cli = MicronautSAMCLI()
        exit_code = cli.run(["--env", "dev"])
        
        assert exit_code == 0
        mock_check_tools.assert_called_once_with(interactive=True)
        mock_load_config.assert_called_once_with("dev")
        mock_get_details.assert_called_once()
        mock_execute.assert_called_once()
    
    @patch('cli.main.MicronautSAMCLI._execute_workflow')
    @patch('cli.main.MicronautSAMCLI._get_project_details')
    @patch('cli.config.ConfigManager.load_environment_config')
    def test_run_success_non_interactive(self, mock_load_config, mock_get_details, 
                                       mock_execute, sample_env_config):
        """Test successful CLI run in non-interactive mode."""
        # Setup mocks
        mock_load_config.return_value = sample_env_config
        mock_get_details.return_value = ("test-app", "/tmp")
        mock_execute.return_value = 0
        
        cli = MicronautSAMCLI()
        exit_code = cli.run([
            "--env", "dev", 
            "--non-interactive", 
            "--project-name", "test-app"
        ])
        
        assert exit_code == 0
        # Should not check CLI tools in non-interactive mode
        mock_load_config.assert_called_once_with("dev")
    
    @patch('cli.config.ConfigManager.load_environment_config')
    def test_run_config_error(self, mock_load_config):
        """Test CLI run with configuration error."""
        mock_load_config.side_effect = ConfigError("Config not found")
        
        cli = MicronautSAMCLI()
        exit_code = cli.run(["--env", "dev"])
        
        assert exit_code == 1
    
    def test_run_keyboard_interrupt(self):
        """Test CLI run with keyboard interrupt."""
        cli = MicronautSAMCLI()
        
        with patch('cli.config.ConfigManager.load_environment_config') as mock_load:
            mock_load.side_effect = KeyboardInterrupt()
            
            exit_code = cli.run(["--env", "dev"])
            assert exit_code == 130
    
    def test_run_unexpected_error(self):
        """Test CLI run with unexpected error."""
        cli = MicronautSAMCLI()
        
        with patch('cli.config.ConfigManager.load_environment_config') as mock_load:
            mock_load.side_effect = RuntimeError("Unexpected error")
            
            exit_code = cli.run(["--env", "dev"])
            assert exit_code == 1
    
    @patch('cli.main.MicronautSAMCLI._delete_all')
    @patch('cli.config.ConfigManager.load_environment_config')
    def test_handle_deletion_delete_all(self, mock_load_config, mock_delete_all, sample_env_config):
        """Test handling delete-all operation."""
        mock_load_config.return_value = sample_env_config
        mock_delete_all.return_value = 0
        
        cli = MicronautSAMCLI()
        args = cli._parse_arguments(["--env", "dev", "--delete-all", "/path/to/project"])
        
        exit_code = cli._handle_deletion(args)
        
        assert exit_code == 0
        mock_delete_all.assert_called_once_with(
            "/path/to/project", "dev", sample_env_config, True
        )
    
    @patch('cli.main.MicronautSAMCLI._delete_stack')
    @patch('cli.config.ConfigManager.load_environment_config')
    def test_handle_deletion_delete_stack(self, mock_load_config, mock_delete_stack, sample_env_config):
        """Test handling delete-stack operation."""
        mock_load_config.return_value = sample_env_config
        mock_delete_stack.return_value = 0
        
        cli = MicronautSAMCLI()
        args = cli._parse_arguments(["--env", "dev", "--delete-stack", "my-app"])
        
        exit_code = cli._handle_deletion(args)
        
        assert exit_code == 0
        mock_delete_stack.assert_called_once_with(
            "my-app", "dev", sample_env_config, True
        )
    
    @patch('shutil.rmtree')
    @patch('os.path.isdir')
    @patch('cli.deploy.DeploymentManager.delete_stack')
    def test_delete_all_success(self, mock_delete_stack, mock_isdir, mock_rmtree, sample_env_config):
        """Test successful delete-all operation."""
        mock_isdir.return_value = True
        
        cli = MicronautSAMCLI()
        exit_code = cli._delete_all("/path/to/project", "dev", sample_env_config, True)
        
        assert exit_code == 0
        mock_delete_stack.assert_called_once()
        mock_rmtree.assert_called_once_with("/path/to/project")
    
    @patch('os.path.isdir')
    def test_delete_all_project_not_found(self, mock_isdir, sample_env_config):
        """Test delete-all with project directory not found."""
        mock_isdir.return_value = False
        
        cli = MicronautSAMCLI()
        exit_code = cli._delete_all("/nonexistent", "dev", sample_env_config, True)
        
        assert exit_code == 1
    
    @patch('cli.deploy.DeploymentManager.delete_stack')
    def test_delete_stack_success(self, mock_delete_stack, sample_env_config):
        """Test successful delete-stack operation."""
        cli = MicronautSAMCLI()
        exit_code = cli._delete_stack("my-app", "dev", sample_env_config, True)
        
        assert exit_code == 0
        mock_delete_stack.assert_called_once_with(
            "my-app-dev-stack", "us-east-1", "default", True
        )
    
    def test_get_project_details_interactive(self):
        """Test getting project details in interactive mode."""
        cli = MicronautSAMCLI()
        
        with patch('cli.utils.ask_user_input') as mock_ask:
            mock_ask.return_value = ("test-app", "/tmp")
            
            args = MagicMock()
            args.non_interactive = False
            
            app_name, dest_dir = cli._get_project_details(args)
            
            assert app_name == "test-app"
            assert dest_dir == "/tmp"
            mock_ask.assert_called_once()
    
    def test_get_project_details_non_interactive(self):
        """Test getting project details in non-interactive mode."""
        cli = MicronautSAMCLI()
        
        args = MagicMock()
        args.non_interactive = True
        args.project_name = "my-app"
        args.dest_dir = "/custom/path"
        
        app_name, dest_dir = cli._get_project_details(args)
        
        assert app_name == "my_app"  # Sanitized
        assert dest_dir == "/custom/path"
    
    def test_get_project_details_non_interactive_missing_name(self):
        """Test getting project details in non-interactive mode without project name."""
        cli = MicronautSAMCLI()
        
        args = MagicMock()
        args.non_interactive = True
        args.project_name = None
        
        with pytest.raises(CLIError, match="--project-name is required"):
            cli._get_project_details(args)
    
    def test_get_project_details_non_interactive_default_dest(self):
        """Test getting project details in non-interactive mode with default destination."""
        cli = MicronautSAMCLI()
        
        args = MagicMock()
        args.non_interactive = True
        args.project_name = "test-app"
        args.dest_dir = None
        
        app_name, dest_dir = cli._get_project_details(args)
        
        assert app_name == "test_app"
        assert dest_dir == os.getcwd()
    
    @patch('cli.deploy.DeploymentManager.get_api_details')
    @patch('cli.deploy.DeploymentManager.deploy_to_aws')
    @patch('cli.build.BuildManager.build_jar')
    @patch('cli.utils.init_git_repo')
    @patch('cli.build.BuildManager.create_sam_template')
    @patch('cli.project.ProjectGenerator.remove_default_generated_files')
    @patch('cli.project.ProjectGenerator.create_default_controller')
    @patch('cli.build.BuildManager.ensure_gradle_wrapper')
    @patch('cli.project.ProjectGenerator.patch_gradle_build')
    @patch('cli.project.ProjectGenerator.generate_micronaut_project')
    @patch('os.chdir')
    def test_execute_workflow_success_without_api_config(self, mock_chdir, mock_generate_project,
                                                       mock_patch_gradle, mock_ensure_wrapper,
                                                       mock_create_controller, mock_remove_files,
                                                       mock_create_template, mock_init_git,
                                                       mock_build_jar, mock_deploy, mock_get_details,
                                                       sample_env_config):
        """Test successful workflow execution without API config."""
        # Setup mocks
        mock_build_jar.return_value = MagicMock(success=True)
        mock_deploy.return_value = MagicMock(success=True)
        mock_get_details.return_value = MagicMock()
        
        cli = MicronautSAMCLI()
        
        args = MagicMock()
        args.requires_key = False
        args.non_interactive = False
        
        exit_code = cli._execute_workflow(
            args, sample_env_config, "test-app", "/tmp", "test-app-dev-stack", None
        )
        
        assert exit_code == 0
        
        # Verify workflow steps were called
        mock_generate_project.assert_called_once()
        mock_patch_gradle.assert_called_once()
        mock_ensure_wrapper.assert_called_once()
        mock_create_controller.assert_called_once()
        mock_remove_files.assert_called_once()
        mock_create_template.assert_called_once()
        mock_init_git.assert_called_once()
        mock_build_jar.assert_called_once()
        mock_deploy.assert_called_once()
        mock_get_details.assert_called_once()
    
    @patch('cli.deploy.DeploymentManager.get_api_details')
    @patch('cli.deploy.DeploymentManager.deploy_to_aws')
    @patch('cli.build.BuildManager.build_jar')
    @patch('cli.utils.init_git_repo')
    @patch('cli.build.BuildManager.create_sam_template')
    @patch('cli.project.ProjectGenerator.remove_default_generated_files')
    @patch('cli.project.ProjectGenerator.generate_controllers_from_config')
    @patch('cli.build.BuildManager.ensure_gradle_wrapper')
    @patch('cli.project.ProjectGenerator.patch_gradle_build')
    @patch('cli.project.ProjectGenerator.generate_micronaut_project')
    @patch('os.chdir')
    def test_execute_workflow_success_with_api_config(self, mock_chdir, mock_generate_project,
                                                    mock_patch_gradle, mock_ensure_wrapper,
                                                    mock_generate_controllers, mock_remove_files,
                                                    mock_create_template, mock_init_git,
                                                    mock_build_jar, mock_deploy, mock_get_details,
                                                    sample_env_config, sample_api_config):
        """Test successful workflow execution with API config."""
        # Setup mocks
        mock_build_jar.return_value = MagicMock(success=True)
        mock_deploy.return_value = MagicMock(success=True)
        mock_get_details.return_value = MagicMock()
        
        from cli.config import ApiConfig
        api_config = ApiConfig.from_dict(sample_api_config)
        
        cli = MicronautSAMCLI()
        
        args = MagicMock()
        args.requires_key = True
        args.non_interactive = False
        
        exit_code = cli._execute_workflow(
            args, sample_env_config, "test-app", "/tmp", "test-app-dev-stack", api_config
        )
        
        assert exit_code == 0
        
        # Verify API config workflow was used
        mock_generate_controllers.assert_called_once_with(api_config, "/tmp/test-app")
        
        # Verify template was created with proxy_all=True
        template_call = mock_create_template.call_args[0][0]
        assert template_call.proxy_all is True
    
    @patch('cli.build.BuildManager.build_jar')
    @patch('cli.utils.init_git_repo')
    @patch('cli.build.BuildManager.create_sam_template')
    @patch('cli.project.ProjectGenerator.remove_default_generated_files')
    @patch('cli.project.ProjectGenerator.create_default_controller')
    @patch('cli.build.BuildManager.ensure_gradle_wrapper')
    @patch('cli.project.ProjectGenerator.patch_gradle_build')
    @patch('cli.project.ProjectGenerator.generate_micronaut_project')
    @patch('os.chdir')
    def test_execute_workflow_build_failure(self, mock_chdir, mock_generate_project,
                                          mock_patch_gradle, mock_ensure_wrapper,
                                          mock_create_controller, mock_remove_files,
                                          mock_create_template, mock_init_git,
                                          mock_build_jar, sample_env_config):
        """Test workflow execution with build failure."""
        # Setup build failure
        mock_build_jar.return_value = MagicMock(success=False, error_message="Build failed")
        
        cli = MicronautSAMCLI()
        
        args = MagicMock()
        args.requires_key = False
        args.non_interactive = False
        
        exit_code = cli._execute_workflow(
            args, sample_env_config, "test-app", "/tmp", "test-app-dev-stack", None
        )
        
        assert exit_code == 1
    
    @patch('cli.deploy.DeploymentManager.deploy_to_aws')
    @patch('cli.build.BuildManager.build_jar')
    @patch('cli.utils.init_git_repo')
    @patch('cli.build.BuildManager.create_sam_template')
    @patch('cli.project.ProjectGenerator.remove_default_generated_files')
    @patch('cli.project.ProjectGenerator.create_default_controller')
    @patch('cli.build.BuildManager.ensure_gradle_wrapper')
    @patch('cli.project.ProjectGenerator.patch_gradle_build')
    @patch('cli.project.ProjectGenerator.generate_micronaut_project')
    @patch('os.chdir')
    def test_execute_workflow_deploy_failure(self, mock_chdir, mock_generate_project,
                                           mock_patch_gradle, mock_ensure_wrapper,
                                           mock_create_controller, mock_remove_files,
                                           mock_create_template, mock_init_git,
                                           mock_build_jar, mock_deploy, sample_env_config):
        """Test workflow execution with deployment failure."""
        # Setup successful build but failed deployment
        mock_build_jar.return_value = MagicMock(success=True)
        mock_deploy.return_value = MagicMock(success=False, error_message="Deploy failed")
        
        cli = MicronautSAMCLI()
        
        args = MagicMock()
        args.requires_key = False
        args.non_interactive = False
        
        exit_code = cli._execute_workflow(
            args, sample_env_config, "test-app", "/tmp", "test-app-dev-stack", None
        )
        
        assert exit_code == 1


def test_main_function():
    """Test main function entry point."""
    from cli.main import main
    
    with patch('cli.main.MicronautSAMCLI.run') as mock_run:
        mock_run.return_value = 0
        
        exit_code = main()
        
        assert exit_code == 0
        mock_run.assert_called_once()
