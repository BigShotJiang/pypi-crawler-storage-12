"""Integration tests for CLI workflows."""
