"""
Test package for Micronaut SAM CLI.

Contains unit tests, integration tests, and test fixtures.
"""
