"""
Unit tests for the configuration module.
"""

import os
import yaml
from pathlib import Path
import pytest

from cli.config import ConfigManager, EnvironmentConfig, ApiConfig, ServiceConfig, RouteConfig
from cli.exceptions import ConfigError


class TestEnvironmentConfig:
    """Test EnvironmentConfig data class."""
    
    def test_from_dict_valid(self, sample_env_config):
        """Test creating EnvironmentConfig from valid dictionary."""
        config = EnvironmentConfig.from_dict(sample_env_config)
        
        assert config.aws_region == "us-east-1"
        assert config.aws_profile == "default"
    
    def test_from_dict_missing_key(self):
        """Test creating EnvironmentConfig with missing required key."""
        data = {"aws_region": "us-east-1"}  # Missing aws_profile
        
        with pytest.raises(ConfigError, match="Missing required configuration key"):
            EnvironmentConfig.from_dict(data)


class TestApiConfig:
    """Test ApiConfig data class."""
    
    def test_from_dict_valid(self, sample_api_config):
        """Test creating ApiConfig from valid dictionary."""
        config = ApiConfig.from_dict(sample_api_config)
        
        assert config.service.name == "test-service"
        assert config.service.package == "com.example.testservice"
        assert len(config.routes) == 2
        
        # Check first route
        route1 = config.routes[0]
        assert route1.path == "/hello"
        assert route1.method == "get"
        assert route1.controller == "HelloController"
        assert route1.method_name == "index"
        
        # Check second route
        route2 = config.routes[1]
        assert route2.path == "/users/{id}"
        assert route2.method == "get"
        assert route2.controller == "UserController"
        assert route2.method_name == "getUser"
    
    def test_from_dict_missing_service(self):
        """Test creating ApiConfig with missing service block."""
        data = {"routes": []}
        
        with pytest.raises(ConfigError, match="Missing required API config key"):
            ApiConfig.from_dict(data)
    
    def test_from_dict_missing_routes(self):
        """Test creating ApiConfig with missing routes block."""
        data = {
            "service": {
                "name": "test-service",
                "package": "com.example.testservice"
            }
        }
        
        with pytest.raises(ConfigError, match="Missing required API config key"):
            ApiConfig.from_dict(data)


class TestConfigManager:
    """Test ConfigManager class."""
    
    def test_init_default_config_dir(self):
        """Test ConfigManager initialization with default config directory."""
        manager = ConfigManager()
        assert manager.config_dir == "config"
    
    def test_init_custom_config_dir(self):
        """Test ConfigManager initialization with custom config directory."""
        manager = ConfigManager("/custom/config")
        assert manager.config_dir == "/custom/config"
    
    def test_load_environment_config_success(self, temp_dir, sample_env_config):
        """Test successful environment config loading."""
        # Create config directory and file
        config_dir = temp_dir / "config"
        config_dir.mkdir()
        
        config_file = config_dir / "dev.yaml"
        with open(config_file, "w") as f:
            yaml.dump(sample_env_config, f)
        
        # Test loading
        manager = ConfigManager(str(config_dir))
        config = manager.load_environment_config("dev")
        
        assert isinstance(config, EnvironmentConfig)
        assert config.aws_region == "us-east-1"
        assert config.aws_profile == "default"
    
    def test_load_environment_config_file_not_found(self, temp_dir):
        """Test environment config loading with missing file."""
        config_dir = temp_dir / "config"
        config_dir.mkdir()
        
        manager = ConfigManager(str(config_dir))
        
        with pytest.raises(ConfigError, match="Configuration file not found"):
            manager.load_environment_config("nonexistent")
    
    def test_load_environment_config_invalid_yaml(self, temp_dir):
        """Test environment config loading with invalid YAML."""
        config_dir = temp_dir / "config"
        config_dir.mkdir()
        
        config_file = config_dir / "dev.yaml"
        config_file.write_text("invalid: yaml: content: [")
        
        manager = ConfigManager(str(config_dir))
        
        with pytest.raises(ConfigError, match="Error parsing YAML file"):
            manager.load_environment_config("dev")
    
    def test_load_environment_config_empty_file(self, temp_dir):
        """Test environment config loading with empty file."""
        config_dir = temp_dir / "config"
        config_dir.mkdir()
        
        config_file = config_dir / "dev.yaml"
        config_file.write_text("")
        
        manager = ConfigManager(str(config_dir))
        
        with pytest.raises(ConfigError, match="Empty configuration file"):
            manager.load_environment_config("dev")
    
    def test_parse_api_config_success(self, temp_dir, sample_api_config):
        """Test successful API config parsing."""
        config_file = temp_dir / "api.yaml"
        with open(config_file, "w") as f:
            yaml.dump(sample_api_config, f)
        
        manager = ConfigManager()
        config = manager.parse_api_config(str(config_file))
        
        assert isinstance(config, ApiConfig)
        assert config.service.name == "test-service"
        assert len(config.routes) == 2
    
    def test_parse_api_config_empty_path(self):
        """Test API config parsing with empty path."""
        manager = ConfigManager()
        
        with pytest.raises(ConfigError, match="Config path is empty"):
            manager.parse_api_config("")
    
    def test_parse_api_config_file_not_found(self):
        """Test API config parsing with missing file."""
        manager = ConfigManager()
        
        with pytest.raises(ConfigError, match="Config file not found"):
            manager.parse_api_config("/nonexistent/path.yaml")
    
    def test_parse_api_config_invalid_yaml(self, temp_dir):
        """Test API config parsing with invalid YAML."""
        config_file = temp_dir / "api.yaml"
        config_file.write_text("invalid: yaml: [")
        
        manager = ConfigManager()
        
        with pytest.raises(ConfigError, match="YAML parse error"):
            manager.parse_api_config(str(config_file))
    
    def test_validate_api_config_invalid_root(self, temp_dir):
        """Test API config validation with invalid root type."""
        config_file = temp_dir / "api.yaml"
        config_file.write_text("- not a mapping")
        
        manager = ConfigManager()
        
        with pytest.raises(ConfigError, match="Config root must be a mapping"):
            manager.parse_api_config(str(config_file))
    
    def test_validate_api_config_missing_service(self, temp_dir):
        """Test API config validation with missing service block."""
        config_data = {"routes": []}
        
        config_file = temp_dir / "api.yaml"
        with open(config_file, "w") as f:
            yaml.dump(config_data, f)
        
        manager = ConfigManager()
        
        with pytest.raises(ConfigError, match="Missing required 'service' block"):
            manager.parse_api_config(str(config_file))
    
    def test_validate_api_config_invalid_service_name(self, temp_dir):
        """Test API config validation with invalid service name."""
        config_data = {
            "service": {"name": "", "package": "com.example.test"},
            "routes": [{"path": "/test", "method": "get", "controller": "Test", "methodName": "test"}]
        }
        
        config_file = temp_dir / "api.yaml"
        with open(config_file, "w") as f:
            yaml.dump(config_data, f)
        
        manager = ConfigManager()
        
        with pytest.raises(ConfigError, match="service.name must be a non-empty string"):
            manager.parse_api_config(str(config_file))
    
    def test_validate_api_config_empty_routes(self, temp_dir):
        """Test API config validation with empty routes."""
        config_data = {
            "service": {"name": "test", "package": "com.example.test"},
            "routes": []
        }
        
        config_file = temp_dir / "api.yaml"
        with open(config_file, "w") as f:
            yaml.dump(config_data, f)
        
        manager = ConfigManager()
        
        with pytest.raises(ConfigError, match="routes must be a non-empty list"):
            manager.parse_api_config(str(config_file))
    
    def test_validate_api_config_invalid_route_method(self, temp_dir):
        """Test API config validation with invalid HTTP method."""
        config_data = {
            "service": {"name": "test", "package": "com.example.test"},
            "routes": [{
                "path": "/test",
                "method": "invalid",
                "controller": "Test",
                "methodName": "test"
            }]
        }
        
        config_file = temp_dir / "api.yaml"
        with open(config_file, "w") as f:
            yaml.dump(config_data, f)
        
        manager = ConfigManager()
        
        with pytest.raises(ConfigError, match="is not a supported HTTP method"):
            manager.parse_api_config(str(config_file))
    
    def test_validate_api_config_missing_route_field(self, temp_dir):
        """Test API config validation with missing route field."""
        config_data = {
            "service": {"name": "test", "package": "com.example.test"},
            "routes": [{
                "path": "/test",
                "method": "get",
                "controller": "Test"
                # Missing methodName
            }]
        }
        
        config_file = temp_dir / "api.yaml"
        with open(config_file, "w") as f:
            yaml.dump(config_data, f)
        
        manager = ConfigManager()
        
        with pytest.raises(ConfigError, match="routes\\[0\\].methodName must be a non-empty string"):
            manager.parse_api_config(str(config_file))
