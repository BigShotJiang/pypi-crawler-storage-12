"""
Unit tests for the deployment operations module.
"""

import json
from unittest.mock import patch, MagicMock
import pytest

from cli.deploy import DeploymentManager, DeploySpec, ApiDetails, DeployResult
from cli.exceptions import DeployError


class TestDeploySpec:
    """Test DeploySpec data class."""
    
    def test_basic_properties(self):
        """Test basic DeploySpec properties."""
        spec = DeploySpec(
            stack_name="test-stack",
            region="us-east-1",
            aws_profile="custom-profile",
            use_profile=False
        )
        
        assert spec.stack_name == "test-stack"
        assert spec.region == "us-east-1"
        assert spec.aws_profile == "custom-profile"
        assert spec.use_profile is False
    
    def test_default_values(self):
        """Test DeploySpec default values."""
        spec = DeploySpec(stack_name="test-stack", region="us-east-1")
        
        assert spec.aws_profile is None
        assert spec.use_profile is True


class TestApiDetails:
    """Test ApiDetails data class."""
    
    def test_basic_properties(self):
        """Test basic ApiDetails properties."""
        details = ApiDetails(
            api_url="https://api.example.com",
            stack_name="test-stack",
            region="us-east-1",
            api_key="secret-key"
        )
        
        assert details.api_url == "https://api.example.com"
        assert details.stack_name == "test-stack"
        assert details.region == "us-east-1"
        assert details.api_key == "secret-key"
    
    def test_without_api_key(self):
        """Test ApiDetails without API key."""
        details = ApiDetails(
            api_url="https://api.example.com",
            stack_name="test-stack",
            region="us-east-1"
        )
        
        assert details.api_key is None


class TestDeployResult:
    """Test DeployResult data class."""
    
    def test_successful_result(self):
        """Test successful DeployResult."""
        api_details = ApiDetails(
            api_url="https://api.example.com",
            stack_name="test-stack",
            region="us-east-1"
        )
        
        result = DeployResult(
            success=True,
            stack_name="test-stack",
            api_details=api_details
        )
        
        assert result.success is True
        assert result.stack_name == "test-stack"
        assert result.api_details == api_details
        assert result.error_message is None
    
    def test_failed_result(self):
        """Test failed DeployResult."""
        result = DeployResult(
            success=False,
            error_message="Deployment failed"
        )
        
        assert result.success is False
        assert result.stack_name is None
        assert result.api_details is None
        assert result.error_message == "Deployment failed"


class TestDeploymentManager:
    """Test DeploymentManager class."""
    
    def test_init(self):
        """Test DeploymentManager initialization."""
        manager = DeploymentManager()
        assert manager is not None
    
    @patch('cli.deploy.run_command')
    def test_deploy_to_aws_success(self, mock_run_command, temp_dir):
        """Test successful AWS deployment."""
        spec = DeploySpec(
            stack_name="test-stack",
            region="us-east-1",
            aws_profile="default",
            use_profile=True
        )
        
        manager = DeploymentManager()
        result = manager.deploy_to_aws(spec, str(temp_dir))
        
        assert result.success is True
        assert result.stack_name == "test-stack"
        assert result.error_message is None
        
        # Check command was called correctly
        mock_run_command.assert_called_once()
        call_args = mock_run_command.call_args[0][0]
        assert "sam" in call_args
        assert "deploy" in call_args
        assert "--stack-name" in call_args
        assert "test-stack" in call_args
        assert "--profile" in call_args
        assert "default" in call_args
    
    @patch('cli.deploy.run_command')
    def test_deploy_to_aws_without_profile(self, mock_run_command, temp_dir):
        """Test AWS deployment without profile."""
        spec = DeploySpec(
            stack_name="test-stack",
            region="us-east-1",
            use_profile=False
        )
        
        manager = DeploymentManager()
        result = manager.deploy_to_aws(spec, str(temp_dir))
        
        assert result.success is True
        
        # Check that profile was not included in command
        call_args = mock_run_command.call_args[0][0]
        assert "--profile" not in call_args
    
    @patch('cli.deploy.run_command')
    def test_deploy_to_aws_failure(self, mock_run_command, temp_dir):
        """Test AWS deployment failure."""
        spec = DeploySpec(stack_name="test-stack", region="us-east-1")
        
        mock_run_command.side_effect = Exception("Deployment failed")
        
        manager = DeploymentManager()
        result = manager.deploy_to_aws(spec, str(temp_dir))
        
        assert result.success is False
        assert "SAM deployment failed" in result.error_message
    
    @patch('cli.deploy.run_command')
    def test_get_api_details_success_with_key(self, mock_run_command):
        """Test successful API details retrieval with API key."""
        # Mock CloudFormation stack outputs
        stack_outputs = [
            {"OutputKey": "ApiUrl", "OutputValue": "https://api.example.com"},
            {"OutputKey": "ApiKey", "OutputValue": "key-id-123"}
        ]
        
        # Mock API key value retrieval
        api_key_response = {"value": "secret-api-key"}
        
        mock_run_command.side_effect = [
            MagicMock(stdout=json.dumps(stack_outputs)),
            MagicMock(stdout=json.dumps(api_key_response))
        ]
        
        manager = DeploymentManager()
        details = manager.get_api_details(
            stack_name="test-stack",
            region="us-east-1",
            aws_profile="default",
            requires_key=True,
            use_profile=True
        )
        
        assert details.api_url == "https://api.example.com"
        assert details.api_key == "secret-api-key"
        assert details.stack_name == "test-stack"
        assert details.region == "us-east-1"
        
        # Should have made two calls: describe-stacks and get-api-key
        assert mock_run_command.call_count == 2
    
    @patch('cli.deploy.run_command')
    def test_get_api_details_success_without_key(self, mock_run_command):
        """Test successful API details retrieval without API key."""
        stack_outputs = [
            {"OutputKey": "ApiUrl", "OutputValue": "https://api.example.com"}
        ]
        
        mock_run_command.return_value = MagicMock(stdout=json.dumps(stack_outputs))
        
        manager = DeploymentManager()
        details = manager.get_api_details(
            stack_name="test-stack",
            region="us-east-1",
            requires_key=False
        )
        
        assert details.api_url == "https://api.example.com"
        assert details.api_key is None
        
        # Should have made only one call: describe-stacks
        assert mock_run_command.call_count == 1
    
    @patch('cli.deploy.run_command')
    def test_get_api_details_missing_api_url(self, mock_run_command):
        """Test API details retrieval with missing API URL."""
        stack_outputs = [
            {"OutputKey": "SomeOtherOutput", "OutputValue": "value"}
        ]
        
        mock_run_command.return_value = MagicMock(stdout=json.dumps(stack_outputs))
        
        manager = DeploymentManager()
        
        with pytest.raises(DeployError, match="Could not find ApiUrl in stack outputs"):
            manager.get_api_details("test-stack", "us-east-1")
    
    @patch('cli.deploy.run_command')
    def test_get_api_details_missing_api_key(self, mock_run_command):
        """Test API details retrieval with missing API key when required."""
        stack_outputs = [
            {"OutputKey": "ApiUrl", "OutputValue": "https://api.example.com"}
            # Missing ApiKey output
        ]
        
        mock_run_command.return_value = MagicMock(stdout=json.dumps(stack_outputs))
        
        manager = DeploymentManager()
        
        with pytest.raises(DeployError, match="Could not find ApiKey in stack outputs"):
            manager.get_api_details(
                stack_name="test-stack",
                region="us-east-1",
                requires_key=True
            )
    
    @patch('cli.deploy.run_command')
    def test_get_api_details_command_failure(self, mock_run_command):
        """Test API details retrieval with command failure."""
        mock_run_command.side_effect = Exception("AWS CLI failed")
        
        manager = DeploymentManager()
        
        with pytest.raises(DeployError, match="Failed to fetch API details"):
            manager.get_api_details("test-stack", "us-east-1")
    
    @patch('cli.deploy.run_command')
    def test_get_api_details_invalid_json(self, mock_run_command):
        """Test API details retrieval with invalid JSON response."""
        mock_run_command.return_value = MagicMock(stdout="invalid json")
        
        manager = DeploymentManager()
        
        with pytest.raises(DeployError, match="Error parsing AWS CLI output"):
            manager.get_api_details("test-stack", "us-east-1")
    
    @patch('cli.deploy.run_command')
    def test_delete_stack_success(self, mock_run_command):
        """Test successful stack deletion."""
        manager = DeploymentManager()
        
        # Should not raise an exception
        manager.delete_stack(
            stack_name="test-stack",
            region="us-east-1",
            aws_profile="default",
            use_profile=True
        )
        
        mock_run_command.assert_called_once()
        call_args = mock_run_command.call_args[0][0]
        assert "sam" in call_args
        assert "delete" in call_args
        assert "--stack-name" in call_args
        assert "test-stack" in call_args
        assert "--profile" in call_args
        assert "default" in call_args
    
    @patch('cli.deploy.run_command')
    def test_delete_stack_without_profile(self, mock_run_command):
        """Test stack deletion without profile."""
        manager = DeploymentManager()
        
        manager.delete_stack(
            stack_name="test-stack",
            region="us-east-1",
            use_profile=False
        )
        
        call_args = mock_run_command.call_args[0][0]
        assert "--profile" not in call_args
    
    @patch('cli.deploy.run_command')
    def test_delete_stack_failure(self, mock_run_command):
        """Test stack deletion failure."""
        mock_run_command.side_effect = Exception("Deletion failed")
        
        manager = DeploymentManager()
        
        with pytest.raises(DeployError, match="Stack deletion failed"):
            manager.delete_stack("test-stack", "us-east-1")
    
    @patch('cli.deploy.run_command')
    def test_list_stacks_success(self, mock_run_command):
        """Test successful stack listing."""
        mock_run_command.return_value = MagicMock(stdout="stack1\tstack2\tstack3")
        
        manager = DeploymentManager()
        stacks = manager.list_stacks("us-east-1")
        
        assert stacks == ["stack1", "stack2", "stack3"]
        
        call_args = mock_run_command.call_args[0][0]
        assert "aws" in call_args
        assert "cloudformation" in call_args
        assert "list-stacks" in call_args
    
    @patch('cli.deploy.run_command')
    def test_list_stacks_with_pattern(self, mock_run_command):
        """Test stack listing with name pattern filter."""
        mock_run_command.return_value = MagicMock(stdout="test-stack-1\tother-stack\ttest-stack-2")
        
        manager = DeploymentManager()
        stacks = manager.list_stacks("us-east-1", name_pattern="test-stack")
        
        assert stacks == ["test-stack-1", "test-stack-2"]
    
    @patch('cli.deploy.run_command')
    def test_list_stacks_failure(self, mock_run_command):
        """Test stack listing failure."""
        mock_run_command.side_effect = Exception("List failed")
        
        manager = DeploymentManager()
        
        with pytest.raises(DeployError, match="Failed to list stacks"):
            manager.list_stacks("us-east-1")
    
    def test_find_output_value(self):
        """Test finding output value by key."""
        manager = DeploymentManager()
        
        outputs = [
            {"OutputKey": "ApiUrl", "OutputValue": "https://api.example.com"},
            {"OutputKey": "ApiKey", "OutputValue": "key-123"},
            {"OutputKey": "Other", "OutputValue": "other-value"}
        ]
        
        assert manager._find_output_value(outputs, "ApiUrl") == "https://api.example.com"
        assert manager._find_output_value(outputs, "ApiKey") == "key-123"
        assert manager._find_output_value(outputs, "NonExistent") is None
    
    @patch('cli.deploy.run_command')
    def test_get_api_key_value_success(self, mock_run_command):
        """Test successful API key value retrieval."""
        api_key_response = {"value": "secret-key"}
        mock_run_command.return_value = MagicMock(stdout=json.dumps(api_key_response))
        
        manager = DeploymentManager()
        key_value = manager._get_api_key_value("key-id-123", "us-east-1", "default", True)
        
        assert key_value == "secret-key"
        
        call_args = mock_run_command.call_args[0][0]
        assert "aws" in call_args
        assert "apigateway" in call_args
        assert "get-api-key" in call_args
        assert "--api-key" in call_args
        assert "key-id-123" in call_args
    
    @patch('cli.deploy.run_command')
    def test_get_api_key_value_failure(self, mock_run_command):
        """Test API key value retrieval failure."""
        mock_run_command.side_effect = Exception("API Gateway error")
        
        manager = DeploymentManager()
        
        with pytest.raises(DeployError, match="Failed to retrieve API key value"):
            manager._get_api_key_value("key-id-123", "us-east-1", "default", True)
