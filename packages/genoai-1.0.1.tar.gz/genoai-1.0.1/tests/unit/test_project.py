"""
Unit tests for the project generation module.
"""

import os
import re
from pathlib import Path
from unittest.mock import patch, MagicMock, mock_open
import pytest

from cli.project import ProjectGenerator, ProjectSpec
from cli.config import ApiConfig, ServiceConfig, RouteConfig
from cli.exceptions import ProjectError


class TestProjectSpec:
    """Test ProjectSpec data class."""
    
    def test_basic_properties(self):
        """Test basic ProjectSpec properties."""
        spec = ProjectSpec(app_name="test-app", dest_dir="/tmp")
        
        assert spec.app_name == "test-app"
        assert spec.dest_dir == "/tmp"
        assert spec.package_name is None
    
    def test_project_dir_property(self):
        """Test project_dir property."""
        spec = ProjectSpec(app_name="test-app", dest_dir="/tmp")
        
        assert spec.project_dir == "/tmp/test-app"
    
    def test_java_package_name_default(self):
        """Test java_package_name property with default generation."""
        spec = ProjectSpec(app_name="my-awesome-app", dest_dir="/tmp")
        
        assert spec.java_package_name == "com.example.myawesomeapp"
    
    def test_java_package_name_custom(self):
        """Test java_package_name property with custom package."""
        spec = ProjectSpec(
            app_name="test-app", 
            dest_dir="/tmp", 
            package_name="com.custom.package"
        )
        
        assert spec.java_package_name == "com.custom.package"
    
    def test_java_package_name_special_chars(self):
        """Test java_package_name with special characters in app name."""
        spec = ProjectSpec(app_name="test-app-123!@#", dest_dir="/tmp")
        
        assert spec.java_package_name == "com.example.testapp123"


class TestProjectGenerator:
    """Test ProjectGenerator class."""
    
    def test_init(self):
        """Test ProjectGenerator initialization."""
        generator = ProjectGenerator()
        assert generator is not None
    
    @patch('cli.project.run_command')
    @patch('cli.project.ensure_directory')
    @patch('os.path.isdir')
    @patch('os.rename')
    def test_generate_micronaut_project_success(self, mock_rename, mock_isdir, mock_ensure_dir, mock_run_command):
        """Test successful Micronaut project generation."""
        spec = ProjectSpec(app_name="test-app", dest_dir="/tmp")
        generator = ProjectGenerator()
        
        # Mock directory existence check and rename
        mock_isdir.return_value = True
        
        generator.generate_micronaut_project(spec)
        
        # Should ensure parent directory exists
        mock_ensure_dir.assert_called_once_with("/tmp")
        
        # Should call mn create-app
        mock_run_command.assert_called_once()
        call_args = mock_run_command.call_args[0][0]
        assert call_args[0] == "mn"
        assert call_args[1] == "create-app"
        assert "com.example.testapp" in call_args[2]
        assert "--features" in call_args
        assert "amazon-api-gateway,aws-lambda" in call_args
    
    @patch('cli.project.run_command')
    @patch('cli.project.ensure_directory')
    def test_generate_micronaut_project_command_failure(self, mock_ensure_dir, mock_run_command):
        """Test Micronaut project generation with command failure."""
        spec = ProjectSpec(app_name="test-app", dest_dir="/tmp")
        generator = ProjectGenerator()
        
        mock_run_command.side_effect = Exception("Command failed")
        
        with pytest.raises(ProjectError, match="Error generating Micronaut project"):
            generator.generate_micronaut_project(spec)
    
    def test_patch_gradle_build_success(self, temp_dir):
        """Test successful Gradle build patching."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        # Create a mock build.gradle
        build_gradle = project_dir / "build.gradle"
        build_gradle.write_text("""
plugins {
    id("io.micronaut.application") version "4.4.2"
}

dependencies {
    implementation("io.micronaut:micronaut-core")
}

application {
    mainClass = "com.example.Application"
}
""")
        
        generator = ProjectGenerator()
        generator.patch_gradle_build(str(project_dir))
        
        # Check that the file was modified
        content = build_gradle.read_text()
        assert "io.micronaut.aws:micronaut-function-aws-api-proxy" in content
        assert "java {" in content
        assert "toolchain {" in content
        assert "JavaLanguageVersion.of(17)" in content
    
    def test_patch_gradle_build_missing_file(self, temp_dir):
        """Test Gradle build patching with missing build.gradle."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        generator = ProjectGenerator()
        
        with pytest.raises(ProjectError, match="Cannot find build.gradle to patch"):
            generator.patch_gradle_build(str(project_dir))
    
    def test_patch_gradle_build_empty_java_block(self, temp_dir):
        """Test Gradle build patching with empty java block."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        build_gradle = project_dir / "build.gradle"
        build_gradle.write_text("""
dependencies {
    implementation("io.micronaut:micronaut-core")
}

java {
    
    
}

application {
    mainClass = "com.example.Application"
}
""")
        
        generator = ProjectGenerator()
        generator.patch_gradle_build(str(project_dir))
        
        content = build_gradle.read_text()
        assert "toolchain {" in content
        assert "JavaLanguageVersion.of(17)" in content
    
    @patch('cli.project.ensure_directory')
    def test_create_default_controller(self, mock_ensure_dir, temp_dir):
        """Test creating default controller."""
        spec = ProjectSpec(app_name="test-app", dest_dir=str(temp_dir))
        generator = ProjectGenerator()
        
        # Mock the directory creation
        controller_dir = temp_dir / "test-app" / "src" / "main" / "java" / "com" / "example" / "testapp"
        controller_dir.mkdir(parents=True)
        
        generator.create_default_controller(spec)
        
        # Check that controller file was created
        controller_file = controller_dir / "AppController.java"
        assert controller_file.exists()
        
        content = controller_file.read_text()
        assert "package com.example.testapp;" in content
        assert "class AppController" in content
        assert "@Controller(\"/hello\")" in content
        assert "@Get" in content
    
    def test_generate_controllers_from_config(self, temp_dir, sample_api_config):
        """Test generating controllers from API config."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        api_config = ApiConfig.from_dict(sample_api_config)
        generator = ProjectGenerator()
        
        generator.generate_controllers_from_config(api_config, str(project_dir))
        
        # Check that controller files were created
        controller_dir = project_dir / "src" / "main" / "java" / "com" / "example" / "testservice"
        assert controller_dir.exists()
        
        hello_controller = controller_dir / "HelloController.java"
        user_controller = controller_dir / "UserController.java"
        
        assert hello_controller.exists()
        assert user_controller.exists()
        
        # Check HelloController content
        hello_content = hello_controller.read_text()
        assert "package com.example.testservice;" in hello_content
        assert "class HelloController" in hello_content
        assert "@Get(\"/hello\")" in hello_content
        assert "public String index()" in hello_content
        
        # Check UserController content
        user_content = user_controller.read_text()
        assert "package com.example.testservice;" in user_content
        assert "class UserController" in user_content
        assert "@Get(\"/users/{id}\")" in user_content
        assert "public String getUser(@PathVariable String id)" in user_content
        assert "@PathVariable" in user_content
    
    def test_extract_path_params(self):
        """Test path parameter extraction."""
        generator = ProjectGenerator()
        
        # Test various path patterns
        assert generator._extract_path_params("/hello") == []
        assert generator._extract_path_params("/users/{id}") == ["id"]
        assert generator._extract_path_params("/users/{id}/posts/{postId}") == ["id", "postId"]
        assert generator._extract_path_params("/api/v1/{version}/users/{userId}") == ["version", "userId"]
    
    def test_get_method_annotation(self):
        """Test HTTP method annotation mapping."""
        generator = ProjectGenerator()
        
        assert generator._get_method_annotation("get") == "Get"
        assert generator._get_method_annotation("post") == "Post"
        assert generator._get_method_annotation("put") == "Put"
        assert generator._get_method_annotation("delete") == "Delete"
        assert generator._get_method_annotation("patch") == "Patch"
        assert generator._get_method_annotation("options") == "Options"
        assert generator._get_method_annotation("head") == "Head"
    
    def test_generate_method_with_path_params(self):
        """Test method generation with path parameters."""
        generator = ProjectGenerator()
        
        route = RouteConfig(
            path="/users/{id}/posts/{postId}",
            method="get",
            controller="UserController",
            method_name="getUserPost"
        )
        
        method_src = generator._generate_method(route)
        
        assert "@Get(\"/users/{id}/posts/{postId}\")" in method_src
        assert "public String getUserPost(@PathVariable String id, @PathVariable String postId)" in method_src
        assert "return \"OK\";" in method_src
    
    def test_generate_method_without_path_params(self):
        """Test method generation without path parameters."""
        generator = ProjectGenerator()
        
        route = RouteConfig(
            path="/hello",
            method="post",
            controller="HelloController",
            method_name="create"
        )
        
        method_src = generator._generate_method(route)
        
        assert "@Post(\"/hello\")" in method_src
        assert "public String create()" in method_src
        assert "return \"OK\";" in method_src
    
    def test_remove_default_generated_files(self, temp_dir):
        """Test removing default generated files."""
        project_dir = temp_dir / "test-project"
        default_package_dir = project_dir / "src" / "main" / "java" / "com" / "example"
        default_package_dir.mkdir(parents=True)
        
        # Create default files
        application_file = default_package_dir / "Application.java"
        home_controller_file = default_package_dir / "HomeController.java"
        custom_file = default_package_dir / "CustomController.java"
        
        application_file.write_text("// Application.java")
        home_controller_file.write_text("// HomeController.java")
        custom_file.write_text("// CustomController.java")
        
        generator = ProjectGenerator()
        generator.remove_default_generated_files(str(project_dir))
        
        # Default files should be removed
        assert not application_file.exists()
        assert not home_controller_file.exists()
        
        # Custom files should remain
        assert custom_file.exists()
    
    @patch('os.remove')
    def test_remove_default_generated_files_permission_error(self, mock_remove, temp_dir):
        """Test removing default files with permission error."""
        project_dir = temp_dir / "test-project"
        default_package_dir = project_dir / "src" / "main" / "java" / "com" / "example"
        default_package_dir.mkdir(parents=True)
        
        application_file = default_package_dir / "Application.java"
        application_file.write_text("// Application.java")
        
        # Mock permission error
        mock_remove.side_effect = OSError("Permission denied")
        
        generator = ProjectGenerator()
        
        # Should not raise an exception, just print a warning
        generator.remove_default_generated_files(str(project_dir))
