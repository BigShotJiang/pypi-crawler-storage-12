"""
Unit tests for the utilities module.
"""

import os
import subprocess
from pathlib import Path
from unittest.mock import patch, MagicMock
import pytest

from cli.utils import (
    sanitize_app_name,
    check_cli_tools,
    ask_user_input,
    init_git_repo,
    ensure_directory,
    run_command,
    ToolCheckResult
)
from cli.exceptions import ToolNotFoundError, ProjectError


class TestSanitizeAppName:
    """Test sanitize_app_name function."""
    
    def test_basic_sanitization(self):
        """Test basic app name sanitization."""
        assert sanitize_app_name("my-app") == "my_app"
        assert sanitize_app_name("My App") == "my_app"
        assert sanitize_app_name("my.app") == "my_app"
        assert sanitize_app_name("my@app#123") == "my_app_123"
    
    def test_already_clean_name(self):
        """Test app name that's already clean."""
        assert sanitize_app_name("my_app") == "my_app"
        assert sanitize_app_name("myapp123") == "myapp123"
    
    def test_empty_name(self):
        """Test empty app name."""
        assert sanitize_app_name("") == ""
    
    def test_special_characters(self):
        """Test various special characters."""
        assert sanitize_app_name("hello-world!@#$%^&*()") == "hello_world__________"
        assert sanitize_app_name("test/path\\name") == "test_path_name"


class TestToolCheckResult:
    """Test ToolCheckResult data class."""
    
    def test_all_available_true(self):
        """Test all_available property when all tools are available."""
        result = ToolCheckResult(aws_cli=True, sam_cli=True, micronaut_cli=True)
        assert result.all_available is True
    
    def test_all_available_false(self):
        """Test all_available property when some tools are missing."""
        result = ToolCheckResult(aws_cli=True, sam_cli=False, micronaut_cli=True)
        assert result.all_available is False
        
        result = ToolCheckResult(aws_cli=False, sam_cli=False, micronaut_cli=False)
        assert result.all_available is False


class TestCheckCliTools:
    """Test check_cli_tools function."""
    
    @patch('cli.utils.subprocess.run')
    def test_all_tools_available(self, mock_run):
        """Test when all CLI tools are available."""
        mock_run.return_value = MagicMock()
        
        result = check_cli_tools(interactive=False)
        
        assert result.aws_cli is True
        assert result.sam_cli is True
        assert result.micronaut_cli is True
        assert result.all_available is True
        
        # Should have called subprocess.run 3 times
        assert mock_run.call_count == 3
    
    @patch('cli.utils.subprocess.run')
    def test_missing_tools_non_interactive(self, mock_run):
        """Test missing tools in non-interactive mode."""
        # AWS CLI available, others missing
        def side_effect(cmd, **kwargs):
            if cmd[0] == "aws":
                return MagicMock()
            else:
                raise FileNotFoundError()
        
        mock_run.side_effect = side_effect
        
        result = check_cli_tools(interactive=False)
        
        assert result.aws_cli is True
        assert result.sam_cli is False
        assert result.micronaut_cli is False
        assert result.all_available is False
    
    @patch('cli.utils.subprocess.run')
    def test_missing_tools_interactive(self, mock_run):
        """Test missing tools in interactive mode raises exception."""
        mock_run.side_effect = FileNotFoundError()
        
        with pytest.raises(ToolNotFoundError, match="AWS CLI"):
            check_cli_tools(interactive=True)
    
    @patch('cli.utils.subprocess.run')
    def test_subprocess_error_non_interactive(self, mock_run):
        """Test subprocess error in non-interactive mode."""
        mock_run.side_effect = subprocess.CalledProcessError(1, "aws")
        
        result = check_cli_tools(interactive=False)
        
        assert result.aws_cli is False
        assert result.sam_cli is False
        assert result.micronaut_cli is False


class TestAskUserInput:
    """Test ask_user_input function."""
    
    @patch('builtins.input')
    def test_default_values(self, mock_input):
        """Test using default values."""
        mock_input.side_effect = ["", ""]  # Empty inputs use defaults
        
        app_name, dest_dir = ask_user_input()
        
        assert app_name == "hello_world"  # Sanitized version of "hello-world"
        assert dest_dir == os.getcwd()
    
    @patch('builtins.input')
    def test_custom_values(self, mock_input):
        """Test using custom values."""
        mock_input.side_effect = ["my-awesome-app", "/tmp/projects"]
        
        app_name, dest_dir = ask_user_input()
        
        assert app_name == "my_awesome_app"
        assert dest_dir == "/tmp/projects"
    
    @patch('builtins.input')
    def test_expanduser_path(self, mock_input):
        """Test path expansion with ~."""
        mock_input.side_effect = ["test-app", "~/projects"]
        
        app_name, dest_dir = ask_user_input()
        
        assert app_name == "test_app"
        assert dest_dir == os.path.expanduser("~/projects")


class TestInitGitRepo:
    """Test init_git_repo function."""
    
    @patch('cli.utils.subprocess.run')
    def test_successful_init_modern_git(self, mock_run, temp_dir):
        """Test successful git initialization with modern git."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        init_git_repo(str(project_dir))
        
        # Should call git init -b main, git add ., git commit
        assert mock_run.call_count == 3
        
        calls = mock_run.call_args_list
        assert calls[0][0][0] == ["git", "init", "-b", "main"]
        assert calls[1][0][0] == ["git", "add", "."]
        assert calls[2][0][0] == ["git", "commit", "-m", "Initial commit"]
    
    @patch('cli.utils.subprocess.run')
    def test_successful_init_old_git(self, mock_run, temp_dir):
        """Test successful git initialization with old git (fallback)."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        # First call fails (old git), subsequent calls succeed
        def side_effect(cmd, **kwargs):
            if cmd == ["git", "init", "-b", "main"]:
                raise subprocess.CalledProcessError(1, cmd)
            return MagicMock()
        
        mock_run.side_effect = side_effect
        
        init_git_repo(str(project_dir))
        
        # Should call git init -b main (fails), git init, git checkout -b main, git add ., git commit
        assert mock_run.call_count == 5
    
    @patch('cli.utils.subprocess.run')
    def test_git_init_failure(self, mock_run, temp_dir):
        """Test git initialization failure."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        mock_run.side_effect = subprocess.CalledProcessError(1, "git")
        
        with pytest.raises(ProjectError, match="Failed to initialize git repository"):
            init_git_repo(str(project_dir))
    
    @patch('cli.utils.subprocess.run')
    def test_git_commit_failure(self, mock_run, temp_dir):
        """Test git commit failure."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        # Init succeeds, add succeeds, commit fails
        def side_effect(cmd, **kwargs):
            if "commit" in cmd:
                raise subprocess.CalledProcessError(1, cmd)
            return MagicMock()
        
        mock_run.side_effect = side_effect
        
        with pytest.raises(ProjectError, match="Failed to create initial git commit"):
            init_git_repo(str(project_dir))


class TestEnsureDirectory:
    """Test ensure_directory function."""
    
    def test_create_new_directory(self, temp_dir):
        """Test creating a new directory."""
        new_dir = temp_dir / "new" / "nested" / "directory"
        
        ensure_directory(str(new_dir))
        
        assert new_dir.exists()
        assert new_dir.is_dir()
    
    def test_existing_directory(self, temp_dir):
        """Test with existing directory."""
        existing_dir = temp_dir / "existing"
        existing_dir.mkdir()
        
        # Should not raise an error
        ensure_directory(str(existing_dir))
        
        assert existing_dir.exists()
        assert existing_dir.is_dir()
    
    @patch('os.makedirs')
    def test_permission_error(self, mock_makedirs, temp_dir):
        """Test directory creation with permission error."""
        mock_makedirs.side_effect = OSError("Permission denied")
        
        with pytest.raises(ProjectError, match="Failed to create directory"):
            ensure_directory(str(temp_dir / "forbidden"))


class TestRunCommand:
    """Test run_command function."""
    
    @patch('cli.utils.subprocess.run')
    def test_successful_command(self, mock_run):
        """Test successful command execution."""
        mock_result = MagicMock()
        mock_run.return_value = mock_result
        
        result = run_command(["echo", "hello"])
        
        assert result == mock_result
        mock_run.assert_called_once_with(["echo", "hello"], cwd=None, check=True)
    
    @patch('cli.utils.subprocess.run')
    def test_command_with_options(self, mock_run):
        """Test command with various options."""
        mock_result = MagicMock()
        mock_run.return_value = mock_result
        
        result = run_command(
            ["ls", "-la"], 
            cwd="/tmp", 
            capture_output=True, 
            check=False
        )
        
        assert result == mock_result
        mock_run.assert_called_once_with(
            ["ls", "-la"], 
            cwd="/tmp", 
            check=False,
            capture_output=True,
            text=True
        )
    
    @patch('cli.utils.subprocess.run')
    def test_command_failure(self, mock_run):
        """Test command failure with check=True."""
        mock_run.side_effect = subprocess.CalledProcessError(1, "false")
        
        with pytest.raises(subprocess.CalledProcessError):
            run_command(["false"])
    
    @patch('cli.utils.subprocess.run')
    def test_command_failure_no_check(self, mock_run):
        """Test command failure with check=False."""
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_run.return_value = mock_result
        
        result = run_command(["false"], check=False)
        
        assert result == mock_result
