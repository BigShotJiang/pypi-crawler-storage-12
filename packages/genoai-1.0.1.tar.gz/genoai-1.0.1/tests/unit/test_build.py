"""
Unit tests for the build operations module.
"""

import os
import glob
from pathlib import Path
from unittest.mock import patch, MagicMock
import pytest

from cli.build import BuildManager, TemplateSpec, BuildResult
from cli.exceptions import BuildError


class TestTemplateSpec:
    """Test TemplateSpec data class."""
    
    def test_basic_properties(self):
        """Test basic TemplateSpec properties."""
        spec = TemplateSpec(
            app_name="test-app",
            region="us-east-1",
            proxy_all=True,
            requires_key=False
        )
        
        assert spec.app_name == "test-app"
        assert spec.region == "us-east-1"
        assert spec.proxy_all is True
        assert spec.requires_key is False
    
    def test_default_values(self):
        """Test TemplateSpec default values."""
        spec = TemplateSpec(app_name="test-app", region="us-east-1")
        
        assert spec.proxy_all is False
        assert spec.requires_key is True


class TestBuildResult:
    """Test BuildResult data class."""
    
    def test_successful_result(self):
        """Test successful BuildResult."""
        result = BuildResult(success=True, jar_path="/path/to/app.jar")
        
        assert result.success is True
        assert result.jar_path == "/path/to/app.jar"
        assert result.error_message is None
    
    def test_failed_result(self):
        """Test failed BuildResult."""
        result = BuildResult(success=False, error_message="Build failed")
        
        assert result.success is False
        assert result.jar_path is None
        assert result.error_message == "Build failed"


class TestBuildManager:
    """Test BuildManager class."""
    
    def test_init(self):
        """Test BuildManager initialization."""
        manager = BuildManager()
        assert manager is not None
    
    @patch('os.path.isfile')
    @patch('os.chmod')
    def test_ensure_gradle_wrapper_exists(self, mock_chmod, mock_isfile, temp_dir):
        """Test ensuring Gradle wrapper when it exists."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        mock_isfile.return_value = True
        
        manager = BuildManager()
        manager.ensure_gradle_wrapper(str(project_dir))
        
        # Should check for gradlew and set permissions
        mock_isfile.assert_called_once_with(str(project_dir / "gradlew"))
        mock_chmod.assert_called_once_with(str(project_dir / "gradlew"), 0o755)
    
    @patch('cli.build.run_command')
    @patch('os.path.isfile')
    @patch('os.chmod')
    def test_ensure_gradle_wrapper_missing(self, mock_chmod, mock_isfile, mock_run_command, temp_dir):
        """Test ensuring Gradle wrapper when it's missing."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        mock_isfile.return_value = False
        
        manager = BuildManager()
        manager.ensure_gradle_wrapper(str(project_dir))
        
        # Should generate wrapper and set permissions
        mock_run_command.assert_called_once_with(["gradle", "wrapper"], cwd=str(project_dir))
        mock_chmod.assert_called_once()
    
    @patch('cli.build.run_command')
    @patch('os.path.isfile')
    def test_ensure_gradle_wrapper_generation_failure(self, mock_isfile, mock_run_command, temp_dir):
        """Test Gradle wrapper generation failure."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        mock_isfile.return_value = False
        mock_run_command.side_effect = Exception("Gradle not found")
        
        manager = BuildManager()
        
        with pytest.raises(BuildError, match="Failed to generate Gradle wrapper"):
            manager.ensure_gradle_wrapper(str(project_dir))
    
    @patch('os.chmod')
    @patch('os.path.isfile')
    def test_ensure_gradle_wrapper_chmod_failure(self, mock_isfile, mock_chmod, temp_dir):
        """Test Gradle wrapper chmod failure."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        mock_isfile.return_value = True
        mock_chmod.side_effect = OSError("Permission denied")
        
        manager = BuildManager()
        
        with pytest.raises(BuildError, match="Failed to set gradlew permissions"):
            manager.ensure_gradle_wrapper(str(project_dir))
    
    @patch('glob.glob')
    @patch('cli.build.run_command')
    def test_build_jar_success(self, mock_run_command, mock_glob, temp_dir):
        """Test successful JAR building."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        # Mock successful build and JAR file existence
        mock_glob.return_value = [str(project_dir / "build" / "libs" / "test-app-0.1-all.jar")]
        
        manager = BuildManager()
        result = manager.build_jar(str(project_dir))
        
        assert result.success is True
        assert "test-app-0.1-all.jar" in result.jar_path
        assert result.error_message is None
        
        mock_run_command.assert_called_once_with(["./gradlew", "shadowJar"], cwd=str(project_dir))
    
    @patch('cli.build.run_command')
    def test_build_jar_command_failure(self, mock_run_command, temp_dir):
        """Test JAR building with command failure."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        mock_run_command.side_effect = Exception("Build failed")
        
        manager = BuildManager()
        result = manager.build_jar(str(project_dir))
        
        assert result.success is False
        assert result.jar_path is None
        assert "Gradle build failed" in result.error_message
    
    @patch('glob.glob')
    @patch('cli.build.run_command')
    def test_build_jar_no_jar_found(self, mock_run_command, mock_glob, temp_dir):
        """Test JAR building when no JAR file is found."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        # Build succeeds but no JAR file found
        mock_glob.return_value = []
        
        manager = BuildManager()
        result = manager.build_jar(str(project_dir))
        
        assert result.success is False
        assert result.jar_path is None
        assert "JAR file not found after build" in result.error_message
    
    @patch('cli.build.run_command')
    def test_run_tests_success(self, mock_run_command, temp_dir):
        """Test successful test execution."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        manager = BuildManager()
        result = manager.run_tests(str(project_dir))
        
        assert result.success is True
        assert result.error_message is None
        
        mock_run_command.assert_called_once_with(["./gradlew", "test"], cwd=str(project_dir))
    
    @patch('cli.build.run_command')
    def test_run_tests_failure(self, mock_run_command, temp_dir):
        """Test test execution failure."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        mock_run_command.side_effect = Exception("Tests failed")
        
        manager = BuildManager()
        result = manager.run_tests(str(project_dir))
        
        assert result.success is False
        assert "Tests failed" in result.error_message
    
    def test_create_sam_template_basic(self, temp_dir):
        """Test basic SAM template creation."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        spec = TemplateSpec(
            app_name="test-app",
            region="us-east-1",
            proxy_all=False,
            requires_key=False
        )
        
        manager = BuildManager()
        manager.create_sam_template(spec, str(project_dir))
        
        template_file = project_dir / "template.yaml"
        assert template_file.exists()
        
        content = template_file.read_text()
        assert "AWSTemplateFormatVersion: '2010-09-09'" in content
        assert "Transform: AWS::Serverless-2016-10-31" in content
        assert "TestAppFunction:" in content
        assert "Runtime: java17" in content
        assert "Path: /hello" in content
        assert "Method: get" in content
        
        # Should not have API key resources
        assert "MyUsagePlan:" not in content
        assert "MyApiKey:" not in content
    
    def test_create_sam_template_with_api_key(self, temp_dir):
        """Test SAM template creation with API key."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        spec = TemplateSpec(
            app_name="test-app",
            region="us-east-1",
            proxy_all=True,
            requires_key=True
        )
        
        manager = BuildManager()
        manager.create_sam_template(spec, str(project_dir))
        
        template_file = project_dir / "template.yaml"
        content = template_file.read_text()
        
        # Should have proxy-all configuration
        assert "Path: /{proxy+}" in content
        assert "Method: any" in content
        
        # Should have API key authentication
        assert "Auth:" in content
        assert "ApiKeyRequired: true" in content
        
        # Should have API key resources
        assert "MyUsagePlan:" in content
        assert "MyApiKey:" in content
        assert "MyUsagePlanKey:" in content
        
        # Should have API key output
        assert "ApiKey:" in content
        assert "Value: !Ref MyApiKey" in content
    
    def test_create_sam_template_special_app_name(self, temp_dir):
        """Test SAM template creation with special characters in app name."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        spec = TemplateSpec(
            app_name="my-awesome_app-123",
            region="us-west-2"
        )
        
        manager = BuildManager()
        manager.create_sam_template(spec, str(project_dir))
        
        template_file = project_dir / "template.yaml"
        content = template_file.read_text()
        
        # Should generate proper logical ID
        assert "MyAwesomeApp123Function:" in content
        
        # Should use sanitized JAR name
        assert "myawesomeapp123-0.1-all.jar" in content
    
    def test_create_sam_template_write_failure(self, temp_dir):
        """Test SAM template creation with write failure."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        # Make directory read-only
        project_dir.chmod(0o444)
        
        spec = TemplateSpec(app_name="test-app", region="us-east-1")
        manager = BuildManager()
        
        with pytest.raises(BuildError, match="Failed to create SAM template"):
            manager.create_sam_template(spec, str(project_dir))
        
        # Restore permissions for cleanup
        project_dir.chmod(0o755)
    
    @patch('cli.build.run_command')
    def test_clean_build_success(self, mock_run_command, temp_dir):
        """Test successful build cleaning."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        manager = BuildManager()
        manager.clean_build(str(project_dir))
        
        mock_run_command.assert_called_once_with(["./gradlew", "clean"], cwd=str(project_dir))
    
    @patch('cli.build.run_command')
    def test_clean_build_failure(self, mock_run_command, temp_dir):
        """Test build cleaning failure."""
        project_dir = temp_dir / "test-project"
        project_dir.mkdir()
        
        mock_run_command.side_effect = Exception("Clean failed")
        
        manager = BuildManager()
        
        with pytest.raises(BuildError, match="Failed to clean build"):
            manager.clean_build(str(project_dir))
