"""Unit tests for individual CLI modules."""
