"""
Pytest configuration and shared fixtures.
"""

import os
import tempfile
import shutil
from pathlib import Path
from typing import Generator
import pytest

from cli.config import ConfigManager, EnvironmentConfig, ApiConfig


@pytest.fixture
def temp_dir() -> Generator[Path, None, None]:
    """Create a temporary directory for tests."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        yield Path(tmp_dir)


@pytest.fixture
def sample_env_config() -> dict:
    """Sample environment configuration data."""
    return {
        "aws_region": "us-east-1",
        "aws_profile": "default"
    }


@pytest.fixture
def sample_api_config() -> dict:
    """Sample API configuration data."""
    return {
        "service": {
            "name": "test-service",
            "package": "com.example.testservice"
        },
        "routes": [
            {
                "path": "/hello",
                "method": "get",
                "controller": "HelloController",
                "methodName": "index"
            },
            {
                "path": "/users/{id}",
                "method": "get", 
                "controller": "UserController",
                "methodName": "getUser"
            }
        ]
    }


@pytest.fixture
def config_manager(temp_dir: Path) -> ConfigManager:
    """ConfigManager instance with temporary config directory."""
    config_dir = temp_dir / "config"
    config_dir.mkdir()
    return ConfigManager(str(config_dir))


@pytest.fixture
def env_config_file(temp_dir: Path, sample_env_config: dict) -> Path:
    """Create a temporary environment config file."""
    import yaml
    
    config_dir = temp_dir / "config"
    config_dir.mkdir(exist_ok=True)
    
    config_file = config_dir / "dev.yaml"
    with open(config_file, "w") as f:
        yaml.dump(sample_env_config, f)
    
    return config_file


@pytest.fixture
def api_config_file(temp_dir: Path, sample_api_config: dict) -> Path:
    """Create a temporary API config file."""
    import yaml
    
    config_file = temp_dir / "api.yaml"
    with open(config_file, "w") as f:
        yaml.dump(sample_api_config, f)
    
    return config_file


@pytest.fixture
def mock_project_dir(temp_dir: Path) -> Path:
    """Create a mock Micronaut project directory structure."""
    project_dir = temp_dir / "test-project"
    project_dir.mkdir()
    
    # Create basic project structure
    src_dir = project_dir / "src" / "main" / "java" / "com" / "example"
    src_dir.mkdir(parents=True)
    
    # Create build.gradle
    build_gradle = project_dir / "build.gradle"
    build_gradle.write_text("""
plugins {
    id("com.github.johnrengelman.shadow") version "8.1.1"
    id("io.micronaut.application") version "4.4.2"
}

dependencies {
    implementation("io.micronaut:micronaut-core")
}

application {
    mainClass = "com.example.Application"
}
""")
    
    # Create gradlew
    gradlew = project_dir / "gradlew"
    gradlew.write_text("#!/bin/bash\necho 'mock gradlew'")
    gradlew.chmod(0o755)
    
    return project_dir


@pytest.fixture(autouse=True)
def preserve_cwd():
    """Preserve current working directory across tests."""
    original_cwd = os.getcwd()
    yield
    os.chdir(original_cwd)
