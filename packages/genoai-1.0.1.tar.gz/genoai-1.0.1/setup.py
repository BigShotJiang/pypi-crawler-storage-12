from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="genoai",
    version="1.0.1",
    author="Your Name",
    author_email="your.email@example.com",
    description="A command-line tool for generating and managing project structures",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/genoai",
    packages=find_packages(),
    py_modules=["genoai"],
    include_package_data=True,
    install_requires=[
        "click>=8.0.0",
        "pyyaml>=6.0",
        "requests>=2.26.0",
    ],
    entry_points={
        "console_scripts": [
            "genoai=genoai:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
