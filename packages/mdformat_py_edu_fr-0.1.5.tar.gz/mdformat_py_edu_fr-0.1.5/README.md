# Tiny wrapper around mdformat for the py-edu-fr project
