"""Encapsulate Atlases."""
from solar_wavelength_calibration.atlas.atlas import Atlas
from solar_wavelength_calibration.atlas.atlas import default_config
from solar_wavelength_calibration.atlas.atlas import DownloadConfig
