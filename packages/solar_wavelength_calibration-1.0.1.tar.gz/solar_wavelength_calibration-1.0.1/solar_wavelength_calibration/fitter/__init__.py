"""Calibrates an input dataset's wavelength axis by fitting data to a FTS Atlas model."""
