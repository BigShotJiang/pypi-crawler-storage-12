.. include:: ../README.rst

.. toctree::
    :maxdepth: 2
    :hidden:

    self
    autoapi/index
    requirements_table
    changelog