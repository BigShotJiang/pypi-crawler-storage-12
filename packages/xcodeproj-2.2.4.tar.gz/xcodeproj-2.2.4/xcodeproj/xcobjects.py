"""PBX object types"""

from typing import Any, cast, Optional

import deserialize

from .pbxobject import PBXObject


@deserialize.key("base_configuration_reference_id", "baseConfigurationReference")
@deserialize.key("build_settings", "buildSettings")
@deserialize.downcast_identifier(PBXObject, "XCBuildConfiguration")
class XCBuildConfiguration(PBXObject):
    """Represents an XCBuildConfiguration.

    This is the raw build settings for a build configuration. Name is usually
    "Debug" or "Release".
    """

    base_configuration_reference_id: str | None
    build_settings: dict[str, Any]
    name: str

    @property
    def base_configuration(self) -> Optional["XCBuildConfiguration"]:
        """Get the base configuration for this build configureation.

        :returns: The base configuration
        """

        if not self.base_configuration_reference_id:
            return None

        return cast(XCBuildConfiguration, self.objects()[self.base_configuration_reference_id])


@deserialize.key("build_configuration_ids", "buildConfigurations")
@deserialize.key("default_configuration_is_visible", "defaultConfigurationIsVisible")
@deserialize.key("default_configuration_name", "defaultConfigurationName")
@deserialize.parser("defaultConfigurationIsVisible", lambda x: {"0": False, "1": True}[x])
@deserialize.downcast_identifier(PBXObject, "XCConfigurationList")
class XCConfigurationList(PBXObject):
    """Represents an XCConfigurationList.

    This is a list of build configurations. Usually associated with a target.
    """

    build_configuration_ids: list[str]
    default_configuration_is_visible: bool
    default_configuration_name: str

    @property
    def build_configurations(self) -> list[XCBuildConfiguration]:
        """Get all the build configurations for this list.

        :returns: The build configurations
        """
        return [
            cast(XCBuildConfiguration, self.objects()[build_configuration_id])
            for build_configuration_id in self.build_configuration_ids
        ]


@deserialize.key("product_name", "productName")
@deserialize.downcast_identifier(PBXObject, "XCSwiftPackageProductDependency")
class XCSwiftPackageProductDependency(PBXObject):
    """Represents an XCSwiftPackageProductDependency.

    This is a Swift package that the product depends on.
    """

    package: str
    product_name: str


@deserialize.key("repository_url", "repositoryURL")
@deserialize.downcast_identifier(PBXObject, "XCRemoteSwiftPackageReference")
class XCRemoteSwiftPackageReference(PBXObject):
    """Represents an XCRemoteSwiftPackageReference.

    This is a remote Swift package.
    """

    repository_url: str
    requirement: dict[str, Any]
