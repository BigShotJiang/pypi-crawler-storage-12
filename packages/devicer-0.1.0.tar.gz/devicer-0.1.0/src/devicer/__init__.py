from .cache import clear_torch
from .get_device import get_device

__all__ = ["get_device", "clear_torch"]
