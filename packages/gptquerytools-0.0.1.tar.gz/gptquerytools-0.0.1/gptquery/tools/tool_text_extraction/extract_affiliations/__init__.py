# gptquery\tools\tool_text_extraction\extract_affiliations\__init__.py
# FILE INTENTIONALLY BLANK
