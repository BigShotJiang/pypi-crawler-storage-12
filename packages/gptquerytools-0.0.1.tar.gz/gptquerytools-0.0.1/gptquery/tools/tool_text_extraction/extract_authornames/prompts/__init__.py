# gptquery\tools\tool_text_extraction\extract_authornames\prompts\__init__.py
# FILE INTENTIONALLY BLANK