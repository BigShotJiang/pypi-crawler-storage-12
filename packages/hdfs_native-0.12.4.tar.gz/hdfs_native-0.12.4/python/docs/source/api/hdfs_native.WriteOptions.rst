WriteOptions
============

.. currentmodule:: hdfs_native

.. autoclass:: WriteOptions
   :show-inheritance:

   .. rubric:: Attributes Summary

   .. autosummary::

      ~WriteOptions.block_size
      ~WriteOptions.create_parent
      ~WriteOptions.overwrite
      ~WriteOptions.permission
      ~WriteOptions.replication

   .. rubric:: Attributes Documentation

   .. autoattribute:: block_size
   .. autoattribute:: create_parent
   .. autoattribute:: overwrite
   .. autoattribute:: permission
   .. autoattribute:: replication
