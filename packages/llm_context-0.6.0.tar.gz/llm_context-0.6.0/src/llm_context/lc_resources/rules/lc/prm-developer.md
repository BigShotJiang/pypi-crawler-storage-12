---
description: Configures a base prompt for developer workflows, composing standard file filters to include essential code files (e.g., .py, .js, .ts).
instructions: [lc/ins-developer]
compose:
  filters: [lc/flt-base]
  excerpters: [lc/exc-base]
---
