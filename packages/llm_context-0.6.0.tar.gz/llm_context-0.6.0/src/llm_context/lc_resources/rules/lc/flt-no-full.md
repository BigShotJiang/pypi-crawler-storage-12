---
description: Excludes all files from full content selection using gitignore patterns. Use to restrict context to code outlines or metadata, minimizing context size.
gitignores:
  full-files: ["**/*"]
---
