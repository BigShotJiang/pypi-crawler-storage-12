"""Init module.

Auto-generated minimal module docstring.
"""
