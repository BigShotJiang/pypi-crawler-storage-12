"""ForgingBlocks for application-specific modules."""
