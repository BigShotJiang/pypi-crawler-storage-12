"""ForgingBlocks foundation.errors package initialization."""
