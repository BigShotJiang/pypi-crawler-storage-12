"""ForgingBlocks foundation modules."""
