"""ForgingBlocks package initialization."""
