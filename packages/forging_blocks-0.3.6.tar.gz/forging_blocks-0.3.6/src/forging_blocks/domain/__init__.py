"""ForgingBlocks for domain-specific modules."""
