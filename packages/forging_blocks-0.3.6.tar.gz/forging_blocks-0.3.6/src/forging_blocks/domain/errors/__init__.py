"""ForgingBlocks for domain errors."""
