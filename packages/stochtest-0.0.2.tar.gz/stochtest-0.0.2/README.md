# stochtest

[![PyPI - Version](https://img.shields.io/pypi/v/stochtest.svg)](https://pypi.org/project/stochtest)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/stochtest.svg)](https://pypi.org/project/stochtest)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install stochtest
```

## License

`stochtest` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
