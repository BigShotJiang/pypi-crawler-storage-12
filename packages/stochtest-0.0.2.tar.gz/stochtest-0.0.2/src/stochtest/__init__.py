# SPDX-FileCopyrightText: 2025-present Micah Brown
#
# SPDX-License-Identifier: MIT

# def test(sim_function, n_runs):
#     pass