

class RegiObject:
    pass






