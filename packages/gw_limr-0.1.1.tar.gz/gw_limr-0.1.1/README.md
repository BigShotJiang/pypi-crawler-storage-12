# limr

This is the Late-Inspiral Merger Ringdown (LIMR) model. It is a non-parametric non-spinning higher multipole model for the gravitational waves emitted from merging black holes.

## Installation

TODO

## Documentation

TODO

## Development

### Publish

```bash
$ uv publish --username __token__
```
