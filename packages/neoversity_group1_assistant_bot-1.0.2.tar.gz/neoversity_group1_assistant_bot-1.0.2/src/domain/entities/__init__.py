from src.domain.entities.contact import Contact
from src.domain.entities.note import Note

__all__ = [
    "Contact",
    "Note",
]
