class PhoneConfig:

    # Exact phone length for validation
    EXACT_PHONE_LENGTH = 10
    """Exact expected length for phone numbers (digits only)."""
