class UIConfig:

    # Command suggestion in classic mode
    CLASSIC_COMMAND_SUGGESTION_CUTOFF = 0.6
    """Fuzzy matching cutoff for command suggestions in classic mode."""
