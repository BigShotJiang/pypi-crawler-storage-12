from src.application.exceptions.base import (
    StorageException,
)

__all__ = [
    "StorageException",
]
