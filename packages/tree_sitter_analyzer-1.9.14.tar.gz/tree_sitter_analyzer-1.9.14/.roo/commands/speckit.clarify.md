# clarify

要件明確化と質問生成 - 詳細は [.roo/docs/speckit.clarify.md](.roo/docs/speckit.clarify.md) を参照