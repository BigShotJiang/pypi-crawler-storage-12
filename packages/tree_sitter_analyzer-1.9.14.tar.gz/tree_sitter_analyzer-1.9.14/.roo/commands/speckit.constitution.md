# constitution

プロジェクト憲法と基本原則 - 詳細は [.roo/docs/speckit.constitution.md](.roo/docs/speckit.constitution.md) を参照