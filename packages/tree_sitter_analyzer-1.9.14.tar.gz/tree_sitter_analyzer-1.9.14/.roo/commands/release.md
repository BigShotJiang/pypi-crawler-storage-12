# release

GitFlowリリースプロセス自動化 - 詳細は [.roo/docs/release.md](.roo/docs/release.md) を参照