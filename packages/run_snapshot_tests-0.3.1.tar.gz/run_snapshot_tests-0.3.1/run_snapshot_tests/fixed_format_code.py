def fixed_format_code(text, filename):
    # disable format code because it fails on new versions of python with inline-snapshot==0.8.0
    return text
