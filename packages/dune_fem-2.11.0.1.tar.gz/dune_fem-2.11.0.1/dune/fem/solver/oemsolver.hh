#ifndef DUNE_FEM_OEMSOLVER_HH
#define DUNE_FEM_OEMSOLVER_HH
#warning "Depreacted header, use #include <dune/fem/solver/krylovinverseoperators.hh> instead!"
#include <dune/fem/solver/krylovinverseoperators.hh>
#endif
