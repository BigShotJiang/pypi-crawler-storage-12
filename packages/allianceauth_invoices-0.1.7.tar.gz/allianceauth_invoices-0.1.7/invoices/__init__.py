"""
Invoice module for AllianceAuth with simplicity and extendability in mind.
"""

__version__ = "0.1.7"
__title__ = "Invoice Manager"
