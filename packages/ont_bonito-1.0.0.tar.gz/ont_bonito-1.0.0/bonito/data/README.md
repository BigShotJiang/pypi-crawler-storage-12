# Bonito Training Data

If this directory is empty is please run `bonito download --training`.
