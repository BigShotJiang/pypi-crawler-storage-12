from bonito import main
main()
