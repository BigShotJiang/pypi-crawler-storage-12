# Bonito Pre-trained Models

If this directory only contains `configs` then please run `bonito download --models`.
