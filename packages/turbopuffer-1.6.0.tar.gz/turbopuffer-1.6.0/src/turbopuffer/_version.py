# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "turbopuffer"
__version__ = "1.6.0"  # x-release-please-version
