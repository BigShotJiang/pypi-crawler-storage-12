v0.2.6
------

Released 2025-11-16

- rename manager.py to exts.py
- rename Class Manager to Exts

v0.2.5
------

Released 2025-10-24

- rewrite template structure
- rewrite user view, user authentication and authorization

v0.2.4
------

Released 2025-10-06

- user change password
- user forgot password
- user 2FA with TOTP
- user recovery codes
- user recovery

v0.2.3
------

Released 2025-08-28

- move form into template
- add folder email
- add security.email_verification

v0.2.2
------

Released 2025-04-09

- fix datetimepicker
- set session = db.session as default if ModelView of sqla init session is None
- set session = db.session as default if QueryAjaxModelLoader init session is None
- fix select.ajax for select2@4.1.0 
- fix select in modal
- add casbin
- add module: security 

v0.2.1
------

Released 2025-02-15

- add admin.sqla

v0.2.0
------

Released 2025-01-07

- update templates.macros

v0.1.9
------

Released 2024-12-01

- add index_view

v0.1.8
------

Released 2024-11-24

- add user_view

v0.1.7
------

Released 2024-10-13

- add theme for template
- admin view framework

v0.1.6
------

Released 2024-09-14

- merge translations of wtforms, flask_exts and app into flask_babel.get_translations()
- update FileField and ImageField
- add url for _template.static

v0.1.5
------

Released 2024-08-21

- bootstrap templates

v0.1.4
------

Released 2024-08-02

- form

v0.1.3
------

Released 2024-03-25

- babel support

v0.1.2
------

Released 2024-03-22

- .readthedocs.yaml

v0.1.1
------

Released 2024-03-21

- Init docs

v0.1.0
------

Released 2024-03-20

- Init release
