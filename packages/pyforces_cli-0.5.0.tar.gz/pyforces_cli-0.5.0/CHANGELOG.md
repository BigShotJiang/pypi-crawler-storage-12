# Change Log

## v0.4.3

* Add the description of "contest id" in README.
* Add color to `pyforces test` results and print the output and answer if failed.
* Executor now only runs for 2s, not double time limit.
