def print_me():
    print("Hello World from print me")