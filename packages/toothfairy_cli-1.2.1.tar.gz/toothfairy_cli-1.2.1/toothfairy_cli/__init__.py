"""ToothFairyAI CLI package."""

__version__ = "1.2.1"
__author__ = "ToothFairyAI"
__email__ = "support@toothfairyai.com"
