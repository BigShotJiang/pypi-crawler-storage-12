"""Plugin system for streamdeck-ui."""
