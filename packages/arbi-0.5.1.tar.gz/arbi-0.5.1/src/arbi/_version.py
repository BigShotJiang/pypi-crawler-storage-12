# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "arbi"
__version__ = "0.5.1"  # x-release-please-version
