# MicroXML versions of Schematron and Examplotron

NOT YET IMPLEMENTED

Collectively called Xtron, here are Amara's implementations of MicroXML versions of the most sensible XML schema technologies

* [Schematron](http://schematron.com/)
* [Examplotron](http://examplotron.org/)



## References

* [schxslt](https://github.com/schxslt/schxslt) by David Maus
* [Schematron.com Github org](https://github.com/Schematron)

----

Author: [Uche Ogbuji](http://uche.ogbuji.net) <uche@ogbuji.net>

