# amara.cmodules - Optional C extension modules for performance
