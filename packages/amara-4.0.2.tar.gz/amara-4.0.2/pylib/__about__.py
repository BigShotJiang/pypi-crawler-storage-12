# SPDX-FileCopyrightText: 2024-present Uche Ogbuji <uche@oori.dev>
#
# SPDX-License-Identifier: Apache-2.0
__version__ = '4.0.2'
