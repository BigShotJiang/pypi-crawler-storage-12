"""Eon Next API client for retrieving electricity consumption data."""

__version__ = "0.1.2"
