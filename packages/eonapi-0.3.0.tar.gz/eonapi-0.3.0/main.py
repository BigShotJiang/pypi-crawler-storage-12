"""Entry point for eonpy CLI."""

from eonpy.cli import main

if __name__ == "__main__":
    main()
