-- EXTERNAL:test-comments-1-rawSql.sql
SELECT * FROM metrics
