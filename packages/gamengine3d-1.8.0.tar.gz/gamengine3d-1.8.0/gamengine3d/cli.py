
import argparse
import runpy
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(prog="gamengine3d")
    sub = parser.add_subparsers(dest="command", required=True)

    # Get the list of available demos from the examples folder
    examples_dir = Path(__file__).parent / "examples"
    available_demos = [
        f.stem for f in examples_dir.glob("*.py") if f.is_file() and f.name != "__init__.py"
    ]

    demo_cmd = sub.add_parser("demo", help="Run a built-in example")
    demo_cmd.add_argument(
        "demo_name",
        nargs="?",
        default="basics",
        choices=available_demos,  # restrict to available demos
        help=f"The name of the example to run. Available: {', '.join(available_demos)}"
    )

    args = parser.parse_args()

    if args.command == "demo":
        module = f"gamengine3d.examples.{args.demo_name}"
        print(f"Running example: {args.demo_name}")
        print(f"Path: {module}")
        runpy.run_module(module, run_name="__main__")

if __name__ == "__main__":
    main()
