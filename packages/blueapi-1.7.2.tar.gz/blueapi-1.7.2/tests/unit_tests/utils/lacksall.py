a = 3
b = "hello"
c = a**2
