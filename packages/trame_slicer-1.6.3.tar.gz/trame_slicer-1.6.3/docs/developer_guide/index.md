# Developer Guide

```{toctree}
:maxdepth: 3

segmentation/index
contributing
style_guide
authors
```
