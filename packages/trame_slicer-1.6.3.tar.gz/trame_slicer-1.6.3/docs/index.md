# Welcome to trame-slicer's documentation!

```{toctree}
:maxdepth: 2

developer_guide/index
```

# Indices and tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`
