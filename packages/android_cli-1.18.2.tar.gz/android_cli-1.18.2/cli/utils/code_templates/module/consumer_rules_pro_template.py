def create_consumer_rules():
    file_name = "consumer-rules.pro"
    file_content = f''''''
    
    with open(file_name, "w") as file:
        file.write(file_content)

