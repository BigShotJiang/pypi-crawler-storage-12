if the survey is properly configured, once it is submited by an
anonomous user, a new contact is create or an existing one is linked.
