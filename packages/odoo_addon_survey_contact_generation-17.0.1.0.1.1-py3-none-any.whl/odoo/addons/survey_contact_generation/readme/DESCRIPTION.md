This module allows to generate new contacts from surveys answers.
