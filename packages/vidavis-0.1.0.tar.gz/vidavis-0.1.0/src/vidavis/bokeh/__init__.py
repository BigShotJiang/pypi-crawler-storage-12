'''This module contains the extensions and additions to the functionality
provided by Bokeh'''
