"""Public API for accessing the NI Data Store Service."""

from ni.measurements.data.v1.client._client import DataStoreClient

__all__ = ["DataStoreClient"]
