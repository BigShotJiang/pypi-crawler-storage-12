# cages

A simple Python module with an add function.

## Installation

```bash
pip install cages
```

## Usage

```python
from cages import add

result = add(2, 3)
print(result)  # Output: 5
```

## License

MIT
