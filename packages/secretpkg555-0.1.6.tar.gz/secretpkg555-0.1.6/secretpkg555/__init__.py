__version__ = "0.1.6"
__author__ = "None555"

# 导出核心模块供用户使用
from . import core_logic

__all__ = ['core_logic']