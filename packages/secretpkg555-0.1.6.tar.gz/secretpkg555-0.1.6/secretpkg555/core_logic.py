"""
核心逻辑模块
"""

def calculation(x, y):
    """计算两个数的和"""
    return x + y