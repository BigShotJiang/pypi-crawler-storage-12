# Copyright (c) 2025 Hasan Sezer Taşan <hasansezertasan@gmail.com>
# Licensed under the MIT License

"""Entry point for the tests."""
