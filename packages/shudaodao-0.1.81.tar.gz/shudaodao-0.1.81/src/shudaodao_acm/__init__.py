#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# @License  ：(C)Copyright 2025, 数道智融科技

# 不要删除这个空文件， yaml配置文件中 routers 节点 自动加载路由、模块 需要文件夹类型为包
