Open a Contact form to see the contacts tab It is visible in new contact
form that the type 'store' appeared at the top right are of the form.

The contact type can be changed by changing the value with the radio
buttons.
