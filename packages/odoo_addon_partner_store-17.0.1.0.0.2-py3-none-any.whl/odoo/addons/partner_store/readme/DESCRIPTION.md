Adds a 'store' type of contact
