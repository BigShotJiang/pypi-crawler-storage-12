To create a new Store contact:

#. Navigate to *Contacts > Open a partner record 

#. Create a new contact of type store in the contacts tab
