#!/usr/bin/env python3
"""Entry point for pkg-guard CLI."""

from pkg_guard.cli import app

if __name__ == "__main__":
    app()
