"""Tests for gocam."""

from pathlib import Path

EXAMPLES_DIR = Path(__file__).parent / "../src/data/examples"
INPUT_DIR = Path(__file__).parent / "input"
OUTPUT_DIR = Path(__file__).parent / "output"
