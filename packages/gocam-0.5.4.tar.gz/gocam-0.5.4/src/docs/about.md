# gocam

GO CAM Data Model (Python)
