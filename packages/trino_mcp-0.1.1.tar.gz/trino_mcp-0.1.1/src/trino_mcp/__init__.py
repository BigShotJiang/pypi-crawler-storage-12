"""Trino MCP Server - A simple Model Context Protocol server for Trino."""

__version__ = "0.1.0"
