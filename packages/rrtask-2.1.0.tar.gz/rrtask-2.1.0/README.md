# Basic Usage

```python3
>>> import rrtask
```

# Install

via `pip`:

```shell
pip install rrtask
```

via `pipenv`:

```
pipenv install rrtask
```

Bump version in pyproject.toml and push with `make deploy`
