"""Main entry point for CLI."""

from omnigen.cli.main import main

if __name__ == "__main__":
    main()