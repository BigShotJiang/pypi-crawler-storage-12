"""Experimental features."""

from that_depends.experimental.providers import LazyProvider


__all__ = [
    "LazyProvider",
]
