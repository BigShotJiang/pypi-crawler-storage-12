"""Utility functions for SDK generation."""
