"""OpenAPI SDK Generator - Multi-language SDK generator from OpenAPI specs."""

__version__ = "0.1.0"
