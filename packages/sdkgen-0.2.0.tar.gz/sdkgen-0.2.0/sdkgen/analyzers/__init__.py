"""Analyzers for detecting patterns in OpenAPI specs."""
