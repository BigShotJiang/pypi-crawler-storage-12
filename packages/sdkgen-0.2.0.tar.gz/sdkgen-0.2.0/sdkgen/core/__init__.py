"""Core components for parsing and building IR from OpenAPI specs."""
