"""
Example Module
"""

__version__ = "0.1.0"

def hello_world():
    """Return a greeting message."""
    return "Hello, World!"

def add_numbers(a, b):
    """Add two numbers and return the result."""
    return a + b

