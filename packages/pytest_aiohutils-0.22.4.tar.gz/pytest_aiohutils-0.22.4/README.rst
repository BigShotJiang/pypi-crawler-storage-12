This library is not intended for direct public use.
It is used as development dependency for the following projects:

* https://github.com/5j9/tsetmc
* https://github.com/5j9/fipiran
* https://github.com/5j9/iranetf
* https://github.com/5j9/aggregator
