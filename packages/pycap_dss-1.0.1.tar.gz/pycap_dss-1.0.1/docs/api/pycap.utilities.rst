Utility functions
-----------------
Utility functions used to facilitate constructing workflows using `pycap-dss`. 

.. automodule:: pycap.utilities
   :members:
   :show-inheritance: