from dataflow.boot import ApplicationBoot
    
if __name__ == "__main__":
    ApplicationBoot.Start()
