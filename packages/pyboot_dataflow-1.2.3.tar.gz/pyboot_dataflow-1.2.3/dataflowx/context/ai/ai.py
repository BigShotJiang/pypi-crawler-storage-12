from dataflow.utils.log import Logger

_logger = Logger('dataflowx.context.ai')

_logger.DEBUG('加载AI模块')