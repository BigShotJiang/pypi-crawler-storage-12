from fasthtml.common import serve #noqa
from fast_gov_uk.core import Fast #noqa
