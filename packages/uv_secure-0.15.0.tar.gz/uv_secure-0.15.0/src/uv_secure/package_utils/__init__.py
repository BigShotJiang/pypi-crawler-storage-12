from uv_secure.package_utils.name_utils import canonicalize_name


__all__ = ["canonicalize_name"]
