from . import cli

cli.handle_cli()
