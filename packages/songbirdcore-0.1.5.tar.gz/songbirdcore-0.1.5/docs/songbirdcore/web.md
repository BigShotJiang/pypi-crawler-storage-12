# web

::: songbirdcore.web
    handler: python
