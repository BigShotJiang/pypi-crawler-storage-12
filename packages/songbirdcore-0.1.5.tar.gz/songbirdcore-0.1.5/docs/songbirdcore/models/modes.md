# modes

::: songbirdcore.models.modes
    handler: python
