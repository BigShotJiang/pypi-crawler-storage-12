"""ADP CLI - Artifact Provisioning Engine."""

__version__ = "0.0.1"

