<div align="center">

# saneyak

Yet Another Kit: Python utilities built with sensible third-party libraries

[![GitHub](https://img.shields.io/badge/github-code-blue?label=GitHub)](https://github.com/oyghen/saneyak)
[![PyPI](https://img.shields.io/pypi/v/saneyak?label=PyPI)](https://pypi.org/project/saneyak)
[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://github.com/oyghen/saneyak/blob/main/LICENSE)
[![CI](https://github.com/oyghen/saneyak/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/oyghen/saneyak/actions/workflows/ci.yml)

</div>

```shell
pip install saneyak
```
