Originally intended to create sentences from the word snippets for the
Half Life 1 Vox, this project can take a folder of word audio files and piece
them into sentences.
