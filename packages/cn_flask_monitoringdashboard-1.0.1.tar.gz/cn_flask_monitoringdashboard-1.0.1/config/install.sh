# Run from the root directory with ./config/install.sh

python -m venv env
source env/bin/activate
pip install -r requirements-dev.txt
