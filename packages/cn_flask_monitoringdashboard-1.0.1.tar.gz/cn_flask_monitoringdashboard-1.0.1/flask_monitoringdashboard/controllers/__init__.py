"""This directory is used for implementing the logic between the database and the API."""
