export default function () {
    this.graphText = 'You can hover the graph with your mouse to see the actual values. You can also use the ' +
        'buttons at the top of the graph to select a subset of graph, scale it accordingly, or save the graph ' +
        'as a PNG image.';
    this.axesText = '';
    this.contentText = '';
}