class RelationElement:
    def relation_construct(self, cur_page, pages):
        pass
