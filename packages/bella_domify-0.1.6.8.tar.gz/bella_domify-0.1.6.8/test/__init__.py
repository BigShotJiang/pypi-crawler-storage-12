import os

# 获取当前文件的绝对路径
TEST_PATH = os.path.dirname(os.path.abspath(__file__))