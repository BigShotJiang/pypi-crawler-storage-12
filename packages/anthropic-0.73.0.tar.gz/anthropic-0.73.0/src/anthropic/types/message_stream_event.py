# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .raw_message_stream_event import RawMessageStreamEvent

__all__ = ["MessageStreamEvent"]

MessageStreamEvent = RawMessageStreamEvent
"""The RawMessageStreamEvent type should be used instead"""
