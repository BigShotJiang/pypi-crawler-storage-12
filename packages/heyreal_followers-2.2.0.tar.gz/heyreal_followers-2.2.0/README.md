# heyreal.ai Follow Bot ✅

<img src = "https://github.com/DwiDevelopes/Followers-HeyReal/blob/main/Screenshot%202025-11-10%20125531.png?raw=true" width="100%">
<p align="center">
<img src="https://github.com/DwiDevelopes/Followers-HeyReal/blob/main/Screenshot%202025-11-10%20125521.png?raw=true" width="48%" />
<img src="https://github.com/DwiDevelopes/Followers-HeyReal/blob/main/Screenshot%202025-11-10%20125628.png?raw=true" width="48%" />
</p>


**Dibuat oleh:** Dwi Bakti N. Dev  
**Versi:** 2.0  
**Status:** Aktif

## 📝 Deskripsi
Bot otomatis untuk mengirim permintaan follow berulang kali di platform heyreal.ai. Dibuat dengan cepat dan efisien untuk kebutuhan automasi follow.

## 🚀 Fitur Utama
- **Request Based** 🔥 - Berbasis permintaan yang efisien
- **High Speed** 🔥 - Proses eksekusi yang cepat
- **Token Reusable** - Dapat menggunakan token yang sama berulang kali
- **Simple Setup** - Konfigurasi mudah dan straightforward


## ⚙️ Cianon Follow Bot
```python
    print(Fore.CYAN + """
███████╗ ██████╗ ██╗      ██╗      ██████╗ ██╗    ██╗  
██╔════╝██╔═══██╗██║      ██║     ██╔═══██╗██║    ██║    
█████╗  ██║   ██║██║      ██║     ██║   ██║██║ █╗ ██║  
██╔══╝  ██║   ██║██║      ██║     ██║   ██║██║███╗██║   
██║     ╚██████╔╝███████╗ ███████╗╚██████╔╝╚███╔███╔╝   
╚═╝      ╚═════╝ ╚══════╝ ╚══════╝ ╚═════╝  ╚══╝╚══╝    

[Please  /\_/\[0m
[Follow ( o.o )[0m
[Me      > ^ <[0m
[Hey   /        \[0m
[Real (  (    )  )[0m
[Cat   \__||__/[0m

██╗  ██╗███████╗██╗   ██╗██████╗ ███████╗ █████╗ ██╗     
██║  ██║██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗██║     
███████║█████╗   ╚████╔╝ ██████╔╝█████╗  ███████║██║     
██╔══██║██╔══╝    ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██║██║     
██║  ██║███████╗   ██║   ██║  ██║███████╗██║  ██║███████╗
╚═╝  ╚═╝╚══════╝   ╚═╝   ╚═╝   ╚═╝╚══════╝╚═╝ ╚═╝╚══════╝
    """)
```


## ⚙️ Setting Bot
```python
headers = {
    "accept": "*/*",
    "accept-encoding": "gzip, deflate, br, zstd",
    "accept-language": "nl,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    "basic-params": '{"buildVersion":"1","deviceId":"Mozilla50WindowsNT100Win64x64AppleWebKit53736KHTMLlikeGeckoChrome130000Safari53736Edg130000","lang":"nl","deviceName":"Netscape","os":"Windows","osVersion":"","platform":"web"}',
    "content-length": "30",
    "content-type": "application/json",
    "origin": "https://heyreal.ai",
    "priority": "u=1, i",
    "referer": "https://heyreal.ai/",
    "sec-ch-ua": '"Chromium";v="130", "Microsoft Edge";v="130", "Not?A_Brand";v="99"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "traceid": "4QhUJipSkh8IePSanejixoxVT630Hz4i",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0"
}
```
Aku tidak bisa membuka langsung tautan GitHub yang kamu berikan, tapi tidak apa—kamu bisa salin isi atau jelaskan struktur project-nya (misalnya: file utama Python apa, apakah pakai `requirements.txt`, dll).

Namun, umumnya untuk **menjalankan project GitHub di Termux** seperti `Followers-HeyReal`, berikut langkah-langkah standarnya:

---

### 🧠 Panduan Umum Menjalankan Project di Termux

1. **Update dan install dependency dasar**

   ```bash
   pkg update && pkg upgrade -y
   pkg install python git -y
   ```

2. **Clone repository**

   ```bash
   git clone https://github.com/Royhtml/Followers-HeyReal
   cd Followers-HeyReal
   ```

3. **Cek isi folder**

   ```bash
   ls
   ```

   Biasanya kamu akan lihat file seperti `hey.py`, `requirements.txt`, atau sejenis.

4. **Jika ada file `requirements.txt`, install library**

   ```bash
   pip install -r requirements.txt
   ```

5. **Jalankan script utama**
   Biasanya:

   ```bash
   python hey.py
   ```

   atau kalau nama filenya beda, sesuaikan:

   ```bash
   python FollowersHeyReal.py
   ```

6. **(Opsional)** Jika script butuh login/token:

   * Baca file `README.md` di repo-nya.
   * Pastikan kamu sudah punya credential/token yang diperlukan.

---

## 🔒 Keamanan & Anonimitas
**Rekomendasi:** Gunakan VPN untuk meningkatkan keamanan dan anonimitas
**Fitur Proxy:** Support proxy akan ditambahkan pada update mendatang

## 🎯 Target Platform
https://heyreal.ai/ - Bot follow otomatis

## 📊 Roadmap & Future Updates

### ⭐ 5 Bintang
- Generator token otomatis (saat ini gunakan token yang sama)

### ⭐⭐ 10 Bintang 
- Full proxy support
- Enhanced features
- Improved performance
- Dan banyak fitur lainnya

## 👨‍💻 Informasi Developer
**Nama:** Dwi Bakti N. Dev  
**Spesialisasi:** Automation Tools Development  

## ⚠️ Disclaimer
Tool ini dibuat untuk tujuan edukasi dan pengembangan. Pengguna bertanggung jawab penuh atas penggunaan tool ini. Disarankan untuk selalu mematuhi Terms of Service platform yang dituju.

---
**Catatan:** Star repository ini untuk mendukung pengembangan lebih lanjut! fr fr 🔥