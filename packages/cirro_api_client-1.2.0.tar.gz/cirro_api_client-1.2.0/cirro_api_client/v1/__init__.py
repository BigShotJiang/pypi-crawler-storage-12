"""A client library for accessing Cirro Data"""

from .client import Client

__all__ = ("Client",)
