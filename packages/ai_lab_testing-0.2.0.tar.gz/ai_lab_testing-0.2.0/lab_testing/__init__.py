"""
Lab Testing MCP Server Package

Copyright (C) 2025 Dynamic Devices Ltd
License: GPL-3.0-or-later

Maintainer: Alex J Lennon <ajlennon@dynamicdevices.co.uk>
"""

from lab_testing.version import __version__

__all__ = ["__version__"]
