# pymb/__init__.py

"""
pymb: A Python framework for simulating Mini-Brain (Brain Organoid) intelligence and dynamics.
"""

__version__ = "0.0.1"