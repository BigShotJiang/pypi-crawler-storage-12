# pymb

**A Python framework for simulating Mini-Brain (Brain Organoid) intelligence and dynamics.**

*This project is currently under active development. This package is a placeholder to reserve the name on PyPI.*

**Coming Soon: A full-featured simulator for Organoid Intelligence research.**

- **Documentation:** (Link to be added)
- **Source Code:** (Link to be added)