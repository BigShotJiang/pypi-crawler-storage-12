# Copyright (c) Microsoft. All rights reserved.

"""API endpoints for AG-UI examples."""
