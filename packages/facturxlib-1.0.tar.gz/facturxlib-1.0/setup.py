"""
setup.py

use declarative information from setup.cfg
instead of programming logic here.
"""

from setuptools import setup

setup()
