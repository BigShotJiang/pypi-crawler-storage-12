# Parser

::: virtual_tiff.VirtualTIFF
    handler: python
    options:
      members:
        - __init__
        - __call__
    show_source: true
