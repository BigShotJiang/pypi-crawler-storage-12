Replace sequence by priority in order to prioritize easily BoMs.
Priority is used to bring up the most important BoMs, the others being classified as by default.
This priority will be used to select the right BoM during manufacturing (thus replacing the sequence).

.. figure:: ../static/description/mrp_bom_view_form.jpeg
.. figure:: ../static/description/mrp_bom_view_tree.jpeg
