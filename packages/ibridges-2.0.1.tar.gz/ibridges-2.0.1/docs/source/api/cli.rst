Reference
=========

.. argparse::
    :module: ibridges.cli.__main__
    :func: create_parser
    :prog: ibridges
    :noepilog:
