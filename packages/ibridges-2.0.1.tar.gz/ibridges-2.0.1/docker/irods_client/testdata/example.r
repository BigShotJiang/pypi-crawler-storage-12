example{
    writeLine("stderr", "Test output for errors.");
    writeLine("stdout", "Input for this rule: *in");
}

input *in="This is a string or a path or etc"
output ruleExecOut
