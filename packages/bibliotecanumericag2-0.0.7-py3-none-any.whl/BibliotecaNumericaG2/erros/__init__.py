from .erro_relativo import erro_relativo
from .erro_absoluto import erro_absoluto

__all__ = ["erro_relativo", "erro_absoluto"]