.. _algorithms-examples-gallery:

Algorithms
----------
