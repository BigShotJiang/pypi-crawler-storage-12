"""
tests of core functionality of ctapipe
"""
