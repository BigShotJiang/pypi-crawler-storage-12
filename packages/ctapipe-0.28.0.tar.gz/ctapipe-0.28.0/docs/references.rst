.. _Astropy: https://astropy.org
.. _skyfield: https://rhodesmill.org/skyfield/
.. _pyephem: https://rhodesmill.org/pyephem/
