collect_ignore = [
    "conf.py",
    "_build",
    "auto_examples",
    "api-reference/instrument/camerageometry_example.py",
    "api-reference/coordinates/plot_camera_frames.py",
]
