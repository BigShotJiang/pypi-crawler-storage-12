.. Include rendered examples build with sphinx-gallery
.. Actual files are in the examples/ directory in the
.. base of the repository

.. include:: ../auto_examples/index.rst
