.. _visualization_bokeh:

**********************************************************
Bokeh-based visualization (`~ctapipe.visualization.bokeh`)
**********************************************************

.. currentmodule:: ctapipe.visualization.bokeh


Reference/API
=============

.. automodapi:: ctapipe.visualization.bokeh
    :no-inheritance-diagram:
