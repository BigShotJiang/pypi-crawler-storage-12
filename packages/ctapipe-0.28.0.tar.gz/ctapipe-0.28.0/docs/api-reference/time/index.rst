.. _time:

**********************
time (`~ctapipe.time`)
**********************

.. currentmodule:: ctapipe.time


Reference/API
=============

.. automodapi:: ctapipe.time
    :no-inheritance-diagram:
