.. _traits:

************************************
Traitlet Implementations for ctapipe
************************************

.. currentmodule:: ctapipe.core.traits


Introduction
============

Custom Traitlets implemented for ctapipe.


Reference/API
=============

.. automodapi:: ctapipe.core.traits
    :include-all-objects:
    :no-inheritance-diagram:
