.. _image_cleaning:

**************
Image Cleaning
**************

Cleaning/denoising of images (tailcuts cleaning, dilation,
filtering).

An example of image cleaning and dilation:

.. image:: ./dilate.png


API Reference
=============

.. automodapi:: ctapipe.image.cleaning
