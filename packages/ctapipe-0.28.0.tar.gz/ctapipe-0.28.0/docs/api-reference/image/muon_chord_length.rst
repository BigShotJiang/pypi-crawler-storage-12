.. _chord_length:


.. currentmodule:: ctapipe.image.muon.intensity_fitter

************
chord_length
************

.. autofunction:: ctapipe.image.muon.intensity_fitter.chord_length
