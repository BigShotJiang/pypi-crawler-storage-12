.. _image_hillas:

***********************
Hillas Parameterization
***********************


Reference/API
=============

.. automodapi:: ctapipe.image.hillas
