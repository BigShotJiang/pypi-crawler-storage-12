.. _image_toymodel:

**************************
Toy Model Image Generation
**************************

Fake shower image generation for testing purposes.


Reference/API
=============

.. automodapi:: ctapipe.image.toymodel
