.. _image_reducers:

**********************
Image Volume Reduction
**********************

Algorithms for reducing image size via volume selection and other methods.


Reference/API
=============

.. automodapi:: ctapipe.image.reducer
