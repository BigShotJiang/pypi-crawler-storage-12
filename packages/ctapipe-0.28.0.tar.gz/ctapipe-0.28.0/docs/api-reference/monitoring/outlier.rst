.. _outlier_detector:

****************
Outlier Detector
****************


Reference/API
=============

.. automodapi:: ctapipe.monitoring.outlier
