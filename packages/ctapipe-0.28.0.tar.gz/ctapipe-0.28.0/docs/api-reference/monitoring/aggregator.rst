.. _stats_aggregator:

*********************
Statistics Aggregator
*********************


Reference/API
=============

.. automodapi:: ctapipe.monitoring.aggregator
