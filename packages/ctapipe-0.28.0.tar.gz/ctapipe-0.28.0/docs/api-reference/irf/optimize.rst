.. _cut_optimization:

********************************
G/H (and Theta) Cut Optimization
********************************


Reference/ API
==============

.. automodapi:: ctapipe.irf.optimize
    :no-inheritance-diagram:
