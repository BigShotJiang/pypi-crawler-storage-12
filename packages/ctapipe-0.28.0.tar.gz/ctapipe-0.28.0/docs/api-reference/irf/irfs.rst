.. _irfs:

**************
IRF components
**************


Reference/ API
==============

.. automodapi:: ctapipe.irf.irfs
    :no-inheritance-diagram:
