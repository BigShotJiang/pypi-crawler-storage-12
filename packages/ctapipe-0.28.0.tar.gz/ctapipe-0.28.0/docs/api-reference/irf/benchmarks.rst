.. _benchmarks:

**********
Benchmarks
**********


Reference/ API
==============

.. automodapi:: ctapipe.irf.benchmarks
    :no-inheritance-diagram:
