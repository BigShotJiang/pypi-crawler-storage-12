.. _spectra:

*************************************
Spectra definitions for event weights
*************************************


Reference/ API
==============

.. automodapi:: ctapipe.irf.spectra
    :no-inheritance-diagram:
