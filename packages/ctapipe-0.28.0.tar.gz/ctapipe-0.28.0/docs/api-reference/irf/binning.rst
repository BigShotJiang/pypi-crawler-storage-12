.. _binning:

*******
Binning
*******


Reference/ API
==============

.. automodapi:: ctapipe.irf.binning
    :no-inheritance-diagram:
