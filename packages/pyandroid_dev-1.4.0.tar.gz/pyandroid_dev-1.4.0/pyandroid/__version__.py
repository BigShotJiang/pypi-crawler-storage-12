"""Version information for PyAndroid."""

__version__ = "1.3.0"
__author__ = "Subhobhai"
__license__ = "PyAndroid Custom License v1.0"
__copyright__ = "Copyright 2025 Subhobhai"
