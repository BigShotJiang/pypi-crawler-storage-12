from enum import Enum

class ProductTools(str, Enum):
    PRODUCT_SEARCH = "product_search_and_recommend"