<img src="https://raw.githubusercontent.com/lucabaldini/aptapy/main/docs/_static/logo.png" alt="aptapy logo" width="175"/>

[![PyPI](https://img.shields.io/pypi/v/aptapy.svg)](https://pypi.org/project/aptapy/)
![Python versions](https://img.shields.io/badge/python-3.7--3.13-blue)
![License](https://img.shields.io/github/license/lucabaldini/aptapy.svg)
[![CI](https://github.com/lucabaldini/aptapy/actions/workflows/ci.yml/badge.svg)](https://github.com/lucabaldini/aptapy/actions/workflows/ci.yml)
[![Docs](https://github.com/lucabaldini/aptapy/actions/workflows/docs.yml/badge.svg)](https://github.com/lucabaldini/aptapy/actions/workflows/docs.yml)
![GitHub last commit](https://img.shields.io/github/last-commit/lucabaldini/aptapy)

[![Ceasefire Now](https://badge.techforpalestine.org/default)](https://techforpalestine.org/learn-more)

Statistical tools for online monitoring and analysis.
[Read more](https://lucabaldini.github.io/aptapy/).