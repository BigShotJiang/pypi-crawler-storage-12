"""命令行入口."""

from .cli import main

if __name__ == "__main__":
    main()
