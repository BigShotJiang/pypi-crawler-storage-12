class Sample:

    def __init__(self, input_text, output_text):
        self.input_text = input_text
        self.output_text = output_text

    def get_output(self):
        return self.output_text

    def get_input(self):
        return self.input_text
