from atcodertools.release_management.version import __version__  # noqa
