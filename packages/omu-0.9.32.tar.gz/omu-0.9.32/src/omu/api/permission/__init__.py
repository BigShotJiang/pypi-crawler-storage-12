from .permission import PermissionType

__all__ = [
    "PermissionType",
]
