Changelog
=========


1.0.0 (2024-11-05)
------------------
- Release: version 1.0.0