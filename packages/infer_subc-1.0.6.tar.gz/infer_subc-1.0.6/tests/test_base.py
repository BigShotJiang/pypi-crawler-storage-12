from infer_subc.bioim.base import NAME


def test_base():
    assert NAME == "infer_subc"
