# # from .bioim.base import *
# # from .image import BioImImage
# # from .bioim.object import BioImObject
# # from .transforms.transform import BioImTransform
# # from .transforms.pipeline import BioImPipeline


# # __all__ = [
# # ]

# from .bioim.image import BioImImage
# from .bioim.object import BioImObject
# from .transforms.transform import BioImTransform
# from .transforms.pipeline import BioImPipeline

# # from .utils.img import *
# # from .utils.file_io import *
# # from .organelles import *

# -*- coding: utf-8 -*-

"""Top-level package for infer_subc."""

__author__ = "Andy Henrie"
__email__ = "ergonyc@gmail.com"
# Do not edit this string manually, always use bumpversion
# Details in CONTRIBUTING.md
__version__ = "0.0.1"


def get_module_version():
    return __version__
