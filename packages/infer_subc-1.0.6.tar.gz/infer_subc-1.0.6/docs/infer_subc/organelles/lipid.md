# infer_subc/organelles/lipid

::: infer_subc.organelles.lipid
