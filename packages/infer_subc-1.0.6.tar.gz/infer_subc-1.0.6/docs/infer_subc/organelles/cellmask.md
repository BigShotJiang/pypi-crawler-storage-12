# infer_subc/organelles/cellmask

Routines for inference of ***cellmask*** for masking later organell segmentation steps.
  
::: infer_subc.organelles.cellmask