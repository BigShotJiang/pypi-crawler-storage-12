# infer_subc/organelles/lysosome

::: infer_subc.organelles.lysosome
