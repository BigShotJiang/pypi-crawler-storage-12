# infer_subc/organelles/peroxisome

::: infer_subc.organelles.peroxisome
