# infer_subc/organelles/cytoplasm

::: infer_subc.organelles.cytoplasm
