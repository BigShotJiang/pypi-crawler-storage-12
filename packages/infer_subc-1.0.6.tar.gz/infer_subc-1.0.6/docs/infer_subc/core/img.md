# infer_subc/core/img

Image processing functions. Most are wrappers to well known `skimage` and `scipy.ndimate` utilities as well as core routines from `aicssegmentation`

::: infer_subc.core.img
