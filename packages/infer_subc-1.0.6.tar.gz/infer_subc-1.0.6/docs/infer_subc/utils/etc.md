# infer_subc/utils

Also there are 'util/directories.py', 'util/filesystempy', 'util/lazy.py', and a hack from `aicsimageio` 'util/_aicsimage_reader.py'

In the base module there are also 'constants.py' and 'exceptions.py'