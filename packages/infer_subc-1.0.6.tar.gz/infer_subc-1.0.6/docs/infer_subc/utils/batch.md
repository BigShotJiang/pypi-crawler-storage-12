# infer_subc/utils

functions which help with processing batches of files

::: infer_subc.utils.batch