Patent Data Examples
====================

.. literalinclude:: ../../examples/patent_data_example.py
   :language: python
   :linenos:
