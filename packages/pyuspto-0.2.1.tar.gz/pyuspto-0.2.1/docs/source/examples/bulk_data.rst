Bulk Data Examples
==================

.. literalinclude:: ../../examples/bulk_data_example.py
   :language: python
   :linenos:
