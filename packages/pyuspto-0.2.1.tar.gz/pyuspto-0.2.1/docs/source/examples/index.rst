Examples
========

.. toctree::
   :maxdepth: 2

   bulk_data
   patent_data
