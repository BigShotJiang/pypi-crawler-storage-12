Models
======

.. automodule:: pyUSPTO.models.bulk_data
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pyUSPTO.models.patent_data
   :members:
   :undoc-members:
   :show-inheritance:
