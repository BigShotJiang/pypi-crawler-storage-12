#  Copyright (c) 2022 Russell Smiley
#
#  This file is part of click_logging_config.

"""Quick and easy logging parameters for click commands."""
