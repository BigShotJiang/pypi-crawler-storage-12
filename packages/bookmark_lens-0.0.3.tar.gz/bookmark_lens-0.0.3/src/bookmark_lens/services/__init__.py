"""Core services for content fetching, embeddings, and search."""
