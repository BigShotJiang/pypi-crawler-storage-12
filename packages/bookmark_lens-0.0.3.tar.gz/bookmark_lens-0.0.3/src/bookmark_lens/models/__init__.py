"""Pydantic data models for type-safe validation."""
