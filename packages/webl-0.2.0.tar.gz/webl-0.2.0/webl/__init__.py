"""
webl - Command-line tool for domain intelligence
"""
__version__ = "0.1.0"
