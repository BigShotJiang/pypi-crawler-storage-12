from zimscraperlib import constants


def test_name():
    assert constants.NAME


def test_scraper():
    assert constants.SCRAPER


def test_version():
    assert constants.VERSION
