
This folder contains some tooling around zimscraperlib:
- `encode_video.py`: a small utility to encode a video with an existing video preset, just like a scraper would do
