export default [
  {
    rules: {
      'prefer-const': 'error',
    },
  },
];
