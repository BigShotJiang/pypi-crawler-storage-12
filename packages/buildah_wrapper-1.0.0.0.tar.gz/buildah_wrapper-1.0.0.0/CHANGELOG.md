# Changelog
* `1.0.0.0`: 
    * 1.0 release!
	* fixed Logic
	* bugfixes
* `0.0.0.8`: 
    * squash added as optional
* `0.0.0.7`: 
    * logs updated
    * squash disabled
* `0.0.0.6`: 
    * added `--squash`
* `0.0.0.5`: 
    * added `--networl=host`
* `0.0.0.4`:
    * added `--cap-add=ALL`
* `0.0.0.3`:
    * isolation fix
* `0.0.0.2`:
    * Logic fix
* `0.0.0.1`:
    * First release
    