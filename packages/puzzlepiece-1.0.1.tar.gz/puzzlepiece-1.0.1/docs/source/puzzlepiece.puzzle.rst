puzzlepiece.puzzle module
=========================

.. automodule:: puzzlepiece.puzzle
   :members:
   :undoc-members:
   :show-inheritance:
