API
===========

.. toctree::
   :maxdepth: 2

   puzzlepiece
   puzzlepiece.puzzle
   puzzlepiece.piece
   puzzlepiece.param
   puzzlepiece.action
   puzzlepiece.parse
   puzzlepiece.threads
   puzzlepiece.extras
