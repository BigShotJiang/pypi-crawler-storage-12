"""
This sub-module contains some features that extend the base functionality of puzzlepiece.
"""
