"""
This folder contains some example Piece implementations
"""
