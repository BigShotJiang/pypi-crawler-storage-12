from .settings import set_rules

__all__ = ["config", "set_rules"]
