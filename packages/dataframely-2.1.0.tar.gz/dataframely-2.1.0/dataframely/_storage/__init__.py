# Copyright (c) QuantCo 2025-2025
# SPDX-License-Identifier: BSD-3-Clause

from ._base import StorageBackend

__all__ = [
    "StorageBackend",
]
