# Features

```{toctree}
:maxdepth: 1

column-metadata
data-generation
primary-keys
serialization
sql-generation
lazy-validation
```
