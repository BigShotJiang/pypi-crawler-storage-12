============
FilterResult
============

.. currentmodule:: dataframely
.. autosummary::
    :toctree: _gen/
    :template: classes/filter_result.rst
    :nosignatures:

    ~filter_result.FilterResult
    ~filter_result.LazyFilterResult
    ~collection.CollectionFilterResult

.. toctree::
    :hidden:
    :maxdepth: 2

    failure_info
