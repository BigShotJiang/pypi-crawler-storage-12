==========
Validation
==========

.. currentmodule:: dataframely
.. autosummary::
    :toctree: _gen/

    Schema.validate
    Schema.filter
    Schema.is_valid
    Schema.cast
    rule
