:html_theme.sidebar_secondary.remove: true

.. role:: hidden

{{ name | underline }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ name }}
    :members:
    :exclude-members: add_note, with_traceback
    :autosummary:
    :autosummary-nosignatures:
