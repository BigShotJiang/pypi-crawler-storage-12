from castlecraft_engineer.commands.entrypoint import main

__all__ = ["main"]
