"""Configuration presets used by the REVISE package."""

