"""
Timer Cog - Discord bot extension for aa-structuretimers
"""

__version__ = "0.0.3"
__title__ = "Timer Cog"

default_app_config = "timercog.apps.TimerCogConfig"
