"""LangExtract provider plugin for LlamaCpp."""

from langextract_llamacpp.provider import LlamaCppLanguageModel

__all__ = ["LlamaCppLanguageModel"]
__version__ = "0.1.0"
