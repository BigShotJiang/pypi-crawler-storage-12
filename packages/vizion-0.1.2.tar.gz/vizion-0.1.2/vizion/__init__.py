from .vizion import Vizion

quick_summary = Vizion.quick_summary
missing_value_summary = Vizion.missing_value_summary
get_column_types = Vizion.get_column_types
handle_outliers = Vizion.handle_outliers
plot_numeric_eda = Vizion.plot_numeric_eda
handle_missing = Vizion.handle_missing
plot_categorical_eda = Vizion.plot_categorical_eda
help_steps = Vizion.help_steps
generate_doc = Vizion.generate_doc

__all__ = [
    "Vizion",
    "quick_summary",
    "missing_value_summary",
    "get_column_types",
    "handle_outliers",
    "plot_numeric_eda",
    "handle_missing",
    "plot_categorical_eda",
    "help_steps",
    "generate_doc",
]
