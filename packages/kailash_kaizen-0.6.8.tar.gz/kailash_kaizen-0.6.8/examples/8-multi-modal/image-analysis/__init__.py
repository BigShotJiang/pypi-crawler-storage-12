"""Image Analysis Example - Vision processing with Ollama."""
