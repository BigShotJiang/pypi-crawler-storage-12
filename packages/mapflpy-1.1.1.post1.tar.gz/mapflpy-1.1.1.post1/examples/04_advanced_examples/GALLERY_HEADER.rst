Advanced Examples
=================

This final section is aimed at exploring more involved visualization approaches using *e.g.* interdomain tracing and
fieldline polarity filtering. The accompanying utility functions (*i.e.* :mod:`~mapflpy.utils`) will be catalogued
here in future releases of the **mapflpy** documentation.