Examples
========

Below you will find a series of examples demonstrating how to use ``mapflpy`` for various basic use cases.

.. toctree::
   :hidden:

   01_getting_started/index
   02_using_tracer_class/index
   03_using_tracermp_class/index
   04_advanced_examples/index
