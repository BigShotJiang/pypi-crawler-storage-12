API Reference
=============

.. autosummary::
   :toctree: ../autodoc/api
   :template: autosummary/package.rst

   mapflpy

