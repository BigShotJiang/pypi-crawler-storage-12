{{ fullname }}
{{ underline }}

.. autoproperty:: {{ fullname }}