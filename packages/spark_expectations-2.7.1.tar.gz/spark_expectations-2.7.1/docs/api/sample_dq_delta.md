
::: examples.scripts.sample_dq_delta
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"
        