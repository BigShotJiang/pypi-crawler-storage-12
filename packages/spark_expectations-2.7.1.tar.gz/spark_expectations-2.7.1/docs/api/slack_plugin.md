---
search:
  exclude: true
---

::: spark_expectations.notifications.plugins.slack
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"