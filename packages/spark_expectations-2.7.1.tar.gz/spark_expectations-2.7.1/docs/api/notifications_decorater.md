---
search:
  exclude: true
---

::: spark_expectations.notifications.push.spark_expectations_notify
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"