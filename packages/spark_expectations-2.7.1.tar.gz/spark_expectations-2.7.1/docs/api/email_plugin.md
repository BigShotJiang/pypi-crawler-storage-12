---
search:
  exclude: true
---

::: spark_expectations.notifications.plugins.email
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"