from .trustspecpy import *

__doc__ = trustspecpy.__doc__
if hasattr(trustspecpy, "__all__"):
    __all__ = trustspecpy.__all__