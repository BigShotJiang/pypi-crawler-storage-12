from .core import analyze_emotion
