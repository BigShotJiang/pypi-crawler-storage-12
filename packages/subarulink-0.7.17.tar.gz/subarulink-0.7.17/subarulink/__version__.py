#  SPDX-License-Identifier: Apache-2.0
"""
subarulink - A Python package for interacting with the MySubaru Connected Services API.

For more details about this api, please refer to the documentation at
https://github.com/G-Two/subarulink
"""
__version__ = "0.7.17"
