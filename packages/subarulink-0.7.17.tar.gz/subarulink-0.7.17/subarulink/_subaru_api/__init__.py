#  SPDX-License-Identifier: Apache-2.0
"""
Constants used by subarulink to interact with the MySubaru Connected Services HTTP API.

This is an undocumented API derived from analysis of the MySubaru Android app v3.0.1
"""
