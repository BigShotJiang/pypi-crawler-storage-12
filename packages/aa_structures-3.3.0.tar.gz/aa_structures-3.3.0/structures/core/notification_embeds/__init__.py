"""Generating notification embeds for Structures."""

from .main import NotificationBaseEmbed

__all__ = ["NotificationBaseEmbed"]
