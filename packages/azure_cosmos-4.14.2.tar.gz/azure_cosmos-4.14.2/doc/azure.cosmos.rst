azure.cosmos package
====================

.. automodule:: azure.cosmos
   :members:
   :undoc-members:
   :inherited-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   azure.cosmos.aio

Submodules
----------

azure.cosmos.exceptions module
------------------------------

.. automodule:: azure.cosmos.exceptions
   :members:
   :undoc-members:
   :inherited-members:
