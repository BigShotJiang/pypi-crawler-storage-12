"""Main entry point for running the package as a module."""

from .server import main

if __name__ == "__main__":
    main()
