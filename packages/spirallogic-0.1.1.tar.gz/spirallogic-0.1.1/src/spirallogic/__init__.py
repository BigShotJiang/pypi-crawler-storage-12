"""SpiralLogic runtime package."""

__all__ = ['spirallogic_runtime', 'spirallogic_cli']
__version__ = "0.1.1"
