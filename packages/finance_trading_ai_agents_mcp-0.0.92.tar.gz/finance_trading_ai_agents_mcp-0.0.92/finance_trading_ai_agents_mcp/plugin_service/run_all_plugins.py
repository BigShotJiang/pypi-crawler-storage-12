from finance_trading_ai_agents_mcp.plugin_service.broker_operation import auto_run_brokers


def run_all_plugin():
    auto_run_brokers()