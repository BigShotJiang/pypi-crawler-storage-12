from finance_trading_ai_agents_mcp.mcp_result_control.control_mixin import ControlMixin


class CommonControl(ControlMixin):
    pass