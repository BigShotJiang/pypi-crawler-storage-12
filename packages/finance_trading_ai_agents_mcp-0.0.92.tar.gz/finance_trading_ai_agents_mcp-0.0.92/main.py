from finance_trading_ai_agents_mcp import mcp_run
if __name__ == "__main__":
    mcp_run()