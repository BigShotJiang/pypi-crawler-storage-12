render = 'JSON'
source = 'national'

# DZ/T/2011/001877
appnum_mask = 'DZ/T/\\d{4}/(\\d*)'

# 1/093368
# T88988
regnum_mask = [ '1/(\\d.*)',
                '(.*)']
