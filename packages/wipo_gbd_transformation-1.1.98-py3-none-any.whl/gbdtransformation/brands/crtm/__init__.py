render = 'JSON'
source = 'national'

# 1900-5981818
appnum_mask = '\\d+-(\\d*)'
