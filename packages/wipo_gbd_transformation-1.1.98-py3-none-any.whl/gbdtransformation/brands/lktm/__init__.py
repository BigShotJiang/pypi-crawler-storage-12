render = 'JSON'
source = 'national'

# AE/321890
appnum_mask = 'LK/T/1/(\\d*)'
