render = 'JSON'
source = 'national'

# BH/T/011818
# BH/T/1/071818
# SM/T/001872
# BH/T/1/071818
appnum_mask = [ '[A-Z]{2}/T/1/(\\d*)',
                '[A-Z]{2}/T/(\\d*)'  ]

regnum_mask = [ '1/(\\d*)',
                '(\\d*)' ]
