render = 'JSON'
source = 'national'

# SM/M/2004/000064
# SM/M/1/000064
appnum_mask = 'SM/M/\\d{1,4}/(\\d*)'
