"""
Repo Flattener - A tool to convert a repository into flattened files
for easier LLM upload.
"""

__version__ = "0.1.1"
