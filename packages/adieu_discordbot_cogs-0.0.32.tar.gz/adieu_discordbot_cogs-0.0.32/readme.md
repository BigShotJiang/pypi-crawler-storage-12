ADIEU Custom Discordbot Cogs for AA DiscordBot

| Permission     | What does it do                                                                                                         | Who should get it     |
|----------------|-------------------------------------------------------------------------------------------------------------------------|-----------------------|
| force_sync     | Allows user to run /admin force_sync                                                                                    | Recruiters/Leadership |
| admin_commands | Allows user to use orphans, get_webhooks, uptime, versions, stats, force_sync, sync_commands, group_sync, nickname_sync | Non SU-IT/Leadership  |