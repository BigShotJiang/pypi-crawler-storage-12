# 作者：Xiaoqiang
# 微信公众号：XiaoqiangClub
# 创建时间：2025-11-12T00:08:14.666Z
# 文件描述：core 包的初始化文件
# 文件路径：xqcsendmessage/core/__init__.py
