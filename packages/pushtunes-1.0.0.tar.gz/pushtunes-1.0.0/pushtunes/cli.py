import typer
from pushtunes.cli.main import app

def main():
    app()

if __name__ == "__main__":
    main()