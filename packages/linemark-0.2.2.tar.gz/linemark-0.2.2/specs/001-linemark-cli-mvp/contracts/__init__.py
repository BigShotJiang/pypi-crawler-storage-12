"""Port interfaces for linemark CLI."""
