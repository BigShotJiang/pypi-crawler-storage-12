"""Test suite for linemark package."""
