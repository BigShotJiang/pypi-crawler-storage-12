"""Entry point for python -m linemark."""

from linemark.cli.main import main

if __name__ == '__main__':  # pragma: no cover
    main()
