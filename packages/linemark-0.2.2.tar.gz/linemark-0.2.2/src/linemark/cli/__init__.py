"""CLI layer: Command-line interface implementation."""

from linemark.cli.main import main

__all__ = ['main']
