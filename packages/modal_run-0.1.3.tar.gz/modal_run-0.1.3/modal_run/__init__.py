"""Modal-run CLI tool for executing Modal functions remotely."""

__version__ = "0.1.0"
