"""
pymathis

A library of interacting function to enable exchanges between MATHIS and python at each time steps


"""

__version__ = "0.1.1"
__author__ = 'Francois DEMOUGE & Xavier FAURE'
__credits__ = 'CSTB - French Institute of Building Physics'