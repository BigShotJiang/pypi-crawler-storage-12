"""Constants for LupisLabs SDK endpoints."""

DEFAULT_TRACES_ENDPOINT = "http://127.0.0.1:9009/api/traces"
