# Configuration

AVD CLI configuration is primarily done through:

1. Command-line options
2. Environment variables
3. Inventory structure

See [User Guide](commands/overview.md) for complete details.
