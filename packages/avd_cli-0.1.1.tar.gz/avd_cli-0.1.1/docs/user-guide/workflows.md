# Workflows

AVD CLI supports two main workflows.

## eos-design

Full AVD pipeline with topology design and validation.

## cli-config

Direct configuration generation from existing structured configs.

See [generate command](commands/generate.md) for details.
