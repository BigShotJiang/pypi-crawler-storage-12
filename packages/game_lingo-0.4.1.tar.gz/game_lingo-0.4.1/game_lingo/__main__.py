"""
Punto de entrada para ejecutar el módulo como script.

Permite ejecutar: python -m game_translator <comando>
"""

from .cli import main

if __name__ == "__main__":
    main()
