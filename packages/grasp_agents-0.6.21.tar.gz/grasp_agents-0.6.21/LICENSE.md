Grasp Agents itself is [MIT](https://mit-license.org/)-licensed.
