#!/bin/bash
sphinx-build -b html . _build
