Contributors
============
DAX is a multi-institution collaborative effort of the following labs:

`MASI <https://masi.vuse.vanderbilt.edu/index.php/Main_Page/>`_ at Vanderbilt University, Nashville, Tennessee, USA

`Center for Cognitive Medicine <https://www.vumc.org/ccm/>`_ at Vanderbilt University Medical Center, Nashville, Tennessee, USA

`TIG <http://cmictig.cs.ucl.ac.uk/>`_ at UCL (University College London), London, UK 

