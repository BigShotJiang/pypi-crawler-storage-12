# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .base_match import BaseMatch

__all__ = ["SimpleMatch"]


class SimpleMatch(BaseMatch):
    id: str
    """The match id"""
