# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .simple_league import SimpleLeague

__all__ = ["ExtendedLeague"]


class ExtendedLeague(SimpleLeague):
    priority: int
    """Unknown"""
