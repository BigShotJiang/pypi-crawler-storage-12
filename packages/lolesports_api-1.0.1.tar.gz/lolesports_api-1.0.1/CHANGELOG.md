# Changelog

## 1.0.1 (2025-11-15)

Full Changelog: [v1.0.0...v1.0.1](https://github.com/Atelier-Nayr/lolesports_api-python/compare/v1.0.0...v1.0.1)

## 1.0.0 (2025-11-15)

Full Changelog: [v0.0.1...v1.0.0](https://github.com/Atelier-Nayr/lolesports_api-python/compare/v0.0.1...v1.0.0)

### Chores

* update SDK settings ([a80368d](https://github.com/Atelier-Nayr/lolesports_api-python/commit/a80368de726aeced28d091d4f0eca5d31f954762))
* update SDK settings ([782ffe2](https://github.com/Atelier-Nayr/lolesports_api-python/commit/782ffe2f42fd476ebfc6e5f6747ca80ab33eee5f))
