# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from lolesports_api import LolesportsAPI, AsyncLolesportsAPI
from lolesports_api.types import DetailRetrieveResponse
from lolesports_api._utils import parse_datetime

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestDetails:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: LolesportsAPI) -> None:
        detail = client.details.retrieve(
            game_id=0,
        )
        assert_matches_type(DetailRetrieveResponse, detail, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve_with_all_params(self, client: LolesportsAPI) -> None:
        detail = client.details.retrieve(
            game_id=0,
            participant_ids="32_9_10_2_61_1_57",
            starting_time=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(DetailRetrieveResponse, detail, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: LolesportsAPI) -> None:
        response = client.details.with_raw_response.retrieve(
            game_id=0,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        detail = response.parse()
        assert_matches_type(DetailRetrieveResponse, detail, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: LolesportsAPI) -> None:
        with client.details.with_streaming_response.retrieve(
            game_id=0,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            detail = response.parse()
            assert_matches_type(DetailRetrieveResponse, detail, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncDetails:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLolesportsAPI) -> None:
        detail = await async_client.details.retrieve(
            game_id=0,
        )
        assert_matches_type(DetailRetrieveResponse, detail, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve_with_all_params(self, async_client: AsyncLolesportsAPI) -> None:
        detail = await async_client.details.retrieve(
            game_id=0,
            participant_ids="32_9_10_2_61_1_57",
            starting_time=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(DetailRetrieveResponse, detail, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLolesportsAPI) -> None:
        response = await async_client.details.with_raw_response.retrieve(
            game_id=0,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        detail = await response.parse()
        assert_matches_type(DetailRetrieveResponse, detail, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLolesportsAPI) -> None:
        async with async_client.details.with_streaming_response.retrieve(
            game_id=0,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            detail = await response.parse()
            assert_matches_type(DetailRetrieveResponse, detail, path=["response"])

        assert cast(Any, response.is_closed) is True
