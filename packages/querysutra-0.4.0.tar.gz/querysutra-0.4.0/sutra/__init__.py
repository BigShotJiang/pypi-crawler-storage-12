"""
QuerySUTRA - Structured-Unstructured-Text-Retrieval-Architecture
v0.3.4 - Proper relational database with unique IDs
"""

__version__ = "0.3.4"

from sutra.sutra import SUTRA, QueryResult, quick_start

__all__ = ["SUTRA", "QueryResult", "quick_start"]
