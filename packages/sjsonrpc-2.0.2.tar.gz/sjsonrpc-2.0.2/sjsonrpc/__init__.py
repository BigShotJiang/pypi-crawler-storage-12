'''
Created on 20241001
Update on 20251114
@author: Eduardo Pagotto
'''

__json_rpc_version__ : str = '2.0'
__version__ : str = "2.0.2"
