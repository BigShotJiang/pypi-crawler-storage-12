if __name__ == "__main__":
    import sys
    from .__init__ import main
    sys.exit(main())
