from __future__ import annotations

import apluggy as pluggy

hookspec = pluggy.HookspecMarker("PlexTraktSync")
hookimpl = pluggy.HookimplMarker("PlexTraktSync")
