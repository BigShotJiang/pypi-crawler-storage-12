# Changelog

## 0.1.4

- Bump Python version required to Python 3.7
- Update README
- Remove deprecated and unnecessary TOML

## 0.1.0 - initial release
- Package the `bin2elf` CLI.
- Endianness selection (`--endian little|big`).
- Accept decimal or hex load address.
- Optional `--prefix` for non-default toolchains.
