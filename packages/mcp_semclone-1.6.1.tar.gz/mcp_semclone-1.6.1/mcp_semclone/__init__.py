"""MCP SEMCL.ONE - Model Context Protocol server for OSS compliance."""

__version__ = "1.6.1"
__author__ = "Oscar Valenzuela B."
__email__ = "oscar.valenzuela.b@gmail.com"