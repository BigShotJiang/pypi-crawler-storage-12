"""
Core components for Distillery.

Data models, connectors, analyzers, filters, and converters.
"""

__version__ = "0.1.0"
