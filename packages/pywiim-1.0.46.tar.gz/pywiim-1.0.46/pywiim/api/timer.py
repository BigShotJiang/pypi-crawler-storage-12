"""Timer and alarm helpers for WiiM HTTP client.

Timer and alarm features are supported by WiiM and Arylic devices via HTTP API.
This module provides methods for managing device timers and alarms.

Note: API endpoints need to be discovered and documented. The structure is ready
for implementation when endpoints are identified.
"""

from __future__ import annotations

import logging
from typing import Any

_LOGGER = logging.getLogger(__name__)


class TimerAPI:
    """Timer and alarm helpers.

    This mixin provides methods for managing device timers and alarms.

    Supported by: WiiM and Arylic devices via HTTP API.

    Note: Specific API endpoints need to be documented. The structure is ready
    for implementation when endpoints are identified.
    """

    async def get_alarms(self) -> list[dict[str, Any]]:
        """Get list of configured alarms.

        Returns:
            List of alarm dictionaries (structure TBD when endpoints discovered).

        Raises:
            WiiMError: If the request fails or alarms are not supported.

        Note:
            This is a placeholder method. Actual implementation requires
            discovery of the alarm API endpoints.
        """
        _LOGGER.warning(
            "Timer/alarm API endpoints not yet discovered. "
            "Alarm features exist in WiiM Home app but may not be exposed via HTTP API."
        )
        raise NotImplementedError(
            "Alarm API endpoints not yet discovered. " "If you find alarm endpoints, please contribute them!"
        )

    async def set_alarm(
        self,
        time: str,
        enabled: bool = True,
        source: str | None = None,
        volume: int | None = None,
    ) -> None:
        """Set or configure an alarm.

        Args:
            time: Alarm time (format TBD - likely "HH:MM" or timestamp)
            enabled: Whether alarm is enabled
            source: Audio source to play (optional)
            volume: Volume level for alarm (optional)

        Raises:
            NotImplementedError: Alarm endpoints not yet discovered.
            WiiMError: If the request fails.

        Note:
            This is a placeholder method. Actual implementation requires
            discovery of the alarm API endpoints.
        """
        _LOGGER.warning(
            "Timer/alarm API endpoints not yet discovered. "
            "Alarm features exist in WiiM Home app but may not be exposed via HTTP API."
        )
        raise NotImplementedError(
            "Alarm API endpoints not yet discovered. " "If you find alarm endpoints, please contribute them!"
        )

    async def delete_alarm(self, alarm_id: int | str) -> None:
        """Delete an alarm.

        Args:
            alarm_id: Alarm identifier

        Raises:
            NotImplementedError: Alarm endpoints not yet discovered.
            WiiMError: If the request fails.

        Note:
            This is a placeholder method. Actual implementation requires
            discovery of the alarm API endpoints.
        """
        _LOGGER.warning(
            "Timer/alarm API endpoints not yet discovered. "
            "Alarm features exist in WiiM Home app but may not be exposed via HTTP API."
        )
        raise NotImplementedError(
            "Alarm API endpoints not yet discovered. " "If you find alarm endpoints, please contribute them!"
        )

    async def get_timers(self) -> list[dict[str, Any]]:
        """Get list of active timers.

        Returns:
            List of timer dictionaries (structure TBD when endpoints discovered).

        Raises:
            WiiMError: If the request fails or timers are not supported.

        Note:
            This is a placeholder method. Actual implementation requires
            discovery of the timer API endpoints.
        """
        _LOGGER.warning(
            "Timer/alarm API endpoints not yet discovered. "
            "Timer features may exist in WiiM Home app but may not be exposed via HTTP API."
        )
        raise NotImplementedError(
            "Timer API endpoints not yet discovered. " "If you find timer endpoints, please contribute them!"
        )

    async def set_timer(
        self,
        duration: int,
        action: str | None = None,
    ) -> None:
        """Set a timer.

        Args:
            duration: Timer duration in seconds
            action: Action to perform when timer expires (e.g., "stop", "pause", "mute")

        Raises:
            NotImplementedError: Timer endpoints not yet discovered.
            WiiMError: If the request fails.

        Note:
            This is a placeholder method. Actual implementation requires
            discovery of the timer API endpoints.
        """
        _LOGGER.warning(
            "Timer/alarm API endpoints not yet discovered. "
            "Timer features may exist in WiiM Home app but may not be exposed via HTTP API."
        )
        raise NotImplementedError(
            "Timer API endpoints not yet discovered. " "If you find timer endpoints, please contribute them!"
        )
