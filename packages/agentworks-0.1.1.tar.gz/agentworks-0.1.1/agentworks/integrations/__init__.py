"""Framework integrations for AgentWorks."""

