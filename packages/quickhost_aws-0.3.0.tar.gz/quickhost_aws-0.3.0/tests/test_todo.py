# for coverage report
# these are all the files we want to test
from quickhost_aws import (
    AWSNetworking,  # test_init.py
    AWSApp,
    AWSConfig,
    AWSHost,
    AWSIam,
    AWSKeypair,
    AWSSG,
    AWSResource,
)