dict_of_parts = {
    "4-ch-transceiver": "",
    "2xAA-battery-holder": "",
    "4xAA-battery-holder": "",
    "yellow-gearbox-dc-motor": "4 x 270 RPM",
    "yellow-wheels": "x 4",
    "L-1x2": "x 8",
    "nuts-bolts-spacers": "M3: ({})".format(
        " + ".join(
            [
                "10 x 6 mm bolt",
                "1 x 5 mm bolt",
                "8 x 30 mm bolt",
                "20 x nut",
                "1 x 5 mm spacer",
                "2 x 10 mm spacer",
            ]
        )
    ),
    "ni-mh-battery": "x 4",
    "plexiglass": "14 cm x 9.5 cm",
    "PCB-single-14x9_5": "",
    "mt-3608": "",
    "arduino-nano": "",
    "tb6612": "",
    "small-on-off-switch": "",
    "pin-headers": "2 x (male, 1 x 40) -> 2 x 4 + 2 x 6 + 2 x 15",
    "double-sided-tape": "",
    "electrical-tape": "",
    "micro-usb-cable": "",
}
