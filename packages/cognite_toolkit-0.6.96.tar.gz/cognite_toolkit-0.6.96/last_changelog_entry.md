## cdf 

### Improved

- [alpha] The command `cdf data upload` is now much faster for events,
files, and timeseries

## templates

No changes.