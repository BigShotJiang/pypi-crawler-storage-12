# Examples

This section contains example Functions that you can copy and adapt to your specific use case.
Remember to [register the Function](../getting_started.md#register-the-function) in the `environment.yaml` after copying it into your code base.
