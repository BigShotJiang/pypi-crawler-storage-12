from .spec1d import Spec1D

__all__ = [
    "Spec1D",
]
