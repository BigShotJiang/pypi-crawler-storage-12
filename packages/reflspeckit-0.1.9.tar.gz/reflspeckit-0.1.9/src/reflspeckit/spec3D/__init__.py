from .spec3d import Spec3D

__all__ = ["Spec3D"]
