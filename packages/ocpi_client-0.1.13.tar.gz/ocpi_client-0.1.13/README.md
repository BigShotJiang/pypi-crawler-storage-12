# OCPI Client

[OCPI](https://evroaming.org/ocpi/) client based on HTTPX, currently supporting OCPI 2.2.1.


## Usage

Here is a quick example of how to use the models to create an OCPI `Location` object.

```python
import ocpi_client

ocpi_client.put_loccation(...)
```
