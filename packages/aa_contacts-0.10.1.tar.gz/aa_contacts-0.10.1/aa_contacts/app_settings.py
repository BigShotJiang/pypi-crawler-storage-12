from app_utils.app_settings import clean_setting

TASK_JITTER = clean_setting('AA_CONTACTS_TASK_JITTER', 300)
