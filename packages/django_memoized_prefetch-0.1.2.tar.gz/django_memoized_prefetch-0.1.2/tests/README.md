# How to generate migrations

```bash
PYTHONPATH=. uv run python tests/manage.py makemigrations
```