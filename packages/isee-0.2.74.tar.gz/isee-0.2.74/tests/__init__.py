"""Test suite for isee local CLI functionality."""
