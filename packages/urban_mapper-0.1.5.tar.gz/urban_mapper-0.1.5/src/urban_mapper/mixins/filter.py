from urban_mapper.modules.filter import FilterFactory


class FilterMixin(FilterFactory):
    def __init__(self):
        super().__init__()
