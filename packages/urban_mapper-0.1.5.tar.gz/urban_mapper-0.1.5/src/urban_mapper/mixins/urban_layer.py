from urban_mapper.modules import UrbanLayerFactory


class UrbanLayerMixin(UrbanLayerFactory):
    def __init__(self):
        super().__init__()
