from urban_mapper.modules.visualiser import VisualiserFactory


class VisualMixin(VisualiserFactory):
    def __init__(self):
        super().__init__()
