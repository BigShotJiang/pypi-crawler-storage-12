from .single_aggregator_enricher import SingleAggregatorEnricher

__all__ = [
    "SingleAggregatorEnricher",
]
