let amc12a-2021-p9 = `&(nproduct (0..(7-1)) (\k. 2 EXP (2 EXP k) + 3 EXP (2 EXP k))) = int_of_num (3 EXP 128) - &(2 EXP 128)`;;
