let amc12b-2020-p6 = `!n:num. 9 <= n ==> ?x. &(x EXP 2) = real_of_int (int_of_num (FACT (n + 2)) - &(FACT (n + 1))) / &(FACT n)`;;
