let amc12b-2021-p13 = `FINITE {x | &0 < x /\ x <= &2 * pi /\ &1 - &3 * sin x + &5 * cos (&3 * x) = &0} ==> CARD {x | &0 < x /\ x <= &2 * pi /\ &1 - &3 * sin x + &5 * cos (&3 * x) = &0} = 6`;;
