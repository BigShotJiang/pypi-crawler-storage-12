let amc12-2001-p5 = `product {x | x < 10000 /\ ODD x} (\x. &x) = &(FACT 10000) / &((2 EXP 5000) * (FACT 5000))`;;
