"""
PeopleDataLabs Python Client.
"""

from .main import PDLPY


__version__ = "6.4.8"

__all__ = ["PDLPY"]
