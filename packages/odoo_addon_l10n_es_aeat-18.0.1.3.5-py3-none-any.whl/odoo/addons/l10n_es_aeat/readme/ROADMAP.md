- La configuración de exportación a BOE no se filtran ni se
  auto-selecciona por fechas de validez.
- Las partes específicas de las Diputaciones Forales no están incluidas.
