XSQLPY

pip install xsqlpy