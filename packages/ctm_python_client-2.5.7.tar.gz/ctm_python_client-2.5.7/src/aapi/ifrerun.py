
from __future__ import annotations
import attrs
import typing
import enum
from aapi.bases import AAPIObject


@attrs.define
class ActionRestart(AAPIObject):

    _type: str = attrs.field(init=False, default='Action:Restart', metadata={
                             '_aapi_repr_': 'Type', '_type_aapi_': 'Action:Restart'})
    object_name: str = attrs.field(metadata={'_aapi_name_': True})
    from_program: str = attrs.field(kw_only=True, default=None, metadata={
                                    '_aapi_repr_': 'FromProgram'})
    from_procedure: str = attrs.field(kw_only=True, default=None, metadata={
                                      '_aapi_repr_': 'FromProcedure'})
    to_program: str = attrs.field(kw_only=True, default=None, metadata={
                                  '_aapi_repr_': 'ToProgram'})
    to_procedure: str = attrs.field(kw_only=True, default=None, metadata={
                                    '_aapi_repr_': 'ToProcedure'})
    confirm: bool = attrs.field(kw_only=True, default=None, metadata={
                                '_aapi_repr_': 'Confirm'})
