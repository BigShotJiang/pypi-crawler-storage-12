# DataBackfillJobStatus

Data Backfill Job Status

## Enum

* `PENDING` (value: `'Pending'`)

* `PROCESSING` (value: `'Processing'`)

* `COMPLETED` (value: `'Completed'`)

* `CANCELED` (value: `'Canceled'`)

* `FAILED` (value: `'Failed'`)

* `STOPPING` (value: `'Stopping'`)

* `STOPPED` (value: `'Stopped'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


