# CustomObjectDefinitionSchemaRelationshipCardinality

The cardinality of the relationship from this object to another object.

## Enum

* `MANYTOONE` (value: `'manyToOne'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


