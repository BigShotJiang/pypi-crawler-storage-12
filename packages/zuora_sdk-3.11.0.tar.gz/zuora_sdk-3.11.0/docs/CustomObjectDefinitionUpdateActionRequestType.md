# CustomObjectDefinitionUpdateActionRequestType

The type of the updating action on a custom object definition

## Enum

* `ADDFIELD` (value: `'addField'`)

* `DELETEFIELD` (value: `'deleteField'`)

* `UPDATEFIELD` (value: `'updateField'`)

* `UPDATEOBJECT` (value: `'updateObject'`)

* `RENAMEFIELD` (value: `'renameField'`)

* `ADDRELATIONSHIP` (value: `'addRelationship'`)

* `DELETERELATIONSHIP` (value: `'deleteRelationship'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


