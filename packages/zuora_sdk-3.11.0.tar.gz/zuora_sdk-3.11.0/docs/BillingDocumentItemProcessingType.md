# BillingDocumentItemProcessingType


## Enum

* `CHARGE` (value: `'Charge'`)

* `DISCOUNT` (value: `'Discount'`)

* `PREPAYMENT` (value: `'Prepayment'`)

* `TAX` (value: `'Tax'`)

* `ROUNDING` (value: `'Rounding'`)

* `SURCHARGE` (value: `'Surcharge'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


