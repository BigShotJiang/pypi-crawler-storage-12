"""Embedding backend implementations for Vexor."""

__all__ = ["gemini"]

