# Project Context

## Purpose
Commity is a Python-based CLI that inspects the current Git repository, summarizes staged diffs, and asks an LLM to draft high-quality commit messages. The primary goal is to help developers ship Conventional Commits (optionally with emoji) faster, in multiple languages, while keeping a deterministic workflow that still allows human confirmation before committing and pushing.

## Tech Stack
- Python 3.12 packaged with Hatch/uv for local development and PyPI distribution.
- CLI entrypoint: `argparse` + `rich` for terminal UX (panels, prompts, spinners, Markdown preview).
- AI helpers: custom prompt builder plus `tiktoken` for token budgeting.
- Networking: `requests` with thin client wrappers for Gemini, OpenAI, OpenRouter, and Ollama.
- Tooling: Ruff (formatter + linter), MyPy (strict-ish), pre-commit, Makefile automation.

## Project Conventions

### Code Style
- Ruff-enforced formatting, 100-character line length, double quotes, spaces for indentation.
- Prefer straightforward functions over decorators or metaprogramming; modules stay <300 lines when possible.
- Type hints on public functions; tolerate partial coverage but avoid `Any` unless talking to third-party APIs.
- Keep CLI output friendly but concise; Rich components centralize colors/emojis to avoid manual ANSI codes.

### Architecture Patterns
- Layered CLI flow:
  1. `commity.cli` parses args, loads config, orchestrates IO/prompts.
  2. `commity.config` merges args/env/config-file into `LLMConfig` and validates provider requirements.
  3. `commity.core` supplies Git diff collection plus prompt assembly.
  4. `commity.llm` hosts provider-specific clients that share a common base for retries/errors.
  5. `commity.utils.*` provides UX helpers (token counting, spinner, diff summarization).
- Dependencies point inward (CLI → config/core/utils/llm); submodules never import the CLI to keep reusability.
- Keep network code isolated per provider so adding/removing providers only touches `llm.py`.

### Testing Strategy
- Unit tests run through `pytest` (invoked via `make test` or `uv run python -m pytest`). Focus areas: prompt builder, token slicing, provider adapters.
- Static checks (`make check` = Ruff lint + format check) and `make typecheck` for MyPy ensure regressions fail early.
- Pre-commit hooks mirror CI expectations (format, lint, typing). Run `make pre-commit-run` locally before publishing.
- Manual smoke test: `uv run python -m commity --help` plus a dry-run on a repo with staged changes to verify CLI UX.

### Git Workflow
- Default branch is `main`; create short-lived feature branches named `feature/<topic>` or `fix/<topic>`.
- Commits MUST follow Conventional Commits (the tool itself helps generate them). Include emoji when opting into `--emoji`.
- Always run formatting/lint/typecheck before opening PRs; CI expects a clean `make check`.
- Release flow: tag via Hatch/uv build, publish to PyPI, then regenerate artifacts under `dist/`.

## Domain Context
- Target users are developers with active Git repositories who want AI assistance for concise, standards-compliant commit messages.
- Supports multilingual output (`--language` / `--lang`) and emoji decoration mapped to commit types.
- LLM selection is plug-and-play across Gemini, OpenAI, OpenRouter, and local Ollama; each provider can override base URL/model.
- CLI optionally auto-commits/pushes but still prompts users for confirmation to keep humans in the loop.

## Important Constraints
- Requires staged diffs; command exits gracefully if nothing is staged.
- Network-dependent providers (Gemini/OpenAI/OpenRouter) need API keys via CLI args/env/config; fail fast when missing.
- Timeout defaults to 60s; max tokens default to 3000 to balance latency and message detail.
- Subject line MUST stay within the configured limit (default 50 chars) and use lowercase type prefixes.
- Output must avoid Markdown/ANSI artifacts so `git commit -m` receives plain text only.

## External Dependencies
- LLM APIs: Google Gemini (`generativelanguage.googleapis.com`), OpenAI (`api.openai.com`), OpenRouter (`openrouter.ai`), Ollama (`localhost:11434`).
- Local tooling: Git CLI, uv, Hatch, Make (provided through repo scripts).
- Python packages: `requests`, `tiktoken`, `rich`, plus dev stack (`ruff`, `mypy`, `pre-commit`, `pytest`, `hatch`).
