## ADDED Requirements

### Requirement: Multiple suggestion requests
The CLI SHALL let users request between 1 and 5 commit message suggestions per invocation via `--suggestions <n>` (or `COMMITY_SUGGESTIONS`). The value defaults to 1 when omitted and MUST be validated before any LLM call.

#### Scenario: Generate three suggestions
- **WHEN** the user runs `commity --suggestions 3`
- **THEN** the CLI SHALL call the configured LLM once and receive at least three distinct commit message candidates
- **AND** each candidate SHALL be preserved exactly as returned (subject + body) for downstream display

### Requirement: Interactive suggestion selection
After rendering all requested suggestions, the CLI SHALL prompt the user to choose one candidate, regenerate a fresh batch, or abort without committing. The chosen candidate MUST still pass subject-length enforcement before the Git commit step.

#### Scenario: Pick a candidate to commit
- **WHEN** the CLI finishes showing suggestions
- **AND** the user types the number of a candidate
- **THEN** Commity SHALL apply subject truncation rules
- **AND** it SHALL reuse the existing commit/push workflow with the selected message

#### Scenario: Regenerate suggestions
- **WHEN** the user requests regeneration instead of selecting a candidate
- **THEN** Commity SHALL ask the LLM for a new batch using the same diff and options
- **AND** previously shown suggestions SHALL be discarded from the selection menu


