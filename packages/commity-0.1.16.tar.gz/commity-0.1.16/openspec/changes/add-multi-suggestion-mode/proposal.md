# Change: Provide multiple commit suggestions per run

## Why
Developers often want to compare more than one AI-generated subject/body before committing. Today Commity only streams a single suggestion, forcing users to re-run the CLI (and re-pay API cost) if they dislike the first draft. A built-in multi-suggestion mode reduces frustration, cuts latency, and keeps humans firmly in control of the final commit.

## What Changes
- Add a `--suggestions <n>` flag (and matching env/config key) to request 1‒5 candidates in a single invocation.
- Display suggestions as numbered, syntax-highlight-free blocks so users can skim or copy as needed.
- Provide a follow-up prompt that lets users (a) pick one to commit, (b) regenerate another batch, or (c) abort without committing.
- Reuse a single diff/token budget by asking the LLM for multiple completions to avoid repeated Git/summary work.

## Impact
- Affected specs: `commit-assistant`
- Affected code: `commity/cli.py`, `commity/config.py`, `commity/utils/prompt_organizer.py`, `commity/llm.py`, documentation (`README*.md`)


