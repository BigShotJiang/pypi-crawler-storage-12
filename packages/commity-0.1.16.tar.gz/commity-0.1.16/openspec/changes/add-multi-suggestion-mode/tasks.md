## 1. Implementation
- [ ] 1.1 Add `--suggestions / COMMITY_SUGGESTIONS` config plumbing with validation (default 1, max 5).
- [ ] 1.2 Update LLM invocation to request multiple completions without re-fetching Git diff.
- [ ] 1.3 Render numbered suggestion panels and capture the user's choice/regeneration preference.
- [ ] 1.4 Wire the chosen suggestion into the existing commit/push flow and ensure subject length enforcement still applies.

## 2. Quality
- [ ] 2.1 Unit-test the selection helper (happy path, invalid input, regenerate branch).
- [ ] 2.2 Document the flag/env/config usage in `README.md` and `README.zh.md`.
- [ ] 2.3 Add an example to `DEVELOPMENT.md` or Makefile target for manual smoke testing.


