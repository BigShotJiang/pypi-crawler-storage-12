# coding: utf-8
"""
    InputProcess.__init__.py

    Copyright (c) 2019, SAXS Team, KEK-PF
"""
