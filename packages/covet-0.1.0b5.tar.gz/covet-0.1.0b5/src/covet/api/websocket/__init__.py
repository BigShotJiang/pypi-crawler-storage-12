"""WebSocket API module."""

class WebSocketEndpoint:
    """WebSocket endpoint."""
    pass

__all__ = ["WebSocketEndpoint"]
