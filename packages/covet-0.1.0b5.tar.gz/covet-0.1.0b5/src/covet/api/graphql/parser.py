class GraphQLParser:
    """GraphQL parser."""


# Auto-generated stubs for missing exports

class parse:
    """Stub class for parse."""

    def __init__(self, *args, **kwargs):
        pass


class parse_query:
    """Stub class for parse_query."""

    def __init__(self, *args, **kwargs):
        pass


class parse_schema:
    """Stub class for parse_schema."""

    def __init__(self, *args, **kwargs):
        pass


__all__ = ["parse", "parse_query", "parse_schema"]
