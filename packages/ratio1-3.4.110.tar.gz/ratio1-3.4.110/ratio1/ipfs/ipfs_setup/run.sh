#!/bin/bash
ipfs bootstrap rm --all
ipfs daemon
