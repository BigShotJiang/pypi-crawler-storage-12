.. _API Documentation:

=================
API Documentation
=================

This is the detailed documentation of ``FunctionalityWrapper``, which
holds all the functionality you gain by ``PyTest local FTP Server``.

.. currentmodule:: pytest_localftpserver.servers

.. autosummary::
   :nosignatures:
   :toctree: api/

   FunctionalityWrapper
