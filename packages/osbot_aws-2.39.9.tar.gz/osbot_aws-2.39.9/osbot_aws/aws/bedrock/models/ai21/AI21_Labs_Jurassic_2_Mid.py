from osbot_aws.aws.bedrock.models.ai21.AI21_Labs_Jurassic_2 import AI21_Labs_Jurassic_2


class AI21_Labs_Jurassic_2_Mid(AI21_Labs_Jurassic_2):
    model_id : str = "ai21.j2-mid-v1"