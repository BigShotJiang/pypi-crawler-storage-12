from osbot_aws.aws.bedrock.models.mistral.Mistral_AI import Mistral_AI


class Mistral_AI_7b_Instruct_v0_2(Mistral_AI):
    model_id : str = "mistral.mistral-7b-instruct-v0:2"