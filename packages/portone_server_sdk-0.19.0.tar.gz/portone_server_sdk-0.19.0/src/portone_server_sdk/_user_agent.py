USER_AGENT = "v0.19.0"

__all__ = ["USER_AGENT"]
