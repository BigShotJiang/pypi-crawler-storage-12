//! Native Rust implementation of the QDLDL solver.

#[allow(clippy::module_inception)]
mod qdldl;
pub use qdldl::*;
