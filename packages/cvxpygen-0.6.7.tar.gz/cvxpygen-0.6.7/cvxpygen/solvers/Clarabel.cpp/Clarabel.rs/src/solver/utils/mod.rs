//! Internal utility functions and helpers.

pub(crate) mod atomic;
pub(crate) mod infbounds;
