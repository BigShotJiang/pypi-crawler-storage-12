//! Concrete implementations for specific problem formats.

pub mod default;
