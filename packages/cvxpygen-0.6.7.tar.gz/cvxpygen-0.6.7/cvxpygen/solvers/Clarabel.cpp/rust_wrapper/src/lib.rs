mod algebra;
mod solver;
mod core;

mod utils;