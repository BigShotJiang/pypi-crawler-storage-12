#ifndef CLARABEL_CLARABEL_TYPES_H
#define CLARABEL_CLARABEL_TYPES_H

#ifdef CLARABEL_USE_FLOAT
typedef float ClarabelFloat;
#else
typedef double ClarabelFloat;
#endif

#endif