from src.abstract_utilities import *
result = collect_filepaths("/home/flerb/Documents/pythonTools/modules/src/modules/abstract_ide/src/abstract_ide")
input(result)
