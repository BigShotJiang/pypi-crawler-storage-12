# VideoSDK Sarvam AI 

Agent Framework plugin for LLM, STT and TTS services from SarvamAI.

## Requirements

- Python 3.12+

## Installation

```bash
pip install videosdk-plugins-sarvamai
```
