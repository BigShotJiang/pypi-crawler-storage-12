#!/bin/bash
cargo run --release --bin generate_preflop_cache -- --file hu_preflop_cache.txt
