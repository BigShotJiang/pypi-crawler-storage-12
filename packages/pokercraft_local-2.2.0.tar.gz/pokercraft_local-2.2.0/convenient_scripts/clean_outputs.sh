#!/bin/bash

shopt -s globstar
rm output/**/*.csv
rm output/**/*.html
