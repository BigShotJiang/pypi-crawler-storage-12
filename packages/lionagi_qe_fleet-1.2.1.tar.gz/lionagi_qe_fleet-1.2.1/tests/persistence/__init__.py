"""Tests for persistence backends (PostgreSQL and Redis memory implementations)"""
