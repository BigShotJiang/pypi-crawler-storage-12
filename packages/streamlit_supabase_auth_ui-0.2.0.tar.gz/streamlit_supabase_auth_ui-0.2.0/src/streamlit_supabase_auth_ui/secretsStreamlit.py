from streamlit import secrets

supa_url = secrets["supa_url"]
supa_key = secrets["supa_key"]