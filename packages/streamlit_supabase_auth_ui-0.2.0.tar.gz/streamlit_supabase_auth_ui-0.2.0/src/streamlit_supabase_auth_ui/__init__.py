from streamlit_supabase_auth_ui.widgets import __login__

# Author: Astra Clelia Bertelli
# GitHub: https://github.com/AstraBert/streamlit_supabase_auth_ui