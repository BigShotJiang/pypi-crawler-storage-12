from maleo.types.misc import StrOrUUID


IdentifierValueType = StrOrUUID | str
ParameterValueType = float | str | bool | None