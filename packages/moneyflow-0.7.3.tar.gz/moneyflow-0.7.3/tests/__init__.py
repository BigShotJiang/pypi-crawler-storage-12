"""Test suite for moneyflow."""
