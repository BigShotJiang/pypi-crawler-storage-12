=========
 systemd
=========

.. automodule:: oslo_service.systemd
   :members:
   :undoc-members:
   :show-inheritance:
