# py-mysql-type

Facilitate mysql typed queries


TODO query example


TODO explain `_LIST_`