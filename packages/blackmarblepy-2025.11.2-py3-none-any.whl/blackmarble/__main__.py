"""Entry point for blackmarblepy."""

if __name__ == "__main__":  # pragma: no cover
    pass
