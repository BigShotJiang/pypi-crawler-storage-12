import Property from "./Property";

export default class MetaProperty<TSchema extends object = object> extends Property<TSchema> {}
