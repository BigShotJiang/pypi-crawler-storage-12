from matchescu.matching.config._record_linkage import AttrCmpConfig, RecordLinkageConfig


__all__ = ["AttrCmpConfig", "RecordLinkageConfig"]
