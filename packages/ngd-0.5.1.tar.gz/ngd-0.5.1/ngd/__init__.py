from .programs import print_program, program_texts

__all__ = ["print_program", "program_texts"]
__version__ = "0.5.1"