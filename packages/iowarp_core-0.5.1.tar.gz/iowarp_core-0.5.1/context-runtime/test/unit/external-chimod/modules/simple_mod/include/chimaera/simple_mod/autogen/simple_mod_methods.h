#ifndef SIMPLE_MOD_AUTOGEN_METHODS_H_
#define SIMPLE_MOD_AUTOGEN_METHODS_H_

#include <chimaera/chimaera.h>

/**
 * Auto-generated method definitions for simple_mod
 */

namespace external_test::simple_mod {

namespace Method {
}  // namespace Method

}  // namespace external_test::simple_mod

#endif  // SIMPLE_MOD_AUTOGEN_METHODS_H_
