model_data = {
    "clinicedc_tests.customer": [
        {
            "name": "The META Trial",
            "contact": "Sokoine Kivuyo",
            "address": "NIMR Tanzania",
        }
    ]
}
