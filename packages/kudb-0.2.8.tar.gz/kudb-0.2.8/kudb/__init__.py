"""
# kudb

Simple document database
"""

from .kudb import *  # noqa: F401, F403

__version__ = "0.2.8"
