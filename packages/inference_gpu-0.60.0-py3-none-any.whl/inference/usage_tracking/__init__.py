"""
Inference utilizes Roboflow's cloud services and requires telemetry during deployment.
Telemetry is automatically turned on if Roboflow API key is provided.
For more information please consult our licensing page [roboflow.com/licensing] or contact sales [roboflow.com/sales].
"""
