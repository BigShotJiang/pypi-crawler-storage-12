from inference.models.easy_ocr.easy_ocr import EasyOCR

__all__ = ["EasyOCR"]
