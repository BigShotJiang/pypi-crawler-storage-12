from .condition import create


@create()
def all() -> bool:
    return True
