"""
Output formatters for the Karma CLI.

This package provides various formatters for displaying evaluation results,
model information, dataset details, and other CLI output in beautiful formats.
"""