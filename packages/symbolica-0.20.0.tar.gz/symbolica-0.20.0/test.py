from symbolica import *


get_version()
