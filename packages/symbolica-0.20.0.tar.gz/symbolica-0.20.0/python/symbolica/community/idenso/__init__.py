"""
# Idenso

Common tensor algebra simpifications using spenso tensor notation

# Contributors
- Lucien Huber mail@lucien.ch

"""
