"""
Vakint module by Valentin Hirschi.

For questions or bug reports, visit https://github.com/alphal00p/vakint/.
"""
