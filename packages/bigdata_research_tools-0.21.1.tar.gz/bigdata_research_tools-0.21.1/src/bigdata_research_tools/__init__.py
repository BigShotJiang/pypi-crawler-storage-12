"""
Bigdata.com Research Tools
"""
from importlib.metadata import version


__version__: str = version("bigdata-research-tools")
