# A minimal base image for KServe Modelcar/sidecar

Creates an oci-layout on disk for the [minimal base image for KServe ModelCar/sidecar](https://github.com/opendatahub-io/modelcar-base-image?tab=readme-ov-file#a-minimal-base-image-for-kserve-modelcarsidecar-puposes-that-does-nothing).
