ODH_MODELCAR_BASE_IMAGE = "quay.io/opendatahub/odh-modelcar-base-image:d59dabeedfbfca18eeeb6e24ea99700b46e163dc"
EMBEDDED_OCI_LAYOUT_DIR = "embedded_oci_layout"
