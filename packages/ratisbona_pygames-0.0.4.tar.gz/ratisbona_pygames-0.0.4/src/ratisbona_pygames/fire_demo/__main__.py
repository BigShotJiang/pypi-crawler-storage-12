from ratisbona_pygames.fire_demo.fire import firedemo

def main():
    firedemo()

if __name__ == "__main__":
    firedemo()
