"""
Demo that shows a famous fire effect using Pygame.
"""

