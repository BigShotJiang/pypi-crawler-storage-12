from ratisbona_pygames.palette_demo._palette_painter import main_game_palette_demo


def main():
    main_game_palette_demo()


if __name__ == "__main__":
    main()
