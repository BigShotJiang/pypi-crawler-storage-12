"""
Demos different palettes that are available in the ratisbona_utils.simplecolors module.
"""