from ratisbona_pygames.joystick_demo._joystick_demo import joystick_demo_main


def main():
    joystick_demo_main()

if __name__ == "__main__":
    main()