from ratisbona_pygames.speedometer._speedometer import speedometer_main


def main():
    speedometer_main()

if __name__ == "__main__":
    main()
