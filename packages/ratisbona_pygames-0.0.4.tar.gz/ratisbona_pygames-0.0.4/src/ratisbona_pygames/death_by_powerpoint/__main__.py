from ratisbona_pygames.death_by_powerpoint._death_by_powerpoint import death_by_powerpoint


def main():
    death_by_powerpoint()

if __name__ == "__main__":
    main()
