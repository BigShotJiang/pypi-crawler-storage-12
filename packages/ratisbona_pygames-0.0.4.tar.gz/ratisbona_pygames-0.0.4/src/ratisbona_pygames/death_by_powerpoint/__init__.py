"""
A little psycho-game that lets you experience, that your brain just has around 7 fast registers for objects.
Guessing the number of larger sets of objects is slower, causes more strain and is more error-prone as for 7 objects.
"""
