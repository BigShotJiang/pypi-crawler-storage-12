from ._color_blindness_cli import color_blindness_cli

def main():
    color_blindness_cli()

if __name__ == "__main__":
    main()