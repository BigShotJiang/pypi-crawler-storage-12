from ratisbona_pygames.frenchvfd_display_arduino_mega import vfd_display_cli

def main():
    vfd_display_cli()

if __name__ == "__main__":
    main()