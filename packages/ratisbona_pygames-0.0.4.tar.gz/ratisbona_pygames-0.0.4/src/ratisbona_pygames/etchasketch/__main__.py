from ratisbona_pygames.etchasketch import main_game_etch_a_sketch


def main():
    main_game_etch_a_sketch()


if __name__ == "__main__":
    main()