"""
A small etch-a-sketch like drawing program.
"""

from .etch_a_sketch import main_game_etch_a_sketch, EtchASketch

__ALL__ = [
    main_game_etch_a_sketch, EtchASketch
]