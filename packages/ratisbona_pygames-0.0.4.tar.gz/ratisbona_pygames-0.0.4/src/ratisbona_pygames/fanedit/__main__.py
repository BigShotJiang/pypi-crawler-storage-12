from ratisbona_pygames.fanedit._fanedit2 import fanedit_main

def main():
    fanedit_main()

if __name__ == "__main__":
    main()
