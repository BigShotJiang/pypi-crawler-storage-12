"""
    Utility to create a cirular image for a usb-powered persistence-of-vision led-display fan.
"""