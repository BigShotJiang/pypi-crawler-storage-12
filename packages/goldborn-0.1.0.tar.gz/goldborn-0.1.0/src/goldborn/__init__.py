from .core import (
    golden_fig,
    square_fig,
    Gax,
    prepare_golden_fig,
    prepare_square_fig,
    plot_scatter,
    plot_normality,
    plot_univariate_distribution
)
