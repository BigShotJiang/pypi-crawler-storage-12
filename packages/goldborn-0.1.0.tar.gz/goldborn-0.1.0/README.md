# goldborn

A plotting library with golden ratio aesthetics, inspired by seaborn.

## Installation
pip install goldborn

## Usage
from goldborn import golden_fig
from goldborn import plot_univariate_distribution

