from .main import BaseLoggingConfig
