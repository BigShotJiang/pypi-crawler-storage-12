# pyegeria: Coco Pharmaceuticals Lab Configurations

This is an experimental package that demonstrates how we can configure the servers used in the 
Egeria Jupyter Labs [Egeria Project - Open metadata and governance for enterprises](https://egeria-project.org/guides/operations/kubernetes/charts/lab/?h=coco) 
using the new pyegeria client.

This package will evolve with planned enhancements to the Coco Pharmaceuticals Jupyter Labs.

All feedback is welcome. Please engage via our [community](http://egeria-project.org/guides/community/), 
team calls, or via github issues in this repo. If interested in contributing,
you can engage via the community or directly reach out to
[dan.wolfson\@pdr-associates.com](mailto:dan.wolfson@pdr-associates.com?subject=pyegeria).

This is a learning experience.


----
License: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/),
Copyright Contributors to the ODPi Egeria project.