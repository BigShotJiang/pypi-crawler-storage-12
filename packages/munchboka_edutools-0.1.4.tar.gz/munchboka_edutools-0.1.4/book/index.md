# munchboka-edutools demo

This mini Jupyter Book demonstrates the bundled directives.

```{tableofcontents}
```
