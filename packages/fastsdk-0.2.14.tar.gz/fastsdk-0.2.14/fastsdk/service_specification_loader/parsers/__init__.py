from .parser import parse_service_definition

__all__ = ["parse_service_definition"]
