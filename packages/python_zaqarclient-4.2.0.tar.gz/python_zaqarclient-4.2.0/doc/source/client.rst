------
Client
------

.. automodule:: zaqarclient.queues.client

.. currentmodule:: zaqarclient.queues.client


Client Object Reference
-----------------------

This is the reference documentation for all API version.

API v2.0:

.. autoclass:: zaqarclient.queues.v2.client.Client
   :members:
