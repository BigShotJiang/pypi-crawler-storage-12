Contributors
============

Contributions to the project can be seen `here <https://github.com/mind-inria/mri-nufft/graphs/contributors>`_

.. raw:: html

  <a href="https://github.com/mind-inria/mri-nufft/graphs/contributors">
     <img src="https://contrib.rocks/image?repo=mind-inria/mri-nufft" />
  </a>
