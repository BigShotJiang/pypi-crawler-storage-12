{{ objname  | escape | underline}}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

.. minigallery:: {{module}}.{{objname}}
   :add-heading: Example using ``{{objname}}``:
