.. patch-denoise documentation master file, created by
   sphinx-quickstart on Mon Jul 11 09:45:05 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README.rst



.. toctree::
   :maxdepth: 3
   :hidden:

   Getting Started <getting_started>
   Examples <generated/autoexamples/index>
   API <api>
   Explanations <explanations/index>
   

   misc/related
   misc/contributors
   misc/code_of_conduct
   misc/license
   misc/development

             
