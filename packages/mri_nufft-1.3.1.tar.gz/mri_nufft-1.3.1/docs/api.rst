API
===

.. autosummary::
   :toctree: generated/_autosummary
   :recursive:

    mrinufft.operators
    mrinufft.trajectories
    mrinufft.density
    mrinufft.io
    mrinufft.extras
    mrinufft._utils
    mrinufft._array_compat
