---
name: 🎇 Trajectory request
about: Propose a new trajectory for MRI-nufft
labels: ['trajectories', 'feature request']
title: "Add trajectory"
---

## The trajectory

> Describe the trajectory/sampling pattern, don't hesitate to add pictures. 

## References

> Add publication and/or code references.
