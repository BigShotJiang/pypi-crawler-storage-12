.. _general_examples:

Examples
========

This is a collection of examples showing how to use MRI-nufft to perform MR image reconstruction.
