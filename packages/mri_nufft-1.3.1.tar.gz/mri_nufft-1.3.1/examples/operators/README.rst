
.. _operators_examples:

Operators Examples
------------------

This is a collection of examples showcasing the use of MRI-NUFFT operators for different MR imaging modalities and specificities.
