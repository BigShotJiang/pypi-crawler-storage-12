"""Innit file."""

from __future__ import annotations


def hello_world():
    """Create useless function for innit."""
    print("This is the HILARy package!")


__version__ = "1.0.13"
