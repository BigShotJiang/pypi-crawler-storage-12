from minchin.pelican.plugins.autoloader import __version__, register
