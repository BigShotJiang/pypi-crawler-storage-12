import webbrowser

print("********************************************************")
print("⚠️ You likely wanted to install a different package. ⚠️")
print("    -> Find out why: https://tally.so/r/PdjxVB          ")
print("********************************************************")

webbrowser.open_new_tab("https://tally.so/r/PdjxVB")
