import webbrowser

import setuptools

print("********************************************************")
print("⚠️ You likely wanted to install a different package. ⚠️")
print("    -> Find out why: https://tally.so/r/PdjxVB          ")
print("********************************************************")

webbrowser.open_new_tab("https://tally.so/r/PdjxVB")


setuptools.setup(
    packages=[
        package
        for package in setuptools.find_namespace_packages()
        if package.startswith("google")
    ]
)
