from . import gaussian_process, kernels
from .gaussian_process import GaussianProcessRegressor
