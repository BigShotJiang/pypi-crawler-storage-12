"""The Zoom CLI architecture. Each command is packaged in its own module. Other
modules contain utilites, supporting logic, and the entry point."""

pass
