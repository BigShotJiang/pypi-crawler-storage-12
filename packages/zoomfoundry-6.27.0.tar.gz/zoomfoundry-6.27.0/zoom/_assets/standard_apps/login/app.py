"""
    login app
"""

import zoom

app = zoom.App()
