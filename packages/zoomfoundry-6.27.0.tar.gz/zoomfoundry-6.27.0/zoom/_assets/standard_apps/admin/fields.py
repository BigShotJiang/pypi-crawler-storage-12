"""
    admin fields
"""

import zoom.fields as f

class UserGroupsField(f.ChosenMultiselectField):
    pass
