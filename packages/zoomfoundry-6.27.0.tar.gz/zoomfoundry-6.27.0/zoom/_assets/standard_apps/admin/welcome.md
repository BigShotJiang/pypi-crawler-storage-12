
Dear {user.first_name},

Your account on {site.name} has been created and is ready to use.

You can access the site here: <a href="{site.abs_url}">{site.abs_url}</a>

Your username is: {user.username}

Your password is: {password}

Please send any feedback and suggestions to {site.admin_email}.

You can also use this email address for any problems accessing the site or if you need assistance in any way.

Thank you,

{site.owner_name}

