
Hello {user.name},

The administrator of {site.name} has reset the password to your account.

You can access the site here: <a href="{site.abs_url}">{site.abs_url}</a>

Your username is: {user.username}

Your password is: {password}

Please send any feedback and suggestions to {site.admin_email}.

Thank you,

{site.owner_name}

