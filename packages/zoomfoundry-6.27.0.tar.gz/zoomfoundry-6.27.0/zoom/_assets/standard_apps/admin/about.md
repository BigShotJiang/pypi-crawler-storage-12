# About Admin

System administration app used to manage users, groups and authorizations and monitor activity of [ZoomFoundry](https://www.zoomfoundry.com) framework version {version}.

Written by [Dynamic Solutions](https://www.dynamic-solutions.com).
