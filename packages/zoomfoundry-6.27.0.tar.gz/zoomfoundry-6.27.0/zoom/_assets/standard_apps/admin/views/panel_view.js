// to use bootstrap responsive tables for zoom.browse
$("div.panel div.baselist table").addClass("table");
