"""
    sample model
"""

data = [
    ('One', 'This is record one')
]
