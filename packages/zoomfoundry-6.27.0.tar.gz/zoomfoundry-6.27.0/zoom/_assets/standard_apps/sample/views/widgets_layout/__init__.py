"""
    widgets_layout component
"""

from zoom import DynamicComponent


class WidgetsLayout(DynamicComponent):
    pass
