# About Sample

Sample application demonstrating many of the features of the [ZoomFoundry](https://www.zoomfoundry.com) framework version {version}.

Written by [Dynamic Solutions](https://www.dynamic-solutions.com).
