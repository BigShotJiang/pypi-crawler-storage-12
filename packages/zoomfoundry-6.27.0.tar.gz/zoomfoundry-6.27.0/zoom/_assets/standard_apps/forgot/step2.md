Password Reset Sent
===================
We have sent you a link to reset your password.  

Please check your e-mail and click on the link provided to reset your password.

Thank you for using <dz:site_name>!  

~The <dz:site_name> Team  

