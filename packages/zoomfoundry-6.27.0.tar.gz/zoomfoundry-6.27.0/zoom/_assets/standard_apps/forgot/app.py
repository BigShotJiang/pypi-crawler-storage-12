"""
    forgot password app
"""

from zoom.apps import App

app = App()
