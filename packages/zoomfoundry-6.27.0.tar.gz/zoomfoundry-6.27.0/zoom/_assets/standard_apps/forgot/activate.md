Greetings from <dz:site_name>

We have received a request to reset the password associated with this email address.  If you made this request, please
click on the following link to reset your password:

<a href="<dz:reset_link>">Click here to reset your password</a>  

This link will take you back to the site.

If you did not make this request you can safely ignore this email.  Rest assured your <dz:site_name> account is safe.

Thank you for using <dz:site_name>!

~The <dz:site_name> Team
