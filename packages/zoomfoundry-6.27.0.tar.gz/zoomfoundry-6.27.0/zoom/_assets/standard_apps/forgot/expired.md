Password Reset Request Failed
=============================
  
Your password reset request has expired.  

In order to protect your privacy, we allow up to one hour
for you to reset your account after your request.  

We're sorry for any inconvenience this may have caused you.  

We request that you [try again](/forgot).  

Thank you.  

The <dz:site_name> Team

