Reset Complete!
===============

Your new password is now ready for you to use.

[Click here to log in to your account now!](/login)

Thank you for using <dz:site_name>.

