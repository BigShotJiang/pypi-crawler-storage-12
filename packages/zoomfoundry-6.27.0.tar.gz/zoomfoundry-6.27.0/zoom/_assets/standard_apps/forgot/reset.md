Reset Password
==============
Welcome back {{first_name}}!  

In case you need it, your username is <strong>{{username}}</strong>.

Please enter and confirm your new password in the spaces provided and we will reset it for you.
