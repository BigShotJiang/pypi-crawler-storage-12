"""
    zoom.settings
"""

import zoom

app = zoom.App()
app.menu = 'Settings', 'About'
