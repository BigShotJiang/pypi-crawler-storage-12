# About Settings

An app to manage system settings.  Stores the settings in the site database.

Written by [Dynamic Solutions](https://www.dynamic-solutions.com).

