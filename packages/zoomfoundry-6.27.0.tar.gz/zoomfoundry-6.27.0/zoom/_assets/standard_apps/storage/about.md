# About Storage

A super simple app to view the entities that are in the entity store.

Written by [Dynamic Solutions](https://www.dynamic-solutions.com).


## Change Log

* 2017-04-20 - Initial Release
