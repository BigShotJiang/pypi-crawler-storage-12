"""
    storage
"""

from zoom.apps import App

app = App()
app.menu = 'Overview', 'About'
