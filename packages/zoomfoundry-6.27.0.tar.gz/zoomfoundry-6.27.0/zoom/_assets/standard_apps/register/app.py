"""
    basic app
"""

import zoom

app = zoom.App()
