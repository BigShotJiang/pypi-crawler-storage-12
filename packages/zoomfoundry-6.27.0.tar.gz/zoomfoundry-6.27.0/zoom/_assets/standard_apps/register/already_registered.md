<h1>Registration Already Completed</h1>

<div class="mediumtext">

Your account has already been activated and is ready for you to use.

<a href="/login"><font color=#619900><b>Log in to your account now!</b></font></a>

Thank you for using {{site_name}}.

</div>
