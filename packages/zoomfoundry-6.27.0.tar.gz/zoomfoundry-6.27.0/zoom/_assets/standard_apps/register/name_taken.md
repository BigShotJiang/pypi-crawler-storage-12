Username in Use
====

Unfortunately the username **{{username}}** is already in use.

Usernames are unique to the system and are approved on a
first come, first served basis.

We're sorry for any inconvenience this may have caused you.

We request that you <a href="/register">re-register</a>.

Thank you.
