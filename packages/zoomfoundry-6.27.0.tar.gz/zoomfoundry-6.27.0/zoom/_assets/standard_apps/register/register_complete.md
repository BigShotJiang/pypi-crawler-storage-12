Registration Complete!
====

<div class="mediumtext">

Your account is now ready for you to use.

<br>
<br>

<a class="new-login-link btn btn-success" href="/login"><b>Log in to your account now!</b></a>

<br>
<br>

Thank you for registering at {{site_name}}.

</div>
