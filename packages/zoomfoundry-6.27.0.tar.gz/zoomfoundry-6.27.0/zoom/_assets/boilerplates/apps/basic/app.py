"""
    Main App Module

    This is the entrypoint to every app.
"""

import zoom

app = zoom.App(['Overview', 'About'])

