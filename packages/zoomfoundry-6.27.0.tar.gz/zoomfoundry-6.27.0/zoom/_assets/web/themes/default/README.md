
This theme is built using pug and sass.  Zoom automatically
translates pug files into html so no extra work is needed.

The best way to udpate the css in this theme is to use the
sass compiler.  To do this, you can either use a plugin for
your editor, or you can run the saas comiler yourself using
the following command:

    sass --watch src/sass:css


