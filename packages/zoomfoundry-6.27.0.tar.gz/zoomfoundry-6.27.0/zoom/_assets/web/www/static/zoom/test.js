
$(function() {

  $('#common_package_test').html('this text was updated by a common package');

});

