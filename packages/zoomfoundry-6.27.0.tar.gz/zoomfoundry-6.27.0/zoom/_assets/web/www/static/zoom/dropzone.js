    // zoom dropzone configuration
    Dropzone.autoDiscover = false;
