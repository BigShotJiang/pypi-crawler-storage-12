"""
    ping

    respond to a request
"""


def app(_):
    return dict(status='OK')
