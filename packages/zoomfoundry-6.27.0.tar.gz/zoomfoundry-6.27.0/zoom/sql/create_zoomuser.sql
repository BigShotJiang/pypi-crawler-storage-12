create user zoomuser identified by 'password';
grant all on zoomdata.* to zoomuser@'%';

