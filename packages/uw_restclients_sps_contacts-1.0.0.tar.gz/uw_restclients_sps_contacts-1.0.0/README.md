# REST client for the UW Student Personal Contacts

[![Build Status](https://github.com/uw-it-aca/uw-restclients-sps-contacts/workflows/tests/badge.svg)](https://github.com/uw-it-aca/uw-restclients-sps-contacts/actions)
[![Coverage Status](https://coveralls.io/repos/github/uw-it-aca/uw-restclients-sps-contacts/badge.svg?branch=main)](https://coveralls.io/github/uw-it-aca/uw-restclients-sps-contacts?branch=main)
[![PyPi Version](https://img.shields.io/pypi/v/uw-restclients-sps-contacts.svg)](https://pypi.python.org/pypi/uw-restclients-sps-contacts)
![Python versions](https://img.shields.io/badge/python-3.10-blue.svg)
