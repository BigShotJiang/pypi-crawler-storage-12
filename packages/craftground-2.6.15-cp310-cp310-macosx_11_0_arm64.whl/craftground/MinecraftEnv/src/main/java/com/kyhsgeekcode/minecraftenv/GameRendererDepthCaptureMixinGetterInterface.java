package com.kyhsgeekcode.minecraftenv;

public interface GameRendererDepthCaptureMixinGetterInterface {
    public float[] minecraftEnv$getLastDepthBuffer();
}
