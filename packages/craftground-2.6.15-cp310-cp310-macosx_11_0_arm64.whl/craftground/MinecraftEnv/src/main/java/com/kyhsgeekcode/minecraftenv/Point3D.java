package com.kyhsgeekcode.minecraftenv;

public record Point3D(int x, int y, int z) {}
