package com.kyhsgeekcode.minecraftenv

data class ChatMessageRecord(
    val addedTime: Int,
    val message: String,
)
