package com.kyhsgeekcode.minecraftenv

object TickSpeed {
    val mspt = 1L; // default: 50mspt
}
