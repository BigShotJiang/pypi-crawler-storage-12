#pragma once
#include "cross_gl.h"
GLubyte *caputreRGB(int frameBufferId, int textureWidth, int textureHeight);