from setuptools import setup, find_packages

setup(
    name="vipzenoxnet",
    version="1.0.0",
    packages=find_packages(),
    install_requires=["requests"],
    description="Lightweight Rubika bot library with Bot Token support",
    author="Your Name",
    python_requires=">=3.8",
)
