"""GOD CLI - Global Operations Deity."""

__version__ = "1.0.1"
__author__ = "Outer Void Team"
__email__ = "outervoid.blux@gmail.com"

from god.cli import main_cli

__all__ = ["main_cli"]
