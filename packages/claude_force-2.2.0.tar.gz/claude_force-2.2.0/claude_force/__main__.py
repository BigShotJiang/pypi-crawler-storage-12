"""
Main entry point for claude-force CLI.

Allows running the CLI with: python -m claude_force
"""

if __name__ == "__main__":
    from .cli import main

    main()
