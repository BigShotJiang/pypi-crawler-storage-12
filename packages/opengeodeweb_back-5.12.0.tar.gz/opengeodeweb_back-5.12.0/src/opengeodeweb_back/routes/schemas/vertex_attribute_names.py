from dataclasses_json import DataClassJsonMixin
from dataclasses import dataclass


@dataclass
class VertexAttributeNames(DataClassJsonMixin):
    id: str
