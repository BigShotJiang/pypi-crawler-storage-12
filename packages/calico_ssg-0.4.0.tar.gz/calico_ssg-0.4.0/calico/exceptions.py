class PageDoesNotExist(Exception):  # noqa: N818
    pass
