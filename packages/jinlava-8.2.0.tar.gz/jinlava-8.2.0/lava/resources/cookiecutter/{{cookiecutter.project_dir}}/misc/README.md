Miscellaneous files. Files in this directory are not part of the lava job(s) per
se but are related artefacts (e.g. SQL to create tables in databases).

With the default configuration, all SQL scripts (`*.sql`) are Jinja rendered
into the dist area but no other action is taken.
