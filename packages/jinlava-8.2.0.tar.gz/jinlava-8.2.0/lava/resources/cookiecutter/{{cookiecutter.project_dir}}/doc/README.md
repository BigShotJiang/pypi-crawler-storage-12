Put your documents, diagrams etc. in here.
