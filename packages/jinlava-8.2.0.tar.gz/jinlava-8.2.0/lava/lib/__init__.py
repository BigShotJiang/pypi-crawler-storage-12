"""General library modules."""

__author__ = 'Murray Andrews'
