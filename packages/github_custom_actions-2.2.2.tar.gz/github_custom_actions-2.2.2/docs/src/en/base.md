::: github_custom_actions.ActionBase
    options:
      heading_level: 1
      show_submodules: false
