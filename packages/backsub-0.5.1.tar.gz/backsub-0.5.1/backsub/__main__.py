from backsub.background_sub import main

if __name__ == "__main__":
    main()
