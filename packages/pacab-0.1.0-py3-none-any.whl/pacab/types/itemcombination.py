class ItemCombination:
	def __init__(self, with_item: str, to_item: str, sound: str | None) -> None:
		self.with_item = with_item
		self.to_item = to_item
		self.sound = sound
