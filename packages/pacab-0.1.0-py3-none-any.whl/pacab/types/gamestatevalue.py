type GameStateValue = bool | int | str
