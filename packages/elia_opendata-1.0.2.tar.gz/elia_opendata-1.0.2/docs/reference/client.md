# Client API Reference

The `EliaClient` class is the main interface for accessing the Elia OpenData API.

::: elia_opendata.client.EliaClient
