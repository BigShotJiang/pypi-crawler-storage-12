# Package marker for decoding utilities
