"""Bedrock AgentCore Memory SDK integration tests."""
