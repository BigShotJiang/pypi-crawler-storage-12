"""Utility helpers for fast-agent."""

from .time import format_duration

__all__ = ["format_duration"]
