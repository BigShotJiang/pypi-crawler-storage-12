List of all dynamic code loading API calls in the application. Loading code from untrusted sources could allow the execution of malicious code in the context of the current application.
