# Newscatcher CatchAll Python Library

[![fern shield](https://img.shields.io/badge/%F0%9F%8C%BF-Built%20with%20Fern-brightgreen)](https://buildwithfern.com?utm_source=github&utm_medium=github&utm_campaign=readme&utm_source=https%3A%2F%2Fgithub.com%2FNewscatcher%2Fnewscatcher-catchall-python)
[![pypi](https://img.shields.io/pypi/v/newscatcher-catchall-sdk)](https://pypi.python.org/pypi/newscatcher-catchall-sdk)

The Newscatcher CatchAll Python library provides access to the [CatchAll API](https://www.newscatcherapi.com/docs/v3/catch-all/overview/introduction), which transforms natural language queries into structured data extracted from web sources.

## Installation

```sh
pip install newscatcher-catchall-sdk
```

## Reference

A full reference for this library is available [here](./reference.md).

## Usage

### Jobs

Submit a query and retrieve structured results:

```python
from newscatcher_catchall import CatchAllApi
import time

client = CatchAllApi(api_key="YOUR_API_KEY")

# Create a job
job = client.jobs.create_job(
    query="Tech company earnings this quarter",
    context="Focus on revenue and profit margins",
    schema="Company [NAME] earned [REVENUE] in [QUARTER]",
)

# Poll for completion
while True:
    status = client.jobs.get_job_status(job.job_id)
    if status.status == "job_completed":
        break
    time.sleep(60)

# Retrieve results
results = client.jobs.get_job_results(job.job_id)
for record in results.all_records:
    print(record.record_title)
    print(record.enrichment)
```

Jobs process asynchronously and typically complete in 10-15 minutes. To learn more, see the [Quickstart](https://www.newscatcherapi.com/docs/v3/catch-all/overview/quickstart).

### Monitors

Automate recurring queries with scheduled execution:

```python
from newscatcher_catchall import CatchAllApi

client = CatchAllApi(api_key="YOUR_API_KEY")

# Create a monitor from a completed job
monitor = client.monitors.create_monitor(
    reference_job_id=job.job_id,
    schedule="every day at 12 PM UTC",
    webhook={
        "url": "https://your-endpoint.com/webhook",
        "method": "POST",
        "headers": {"Authorization": "Bearer YOUR_TOKEN"},
    },
)

# List all monitors
monitors = client.monitors.list_monitors()

# Get aggregated results
results = client.monitors.pull_monitor_results(monitor.monitor_id)
```

Monitors run jobs on your schedule and send webhook notifications when complete. See the [Monitors documentation](https://www.newscatcherapi.com/docs/v3/catch-all/overview/monitors) for setup and configuration.

## Async client

Use the async client for non-blocking API calls:

```python
import asyncio
from newscatcher_catchall import AsyncCatchAllApi

client = AsyncCatchAllApi(api_key="YOUR_API_KEY")

async def main() -> None:
    job = await client.jobs.create_job(
        query="Tech company earnings this quarter",
        context="Focus on revenue and profit margins",
    )
    print(f"Job created: {job.job_id}")

asyncio.run(main())
```

## Exception handling

Handle API errors with the `ApiError` exception:

```python
from newscatcher_catchall.core.api_error import ApiError

try:
    client.jobs.create_job(query="...")
except ApiError as e:
    print(f"Status: {e.status_code}")
    print(f"Error: {e.body}")
```

## Advanced

### Pagination

Retrieve large result sets with pagination:

```python
results = client.jobs.get_job_results(
    job_id="...",
    page=1,
    page_size=100,  # Default: 100, Max: 1000
)
```

### Access raw response data

Access response headers and raw data:

```python
response = client.jobs.with_raw_response.create_job(query="...")
print(response.headers)
print(response.data)
```

### Retries

The SDK retries failed requests automatically with exponential backoff. Configure retry behavior:

```python
client.jobs.create_job(
    query="...",
    request_options={"max_retries": 3},
)
```

### Timeouts

Set custom timeouts at the client or request level:

```python
# Client-level timeout
client = CatchAllApi(api_key="YOUR_API_KEY", timeout=30.0)

# Request-level timeout
client.jobs.create_job(
    query="...",
    request_options={"timeout_in_seconds": 10},
)
```

### Custom HTTP client

Customize the underlying HTTP client for proxies or custom transports:

```python
import httpx
from newscatcher_catchall import CatchAllApi

client = CatchAllApi(
    api_key="YOUR_API_KEY",
    httpx_client=httpx.Client(
        proxy="http://my.proxy.example.com",
        transport=httpx.HTTPTransport(local_address="0.0.0.0"),
    ),
)
```

## Beta status

CatchAll API is in beta. Breaking changes may occur in minor version updates. See the [Changelog](https://www.newscatcherapi.com/docs/v3/catch-all/overview/changelog) for updates.

## Contributing

This library is generated programmatically from our API specification. Direct contributions to the generated code cannot be merged, but README improvements are welcome. To suggest SDK changes, please [open an issue](https://github.com/Newscatcher/newscatcher-catchall-python/issues).

## Support

- Documentation: [https://www.newscatcherapi.com/docs/v3/catch-all](https://www.newscatcherapi.com/docs/v3/catch-all)
- Support: <support@newscatcherapi.com>
