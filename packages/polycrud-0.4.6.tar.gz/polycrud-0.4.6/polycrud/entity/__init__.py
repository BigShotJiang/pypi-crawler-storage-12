from .base import ModelEntity

__all__ = ["ModelEntity"]
