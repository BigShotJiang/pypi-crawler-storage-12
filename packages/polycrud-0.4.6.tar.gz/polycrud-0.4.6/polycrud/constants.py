NULL_VALUE = b"null"  # Optional: use orjson.dumps(None) instead for compatibility
