# deepagents cli

This is the CLI for deepagents

## Development

### Running Tests

To run the test suite:

```bash
uv sync --all-groups

make test
```
