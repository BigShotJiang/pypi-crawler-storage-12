autorag.data.legacy.corpus package
==================================

Submodules
----------

autorag.data.legacy.corpus.langchain module
-------------------------------------------

.. automodule:: autorag.data.legacy.corpus.langchain
   :members:
   :undoc-members:
   :show-inheritance:

autorag.data.legacy.corpus.llama\_index module
----------------------------------------------

.. automodule:: autorag.data.legacy.corpus.llama_index
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: autorag.data.legacy.corpus
   :members:
   :undoc-members:
   :show-inheritance:
