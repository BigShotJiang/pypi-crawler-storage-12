autorag.evaluation.metric package
=================================

Submodules
----------

autorag.evaluation.metric.deepeval\_prompt module
-------------------------------------------------

.. automodule:: autorag.evaluation.metric.deepeval_prompt
   :members:
   :undoc-members:
   :show-inheritance:

autorag.evaluation.metric.generation module
-------------------------------------------

.. automodule:: autorag.evaluation.metric.generation
   :members:
   :undoc-members:
   :show-inheritance:

autorag.evaluation.metric.retrieval module
------------------------------------------

.. automodule:: autorag.evaluation.metric.retrieval
   :members:
   :undoc-members:
   :show-inheritance:

autorag.evaluation.metric.retrieval\_contents module
----------------------------------------------------

.. automodule:: autorag.evaluation.metric.retrieval_contents
   :members:
   :undoc-members:
   :show-inheritance:

autorag.evaluation.metric.util module
-------------------------------------

.. automodule:: autorag.evaluation.metric.util
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: autorag.evaluation.metric
   :members:
   :undoc-members:
   :show-inheritance:
