autorag.data.chunk package
==========================

Submodules
----------

autorag.data.chunk.base module
------------------------------

.. automodule:: autorag.data.chunk.base
   :members:
   :undoc-members:
   :show-inheritance:

autorag.data.chunk.langchain\_chunk module
------------------------------------------

.. automodule:: autorag.data.chunk.langchain_chunk
   :members:
   :undoc-members:
   :show-inheritance:

autorag.data.chunk.llama\_index\_chunk module
---------------------------------------------

.. automodule:: autorag.data.chunk.llama_index_chunk
   :members:
   :undoc-members:
   :show-inheritance:

autorag.data.chunk.run module
-----------------------------

.. automodule:: autorag.data.chunk.run
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: autorag.data.chunk
   :members:
   :undoc-members:
   :show-inheritance:
