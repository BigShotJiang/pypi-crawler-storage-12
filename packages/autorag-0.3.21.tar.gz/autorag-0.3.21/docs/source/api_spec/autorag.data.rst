autorag.data package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   autorag.data.chunk
   autorag.data.legacy
   autorag.data.parse
   autorag.data.qa
   autorag.data.utils

Module contents
---------------

.. automodule:: autorag.data
   :members:
   :undoc-members:
   :show-inheritance:
