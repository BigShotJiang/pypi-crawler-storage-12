autorag.data.qa package
=======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   autorag.data.qa.evolve
   autorag.data.qa.filter
   autorag.data.qa.generation_gt
   autorag.data.qa.query

Submodules
----------

autorag.data.qa.extract\_evidence module
----------------------------------------

.. automodule:: autorag.data.qa.extract_evidence
   :members:
   :undoc-members:
   :show-inheritance:

autorag.data.qa.sample module
-----------------------------

.. automodule:: autorag.data.qa.sample
   :members:
   :undoc-members:
   :show-inheritance:

autorag.data.qa.schema module
-----------------------------

.. automodule:: autorag.data.qa.schema
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: autorag.data.qa
   :members:
   :undoc-members:
   :show-inheritance:
