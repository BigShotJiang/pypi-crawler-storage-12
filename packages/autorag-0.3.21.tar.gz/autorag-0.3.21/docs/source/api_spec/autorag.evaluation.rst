autorag.evaluation package
==========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   autorag.evaluation.metric

Submodules
----------

autorag.evaluation.generation module
------------------------------------

.. automodule:: autorag.evaluation.generation
   :members:
   :undoc-members:
   :show-inheritance:

autorag.evaluation.retrieval module
-----------------------------------

.. automodule:: autorag.evaluation.retrieval
   :members:
   :undoc-members:
   :show-inheritance:

autorag.evaluation.retrieval\_contents module
---------------------------------------------

.. automodule:: autorag.evaluation.retrieval_contents
   :members:
   :undoc-members:
   :show-inheritance:

autorag.evaluation.util module
------------------------------

.. automodule:: autorag.evaluation.util
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: autorag.evaluation
   :members:
   :undoc-members:
   :show-inheritance:
