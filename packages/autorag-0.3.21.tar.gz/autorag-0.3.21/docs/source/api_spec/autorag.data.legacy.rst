autorag.data.legacy package
===========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   autorag.data.legacy.corpus
   autorag.data.legacy.qacreation

Module contents
---------------

.. automodule:: autorag.data.legacy
   :members:
   :undoc-members:
   :show-inheritance:
