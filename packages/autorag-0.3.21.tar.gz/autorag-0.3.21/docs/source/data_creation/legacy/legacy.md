# Legacy

This is the legacy docs.
Deprecated since v0.3.0 release.


```{toctree}
---
maxdepth: 1
---
ragas.md
tutorial.md
```
