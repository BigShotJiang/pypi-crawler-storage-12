# This is v2 version, the next version of data creation
# The legacy (v1) version will be deprecated on AutoRAG version 0.3
# The legacy (v1) version and new v2 data creation is not compatible with each other
