## Acknowledgements

The file `sample_contents_nqa.csv` and the example context in the few-shot prompt in the '
autorag/data/qacreation/llama_index_default_prompt.txt' is the part of the Google's Natural QA dataset.
It is under 'cc-by-sa 3.0' license.

Citation:

```
@article{47761,
title	= {Natural Questions: a Benchmark for Question Answering Research},
author	= {Tom Kwiatkowski and Jennimaria Palomaki and Olivia Redfield and Michael Collins and Ankur Parikh and Chris Alberti and Danielle Epstein and Illia Polosukhin and Matthew Kelcey and Jacob Devlin and Kenton Lee and Kristina N. Toutanova and Llion Jones and Ming-Wei Chang and Andrew Dai and Jakob Uszkoreit and Quoc Le and Slav Petrov},
year	= {2019},
journal	= {Transactions of the Association of Computational Linguistics}
}
```
