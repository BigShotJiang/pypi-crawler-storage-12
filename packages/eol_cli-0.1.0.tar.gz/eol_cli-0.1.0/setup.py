"""Setup file for backward compatibility."""
from setuptools import setup

setup()

