"""API client module for endoflife.date API."""

from eol_cli.api.client import EOLClient

__all__ = ["EOLClient"]
