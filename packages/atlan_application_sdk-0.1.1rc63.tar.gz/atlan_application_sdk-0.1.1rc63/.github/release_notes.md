## v0.1.1rc63 (November 12, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc62...v0.1.1rc63

### Features

- handle single key secret stores (#812) (by @nishantmunjal7 in [abf5f6d](https://github.com/atlanhq/application-sdk/commit/abf5f6d))
- deployment secret single-key (#816) (by @nishantmunjal7 in [c5efd9a](https://github.com/atlanhq/application-sdk/commit/c5efd9a))
