"""Additional data required for integration of the EPA CEMS hourly data."""
