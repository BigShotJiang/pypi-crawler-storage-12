"""Metadata linking semantic meaning of Testing spreadsheet columns across years."""
