"""Metadata linking semantic meaning of PHMSA spreadsheet columns across years."""
