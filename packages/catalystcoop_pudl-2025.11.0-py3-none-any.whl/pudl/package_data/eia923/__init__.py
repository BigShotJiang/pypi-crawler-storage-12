"""Excel spreadsheet extraction maps for EIA 923."""
