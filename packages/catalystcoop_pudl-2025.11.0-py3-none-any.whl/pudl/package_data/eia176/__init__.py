"""CSV file extraction maps for EIA 176."""
