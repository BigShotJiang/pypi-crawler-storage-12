"""Metadata linking semantic meaning of EIA 860M spreadsheet columns across years."""
