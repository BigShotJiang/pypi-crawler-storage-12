"""Metadata linking semantic meaning of EIA 930 CSV file columns across years."""
