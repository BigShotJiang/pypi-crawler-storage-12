"""Excel spreadsheet extraction maps for EIA 861."""
