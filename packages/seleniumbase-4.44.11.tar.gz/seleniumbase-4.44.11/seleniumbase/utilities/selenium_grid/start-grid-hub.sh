#!/bin/bash
java -jar selenium-server-standalone.jar -role hub -timeout 230 -browserTimeout 170 -port 4444