# Example Package

This is a simple example package. You can use
[GitHub-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content

mcp-name: io.github.elpadev/sample-mcp-server-python-package