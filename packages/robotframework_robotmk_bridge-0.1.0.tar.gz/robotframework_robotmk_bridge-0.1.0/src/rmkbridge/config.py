from pathlib import Path

CONFIG_FILE = Path(__file__).resolve().parent / 'config.yml'
ORIGINAL_CONFIG_FILE = Path(__file__).resolve().parent / 'config_original.yml'
