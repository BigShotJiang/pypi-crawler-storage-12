# proxio
Proxmox api wrapper

## test
`pytest --cov=proxio --cov-report=term`

## build
`hatch build`

## publish
`hatch publish`
