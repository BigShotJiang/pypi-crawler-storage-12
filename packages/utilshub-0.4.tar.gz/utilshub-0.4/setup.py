from setuptools import setup

setup(
    name="utilshub",
    version="0.4",
    py_modules=["utilshub"],
    author="tester641114",
    author_email="guesthello01@gmail.com",
    description="Utility functions collection",
    url="",  # Optional: add your repository URL here
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
    python_requires='>=3.6',
)
