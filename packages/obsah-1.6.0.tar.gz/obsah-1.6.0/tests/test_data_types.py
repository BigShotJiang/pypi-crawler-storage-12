from obsah import data_types


def test_registered_types():
    assert data_types.REGISTRY
