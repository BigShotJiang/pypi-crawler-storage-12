# VKPyKit

This python package is packaged version of list of functions used for Exploratory Data Analysis, Linear Regression, Decision Trees. Intead of writing those everytime, just wanted to put them in a package and reuse myself. 

Use it as is, if you find issues or have more such functions, please contribute on github. 

## Setup / Run 
    pip install -r requirements.txt

[Source](https://github.com/assignarc/VKPyKit)