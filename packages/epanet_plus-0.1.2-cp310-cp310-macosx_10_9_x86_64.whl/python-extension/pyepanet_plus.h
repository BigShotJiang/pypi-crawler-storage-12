#include <Python.h>

PyObject* method_ENopenfrombuffer(PyObject* self, PyObject* args);
PyObject* method_EN_openfrombuffer(PyObject* self, PyObject* args);
