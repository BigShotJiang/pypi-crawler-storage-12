class InvalidScanType(Exception):
    pass


class ConfigurationError(Exception):
    pass
