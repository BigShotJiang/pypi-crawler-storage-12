__version__ = "0.4.9"

def get_versions():
    return {"version": __version__}
