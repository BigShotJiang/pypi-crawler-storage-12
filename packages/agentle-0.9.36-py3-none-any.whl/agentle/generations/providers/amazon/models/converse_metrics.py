from typing import TypedDict


class ConverseMetrics(TypedDict):
    latencyMs: int
