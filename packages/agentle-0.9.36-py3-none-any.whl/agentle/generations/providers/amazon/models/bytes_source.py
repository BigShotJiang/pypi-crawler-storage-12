# Base source types for media content
from typing import TypedDict


class BytesSource(TypedDict):
    bytes: str
