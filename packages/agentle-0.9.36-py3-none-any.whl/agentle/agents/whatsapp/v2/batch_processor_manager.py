import abc


class BatchProcessorManager(abc.ABC): ...
