"""Tests for quli quiz app."""

