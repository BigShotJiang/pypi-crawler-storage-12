"""Quli - CLI Quiz App powered by Gemini Flash 2.5."""

__version__ = "2.1.0"
