"""Streamlit UI components for the quiz app."""

