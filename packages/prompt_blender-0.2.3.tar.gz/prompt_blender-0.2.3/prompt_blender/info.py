__version__ = '0.2.3'
__author__ = 'Edans Sandes'

APP_NAME = "Prompt Blender"
DESCRIPTION = "A simple tool to create and execute prompts for Language Models"
WEB_SITE = 'https://github.com/edanssandes/prompt-blender'