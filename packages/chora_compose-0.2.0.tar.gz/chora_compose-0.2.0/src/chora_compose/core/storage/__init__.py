"""Storage layer for artifact persistence."""

from .artifact_store import ArtifactStore

__all__ = ["ArtifactStore"]
