# JavaJar - Python Java Runner with Auto JDK Management

JavaJar 是一个 Python 工具，可以通过 Python 运行 Java JAR 文件，并自动下载和管理 Java 运行环境。它支持本地 JAR 文件执行和 Maven 仓库依赖解析。

## 功能特性

- 🚀 **自动 JDK 管理**: 自动检测、下载和安装所需的 Java 版本
- 📦 **Maven 支持**: 直接从 Maven 仓库下载并运行 JAR 文件
- 🔧 **版本控制**: 支持指定 Java 版本（1.8, 11, 17, 21 等）
- 🎯 **本地执行**: 支持运行本地 JAR 文件
- 📋 **环境列表**: 查看系统中所有可用的 Java 版本
- 🌐 **多平台**: 支持 Windows、macOS 和 Linux
- 💾 **智能缓存**: 本地缓存下载的 JDK 和 Maven 依赖

## 安装

### 使用 pip 安装

```bash
pip install javajar
```

### 使用 uv 安装（推荐）

```bash
uv add javajar
```

### 从源码安装

```bash
git clone <repository-url>
cd javajar
pip install -e .
```

## 使用方法

### 基本命令

```bash
# 运行本地 JAR 文件
javajar run /path/to/your.jar

# 指定 Java 版本运行 JAR
javajar run /path/to/your.jar --java 17

# 从 Maven 仓库运行 JAR
javajar run --maven com.example:myapp:1.0.0

# 查看可用的 Java 版本
javajar java-list
```

### 高级用法

#### Maven 仓库配置

```bash
# 使用自定义 Maven 仓库
javajar run --maven com.alibaba:fastjson:2.0.31 \
  --release-repo https://repo1.maven.org/maven2 \
  --snapshot-repo https://oss.sonatype.org/content/repositories/snapshots
```

#### Java 参数传递

```bash
# 传递 JVM 参数
javajar run app.jar --java-args "-Xmx1g -Xms512m"

# 传递应用程序参数
javajar run app.jar --jar-args "--port 8080 --debug"
```

#### 版本范围支持

```bash
# 使用版本范围（自动选择 17 或更高版本）
javajar run app.jar --java 17+
```

## 命令行选项

### `javajar run` 命令

- `--jar`: 本地 JAR 文件路径
- `--maven`: Maven 坐标 (格式: groupId:artifactId:version[:packaging][:classifier])
- `--java`: 指定 Java 版本（默认: 17）
- `--java-args`: 传递给 Java 命令的附加参数
- `--jar-args`: 传递给 JAR 文件的参数
- `--release-repo`: Release 仓库 URL（可多次指定）
- `--snapshot-repo`: Snapshot 仓库 URL（可多次指定）

### `javajar java-list` 命令

列出系统中所有可用的 Java 版本，包括：
- JAVA_HOME 中的 Java
- PATH 中的 Java
- 通过 JavaJar 安装的 Java

## JDK 管理策略

JavaJar 按以下优先级查找和使用 JDK：

1. **JAVA_HOME**: 检查环境变量中的 JDK
2. **系统 PATH**: 查找系统中的 Java 安装
3. **本地缓存**: 检查 `~/.ylk_javajar/jdkinstall/` 中的安装
4. **自动下载**: 从 Foojay API 下载并安装所需的 JDK

## Maven 依赖解析

支持标准的 Maven 坐标格式：
- `groupId:artifactId:version`
- `groupId:artifactId:version:packaging`
- `groupId:artifactId:version:packaging:classifier`

依赖缓存位置：`~/.ylk_javajar/groupId/artifactId/version/`

## 系统要求

- Python >= 3.10
- 支持的操作系统：Windows、macOS、Linux（包括 Alpine Linux）

## 开发

### 项目结构

```
javajar/
├── src/javajar/
│   ├── __init__.py
│   ├── __main__.py
│   ├── cli.py              # 命令行接口
│   ├── java_runner.py      # JAR 执行逻辑
│   ├── jdk_manager.py      # JDK 管理
│   ├── java_list.py        # Java 版本列表
│   └── maven_resolver.py   # Maven 依赖解析
├── tests/                  # 测试文件
├── pyproject.toml         # 项目配置
└── README.md
```

### 下载和构建
```bash
git clone <repository-url>
uv sync
```

## 贡献

欢迎提交 Issue 和 Pull Request！

## 支持

如有问题，请在 GitHub Issues 中提交。