import typer

from javajar.java_runner import run_jar
from javajar.java_list import java_list

app = typer.Typer()

# Add Java JAR execution command
app.command("run")(run_jar)

# Add Java check command
app.command("java-list")(java_list)

if __name__ == "__main__":
    app()
