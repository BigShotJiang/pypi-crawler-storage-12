from isofate.isofunks import isocalc

'''
Test script for isocalc function
'''

