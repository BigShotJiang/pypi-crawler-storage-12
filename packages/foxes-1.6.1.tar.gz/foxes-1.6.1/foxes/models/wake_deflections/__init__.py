from .no_deflection import NoDeflection as NoDeflection
from .bastankhah2016 import Bastankhah2016Deflection as Bastankhah2016Deflection
from .jimenez import JimenezDeflection as JimenezDeflection
