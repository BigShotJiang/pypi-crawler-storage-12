from .betz import BetzAxialInduction as BetzAxialInduction
from .madsen import MadsenAxialInduction as MadsenAxialInduction
