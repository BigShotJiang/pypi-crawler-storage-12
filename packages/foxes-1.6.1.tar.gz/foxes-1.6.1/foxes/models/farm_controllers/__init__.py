"""
Farm controller models.
"""

from .basic import BasicFarmController as BasicFarmController
from .op_flag import OpFlagController as OpFlagController
