from django.apps import AppConfig


class ConflictIDConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "smoothglue.conflictid"
    label = "conflictid"
