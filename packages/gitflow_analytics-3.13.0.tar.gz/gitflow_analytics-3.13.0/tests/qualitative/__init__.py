"""Tests for qualitative analysis components."""
