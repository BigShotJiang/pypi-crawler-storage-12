"""Tests for data extractors."""
