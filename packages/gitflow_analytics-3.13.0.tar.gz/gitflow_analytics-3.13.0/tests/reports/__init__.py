"""Tests for report generation."""
