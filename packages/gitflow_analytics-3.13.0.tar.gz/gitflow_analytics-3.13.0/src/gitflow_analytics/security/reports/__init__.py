"""Security reporting module."""

from .security_report import SecurityReportGenerator

__all__ = ["SecurityReportGenerator"]