"""Factories for constructing graph infrastructure."""
