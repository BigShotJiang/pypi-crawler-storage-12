"""Top-level package for reusable graph components."""

from .base import BaseComponent

__all__ = ["BaseComponent"]
