from setuptools import setup, find_packages

setup(
    name='pymcdc',
    version='0.1',
    packages=find_packages(),
    install_requires=[],  # Dependências, se houver
    author='Delamaro',
    description='A module to evaluate MC/DC criterion to Python programs',
)