"""Claude Finder - Semantic search across Claude Code conversation history"""

__version__ = "0.2.0"
