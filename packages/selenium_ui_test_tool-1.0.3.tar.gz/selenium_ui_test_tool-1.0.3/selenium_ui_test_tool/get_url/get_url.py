def get_url(driver, url):
    return driver.get(url)
