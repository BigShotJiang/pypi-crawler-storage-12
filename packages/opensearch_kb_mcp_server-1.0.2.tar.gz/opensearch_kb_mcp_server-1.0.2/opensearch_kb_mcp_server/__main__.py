"""
Main entry point for running the MCP server as a module.

Usage:
    python -m opensearch_kb_mcp_server
"""

from . import main

if __name__ == "__main__":
    main()
