from typing import Literal

TimePeriod = Literal["years", "months"]
