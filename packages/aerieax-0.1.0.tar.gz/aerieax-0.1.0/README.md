# aerieax
[![tests](https://github.com/beckermr/aerieax/actions/workflows/tests.yml/badge.svg)](https://github.com/beckermr/aerieax/actions/workflows/tests.yml) [![pre-commit.ci status](https://results.pre-commit.ci/badge/github/beckermr/aerieax/main.svg)](https://results.pre-commit.ci/latest/github/beckermr/aerieax/main)

Affine Invariant HMC and Nested Sampling in JAX
