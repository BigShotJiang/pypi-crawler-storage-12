"""
    All modules contained in frontend were written to be compiled bythe transpiler (transcrypt), they were not tested
    in Cpython.
"""
