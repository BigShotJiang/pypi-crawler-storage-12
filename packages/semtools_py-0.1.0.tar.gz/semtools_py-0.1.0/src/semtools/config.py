from pathlib import Path

APP_HOME_DIR_NAME = ".semtools"
APP_HOME_DIR = Path.home() / APP_HOME_DIR_NAME