class WorkspaceError(Exception):
    """Base exception for workspace-related errors."""
    pass
