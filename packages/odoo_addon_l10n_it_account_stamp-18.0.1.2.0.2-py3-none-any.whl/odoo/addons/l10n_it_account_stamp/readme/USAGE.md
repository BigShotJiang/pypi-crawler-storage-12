**Italiano**

Se nella fattura o ricevuta è previsto l'addebito dell'imposta di bollo
al cliente, fare clic sul pulsante "Aggiungi riga bollo" per aggiungere
una riga relativa all'imposta di bollo.

In caso contrario, l'imposta di bollo verrà comunque considerata ma non
verrà addebitata al cliente.

**English**

In invoice or receipt form, when applicable, click 'Add stamp duty line'
button to add stamp duty as invoice line, thus charging customer.

Otherwise, stamp duty will be anyway accounted, without charging
customer.
