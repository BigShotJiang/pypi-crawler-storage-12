"""spry.stuff: stuff module within the bootstrap package."""


class Stuff:
    pass
