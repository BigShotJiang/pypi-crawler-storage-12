"""spry.__main__: executed when spry directory is called as script."""


from .spry import main
main()
