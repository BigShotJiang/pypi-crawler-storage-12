from setuptools import setup

# All package metadata is now defined in pyproject.toml
setup() 