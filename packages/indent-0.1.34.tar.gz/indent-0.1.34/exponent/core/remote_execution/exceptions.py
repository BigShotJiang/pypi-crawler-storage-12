class ExponentError(Exception):
    pass


class HandledExponentError(Exception):
    pass


class RateLimitError(Exception):
    pass
