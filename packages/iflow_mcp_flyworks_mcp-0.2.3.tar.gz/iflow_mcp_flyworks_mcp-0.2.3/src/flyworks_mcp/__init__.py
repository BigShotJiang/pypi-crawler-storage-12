"""
Flyworks MCP: Free & Fast Zeroshot Lipsync Tool.

A Model Context Protocol (MCP) server that provides a convenient interface
for interacting with the Flyworks API for lipsync video creation.
"""

__version__ = "0.2.3" 