from .pde_adapter import solve_pde

__all__ = ["solve_pde"]


