"""Module exports."""
求解器基础module

包含所有求解器的公共基类和工具函数。
"""

from .solver_base import BaseSolver

__all__ = ['BaseSolver']