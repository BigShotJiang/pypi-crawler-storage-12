"""
.. include:: ../../README.md
"""

from .generate import generate

__all__ = ["generate"]

__version__ = "1.0.1"
