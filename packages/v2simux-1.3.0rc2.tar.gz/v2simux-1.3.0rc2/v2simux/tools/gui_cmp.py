from v2simux.gui.cmpbox import CmpBox

    
if __name__ == "__main__":
    app = CmpBox()
    app.mainloop()