from __future__ import annotations
from typing import Any, Tuple
from syncraft.syntax import Syntax, SyntaxSpec, Graph


