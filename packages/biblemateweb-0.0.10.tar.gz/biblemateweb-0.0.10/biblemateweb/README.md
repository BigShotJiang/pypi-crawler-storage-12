# BibleMate AI Web

BibleMate AI Web Application - Web UI based on the work at https://github.com/eliranwong/biblemate

# Development in Progress ...

Install for testing:

> pip install --upgrade biblemateweb

Run:

> biblemateweb

## Use Existing UniqueBible App Data

```
cd
mkdir biblemate
cd biblemate
ln -s ../UniqueBible/marvelData data
cd data
eliran@ai-desk:~/biblemate/data$ ln -s ../../UniqueBible/audio/ audio
```