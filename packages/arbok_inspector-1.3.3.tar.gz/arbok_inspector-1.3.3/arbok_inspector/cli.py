import runpy

def main():
    runpy.run_module('arbok_inspector.main', run_name='__main__')
