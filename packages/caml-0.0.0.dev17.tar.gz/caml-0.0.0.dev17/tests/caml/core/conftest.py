import pytest

pytestmark = pytest.mark.core
