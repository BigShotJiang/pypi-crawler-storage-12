---
name: Question
about: Ask a specific question related to camper
title: "[QUESTION] <INSERT_TITLE_HERE>"
labels: "issue: question"
assignees: ""
---

# Question

## 1. Description
<!--
A clear and targeted desciption of the question you are asking.
-->

## 2. Context
<!--
Any useful context around the specific question.
-->

## 3. Code Examples
<!--
If applicable, any code examples related to the question you are asking.
-->

## 4. Additional Information
<!--
Any additional information we should know about this question.
-->
