# SCAN Command Help

```
usage: python.exe C:\Users\joedi\AppData\Local\Programs\Python\Python314\Scripts\codesentinel scan
       [-h] [--output OUTPUT]

options:
  -h, --help           show this help message and exit
  --output, -o OUTPUT  Output file for scan results

```
