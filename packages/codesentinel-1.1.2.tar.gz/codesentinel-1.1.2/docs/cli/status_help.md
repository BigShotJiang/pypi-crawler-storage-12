# STATUS Command Help

```
usage: python.exe C:\Users\joedi\AppData\Local\Programs\Python\Python314\Scripts\codesentinel status
       [-h]

options:
  -h, --help  show this help message and exit

```
