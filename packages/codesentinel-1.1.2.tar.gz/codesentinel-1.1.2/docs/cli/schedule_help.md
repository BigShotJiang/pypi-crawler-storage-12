# SCHEDULE Command Help

```
usage: python.exe C:\Users\joedi\AppData\Local\Programs\Python\Python314\Scripts\codesentinel schedule
       [-h] {start,stop,status}

positional arguments:
  {start,stop,status}  Scheduler action

options:
  -h, --help           show this help message and exit

```
