# MAINTENANCE Command Help

```
usage: python.exe C:\Users\joedi\AppData\Local\Programs\Python\Python314\Scripts\codesentinel maintenance
       [-h] [--dry-run] {daily,weekly,monthly}

positional arguments:
  {daily,weekly,monthly}
                        Type of maintenance to run

options:
  -h, --help            show this help message and exit
  --dry-run             Show what would be done without executing

```
