# Orphaned Modules Report

**Generated**: 2025-11-11 05:31:58

**Total Orphaned Modules**: 4

## Modules

### 1. doc_utils

- **Type**: CLI utility module
- **Path**: `C:\Users\joedi\Documents\CodeSentinel\codesentinel\cli\doc_utils.py`
- **Suggested Command**: `codesentinel doc`

### 2. main_utils

- **Type**: CLI utility module
- **Path**: `C:\Users\joedi\Documents\CodeSentinel\codesentinel\cli\main_utils.py`
- **Suggested Command**: `codesentinel main`

### 3. document_formatter

- **Type**: Utils module
- **Path**: `C:\Users\joedi\Documents\CodeSentinel\codesentinel\utils\document_formatter.py`

### 4. root_policy

- **Type**: Utils module
- **Path**: `C:\Users\joedi\Documents\CodeSentinel\codesentinel\utils\root_policy.py`

