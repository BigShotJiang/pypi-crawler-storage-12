# Validation Reminder

**CRITICAL:** All JSON artifacts MUST be validated before emission.

**Refer to:** `@procedure:artifact_validation`

**For every artifact you produce:**

1. **Locate schema** in `SCHEMA_INDEX.json` using the artifact type
2. **Run preflight protocol:**
   - Echo schema metadata ($id, draft, path, sha256)
   - Show a minimal valid instance
   - Show one invalid example with explanation
3. **Produce artifact** with `"$schema"` field pointing to schema $id
4. **Validate** artifact against schema before emission
5. **Emit `validation_report.json`** with validation results
6. **STOP if validation fails** — do not proceed with invalid artifacts

**No exceptions.** Validation failures are hard gates that stop the workflow.
