from importlib.metadata import version

app_name = "schemist"
__author__ = "Eachan Johnson"
__version__ = version(app_name)
