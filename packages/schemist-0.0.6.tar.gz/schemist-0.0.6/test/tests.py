import doctest
import schemist as sch

if __name__ == '__main__':

    doctest.testmod(sch)