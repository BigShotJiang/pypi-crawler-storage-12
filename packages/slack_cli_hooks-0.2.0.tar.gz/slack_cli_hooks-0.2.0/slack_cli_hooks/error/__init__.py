class CliError(Exception):
    """General class for cli error"""


class PypiError(Exception):
    """General class for PyPI package info retrieval error"""
