"""Slack CLI contract implementation for Bolt."""
