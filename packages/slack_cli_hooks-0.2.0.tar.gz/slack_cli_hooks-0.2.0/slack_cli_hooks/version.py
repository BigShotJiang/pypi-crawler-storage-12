"""Check the latest version at https://pypi.org/project/slack-cli-hooks/"""

__version__ = "0.2.0"
