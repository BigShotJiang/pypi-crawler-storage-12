"""batplot: Interactive plotting for battery data visualization."""

__version__ = "1.5.3"

__all__ = ["__version__"]
