"""A full benchmark."""
