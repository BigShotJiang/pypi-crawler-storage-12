# Walker Examples

This directory contains examples demonstrating Walker features:

- `walker_events_demo.py` - Event handling in Walkers
- `walker_reporting_demo.py` - Walker reporting and data collection
- `walker_traversal_demo.py` - Graph traversal patterns
- `multi_target_hooks_demo.py` - Multiple target node handling