This module adds the function to calculate commissions in invoices
(account moves).

It also allows to create vendor bills from settlements for external
agents.

This module depends on the commission module.

Additionally, it extends the grouped settlement report from the commission module
to include a grouping by invoice
