from enum import Enum
 
class ImagePartCategory(Enum):
    PART = 1
    HATCH = 2
