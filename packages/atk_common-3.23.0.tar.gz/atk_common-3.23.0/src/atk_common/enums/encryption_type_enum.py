from enum import Enum
 
class EncryptionType(Enum):
    NONE = 1
    X25519_AES_GCM = 2
