# limit the exported strings for 'import *' usage
__all__ = [
    "ScriptTest3"
]

from .ScriptTest3 import ScriptTest3
