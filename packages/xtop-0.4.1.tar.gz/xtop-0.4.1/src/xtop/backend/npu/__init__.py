from .intel import IntelNPU


__all__ = ["IntelNPU"]

