from .gpu import GPU_UI
from .npu import NPU_UI


__all__ = ["GPU_UI", "NPU_UI"]

