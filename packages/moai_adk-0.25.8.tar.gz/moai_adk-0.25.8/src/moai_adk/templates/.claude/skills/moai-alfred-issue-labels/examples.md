# Examples

See `reference.md` for practical examples and usage patterns.

