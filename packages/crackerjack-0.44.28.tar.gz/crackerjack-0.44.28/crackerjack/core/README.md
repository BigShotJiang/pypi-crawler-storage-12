# Core

Core utilities and base abstractions shared across the package.
