# Decorators

Cross-cutting decorators and helper wrappers. Keep complexity ≤15 per function.
