from modal_mcp_toolbox import main

main()
