"""Workflows defined in fabricatio-capabilities."""
