Files in this folder are copied and adapted from SUMO tools.
Thus these files may cater to EPL-2.0 with GPL-v2 license.