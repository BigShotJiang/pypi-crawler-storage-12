from v2sim.gui.parabox import *

if __name__ == "__main__":
    app = ParaBox()
    app.mainloop()