from linkmerce.core.searchad.gfa.common import SearchAdGFA
