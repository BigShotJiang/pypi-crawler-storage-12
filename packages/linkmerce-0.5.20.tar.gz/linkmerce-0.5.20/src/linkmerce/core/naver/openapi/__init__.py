from linkmerce.core.naver.openapi.common import NaverOpenAPI
