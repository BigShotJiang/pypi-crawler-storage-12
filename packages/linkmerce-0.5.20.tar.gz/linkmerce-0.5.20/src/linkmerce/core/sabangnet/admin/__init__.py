from linkmerce.core.sabangnet.admin.common import SabangnetAdmin
