__author__ = "Bailey Stoner <monokrome@monokro.me>"
__version__ = "0.2.0"

from prefer import loading

load = loading.load
