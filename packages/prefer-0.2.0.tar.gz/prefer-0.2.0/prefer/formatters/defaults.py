defaults = [
    "prefer.formatters.json:JSONFormatter",
    "prefer.formatters.yaml:YAMLFormatter",
    "prefer.formatters.ini:INIFormatter",
    "prefer.formatters.xml:XMLFormatter",
]
