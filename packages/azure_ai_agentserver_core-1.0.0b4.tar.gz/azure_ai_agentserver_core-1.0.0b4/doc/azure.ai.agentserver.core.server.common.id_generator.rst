azure.ai.agentserver.core.server.common.id\_generator package
=============================================================

.. automodule:: azure.ai.agentserver.core.server.common.id_generator
   :inherited-members:
   :members:
   :undoc-members:

Submodules
----------

azure.ai.agentserver.core.server.common.id\_generator.foundry\_id\_generator module
-----------------------------------------------------------------------------------

.. automodule:: azure.ai.agentserver.core.server.common.id_generator.foundry_id_generator
   :inherited-members:
   :members:
   :undoc-members:

azure.ai.agentserver.core.server.common.id\_generator.id\_generator module
--------------------------------------------------------------------------

.. automodule:: azure.ai.agentserver.core.server.common.id_generator.id_generator
   :inherited-members:
   :members:
   :undoc-members:
