# Environment variable name used by the assume_role decorator to pass
# the role ARN to AWS client functions
OBP_ASSUME_ROLE_ARN_ENV_VAR = "OBP_ASSUME_ROLE_ARN"
