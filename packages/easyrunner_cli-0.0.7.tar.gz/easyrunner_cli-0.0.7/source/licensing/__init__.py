"""License management for EasyRunner CLI."""

from .license_manager import LicenseInfo, LicenseManager

__all__ = ["LicenseManager", "LicenseInfo"]
