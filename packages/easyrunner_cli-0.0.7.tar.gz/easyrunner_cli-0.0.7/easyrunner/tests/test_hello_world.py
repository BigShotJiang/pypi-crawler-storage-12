def test_hello_world():
    assert 1 + 1 == 2