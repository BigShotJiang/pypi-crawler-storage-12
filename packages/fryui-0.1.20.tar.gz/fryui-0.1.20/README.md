# fryui
UI Framework based on [FryWEB](https://github.com/frybox/fryweb)
