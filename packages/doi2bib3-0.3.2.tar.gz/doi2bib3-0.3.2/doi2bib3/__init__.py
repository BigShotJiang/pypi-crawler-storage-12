"""doi2bib3 package shim."""

from .backend import fetch_bibtex

__all__ = ["fetch_bibtex"]
