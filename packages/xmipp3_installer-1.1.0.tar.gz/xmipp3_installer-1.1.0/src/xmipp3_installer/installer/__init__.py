"""### Contains the main logic of the project."""
