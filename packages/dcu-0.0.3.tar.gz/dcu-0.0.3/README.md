# Danes Cool Utility

The very coolest most bestest cool utility. You can use
[GitHub-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.
