#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""

if __name__ == '__main__':
    from metrics_utility import manage

    manage()
