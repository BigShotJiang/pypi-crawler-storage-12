from sanic_httpauth import HTTPBasicAuth

auth = HTTPBasicAuth()
