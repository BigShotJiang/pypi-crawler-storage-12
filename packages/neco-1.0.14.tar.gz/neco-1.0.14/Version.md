# 1.0.14
* 修复 AG-UI 异步返回的缺陷

# 1.0.13
* 添加缺失的依赖包: pycryptodome、networkx
# 1.0.12
* 移除 PPOCR 支持
* 移除 Torch 相关依赖

# 1.0.11
* 添加 agent_cli
* 修复 pgvector 连接问题

# 1.0.10
* 修复升级后`"sentence-transformers==5.1.2",`缺失包的问题

# 1.0.9
* 新增 AG-UI 支持
* Lats Agent 修改为并行评估模式
* 重构 tools 文件夹结构
* 移除 Ansible 和 HTTP Request 工具模块
* 新增 CLI 命令行工具： 导出当前支持的工具列表为 yaml 文件
* 新增 Shell 工具
* LangChain 工具链升级
* 新增 DeepAgent
* 新增 Supervisor Multi Agent