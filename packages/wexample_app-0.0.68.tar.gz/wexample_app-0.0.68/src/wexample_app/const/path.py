from __future__ import annotations

from pathlib import Path

# filestate: python-constant-sort
APP_DIR_NAME_OUTPUT: Path = Path("output")
APP_DIR_NAME_TMP: Path = Path("tmp")
APP_DIR_PATH_RELATIVE_OUTPUT: Path = Path(APP_DIR_NAME_TMP / "output")
