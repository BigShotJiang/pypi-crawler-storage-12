"""VoiceMD Colab utilities"""

