class TestFake(object):

    def test_fake(self):
        assert True
