import os

os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
