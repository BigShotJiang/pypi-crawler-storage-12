"""
Copyright 2025 Google LLC
Licensed under the Apache License, Version 2.0

内部实现模块
"""

# 此模块包含内部实现细节，不应被外部直接使用 