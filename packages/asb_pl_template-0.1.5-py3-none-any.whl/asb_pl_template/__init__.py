# -*- coding: utf-8 -*-
from .core import AnsibleProjectManager

VERSION = (0, 1, 5)
