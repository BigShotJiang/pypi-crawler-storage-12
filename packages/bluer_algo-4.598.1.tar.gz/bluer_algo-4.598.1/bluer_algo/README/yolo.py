docs = [
    {"path": "../docs/yolo"},
    {"path": "../docs/yolo/dataset"},
    {"path": "../docs/yolo/dataset/ingest-and-review.md"},
    {"path": "../docs/yolo/model"},
    {"path": "../docs/yolo/model/validation.md"},
]
