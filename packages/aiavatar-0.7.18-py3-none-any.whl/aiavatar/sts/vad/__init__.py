from .base import SpeechDetector, SpeechDetectorDummy
from .standard import StandardSpeechDetector
