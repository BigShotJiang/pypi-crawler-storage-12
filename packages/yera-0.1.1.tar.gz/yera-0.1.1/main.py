def main():
    print("Hello from yera!")


if __name__ == "__main__":
    main()
