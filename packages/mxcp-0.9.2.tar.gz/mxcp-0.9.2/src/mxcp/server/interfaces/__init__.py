"""External interfaces for MXCP.

This package contains modules that provide external-facing interfaces
such as the CLI and server API.
"""
