"""MCP server interface for MXCP.

This module provides the Model Context Protocol (MCP) server implementation.
"""
