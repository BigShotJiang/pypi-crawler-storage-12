"""Endpoint definition management.

This module handles loading and parsing of endpoint YAML files
(tools, resources, and prompts).
"""
