"""Authentication utilities for MXCP core.

This module contains helpers for translating between MXCP configuration
and SDK authentication types.
"""
