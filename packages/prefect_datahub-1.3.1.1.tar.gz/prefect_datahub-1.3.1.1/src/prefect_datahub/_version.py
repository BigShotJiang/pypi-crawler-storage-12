# Published at https://pypi.org/project/prefect-datahub/.
__package_name__ = "prefect-datahub"
__version__ = "1.3.1.1"
