"""Version information for withoutbg."""

__version__ = "1.0.0"
