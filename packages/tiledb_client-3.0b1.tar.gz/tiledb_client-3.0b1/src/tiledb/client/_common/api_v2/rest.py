"""Re-exporting the ``rest`` namespace."""

from tiledb.client.rest_api.rest import *  # noqa: F401,F403
