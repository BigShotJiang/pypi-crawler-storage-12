"""
Hypersonic_HeyGen

Educational CLI to scaffold a HeyGen-ready Jupyter notebook.
"""

__all__ = ["__version__"]

# Keep this in sync with pyproject.toml
__version__ = "0.1.2"
