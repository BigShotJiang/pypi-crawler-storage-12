## remove cmk-dev command because of preexisting binary with same name
<!--
type: breaking
scope: all
affected: all
-->

We hope to restore `cmk-dev` in the future but have to coordinate
internally, which takes some time.
