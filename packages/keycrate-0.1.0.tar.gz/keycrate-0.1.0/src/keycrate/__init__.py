from .client import LicenseAuthClient, configurate

__all__ = ["LicenseAuthClient", "configurate"]
