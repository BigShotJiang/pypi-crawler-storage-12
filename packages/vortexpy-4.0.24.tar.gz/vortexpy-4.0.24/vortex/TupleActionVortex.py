class TupleActionVortex:
    def __init__(self, vortexName, vortexUuid, httpSession):
        self.name = vortexName
        self.uuid = vortexUuid
        self.httpSession = httpSession
