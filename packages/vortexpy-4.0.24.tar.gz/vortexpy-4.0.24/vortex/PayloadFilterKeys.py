"""
 * Created by Synerty Pty Ltd
 *
 * This software is open source, the MIT license applies.
 *
 * Website : http://www.synerty.com
 * Support : support@synerty.com
"""

rapuiServerEcho = "rapuiServerEcho"
rapuiClientEcho = "rapuiClientEcho"
rapuiVortexUuid = "rapuiVortexUuid"

plIdKey = "id"
plDeleteKey = "delete"
