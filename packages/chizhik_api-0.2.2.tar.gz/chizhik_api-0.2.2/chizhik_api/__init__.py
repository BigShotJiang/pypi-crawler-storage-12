from .manager import ChizhikAPI

__all__ = ["ChizhikAPI"]
__version__ = "0.2.2"
