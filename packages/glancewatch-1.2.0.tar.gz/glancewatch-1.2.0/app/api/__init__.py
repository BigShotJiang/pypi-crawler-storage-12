"""API module for GlanceWatch."""
