# Requirements

```{requirements} ../../requirements.txt
---
title: Mandatory Requirements
---
```

```{requirements} ../../requirements/*.txt
---
---
```
