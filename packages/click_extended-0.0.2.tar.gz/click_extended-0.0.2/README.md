![Banner](./assets/click-extended-banner.png)

# Click Extended

TBD

## Installation

```bash
pip install click-extended
```

## Requirements

TBD

## License

This project is licensed under the MIT License - see the [LICENSE](./LICENSE) file for details.

## Contributing

TBD

## Acknowledgements

This project is built on top of the [Click](https://github.com/pallets/click) library.
