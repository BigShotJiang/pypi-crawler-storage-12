"""Workflows defined in fabricatio-mock."""
