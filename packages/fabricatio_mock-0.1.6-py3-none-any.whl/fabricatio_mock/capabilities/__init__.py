"""Capabilities defined in fabricatio-mock."""
