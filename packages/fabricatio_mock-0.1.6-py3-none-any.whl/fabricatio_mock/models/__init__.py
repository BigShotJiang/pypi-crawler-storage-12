"""Models defined in fabricatio-mock."""
