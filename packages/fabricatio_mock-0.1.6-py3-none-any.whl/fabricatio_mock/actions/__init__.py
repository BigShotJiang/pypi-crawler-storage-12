"""Actions defined in fabricatio-mock."""
