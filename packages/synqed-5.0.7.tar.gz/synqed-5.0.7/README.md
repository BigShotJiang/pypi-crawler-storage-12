# Synqed - Simplified Multi-Agent System Platform

**API Name:** Synqed  
**Built on:** A2A (Agent2Agent) Protocol

Synqed enables multi-agent systems interaction and communication by providing a simplified, developer-friendly wrapper around the A2A protocol. Build sophisticated multi-agent systems with minimal code.

---

## 🚀 Features

### 1. Delegation Layer ✅
A complete wrapper around A2A that simplifies:
- ✨ **Agent Creation** - Create agents with minimal configuration
- 🎴 **Agent Cards** - Auto-generate agent cards with sensible defaults
- 🖥️ **Server Management** - Start servers with one line of code
- 📨 **Task Requests** - Simple client API for agent communication
- 🤝 **Multi-Agent Delegation** - Automatically route tasks to the right agents

### 2. Workspace/Collaboration (Coming Soon)
A temporary environment/sandbox where AI agents can collaborate in real-time.

---

## 📦 Installation

```bash
pip install synqed
```

With all extras (gRPC, SQL, etc.):

```bash
pip install synqed[all]
```

From source:

```bash
cd Synq
pip install -e .
```

**Requirements:**
- Python 3.10+
- `uvicorn` for running servers

---

## ⚡ Quick Start

### Create Your First Agent

```python
import asyncio
from synqed import Agent, AgentServer

# Define your agent's logic
async def my_agent_logic(context):
    user_message = context.get_request_message_text()
    return f"You said: {user_message}"

# Create the agent
agent = Agent(
    name="My First Agent",
    description="A helpful assistant",
    skills=["conversation", "echo"],
    executor=my_agent_logic
)

# Start the server
server = AgentServer(agent, port=8000)
await server.start()  # Runs on http://localhost:8000
```

### Connect as a Client

```python
from synqed import Client

async with Client("http://localhost:8000") as client:
    # Stream responses
    async for chunk in client.send("Hello, agent!"):
        print(chunk, end="")
    
    # Or wait for complete response
    response = await client.send_and_wait("What can you do?")
    print(response)
```

### Multi-Agent Coordination

```python
from synqed import TaskDelegator

# Create specialized agents
recipe_agent = Agent(
    name="Recipe Agent",
    description="Finds recipes",
    skills=["recipe_search", "cooking"],
    executor=recipe_logic
)

shopping_agent = Agent(
    name="Shopping Agent",
    description="Helps with shopping",
    skills=["shopping", "products"],
    executor=shopping_logic
)

# Set up delegator
delegator = TaskDelegator()
delegator.register_agent(recipe_agent)
delegator.register_agent(shopping_agent)

# Tasks automatically routed to the right agent!
result = await delegator.submit_task(
    "Find me a recipe for pasta"
)
```

---

## 🎯 Usage Modes

Synqed supports three different usage paradigms:

### 1. Developer Mode 👨‍💻
- **Who:** Developers building agent systems
- **How:** Python API + Local servers
- **Features:** Full control, custom logic, direct access to all features
- **Example:** See `examples/` directory

### 2. Admin Mode 🎛️ (Coming Soon)
- **Who:** System administrators and non-developers
- **How:** Web UI for visual management
- **Features:** Create agents, manage workspaces, configure delegation
- **No Code Required:** Point-and-click interface

### 3. Layman Mode 🌐 (Coming Soon)
- **Who:** End users who just want to get things done
- **How:** Simple chat interface
- **Features:** Just describe your task, agents handle everything
- **Zero Configuration:** Everything automatic behind the scenes

---

## 📚 Documentation

### Core Components

#### 1. **Agent** - Your AI Worker
```python
agent = Agent(
    name="Agent Name",
    description="What it does",
    skills=["skill1", "skill2"],  # or detailed dicts
    executor=your_async_function,  # optional
    version="1.0.0",
    url="http://...",  # auto-set by server
    capabilities={"streaming": True},
    # ... more options
)
```

#### 2. **AgentServer** - Host Your Agent
```python
server = AgentServer(
    agent=agent,
    host="0.0.0.0",
    port=8000,
    path_prefix="",
    enable_cors=True
)

# Blocking
await server.start()

# Or background
await server.start_background()
# ... do other things ...
await server.stop()
```

#### 3. **Client** - Connect to Agents
```python
client = Client(
    agent_url="http://localhost:8000",
    streaming=True,
    timeout=30.0
)

# Send messages
async for response in client.send("Hello"):
    print(response)

# Get task status
task = await client.get_task(task_id)

# Cancel tasks
await client.cancel_task(task_id)
```

#### 4. **TaskDelegator** - Orchestrate Multiple Agents
```python
delegator = TaskDelegator()

# Register agents (local or remote)
delegator.register_agent(agent=local_agent)
delegator.register_agent(agent_url="http://remote-agent:8000")

# Submit tasks
result = await delegator.submit_task(
    "Your task description",
    require_skills=["cooking"],  # optional
    preferred_agent="Recipe Agent"  # optional
)

# Broadcast to multiple agents
results = await delegator.submit_task_to_multiple(
    "Question for everyone"
)

# List all agents
agents = delegator.list_agents()
```

#### 5. **AgentCardBuilder** - Custom Cards
```python
from synqed import AgentCardBuilder

builder = AgentCardBuilder(
    name="My Agent",
    description="Description",
    version="1.0.0",
    url="http://..."
)

builder.add_skill(
    skill_id="my_skill",
    name="My Skill",
    description="What it does",
    tags=["tag1", "tag2"],
    examples=["Example usage"]
)

builder.set_capabilities(
    streaming=True,
    push_notifications=False
)

card = builder.build()
```

---

## 📖 Examples

Check out the `examples/` directory for complete working examples:

1. **`basic_agent.py`** - Simple agent with custom logic
2. **`client_example.py`** - Connect and interact with agents
3. **`multi_agent_delegation.py`** - Full multi-agent orchestration

Run them:
```bash
# Start an agent
python examples/basic_agent.py

# In another terminal, run the client
python examples/client_example.py

# Or run the multi-agent demo (all-in-one)
python examples/multi_agent_delegation.py
```

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────┐
│           Synqed (High-Level API)           │
├─────────────────────────────────────────────┤
│  Agent │ AgentServer │ Client │ Delegator   │
└──────────────────┬──────────────────────────┘
                   │
        ┌──────────▼──────────┐
        │   A2A Protocol      │
        │  (JSON-RPC/gRPC)    │
        └─────────────────────┘
```

**Why Synqed?**
- 🎯 **Simplified API** - 10x less code than raw A2A
- 🚀 **Faster Development** - Focus on agent logic, not protocol details
- 🔧 **Sensible Defaults** - Works out of the box
- 🔌 **Extensible** - Full access to underlying A2A when needed
- 📚 **Well Documented** - Clear examples and guides

---

## 🛠️ Development

### Project Structure
```
Synq/
├── src/synqed/           # Main package
│   ├── agent.py          # Agent wrapper
│   ├── agent_card.py     # Card builder
│   ├── server.py         # Server wrapper
│   ├── client.py         # Client wrapper
│   └── delegator.py      # Multi-agent coordinator
├── examples/             # Example scripts
├── pyproject.toml        # Package config
└── README.md            # This file
```

### Running Tests
```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Type checking
mypy src/synqed

# Linting
ruff check src/synqed
```

---

## 🤝 Contributing

Contributions are welcome! This is proprietary software - please contact the Synq team for contribution guidelines.

---

## 📄 License

Proprietary License - Copyright © 2025 Synq Team. All rights reserved.

See [LICENSE](LICENSE) for details.

---

## 🔗 Related Projects

- [A2A Protocol](https://a2a-protocol.org) - The underlying protocol
- [A2A Python SDK](https://github.com/a2aproject/a2a-python) - The SDK we wrap

---

## 💬 Support

For questions, issues, or licensing inquiries, please contact the Synq team.

---

**Built with ❤️ by the Synq Team**

