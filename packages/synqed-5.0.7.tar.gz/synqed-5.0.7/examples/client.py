import asyncio
from synqed import Client

async def main():
    async with Client("http://localhost:8000") as client:
        # Test 1: Simple message
        response = await client.send_and_wait("Hi there!")
        print(f"Response: {response}")
        
        # Test 2: Streaming
        print("\nStreaming response:")
        async for chunk in client.send("Tell me a story"):
            print(chunk, end="", flush=True)
        print()

if __name__ == "__main__":
    asyncio.run(main())