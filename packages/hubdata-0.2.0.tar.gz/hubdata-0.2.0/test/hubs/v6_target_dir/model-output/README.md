# Model outputs folder

This folder should contain a set of subdirectories, one for each model, that contains submitted model output files for that model. The structure of the directories and their contents should follow [the model output guidelines in our documentation](https://docs.hubverse.io/en/latest/user-guide/model-output.html).
