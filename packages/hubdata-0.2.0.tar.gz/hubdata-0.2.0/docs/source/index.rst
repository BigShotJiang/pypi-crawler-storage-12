:og:description: hubdata: Python tools for accessing and working with the hubverse

.. hubdata documentation index file,
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. toctree::
   :hidden:
   :maxdepth: 2
   :caption: Contents:

   cli
   usage
   dev
   CONTRIBUTING
   reference/index
   CHANGELOG

.. include:: readme.md
   :parser: myst_parser.sphinx_
