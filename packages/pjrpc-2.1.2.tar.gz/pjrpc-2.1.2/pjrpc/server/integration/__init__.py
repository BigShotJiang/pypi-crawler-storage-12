"""
JSON-RPC server framework integrations.
"""
