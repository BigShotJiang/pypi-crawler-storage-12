"""
JSON-RPC client library integrations.
"""
