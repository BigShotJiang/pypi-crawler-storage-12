Após a instalação do módulo, deve ser configurado a empresa nos seguintes pontos:

* Na aba Fiscal -> Documentos Eletrônicos: Selecionar no campo Processador de Documentos Eletrônicos o registro erpbrasil.edoc.
* Na aba Fiscal -> Certificados: Atribuir um certificado correspondente.
