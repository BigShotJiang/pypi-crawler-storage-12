# click_fit

# Divot Function Documentation

## Overview

Divot is a shaped part with a positive and negative implementation meant for 3d printing applications to "lock" two pieces together. It 
