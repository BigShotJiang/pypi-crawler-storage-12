from authlib.integrations.flask_client import OAuth

from .auth_manager import *
from .authentication import *


oauth = OAuth()
