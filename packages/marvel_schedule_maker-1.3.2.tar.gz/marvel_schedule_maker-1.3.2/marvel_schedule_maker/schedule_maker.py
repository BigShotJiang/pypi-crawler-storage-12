import copy
from functools import partial
import math
import os
from pprint import pprint
import random
import re
from typing import Any, Dict, List, Optional, Type, TypedDict, cast
import inspect
import signal
import sys
import uuid
from astropy.time import Time as AstroTime
from numpy import interp
import marvel_schedule_maker.sequencer_validator as Validator
from .sequencer import Sequencer
from datetime import date, datetime, time, timedelta, timezone
from dataclasses import dataclass
from enum import Enum, auto
import pandas as pd
from marvel_schedule_maker.sequencer_common import DateTimes, ValidatorContext, raDecToAltAz, getMoonAltAz

from PyQt6.QtWidgets import QApplication,QMainWindow,QFormLayout,QWidget,QVBoxLayout,QHBoxLayout,QFrame,QLabel,QComboBox,QTableWidget,QTableWidgetItem,QPushButton,QLineEdit,QSizePolicy,QFileDialog,QScrollArea,QGridLayout, QGraphicsDropShadowEffect, QMenu, QGraphicsOpacityEffect, QSlider, QGraphicsRectItem, QGraphicsTextItem, QGraphicsScene, QGraphicsView, QGraphicsSceneMouseEvent, QGraphicsItem
from PyQt6.QtCore import Qt,QTimer,pyqtSignal,QPropertyAnimation,QPoint,QSize, QObject, QRectF, QPointF, QByteArray
from PyQt6.QtGui import QResizeEvent, QStandardItemModel, QStandardItem, QIntValidator, QFont, QPainter, QColor, QLinearGradient, QPolygon, QPen, QBrush, QRadialGradient, QPixmap
from PyQt6.QtSvg import QSvgRenderer
import pyqtgraph as pg
import qtawesome as qta

# The publish.yml file will adjust this during build
# It releases with the correct version number given in VERSION file
PACKAGE_VERSION = '1.3.2'

# TODO (maybe) show a small red square when starttime = endtime instead of a baraly seeable and clickable redline
# BUG random segmentation fault out of no where some times. (hard to find)
# BUG validatie fout bij start night maar niet bij get temperature bv hmmm...

def create_star_svg_renderer():
    svg_string = """
    <svg viewBox="0 0 24.00 24.00" fill="#ffd500" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 3L14.0357 8.16153C14.2236 8.63799 14.3175 8.87622 14.4614 9.0771C14.5889 9.25516 14.7448 9.41106 14.9229 9.53859C15.1238 9.68245 15.362 9.77641 15.8385 9.96432L21 12L15.8385 14.0357C15.362 14.2236 15.1238 14.3175 14.9229 14.4614C14.7448 14.5889 14.5889 14.7448 14.4614 14.9229C14.3175 15.1238 14.2236 15.362 14.0357 15.8385L12 21L9.96432 15.8385C9.77641 15.362 9.68245 15.1238 9.53859 14.9229C9.41106 14.7448 9.25516 14.5889 9.0771 14.4614C8.87622 14.3175 8.63799 14.2236 8.16153 14.0357L3 12L8.16153 9.96432C8.63799 9.77641 8.87622 9.68245 9.0771 9.53859C9.25516 9.41106 9.41106 9.25516 9.53859 9.0771C9.68245 8.87622 9.77641 8.63799 9.96432 8.16153L12 3Z" stroke="#000000" stroke-width="0.4800000000000001" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>
    """

    return QSvgRenderer(QByteArray(svg_string.encode()))

class AttributeDict(TypedDict):
    type: str
    category: str
    description: str
    position: int
    display_name: str
    duration: str
    validators: dict[str, Type[Validator.BaseClass]]
    timeline_name: str
    
ActionsDict = Dict[str, AttributeDict]

@dataclass
class InputEntry:
    label_widget: QWidget
    icon: QLabel
    input_widget: QWidget
    validator: Validator.BaseClass

def getActionRegistry() -> ActionsDict:
    actions: ActionsDict = {}
    for name, func in inspect.getmembers(Sequencer, predicate=inspect.isfunction):
        if getattr(func, "__is_action_method__", False):
            # Get all attributes of the function except built-ins
            attributes = cast(AttributeDict, {k: v for k, v in func.__dict__.items() if not k.startswith('__')})
            actions[attributes['type']] = attributes
    return actions

ACTION_REGISTRY = getActionRegistry()
ACTION_DURATIONS = {action['type']: action['duration'] for action in ACTION_REGISTRY.values()}

@dataclass
class TimelineEntry:
    id: str
    action_data: dict
    telescope: int
    start_time: datetime
    end_time: datetime

def calculate_timeline(
    entries: list[dict],
    dates: DateTimes
) -> list[TimelineEntry]:
    """
    Pure function to calculate timeline from schedule entries.
    
    Args:
        entries: List of action data dictionaries
        dates: DateTimes instance for time calculations
        
    Returns:
        List of TimelineEntry objects with calculated start/end times
    """
    timeline = []
    current_start_per_telescope: dict[int, datetime] = {
        i: datetime.combine(dates.observation_date, time(12, 0, 0)) 
        for i in range(1,5)
    }
    
    for action_data in entries:
        telescope = action_data.get('telescope', 0)
        
        # Determine start time
        if telescope == 0:
            start_time = max(current_start_per_telescope.values())
        else:
            start_time = current_start_per_telescope[telescope]

        # Calculate end time
        end_time = calculate_end_time(start_time, action_data)
        
        if end_time:
            timeline.append(TimelineEntry(
                id=action_data['id'],
                action_data=action_data,
                telescope=telescope,
                start_time=start_time,
                end_time=end_time
            ))
            
            # Update start times
            if telescope == 0:
                for t in current_start_per_telescope.keys():
                    current_start_per_telescope[t] = end_time
            else:
                current_start_per_telescope[telescope] = end_time
        else:
            print(f"Problem calculating end time for {action_data.get('type')}")
    
    return timeline

def calculate_end_time(
    start_time: datetime,
    action_data: dict
) -> Optional[datetime]:
    """Calculate end time for an action."""
    if not action_data or 'type' not in action_data:
        return start_time + timedelta(seconds=300)
    
    action_type = action_data['type']
    if action_type not in ACTION_DURATIONS:
        return None
    
    # Evaluate duration expression
    duration_expr = ACTION_DURATIONS[action_type]
    for key, value in action_data.items():
        duration_expr = duration_expr.replace(key, str(value))
    duration_expr = duration_expr.strip() or '0'

    try:
        duration_seconds = float(eval(duration_expr))
    except Exception:
        return None

    # Handle timestamp constraints
    if 'until_timestamp' in action_data and action_data['until_timestamp']:
        until_time = datetime.strptime(action_data['until_timestamp'], "%Y-%m-%d %H:%M:%S")
        return min(
            start_time + timedelta(seconds=duration_seconds),
            max(start_time, until_time)
        )
    
    if 'wait_timestamp' in action_data and action_data['wait_timestamp']:
        wait_time = datetime.strptime(action_data['wait_timestamp'], "%Y-%m-%d %H:%M:%S")
        actual_start = max(start_time, wait_time)
        return actual_start + timedelta(seconds=duration_seconds)
    
    return start_time + timedelta(seconds=duration_seconds)

class Schedule(QObject):
    """Schedule data manager - handles CRUD operations on schedule entries."""
    
    data_changed = pyqtSignal()  # Emitted when schedule data changes
    entry_added = pyqtSignal(str) # Emitted when new entry added (entry_id)
    
    def __init__(self):
        super().__init__()
        self._entries: list[dict] = []

    # ==================== Data Access ====================

    def get_entries(self) -> list[dict]:
        """Get all schedule entries."""
        return self._entries

    def get_entry_count(self) -> int:
        """Get number of entries in schedule."""
        return len(self._entries)

    # ==================== ID-Based Lookups ====================
    
    def get_row_by_id(self, entry_id: Optional[str]) -> Optional[int]:
        """Find row index by entry ID."""
        if entry_id is None:
            return None
        for i, entry_data in enumerate(self._entries):
            if entry_data.get('id') == entry_id:
                return i
        return None
    
    def get_data_entry_by_id(self, entry_id: Optional[str]) -> Optional[dict]:
        """Find data entry by ID."""
        if entry_id is None:
            return None
        row = self.get_row_by_id(entry_id)
        if row is not None:
            return self._entries[row]
        return None
    
    def get_timeline_entry_by_id(self, entry_id: Optional[str]) -> Optional[TimelineEntry]:
        """Find timeline entry by ID from AppContext timeline."""
        if entry_id is None:
            return None
        timeline = AppContext.getTimeline()
        for entry in timeline:
            if entry.id == entry_id:
                return entry
        return None
    
    # ==================== CRUD Operations ====================
    
    def add_entry(self, new_data: dict) -> None:
        """Add a new entry to the schedule."""
        new_data['id'] = str(uuid.uuid4())
        self._entries.append(new_data)
        self.data_changed.emit()
        self.entry_added.emit(new_data['id'])
    
    def update_entry(self, entry_id: Optional[str], updated_data: dict) -> None:
        """Update an existing entry."""
        row = self.get_row_by_id(entry_id)
        if row is not None:
            # Preserve the ID
            updated_data['id'] = self._entries[row]['id']
            self._entries[row] = updated_data
            self.data_changed.emit()
    
    def delete_entry(self, entry_id: str) -> None:
        """Delete an entry by ID."""
        row = self.get_row_by_id(entry_id)
        if row is not None:
            del self._entries[row]
            self.data_changed.emit()
    
    def insert_entry_above(self, entry_id: str, new_data: dict) -> None:
        """Insert a new entry above the specified entry."""
        row = self.get_row_by_id(entry_id)
        if row is not None:
            new_data = {k: v for k, v in new_data.items() if k != 'id'}
            new_data['id'] = str(uuid.uuid4())
            self._entries.insert(row, new_data)
            self.data_changed.emit()
            self.entry_added.emit(new_data['id'])

    
    def insert_entry_below(self, entry_id: str, new_data: dict) -> None:
        """Insert a new entry below the specified entry."""
        row = self.get_row_by_id(entry_id)
        if row is not None:
            new_data = {k: v for k, v in new_data.items() if k != 'id'}
            new_data['id'] = str(uuid.uuid4())
            self._entries.insert(row + 1, new_data)
            self.data_changed.emit()
            self.entry_added.emit(new_data['id'])
    
    def move_entry_to(self, entry_id: str, new_index: int) -> None:
        """Move an entry to a new position."""
        row = self.get_row_by_id(entry_id)
        if row is not None and 0 <= new_index < len(self._entries):
            entry_data = self._entries.pop(row)
            self._entries.insert(new_index, entry_data)
            self.data_changed.emit()
    
    def move_entry_up(self, entry_id: str) -> None:
        """Move an entry up one position."""
        row = self.get_row_by_id(entry_id)
        if row is not None and row > 0:
            entry_data = self._entries.pop(row)
            self._entries.insert(row - 1, entry_data)
            self.data_changed.emit()
    
    def move_entry_down(self, entry_id: str) -> None:
        """Move an entry down one position."""
        row = self.get_row_by_id(entry_id)
        if row is not None and row < len(self._entries) - 1:
            entry_data = self._entries.pop(row)
            self._entries.insert(row + 1, entry_data)
            self.data_changed.emit()
    
    # ==================== Schedule File Operations ====================
    
    def new_schedule(self) -> None:
        """Create a new empty schedule."""
        AppContext.get().clear_clipboard()
        AppContext.get().clear_editing_entry()
        self._entries.clear()
        self.data_changed.emit()
    
    def load_schedule(self, filepath: str) -> None:
        """Load schedule from CSV file."""
        df = pd.read_csv(filepath, index_col=False)
        df = df.replace(["", " ", "nan", "NaN", "None"], pd.NA)
        
        # Convert float columns that are really integers
        for col in df.columns:
            if df[col].dtype == float and all(
                df[col].dropna().apply(lambda x: float(x).is_integer())
            ):
                df[col] = df[col].astype("Int64")
        
        records = [
            {k: v for k, v in row.items() if pd.notna(v)}
            for _, row in df.iterrows()
        ]
        
        # Clear UI state
        AppContext.get().clear_clipboard()
        AppContext.get().clear_editing_entry()

        extracted_date = self._extract_date_from_filename(filepath)
        if extracted_date:
            AppContext.getDates().set_date(extracted_date)
        else:
            first_date = self._find_first_date(records)
            if first_date:
                AppContext.getDates().set_date(first_date)
        
        # Load entries
        self.blockSignals(True)
        self._entries.clear()
        for record in records:
            self.add_entry(record)
        self.blockSignals(False)

        self.data_changed.emit()

    def _extract_date_from_filename(self, filepath: str) -> Optional[date]:
        filename = os.path.basename(filepath)

        pattern = r'(\d{8})'
        match = re.search(pattern, filename)

        if match:
            date_str = match.group(1)
        try:
            return datetime.strptime(date_str, "%Y%m%d").date()
        except ValueError:
            return None
        
        return None
    
    def save_schedule(self, filepath: str) -> None:
        """Save schedule to CSV file."""
        if not filepath.lower().endswith('.csv'):
            filepath += '.csv'
        
        try:
            df = pd.DataFrame(self._entries)
            df.to_csv(filepath, index=False)
        except Exception as e:
            print(f"Failed to save CSV: {e}")
    
    # ==================== Helper Methods ====================
    
    def create_default_data(self, telescope: int) -> dict:
        """Create a default action data dictionary."""
        return {
            'id': str(uuid.uuid4()),
            'telescope': telescope
        }
    
    def _find_first_date(self, records: list[dict]) -> Optional[date]:
        """Find the first date from wait_timestamp in records."""
        for record in records:
            if (timestamp := record.get('wait_timestamp')) is not None:
                return datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S").date()
        return None
    
    def update_data_date(self, data: Optional[list[dict]] = None) -> list[dict]:
        """Update timestamps in data to match current observation date."""
        dates = AppContext.getDates()
        observation_date = dates.observation_date
        
        def full_datetime(value_str: str) -> str:
            time_object = datetime.strptime(value_str, "%Y-%m-%d %H:%M:%S").time()
            dt = datetime.combine(observation_date, time_object)
            
            # Add a day if time is before noon
            if time_object < time(12, 0, 0):
                dt += timedelta(days=1)
            
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        
        if data is None:
            data = self._entries
        
        updated_data = []
        for entry in data:
            copied = entry.copy()
            
            if (wait_ts := copied.get('wait_timestamp')) is not None:
                copied['wait_timestamp'] = full_datetime(wait_ts)
            
            if (until_ts := copied.get('until_timestamp')) is not None:
                copied['until_timestamp'] = full_datetime(until_ts)
            
            updated_data.append(copied)
        
        self.data_changed.emit()
        return updated_data

class ToastNotification(QFrame):
    """Toast notification widget that appears temporarily at the top of the window."""

    class Type(Enum):
        SUCCESS = auto()
        ERROR = auto()
        WARNING = auto()
    
    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self._parent = parent
        
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(20, 15, 20, 15)
        main_layout.setSpacing(15)
        
        # Icon Label
        self.icon_label = QLabel()
        self.icon_label.setFixedSize(28, 28)
        self.icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Message label
        self.message_label = QLabel()
        self.message_label.setStyleSheet("""
            font-size: 14px;
            font-weight: 500;
        """)
        self.message_label.setWordWrap(False)
        
        main_layout.addWidget(self.icon_label)
        main_layout.addWidget(self.message_label)
        
        # Shadow effect
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setXOffset(0)
        shadow.setYOffset(4)
        shadow.setColor(QColor(0, 0, 0, 100))
        self.setGraphicsEffect(shadow)
        
        # Timer for auto-hide
        self.hide_timer = QTimer(self)
        self.hide_timer.setSingleShot(True)
        self.hide_timer.timeout.connect(self.hide)
        
        # Initially hidden
        self.hide()
    

    def show_message(self, message: str, notification_type: Type = Type.SUCCESS):
        """Show a toast notification with the given message and type."""
        # Set icon and color based on type
        if notification_type == ToastNotification.Type.SUCCESS:
            self.icon_label.setText("✓")
            self.icon_label.setStyleSheet("""
                font-size: 22px;
                font-weight: bold;
                color: #28a745;
            """)
            icon_color = "#28a745"
        elif notification_type == ToastNotification.Type.ERROR:
            self.icon_label.setText("✖")
            self.icon_label.setStyleSheet("""
                font-size: 20px;
                font-weight: bold;
                color: #dc3545;
            """)
            icon_color = "#dc3545"
        else:  # WARNING
            self.icon_label.setText("⚠")
            self.icon_label.setStyleSheet("""
                font-size: 22px;
                font-weight: bold;
                color: #ffc107;
            """)
            icon_color = "#ffc107"
        
        # Set message
        self.message_label.setText(message)
        
        # Update container styling
        self.setStyleSheet(f"""
            ToastNotification {{
                background-color: white;
                border: 2px solid {icon_color};
                border-radius: 10px;
            }}
        """)
        
        # Position and show
        self.adjustSize()

        # Position at horizontal center, 20px from top
        x = (self._parent.width() - self.width()) // 2
        y = 20
        
        self.move(x, y)
        self.show()
        self.raise_()
        
        # Auto-hide after 3 seconds
        self.hide_timer.start(3000)

class AppContext(QObject):
    """Global application context for shared services."""
    _instance = None

    # Signals
    action_type_changed = pyqtSignal()
    observation_date_changed = pyqtSignal() 
    timeline_updated = pyqtSignal()
    clipboard_updated = pyqtSignal()
    editing_state_changed = pyqtSignal()

    def __new__(cls):
        """Ensure singleton pattern with thread safety."""
        if cls._instance is None:
            cls._instance = super(AppContext, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        """Initialize context (only once due to singleton)."""
        if not self._initialized:
            super().__init__()
            self._initialized = True
        
            # Services
            self.schedule: Optional[Schedule] = None
            self.toast: Optional[ToastNotification] = None
            
            # Configuration
            self.dates: Optional[DateTimes] = None
            
            # Computed state
            self.timeline: list[TimelineEntry] = []
            
            # UI state
            self.clipboard: Optional[dict] = None
            self.copied_entry_id: Optional[str] = None
            self.editing_entry_id: Optional[str] = None
            self.selected_action_type: Optional[str] = None
            
            # Validation
            self.validator_context: Optional[ValidatorContext] = None

    @classmethod
    def get(cls) -> 'AppContext':
        """Get the singleton instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    @classmethod
    def initialize(cls, parent: QWidget) -> None:
        """Initialize the context with services and configuration.."""
        ctx = cls.get()
        
        if ctx.schedule is not None:
            raise RuntimeError("AppContext already initialized")

        ctx.schedule = Schedule()
        ctx.toast = ToastNotification(parent)
        ctx.dates = DateTimes(date.today())
        ctx.validator_context = ValidatorContext(ctx.dates)

        # Set up callbacks
        def _on_date_changed():
            if ctx.schedule and ctx.dates:
                ctx.validator_context = ValidatorContext(ctx.dates)
                ctx.observation_date_changed.emit()
                ctx.schedule.update_data_date()

        def _on_schedule_data_changed():
            if ctx.schedule and ctx.dates:
                ctx.timeline = calculate_timeline(
                    ctx.schedule.get_entries(),
                    ctx.dates
                )
                ctx.timeline_updated.emit()

        ctx.dates.set_change_callback(_on_date_changed)
        ctx.schedule.data_changed.connect(_on_schedule_data_changed)
        
        _on_schedule_data_changed()

    # ==================== Service Getters ====================
    
    @classmethod
    def getSchedule(cls) -> Schedule:
        ctx = cls.get()
        if ctx.schedule is None:
            raise RuntimeError("AppContext not initialized. Call AppContext.initialize() first.")
        return ctx.schedule
    
    @classmethod
    def getToast(cls) -> ToastNotification:
        ctx = cls.get()
        if ctx.toast is None:
            raise RuntimeError("AppContext not initialized. Call AppContext.initialize() first.")
        return ctx.toast

    @classmethod
    def getDates(cls) -> DateTimes:
        ctx = cls.get()
        if ctx.dates is None:
            raise RuntimeError("AppContext not initialized. Call AppContext.initialize() first.")
        return ctx.dates
        
    @classmethod
    def getValidatorContext(cls) -> ValidatorContext:
        ctx = cls.get()
        if ctx.validator_context is None:
            raise RuntimeError("ValidatorContext not initialized. Call AppContext.initialize() first.")
        return ctx.validator_context

    @classmethod
    def getTimeline(cls) -> list[TimelineEntry]:
        """Get the computed timeline"""
        ctx = cls.get()
        return ctx.timeline

    # ==================== Clipboard Management ====================
    
    def set_clipboard(self, data: dict, entry_id: str):
        cleansed_data = {k:v for k,v in data.items() if k != 'id'}
        self.clipboard = cleansed_data
        self.copied_entry_id = entry_id
        self.clipboard_updated.emit()
    
    def get_clipboard(self) -> Optional[dict]:
        return self.clipboard
    
    def has_clipboard(self) -> bool:
        return self.clipboard is not None
    
    def clear_clipboard(self):
        self.clipboard = None
        self.copied_entry_id = None
        self.clipboard_updated.emit()
    
    # ==================== Editing State Management ====================

    def set_editing_entry(self, entry_id: Optional[str]):
        if entry_id != self.editing_entry_id:
            self.editing_entry_id = entry_id
            self.editing_state_changed.emit()

    def get_editing_entry_id(self) -> Optional[str]:
        return self.editing_entry_id

    def clear_editing_entry(self):
        self.set_editing_entry(None)
    
    # ==================== Action Type Management ====================

    def set_action_type(self, action_type: Optional[str]):
        if action_type != self.selected_action_type:
            self.selected_action_type = action_type
            if self.validator_context is not None:
                self.validator_context.clear()
            self.action_type_changed.emit()

    def get_action_type(self) -> Optional[str]:
        return self.selected_action_type

    def get_action_info(self) -> Optional[AttributeDict]:
        if self.selected_action_type is None:
            return None
        return ACTION_REGISTRY[self.selected_action_type]

    def clear_action_type(self):
        self.set_action_type(None)

class SettingsModal(QWidget):
    """Closed modal overlay with centered dialog."""

    closed = pyqtSignal()
    
    def __init__(self, parent: QWidget):
        super().__init__(parent)
        
        self.toast = AppContext.getToast()
        
        # Main layout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Modal dialog frame
        self.dialog = QFrame()
        self.dialog.setFixedSize(1000, 700)
        self.dialog.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                border: 1px solid #dee2e6;
            }
        """)
        
        # Dialog layout
        dialog_layout = QVBoxLayout(self.dialog)
        dialog_layout.setContentsMargins(0, 0, 0, 0)
        dialog_layout.setSpacing(0)
        
        # Header with close button
        header = QWidget()
        header.setFixedHeight(50)
        header.setStyleSheet("background-color: #f8f9fa; border-radius: 12px 12px 0 0;")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(20, 10, 10, 10)
        
        title_label = QLabel("Settings")
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #212529;")
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        
        close_button = QPushButton()
        close_button.setIcon(qta.icon('fa6s.xmark', color='#6c757d'))
        close_button.setIconSize(QSize(20, 20))
        close_button.setFixedSize(30, 30)
        close_button.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                border-radius: 15px;
            }
            QPushButton:hover {
                color: "#fff";
                background-color: #e9ecef;
            }
        """)
        close_button.clicked.connect(self.close_modal)
        header_layout.addWidget(close_button)
        
        dialog_layout.addWidget(header)
        
        # Content area with sidebar and content panels
        content_container = QWidget()
        content_container.setStyleSheet("background-color: white;")
        content_layout = QHBoxLayout(content_container)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)
        
        # Sidebar (250px)
        self.sidebar = SettingsSidebar()
        self.sidebar.option_clicked.connect(self._on_option_changed)
        content_layout.addWidget(self.sidebar)
        
        # Content area (750px)
        self.content = SettingsContent()
        content_layout.addWidget(self.content, stretch=1)
        
        dialog_layout.addWidget(content_container)
        
        main_layout.addWidget(self.dialog)
        
        # Animation for fade in/out
        self.opacity_effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.opacity_effect)
        
        self.fade_animation = QPropertyAnimation(self.opacity_effect, b"opacity")
        self.fade_animation.setDuration(200)
        self.fade_animation.finished.connect(self._on_animation_finished)
        
        self._closing = False

        self.hide()
    
    def _on_option_changed(self, option_name: str):
        """Handle sidebar option selection."""
        self.content.show_panel(option_name)

    def paintEvent(self, event):
        """Paint semi-transparent overlay background."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Semi-transparent black background
        painter.fillRect(self.rect(), QColor(0, 0, 0, 127))  # 50% opacity
    
    def mousePressEvent(self, event):
        """Close modal when clicking outside the dialog."""
        # Check if click is outside dialog bounds
        dialog_rect = self.dialog.geometry()
        click_pos = event.pos()
        
        if not dialog_rect.contains(click_pos):
            self.close_modal()
    
    def keyPressEvent(self, event):
        """Handle ESC key to close modal."""
        if event.key() == Qt.Key.Key_Escape:
            self.close_modal()
        else:
            super().keyPressEvent(event)
    
    def show_modal(self):
        """Show the modal with fade-in animation."""
        self.resize()
        self.show()
        self.raise_()
        
        # Fade in
        self.opacity_effect.setOpacity(0)
        self.fade_animation.setStartValue(0.0)
        self.fade_animation.setEndValue(1.0)
        self.fade_animation.start()
    
    def resize(self):
        """Resize the window. Also gets triggered when mainwindow resizes."""
        if self.parent():
            # Resize to parent size
            parent_rect = self.parent().rect()  # type: ignore
            self.setGeometry(parent_rect)
            
            # Calculate dialog size: 90% of parent, but minimum 1000x700 if possible
            parent_width = parent_rect.width()
            parent_height = parent_rect.height()
            
            # Desired size
            desired_width = 1000
            desired_height = 700
            
            # Maximum size (90% of parent)
            max_width = int(parent_width * 0.9)
            max_height = int(parent_height * 0.9)
            
            # Use minimum of desired and maximum
            dialog_width = min(desired_width, max_width)
            dialog_height = min(desired_height, max_height)
            
            self.dialog.setFixedSize(dialog_width, dialog_height)

    def close_modal(self):
        """Close the modal with fade-out animation."""
        if self._closing:
            return
        
        self._closing = True
        
        # Fade out
        self.fade_animation.setStartValue(1.0)
        self.fade_animation.setEndValue(0.0)
        self.fade_animation.start()
    
    def _on_animation_finished(self):
        """Handle animation completion."""
        if self._closing:
            self.hide()
            self.closed.emit()
            self._closing = False

class SettingsSidebar(QWidget):
    """Navigation sidebar for settings modal."""
    
    option_clicked = pyqtSignal(str)  # Emits option name when clicked
    
    def __init__(self):
        super().__init__()

        self.setFixedWidth(250)
        self.setStyleSheet("background-color: #f8f9fa;")
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Navigation items
        self.buttons: dict[str, QPushButton] = {}
        self.current_selection: Optional[str] = None
        
        # Add navigation options
        options = ["Object Names"]
        
        for option_name in options:
            button = self._create_nav_button(option_name)
            self.buttons[option_name] = button
            layout.addWidget(button)
        
        layout.addStretch()
        
        # Select first option by default
        if options:
            self.select_option(options[0])
    
    def _create_nav_button(self, text: str) -> QPushButton:
        """Create a navigation button with icon and text."""
        button = QPushButton()
        button.setText(text)
        button.setFixedHeight(50)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        
        # Default style
        button.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                text-align: left;
                padding-left: 20px;
                font-size: 14px;
                color: #495057;
            }
            QPushButton:hover {
                background-color: #e9ecef;
            }
        """)
        
        button.clicked.connect(lambda: self._on_button_clicked(text))
        return button
    
    def _on_button_clicked(self, option_name: str):
        """Handle button click."""
        self.select_option(option_name)
        self.option_clicked.emit(option_name)
    
    def select_option(self, option_name: str):
        """Visually select an option."""
        if option_name not in self.buttons:
            return
        
        # Reset all buttons to default style
        for name, button in self.buttons.items():
            if name == option_name:
                # Selected style
                button.setStyleSheet("""
                    QPushButton {
                        background-color: #2196f3;
                        border: none;
                        text-align: left;
                        padding-left: 20px;
                        font-size: 14px;
                        color: white;
                        font-weight: bold;
                    }
                """)
            else:
                # Default style
                button.setStyleSheet("""
                    QPushButton {
                        background-color: transparent;
                        border: none;
                        text-align: left;
                        padding-left: 20px;
                        font-size: 14px;
                        color: #495057;
                    }
                    QPushButton:hover {
                        background-color: #e9ecef;
                    }
                """)
        
        self.current_selection = option_name

class SettingsContent(QWidget):
    """Content area that switches between different settings panels."""
    
    def __init__(self):
        super().__init__()
        
        # Main layout
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)
        
        # Store panels
        self.panels: dict[str, QWidget] = {}
        self.current_panel: Optional[QWidget] = None
        
        # Create panels
        self.panels["Object Names"] = ObjectNamesPanel()
        
        # Show default panel
        self.show_panel("Object Names")
    
    def show_panel(self, panel_name: str):
        """Switch to a different panel."""
        if panel_name not in self.panels:
            return
        
        # Remove current panel
        if self.current_panel:
            self.main_layout.removeWidget(self.current_panel)
            self.current_panel.hide()
        
        # Show new panel
        new_panel = self.panels[panel_name]
        self.main_layout.addWidget(new_panel)
        new_panel.show()
        self.current_panel = new_panel

class ObjectNamesPanel(QWidget):
    """Panel for editing the OBJECT_CATALOG."""
    
    def __init__(self):
        super().__init__()

        self.object_catalog = Validator.ObjectCatalog()
        self.toast = AppContext.getToast()
        
        # Main layout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(30, 30, 30, 30)
        main_layout.setSpacing(20)
        
        # Title
        title = QLabel("Object Catalog")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #212529;")
        main_layout.addWidget(title)
        
        # Description
        description = QLabel("Manage astronomical objects in your catalog. RADEC can be auto filled by objectname.")
        description.setWordWrap(True)
        description.setStyleSheet("font-size: 13px; color: #6c757d; margin-bottom: 10px;")
        main_layout.addWidget(description)
        
        # Button bar
        button_bar = QWidget()
        button_layout = QHBoxLayout(button_bar)
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.setSpacing(10)
        
        add_button = QPushButton("Add Object")
        add_button.setIcon(qta.icon('fa6s.plus', color='white'))
        add_button.setIconSize(QSize(16, 16))
        add_button.setStyleSheet("""
            QPushButton {
                background-color: #28a745;
                color: white;
                padding: 8px 16px;
                border-radius: 5px;
                font-weight: bold;
                border: none;
            }
            QPushButton:hover {
                background-color: #218838;
            }
        """)
        add_button.clicked.connect(self._on_add_object)
        
        remove_button = QPushButton("Remove Selected")
        remove_button.setIcon(qta.icon('fa6s.trash', color='white'))
        remove_button.setIconSize(QSize(16, 16))
        remove_button.setStyleSheet("""
            QPushButton {
                background-color: #dc3545;
                color: white;
                padding: 8px 16px;
                border-radius: 5px;
                font-weight: bold;
                border: none;
            }
            QPushButton:hover {
                background-color: #c82333;
            }
        """)
        remove_button.clicked.connect(self._on_remove_object)
        
        button_layout.addWidget(add_button)
        button_layout.addWidget(remove_button)
        button_layout.addStretch()
        
        main_layout.addWidget(button_bar)
        
        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Object Name", "RA", "DEC"])
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.setStyleSheet("""
            QHeaderView::section {
                padding-left: 15px;
                padding-right: 15px;
            }
        """)
        
        main_layout.addWidget(self.table)
        
        # Save button at bottom
        save_button = QPushButton("Save Changes")
        save_button.setIcon(qta.icon('fa6s.floppy-disk', color='white'))
        save_button.setIconSize(QSize(16, 16))
        save_button.setStyleSheet("""
            QPushButton {
                background-color: #007bff;
                color: white;
                padding: 10px 20px;
                border-radius: 5px;
                font-weight: bold;
                border: none;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
        """)
        save_button.clicked.connect(self._on_save)
        
        button_container = QWidget()
        button_container_layout = QHBoxLayout(button_container)
        button_container_layout.setContentsMargins(0, 0, 0, 0)
        button_container_layout.addStretch()
        button_container_layout.addWidget(save_button)
        
        main_layout.addWidget(button_container)
    
    def _load_catalog(self):
        """Load into the table."""
        all_objects = self.object_catalog.get_all()
        
        self.table.setRowCount(len(all_objects))
        
        for row, (name, coords) in enumerate(sorted(all_objects.items())):
            # Object name
            name_item = QTableWidgetItem(name)
            self.table.setItem(row, 0, name_item)
            
            # RA
            ra_item = QTableWidgetItem(str(coords.RA))
            self.table.setItem(row, 1, ra_item)
            
            # DEC
            dec_item = QTableWidgetItem(str(coords.DEC))
            self.table.setItem(row, 2, dec_item)
        
        self.table.resizeColumnsToContents()
    
    def _on_add_object(self):
        """Add a new row to the table."""
        row_count = self.table.rowCount()
        self.table.insertRow(row_count)
        
        # Set default values
        self.table.setItem(row_count, 0, QTableWidgetItem("NEW_OBJECT"))
        self.table.setItem(row_count, 1, QTableWidgetItem("0.0"))
        self.table.setItem(row_count, 2, QTableWidgetItem("0.0"))
        
        # Select the new row for editing
        self.table.selectRow(row_count)
        self.table.editItem(self.table.item(row_count, 0))
    
    def _on_remove_object(self):
        """Remove selected rows from the table."""
        selected_rows = set()
        for item in self.table.selectedItems():
            selected_rows.add(item.row())
        
        if not selected_rows:
            self.toast.show_message("No rows selected", ToastNotification.Type.WARNING)
            return
        
        # Remove rows in reverse order to avoid index issues
        for row in sorted(selected_rows, reverse=True):
            self.table.removeRow(row)

        self.toast.show_message(f"Removed {len(selected_rows)} row(s)", ToastNotification.Type.SUCCESS)

    def _on_save(self):
        """Save the table data."""
        
        self.object_catalog.clear()

        errors = []
        
        for row in range(self.table.rowCount()):
            name_item = self.table.item(row, 0)
            ra_item = self.table.item(row, 1)
            dec_item = self.table.item(row, 2)
            
            if not name_item or not ra_item or not dec_item:
                errors.append(f"Row {row + 1}: Missing data")
                return
            
            name = name_item.text().strip()
            ra = ra_item.text().strip()
            dec = dec_item.text().strip()
            
            if not name:
                errors.append(f"Row {row + 1}: Empty object name")
                continue
            
            try:
                ra_parsed = Validator.Ra.parse(ra)
                dec_parsed = Validator.Dec.parse(dec)

                if ra_parsed is None or dec_parsed is None:
                    errors.append(f"Row {row + 1} ({name}): Invalid RA/DEC format")
                    continue

            except Exception as e:
                errors.append(f"Row {row + 1} ({name}): {str(e)}")
                continue
            
            success = self.object_catalog.add(name, ra, dec)
            if not success:
                errors.append(f"Row {row + 1} ({name}): Failed to add")
        

        # Show results
        if errors:
            error_msg = "\n".join(errors[:5])  # Show first 5 errors
            if len(errors) > 5:
                error_msg += f"\n... and {len(errors) - 5} more errors"
            self.toast.show_message(f"Saved with errors:\n{error_msg}", ToastNotification.Type.WARNING)
        else:
            catalog_count = len(self.object_catalog)
            self.toast.show_message(
                f"Successfully saved {catalog_count} object(s) to catalog", 
                ToastNotification.Type.SUCCESS
            )
        
        # Reload table to show what was actually saved
        self._load_catalog()
    
    def _show_toast(self, message: str, toast_type: ToastNotification.Type = ToastNotification.Type.SUCCESS):
        """Show a toast notification."""
        AppContext.getToast().show_message(message, toast_type)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle(f"Marvel Schedule Maker {PACKAGE_VERSION}")

        AppContext.initialize(self)

        # Central widget in vertical layout
        central_widget = QWidget()
        root_layout = QHBoxLayout(central_widget)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        content_layout = QVBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        toolBar = TopBar()
        toolBar.settings_requested.connect(self.open_settings)
        
        self.actionPanel = ActionPanel()
        self.viewPanel = ViewPanel()

        root_layout.addWidget(self.actionPanel)
        self.actionPanel.setMinimumWidth(450)
        root_layout.addLayout(content_layout, stretch=1)

        content_layout.addWidget(toolBar)
        content_layout.addWidget(self.viewPanel, stretch=1)
        
        self.setCentralWidget(central_widget)

        self.settings_modal = SettingsModal(central_widget)
        self.settings_modal.closed.connect(self._on_settings_closed)
        
        self.showMaximized()

    def resizeEvent(self, a0: QResizeEvent | None) -> None:
        super().resizeEvent(a0)
        if self.settings_modal and self.settings_modal.isVisible():
            self.settings_modal.resize()

    def open_settings(self):
        """Open the settings modal."""
        self.settings_modal.show_modal()

    def _on_settings_closed(self):
        """When modal closes this part will be triggered to maybe reload data or ui stuff"""
        pass

class TopBar(QFrame):
    settings_requested = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setFrameShape(QFrame.Shape.StyledPanel)

        self.schedule = AppContext.getSchedule()

        self.main_layout = QHBoxLayout()

        buttons_size = QSize(32,32)

        new_icon = qta.icon('fa6.file')
        new_button = QPushButton()
        new_button.setIcon(new_icon)
        new_button.setIconSize(buttons_size)
        new_button.clicked.connect(self.on_new)

        load_icon = qta.icon('fa6.folder-open')
        load_button = QPushButton()
        load_button.setIcon(load_icon)
        load_button.setIconSize(buttons_size)
        load_button.clicked.connect(self.on_load)

        save_icon = qta.icon('fa6.floppy-disk')
        save_button = QPushButton()
        save_button.setIcon(save_icon)
        save_button.setIconSize(buttons_size)
        save_button.clicked.connect(self.on_save)

        settings_icon = qta.icon('fa6s.gear')
        settings_button = QPushButton()
        settings_button.setIcon(settings_icon)
        settings_button.setIconSize(buttons_size)
        settings_button.clicked.connect(self.open_settings)

        timesShower = DateTimeBar()

        self.main_layout.addWidget(timesShower)
        self.main_layout.addStretch()
        self.main_layout.addWidget(new_button)
        self.main_layout.addWidget(load_button)
        self.main_layout.addWidget(save_button)
        self.main_layout.addWidget(settings_button)

        self.setLayout(self.main_layout)

    def clear_layout(self):
        while self.main_layout.count():
            item = self.main_layout.takeAt(0)
            if item is not None:
                widget = item.widget()
                if widget is not None:
                    widget.deleteLater()

    def refresh(self):
        self.clear_layout()

    def on_new(self):
        self.schedule.new_schedule()

    def on_load(self):
        filepath, _ = QFileDialog.getOpenFileName(
            None,
            "Open CSV",
            "",
            "CSV Files (*.csv)"
        )
        if filepath:
            self.schedule.load_schedule(filepath)

    def on_save(self):
        observation_date = AppContext.getDates().observation_date
        suggested_filename = observation_date.strftime("scheduler_%Y%m%d.csv")

        filepath, _ = QFileDialog.getSaveFileName(
            None,
            "Save CSV",
            suggested_filename,
            "CSV Files (*.csv)"
        )
        if filepath:
            self.schedule.save_schedule(filepath)

    def open_settings(self):
        """Emit signal to request settings modal to open."""
        self.settings_requested.emit()

class ViewPanel(QFrame):

    def __init__(self):
        super().__init__()
        self.setFrameShape(QFrame.Shape.StyledPanel)

        layout = QVBoxLayout(self)
        
        view = TimelineViewer()

        layout.addWidget(view)

class ActionPanel(QFrame):
    def __init__(self):
        super().__init__()
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setFixedWidth(400)

        # App context references
        self.app_ctx = AppContext.get()
        self.schedule = AppContext.getSchedule()
        self.toast = AppContext.getToast()
        self.validator_context = AppContext.getValidatorContext()

        # form references
        self.input_form: Optional[InputForm] = None
        self.description_widget: Optional[ActionDescription] = None
        self.observe_graph: Optional[ObserveGraph] = None

        # Signals
        AppContext.get().editing_state_changed.connect(self._on_editing_changed)
        AppContext.get().action_type_changed.connect(self.refresh)

        # Scroll area setup
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        scroll_area.setStyleSheet("""
            /* Chrome-style scrollbar */
            QScrollBar:vertical {
                background: transparent;
                width: 14px;
                margin: 0px;
                border: none;
            }
            
            QScrollBar::handle:vertical {
                background: #5f6368;
                min-height: 30px;
                margin: 2px 2px 2px 2px;
                border-radius: 7px;
            }
            
            QScrollBar::handle:vertical:hover {
                background: #80868b;
            }
            
            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                border: none;
                background: none;
                height: 0px;
            }
            
            QScrollBar::add-page:vertical,
            QScrollBar::sub-page:vertical {
                background: transparent;
            }
            
            QScrollBar::up-arrow:vertical,
            QScrollBar::down-arrow:vertical {
                background: none;
            }
        """)
        scroll_content = QWidget()

        # Main Layout
        self.main_layout = QVBoxLayout(scroll_content)
        self.main_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.main_layout.setContentsMargins(10, 10, 10, 10)
        self.main_layout.setSpacing(15)

        # Action Picker at the top
        self.action_picker = ActionPicker()
        font = self.action_picker.font()
        font.setPointSize(18)
        self.action_picker.setFont(font)
        self.main_layout.addWidget(self.action_picker)

        # Container for dynamic content
        self.content_widget: Optional[QWidget] = None

        # Add action buttons at top
        self.button_container = QWidget()
        button_layout = QHBoxLayout(self.button_container)
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.setSpacing(10)

        self.insert_button = QPushButton("Insert New")
        self.insert_button.setStyleSheet("""
            QPushButton {
                background-color: #28a745;
                color: white;
                padding: 10px 20px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #218838;
            }
        """)
        self.insert_button.clicked.connect(self._on_insert_clicked)

        self.save_button = QPushButton("Save Changes")
        self.save_button.setStyleSheet("""
            QPushButton {
                background-color: #007bff;
                color: white;
                padding: 10px 20px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
        """)
        self.save_button.clicked.connect(self._on_save_clicked)

        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.setStyleSheet("""
            QPushButton {
                background-color: #6c757d;
                color: white;
                padding: 10px 20px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #5a6268;
            }
        """)
        self.cancel_button.clicked.connect(self._on_cancel_clicked)

        self.btn_up = QPushButton("▲")
        self.btn_down = QPushButton("▼")
        self.btn_down.setFixedWidth(30)
        self.btn_up.setFixedWidth(30)

        self.row_input = QLineEdit()
        self.row_input.setFixedWidth(45)
        onlyAvailableRows = QIntValidator(0, 9999)
        self.row_input.setValidator(onlyAvailableRows)
        self.row_input.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.btn_up.clicked.connect(self._on_button_up)
        self.btn_down.clicked.connect(self._on_button_down)
        self.row_input.returnPressed.connect(self._on_return_pressed)

        button_layout.addWidget(self.cancel_button)
        button_layout.addStretch()
        button_layout.addWidget(self.btn_up)
        button_layout.addWidget(self.row_input)
        button_layout.addWidget(self.btn_down)
        button_layout.addStretch()
        button_layout.addWidget(self.insert_button)
        button_layout.addWidget(self.save_button)

        self.main_layout.addWidget(self.button_container)

        scroll_area.setWidget(scroll_content)

        panel_layout = QVBoxLayout(self)
        panel_layout.setContentsMargins(0, 0, 0, 0)
        panel_layout.addWidget(scroll_area)

        self.refresh()

    # ==================== Properties ====================

    @property
    def is_editing(self) -> bool:
        """Check if currently editing an entry."""
        return self.app_ctx.get_editing_entry_id() is not None

    @property
    def current_action_type(self) -> Optional[str]:
        """Get current action type."""
        return self.app_ctx.get_action_type()

    @property
    def current_action_info(self) -> Optional[AttributeDict]:
        """Get current action info."""
        return self.app_ctx.get_action_info()


    # ==================== UI State Management ====================

    def _update_button_visability(self):
        is_editing = AppContext.get().get_editing_entry_id() is not None
        has_action = AppContext.get().get_action_type() is not None

        self.insert_button.setVisible(has_action and not is_editing)

        self.save_button.setVisible(has_action and is_editing)
        self.cancel_button.setVisible(has_action and is_editing)
        self.btn_up.setVisible(has_action and is_editing)
        self.btn_down.setVisible(has_action and is_editing)
        self.row_input.setVisible(has_action and is_editing)

    def _on_editing_changed(self):
        entry_id = AppContext.get().get_editing_entry_id()
        if entry_id is None:
            self.row_input.clear()
        
        row = self.schedule.get_row_by_id(entry_id)
        if row is None:
            self.row_input.clear()
        
        self.row_input.setText(str(row))
        
        self.refresh()
    
    # ==================== Content Management ====================

    def clear_content(self):
        if self.content_widget:
            self.main_layout.removeWidget(self.content_widget)
            self.content_widget.deleteLater()
            self.content_widget = None

        self.input_form = None
        self.description_widget = None
        self.observe_graph = None

    def refresh(self):
        self.clear_content()
        self._update_button_visability()

        action_type = self.current_action_type
        entry_id = self.app_ctx.get_editing_entry_id()

        if not action_type:
            label = QLabel("Select an action from the dropdown above.")
            label.setStyleSheet("color: #666; font-style: italic; padding: 20px;")
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.content_widget = label
            self.main_layout.addWidget(self.content_widget)
            return
        
        action_info = self.current_action_info
        if not action_info:
            label = QLabel(f"Action '{action_type}' not found in registry.")
            label.setStyleSheet("color: #666; font-style: italic; padding: 20px;")
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.content_widget = label
            self.main_layout.addWidget(self.content_widget)
            return

        content = QWidget()
        content_layout = QVBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(15)
        content.setLayout(content_layout)

        # Show edit text if editing
        if entry_id is not None:
            edit_label = QLabel(f"Editing Entry #{self.schedule.get_row_by_id(entry_id)}")
            edit_label.setStyleSheet("""
                background-color: #fff3cd;
                color: #856404;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
                border: 1px solid #ffeaa7;
            """)
            content_layout.addWidget(edit_label)

        self.input_form = InputForm(action_info)
        content_layout.addWidget(self.input_form)

        self.description_widget = ActionDescription(action_info["description"])
        content_layout.addWidget(self.description_widget)

        if action_type == 'OBSERVE':
            observe_graph = ObserveGraph()
            content_layout.addWidget(observe_graph)

        content_layout.addStretch()

        self.content_widget = content
        self.main_layout.addWidget(self.content_widget)
        

    # ==================== Button Handlers ====================

    def _on_insert_clicked(self):
        """Handle insert new entry."""
        if not self.input_form:
            return
        
        if not self.input_form.validate_all():
            self._show_validation_error(self.insert_button)
            return

        action_type = self.current_action_type
        if not action_type:
            return
        
        pprint(self.validator_context.get_full_all())

        new_entry = self.validator_context.get_full_all()
        new_entry['type'] = action_type
        new_entry['done'] = Validator.StatusValue.WAITING
        
        self.schedule.add_entry(new_entry)
        self._show_toast(f"Inserted new {action_type} entry")
        
        self.app_ctx.clear_editing_entry()

    def _on_save_clicked(self):
        """Handle save changes to existing entry."""
        entry_id = self.app_ctx.get_editing_entry_id()
        if not entry_id:
            return

        if not self.input_form:
            return
        
        if not self.input_form.validate_all():
            self._show_validation_error(self.save_button)
            return

        action_info = self.current_action_info
        if not action_info:
            return

        updated_entry = self.validator_context.get_full_all()
        updated_entry['type'] = self.current_action_type
        updated_entry['done'] = action_info.get('done', Validator.StatusValue.WAITING)
        
        self.schedule.update_entry(entry_id, updated_entry)
        
        row = self.schedule.get_row_by_id(entry_id)
        self._show_toast(f"Saved changes to entry #{row}")
        self._reset_to_insert_mode()

    def _on_cancel_clicked(self):
        """Cancel editing and return to insert mode."""
        self._show_toast("Edit cancelled")
        self._reset_to_insert_mode()

    def _reset_to_insert_mode(self):
        """Reset panel to insert mode."""
        self.app_ctx.clear_editing_entry()

    def _on_button_up(self):
        entry_id = self.app_ctx.get_editing_entry_id()
        if entry_id:
            self.schedule.move_entry_up(entry_id)
            self._update_row_display(entry_id)

    def _on_button_down(self):
        entry_id = self.app_ctx.get_editing_entry_id()
        if entry_id:
            self.schedule.move_entry_down(entry_id)
            self._update_row_display(entry_id)

    def _on_return_pressed(self):
        entry_id = self.app_ctx.get_editing_entry_id()
        if not entry_id:
            return
        
        new_index = self._validate_row_input()
        if new_index is not None:
            self.schedule.move_entry_to(entry_id, new_index)
            self._show_validation_feedback(True)
        else:
            self._show_validation_feedback(False)

    # ==================== Helper Methods ====================

    def _validate_row_input(self) -> Optional[int]:
        text = self.row_input.text().strip()
        if not text:
            return None

        try:
            new_index = int(text)
        except ValueError:
            return None

        # Check bounds
        max_index = self.schedule.get_entry_count() - 1
        if 0 <= new_index <= max_index:
            return new_index
        
        return None

    def _update_row_display(self, entry_id: str):
        row = self.schedule.get_row_by_id(entry_id)
        if row is not None:
            self.row_input.setText(str(row))

    def _show_validation_error(self, button: QPushButton):
        """Show validation error feedback."""
        original_text = button.text()
        original_geometry = button.geometry()

        button.setText("Fix Invalid")
        button.adjustSize()
        button.setDisabled(True)

        # Restore button after delay
        QTimer.singleShot(1500, lambda: (
            button.setText(original_text),
            button.adjustSize(),
            button.setDisabled(False)
        ))
        
        # Shaker
        self._shake_anim = QPropertyAnimation(button, b"geometry")
        self._shake_anim.setDuration(500)
        self._shake_anim.setKeyValueAt(0, original_geometry)
        self._shake_anim.setKeyValueAt(0.1, original_geometry.translated(-10, 0))
        self._shake_anim.setKeyValueAt(0.2, original_geometry.translated(00, 0))
        self._shake_anim.setKeyValueAt(0.3, original_geometry.translated(-10, 0))
        self._shake_anim.setKeyValueAt(0.4, original_geometry.translated(00, 0))
        self._shake_anim.setKeyValueAt(0.5, original_geometry)
        self._shake_anim.setEndValue(original_geometry)
        self._shake_anim.start()

    def _show_validation_feedback(self, success: bool):
        """Show feedback for row input validation."""
        if success:
            # Flash green
            original_style = self.row_input.styleSheet()
            self.row_input.setStyleSheet("background-color: #d4edda; border: 1px solid #28a745;")
            QTimer.singleShot(300, lambda: self.row_input.setStyleSheet(original_style))
        else:
            # Flash red and shake
            original_style = self.row_input.styleSheet()
            original_geometry = self.row_input.geometry()
            
            self.row_input.setStyleSheet("background-color: #f8d7da; border: 1px solid #dc3545;")
            QTimer.singleShot(500, lambda: self.row_input.setStyleSheet(original_style))
            
            # Shake animation
            shake_anim = QPropertyAnimation(self.row_input, b"geometry")
            shake_anim.setDuration(300)
            shake_anim.setKeyValueAt(0.0, original_geometry)
            shake_anim.setKeyValueAt(0.25, original_geometry.translated(-5, 0))
            shake_anim.setKeyValueAt(0.75, original_geometry.translated(5, 0))
            shake_anim.setKeyValueAt(1.0, original_geometry)
            shake_anim.start()
            
            # Store reference to prevent garbage collection
            self._row_shake_anim = shake_anim

    def _show_toast(self, message: str, toast_type: ToastNotification.Type = ToastNotification.Type.SUCCESS):
        """Show a toast notification."""
        self.toast.show_message(message, toast_type)
    
class InputForm(QWidget):
    """Manages form fields, validation icons, and input widgets for action parameters."""

    def __init__(
            self,
            action_info: AttributeDict,
            entry_id: Optional[str] = None
    ):
        super().__init__()
        self.action_info = action_info
        self.entry_id = entry_id

        # AppContext references
        self.app_ctx = AppContext.get()
        self.schedule = AppContext.getSchedule()
        self.validator_context = AppContext.getValidatorContext()

        self.entry_data: Optional[dict] = None
        if entry_id is not None:
            self.entry_data = self.schedule.get_data_entry_by_id(entry_id)

        self.inputs: dict[str, InputEntry] = {}
        
        self._validation_timers: dict[str, QTimer] = {}
        
        self._create_validators()
        self._build_layout()

    def _create_validators(self) -> None:
        """Create validators and associated widgets for each attribute."""
        validators_config = self.action_info.get('validators', {})

        for name, validator_class in validators_config.items():
            # Validation icon
            icon = QLabel()
            icon.setFixedWidth(20)
            icon.setAlignment(Qt.AlignmentFlag.AlignCenter)

            # Initial value
            initial_value = None
            if self.entry_data:
                initial_value = self.entry_data.get(name)

            # Create validator instance
            validator = validator_class(
                name=name,
                value=initial_value,
                context=self.validator_context
            )

            def create_handler(field_name: str):
                return lambda: self._handle_input_change(field_name, validator.isValid())

            # Create input widget with change handler
            input_widget = validator.input_widget(create_handler(name))

            # Create label with text and icon
            label_widget = self._create_label_widget(name, icon)

            # Store entry
            self.inputs[name] = InputEntry(
                icon=icon,
                validator=validator,
                label_widget=label_widget,
                input_widget=input_widget
            )

    def _create_label_widget(self, name: str, icon: QLabel) -> QWidget:
        """Create a label widget with text and an associated icon."""
        label = QLabel(name)
        label.setStyleSheet("font-weight: normal;")

        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        layout.addWidget(label)
        layout.addStretch()
        layout.addWidget(icon)

        return container

    def _build_layout(self) -> None:
        """Build the form layout with all input fields."""
        form_layout = QFormLayout()
        form_layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        form_layout.setLabelAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        form_layout.setFormAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        form_layout.setSpacing(10)

        for entry in self.inputs.values():
            entry.label_widget.setFixedWidth(150)
            entry.label_widget.setSizePolicy(
                QSizePolicy.Policy.Fixed,
                QSizePolicy.Policy.Preferred
            )

            entry.input_widget.setFixedWidth(250)
            entry.input_widget.setSizePolicy(
                QSizePolicy.Policy.Expanding,
                QSizePolicy.Policy.Preferred
            )

            form_layout.addRow(entry.label_widget, entry.input_widget)

        self.setLayout(form_layout)

    def _handle_input_change(self, name: str, is_valid: bool) -> None:
        """Handle input changes by validating and updating context."""
        # if name in self._validation_timers:
        #     self._validation_timers[name].stop()
        
        # timer = QTimer()
        # timer.setSingleShot(True)
        # timer.timeout.connect(lambda: self._update_validation_icon(name, is_valid))
        # self._validation_timers[name] = timer

        # timer.start(300)
        self._update_validation_icon(name, is_valid)

    def _update_validation_icon(self, name: str, is_valid: bool) -> None:
        """Update the validation icon for a specific input field."""
        if name not in self.inputs:
            return
        
        print(name, is_valid)
        pprint(self.inputs)

        icon = self.inputs[name].icon

        if is_valid:
            icon.setStyleSheet("color: #28a745; font-weight: bold;")
            icon.setText("✔")
            icon.setToolTip("Valid input")
        else:
            icon.setStyleSheet("color: #dc3545; font-weight: bold;")
            icon.setText("✖")
            icon.setToolTip(f"Invalid input {self.inputs[name].validator.expected()}")

    def validate_all(self) -> bool:
        """Validate all input fields and update their icons."""
        all_valid = True
        
        for name, entry in self.inputs.items():
            is_valid = entry.validator.isValid()
            self._update_validation_icon(name, is_valid)
            if not is_valid:
                all_valid = False
        return all_valid

class ActionDescription(QWidget):
    """Displays the description of the selected action."""

    def __init__(self, description: str):
        super().__init__()
        
        label = QLabel(description)
        label.setWordWrap(True)
        label.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)

        label.setStyleSheet("font-size: 14px;")

        label.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Minimum
        )

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(label)
        self.setLayout(layout)

class ObserveGraph(QWidget):
    """Real-time altitude graph for 'OBSERVE' action."""

    def __init__(self):
        super().__init__()

        # AppContext references
        self.app_ctx = AppContext.get()
        self.schedule = AppContext.getSchedule()
        self.validator_context = AppContext.getValidatorContext()
        self.dates = AppContext.getDates()
        
        # Create the plot widget
        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setBackground(None)
        self.plot_widget.setInteractive(False)
        self.plot_widget.showGrid(x=False, y=False)
        self.plot_widget.setFixedHeight(250)

        # Store plot items for later updates
        self.altitude_moon_curve = None
        self.altitude_curve = None
        self.start_marker = None
        self.end_marker = None
        self.min_limit_line = None
        self.max_limit_line = None
        self.observable_regions = []
        self.twilight_regions = []
        self.curve: Optional[list[tuple[float, float]]] = None
        self.moon_curve: Optional[list[tuple[float, float]]] = None

        self.sky_widget = SkyWidget()

        # Layout
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(20)
        layout.addWidget(self.plot_widget)
        layout.addWidget(self.sky_widget)
        self.setLayout(layout)

        self._connect_signals()

        self._configure_axes()
        self._initial_draw()
    
    def _connect_signals(self):
        self.schedule.data_changed.connect(self._on_schedule_changed)

        self.validator_context.watch('RA', self._on_coordinate_changed)
        self.validator_context.watch('DEC', self._on_coordinate_changed)
        
        self.validator_context.watch('telescope', self._on_telescope_changed)
        
        self.validator_context.watch('exp_time', self._on_timing_changed)
        self.validator_context.watch('exp_number', self._on_timing_changed)
        self.validator_context.watch('until_timestamp', self._on_timing_changed)

    def _initial_draw(self):
        self._draw_twilight_zones()
        self._draw_moon_curve()
        self._on_schedule_changed()
        self._on_coordinate_changed()
        self._on_telescope_changed('telescope', None)
        self._on_timing_changed('exp_time', None)

    def _on_coordinate_changed(self, *args) -> None:
        """RA or DEC changed -> Update curve and observable range."""
        ra = self.validator_context.get('RA')
        dec = self.validator_context.get('DEC')

        ra_hours = self._validate_and_parse_ra(ra)
        dec_degrees = self._validate_and_parse_dec(dec)

        if ra_hours is not None and dec_degrees is not None:
            self._draw_altitude_curve(ra_hours, dec_degrees)
            self._update_observable_range_if_possible()
            self._update_sky_view()

    def _on_telescope_changed(self, *args) -> None:
        """Telescope changed -> Update limits and observable range."""
        telescope_idx = self.validator_context.get('telescope')
        if telescope_idx is not None:
            self._draw_horizon_limits(telescope_idx)
            self._update_observable_range_if_possible()
        
    def _on_timing_changed(self, *args) -> None:
        """Timing params changed -> Update markers and observable range."""
        self._update_observable_range_if_possible()

    def _on_schedule_changed(self) -> None:
        """Schedule changed -> Redraw static elements."""
        start_time, end_time = self._calculate_times()
        self._draw_time_markers(start_time, end_time)
        self._update_sky_view()
        # Also trigger timing changes
        self._on_timing_changed()

    def _update_observable_range_if_possible(self) -> None:
        """Only update observable range if we have all required data."""
        telescope_idx = self.validator_context.get('telescope')
        ra = self.validator_context.get('RA')
        dec = self.validator_context.get('DEC')

        if telescope_idx is None:
            return
        
        ra_hours = self._validate_and_parse_ra(ra)
        dec_degrees = self._validate_and_parse_dec(dec)

        if ra_hours is None or dec_degrees is None:
            return

        self._highlight_observable_range(ra_hours, dec_degrees, telescope_idx)

    def _calculate_times(self) -> tuple[datetime, Optional[datetime]]:
        """Calculate start and end times for the observation period."""
        start_time = self.dates.astronomical_twilight_start

        entry_id = self.app_ctx.get_editing_entry_id()
        entry = self.schedule.get_timeline_entry_by_id(entry_id)

        if entry:
            start_time = entry.start_time
        else:
            telescope_idx = self.validator_context.get('telescope')
            if telescope_idx:
                timeline = self.app_ctx.getTimeline()
                matching_entries = [
                    entry for entry in timeline
                    if entry.telescope == telescope_idx
                ]
                if matching_entries:
                    start_time = max(entry.end_time for entry in matching_entries)

        action_data = self.validator_context.get_full_all()
        action_data['type'] = "OBSERVE"
        end_time = calculate_end_time(start_time, action_data)

        return start_time, end_time

    def _generate_time_points(self, start: datetime, end: datetime, interval_minutes: int = 5) -> list[datetime]:
        """Generate time points between start and end at specified intervals."""
        step = timedelta(minutes=interval_minutes)
        num_points = int((end - start).total_seconds() / step.total_seconds()) + 1
        return [start + i * step for i in range(num_points)]
    
    def _calculate_altazs(self, ra_hours: float, dec_degrees: float, timestamps: list[datetime]) -> list[tuple[float, float]]:
        """Calculate altitudes for given RA/DEC at specified times."""
        altitudes = []
        for t in timestamps:
            astro_time = AstroTime(t)
            alt, az = raDecToAltAz(ra_hours, dec_degrees, astro_time)  # type: ignore
            altitudes.append((alt, az))

        return altitudes
    
    def _calculate_moon_altazs(self, timestamps: list[datetime]) -> list[tuple[float, float]]:
        """Calculate altitudes for moon at specified times."""
        altitudes = []
        for t in timestamps:
            astro_time = AstroTime(t)
            alt, az = getMoonAltAz(astro_time)
            altitudes.append((alt, az))
        return altitudes

    def _configure_axes(self) -> None:
        """Configure plot axes with labels and ranges."""
        # Y axis (altitude)
        self.plot_widget.setLabel('left', 'Altitude', units='°')
        self.plot_widget.setYRange(0, 90, padding=0) # type: ignore

        altitude_axis = AltitudeAxisItem(orientation='left')
        self.plot_widget.setAxisItems({'left': altitude_axis})

        self.plot_widget.setLabel('bottom', 'Time')

        # X axis (time)
        start_time = self.dates.civil_twilight_start - timedelta(hours=1)
        end_time = self.dates.civil_twilight_end + timedelta(hours=1)

        x_min = self._datetime_to_plot_x(start_time)
        x_max = self._datetime_to_plot_x(end_time)

        # Custom time axis formatting
        time_axis = TimeAxisItem(start_time, end_time, orientation='bottom')
        self.plot_widget.setAxisItems({'bottom': time_axis})

        self.plot_widget.setXRange(x_min, x_max, padding=0) # type: ignore

        self.plot_widget.enableAutoRange(enable=False)

    #########################
    #                       #
    #   Conversion Methods  #
    #                       #
    #########################

    def _datetime_to_plot_x(self, dt: datetime) -> float:
        """Convert datetime to plot x-coordinate (timestamp)."""
        return dt.timestamp()

    def _plot_x_to_datetime(self, x: float) -> datetime:
        """Convert plot x-coordinate (timestamp) back to datetime."""
        return datetime.fromtimestamp(x)

    def _validate_and_parse_ra(self, ra: Any) -> Optional[float]:
        """Parse and validate RA value."""
        ra_parsed = Validator.Ra.parse(ra)
        return float(ra_parsed) if ra_parsed is not None else None

    def _validate_and_parse_dec(self, dec: Any) -> Optional[float]:
        """Parse and validate DEC value."""
        dec_parsed = Validator.Dec.parse(dec)
        return float(dec_parsed) if dec_parsed is not None else None

    #####################
    #                   #
    #   Drawing Methods #
    #                   #
    #####################

    def _update_sky_view(self):
        """Update the sky view with current curves."""
        self.sky_widget.setCurves(self.curve, self.moon_curve)

    def _draw_moon_curve(self):
        """Draw the altitude curve on the plot for the moon."""

        start_time = self.dates.civil_twilight_start - timedelta(hours=1)
        end_time = self.dates.civil_twilight_end + timedelta(hours=1)

        timestamps = self._generate_time_points(start_time, end_time)
        altazs = self._calculate_moon_altazs(timestamps)
        altitudes = [alt for alt, az in altazs]

        x_values = [self._datetime_to_plot_x(t) for t in timestamps]

        if self.altitude_moon_curve is not None:
            self.plot_widget.removeItem(self.altitude_moon_curve)

        pen = pg.mkPen(color="#516F7B", width=2)
        self.altitude_moon_curve = self.plot_widget.plot(
            x=x_values,
            y=altitudes,
            pen=pen,
            name="Altitude Moon Curve"
        )

        self.moon_curve = altazs

    def _draw_altitude_curve(self, ra_hours: float, dec_degrees: float):
        """Draw the altitude curve on the plot."""
        start_time = self.dates.civil_twilight_start - timedelta(hours=1)
        end_time = self.dates.civil_twilight_end + timedelta(hours=1)

        timestamps = self._generate_time_points(start_time, end_time)
        altazs = self._calculate_altazs(ra_hours, dec_degrees, timestamps)
        altitudes = [alt for alt, az in altazs]

        x_values = [self._datetime_to_plot_x(t) for t in timestamps]

        if self.altitude_curve:
            self.plot_widget.removeItem(self.altitude_curve)

        pen = pg.mkPen(color='#3A86FF', width=2)
        self.altitude_curve = self.plot_widget.plot(
            x=x_values,
            y=altitudes,
            pen=pen,
            name="Altitude Curve"
        )

        self.curve = altazs

    def _draw_time_markers(self, start_time: datetime, end_time: Optional[datetime]):
        """Draw start and end time markers on the plot."""
        if self.start_marker:
            self.plot_widget.removeItem(self.start_marker)
        if self.end_marker:
            self.plot_widget.removeItem(self.end_marker)

        start_x = self._datetime_to_plot_x(start_time)
        pen_start = pg.mkPen('#6A4C93', width=1, style=pg.QtCore.Qt.PenStyle.DashLine)
        self.start_marker = pg.InfiniteLine(
            pos=start_x,
            angle=90,
            pen=pen_start,
            label="Start",
            labelOpts={'position': 0.9, 'color': '#6A4C93', 'fill': '#FFFFFF'}
        )
        self.plot_widget.addItem(self.start_marker)

        if end_time is None:
            return

        end_x = self._datetime_to_plot_x(end_time)
        pen_end = pg.mkPen('#FF6F61', width=1, style=pg.QtCore.Qt.PenStyle.DashLine)
        self.end_marker = pg.InfiniteLine(
            pos=end_x,
            angle=90,
            pen=pen_end,
            label="End",
            labelOpts={'position': 0.9, 'color': '#FF6F61', 'fill': '#FFFFFF'}
        )
        self.plot_widget.addItem(self.end_marker)

    def _draw_horizon_limits(self, telescope_idx: int):
        """Draw horizontal lines for telescope horizon limits."""
        if self.min_limit_line:
            self.plot_widget.removeItem(self.min_limit_line)
        if self.max_limit_line:
            self.plot_widget.removeItem(self.max_limit_line)
        
        telescope_config = Validator.TELESCOPES[telescope_idx]
        min_alt = telescope_config.TELESCOPE.MIN_ALTITUDE
        max_alt = telescope_config.TELESCOPE.MAX_ALTITUDE

        self.sky_widget.setMinMaxAltitude(min_alt, max_alt)

        pen_min = pg.mkPen("#3A2909", width=1, style=pg.QtCore.Qt.PenStyle.DotLine)
        self.min_limit_line = pg.InfiniteLine(
            pos=min_alt,
            angle=0,
            pen=pen_min,
            label="Min Altitude",
            labelOpts={'position': 0.9, 'color': '#FFA500', 'fill': '#FFFFFF'}
        )
        self.plot_widget.addItem(self.min_limit_line)

        pen_max = pg.mkPen("#3F3109", width=1, style=pg.QtCore.Qt.PenStyle.DotLine)
        self.max_limit_line = pg.InfiniteLine(
            pos=max_alt,
            angle=0,
            pen=pen_max,
            label="Max Altitude",
            labelOpts={'position': 0.9, 'color': '#32CD32', 'fill': '#FFFFFF'}
        )
        self.plot_widget.addItem(self.max_limit_line)
    
    def _draw_twilight_zones(self) -> None:
        """Shade twilight zones on the plot."""
        for region in self.twilight_regions:
            self.plot_widget.removeItem(region)
        self.twilight_regions.clear()

        evening_start = self._datetime_to_plot_x(datetime.combine(self.dates.observation_date, time(12)))
        evening_end = self._datetime_to_plot_x(self.dates.astronomical_twilight_start)
        evening_region = pg.LinearRegionItem(
            values=(evening_start, evening_end),
            brush=pg.mkBrush(QColor(200, 200, 255, 50)),
            movable=False
        )
        self.plot_widget.addItem(evening_region)
        self.twilight_regions.append(evening_region)

        morning_start = self._datetime_to_plot_x(self.dates.astronomical_twilight_end)
        morning_end = self._datetime_to_plot_x(datetime.combine(self.dates.observation_date+timedelta(days=1), time(12)))
        morning_region = pg.LinearRegionItem(
            values=(morning_start, morning_end),
            brush=pg.mkBrush(QColor(200, 200, 255, 50)),
            movable=False
        )
        self.plot_widget.addItem(morning_region)
        self.twilight_regions.append(morning_region)

    def _highlight_observable_range(
            self,
            ra_hours: float,
            dec_degrees: float,
            telescope_idx: int
        ) -> None:
        """Highlight the observable range on the plot."""
        for region in self.observable_regions:
            self.plot_widget.removeItem(region)
        self.observable_regions = []
        
        telescope_config = Validator.TELESCOPES[telescope_idx]
        min_alt = telescope_config.TELESCOPE.MIN_ALTITUDE
        max_alt = telescope_config.TELESCOPE.MAX_ALTITUDE

        start_time = self.dates.civil_twilight_start - timedelta(hours=1)
        end_time = self.dates.civil_twilight_end + timedelta(hours=1)
        
        timestamps = self._generate_time_points(start_time, end_time)
        altazs = self._calculate_altazs(ra_hours, dec_degrees, timestamps)
        altitudes = [alt for alt,az in altazs]

        observable_segments = []
        segment_start = None

        for i, alt in enumerate(altitudes):
            # Check if altitude is within limits
            is_observable = min_alt <= alt
            
            if is_observable and segment_start is None:
                segment_start = i
                
            elif not is_observable and segment_start is not None:
                observable_segments.append((segment_start, i))
                segment_start = None

        if segment_start is not None:
            observable_segments.append((segment_start, len(timestamps)))

        for seg_start_idx, seg_end_idx in observable_segments:
            segment_times = timestamps[seg_start_idx: seg_end_idx]
            segment_alts = altitudes[seg_start_idx: seg_end_idx]

            x_values = [self._datetime_to_plot_x(t) for t in segment_times]
            y_values = [min(alt, max_alt) for alt in segment_alts]

            fill_item = pg.PlotDataItem(
                x=x_values,
                y=y_values,
                pen=None,
                brush=pg.mkBrush(QColor(100, 255, 100, 100)),
                fillLevel=min_alt
            )

            self.plot_widget.addItem(fill_item)
            self.observable_regions.append(fill_item)

    def clear_plot(self) -> None:
        """Clear all plot items."""
        if self.altitude_moon_curve:
            self.plot_widget.removeItem(self.altitude_moon_curve)
            self.altitude_moon_curve = None
        if self.altitude_curve:
            self.plot_widget.removeItem(self.altitude_curve)
            self.altitude_curve = None
        if self.start_marker:
            self.plot_widget.removeItem(self.start_marker)
            self.start_marker = None
        if self.end_marker:
            self.plot_widget.removeItem(self.end_marker)
            self.end_marker = None
        if self.min_limit_line:
            self.plot_widget.removeItem(self.min_limit_line)
            self.min_limit_line = None
        if self.max_limit_line:
            self.plot_widget.removeItem(self.max_limit_line)
            self.max_limit_line = None
        for region in self.observable_regions:
            self.plot_widget.removeItem(region)
        self.observable_regions.clear()
        for region in self.twilight_regions:
            self.plot_widget.removeItem(region)
        self.twilight_regions.clear()

class AltitudeAxisItem(pg.AxisItem):
    """Custom axis item for displaying altitude labels."""
    def tickStrings(self, values, scale, spacing):
        strings = []
        for v in values:
            strings.append(f"{v:.0f}°")
        return strings
    
    def tickValues(self, minVal, maxVal, size):
        """Generate ticks at every 20 degrees."""
        ticks = []
        current = (minVal // 20) * 20
        if current < minVal:
            current += 20
        while current <= maxVal:
            ticks.append(current)
            current += 20
        return [(20, ticks)]

class TimeAxisItem(pg.AxisItem):
    """Custom axis item for displaying time labels."""
    def __init__(self, start_time: datetime, end_time: datetime, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.start_time = start_time
        self.end_time = end_time

    def tickStrings(self, values, scale, spacing):
        strings = []
        for v in values:
            dt = datetime.fromtimestamp(v)
            strings.append(dt.strftime("%H"))
        return strings

    def tickValues(self, minVal, maxVal, size):
        """Generate ticks at even hours only."""
        # Convert timestamps to datetime
        start_dt = datetime.fromtimestamp(minVal)
        end_dt = datetime.fromtimestamp(maxVal)
        
        # Round start to next even hour
        start_hour = start_dt.hour
        if start_hour % 2 != 0:
            start_hour += 1
        
        # Create first tick at even hour
        first_tick = start_dt.replace(hour=start_hour, minute=0, second=0, microsecond=0)
        if first_tick < start_dt:
            first_tick += timedelta(hours=2)
        
        # Generate ticks every 2 hours
        ticks = []
        current = first_tick
        
        while current <= end_dt:
            ticks.append(current.timestamp())
            current += timedelta(hours=2)
        
        return [(2 * 3600, ticks)]

class SkyWidget(QWidget):
    
    def __init__(self):
        super().__init__()
        self.curve = []
        self.moon_curve = []
        self.minAlt = None
        self.maxAlt = None
        self.current_index = 0
        self._direction = 1

        self.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Fixed)
        self.setFixedHeight(400)

        self.center = 200
        self.centerPointF = QPointF(self.center, self.center)
        
        self.star_icon = create_star_svg_renderer()
        self.moon_size = 30
        self.moon_pixmap = self._create_moon_pixmap(self.moon_size)

        # Stars
        self.stars: List[tuple[QPointF, float]] = []
        for _ in range(60):
            alt = (random.random() ** 2) * 90
            az = random.uniform(0, 359)
            radius = self.alt_to_radius(alt)
            center = self.az_radius_to_QPointF(az, radius)
            size = random.uniform(2, 8)
            self.stars.append((center, size))

        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self._advance_animation)
        self.animation_timer.setInterval(20)  # 1ms = 10fps

        self._background_cache = None
        self._background_needs_update = True

    def alt_to_radius(self, alt: float) -> float:
        return (1 - alt / 90.0) * (self.center * 0.9)
    
    def az_radius_to_QPointF(self, az: float, radius: float) -> QPointF:
        az = -az
        angle = math.radians(az)
        x = self.centerPointF.x() + radius * math.sin(angle)
        y = self.centerPointF.y() - radius * math.cos(angle)
        return QPointF(x, y)


    def setMinMaxAltitude(self, minAlt, maxAlt):
        self.minAlt = minAlt
        self.maxAlt = maxAlt
        self._background_needs_update = True
        self.update()

    def resizeEvent(self, event):
        self.center = self.parentWidget().width() / 2 # type: ignore
        self.centerPointF = QPointF(self.center, self.center)
        self._background_needs_update = True
        super().resizeEvent(event)

    def setCurves(self, curve, moon_curve):
        self.curve = curve if curve else []
        self.moon_curve = moon_curve if moon_curve else []
        self.current_index = 0

        if self.curve or self.moon_curve:
            self.animation_timer.start()
        else:
            self.animation_timer.stop()

        self.update()

    def _advance_animation(self):
        """Move to next point in the curve."""
        if not self.curve and not self.moon_curve:
            self.animation_timer.stop()
            return
        max_len = max(len(self.curve), len(self.moon_curve))
        if max_len == 0:
            return

        self.current_index += self._direction

        # Reverse direction at ends
        if self.current_index >= max_len - 1:
            self.current_index = max_len - 1
            self._direction = -1
        elif self.current_index <= 0:
            self.current_index = 0
            self._direction = 1

        self.update()

    def _draw_static_background(self):
        pixmap = QPixmap(self.size())
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        radius = self.alt_to_radius(0)

        grad = QRadialGradient(self.centerPointF, radius)
        grad.setColorAt(0.0, QColor("#101830"))
        grad.setColorAt(1.0, QColor("#000010"))

        painter.setBrush(QBrush(grad))
        painter.drawEllipse(self.centerPointF, radius, radius)
        
        if self.minAlt is not None and self.maxAlt is not None:
            minAltRadius = self.alt_to_radius(self.minAlt)
            maxAltRadius = self.alt_to_radius(self.maxAlt)

            painter.setPen(Qt.PenStyle.NoPen)

            painter.setBrush(QBrush(QColor(255, 0, 0, 255), Qt.BrushStyle.BDiagPattern))
            painter.drawEllipse(self.centerPointF, radius, radius)

            # Background gradient night sky
            painter.setBrush(QBrush(grad))
            painter.drawEllipse(self.centerPointF, minAltRadius, minAltRadius)

            painter.setBrush(QBrush(QColor(255, 0, 0, 255), Qt.BrushStyle.BDiagPattern))
            painter.drawEllipse(self.centerPointF, maxAltRadius, maxAltRadius)

            painter.setPen(QPen(QColor(255, 0, 0, 255), 2))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawEllipse(self.centerPointF, minAltRadius, minAltRadius)
            painter.drawEllipse(self.centerPointF, maxAltRadius, maxAltRadius)
        
        for center, size in self.stars:
            half = size / 2
            rect = QRectF(center.x() - half, center.y() - half, size, size)
            self.star_icon.render(painter, rect)

        # Draw circles
        painter.setPen(QPen(Qt.GlobalColor.gray, 2))
        painter.setBrush(QBrush(QColor(255, 255, 255, 30)))
        painter.drawEllipse(self.centerPointF, radius, radius)
        painter.setPen(QPen(Qt.GlobalColor.gray, 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        _66altline = self.alt_to_radius(66)
        _33altline = self.alt_to_radius(33)
        painter.drawEllipse(self.centerPointF, _66altline, _66altline)
        painter.drawEllipse(self.centerPointF, _33altline, _33altline)
        painter.drawPoint(self.centerPointF)

        return pixmap
    
    def _create_moon_pixmap(self, size) -> QPixmap:
        pix = QPixmap(size, size)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix)
        self._create_moon_svg_renderer().render(p, QRectF(0, 0, size, size))
        return pix
    
    def _draw_pixmap_centered(self, painter: QPainter, center: QPointF, pixmap: QPixmap):
        half_w = pixmap.width() / 2
        half_h = pixmap.height() / 2
        painter.drawPixmap(QPointF(center.x() - half_w, center.y() - half_h), pixmap)


    def paintEvent(self, event):
        if self._background_needs_update or self._background_cache is None:
            self._background_cache = self._draw_static_background()
            self._background_needs_update = False

        painter = QPainter(self)
        painter.drawPixmap(0, 0, self._background_cache)
        
        if self.curve and self.current_index < len(self.curve):
            alt, az = self.curve[self.current_index]
            if alt >= 0:
                radius = self.alt_to_radius(alt)
                center = self.az_radius_to_QPointF(az, radius)
                grad = QRadialGradient(center, 6)
                grad.setColorAt(0.0, QColor(255, 255, 180, 255))
                grad.setColorAt(0.5, QColor(255, 200, 50, 180))
                grad.setColorAt(1.0, QColor(255, 255, 255, 0))
                painter.setBrush(QBrush(grad))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawEllipse(center, 6, 6)

        if self.moon_curve and self.current_index < len(self.moon_curve):
            alt, az = self.moon_curve[self.current_index]
            if alt >= 0:
                radius = self.alt_to_radius(alt)
                center = self.az_radius_to_QPointF(az, radius)
                self._draw_pixmap_centered(painter, center, self.moon_pixmap)
   
    def hideEvent(self, event):
        """Stop animation when widget is hidden."""
        self.animation_timer.stop()
        super().hideEvent(event)
    
    def showEvent(self, event):
        """Resume animation when widget is shown."""
        if self.curve:
            self.animation_timer.start()
        super().showEvent(event)

    def _create_moon_svg_renderer(self):
        svg_string = """
        <svg version="1.1" id="_x34_" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="#000000">
            <g>
                <g>
                    <path style="fill:#C6C6C6;" d="M426.655,444.491c-85.064,74.278-206.9,83.839-299.319,29.581 c-22.308-13.074-42.982-29.907-60.958-50.499C56,411.723,46.93,399.058,39.085,385.82C15.143,345.045,3.539,298.958,3.784,252.953 c0.49-71.582,29.989-142.754,87.026-192.6C138.776,18.433,197.855-1.096,256.69,0.047c45.597,0.817,91.03,13.973,131.069,38.733 c22.063,13.564,42.41,30.724,60.305,51.153c9.724,11.114,18.386,22.799,25.822,34.974 C537.623,227.785,521.117,361.878,426.655,444.491z"></path>
                    <path style="fill:#969696;" d="M107.7,89.244c99.915-87.35,248.817-74.175,333.815,23.051 c84.998,97.226,75.388,243.379-24.528,330.729c-99.915,87.35-251.727,82.317-336.725-14.908S7.784,176.594,107.7,89.244z"></path>
                    <g>
                        <path style="fill:#6F6F6F;" d="M244.029,141.49c-17.92,37.27-63.032,51.341-100.302,33.421 c-37.27-17.92-53.234-61.357-35.315-98.627c17.92-37.27,62.835-54.046,100.105-36.126 C245.787,58.078,261.948,104.22,244.029,141.49z"></path>
                        <path style="opacity:0.06;fill:#040000;" d="M128.086,97.65c17.92-37.27,62.835-54.046,100.105-36.126 c4.127,1.984,7.994,4.316,11.586,6.942c-7.335-11.909-17.95-21.909-31.26-28.308c-37.27-17.92-82.185-1.144-100.105,36.126 c-15.805,32.872-5.247,70.538,23.036,91.265C118.963,147.091,116.789,121.146,128.086,97.65z"></path>
                    </g>
                    <path style="fill:#6F6F6F;" d="M217.121,218.367c-1.17-5.733,2.71-11.178,8.442-12.348c5.733-1.17,11.248,2.359,12.418,8.091 c1.17,5.733-2.456,11.466-8.189,12.635C224.06,227.916,218.291,224.099,217.121,218.367z"></path>
                    <path style="opacity:0.5;fill:#FFFFFF;" d="M363.151,96.945c-1.17-5.733,2.71-11.178,8.442-12.348s11.248,2.359,12.418,8.091 c1.17,5.733-2.456,11.466-8.189,12.636C370.089,106.493,364.32,102.677,363.151,96.945z"></path>
                    <path style="fill:#6F6F6F;" d="M282.752,398.389c8.691-7.598,21.813-6.256,29.411,2.435c7.598,8.691,6.926,21.591-1.765,29.189 c-8.691,7.598-22.059,6.972-29.657-1.719C273.143,419.603,274.061,405.987,282.752,398.389z"></path>
                    <path style="opacity:0.5;fill:#FFFFFF;" d="M58.327,220.961c-1.17-5.733,2.71-11.178,8.442-12.348 c5.733-1.17,11.248,2.359,12.418,8.091s-2.456,11.466-8.189,12.636C65.265,230.51,59.496,226.694,58.327,220.961z"></path>
                    <path style="fill:#6F6F6F;" d="M468.947,281.701c-3.725,36.649-37.256,62.098-73.905,58.373 c-36.649-3.725-63.177-35.279-59.452-71.928c3.725-36.649,36.272-64.305,72.921-60.58 C445.16,211.292,472.673,245.052,468.947,281.701z"></path>
                    <g>
                        <path style="fill:#6F6F6F;" d="M173.239,331.136c14.631,25.328,4.867,57.294-20.461,71.925 c-25.328,14.631-57.07,6.642-71.701-18.686c-14.631-25.328-6.526-58.257,18.802-72.888 C125.206,296.855,158.608,305.808,173.239,331.136z"></path>
                        <path style="opacity:0.06;fill:#040000;" d="M112.818,324.329c18.464-10.666,41.21-8.787,57.855,2.82 c-15.693-22.238-46.847-29.497-70.794-15.663c-25.328,14.631-33.433,47.561-18.802,72.888c4.04,6.993,9.388,12.657,15.541,16.895 c-0.915-1.299-1.788-2.644-2.602-4.052C79.385,371.89,87.49,338.96,112.818,324.329z"></path>
                    </g>
                    <path style="opacity:0.06;fill:#040000;" d="M349.701,282.093c3.725-36.649,36.272-64.305,72.921-60.579 c12.217,1.242,23.415,5.824,32.783,12.735c-11.007-14.534-27.694-24.73-46.893-26.682c-36.649-3.725-69.196,23.93-72.921,60.579 c-2.465,24.247,8.316,46.261,26.506,59.464C352.777,315.06,347.969,299.128,349.701,282.093z"></path>
                </g>
                <path style="opacity:0.1;fill:#040000;" d="M254.81,381.707c-105.358,0-198.419-52.064-254.72-131.654 c-2.703,99.72,55.552,194.334,153.936,236.742c128.773,55.507,279.648,1.534,335.155-127.239 c15.267-35.419,21.657-72.747,20.288-109.416C453.162,329.68,360.13,381.707,254.81,381.707z"></path>
            </g>
        </svg>
        """

        return QSvgRenderer(QByteArray(svg_string.encode()))

class TimelineControlBar(QWidget):
    zoom_changed = pyqtSignal(float) # pixels per second scale
    
    def __init__(self) -> None:
        super().__init__()
        self.setFixedHeight(50)
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 5, 10, 5)
        layout.setSpacing(10)

        layout.addStretch()

        # Zoom controls
        zoom_label = QLabel("Zoom:")
        layout.addWidget(zoom_label)
        
        self.zoom_out_btn = QPushButton()
        self.zoom_out_btn.setIcon(qta.icon('fa6s.magnifying-glass-minus'))
        self.zoom_out_btn.setFixedSize(30, 30)
        self.zoom_out_btn.clicked.connect(self._on_zoom_out)
        layout.addWidget(self.zoom_out_btn)
        
        self.zoom_slider = QSlider(Qt.Orientation.Horizontal)
        self.zoom_slider.setMinimum(2)
        self.zoom_slider.setMaximum(150)
        self.zoom_slider.setValue(2)
        self.zoom_slider.setFixedWidth(300)
        self.zoom_slider.valueChanged.connect(self._on_zoom_slider)
        layout.addWidget(self.zoom_slider)
        
        self.zoom_in_btn = QPushButton()
        self.zoom_in_btn.setIcon(qta.icon('fa6s.magnifying-glass-plus'))
        self.zoom_in_btn.setFixedSize(30, 30)
        self.zoom_in_btn.clicked.connect(self._on_zoom_in)
        layout.addWidget(self.zoom_in_btn)

    def _on_zoom_slider(self, value: int):
        """Set zoom to value"""
        self.zoom_changed.emit(value / 100)

    def _on_zoom_in(self):
        """Increase zoom."""
        current = self.zoom_slider.value()
        self.zoom_slider.setValue(min(current + 5, self.zoom_slider.maximum()))
    
    def _on_zoom_out(self):
        """Decrease zoom."""
        current = self.zoom_slider.value()
        self.zoom_slider.setValue(max(current - 5, self.zoom_slider.minimum()))
    
    def set_zoom_value(self, pixels_per_second: float):
        """Set zoom slider to specific value."""
        slider_value = int(pixels_per_second * 10)
        self.zoom_slider.blockSignals(True)
        self.zoom_slider.setValue(slider_value)
        self.zoom_slider.blockSignals(False)

class TimeRulerWidget(QWidget):
    """Vertical time axis showing hours and grid lines."""
    
    def __init__(self):
        super().__init__()
        self.setFixedWidth(80)
        
        self.start_time: Optional[datetime] = None
        self.end_time: Optional[datetime] = None
        self.pixels_per_second = 0.02
        self.scroll_offset = 0

        self.current_time = self._time_now_without_tzinfo()
        self.time_update_timer = QTimer(self)
        self.time_update_timer.timeout.connect(self._update_current_time)
        self.time_update_timer.start(5 * 60 * 1000)
        
        self.setStyleSheet("background-color: #f8f9fa; border-right: 1px solid #dee2e6;")

    def _time_now_without_tzinfo(self):
        time = datetime.now(timezone.utc)
        return time.replace(tzinfo=None)

    def _update_current_time(self):
        """Update current time and repaint."""
        self.current_time = self._time_now_without_tzinfo()
        self.update()

    def update_time_range(self, start_time: datetime, end_time: datetime):
        """Update the time range."""
        self.start_time = start_time
        self.end_time = end_time
        self.update()
    
    def update_zoom(self, pixels_per_second: float):
        """Update zoom level."""
        self.pixels_per_second = pixels_per_second
        self.update()
    
    def set_scroll_offset(self, offset: int):
        """Update scroll position."""
        self.scroll_offset = offset
        self.update()
    
    def time_to_y(self, dt: datetime) -> float:
        """Convert datetime to Y coordinate."""
        if not self.start_time:
            return 0
        delta_seconds = (dt - self.start_time).total_seconds()
        return delta_seconds * self.pixels_per_second - self.scroll_offset
    
    def paintEvent(self, event):
        """Draw time ruler."""
        super().paintEvent(event)
        
        if not self.start_time or not self.end_time:
            return
        
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Calculate time range
        current_time = self.start_time
        
        # Draw time labels and grid lines
        while current_time <= self.end_time:
            y = self.time_to_y(current_time)
            
            # Only draw if visible
            if -20 <= y <= self.height() + 20:
                # Draw time label
                time_str = current_time.strftime("%H:%M")
                
                # Major hour lines
                if current_time.minute == 0:
                    painter.setPen(QPen(QColor("#495057"), 2))
                    font = painter.font()
                    font.setBold(True)
                    painter.setFont(font)
                else:
                    painter.setPen(QPen(QColor("#6c757d"), 1))
                    font = painter.font()
                    font.setBold(False)
                    painter.setFont(font)

                # Draw text
                text_rect = QRectF(5, y - 10, 50, 20)
                painter.drawText(text_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, time_str)
            
            # Increment by 30 minutes
            current_time += timedelta(minutes=30)

        painter.setPen(QPen(QColor("#FF0000"), 2))
        painter.drawPolygon(self.arrow(85, int(self.time_to_y(self.current_time))))

        painter.end()
    
    def arrow(self, x, y):
        points: QPolygon = QPolygon()
        points.append(QPoint(x-20, y+3))
        points.append(QPoint(x-20, y+8))
        points.append(QPoint(x-10, y))
        points.append(QPoint(x-20, y-8))
        points.append(QPoint(x-20, y-3))
        points.append(QPoint(x-30, y-3))
        points.append(QPoint(x-30, y+3))
        return points

class TelescopeHeaderWidget(QWidget):
    """Horizontal header showing telescope names."""
    
    COLUMN_COUNT = 5
    COLUMN_SPACING = 10
    
    def __init__(self):
        super().__init__()
        self.setFixedHeight(40)
        self.telescope_names = ["Telescope 1", "Telescope 2", "Telescope 3", "Telescope 4", "Sun Telescope"]
        self.setStyleSheet("background-color: #f8f9fa; border-bottom: 2px solid #dee2e6;")
    
    def get_column_width(self) -> float:
        """Calculate dynamic column width based on widget width."""
        widget_width = self.width()
        available_width = max(widget_width, 1000)
        
        total_spacing = self.COLUMN_SPACING * (self.COLUMN_COUNT - 1)
        column_width = (available_width - total_spacing) / self.COLUMN_COUNT
        
        return column_width
    
    def paintEvent(self, event):
        """Draw telescope headers."""
        super().paintEvent(event)
        
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        font = painter.font()
        font.setBold(True)
        font.setPointSize(11)
        painter.setFont(font)
        painter.setPen(QColor("#212529"))
        
        column_width = self.get_column_width()
        
        for i, name in enumerate(self.telescope_names):
            x = i * (column_width + self.COLUMN_SPACING)
            rect = QRectF(x, 0, column_width, self.height())
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, name)
        
        painter.end()

class TimelineViewer(QWidget):
    """Time-proportional timeline viewer showing tasks with accurate duration representation."""
    
    def __init__(self):
        super().__init__()
        self.app_ctx = AppContext.get()
        self.schedule = AppContext.getSchedule()
        self.toast = AppContext.getToast()

        self.grid_layout = QGridLayout(self)

        # Initialize the sub widgets
        self.control_bar = TimelineControlBar()
        self.header_widget = TelescopeHeaderWidget()
        self.ruler_widget = TimeRulerWidget()
        self.graphics_widget = TimelineGraphicsWidget()
        
        self.grid_layout.addWidget(self.control_bar, 0, 0, 1, 2)
        self.grid_layout.addWidget(self.header_widget, 1, 1, 1, 1)
        self.grid_layout.addWidget(self.ruler_widget, 2, 0, 1, 1)
        self.grid_layout.addWidget(self.graphics_widget, 2, 1, 1, 1)

        self.control_bar.zoom_changed.connect(self._on_zoom_changed)
        self.graphics_widget.task_context_menu.connect(self._on_task_context_menu)
        self.graphics_widget.verticalScrollBar().valueChanged.connect(self._sync_ruler_scroll) # type: ignore

        self.app_ctx.timeline_updated.connect(self.refresh)
        self.app_ctx.clipboard_updated.connect(self._on_clipboard_changed)
        self.app_ctx.editing_state_changed.connect(self._on_editing_changed)

        self.schedule.entry_added.connect(self._on_entry_added)

        # Initial update
        self.refresh()
    
    def refresh(self):
        """Refresh the timeline from schedule data."""
        
        # Set time range
        dates = AppContext.getDates()
        if dates:
            start_raw = dates.civil_twilight_start - timedelta(hours=1)
            start_time = start_raw.replace(minute=0, second=0, microsecond=0)
            end_raw = dates.civil_twilight_end + timedelta(hours=1)
            end_time = end_raw.replace(minute=0, second=0, microsecond=0)

            # if actions happen before and after start and end, adjust start and end
            timeline = AppContext.getTimeline()
            for entry in reversed(timeline):
                if entry.start_time < start_time:
                    if entry.action_data.get('type') != 'WAIT_TIMESTAMP':
                        start_time = entry.start_time
            
            for entry in timeline:
                if entry.end_time > end_time:
                    end_time = entry.end_time
            
        # Update graphics
        self.graphics_widget.update_time_range(start_time, end_time)
        self.graphics_widget.update_from_schedule()
        self.ruler_widget.update_time_range(start_time, end_time)
        self.ruler_widget.update_zoom(self.graphics_widget.pixels_per_second)

    def _on_entry_added(self, entry_id: str):
        QTimer.singleShot(100, lambda: self.graphics_widget.scroll_to_entry(entry_id))

    def _on_clipboard_changed(self):
        pass

    def _on_editing_changed(self):
        entry_id = self.app_ctx.get_editing_entry_id()
        if entry_id:
            self.graphics_widget.set_editing_task(entry_id)
        else:
            self.graphics_widget.set_editing_task(None)

    def _on_zoom_changed(self, pixels_per_second: float):
        """Handle zoom change."""
        self.graphics_widget.update_zoom(pixels_per_second)
        self.ruler_widget.update_zoom(pixels_per_second)
    
    def _sync_ruler_scroll(self, value: int):
        """Sync ruler widget with view scroll."""
        self.ruler_widget.set_scroll_offset(value)
    
    def _on_task_context_menu(self, entry_id: str, pos: QPoint):
        """Show context menu for task."""
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: white;
                border: 1px solid #adb5bd;
                border-radius: 5px;
                padding: 5px;
            }
            QMenu::item {
                padding: 8px 25px;
                border-radius: 3px;
            }
            QMenu::item:selected {
                background-color: #e2e6ea;
            }
            QMenu::separator {
                height: 1px;
                background-color: #ced4da;
                margin: 5px 10px;
            }
        """)
        
        edit_action = menu.addAction("Edit")
        edit_action.triggered.connect(lambda: self._handle_edit(entry_id)) # type: ignore
        
        copy_action = menu.addAction("Copy")
        copy_action.triggered.connect(lambda: self._handle_copy(entry_id)) # type: ignore
        
        menu.addSeparator()
        
        delete_action = menu.addAction("Delete")
        delete_action.triggered.connect(lambda: self._handle_delete(entry_id)) # type: ignore
        
        menu.addSeparator()
        
        insert_above_action = menu.addAction("Insert Above")
        insert_above_action.triggered.connect(lambda: self._handle_insert_above(entry_id)) # type: ignore
        
        insert_below_action = menu.addAction("Insert Below")
        insert_below_action.triggered.connect(lambda: self._handle_insert_below(entry_id)) # type: ignore
        
        if self.app_ctx.has_clipboard():
            menu.addSeparator()
            
            insert_copied_above_action = menu.addAction("Insert Copied Above")
            insert_copied_above_action.triggered.connect(lambda: self._handle_insert_copied_above(entry_id)) # type: ignore
            
            insert_copied_below_action = menu.addAction("Insert Copied Below")
            insert_copied_below_action.triggered.connect(lambda: self._handle_insert_copied_below(entry_id)) # type: ignore
        
        menu.exec(pos)
        
    def _handle_edit(self, entry_id: str):
        """Handle edit request."""
        self.app_ctx.set_editing_entry(entry_id)

    def _handle_copy(self, entry_id: str):
        """Copy the entry at row_index to clipboard."""
        entry_data = self.schedule.get_data_entry_by_id(entry_id)
        if entry_data:
            self.app_ctx.set_clipboard(entry_data, entry_id)
            entry_type = entry_data.get('type', 'Unknown')
            self._show_toast(f"Copied {entry_type} entry")

    def _handle_delete(self, entry_id: str):
        """Delete the entry by entry_id."""
        entry_data = self.schedule.get_data_entry_by_id(entry_id)
        if entry_data:
            entry_type = entry_data.get('type', 'Unknown')
            self.schedule.delete_entry(entry_id)
            self._show_toast(f"Deleted {entry_type} entry")

    def _handle_insert_above(self, entry_id: str):
        """Insert a new blank entry above entry_id."""
        timeline_entry = self.schedule.get_timeline_entry_by_id(entry_id)
        if timeline_entry:
            new_data = self.schedule.create_default_data(timeline_entry.telescope)
            self.schedule.insert_entry_above(entry_id, new_data)
            self._show_toast(f"Inserted blank entry above")

    def _handle_insert_below(self, entry_id: str):
        """Insert a new blank entry below row_index."""
        timeline_entry = self.schedule.get_timeline_entry_by_id(entry_id)
        if timeline_entry:
            new_data = self.schedule.create_default_data(timeline_entry.telescope)
            self.schedule.insert_entry_below(entry_id, new_data)
            self._show_toast(f"Inserted blank entry below")

    def _handle_insert_copied_above(self, entry_id: str):
        """Insert copied entry above row_index."""
        copied_data = self.app_ctx.get_clipboard()
        if copied_data:
            self.schedule.insert_entry_above(entry_id, copied_data)
            self.app_ctx.clear_clipboard()
            self._show_toast(f"Pasted {copied_data.get('type')} entry above")

    def _handle_insert_copied_below(self, entry_id: str):
        """Insert copied entry below row_index."""
        copied_data = self.app_ctx.get_clipboard()
        if copied_data:
            self.schedule.insert_entry_below(entry_id, copied_data)
            self.app_ctx.clear_clipboard()
            self._show_toast(f"Pasted {copied_data.get('type')} entry below")

    def _show_toast(self, message: str, toast_type: ToastNotification.Type = ToastNotification.Type.SUCCESS):
        """Show a toast notification."""
        self.toast.show_message(message, toast_type)
    
    def resizeEvent(self, event):
        """Handle resize to redistribute columns."""
        super().resizeEvent(event)
        self.refresh()

class TaskRectItem(QGraphicsRectItem):
    """Visual representation of a single scheduled task."""
    
    def __init__(self, timeline_entry: TimelineEntry, x: float, y: float, width: float, height: float):
        super().__init__(x, y, width, height)
        
        self.timeline_entry = timeline_entry
        self.is_copied = False
        self.is_editing = False
        self.is_hovered = False
        self._is_being_deleted = False  # Add flag to track deletion
        
        self.setAcceptHoverEvents(True)

        # Add drop shadow effect
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(8)
        shadow.setXOffset(0)
        shadow.setYOffset(2)
        shadow.setColor(QColor(0, 0, 0, 40))  # Subtle shadow
        self.setGraphicsEffect(shadow)
        
        # Rounded corners
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, False)
        
        self.text_item = QGraphicsTextItem(self)
        self.symbol_item = QGraphicsTextItem(self)

        self._update_appearance()

        # Show tooltip
        start_str = self.timeline_entry.start_time.strftime("%H:%M:%S")
        end_str = self.timeline_entry.end_time.strftime("%H:%M:%S")
        duration = self.timeline_entry.end_time - self.timeline_entry.start_time
        self.setToolTip(f"{start_str} - {end_str}\nDuration: {duration}")

    def cleanup(self):
        """Properly clean up resources before deletion."""
        self._is_being_deleted = True
        
        # Clear graphics effect to avoid Qt issues
        self.setGraphicsEffect(None)
        
        # Remove child items
        if self.text_item:
            scene = self.text_item.scene()
            if scene:
                scene.removeItem(self.text_item)
            self.text_item.setParentItem(None)
            self.text_item = None
            
        if self.symbol_item:
            scene = self.symbol_item.scene()
            if scene:
                scene.removeItem(self.symbol_item)
            self.symbol_item.setParentItem(None)
            self.symbol_item = None
    
    def _update_appearance(self):
        """Update the visual appearance based on hover and copied state."""
        if self._is_being_deleted:
            return
            
        if self.is_copied:
            # Yellow highlight for copied items
            border_color = QColor("#ffc107")
            fill_color = QColor("#fff9e6")
            border_width = 2
        elif self.is_editing:
            #  highlight for editing items
            border_color = QColor("#180808")
            fill_color = QColor("#675E5E")
            border_width = 5
        elif self.is_hovered:
            # Hover colors
            border_color = QColor("#2196f3")
            fill_color = QColor("#e3f2fd")
            border_width = 2
        else:
            # Normal colors
            border_color = QColor("#90a4ae")
            fill_color = QColor("#ffffff")
            border_width = 1
        
        if self.timeline_entry.start_time == self.timeline_entry.end_time:
            border_color = QColor("#dc3545")
            border_width = 3
        
        # Set pen and brush
        pen = QPen(border_color, border_width)
        self.setPen(pen)
        gradient = QLinearGradient(0, 0, 0, self.rect().height())
        gradient.setColorAt(0.0, fill_color.lighter(105))
        gradient.setColorAt(1.0, fill_color)
        self.setBrush(QBrush(fill_color))

    def set_is_copied(self, is_copied: bool):
        if self._is_being_deleted:
            return
        self.is_copied = is_copied
        self._update_appearance()
    
    def set_is_editing(self, is_editing: bool):
        if self._is_being_deleted:
            return
        self.is_editing = is_editing
        self._update_appearance()

    def hoverEnterEvent(self, event):
        """Handle mouse hover enter."""
        if self._is_being_deleted:
            return
        self.is_hovered = True
        self._update_appearance()
        super().hoverEnterEvent(event)
    
    def hoverLeaveEvent(self, event):
        """Handle mouse hover leave."""
        if self._is_being_deleted:
            return
        self.is_hovered = False
        self._update_appearance()
        super().hoverLeaveEvent(event)

    def itemChange(self, change, value):
        if self._is_being_deleted:
            return super().itemChange(change, value)
            
        # Called whenever the item is added/removed/moved in a scene
        if change == QGraphicsItem.GraphicsItemChange.ItemSceneHasChanged and value is not None:
            # Defer update until next event loop tick (scene is fully ready)
            QTimer.singleShot(0, self._update_text)
        return super().itemChange(change, value)
    
    def _update_text(self):
        """Update text label."""
        parent_rect = self.rect()

        if self._is_being_deleted:
            return
        
        assert self.text_item is not None
        assert self.symbol_item is not None

        # --- Hide text entirely if rect is too small ---
        if parent_rect.width() < 10 or parent_rect.height() < 10:
            self.text_item.setVisible(False)
            self.symbol_item.setVisible(False)
            return
        else:
            self.text_item.setVisible(True)
            self.symbol_item.setVisible(True)
            
        display_text = self._get_display_text()
        status_symbol, status_symbol_color = self._get_status_symbol_text()

        # Set symbol text and color
        self.symbol_item.setPlainText(status_symbol)
        self.symbol_item.setDefaultTextColor(QColor(status_symbol_color))
        symbol_font = self.symbol_item.font()
        symbol_font.setBold(True)
        symbol_font.setPointSize(9)
        self.symbol_item.setFont(symbol_font)
        
        # Set display text and color
        self.text_item.setPlainText(display_text)
        self.text_item.setDefaultTextColor(QColor("#212529"))
        text_font = self.text_item.font()
        text_font.setBold(True)
        text_font.setPointSize(9)
        self.text_item.setFont(text_font)      

        # Get dimensions
        symbol_rect = self.symbol_item.boundingRect()
        text_rect = self.text_item.boundingRect()
        spacing = 5  # Space between symbol and text

        # Compute total content width and height
        total_width = symbol_rect.width() + spacing + text_rect.width()
        total_height = max(symbol_rect.height(), text_rect.height())

        # Compute top-left starting point for centering
        start_x = parent_rect.left() + (parent_rect.width() - total_width) / 2
        start_y = parent_rect.top() + (parent_rect.height() - total_height) / 2

        # --- Optional visible-portion adjustment ---
        if self.scene() and self.scene().views(): # type: ignore
            view = self.scene().views()[0]# type: ignore
            visible_scene_rect = view.mapToScene(view.viewport().rect()).boundingRect()# type: ignore
            item_scene_rect = self.mapToScene(parent_rect).boundingRect()
            visible_part = visible_scene_rect.intersected(item_scene_rect)

            # Only adjust vertically if there's a visible overlap
            if visible_part.isValid() and visible_part.height() >= 30:
                visible_top_left = self.mapFromScene(visible_part.topLeft())
                visible_bottom_right = self.mapFromScene(visible_part.bottomRight())
                visible_height = visible_bottom_right.y() - visible_top_left.y()
                start_y = visible_top_left.y() + (visible_height - total_height) / 2


        # Adjust for each item's own local bounding rect offset
        symbol_x = start_x - symbol_rect.left()
        symbol_y = start_y - symbol_rect.top()
        text_x = symbol_x + symbol_rect.width() + spacing - text_rect.left()
        text_y = start_y - text_rect.top()

        # Apply positions
        self.symbol_item.setPos(symbol_x, symbol_y)
        self.text_item.setPos(text_x, text_y)
    
    def _get_display_text(self) -> str:
        """Get formatted display name for task."""
        action_data = self.timeline_entry.action_data
        if action_data.get('type') is None:
            return "~INSERTING NEW~"
        else:
            timeline_name = ACTION_REGISTRY[action_data['type']]['timeline_name']
            for k, v in action_data.items():
                timeline_name = timeline_name.replace(f"<{k}>", str(v))
            return timeline_name
        
    def _get_status_symbol_text(self) -> tuple[str, str]:
        status = self.timeline_entry.action_data.get('done')
        if status == Validator.StatusValue.WAITING:
            color = "#ff9800"
            symbol = "⧗"
        elif status == Validator.StatusValue.DONE:
            color = "#4caf50"
            symbol = "✔"
        elif status == Validator.StatusValue.FAILED:
            color = "#f44336"
            symbol = "✘"
        elif status == Validator.StatusValue.BUSY:
            color = "#2196f3"
            symbol = "⧖"
        else:
            color = "#9e9e9e"
            symbol = "-"
        return symbol, color
    
    def update_geometry(self, x: float, y: float, width: float, height: float):
        """Update position and size."""
        if self._is_being_deleted:
            return

        self.setRect(x, y, width, height)
        self.setPos(0, 0)

        QTimer.singleShot(0, self._update_text)

    def paint(self, painter: QPainter, option, widget=None):
        """Custom paint with rounded corners."""
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        rect = self.rect()
        
        # Draw rounded rectangle
        painter.setPen(self.pen())
        painter.setBrush(self.brush())
        painter.drawRoundedRect(rect, 6, 6)  # 6px rounded corners

class TimelineGraphicsWidget(QGraphicsView):
    """Custom graphics view for timeline with scroll and zoom."""
    
    task_context_menu = pyqtSignal(str, QPoint)  # entry_id, Position
    
    COLUMN_COUNT = 5
    COLUMN_SPACING = 10
    
    def __init__(self):
        self._scene = QGraphicsScene()
        super().__init__(self._scene)
        
        self.pixels_per_second = 0.02

        self.start_datetime: Optional[datetime] = None
        self.end_datetime: Optional[datetime] = None
        self.task_items: List[TaskRectItem] = []

        # View settings
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setStyleSheet("""
            
            /* Chrome-style scrollbar */
            QScrollBar:vertical {
                background: transparent;
                width: 14px;
                margin: 0px;
                border: none;
            }
            
            QScrollBar::handle:vertical {
                background: #5f6368;
                min-height: 30px;
                margin: 2px 2px 2px 2px;
                border-radius: 7px;
            }
            
            QScrollBar::handle:vertical:hover {
                background: #80868b;
            }
            
            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                border: none;
                background: none;
                height: 0px;
            }
            
            QScrollBar::add-page:vertical,
            QScrollBar::sub-page:vertical {
                background: transparent;
            }
            
            QScrollBar::up-arrow:vertical,
            QScrollBar::down-arrow:vertical {
                background: none;
            }
        """)
        
        # Mouse tracking
        self.setMouseTracking(True)
    
    def get_column_width(self) -> float:
        view_width = self.viewport().width() #type: ignore
        available_width = max(view_width, 1000) # Minimum 1000px

        total_spacing = self.COLUMN_SPACING * (self.COLUMN_COUNT - 1)
        column_width = (available_width - total_spacing) / self.COLUMN_COUNT

        return column_width
    
    def time_to_y_coordinate(self, dt: datetime) -> float:
        """Convert datetime to Y coordinate."""
        if not self.start_datetime:
            return 0
        delta_seconds = (dt - self.start_datetime).total_seconds()
        return delta_seconds * self.pixels_per_second
    
    def telescope_to_x_coordinate(self, telescope_idx: int) -> float:
        """Get left X coordinate for telescope column."""
        column_width = self.get_column_width()
        return (telescope_idx - 1) * (column_width + self.COLUMN_SPACING)
    
    def update_time_range(self, start_time, end_time):
        self.start_datetime = start_time
        self.end_datetime = end_time
        self._calculate_scene_size()
    
    def _calculate_scene_size(self):
        assert self.start_datetime is not None
        assert self.end_datetime is not None
        
        # Calculate scene size
        total_seconds = (self.end_datetime - self.start_datetime).total_seconds()
        scene_height = total_seconds * self.pixels_per_second
        column_width = self.get_column_width()
        scene_width = self.COLUMN_COUNT * column_width + (self.COLUMN_COUNT - 1) * self.COLUMN_SPACING  # 4 telescopes + sun
        self._scene.setSceneRect(0, 0, scene_width, scene_height)

    def update_from_schedule(self):
        """Rebuild all items from schedule data."""
        # Clear existing items
        self.clear_all_items()

        # Create task rectangles ( if telescope 0 then make task for each of the 4 telescope)
        timeline = AppContext.getTimeline()
        for entry in timeline:
            if entry.telescope == 0:
                for telescope_idx in range(1,5):
                    copied_entry = copy.deepcopy(entry)
                    copied_entry.telescope = telescope_idx
                    self._create_task_rect(copied_entry)
            else:
                self._create_task_rect(entry)

    def _calculate_x_y_width_height_task_rect(self, entry: TimelineEntry):
        column_width = self.get_column_width()

        x = self.telescope_to_x_coordinate(entry.telescope)
        y = self.time_to_y_coordinate(entry.start_time)
        
        duration_seconds = (entry.end_time - entry.start_time).total_seconds()
        height = duration_seconds * self.pixels_per_second
        width = column_width - 2

        return x, y, width, height

    def _create_task_rect(self, entry: TimelineEntry) -> TaskRectItem:
        """Create a task rectangle item."""
        x, y, width, height = self._calculate_x_y_width_height_task_rect(entry)
        
        task_item = TaskRectItem(entry, x, y, width, height)

        app_ctx = AppContext.get()
        if entry.id == app_ctx.copied_entry_id:
            task_item.set_is_copied(True)
        if entry.id == app_ctx.editing_entry_id:
            task_item.set_is_editing(True)
        
        # Connect click events
        task_item.mousePressEvent = lambda event: self._on_task_clicked(entry.id, event)
        
        self._scene.addItem(task_item)
        self.task_items.append(task_item)
        
        return task_item
    
    def _on_task_clicked(self, entry_id: str, event: Optional[QGraphicsSceneMouseEvent]):
        """Handle task click."""
        if event is not None and event.button() == Qt.MouseButton.RightButton:
            self.task_context_menu.emit(entry_id, event.screenPos())
    
    def set_copied_task(self, entry_id: Optional[str]):
        """Mark a task as copied."""
        for task_item in self.task_items:
            if task_item._is_being_deleted:
                continue
            should_be_copied = (entry_id is not None and task_item.timeline_entry.id == entry_id)
            task_item.set_is_copied(should_be_copied)
    
    def set_editing_task(self, entry_id: Optional[str]):
        """Mark a task as editing."""
        for task_item in self.task_items:
            if task_item._is_being_deleted:
                continue
            should_be_editing = (entry_id is not None and task_item.timeline_entry.id == entry_id)
            task_item.set_is_editing(should_be_editing)

    def scroll_to_entry(self, entry_id: str) -> None:
        """Scroll to make the specified entry visible."""
        for task_item in self.task_items:
            if task_item._is_being_deleted:
                continue
            if task_item.timeline_entry.id == entry_id:
                item_rect = task_item.sceneBoundingRect()
                self.centerOn(item_rect.center())
                break

    def update_zoom(self, pixels_per_second: float):
        """Update zoom level and reposition all items."""
        self.pixels_per_second = pixels_per_second
        self.update_from_schedule()
        
    def clear_all_items(self):
        """Remove all items from scene."""
        # Create a copy of the list to iterate over
        task_items_to_remove = self.task_items.copy()

        # Clear the list first
        self.task_items.clear()
        
        # Then remove items from scene
        for item in task_items_to_remove:
            item.cleanup()
            
            if item.scene() is self._scene:
                self._scene.removeItem(item)
            # Explicitly delete the item
            item.setParentItem(None)
            del item
    
    def scrollContentsBy(self, dx: int, dy: int):
        """Override to sync with ruler widget."""
        super().scrollContentsBy(dx, dy)

    def resizeEvent(self, event: QResizeEvent | None) -> None:
        """Handle resize by updating scene and items."""
        super().resizeEvent(event)
        self._calculate_scene_size()
        self.update_from_schedule()

class DateTimeBar(QWidget):
    def __init__(self):
        super().__init__()
        
        self.app_ctx = AppContext.get()
        self.dates = AppContext.getDates()

        layout = QHBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(10, 5, 10, 5)

        self.date_label = EditableLabel()
        self.date_label.date_edited.connect(self._on_date_edited)
        self.date_label.setToolTip("Double click to edit date")
        self.date_label.setStyleSheet("font-size: 16px;")
        layout.addWidget(self.date_label)

        self.gradient_bar = GradientBar()
        self.gradient_bar.setMinimumWidth(130)
        layout.addWidget(self.gradient_bar)

        self.app_ctx.observation_date_changed.connect(self._on_observation_date_changed)

        self._update_display()

    
    def _on_date_edited(self, new_date: date):
        """Handle date edit from label."""
        self.dates.set_date(new_date)

    def _on_observation_date_changed(self):
        """Handle observation date changes."""
        self._update_display()

    def _update_display(self):
        """Update all display elements."""
        self.date_label.update_date()
        self.gradient_bar.update_times()

class GradientBar(QWidget):
    def __init__(self):
        super().__init__()
        
        self.dates = AppContext.getDates()
        
        self.setMinimumHeight(60)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        self._star_positions: list[tuple[float, float, float]] = self._generate_star_positions()

    def update_times(self):
        self.update()

    def _generate_star_positions(self):
        """Generate random star positions withing the night zone."""
        num_stars = 25
        star_positions = []
        for _ in range(num_stars):
            x_factor = random.uniform(0.2, 0.8)
            y_factor = random.uniform(0.0, 1.0)
            radius = random.uniform(2, 6)
            star_positions.append((x_factor, y_factor, radius))
        return star_positions

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect()

        bar_height = 20
        bar_y = rect.center().y() - bar_height // 2
        bar_rect = QRectF(rect.left(), bar_y, rect.width(), bar_height)

        # --- Create horizontal gradient ---
        grad = QLinearGradient(bar_rect.topLeft(), bar_rect.topRight())
        grad.setColorAt(0.0, QColor("#FFD580"))   # Sunset
        grad.setColorAt(0.2, QColor("#001030"))   # Night
        grad.setColorAt(0.8, QColor("#001030"))   # Night
        grad.setColorAt(1.0, QColor("#FFD580"))   # Sunrise

        painter.fillRect(bar_rect, grad)

        # --- Stars ---
        star_renderer = create_star_svg_renderer()
        for x_factor, y_factor, radius, in self._star_positions:
            x = bar_rect.left() + bar_rect.width() * x_factor
            y = bar_rect.top() + bar_rect.height() * y_factor
            star_rect = QRectF(x - radius/2, y - radius/2, radius, radius)
            star_renderer.render(painter, star_rect)

        # --- border around bar ---
        painter.setPen(QPen(QColor("#FFFFFF"), 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(bar_rect.adjusted(0, 0, -1, -1))

        # --- Text settings ---
        painter.setPen(Qt.GlobalColor.black)
        font = QFont()
        font.setPointSize(11)
        font.setBold(True)
        painter.setFont(font)

        # --- Draw labels ---
        def draw_label(x_factor: float, time: datetime, y_pos: float):
            x = rect.width() * x_factor
            
            # Choose alignment based on x position
            if x_factor <= 0.05:
                align = Qt.AlignmentFlag.AlignLeft
                x_offset = 0
            elif x_factor >= 0.95:
                align = Qt.AlignmentFlag.AlignRight
                x_offset = -60
            else:
                align = Qt.AlignmentFlag.AlignCenter
                x_offset = -30
            
            label_rect = QRectF(x + x_offset, int(y_pos) - 10, 60, 20)
            painter.drawText(label_rect, align, time.strftime('%H:%M'))

        # Positions
        top_y = bar_rect.top() - 10
        bottom_y = bar_rect.bottom() + 12

        # Top labels (sunrise/sunset)
        draw_label(0.0, self.dates.civil_twilight_start, top_y)
        draw_label(1.0, self.dates.civil_twilight_end, top_y)

        # Bottom labels (night start/end)
        draw_label(0.2, self.dates.astronomical_twilight_start, bottom_y)
        draw_label(0.8, self.dates.astronomical_twilight_end, bottom_y)

        painter.end()

class EditableLabel(QLabel):
    """A QLabel that can be edited on double-click without layout shift."""
    date_edited = pyqtSignal(date)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.dates = AppContext.getDates()

        self._current_date: date = self.dates.observation_date
        self._edit_widget: Optional[QLineEdit] = None

        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        
        self.setStyleSheet("""
            QLabel {
                padding: 5px 10px;
                border-radius: 5px;
                background-color: #f8f9fa;
            }
            QLabel:hover {
                background-color: #e9ecef
            }
        """)

    def update_date(self):
        self._current_date = self.dates.observation_date
        self.setText(self.dates.observation_date.strftime('%Y-%m-%d'))

    def mouseDoubleClickEvent(self, event):
        """Handle double click to enter edit mode."""
        if self._edit_widget is not None:
            return

        self._edit_widget = QLineEdit(self.text(), self.parent()) #type: ignore
        self._edit_widget.setStyleSheet("""
            QLineEdit {
                padding: 5px 10px;
                border: 2px solid #007bff;
                border-radius: 5px;
                background-color: white;
                font-size: 16px;
                font-weight: bold;
        """)
        self._edit_widget.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._edit_widget.setGeometry(self.geometry())
            
        self._edit_widget.returnPressed.connect(self._finish_edit)
        self._edit_widget.editingFinished.connect(self._finish_edit)
        self.hide()
        self._edit_widget.show()
        self._edit_widget.setFocus()

    def _finish_edit(self):
        if self._edit_widget is None:
            return

        new_text = self._edit_widget.text().strip()

        try:
            new_date = datetime.strptime(new_text, '%Y-%m-%d').date()
            self._current_date = new_date
            self.setText(new_text)
            self.date_edited.emit(new_date)
        except ValueError:
            if self._current_date:
                self.setText(self._current_date.strftime('%Y-%m-%d'))
            else:
                AppContext.getToast().show_message(
                    "Invalid date format. Use YYYY-MM-DD",
                    ToastNotification.Type.ERROR
                )
        
        self._edit_widget.deleteLater()
        self._edit_widget = None
        self.show()

    
    def keyPressEvent(self, event):
        """Handle ESC key to cancel editing."""
        if event.key() == Qt.Key.Key_Escape and self._edit_widget:
            if self._current_date:
                self.setText(self._current_date.strftime('%Y-%m-%d'))
            self._edit_widget.deleteLater()
            self._edit_widget = None
            self.show()
        else:
            super().keyPressEvent(event)

class ActionPicker(QComboBox):
    """Dropdown where you can pick the action."""
    def __init__(self):
        super().__init__()
        self.setStyleSheet("QComboBox { combobox-popup: 0; }")
        self.setPlaceholderText("Select Action...")

        model = QStandardItemModel()
        self.setModel(model)
        self.populate(model)

        self.currentIndexChanged.connect(self.emit_action_changed)
        self.showPopup()

    def current_action(self):
        return self.currentData(Qt.ItemDataRole.UserRole)

    def setCurrentAction(self, action_key: Optional[str]) -> None:
        self.blockSignals(True)
        if action_key is None:
            self.setCurrentIndex(0)
        else:
            for i in range(self.count()):
                if self.itemData(i, Qt.ItemDataRole.UserRole) == action_key:
                    self.setCurrentIndex(i)
                    break
        self.blockSignals(False)

    def emit_action_changed(self, _):
        action_key = self.current_action()
        if action_key and action_key in ACTION_REGISTRY:
            AppContext.get().set_action_type(action_key)

    def populate(self, model:QStandardItemModel):
        # Get unique categories
        categories = set([attr['category'] for attr in ACTION_REGISTRY.values()])

        # This way I dont need to make a tree model (easier)
        for category in sorted(categories):
            # Header item (not selectable)
            header = QStandardItem(category)
            header.setFlags(Qt.ItemFlag.NoItemFlags)
            model.appendRow(header)

            # Get attributes for this category and sort by position
            attrs = [(k,v) for k, v in ACTION_REGISTRY.items() if v['category'] == category]
            sorted_attrs = sorted(attrs, key=lambda attr: attr[1]['position'])

            for key, attr in sorted_attrs:
                child_item = QStandardItem(f"    {attr['display_name']}")
                child_item.setData(key, Qt.ItemDataRole.UserRole)
                model.appendRow(child_item)

    def showPopup(self):
        super().showPopup()
        view = self.view()
        if not view:
            return
        popup = view.window()
        if not popup:
            return
        popup_rect = popup.geometry()
        window = self.window()
        if not window:
            return
        below = self.mapToGlobal(self.rect().bottomLeft())
        window_height = window.height()
        widget_bottom_y = self.mapTo(window, self.rect().bottomLeft()).y()
        space_below = window_height - widget_bottom_y
        popup.resize(popup_rect.width(), space_below - 10) 
        popup.move(below)

def main():
    app = QApplication([])
    myapp = MainWindow()
    myapp.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    main()
