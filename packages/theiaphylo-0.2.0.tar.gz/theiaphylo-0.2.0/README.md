# TheiaPhylo

A collection of phylogenetic analysis and comparison tools for Theiagen. 

## Install

```bash
python3 -m pip install theiaphylo
```
