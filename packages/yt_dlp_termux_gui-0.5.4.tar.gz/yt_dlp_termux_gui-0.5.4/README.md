# yt-dlp-termux-gui

Simple yet useful Termux GUI for [yt-dlp](https://github.com/yt-dlp/yt-dlp).

**Requires Python 3.8+**

## Tools

### Terminal

- [Termux](https://termux.dev)
  - [Termux:Widget Plugin](https://github.com/termux/termux-widget)
  - [Termux:GUI Plugin](https://github.com/termux/termux-gui)

### CLI

- [yt-dlp](https://github.com/yt-dlp/yt-dlp)
- [termux-api](https://github.com/termux/termux-api)
- [termuxgui](https://github.com/tareksander/termux-gui-python-bindings)

### Modules

- [curl_cffi](https://github.com/lexiforest/curl_cffi)
- [curl-impersonate](https://github.com/lexiforest/curl-impersonate)

`curl_cffi` won't work out of the box on Android unless the `curl-impersonate` binaries are built correctly for Android. This is a common issue with `curl_cffi` on Android ([see here](https://github.com/lexiforest/curl_cffi/issues/74)).

But you can find the compiled binaries at [resources/curl](https://github.com/T0chi/yt-dlp-termux-gui/tree/main/yt_dlp_termux_gui/resources/curl), which was built specifically to work on Android ([see here](https://github.com/xtekky/gpt4free/issues/1107#issuecomment-1908751805)).

## How to use

```bash
Usage: yt-dlp-termux-gui [OPTIONS...] [COMMAND]

Commands:
deps --> Ensure dependencies (install missing packages)
launch --> Launch the GUI
widget --> Ensure Termux:Widget for the GUI

Options:
--verbose <silent|debug|info|warning|error|critical> --> Set logging level
--silent --> Disable ALL GUI logs in termux
--widget-name --> Print widget name
--widget-script-name --> Print widget script filename
--settings-path --> Print settings path
--print-settings --> Print current settings
--reset-settings --> Reset settings
-h, --help --> Show this help message
-v, -V, --version --> Print version

Options [deps]:
--overwrite --> Overwrite 'curl-impersonate' compiled binaries if they already exist

Options [launch]:
--no-activity-logs --> Disable GUI activity logs in Termux
--init-logs --> Enable GUI initialization logs in Termux by the GUI
```
