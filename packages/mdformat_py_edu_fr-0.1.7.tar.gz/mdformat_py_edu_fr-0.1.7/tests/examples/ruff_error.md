---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
    format_version: 0.13
kernelspec:
  display_name: Python 3 (ipykernel)
  language: python
  name: python3
---

Check nice error for Python syntax error.

```{code-cell} ipython3
def func:
    a === 2
```
