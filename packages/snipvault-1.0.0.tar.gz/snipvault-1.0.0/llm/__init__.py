"""LLM integration layer for SnipVault."""
