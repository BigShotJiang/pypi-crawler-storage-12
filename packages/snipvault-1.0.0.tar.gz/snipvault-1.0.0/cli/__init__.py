"""CLI package for SnipVault."""
