"""CLI commands for SnipVault."""
