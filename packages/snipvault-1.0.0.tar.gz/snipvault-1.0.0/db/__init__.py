"""Database layer for SnipVault."""
