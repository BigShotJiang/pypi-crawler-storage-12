# -*- mode: python; coding: utf-8 -*-
#
# Copyright (C) 2023 Benjamin Thomas Schwertfeger
# All rights reserved.
# https://github.com/btschwertfeger
#
#
# This file is only used by sphinx for liking the package to the documentation.

from setuptools import setup

setup()
