# `unxt.quantity`

```{eval-rst}

.. currentmodule:: unxt.quantity

.. automodule:: unxt.quantity
    :exclude-members: aval, default, materialise, enable_materialise

```
