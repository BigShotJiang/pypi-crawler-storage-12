"""Config models for all bridge rules."""
