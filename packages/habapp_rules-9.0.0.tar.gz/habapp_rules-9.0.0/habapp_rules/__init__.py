"""Define all rules for HABApp."""

import pathlib

__version__ = "9.0.0"
BASE_PATH = pathlib.Path(__file__).parent.parent.resolve()
