"""Core module of habapp_rules."""
