"""Config models for all energy rules."""
