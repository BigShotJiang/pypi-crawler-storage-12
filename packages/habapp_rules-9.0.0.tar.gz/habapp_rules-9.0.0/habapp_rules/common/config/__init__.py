"""Config models for all common rules."""
