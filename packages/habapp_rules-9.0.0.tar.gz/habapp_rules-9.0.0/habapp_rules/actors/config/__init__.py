"""Config models for all actor rules."""
