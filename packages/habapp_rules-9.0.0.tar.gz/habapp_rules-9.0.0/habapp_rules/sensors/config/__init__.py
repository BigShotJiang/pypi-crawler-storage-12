"""Config models for all sensor rules."""
