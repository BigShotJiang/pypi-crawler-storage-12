"""Config models for all system rules."""
