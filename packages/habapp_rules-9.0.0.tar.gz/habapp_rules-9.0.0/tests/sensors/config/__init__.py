"""Tests for all config models of sensor rules."""
