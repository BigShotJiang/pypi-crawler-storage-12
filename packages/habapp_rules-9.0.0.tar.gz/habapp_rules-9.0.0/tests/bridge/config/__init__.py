"""Test all config models for all bridge rules."""
