"""Tests for all energy config models."""
