"""Test all config models for all common rules."""
