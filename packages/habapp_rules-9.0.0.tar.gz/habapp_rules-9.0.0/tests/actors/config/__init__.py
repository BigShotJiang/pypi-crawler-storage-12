"""Tests for config models for all actor rules."""
