# Video Tutorials

## Sneaky REST APIs With Django Ninja

[realpython.com/lessons/sneaky-rest-apis-with-django-ninja-overview/](https://realpython.com/lessons/sneaky-rest-apis-with-django-ninja-overview/)


## Creating a CRUD API with Django-Ninja by BugBytes (English)
<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PLXskueZ7apWgNasQPt6PYhlKNKNEghT3T" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
