# NinjaAPI

::: ninja.main.NinjaAPI
    rendering:
      show_signature: False
      group_by_category: False
