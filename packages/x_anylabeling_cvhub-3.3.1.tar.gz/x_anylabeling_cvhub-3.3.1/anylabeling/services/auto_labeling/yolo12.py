from .__base__.yolo import YOLO


class YOLO12(YOLO):
    pass
