from .yolov10 import YOLOv10


class DocLayoutYOLO(YOLOv10):
    pass
