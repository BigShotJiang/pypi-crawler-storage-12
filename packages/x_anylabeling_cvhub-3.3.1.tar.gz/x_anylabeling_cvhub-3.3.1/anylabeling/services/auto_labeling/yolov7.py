from .__base__.yolo import YOLO


class YOLOv7(YOLO):
    pass
