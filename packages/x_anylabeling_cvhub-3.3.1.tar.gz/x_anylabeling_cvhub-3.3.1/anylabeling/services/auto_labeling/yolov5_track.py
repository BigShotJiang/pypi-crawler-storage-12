from .__base__.yolo import YOLO


class YOLOv5_Tracker(YOLO):
    pass
