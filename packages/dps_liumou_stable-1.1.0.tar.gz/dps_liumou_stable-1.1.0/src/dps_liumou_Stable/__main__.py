#!/usr/bin/env python3
"""
DPS - Docker Pull Smart 命令行工具入口点
"""

from . import main

if __name__ == "__main__":
    main()