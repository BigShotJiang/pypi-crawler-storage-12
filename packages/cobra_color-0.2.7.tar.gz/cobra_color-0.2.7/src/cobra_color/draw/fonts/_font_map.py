
from enum import Enum


class FontName(str, Enum):
    GAMEPLAY = "Gameplay.ttf"
    LLDISCO = "LLDISCO_.TTF"
