Template tags
=============

Tag reference
-------------

.. automodule:: dynamicforms.templatetags.dynamicforms
   :members: get_data_template, render_field,render_form,set_var,set_var_conditional,
      render_table_commands, table_columns_count

Filter reference
----------------

.. automodule:: dynamicforms.templatetags.dynamicforms
   :members:
   :exclude-members: get_data_template, render_field,render_form,set_var,set_var_conditional,
      render_table_commands, table_columns_count
   :noindex:
