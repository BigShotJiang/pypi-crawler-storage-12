# checklist

タスク管理とチェックリスト作成 - 詳細は [.roo/docs/speckit.checklist.md](.roo/docs/speckit.checklist.md) を参照