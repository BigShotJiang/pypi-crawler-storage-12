# tasks

タスク分解と進捗管理 - 詳細は [.roo/docs/speckit.tasks.md](.roo/docs/speckit.tasks.md) を参照