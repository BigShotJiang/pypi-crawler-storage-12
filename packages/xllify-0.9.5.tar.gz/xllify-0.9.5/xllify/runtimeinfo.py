#!/usr/bin/env python3
"""
Python Runtime Config Extractor for xllify

Parses Python files to extract runtime configuration like spawn_count
from xllify.configure_spawn_count() calls.

Usage:
    xllify-runtimeinfo <script.py>
    python -m xllify.runtimeinfo <script.py>

Output:
    JSON object containing runtime configuration:
    {
      "runtime": {
        "spawn_count": 2
      }
    }
"""

import ast
import json
import sys
from typing import Optional
from pathlib import Path


class RuntimeConfigExtractor(ast.NodeVisitor):
    """AST visitor to extract xllify runtime configuration"""

    def __init__(self):
        self.spawn_count: Optional[int] = None

    def visit_Expr(self, node: ast.Expr):
        """Visit expression statements to find configure_spawn_count() calls"""
        if isinstance(node.value, ast.Call):
            self._check_spawn_count_call(node.value)
        self.generic_visit(node)

    def _check_spawn_count_call(self, call: ast.Call):
        """Check if this is a configure_spawn_count() call and extract the value"""
        # Check for xllify.configure_spawn_count(...)
        if isinstance(call.func, ast.Attribute):
            if (
                call.func.attr == "configure_spawn_count"
                and isinstance(call.func.value, ast.Name)
                and call.func.value.id == "xllify"
            ):
                self._extract_spawn_count(call)
        # Check for configure_spawn_count(...) where it was imported from xllify
        elif isinstance(call.func, ast.Name):
            if call.func.id == "configure_spawn_count":
                self._extract_spawn_count(call)

    def _extract_spawn_count(self, call: ast.Call):
        """Extract the spawn_count value from the function call"""
        if call.args and isinstance(call.args[0], ast.Constant):
            if isinstance(call.args[0].value, int):
                self.spawn_count = call.args[0].value


def extract_runtime_config(source_code: str) -> Optional[int]:
    """Parse Python source code and extract runtime configuration

    Returns:
        spawn_count if configured via xllify.configure_spawn_count(), otherwise None
    """
    try:
        tree = ast.parse(source_code)
        extractor = RuntimeConfigExtractor()
        extractor.visit(tree)
        return extractor.spawn_count
    except SyntaxError as e:
        print(f"Syntax error in Python file: {e}", file=sys.stderr)
        return None


def output_json(spawn_count: Optional[int] = None) -> str:
    """Generate JSON output for runtime configuration"""
    output = {
        "runtime": {
            "spawn_count": spawn_count if spawn_count is not None else 1
        }
    }
    return json.dumps(output, indent=2)


def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <script.py>", file=sys.stderr)
        sys.exit(1)

    filename = sys.argv[1]

    try:
        with open(filename, "r", encoding="utf-8") as f:
            source_code = f.read()
    except FileNotFoundError:
        print(f"Error: Could not open file {filename}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error reading file: {e}", file=sys.stderr)
        sys.exit(1)

    spawn_count = extract_runtime_config(source_code)
    print(output_json(spawn_count))
    return 0


if __name__ == "__main__":
    sys.exit(main())
