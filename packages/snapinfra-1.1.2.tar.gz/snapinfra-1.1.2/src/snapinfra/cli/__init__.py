"""CLI interface for AIAC."""

from .main import main

__all__ = ["main"]