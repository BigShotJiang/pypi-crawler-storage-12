"""CLI interface for OSPAC."""

from ospac.cli.commands import cli

__all__ = ["cli"]