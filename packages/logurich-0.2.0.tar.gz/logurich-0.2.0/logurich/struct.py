extra_logger = {
    "__min_level": None,
    "__level_upper_only": None,
    "__level_per_module": None,
    "__rich_highlight": False,
}
