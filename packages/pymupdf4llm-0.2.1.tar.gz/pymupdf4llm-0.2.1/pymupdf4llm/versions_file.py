# Generated file - do not edit.
MINIMUM_PYMUPDF_VERSION = (1, 26, 6)
VERSION = '0.2.1'
