class UnsupportedTable(Exception):
    pass
