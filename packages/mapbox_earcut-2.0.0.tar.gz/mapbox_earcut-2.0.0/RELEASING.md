# Releasing a new version

1. Update CHANGELOG.md
2. Update VERSION in setup.py
3. `git tag`
4. `git push --tags`
