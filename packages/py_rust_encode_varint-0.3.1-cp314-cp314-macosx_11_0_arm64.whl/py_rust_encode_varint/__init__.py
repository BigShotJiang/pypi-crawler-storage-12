from .py_rust_encode_varint import *

__doc__ = py_rust_encode_varint.__doc__
if hasattr(py_rust_encode_varint, "__all__"):
    __all__ = py_rust_encode_varint.__all__