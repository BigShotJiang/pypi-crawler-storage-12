from .scraper import Grabber

__author__ = 'Riain Ó Tuathail <rotuathail01@gmail.com>'

__all__ = ['Grabber']
