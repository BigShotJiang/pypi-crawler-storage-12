# Orchestrator Guide

## Overview

The **Orchestrator** is an intelligent agent routing system that uses Large Language Models (LLMs) to analyze tasks and automatically select the best agent(s) to handle them. This solves the problem of determining which model/provider an API key belongs to by requiring users to explicitly specify both the LLM provider and the API key.

## Key Features

✅ **LLM-Powered Decision Making** - Uses AI to intelligently route tasks based on agent capabilities  
✅ **Multi-Provider Support** - Works with OpenAI, Anthropic, and Google  
✅ **Confidence Scoring** - Provides confidence levels for agent selections  
✅ **Reasoning Transparency** - Explains why each agent was selected  
✅ **TaskDelegator Integration** - Seamlessly integrates with existing delegation workflows  

## Architecture

```
User Task
    ↓
Orchestrator (with specified LLM)
    ↓
Analyzes agent cards & skills
    ↓
Selects best agent(s) + provides reasoning
    ↓
TaskDelegator executes task
    ↓
Result returned to user
```

## Why This Design?

**Problem**: There's no way to automatically determine which LLM provider an API key belongs to. If the orchestrator assumes GPT-4o but the user's key is for Anthropic, the entire flow breaks.

**Solution**: Users must explicitly specify:
1. The LLM provider (OpenAI, Anthropic, or Google)
2. The API key for that provider
3. The model to use for orchestration decisions

## Quick Start

### 1. Installation

```bash
pip install synqed openai python-dotenv

# Optional: for other providers
pip install anthropic google-generativeai
```

### 2. Basic Usage

```python
from synqed import Orchestrator, LLMProvider, Agent

# Create orchestrator with your chosen LLM
orchestrator = Orchestrator(
    provider=LLMProvider.OPENAI,  # REQUIRED: specify the provider
    api_key="sk-...",              # REQUIRED: provide the API key
    model="gpt-4o",                # REQUIRED: specify the model
)

# Register agents
orchestrator.register_agent(agent.card, agent.url)

# Get intelligent routing decision
result = await orchestrator.orchestrate("Find me a recipe for pasta")

print(f"Selected: {result.selected_agents[0].agent_name}")
print(f"Confidence: {result.selected_agents[0].confidence}")
print(f"Reasoning: {result.selected_agents[0].reasoning}")
```

### 3. Integration with TaskDelegator

```python
from synqed import Orchestrator, TaskDelegator, LLMProvider

# Create orchestrator
orchestrator = Orchestrator(
    provider=LLMProvider.OPENAI,
    api_key=os.getenv("OPENAI_API_KEY"),
    model="gpt-4o",
)

# Create TaskDelegator with orchestrator
delegator = TaskDelegator(orchestrator=orchestrator)

# Register agents (automatically registered with orchestrator too)
delegator.register_agent(recipe_agent)
delegator.register_agent(shopping_agent)

# Submit task - orchestrator handles routing
result = await delegator.submit_task("I need a recipe and shopping list")
```

## Supported LLM Providers

### OpenAI

```python
orchestrator = Orchestrator(
    provider=LLMProvider.OPENAI,
    api_key=os.getenv("OPENAI_API_KEY"),
    model="gpt-4o",  # or "gpt-4-turbo", "gpt-3.5-turbo"
)
```

**Required**: `pip install openai`

### Anthropic

```python
orchestrator = Orchestrator(
    provider=LLMProvider.ANTHROPIC,
    api_key=os.getenv("ANTHROPIC_API_KEY"),
    model="claude-3-5-sonnet-20241022",  # or "claude-3-opus-20240229"
)
```

**Required**: `pip install anthropic`

### Google

```python
orchestrator = Orchestrator(
    provider=LLMProvider.GOOGLE,
    api_key=os.getenv("GOOGLE_API_KEY"),
    model="gemini-pro",  # or "gemini-1.5-pro"
)
```

**Required**: `pip install google-generativeai`

## Configuration Options

```python
orchestrator = Orchestrator(
    provider=LLMProvider.OPENAI,     # REQUIRED: LLM provider
    api_key="your-key",              # REQUIRED: API key
    model="gpt-4o",                  # REQUIRED: Model name
    temperature=0.3,                 # Optional: 0.0-1.0 (default: 0.7)
    max_tokens=2000,                 # Optional: Max response tokens (default: 2000)
)
```

**Recommended**: Use `temperature=0.3` for more consistent routing decisions.

## API Reference

### Orchestrator Class

#### `register_agent(agent_card, agent_url, agent_id=None)`
Register an agent with the orchestrator.

```python
orchestrator.register_agent(
    agent_card=my_agent.card,
    agent_url=my_agent.url,
    agent_id="MyAgent"  # Optional
)
```

#### `orchestrate(task, context=None, max_agents=3)`
Analyze a task and select the best agent(s).

**Returns**: `OrchestrationResult` with:
- `selected_agents`: List of `AgentSelection` objects
- `execution_plan`: String describing how agents should work together
- `alternative_agents`: Optional list of backup options

```python
result = await orchestrator.orchestrate(
    task="Find a recipe and create shopping list",
    context={"dietary_restrictions": ["vegetarian"]},
    max_agents=2
)
```

#### `list_agents()`
List all registered agents.

```python
agents = orchestrator.list_agents()
for agent in agents:
    print(f"{agent['name']}: {agent['description']}")
```

### OrchestrationResult

```python
@dataclass
class OrchestrationResult:
    task: str                                    # Original task
    selected_agents: list[AgentSelection]        # Selected agents
    execution_plan: str                          # How to execute
    alternative_agents: list[AgentSelection]     # Backup options
```

### AgentSelection

```python
@dataclass
class AgentSelection:
    agent_id: str              # Agent identifier
    agent_name: str            # Human-readable name
    confidence: float          # 0.0 to 1.0
    reasoning: str             # Why this agent was selected
    recommended_skills: list   # Which skills to use
```

## Examples

### Example 1: Standalone Orchestrator

```python
import asyncio
import os
from synqed import Orchestrator, LLMProvider, Agent

async def main():
    # Create orchestrator
    orchestrator = Orchestrator(
        provider=LLMProvider.OPENAI,
        api_key=os.getenv("OPENAI_API_KEY"),
        model="gpt-4o",
    )
    
    # Create agents
    recipe_agent = Agent(
        name="RecipeAgent",
        description="Search and recommend recipes",
        skills=["recipe_search", "ingredient_substitution"]
    )
    
    shopping_agent = Agent(
        name="ShoppingAgent",
        description="Create shopping lists",
        skills=["create_shopping_list", "price_comparison"]
    )
    
    # Register
    orchestrator.register_agent(recipe_agent.card, recipe_agent.url)
    orchestrator.register_agent(shopping_agent.card, shopping_agent.url)
    
    # Orchestrate
    result = await orchestrator.orchestrate(
        "I need pasta ingredients"
    )
    
    # View results
    for selection in result.selected_agents:
        print(f"Agent: {selection.agent_name}")
        print(f"Confidence: {selection.confidence:.1%}")
        print(f"Reasoning: {selection.reasoning}")

asyncio.run(main())
```

### Example 2: With TaskDelegator

See `examples/multi-agentic/orchestrator_example.py` for a complete example.

### Example 3: Multiple Providers

```python
# Use different providers for different orchestrators
openai_orchestrator = Orchestrator(
    provider=LLMProvider.OPENAI,
    api_key=os.getenv("OPENAI_API_KEY"),
    model="gpt-4o"
)

anthropic_orchestrator = Orchestrator(
    provider=LLMProvider.ANTHROPIC,
    api_key=os.getenv("ANTHROPIC_API_KEY"),
    model="claude-3-5-sonnet-20241022"
)

# Compare routing decisions
openai_result = await openai_orchestrator.orchestrate(task)
anthropic_result = await anthropic_orchestrator.orchestrate(task)
```

## Best Practices

### 1. Choose the Right LLM

- **OpenAI GPT-4o**: Best overall performance, fast, good at following instructions
- **Anthropic Claude**: Excellent reasoning, more verbose explanations
- **Google Gemini**: Cost-effective, good for simpler routing decisions

### 2. Optimize Temperature

```python
# For consistent routing (recommended)
temperature=0.3

# For more creative/varied routing
temperature=0.7
```

### 3. Provide Good Agent Descriptions

```python
# ❌ Bad
Agent(name="Agent1", description="Does stuff", skills=["thing"])

# ✅ Good
Agent(
    name="RecipeSearchAgent",
    description="Searches for recipes by ingredient, cuisine type, or dietary restriction",
    skills=[{
        "id": "recipe_search",
        "name": "Recipe Search",
        "description": "Find recipes matching specific criteria",
        "tags": ["cooking", "food", "recipes"],
        "examples": ["Find pasta recipes", "Vegetarian dinner ideas"]
    }]
)
```

### 4. Handle Errors Gracefully

```python
try:
    result = await orchestrator.orchestrate(task)
except ValueError as e:
    # Handle orchestration errors
    print(f"Orchestration failed: {e}")
    # Fall back to simple routing
    result = await delegator.submit_task(task, use_orchestrator=False)
```

### 5. Monitor Confidence Scores

```python
result = await orchestrator.orchestrate(task)
if result.selected_agents[0].confidence < 0.6:
    print("⚠️ Low confidence - review the selection")
    print(f"Alternatives: {result.alternative_agents}")
```

## Running the Examples

### Quick Start Example

```bash
cd Synq/examples/intro
python orchestrator_quickstart.py
```

### Full Multi-Agent Example

```bash
cd Synq/examples/multi-agentic
python orchestrator_example.py
```

## Troubleshooting

### "No API key found"

**Solution**: Create a `.env` file with your API key:

```bash
# .env
OPENAI_API_KEY='sk-...'
```

### "Failed to parse orchestration response"

**Cause**: LLM returned invalid JSON  
**Solution**: 
- Use a more capable model (e.g., GPT-4o instead of GPT-3.5)
- Lower the temperature to 0.3 for more consistent output
- Check your max_tokens setting (should be at least 1000)

### "Orchestrator selection failed, falling back to simple matching"

**Cause**: LLM API call failed  
**Solution**: TaskDelegator automatically falls back to skill-based matching. Check:
- API key is valid
- You have sufficient API credits
- Network connectivity

## Environment Variables

Create a `.env` file in your project:

```bash
# OpenAI
OPENAI_API_KEY='sk-...'

# Anthropic (optional)
ANTHROPIC_API_KEY='sk-ant-...'

# Google (optional)
GOOGLE_API_KEY='AI...'
```

## Performance Considerations

- **Latency**: Orchestration adds ~1-3 seconds per task (LLM call overhead)
- **Cost**: Each orchestration costs ~$0.01-0.03 depending on provider/model
- **Caching**: Consider caching orchestration results for identical tasks
- **Fallback**: TaskDelegator automatically falls back to simple routing if orchestration fails

## Comparison: Orchestrator vs Simple Routing

| Feature | Simple Routing | Orchestrator |
|---------|---------------|--------------|
| Speed | ⚡ Instant | 🐢 1-3 seconds |
| Accuracy | ⭐⭐ Skill matching only | ⭐⭐⭐⭐⭐ Intelligent analysis |
| Cost | 💰 Free | 💰💰 $0.01-0.03/task |
| Context awareness | ❌ No | ✅ Yes |
| Reasoning | ❌ No | ✅ Detailed explanation |
| Multi-agent coordination | ❌ Limited | ✅ Sophisticated |

## When to Use Orchestrator

✅ **Use Orchestrator when:**
- Task complexity varies significantly
- You have many specialized agents
- You need explainable routing decisions
- Context matters for agent selection
- Cost/latency tradeoff is acceptable

❌ **Use simple routing when:**
- You have few agents with clear distinctions
- Speed is critical (real-time applications)
- Cost must be minimized
- Tasks map directly to specific skills

## Contributing

To add a new LLM provider:

1. Add to `LLMProvider` enum in `orchestrator.py`
2. Implement initialization in `_init_llm_client()`
3. Implement API call in `_call_llm()`
4. Update documentation

## Support

- **Examples**: `Synq/examples/intro/orchestrator_quickstart.py`
- **Full Demo**: `Synq/examples/multi-agentic/orchestrator_example.py`
- **API Docs**: See docstrings in `synqed/orchestrator.py`

---

**Built with Synq** - Simplified multi-agent orchestration for everyone.

