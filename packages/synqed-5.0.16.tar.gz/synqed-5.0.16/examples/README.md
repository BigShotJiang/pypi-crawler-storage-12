# Synq Examples

This directory contains complete working examples demonstrating different aspects of the Synq platform.

## Prerequisites

All examples require:
- Python 3.10+
- OpenAI API key (for LLM-powered agents and orchestrator)

```bash
pip install synqed openai python-dotenv

# Optional: for other LLM providers
pip install anthropic google-generativeai
```

Create a `.env` file in this directory with:
```
OPENAI_API_KEY='your-api-key-here'

# Optional: for other providers
ANTHROPIC_API_KEY='your-key-here'
GOOGLE_API_KEY='your-key-here'
```

## Examples

### 1. Basic Agent (`agent.py`)
**What it demonstrates**: Creating and running a single AI agent

**Use case**: Simple customer support assistant

**Key concepts**:
- Agent creation with custom logic
- AgentServer setup
- Defining agent capabilities

**Run it**:
```bash
python agent.py
```

Then in another terminal:
```bash
python client.py
```

---

### 2. Client Interaction (`client.py`)
**What it demonstrates**: Two ways to interact with agents

**Features**:
- `ask()` - Get complete responses
- `stream()` - Real-time streaming responses

**Requires**: First run `agent.py` in another terminal

**Run it**:
```bash
python client.py
```

---

### 3. Agent Card Discovery (`agent_card.py`)
**What it demonstrates**: Discovering agent capabilities

**Use case**: View agent metadata, skills, and supported features

**What you'll see**:
- Agent name and description
- Available skills
- Supported capabilities (streaming, auth, etc.)

**Requires**: First run `agent.py` in another terminal

**Run it**:
```bash
python agent_card.py
```

---

### 4. Enterprise RFP Delegation (`delegator_rfp_system.py`) ⭐ **Enterprise B2B**
**What it demonstrates**: Multi-agent coordination for complex enterprise workflows

**Use case**: Automated RFP (Request for Proposal) response system

**Business value**:
- Reduces RFP response time from days to minutes
- Coordinates across multiple departments (technical, financial, legal)
- Demonstrates real B2B enterprise automation

**Architecture**:
```
                    ┌─────────────────────┐
                    │   TaskDelegator     │
                    │   (Orchestrator)    │
                    └──────────┬──────────┘
                               │
            ┌──────────────────┼──────────────────┐
            │                  │                  │
    ┌───────▼────────┐ ┌──────▼──────┐ ┌────────▼────────┐
    │ Requirements   │ │  Technical  │ │    Pricing      │
    │   Analyst      │ │  Architect  │ │    Analyst      │
    └────────────────┘ └─────────────┘ └─────────────────┘
            │
    ┌───────▼────────┐
    │  Compliance    │
    │     Agent      │
    └────────────────┘
```

**The 4 Agents**:
1. **Requirements Analyst** - Extracts key requirements from RFP
2. **Technical Architect** - Designs cloud migration solution
3. **Pricing Analyst** - Creates comprehensive pricing proposals
4. **Compliance Agent** - Reviews legal and compliance requirements

**Key features demonstrated**:
- Sequential delegation (requirements → design → pricing)
- Parallel delegation (technical + compliance simultaneously)
- Multi-agent coordination via TaskDelegator
- Context passing between agents
- Background server management

**Run it**:
```bash
python delegator_rfp_system.py
```

**What happens**:
1. Starts 4 specialized agents (ports 8001-8004)
2. Registers them with TaskDelegator
3. Processes a sample enterprise RFP through the pipeline
4. Generates complete proposal with all sections
5. Shows time saved vs traditional process

**Expected output**:
- Requirements analysis
- Technical architecture and migration plan
- Comprehensive pricing breakdown
- Compliance and legal review
- Final proposal summary

---

## Running Multiple Examples

**Terminal 1** - Start an agent:
```bash
python agent.py
```

**Terminal 2** - Interact with the agent:
```bash
python client.py
# or
python agent_card.py
```

**Terminal 1 (Alternative)** - Run complete multi-agent demo:
```bash
python delegator_rfp_system.py
```
(This is self-contained and doesn't require multiple terminals)

---

## Troubleshooting

### "Missing OpenAI API Key"
- Create a `.env` file in the `examples/` directory
- Add: `OPENAI_API_KEY='sk-...'`

### "Connection refused" or "Cannot connect to agent"
- Make sure `agent.py` is running first
- Check that the ports (8000, 8001-8004) are not already in use
- Wait a few seconds after starting agents before running clients

### "Port already in use"
- Change the port number in the script
- Or kill the process using the port: `lsof -ti:8000 | xargs kill`

---

## Next Steps

After running these examples:

1. **Modify agent logic** - Update the `agent_logic()` functions to use different LLMs or add custom business logic
2. **Add more agents** - Create specialized agents for your use case
3. **Integrate with your systems** - Connect agents to databases, APIs, or enterprise tools
4. **Deploy to production** - Use the same code in production environments
5. **Build custom workflows** - Create multi-agent workflows specific to your business needs

---

## Example Use Cases by Industry

### Financial Services
- Loan application processing (credit check → risk assessment → approval)
- Fraud detection pipeline (transaction analysis → alert → investigation)
- Regulatory reporting (data collection → validation → compliance check)

### Healthcare
- Patient intake (registration → insurance verification → appointment scheduling)
- Medical records processing (OCR → data extraction → validation)
- Clinical trial coordination (screening → enrollment → monitoring)

### Manufacturing
- Supply chain orchestration (inventory → procurement → logistics)
- Quality control pipeline (inspection → analysis → reporting)
- Maintenance scheduling (monitoring → diagnosis → work order)

### Enterprise IT
- **RFP Response** (✓ included in examples)
- Incident management (triage → diagnosis → resolution)
- Onboarding automation (access provisioning → training → compliance)

---

## Learn More

- **Main Documentation**: See `../README.md`
- **A2A Protocol**: https://a2a-protocol.org
- **Synq Package**: https://pypi.org/project/synqed/

---

**Questions?** Contact the Synq team or check the main README.

