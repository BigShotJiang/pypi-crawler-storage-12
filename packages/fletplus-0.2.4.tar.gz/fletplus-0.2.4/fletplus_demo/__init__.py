"""Aplicación de demostración para FletPlus."""

from .app import run


def main() -> None:
    """Punto de entrada compatible con scripts de consola."""
    run()


__all__ = ["main"]
