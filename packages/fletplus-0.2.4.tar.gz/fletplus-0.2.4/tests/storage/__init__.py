"""Pruebas unitarias para los proveedores de almacenamiento."""

