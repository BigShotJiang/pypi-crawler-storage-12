"""Utilidades para ejecutar ejemplos sin instalar el paquete."""

from __future__ import annotations

from . import ensure_project_root

__all__ = ["ensure_project_root"]
