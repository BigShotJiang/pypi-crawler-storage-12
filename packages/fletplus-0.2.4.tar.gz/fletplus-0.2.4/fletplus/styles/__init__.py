from fletplus.styles.style import Style

__all__ = ["Style"]
