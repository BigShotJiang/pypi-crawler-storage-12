"""Herramientas de línea de comandos para FletPlus."""

from .main import app

__all__ = ["app"]
