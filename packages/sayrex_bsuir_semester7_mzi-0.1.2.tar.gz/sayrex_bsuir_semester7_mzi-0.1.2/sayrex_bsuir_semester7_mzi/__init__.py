from .lab4 import lab4
from .lab5 import lab5

__all__ = [
    "lab4",
    "lab5"
]