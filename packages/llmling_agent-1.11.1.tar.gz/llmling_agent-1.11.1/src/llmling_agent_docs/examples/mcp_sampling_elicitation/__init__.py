"""Example demonstrating MCP server with sampling and elicitation tools."""

TITLE = "MCP Sampling & Elicitation"
ICON = "octicon:zap-16"
