"""Example demonstrating MCP server integration with git tools."""

TITLE = "MCP Servers (YAML)"
ICON = "octicon:file-code-16"
