"""Minitrino CLI package."""
