* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* AITIC S.A. <info@aitic.com.ar>
* Quartile Limited <info@quartile.co>
* `Studio73 <https://www.studio73.es>`_:

    * Miguel Gandia
* `APSL-Nagarro <https://www.apsl.tech>`_:

    * Antoni Marroig <amarroig@apsl.net>
