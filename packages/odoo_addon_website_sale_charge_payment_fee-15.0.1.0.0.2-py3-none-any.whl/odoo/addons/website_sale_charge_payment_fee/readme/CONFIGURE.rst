Click on Accounting -> Configuration -> Payments -> Payment Acquirers

Open an acquirer and in CHARGE PAYMENT FEE tab, you can set the fee to be charged to customer.
