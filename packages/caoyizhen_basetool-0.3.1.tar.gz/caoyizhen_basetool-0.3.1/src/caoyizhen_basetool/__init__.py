"""
The caoyizhen_basetool library provides a tool to help you to dealing with data in Python.
"""