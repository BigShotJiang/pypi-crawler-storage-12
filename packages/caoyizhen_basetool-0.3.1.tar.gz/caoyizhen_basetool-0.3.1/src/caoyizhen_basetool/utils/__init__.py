from .utils import singleton
from .log_manage import LoggerManager