# Pygments Vex Lexer
Pygments Lexer for the Vex language used in Side Effects Houdini. Supports wrangle binding syntax: `v@vel, v[]@colors, @P` and backtick strings for expression injection in wrangle snippets.
