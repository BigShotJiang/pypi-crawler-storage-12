from setuptools import find_packages, setup

setup(
    name="sinq",
    version="0.1",
    description="SINQ quantization method",
    packages=find_packages()
)
