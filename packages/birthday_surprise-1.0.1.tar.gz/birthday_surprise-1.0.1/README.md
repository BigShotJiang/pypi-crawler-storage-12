Install:

    pip install birthday_surprise

Run:

    birthday