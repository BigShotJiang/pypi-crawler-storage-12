"""Actions defined in fabricatio-agent."""
