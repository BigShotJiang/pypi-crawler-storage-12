"""PyToon version information."""

__version__ = "1.0.1"
__version_info__ = (1, 0, 1)
