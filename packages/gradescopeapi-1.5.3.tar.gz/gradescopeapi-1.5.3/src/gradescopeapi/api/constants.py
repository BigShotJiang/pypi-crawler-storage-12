"""constants.py
Constants file for FastAPI. Specifies any variable or other object which should remain the same across all environments.
"""

BASE_URL = "https://www.gradescope.com"
