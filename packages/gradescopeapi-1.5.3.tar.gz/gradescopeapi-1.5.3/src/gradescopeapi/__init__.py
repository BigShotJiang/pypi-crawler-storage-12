DEFAULT_GRADESCOPE_BASE_URL = "https://www.gradescope.com"
