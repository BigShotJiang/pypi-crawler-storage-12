"""MCP Vector Search - Cloud-based vector code search"""
__version__ = "1.0.2"
