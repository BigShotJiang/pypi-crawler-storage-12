1.  Go to *Helpdesk* or *Helpdesk \> Dashboard* to see the tickets
    dashboard.
2.  In the Kanban view, you can see datetime in two colors: Green and
    Red. If is green, SLA is ok, if is red, SLA is wrong.
3.  In the form, you will see all affected SLAs that were computed on creation.
4.  If the SLA should change due a change on the ticket, you can recompute it.
