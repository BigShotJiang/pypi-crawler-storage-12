"""Terminal widget package with modular components."""

from par_term_emu_tui_rust.terminal_widget.terminal_widget import TerminalWidget

__all__ = ["TerminalWidget"]
