"""Shell session recording for deep context capture."""

from whai.shell.session import launch_shell_session

__all__ = ["launch_shell_session"]

