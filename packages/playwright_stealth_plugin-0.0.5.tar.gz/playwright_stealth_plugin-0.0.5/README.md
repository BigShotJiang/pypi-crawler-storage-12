# playwright-stealth-plugin
Playwright Plugin for Anti-Bot Stealth