---
jupyter:
  kernelspec:
    display_name: Python 3
    language: python
    name: python3
  nbformat: 4
  nbformat_minor: 5
---

::: {#b32297a4 .cell .raw}
```{=ipynb}
---

This is a complex paragraph
that is split over multiple lines.

It also includes blank lines.


---
```
:::

::: {#0b3bde0a .cell .code}
``` python
print("Hello, World!")
```
:::
