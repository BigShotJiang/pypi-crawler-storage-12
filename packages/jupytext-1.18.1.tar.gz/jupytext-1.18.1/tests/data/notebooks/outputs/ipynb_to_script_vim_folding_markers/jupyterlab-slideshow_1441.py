# ---
# jupyter:
#   jupytext:
#     cell_markers: '{{{,}}}'
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# {{{ [markdown] @deathbeds/jupyterlab-fonts={"styles": {"": {"body[data-jp-deck-mode='presenting'] &": {"right": "0", "top": "30%", "width": "25%", "z-index": 1}}}} jupyterlab-slideshow={"layer": "slide"}
# > **Note**
# > 
# > `slide` layer with a `top` of `30%`
# }}}
