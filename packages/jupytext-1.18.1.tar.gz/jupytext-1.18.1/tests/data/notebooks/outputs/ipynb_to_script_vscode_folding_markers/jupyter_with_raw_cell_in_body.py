# ---
# jupyter:
#   jupytext:
#     cell_markers: region,endregion
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

1+2+3

# region active=""
# This is a raw cell
# endregion

# This is a markdown cell
