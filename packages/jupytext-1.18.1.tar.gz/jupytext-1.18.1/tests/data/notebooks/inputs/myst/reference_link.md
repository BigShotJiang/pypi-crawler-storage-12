This documents contains a code cell to make sure it is recognized as a MyST document.

```{code-cell} ipython3
1 + 1
```

This is a [reference-link to the issue][].

:::{note}
This note is key... not sure why.
:::

[reference-link to the issue]: <https://github.com/mwouts/jupytext/issues/789>
