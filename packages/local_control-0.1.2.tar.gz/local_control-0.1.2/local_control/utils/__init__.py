"""
Utility helpers for ancillary features (QR code rendering, startup registration, etc.).
"""

from __future__ import annotations

from . import terminal_qr

__all__ = ["terminal_qr"]
