CHANGELOG
=========

1.0.6 - 2025-11-11
------------------

This is a maintenance release. For clarity's sake, the wording in the `README.md` documentation file has been improved.

1.0.5 - 2025-01-20
------------------

This is a maintenance release. No user-visible changes have been made. This release implements the new system that keeps alignment with plugin template via Cruft.

1.0.4 - 2024-04-14
------------------

Ensure plugin is included in sdist build

1.0.3 - 2024-04-07
------------------

Maintainance release (no user visible changes)

* Add Python 3.12 to CI test matrix
* Switch build system from Hatchling to PDM

1.0.2 - 2023-10-31
------------------

Fix project name

1.0.1 - 2023-10-31
------------------

Maintenance release:

- Migrate to the new tooling standards
- Improve code quality

1.0.0 - 2023-06-24
------------------

Initial release as namespace plugin
