
from setuptools import setup, find_packages

setup(
    name='starco-dj-bot',
    version='1.0.2',
    packages=['bot'],
    include_package_data=True,
    license='MIT',
    description='A Django pluggable app for telegram bot development.',
    author='Mojtaba',
    author_email='m.tahmasbi0111@yahoo.com',
    install_requires=[
        'Django>=4.0',
        'starco-dj-utils',
    ],
    classifiers=[
        'Framework :: Django',
        'Programming Language :: Python :: 3',
    ],
)
