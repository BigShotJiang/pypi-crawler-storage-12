from django.contrib import admin
from . import models


# Register your models here.
@admin.register(models.Setting)
class SettingAdmin(admin.ModelAdmin):
    fields = [field.name for field in models.Setting._meta.fields if field.name not in ['list_display_links', 'id']]
    list_display = fields
    list_editable = [i for i in fields if i != 'name']

    def has_add_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    class Media:
        css = {
            'all': ('setting/admin/css/style.css',),  # آدرس فایل CSS
        }
        js = ('setting/admin/js/script.js',)  # آدرس فایل JS


@admin.register(models.User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('user_id', 'username', 'first_name', 'last_name', 'language', 'created_at', 'updated_at')
    list_filter = ('language', 'created_at')
    search_fields = ('user_id', 'username', 'first_name', 'last_name')
    ordering = ('-created_at',)

