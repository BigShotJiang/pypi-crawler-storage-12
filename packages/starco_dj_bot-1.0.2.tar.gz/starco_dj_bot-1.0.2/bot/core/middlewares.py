from ._base import BaseBot
async def check_maintenance_middleware(self:BaseBot):
    if self.user_id in self.admins: return True
    self.allow_continue = not self.setting.is_maintenance
    if not self.setting.is_maintenance:
        return True
    else:
        await self.send(self.T('is_maintenance_text'))
        return False
async def check_status_middleware(self:BaseBot):
    if self.user_id in self.admins:
        return True
    self.allow_continue = self.setting.status_bot
    if self.setting.status_bot:
        return True
    else:
        await self.send(self.T('bot_is_offline_text'))
        return False
