from django.core.management.base import BaseCommand
from bot.core import TelegramBot

class Command(BaseCommand):
    help = 'Runs the Telegram setting with optional auto-reload'

    def add_arguments(self, parser):
        pass

    def handle(self, *args, **options):

        bot = TelegramBot()
        bot.run()

