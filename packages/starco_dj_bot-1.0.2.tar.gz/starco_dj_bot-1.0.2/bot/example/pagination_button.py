from ..ext.base import Base, MH
from ..models import Message


class NodeUser(Base):
    def __init__(self):
        super().__init__('user', 1)

    def n_active_service(self):
        e = MH()
        e.filters = self.match_filter(active_service)

        async def show_services():
            query = Order.objects.filter(user=self.user, status='complete', is_expired=False, parent_order=None)
            if await self.db(query.count) > 0:
                def formater(item):
                    return item.uuid[:5], {'act': 'show_order', 'order_id': item.id}

                self.pagination('active_service', query.all(), formater, per_page=10, btn_sizes=2)
                btn = await self.make_pagination_button('active_service', 1)
                # caption=active_service_text
                await self.send('services', reply_markup=btn)
            else:
                caption = no_active_service_text
                await self.send(caption)

        e.callback = show_services
        self.node(e)