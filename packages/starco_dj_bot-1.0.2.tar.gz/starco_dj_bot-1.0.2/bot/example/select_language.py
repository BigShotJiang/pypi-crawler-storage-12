from ..ext.base import Base
from bot.utils.setup.select_language import select_language_setup
class NodeUser(Base):
    def __init__(self):
        super().__init__('user',1)

    async def after_setup(self):
        if await select_language_setup(self):
            self.allow_continue=False
            return
        else:self.allow_continue=True