from restiny.consts import MODULE_DIR

STYLE_TCSS = MODULE_DIR.joinpath('assets/style.tcss')
