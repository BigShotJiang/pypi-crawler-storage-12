from restiny.consts import MODULE_DIR

SQL_DIR = MODULE_DIR.joinpath('data/sql')
