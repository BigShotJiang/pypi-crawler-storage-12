"""OAuth authentication utilities for GAC."""
