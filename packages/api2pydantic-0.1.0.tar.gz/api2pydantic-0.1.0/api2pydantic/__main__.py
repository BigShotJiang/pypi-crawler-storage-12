"""
Allow running the package as: python -m api2pydantic
"""

from api2pydantic.cli import main

if __name__ == "__main__":
    main()
