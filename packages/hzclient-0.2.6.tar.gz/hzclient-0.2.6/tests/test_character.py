def test_character_model(state):
  assert state.character.name == "JoyfulShieldbearer"