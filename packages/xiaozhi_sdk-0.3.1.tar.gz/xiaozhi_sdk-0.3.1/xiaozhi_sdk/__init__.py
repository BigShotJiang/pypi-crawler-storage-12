__version__ = "0.3.1"

from xiaozhi_sdk.core import XiaoZhiWebsocket  # noqa
