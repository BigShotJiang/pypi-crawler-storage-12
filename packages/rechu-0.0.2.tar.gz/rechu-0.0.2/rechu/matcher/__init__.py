"""
Entity matching submodule.
"""

__all__: list[str] = []
