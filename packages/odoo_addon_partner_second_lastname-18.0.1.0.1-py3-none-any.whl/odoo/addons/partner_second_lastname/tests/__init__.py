# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import test_name
from . import test_config
from . import test_multiple_names
from odoo.addons.partner_firstname.tests import test_empty
