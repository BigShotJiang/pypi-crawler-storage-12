This module was written to extend the functionality of
`partner_firstname` to support having a second lastname for contact
partners.

In some countries, it's important to have a second last name for
contacts.

Contact partners will need to fill at least one of the name fields
(*First name*, *First last name* or *Second last name*).
