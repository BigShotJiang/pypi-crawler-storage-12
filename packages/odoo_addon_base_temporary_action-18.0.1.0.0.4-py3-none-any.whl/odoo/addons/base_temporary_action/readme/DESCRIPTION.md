This module is a technical module that does nothing by itself.

This addon allows to create temporary actions that will be removed automatically after one hour (default transient age limit).
Temporary actions are identified by a field 'is_temporary'.
