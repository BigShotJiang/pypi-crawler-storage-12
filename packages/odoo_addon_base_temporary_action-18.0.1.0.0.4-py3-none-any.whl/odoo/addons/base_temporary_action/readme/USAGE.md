To use this module, you need to:

- Create an action, either by code or in the user interface and set its field is_temporary to True.
- You have one hour to use your action (default transient age limit).
