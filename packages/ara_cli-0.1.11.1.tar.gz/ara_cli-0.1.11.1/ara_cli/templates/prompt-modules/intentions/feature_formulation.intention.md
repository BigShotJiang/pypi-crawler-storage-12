### INTENTION and CONTEXT
Formulate a new feature file `{Feature File}` in gherkin as described in task `{Task Name}`. Do not implement any code for now. 
