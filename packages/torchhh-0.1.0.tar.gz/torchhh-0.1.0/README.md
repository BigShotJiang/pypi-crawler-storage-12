# myutils
This is a simple Python utilities package.