печать = print()
ввод = input()
