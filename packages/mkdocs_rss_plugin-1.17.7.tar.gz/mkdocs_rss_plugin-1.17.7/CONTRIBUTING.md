Contributing guidelines are now published on [the online documentation](https://guts.github.io/mkdocs-rss-plugin/contributing/).
