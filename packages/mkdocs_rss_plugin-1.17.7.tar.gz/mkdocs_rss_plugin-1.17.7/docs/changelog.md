---
title: Changelog
description: "Release notes of the RSS plugin for MkDocs."
categories:
    - Release notes
search:
    exclude: true
tags:
    - development
---

--8<-- "CHANGELOG.md"
