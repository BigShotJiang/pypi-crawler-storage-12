render = 'JSON'
source = 'national'

# CU/I/1996/000105
appnum_mask = ['CU/I/\\d{4}/(\\d*)']
