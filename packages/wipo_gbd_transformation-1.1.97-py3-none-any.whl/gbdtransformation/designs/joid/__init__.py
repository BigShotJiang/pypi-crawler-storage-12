render = 'JSON'
source = 'national'

#JO/D/1996/0625
appnum_mask = ['(JO)/D/\\d*/(\\d*)',
               '(\\d*)/D/\\d*/(\\d*)']
