# instruction to render the output to JSON format
render = 'JSON'
source = 'national'

appnum_mask = '\\d{4}(\\d*)([A-Z]*)'
