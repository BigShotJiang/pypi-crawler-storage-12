# instruction to render the output to JSON format
render = 'JSON'
source = 'national'

# V0045129
appnum_mask = '[Vv](\\d*)'

# 93/1948
regnum_mask = ['(\\d.*)/\\d{4}',
               '(.*)']
