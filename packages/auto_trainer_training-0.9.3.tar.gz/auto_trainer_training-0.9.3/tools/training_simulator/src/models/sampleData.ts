export const sampleProtocol = {
    "planId": "57094295-5234-44f3-a925-14ceb772c8e5",
    "name": "Sample Training Protocol",
    "description": "A sample training protocol with multiple phases.",
    "phases": [
        {
            "phaseId": "3a37f67e-12f1-47e3-ae9a-fd6d0edb9bac",
            "name": "Reach A",
            "description": "Manual pellet delivery (uncovered).",
            "fallbackPredicate": null,
            "advancePredicate": {
                "type": "NumberComparisonPredicate",
                "module": "autotrainer.training.training_predicate",
                "properties": {
                    "comparisonType": "GTE",
                    "path": [
                        "progress",
                        "pellets_consumed"
                    ],
                    "value": 3
                }
            },
            "sessionActions": [],
            "startingBaselineIntensity": 0,
            "isPelletCoverEnabled": false,
            "isAutoClampEnabled": false
        },
        {
            "phaseId": "3a37f67e-12f1-47e3-ae9a-fd6d0edb9bac",
            "name": "Reach B",
            "description": "Automated pellet delivery (uncovered).",
            "fallbackPredicate": null,
            "advancePredicate": {
                "type": "NumberComparisonPredicate",
                "module": "autotrainer.training.training_predicate",
                "properties": {
                    "comparisonType": "GTE",
                    "path": [
                        "progress",
                        "pellets_consumed"
                    ],
                    "value": 3
                }
            },
            "sessionActions": [],
            "startingBaselineIntensity": 0,
            "isPelletCoverEnabled": false,
            "isAutoClampEnabled": false
        },
        {
            "phaseId": "3a37f67e-12f1-47e3-ae9a-fd6d0edb9bac",
            "name": "Reach C",
            "description": "Pellet positioning to maximum distance (covered with reach distance).",
            "fallbackPredicate": null,
            "advancePredicate": {
                "type": "NumberComparisonPredicate",
                "module": "autotrainer.training.training_predicate",
                "properties": {
                    "comparisonType": "GTE",
                    "path": [
                        "progress",
                        "pellets_consumed"
                    ],
                    "value": 3
                }
            },
            "sessionActions": [
                {
                    "type": "ReachDistanceAction",
                    "module": "autotrainer.training.training_action",
                    "properties": {
                        "distance": 3.0,
                        "increment": 0.5,
                        "pellet_delta": 5
                    }
                }
            ],
            "startingBaselineIntensity": 0,
            "isPelletCoverEnabled": true,
            "isAutoClampEnabled": false
        },
        {
            "phaseId": "3a37f67e-12f1-47e3-ae9a-fd6d0edb9bac",
            "name": "Reach D",
            "description": "Stable automatic delivery (covered with reach distance).",
            "fallbackPredicate": null,
            "advancePredicate": {
                "type": "NumberComparisonPredicate",
                "module": "autotrainer.training.training_predicate",
                "properties": {
                    "comparisonType": "GTE",
                    "path": [
                        "progress",
                        "pellets_consumed"
                    ],
                    "value": 3
                }
            },
            "sessionActions": [],
            "startingBaselineIntensity": 10,
            "isPelletCoverEnabled": true,
            "isAutoClampEnabled": false
        },
        {
            "phaseId": "3a37f67e-12f1-47e3-ae9a-fd6d0edb9bac",
            "name": "Head Fix A",
            "description": "Magnet baseline incremental training",
            "fallbackPredicate": null,
            "advancePredicate": {
                "type": "NumberComparisonPredicate",
                "module": "autotrainer.training.training_predicate",
                "properties": {
                    "comparisonType": "GTE",
                    "path": [
                        "progress",
                        "pellets_consumed"
                    ],
                    "value": 3
                }
            },
            "sessionActions": [
                {
                    "type": "HeadMagnetIntensityAction",
                    "module": "autotrainer.training.training_action",
                    "properties": {
                        "start": 0.0,
                        "increment": 10,
                        "end": 90,
                        "pellet_delta": 5
                    }
                }
            ],
            "startingBaselineIntensity": 0,
            "isPelletCoverEnabled": true,
            "isAutoClampEnabled": false
        },
        {
            "phaseId": "3a37f67e-12f1-47e3-ae9a-fd6d0edb9bac",
            "name": "Head Fix B",
            "description": "90% Magnet baseline without auto-clamp",
            "fallbackPredicate": null,
            "advancePredicate": {
                "type": "NumberComparisonPredicate",
                "module": "autotrainer.training.training_predicate",
                "properties": {
                    "comparisonType": "GTE",
                    "path": [
                        "progress",
                        "pellets_consumed"
                    ],
                    "value": 3
                }
            },
            "sessionActions": [],
            "isPelletDeliveryEnabled": true,
            "isPelletCoverEnabled": true,
            "startingBaselineIntensity": 90,
            "pelletHandsMinDistance": 3.2,
            "isPelletShiftEnabled": false,
            "isAutoClampEnabled": false,
            "autoClampNoActivityReleaseDelay": 5.0,
            "autoClampReleaseLoadCount": 3
        },
        {
            "phaseId": "3a37f67e-12f1-47e3-ae9a-fd6d0edb9bac",
            "name": "Head Fix C",
            "description": "Auto-clamp enabled.  Deliver pellets until a pellet remains in the at-mouse position for [x] seconds, then release the mouse (tone, then release).",
            "fallbackPredicate": null,
            "advancePredicate": {
                "type": "NumberComparisonPredicate",
                "module": "autotrainer.training.training_predicate",
                "properties": {
                    "comparisonType": "GTE",
                    "path": [
                        "progress",
                        "pellets_consumed"
                    ],
                    "value": 3
                }
            },
            "sessionActions": [],
            "startingBaselineIntensity": 90,
            "isPelletCoverEnabled": true,
            "isAutoClampEnabled": true
        },
        {
            "phaseId": "3a37f67e-12f1-47e3-ae9a-fd6d0edb9bac",
            "name": "Head Fix D",
            "description": "Auto-clamp enabled until digital feed indicates release.",
            "fallbackPredicate": null,
            "advancePredicate": {
                "type": "NumberComparisonPredicate",
                "module": "autotrainer.training.training_predicate",
                "properties": {
                    "comparisonType": "GTE",
                    "path": [
                        "progress",
                        "pellets_consumed"
                    ],
                    "value": 3
                }
            },
            "sessionActions": [],
            "startingBaselineIntensity": 90,
            "isPelletCoverEnabled": true,
            "isAutoClampEnabled": true
        }
    ]
};