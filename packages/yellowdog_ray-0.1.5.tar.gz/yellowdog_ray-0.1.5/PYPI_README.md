# YellowDog Integration with Ray: RayDog

YellowDog's RayDog package provides seamless integration of the [YellowDog Platform](https://yellowdog.ai) with Ray.

Documentation is found at: https://docs.yellowdog.ai/raydog/index.html.
