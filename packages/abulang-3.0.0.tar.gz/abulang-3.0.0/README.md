# AbuLang 🚀

A friendly, Pythonic programming language designed for beginners, educators, and creative coders. Write Python with a more intuitive syntax!

[![PyPI version](https://badge.fury.io/py/abulang.svg)](https://badge.fury.io/py/abulang)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![GitHub Stars](https://img.shields.io/github/stars/yourusername/abulang.svg)](https://github.com/yourusername/abulang)

## Features ✨

- **Beginner-Friendly**: Simple, readable syntax inspired by natural language
- **Python-Powered**: Runs on Python 3.8+ with full Python compatibility
- **Multi-Format Support**: Switch between YAML, JSON, CSV, and more
- **Built-in Packages**: AbuSmart, AbuFILES, AbuINSTALL, AbuChess
- **Neural Chess AI**: Play against a trained neural network chess engine
- **File Operations**: Easy file handling with `save_as()` and `get_line()`
- **Interactive REPL**: Command-line interface for quick testing
- **Educational**: Perfect for teaching programming concepts

## Installation 📦

### Via pip (Recommended)
```bash
pip install abulang
```

### From source
```bash
git clone https://github.com/yourusername/abulang.git
cd abulang
pip install -e .
```

## Quick Start 🎯

### Hello World
```abu
show "Hello, World!"
```

### Variables and Math
```abu
x = 10
y = 5
show "Sum: " + str(x + y)
show "Product: " + str(x * y)
```

### Functions
```abu
def greet(name):
    return "Hello, " + name + "!"

show greet("Abu")
```

### Loops
```abu
for i in range(5):
    show i
```

### Using Libraries
```abu
libra math
result = math.sqrt(16)
show result
```

### Multi-Format Blocks
```abu
switch(yaml)
database:
  host: localhost
  port: 5432
save_as(config.yaml)

# Read it back
line = get_line 2 config.yaml
show line
```

### AbuLang Packages
```abu
# System utilities
libra AbuSmart
show smart.time()

# File operations
libra AbuFILES
files.save_data("data", {"key": "value"})

# Chess AI
libra AbuChess
chess.AIweb()  # Launch web interface
```

## Running AbuLang Files

### Command Line
```bash
abulang myprogram.abu
```

### Python
```python
from abulang import run

code = """
show "Hello from AbuLang!"
x = 10
show x
"""

run(code)
```

### Interactive REPL
```bash
abulang
```

## Documentation 📚

- [Quick Start Guide](ABULANG_QUICKSTART.md)
- [Language Reference](ABULANG_V3_COMPLETE.md)
- [Package Documentation](ABU_PACKAGES.md)
- [Chess AI Guide](ABUCHESS_INTEGRATION.md)

## Core Commands

### I/O
- `show` - Display output
- `ask` - Get user input

### Variables
- `x = value` - Assign variable
- `libra module` - Import library

### Control Flow
- `if`, `elif`, `else` - Conditionals
- `for`, `while` - Loops
- `def` - Define functions

### Multi-Format
- `switch(yaml)` - Switch to YAML mode
- `save_as(file)` - Save to file
- `get_line N file` - Read line from file

## Packages 📦

### AbuSmart
System utilities: time, date, shutdown, webcam, notifications

```abu
libra AbuSmart
show smart.time()
smart.webcam()
```

### AbuFILES
File operations with multiple formats

```abu
libra AbuFILES
files.save_data("data", {"name": "Abu"})
loaded = files.load_data("data")
```

### AbuINSTALL
Package manager (pip wrapper)

```abu
libra AbuINSTALL
installer.install("requests")
installer.check("numpy")
```

### AbuChess
Neural network chess AI

```abu
libra AbuChess
chess.AIweb()      # Web interface
chess.play()       # CLI game
chess.train()      # Train AI
```

## Examples 🎮

### Game: Guessing Game
```abu
libra random

secret = random.randint(1, 100)
guesses = 0

while True:
    guess = ask "Guess the number: "
    guess = int(guess)
    guesses = guesses + 1
    
    if guess < secret:
        show "Too low!"
    elif guess > secret:
        show "Too high!"
    else:
        show "You got it in " + str(guesses) + " guesses!"
        break
```

### Data Processing
```abu
libra stat

data = [10, 20, 30, 40, 50]
show "Mean: " + str(stat.mean(data))
show "Sum: " + str(sum(data))
show "Count: " + str(len(data))
```

### File Handling
```abu
libra AbuFILES

switch(yaml)
users:
  - name: Alice
    age: 30
  - name: Bob
    age: 25
save_as(users.yaml)

# Read it
line = get_line 3 users.yaml
show line
```

## System Requirements

- Python 3.8 or higher
- pip (Python package manager)
- ~50MB disk space

## Optional Dependencies

For full feature support:
- `psutil` - System information
- `pyperclip` - Clipboard operations
- `torch` - Chess AI (GPU support)
- `flask` - Chess web interface

## Contributing 🤝

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License 📄

This project is licensed under the MIT License - see [LICENSE](LICENSE) file for details.

## Changelog 📝

### v3.0.0 (Current)
- Multi-format block support (YAML, JSON, CSV, etc.)
- AbuChess neural network integration
- AbuSmart system utilities
- AbuFILES file operations
- AbuINSTALL package manager
- Multi-line block support
- Improved error messages

### v2.0.0
- GUI alias system
- Flexible syntax support
- Smart parentheses handling

### v1.0.0
- Initial release
- Basic interpreter
- Core commands

## Support 💬

- **Issues**: [GitHub Issues](https://github.com/yourusername/abulang/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/abulang/discussions)
- **Email**: your.email@example.com

## Roadmap 🗺️

- [ ] Web-based IDE
- [ ] Mobile app
- [ ] VS Code extension
- [ ] Jupyter notebook support
- [ ] Package manager (abulang packages)
- [ ] Debugger
- [ ] Performance profiler
- [ ] Type hints support

## Credits 🙏

- Inspired by Python, Lua, and educational languages
- Chess AI based on AlphaZero architecture
- Built with ❤️ for the programming community

## Acknowledgments

- Python community
- Stockfish chess engine
- All contributors and users

---

**Made with ❤️ by Abu**

[⭐ Star us on GitHub!](https://github.com/yourusername/abulang)
