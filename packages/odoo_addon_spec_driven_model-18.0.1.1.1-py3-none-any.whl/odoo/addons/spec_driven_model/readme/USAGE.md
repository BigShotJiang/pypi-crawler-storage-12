See my detailed OCA Days explanations here:
<https://www.youtube.com/watch?v=6gFOe7Wh8uA>

You are also encouraged to look at the tests directory which features a
full blown example from the famous PurchaseOrder.xsd from Microsoft
tutorials.
