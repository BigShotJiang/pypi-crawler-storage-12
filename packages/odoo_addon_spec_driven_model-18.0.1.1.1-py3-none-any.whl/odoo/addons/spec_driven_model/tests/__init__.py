from . import test_spec_model

spec_schema = "poxsd"
spec_version = "10"
