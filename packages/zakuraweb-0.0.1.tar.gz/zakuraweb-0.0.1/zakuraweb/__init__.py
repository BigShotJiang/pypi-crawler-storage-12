from .zakuraweb import color

color()