# auto-trace-analyzer

A lightweight automated engine for traceback analysis and explanation.