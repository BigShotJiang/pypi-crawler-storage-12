"""
GUI components for Annotex
"""

from annotex.gui.advanced_gui import Annotex

__all__ = ["Annotex"]