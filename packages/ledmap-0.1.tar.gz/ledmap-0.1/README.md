# LED Pixel Mapper

Tools for working with pixel mappings.
Aimed at
[WLED](https://kno.wled.ge/advanced/mapping/)
and [ESPHome](https://esphome.io/components/display/addressable_light/#pixel_mapper).

We use [ADR](adr)s to capture the key decisions.
