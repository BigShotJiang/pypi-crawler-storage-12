"""Entry point for python -m genlist_butler"""
from genlist_butler.cli import main

if __name__ == "__main__":
    main()
