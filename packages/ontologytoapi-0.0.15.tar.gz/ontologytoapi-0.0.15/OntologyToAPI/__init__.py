# Package
from OntologyToAPI.core import *