"""
Command-line interface for MetaSpec.
"""

__all__ = ["main"]

from metaspec.cli.main import main
