from importlib.metadata import version

__version__ = version("plain.scan")

__all__ = ["__version__"]
