# CoDrone EDU

The python code base for CoDrone EDU.