"""
Units that process Java related binary formats such as class files and serialized Java objects.
"""
