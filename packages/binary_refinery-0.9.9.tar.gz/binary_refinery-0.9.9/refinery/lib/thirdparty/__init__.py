"""
This module contains third-party libraries that usually have different licensing than
Binary Refinery itself.
"""
