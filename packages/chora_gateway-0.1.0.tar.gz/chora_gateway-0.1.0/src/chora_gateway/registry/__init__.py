"""Registry integration for chora-manifest."""
