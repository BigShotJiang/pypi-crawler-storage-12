This folder contains SQL scripts that are used to generate tables that are
attached to the releases as assets. Initially, those will be generated and
attached manually, but in the future this process may be automated.
