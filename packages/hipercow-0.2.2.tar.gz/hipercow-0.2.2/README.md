# hipercow

[![PyPI - Version](https://img.shields.io/pypi/v/hipercow.svg)](https://pypi.org/project/hipercow)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/hipercow.svg)](https://pypi.org/project/hipercow)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install hipercow
```

## License

`hipercow` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
