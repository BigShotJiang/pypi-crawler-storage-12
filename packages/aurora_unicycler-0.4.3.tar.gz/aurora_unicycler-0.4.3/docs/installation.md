The package is available on PyPI, install on Python >3.10 with
```
pip install aurora-unicycler
```

### For contributors

If you want to edit or contribute to the package, then clone the repo and
install as editable with developer dependencies
```
git clone https://github.com/empaeconversion/aurora-unicycler.git
cd aurora-unicycler
pip install -e .[dev]
```
