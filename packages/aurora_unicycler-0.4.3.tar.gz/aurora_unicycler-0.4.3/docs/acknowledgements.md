This software was developed at the Laboratory of Materials for Energy Conversion
at Empa, the Swiss Federal Laboratories for Materials Science and Technology,
and supported by funding from the [IntelLiGent](https://heuintelligent.eu/)
project from the European Union’s research and innovation program under grant
agreement No. 101069765, and from the Swiss State Secretariat for Education,
Research, and Innovation (SERI) under contract No. 22.001422.
