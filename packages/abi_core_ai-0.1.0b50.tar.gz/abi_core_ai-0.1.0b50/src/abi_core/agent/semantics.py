# agent/semantics.py
def enrich_input(raw_input):
    # Add semantic tags, structure, maybe LangChain parsing
    return {"semantic": "enriched", "raw": raw_input}
