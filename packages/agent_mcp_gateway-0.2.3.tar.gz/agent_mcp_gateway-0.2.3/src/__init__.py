"""Agent MCP Gateway - Core implementation package."""
