from django.apps import AppConfig


class S3UtilsConfig(AppConfig):
    name = "baumbelt.django.s3utils"
