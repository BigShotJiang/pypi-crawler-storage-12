* tests
    * right now, you'd have to run `PYTHONPATH=src/ pytest` otherwise there will be ModuleNotFound, there should be a better way
    * django tests
