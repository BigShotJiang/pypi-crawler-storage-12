# Install dev dependencies

Run `pip install ".[dev]"`

# Build

Run `python -m build` in the repository root.

# Testing

Run `PYTHONPATH=src pytest`

