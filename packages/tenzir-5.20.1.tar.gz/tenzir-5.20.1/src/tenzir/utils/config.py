"""Compatibility wrapper that re-exports config helpers from tenzir-common."""

from tenzir_common.config import Config, create  # noqa: F401
