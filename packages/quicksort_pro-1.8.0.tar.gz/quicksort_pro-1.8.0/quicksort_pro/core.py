def hybrid_sort(arr, threshold=10):
    """
    Hybrid sorting algorithm combining quicksort with insertion sort.
    Uses insertion sort for small subarrays for better performance.
    
    Args:
        arr: List to sort
        threshold: Size threshold for switching to insertion sort
    
    Returns:
        Sorted list
    """
    if len(arr) <= 1:
        return arr
    
    arr_copy = arr[:]
    _hybrid_sort_impl(arr_copy, 0, len(arr_copy) - 1, threshold)
    return arr_copy


def _hybrid_sort_impl(arr, low, high, threshold):
    """Internal implementation of hybrid sort"""
    if high - low < threshold:
        _insertion_sort(arr, low, high)
    elif low < high:
        pi = _partition(arr, low, high)
        _hybrid_sort_impl(arr, low, pi - 1, threshold)
        _hybrid_sort_impl(arr, pi + 1, high, threshold)


def _insertion_sort(arr, low, high):
    """Insertion sort for small subarrays"""
    for i in range(low + 1, high + 1):
        key = arr[i]
        j = i - 1
        while j >= low and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key


def _partition(arr, low, high):
    """Partition function for quicksort"""
    pivot = arr[high]
    i = low - 1
    
    for j in range(low, high):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    
    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1


def sort_data(data, key=None, reverse=False):
    """
    Sort a list of dictionaries or objects by a specific key.
    
    Args:
        data: List of dictionaries or objects to sort
        key: Key name to sort by (for dictionaries)
        reverse: Sort in descending order if True
    
    Returns:
        Sorted list
    """
    if not data:
        return []
    
    if key is not None:
        if isinstance(data[0], dict):
            values = [(item[key], i, item) for i, item in enumerate(data)]
        else:
            values = [(getattr(item, key), i, item) for i, item in enumerate(data)]
        
        sorted_values = hybrid_sort(values)
        result = [item[2] for item in sorted_values]
    else:
        result = hybrid_sort(data)
    
    if reverse:
        result.reverse()
    
    return result
