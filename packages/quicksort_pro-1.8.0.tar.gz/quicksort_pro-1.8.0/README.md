# QuickSort Pro

A professional-grade sorting library with optimized algorithms and data preprocessing utilities.

## Features

- Hybrid sorting algorithm combining quicksort with insertion sort optimization
- Built-in data validation and preprocessing
- Pure Python implementation for maximum compatibility
- Cross-platform support (Linux, Windows, macOS)
- Optimized for performance with O(n log n) average complexity

## Installation

```bash
pip install quicksort-pro
```

## Usage

### Basic Sorting

```python
from quicksort_pro import hybrid_sort

# Sort a simple list
numbers = [64, 34, 25, 12, 22, 11, 90]
sorted_numbers = hybrid_sort(numbers)
print(sorted_numbers)  # [11, 12, 22, 25, 34, 64, 90]
```

### Sorting Dictionaries

```python
from quicksort_pro import sort_data

# Sort a list of dictionaries by a specific key
data = [
    {"name": "Item 1", "value": 45.2},
    {"name": "Item 2", "value": 12.8},
    {"name": "Item 3", "value": 78.1},
]

sorted_data = sort_data(data, key="value", reverse=False)
```

### Data Validation

```python
from quicksort_pro import validate_and_prepare

data = [
    {"name": "Book 1", "price": 29.99},
    {"name": "Book 2", "price": 19.99},
]

validated = validate_and_prepare(data, required_keys=["name", "price"])
```

### Cleaning Numeric Data

```python
from quicksort_pro import clean_numeric_data

data = [
    {"item": "A", "price": "£29.99"},
    {"item": "B", "price": "$19.99"},
    {"item": "C", "price": "invalid"},
]

cleaned = clean_numeric_data(data, key="price", default=0.0)
```

## API Reference

### `hybrid_sort(arr, threshold=10)`
Sorts a list using a hybrid quicksort/insertion sort algorithm.

**Parameters:**
- `arr` (list): List to sort
- `threshold` (int): Size threshold for switching to insertion sort (default: 10)

**Returns:** Sorted list

### `sort_data(data, key=None, reverse=False)`
Sorts a list of dictionaries or objects by a specific key.

**Parameters:**
- `data` (list): List of dictionaries or objects to sort
- `key` (str): Key name to sort by (for dictionaries)
- `reverse` (bool): Sort in descending order if True

**Returns:** Sorted list

### `validate_and_prepare(data, required_keys)`
Validates that all items have required keys.

**Parameters:**
- `data` (list): List of dictionaries to validate
- `required_keys` (list): List of keys that must be present

**Returns:** Validated data

**Raises:** `ValueError` if validation fails

### `clean_numeric_data(data, key, default=0.0)`
Cleans numeric data by removing currency symbols and handling invalid values.

**Parameters:**
- `data` (list): List of dictionaries
- `key` (str): Key containing numeric data
- `default` (float): Default value for invalid entries

**Returns:** Cleaned data with valid numeric values

## Performance

The hybrid sorting algorithm provides:
- O(n log n) average time complexity
- O(n²) worst-case time complexity
- O(log n) space complexity
- Optimized for small arrays using insertion sort

## License

MIT License - see LICENSE file for details

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Author

Algorithm Solutions Inc.

## Links

- GitHub: https://github.com/algorithmsolutions/quicksort-pro
- PyPI: https://pypi.org/project/quicksort-pro/
