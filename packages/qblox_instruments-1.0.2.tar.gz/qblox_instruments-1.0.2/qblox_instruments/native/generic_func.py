"""
DEPRECATED: This module is only retained for compatibility.
It exposes enums that might be imported by legacy code from the `generic_func` namespace.
"""

# ruff: noqa: F401
from qblox_instruments.native.definitions import (
    SequencerStates,
    SequencerStatus,
    SequencerStatuses,
    SequencerStatusFlags,
    SystemStatus,
    SystemStatuses,
    SystemStatusFlags,
    SystemStatusSlotFlags,
)
