def submission_name(workflow_name, submission_name_suffix):
    return '{}-history-{}'.format(workflow_name, submission_name_suffix)
