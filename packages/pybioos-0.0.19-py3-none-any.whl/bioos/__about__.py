# coding:utf-8

# Package version
__version__ = "0.0.19"
