class VentError(Exception):
    pass
