## Remove need of HTTP-redirect
<!--
type: bugfix
scope: all
affected: all
-->

Appended a trailing slash so no HTTP-redirect takes place.
