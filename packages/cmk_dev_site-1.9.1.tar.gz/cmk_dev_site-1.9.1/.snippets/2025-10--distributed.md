## Adapt to REST-API changes
<!--
type: bugfix
scope: all
affected: all
-->

previously you may have seen:
```
cmk_dev_site.cmk.rest_api.CheckmkAPIException: Failed to create site connection
```

this is now fixed.
