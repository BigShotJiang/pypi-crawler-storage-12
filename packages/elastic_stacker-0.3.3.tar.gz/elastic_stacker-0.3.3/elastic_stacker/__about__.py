# SPDX-FileCopyrightText: 2024-present James Taliaferro <taliaferro1@llnl.gov>
#
# SPDX-License-Identifier: Apache-2.0
__version__ = "0.3.3"
