:::darkseid.utils.DataSources
:::darkseid.utils.get_issue_id_from_note
:::darkseid.utils.get_recursive_filelist
:::darkseid.utils.list_to_string
:::darkseid.utils.remove_articles
:::darkseid.utils.unique_file
