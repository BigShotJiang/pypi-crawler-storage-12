::: helical.models.base_models.ClassificationHead
    handler: python
    options:
      show_root_heading: True
      show_source: True
::: helical.models.base_models.RegressionHead
    handler: python
    options:
      show_root_heading: True
      show_source: True
      