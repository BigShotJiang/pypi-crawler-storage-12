::: helical.models.c2s.Cell2Sen
    handler: python
    options:
      members:
        - process_data
        - get_embeddings
        - get_perturbations
      show_root_heading: True
      show_source: True