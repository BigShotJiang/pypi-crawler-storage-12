"""
Services package for WhatsApp integration.
"""

default_whatsapp_service = None
