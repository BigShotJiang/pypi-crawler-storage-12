def http_common_header():
    header_dict = {
        "Content-Type": "application/json",
        "accept": "application/json"
    }
    return header_dict