from __future__ import annotations

from .cli_adapter import CLIAdapter

class OpenAICodexAgent(CLIAdapter):
    """OpenAI Codex adapter using CLIAdapter mechanics."""
    pass
