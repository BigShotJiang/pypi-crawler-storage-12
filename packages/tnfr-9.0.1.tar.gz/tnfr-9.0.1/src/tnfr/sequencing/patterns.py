"""Legacy entry points for advanced pattern detection."""

from ..operators.patterns import AdvancedPatternDetector

__all__ = ["AdvancedPatternDetector"]
