"""JSON schema resources bundled with the TNFR engine."""

from __future__ import annotations

__all__ = ["package"]

# Namespace packages need at least one attribute for static analysers.
package = __name__
