from onemod.io.base import Input, Output

__all__ = ["Input", "Output"]
