from onemod.fsutils.interface import DataInterface

__all__ = ["DataInterface"]
