"""Capabilities defined in fabricatio-judge."""
