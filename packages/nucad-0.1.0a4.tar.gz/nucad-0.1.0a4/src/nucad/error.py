
class InvalidGeometryError(RuntimeError):
    pass

class OCPOperationFailError(RuntimeError):
    pass