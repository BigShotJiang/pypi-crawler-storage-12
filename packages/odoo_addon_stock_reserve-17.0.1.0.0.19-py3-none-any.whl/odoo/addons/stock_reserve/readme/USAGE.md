To make a stock reservation:

1.  Go to *Inventory \> Products*.
2.  Select or create one product with stock.
3.  Click on *Stock Reservations* smart button.
4.  Create one reservation.
5.  Press the button *Reserve*.

You can release a reservation by clicking on the button *Release*
