* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Leonardo Pistone <leonardo.pistone@camptocamp.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Roca

* `GreenIce <https://www.greenice.com>`_:

  * Fernando La Chica <fernandolachica@gmail.com>
