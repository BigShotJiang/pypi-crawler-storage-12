"""
Useful functions for performing quick computations of statistical distributions, as well as helper functions for histogramming data
"""
