"""
Pygama: decoding and processing digitizer data.
Check out the `online documentation <https://pygama.readthedocs.io>`_
"""

from pygama._version import version as __version__

__all__ = ["__version__"]
