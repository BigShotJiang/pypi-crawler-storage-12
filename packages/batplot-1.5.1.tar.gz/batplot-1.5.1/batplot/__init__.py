"""batplot: Interactive plotting for battery data visualization."""

__version__ = "1.5.1"

__all__ = ["__version__"]
