import{aF as f}from"./index-ClApvkkz.js";export{f as default};
