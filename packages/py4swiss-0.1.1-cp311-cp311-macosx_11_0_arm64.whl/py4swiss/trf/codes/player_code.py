from enum import Enum


class PlayerCode(str, Enum):
    """TRF player codes."""

    PLAYER = "001"
