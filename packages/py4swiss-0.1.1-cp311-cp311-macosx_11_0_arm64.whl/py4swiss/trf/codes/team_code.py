from enum import Enum


class TeamCode(str, Enum):
    """TRF team codes."""

    TEAM = "013"
