from py4swiss.engines.dutch.criteria.color.e1 import E1
from py4swiss.engines.dutch.criteria.color.e2 import E2
from py4swiss.engines.dutch.criteria.color.e3 import E3
from py4swiss.engines.dutch.criteria.color.e4 import E4
from py4swiss.engines.dutch.criteria.color.e5 import E5

__all__ = ["E1", "E2", "E3", "E4", "E5"]
