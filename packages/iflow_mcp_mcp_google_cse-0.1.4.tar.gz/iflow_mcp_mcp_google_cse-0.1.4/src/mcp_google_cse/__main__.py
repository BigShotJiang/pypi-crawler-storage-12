from mcp_google_cse import main

main()
