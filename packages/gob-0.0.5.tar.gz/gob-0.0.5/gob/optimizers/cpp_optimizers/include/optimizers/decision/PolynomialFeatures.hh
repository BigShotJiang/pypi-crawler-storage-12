/*
 * Created in 2024 by Gaëtan Serré
 */

#include "utils.hh"

extern int comp(const int &n, const int &k);

extern dyn_vector polynomial_features(dyn_vector &x, int degree);