#
# Created in 2024 by Gaëtan Serré
#

from .print_table import *
