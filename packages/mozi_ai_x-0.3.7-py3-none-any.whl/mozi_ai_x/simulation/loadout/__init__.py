from .base import CLoadout

__all__ = [
    "CLoadout",
]
