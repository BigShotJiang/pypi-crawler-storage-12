# Swarm

A general purpose multi-agent system

### Tagging and Publishing

Make sure it matches with the current package

    git tag -a v0.1.0 -m v0.1.0
    git push --tags
