"""
썸네일 생성기 패키지
"""

from .renderer import ThumbnailRenderer

__version__ = "0.1.0"
__all__ = ["ThumbnailRenderer"]

