"""Data helpers for pytemplify examples."""
