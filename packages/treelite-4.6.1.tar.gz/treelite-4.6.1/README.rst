=======================
Treelite Python Package
=======================

|PyPI version|

.. |PyPI version| image:: https://badge.fury.io/py/treelite.svg
   :target: http://badge.fury.io/py/treelite

**Treelite** is a universal model exchange and serialization format for decision tree forests.

See the documentation for more details.
