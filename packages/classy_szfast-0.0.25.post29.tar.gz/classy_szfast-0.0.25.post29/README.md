Python module for the acceleration of class_sz and interface with likelihood codes. 

see https://github.com/CLASS-SZ for details.

