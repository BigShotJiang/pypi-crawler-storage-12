# simplemathy

A tiny demo package for learning how to publish to PyPI.

## Usage

```python
from simplemathy import add

print(add(2, 3))  # 5
