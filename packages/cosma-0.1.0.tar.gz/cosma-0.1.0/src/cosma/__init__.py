from cli import cli

def main():
    cli()
