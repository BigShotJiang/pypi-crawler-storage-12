# korea-weather-api

[![PyPI - Version](https://img.shields.io/pypi/v/korea-weather-api.svg)](https://pypi.org/project/korea-weather-api)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/korea-weather-api.svg)](https://pypi.org/project/korea-weather-api)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install korea-weather-api
```

## License

`korea-weather-api` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
