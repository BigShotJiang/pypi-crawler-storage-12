from .console import ConsoleInterface

__version__ = "1.1.0"
