from anicli_api.tools.dummy_cli import cli
from anicli_api.tools.m3u import generate_asyncio_playlist, generate_playlist
