"""
Author: Wenyu Ouyang
Date: 2022-12-08 09:24:54
LastEditTime: 2024-03-26 21:29:39
LastEditors: Wenyu Ouyang
Description: some util funcs for hydro model
FilePath: \hydro-model-xaj\test\test_show_results.py
Copyright (c) 2021-2022 Wenyu Ouyang. All rights reserved.
"""
