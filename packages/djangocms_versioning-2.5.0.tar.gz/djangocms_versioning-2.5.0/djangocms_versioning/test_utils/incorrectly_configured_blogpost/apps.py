from django.apps import AppConfig


class BlogpostConfig(AppConfig):
    name = "djangocms_versioning.test_utils.incorrectly_configured_blogpost"
