from django.views.generic import View


class PreviewView(View):
    pass
