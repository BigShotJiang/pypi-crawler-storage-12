from cms.extensions.models import PageContentExtension, PageExtension


class TestPageExtension(PageExtension):
    pass


class TestPageContentExtension(PageContentExtension):
    pass
