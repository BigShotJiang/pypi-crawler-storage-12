class ConditionFailed(Exception):
    pass
