from django.dispatch import Signal

pre_version_operation = Signal()

post_version_operation = Signal()
