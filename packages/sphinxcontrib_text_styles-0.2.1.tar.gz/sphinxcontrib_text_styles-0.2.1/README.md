# sphinxcontrib-text-styles
A Sphinx extension for defining custom text-formatting roles

See project documentation:
https://sphinxcontrib-text-styles.readthedocs.io
