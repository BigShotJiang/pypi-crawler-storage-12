## [0.6.7]
- Stability

## [0.6.6]
- Stability

## [0.6.5]
- Stability

## [0.6.4]
- Stability

## [0.6.3]
- Stability

## [0.6.2]
- Stability

## [0.6.1]
- Stability

## [0.6.0]
- Stability

## [0.5.19]
- Stability

## [0.5.18]
- Stability

## [0.5.15]
- Stability

## [0.5.14]
- Stability

## [0.5.13]
- Stability

## [0.5.12]
- Stability

## [0.5.8]
- Stability

## [0.5.7]
- Stability

## [0.5.6]
- Stability

## [0.5.5]
- Stability

## [0.5.4]
- Stability

## [0.5.3]
- Stability

## [0.5.2]
- Stability

## [0.5.1]
- Stability

## [0.5.0]
- Stability

## [0.4.3]
- Stability

## [0.4.2]
- Stability

## [0.4.1]
- Stability

## [0.4.0]
- Stability

## [0.3.1]
- Stability

## [0.3.0]
- Stability

## [0.2.1]
- Stability

## [0.2.0]
- Stability

## [0.1.0]
- Stability

## [0.0.39]
- Stability

## [0.0.38]
- Stability

## [0.0.37]
- Stability

## [0.0.36]
- Stability

## [0.0.35]
- Stability

## [0.0.34]
- Stability

## [0.0.33]
- Stability

## [0.0.32]
- Stability

## [0.0.31]
- Stability

## [0.0.31]
- Stability

## [0.0.29]
- Stability

## [0.0.28]
- Stability

## [0.0.27]
- Stability

## [0.0.26]
- Stability

## [0.0.25]
- Stability

## [0.0.24]
- Stability

## [0.0.23]
- Stability

## [0.0.22]
- Stability

## [0.0.21]
- Stability

## [0.0.20]
- Stability

## [0.0.19]
- Stability

## [0.0.18]
- Stability

## [0.0.17]
- Stability
- Meshagent cli 

## [0.0.16]
- Stability

## [0.0.15]
- Stability

## [0.0.14]
- Stability

## [0.0.11]
- Stability

## [0.0.10]
- Stability

## [0.0.9]
- Stability

## [0.0.8]
- Stability 

## [0.0.7]
- Added code editor agent
- Fixes

## [0.0.6]
- Fixes

## [0.0.5]
- Fix chatbox initialization

## [0.0.4]
- Streaming support
