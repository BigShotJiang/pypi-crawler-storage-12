"""
Tests for the Linear CLI application.
"""