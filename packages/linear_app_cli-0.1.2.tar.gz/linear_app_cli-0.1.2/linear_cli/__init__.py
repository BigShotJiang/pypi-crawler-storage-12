"""
Linear CLI - A command-line interface for interacting with the Linear.app API.
"""

__version__ = "0.1.0"