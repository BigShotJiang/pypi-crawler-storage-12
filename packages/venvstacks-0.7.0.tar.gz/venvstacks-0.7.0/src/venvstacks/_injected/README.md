Files injected into deployed environments
=========================================

Files in this folder are injected into the deployed
environments when publishing artifacts or locally
exporting environments.

They are also designed to be importable so that
the build process can access their functionality
without needing to duplicate the implementation,
and to make them more amenable to unit testing.
