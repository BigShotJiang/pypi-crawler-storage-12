"""Layered virtual environments stacks.

Note: Python API is *NOT YET STABLE*
"""
