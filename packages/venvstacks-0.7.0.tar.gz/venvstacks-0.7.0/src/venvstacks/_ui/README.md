Console UI utilities
====================

The `venvstacks` console UI design is inherited directly from the PDM project.
This doesn't change the overall project license, as PDM also uses the MIT license.

The additional license file in this folder is due to these files having a mixed
copyright (starting as clones from PDM, but evolving independently over time)

Original baseline files:

* https://github.com/pdm-project/pdm/blob/b5ac9b656b5e4b8f82870946a5f93ab2857642bf/src/pdm/_types.py
* https://github.com/pdm-project/pdm/blob/b5ac9b656b5e4b8f82870946a5f93ab2857642bf/src/pdm/termui.py
