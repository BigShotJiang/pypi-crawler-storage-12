#include "checkdynlib.h"

int sum(int a, int b) {
	return a + b;
}
