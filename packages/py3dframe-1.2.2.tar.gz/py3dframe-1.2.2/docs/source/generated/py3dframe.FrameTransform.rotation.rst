rotation
========

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.rotation