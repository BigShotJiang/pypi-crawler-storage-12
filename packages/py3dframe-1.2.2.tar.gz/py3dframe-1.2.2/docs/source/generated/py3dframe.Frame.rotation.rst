rotation
========

.. currentmodule:: py3dframe

.. autoproperty:: Frame.rotation