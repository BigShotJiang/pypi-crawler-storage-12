translation
===========

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.translation