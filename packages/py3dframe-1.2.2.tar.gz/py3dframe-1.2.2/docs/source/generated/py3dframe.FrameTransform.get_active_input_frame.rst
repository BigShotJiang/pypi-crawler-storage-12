get\_active\_input\_frame
=========================

.. currentmodule:: py3dframe

.. automethod:: FrameTransform.get_active_input_frame