axes
====

.. currentmodule:: py3dframe

.. autoproperty:: Frame.axes