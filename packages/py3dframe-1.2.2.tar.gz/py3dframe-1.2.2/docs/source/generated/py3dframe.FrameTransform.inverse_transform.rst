inverse\_transform
==================

.. currentmodule:: py3dframe

.. automethod:: FrameTransform.inverse_transform