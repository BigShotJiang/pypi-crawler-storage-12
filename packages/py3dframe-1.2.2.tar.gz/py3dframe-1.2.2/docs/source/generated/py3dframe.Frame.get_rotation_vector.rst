get\_rotation\_vector
=====================

.. currentmodule:: py3dframe

.. automethod:: Frame.get_rotation_vector