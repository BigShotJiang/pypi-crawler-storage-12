rotation\_matrix
================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.rotation_matrix