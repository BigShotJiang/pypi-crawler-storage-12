get\_quaternion
===============

.. currentmodule:: py3dframe

.. automethod:: FrameTransform.get_quaternion