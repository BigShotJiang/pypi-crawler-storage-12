# android_ui_automation/__init__.py
# Apenas exporta o módulo principal
from .android_ui_library import AndroidUiAutomation
