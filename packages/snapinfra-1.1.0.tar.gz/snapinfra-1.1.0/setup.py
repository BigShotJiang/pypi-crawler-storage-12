#!/usr/bin/env python3
"""Setup script for SnapInfra."""

from setuptools import setup, find_packages

setup()