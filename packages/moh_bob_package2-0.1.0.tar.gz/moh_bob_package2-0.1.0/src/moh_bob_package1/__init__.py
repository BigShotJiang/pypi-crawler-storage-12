from .core import saluer

print(saluer("Hi from init"))