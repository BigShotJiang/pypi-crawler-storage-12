def saluer(nom: str):
    return f"Bonjour {nom} !"
    
print("Module importé !")
print(saluer("Hi from core"))