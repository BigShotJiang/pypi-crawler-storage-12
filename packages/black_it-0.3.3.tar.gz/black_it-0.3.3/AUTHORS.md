# Credits

## Original Author
 
- [Gennaro Catapano](https://github.com/CatapanoG) <[gennaro.catapano@bancaditalia.it](mailto:gennaro.catapano@bancaditalia.it)>

## Co-authors/Maintainers

- [Marco Benedetti](https://github.com/mabene-BI) <[marco.benedetti@bancaditalia.it](mailto:marco.benedetti@bancaditalia.it)>
- [Francesco De Sclavis](https://github.com/Francesco-De-Sclavis-BdI) <[francesco.desclavis@bancaditalia.it](mailto:francesco.desclavis@bancaditalia.it)>
- [Marco Favorito](https://github.com/marcofavoritobi) <[marco.favorito@bancaditalia.it](mailto:marco.favorito@bancaditalia.it)>
- [Aldo Glielmo](https://github.com/aldoglielmo) <[aldo.glielmo@bancaditalia.it](mailto:aldo.glielmo@bancaditalia.it)>
- [Davide Magnanimi](https://github.com/davidemagnanimi) <[davide.magnanimi@bancaditalia.it](mailto:davide.magnanimi@bancaditalia.it)>
- [Antonio Muci](https://github.com/muxator) <[antonio.muci@bancaditalia.it](mailto:antonio.muci@bancaditalia.it)>

## Contributors

None yet. [Why not be the first](./CONTRIBUTING.md)? 
