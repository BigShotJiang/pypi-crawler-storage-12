"""Setup script for the NLP Tweets Sentiment Analysis Pipeline package."""

from setuptools import setup

# All configuration is now in pyproject.toml
# This file is kept for backwards compatibility
setup()
