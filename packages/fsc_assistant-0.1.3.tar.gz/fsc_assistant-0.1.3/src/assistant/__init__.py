"""Kara Code - An AI-powered software development assistant."""

from .__version__ import __version__, __version_info__

__all__ = ["__version__", "__version_info__"]
