"""
MCP (Model Context Protocol) integration for fsc-assistant.

This module provides FastMCP 2.0 client wrapper for connecting to external
MCP servers and using their tools in the AgenticShell.
"""
