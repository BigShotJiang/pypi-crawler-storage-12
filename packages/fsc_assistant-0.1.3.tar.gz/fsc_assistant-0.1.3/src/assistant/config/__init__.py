from ..config.manager import AssistantConfig

__all__ = [
    "AssistantConfig",
]
