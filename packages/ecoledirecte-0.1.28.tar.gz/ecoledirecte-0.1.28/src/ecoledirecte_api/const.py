from __future__ import annotations

AUGUST = 8
ED_MFA_REQUIRED = 250
ED_OK = 200
ED_NODATA = 210
APIURL = "https://api.ecoledirecte.com/v3"
APIVERSION = "4.89.1"  # Version of the official Ecole Directe app
