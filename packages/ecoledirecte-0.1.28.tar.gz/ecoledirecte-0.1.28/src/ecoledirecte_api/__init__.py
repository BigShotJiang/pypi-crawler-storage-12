"""Top-level package for Ecole Directe API."""

__author__ = """Giga77"""
__version__ = "0.1.28"
