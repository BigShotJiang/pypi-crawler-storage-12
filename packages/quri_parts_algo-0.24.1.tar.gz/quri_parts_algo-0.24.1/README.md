# QURI Parts Algo

QURI Parts Algo is a library containing implementations of algorithms for quantum computers.

## Documentation

[QURI Parts Documentation](https://quri-parts.qunasys.com)

## Installation

```
pip install quri-parts-algo
```

## License

Apache License 2.0
