SCRIPT_TASK_BLOCKS = {
    "task",
    "file_download",
    "navigation",
    "action",
    "extraction",
    "login",
}
SCRIPT_TASK_BLOCKS_WITH_COMPLETE_ACTION = {
    "task",
    "navigation",
    "login",
}
