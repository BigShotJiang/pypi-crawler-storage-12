"""系统监控工具 - 获取CPU和内存使用率"""

__version__ = "0.7.0"

from .system_info import get_system_info