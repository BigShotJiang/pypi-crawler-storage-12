import sys
from opp_env.opp_env import main

sys.exit(main())