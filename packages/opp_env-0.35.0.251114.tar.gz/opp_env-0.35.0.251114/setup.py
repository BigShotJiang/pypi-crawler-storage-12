# stub for setuptools. Project is configured in pyproject.toml

from setuptools import setup

setup()