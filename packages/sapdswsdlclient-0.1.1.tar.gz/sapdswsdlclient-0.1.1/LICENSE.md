Copyright (c) 2025 <a href="https://github.com/sparklingSky">sparklingSky</a>

### General Information

The library is provided 'as is'. No warranty of any kind is granted, and the author is not liable for any kind of potential damage or other consequences of using the code.

### Conditions
You can freely use, copy, modify and distribute the code of the library 'sapwsdlclient' - totally or partially - with the conditions that:
* you use the code for non-commercial or internal business purposes; 
* you retain the original copyright notice and this license for your product as for 'sapwsdlclient', and you must retain attribution for all contributors of the modified code, if there are such. 

For any other use, including a product intended for direct commercial distribution, you must contact the author and obtain a separate commercial license.
me[__!dot!__]sparklingsky[__!at!__]gmail[__!dot!__]com

### Terms Definition
* The term '**author**' means the author of the original code of the library 'sapwsdlclient'.
* The term '**non-commercial or internal business purposes**' means any of your non-profit products or activities (including personal usage, education, research, charitable work, or community service), or using the library's code internally within your business without directly distributing it to third parties for financial benefit.
* The term '**direct commercial distribution**' means including the code of 'sapwsdlclient' - totally or partially - in your product intended for sale or for any other form of gaining the financial benefit from your product.

### Additional Information
If you want to thank the author, you are welcome to donate to the volunteer charitable organization <a href="https://spgr.org.ua/en/donate/">Solidarna Sprava Hromad</a> (supporting humanitarian and defense efforts in Ukraine).
The author is not affiliated with this organization but fully endorses its projects and activities.