from sapdswsdlclient.server.auth import Server
