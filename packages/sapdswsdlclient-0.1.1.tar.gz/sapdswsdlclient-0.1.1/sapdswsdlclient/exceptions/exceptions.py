class NotSignedInError(Exception):
    pass