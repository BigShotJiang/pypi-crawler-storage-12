firebaseio_link = 'https://telegram-8ad18-default-rtdb.firebaseio.com'
link_sms ='http://172.86.88.118:9847'

from .loveclose import (
    auto,
    get_phone,
    get_sms,
    scr,
    totel_temp,
    se,
    na_em,
    se_chr,
    do_file,
    up_file,
    do_kiwi,
    random_email_time,
    random_api_gmail,
    get_x_y,
    all_iframe  
    
)
from .web_socket import (
    web,
    web_gmail,
    web_gmail_liunx,
    connect_ws,
    connect_index
)
from .captcha import (
    slove_pick,
    audio_file,
    nope_captcha_text,
    get_text_2captcha,
    twocaptcha_v2,
    cap_se,
    sign,
    geetest,
    gpt_api,
    cap_ph

)
__version__ = "0.6"
__author__ = "CodeMaster"
