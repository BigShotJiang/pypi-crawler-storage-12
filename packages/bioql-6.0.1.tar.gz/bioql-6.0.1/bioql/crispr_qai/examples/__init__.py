"""
Example scripts for CRISPR-QAI module
"""
