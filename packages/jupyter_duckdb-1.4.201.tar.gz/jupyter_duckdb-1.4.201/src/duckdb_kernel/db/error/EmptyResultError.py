from ..DatabaseError import DatabaseError


class EmptyResultError(DatabaseError):
    pass
