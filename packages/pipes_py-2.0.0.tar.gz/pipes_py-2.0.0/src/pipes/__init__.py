"""Pipes - A Python implementation of pipes.sh."""

__version__ = "2.0.0"

__all__ = ["__version__"]
