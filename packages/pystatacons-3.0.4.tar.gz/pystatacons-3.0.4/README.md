# pystatacons
Python package so that you can use [SCons](https://scons.org) with [Stata](https://stata.com) more easily. See https://github.com/bquistorff/statacons/ for more details


