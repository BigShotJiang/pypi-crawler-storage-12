---
title: "Document Title"
description: "Brief document description"
sidebar_position: 1
tags: ["tag1", "tag2"]  # Format: lowercase-with-dashes
id: "document-slug"  # Lowercase slug format: my-document-name
project_id: "your-project-id"
doc_uuid: "00000000-0000-4000-8000-000000000000"  # Generate: uuidgen  OR  python -c "import uuid; print(uuid.uuid4())"
---

# Document Title

Brief introduction or overview of the document.

## Section 1

Content for section 1.

### Subsection 1.1

Details for subsection.

### Subsection 1.2

Details for subsection.

## Section 2

Content for section 2.

## Section 3

Content for section 3.

## Related Documents

- [Related Doc 1](./doc1.md)
- [Related Doc 2](./doc2.md)
