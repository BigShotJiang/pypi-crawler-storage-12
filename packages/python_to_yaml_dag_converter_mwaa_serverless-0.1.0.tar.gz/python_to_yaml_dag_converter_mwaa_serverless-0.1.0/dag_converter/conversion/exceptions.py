class InvalidOperatorError(Exception):
    pass


class InvalidDagParameter(Exception):
    pass


class InvalidDefaultArg(Exception):
    pass


class InvalidOperatorParameter(Exception):
    pass


class InvalidSchedule(Exception):
    pass
