"""
Constants we use throughout the app
"""

# All internal URLs need to start with this prefix
INTERNAL_URL_PREFIX = "-"
