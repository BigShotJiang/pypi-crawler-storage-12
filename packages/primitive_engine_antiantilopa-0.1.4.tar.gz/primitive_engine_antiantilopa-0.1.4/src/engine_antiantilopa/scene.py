from .game_object import GameObject, Component

class Scene(Component):

    raise NotImplemented
