# Primitive engine

welcome to primitive engine readme file. 
Primitive engine is a kind of wrapper for pygame to simlify the work with the module. 
<!-- <br> -->
more information in [DOC.md](DOC.md)

# Creditionals:

author:
- [antiantilopa](https://github.com/antiantilopa)<br>


thanks to [TAFH](https://github.com/TAFH-debug), my friend, for [pygame_tools_tafh](https://github.com/TAFH-debug/pygame_tools_tafh) that is insperation source for this package.