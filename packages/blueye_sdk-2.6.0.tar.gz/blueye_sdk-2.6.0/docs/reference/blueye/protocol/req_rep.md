::: blueye.protocol.types.req_rep
    options:
      show_if_no_docstring: True
      show_docstring_attributes: false
      summary:
        classes: true
        attributes: false
      filters:
        - "!^__"
