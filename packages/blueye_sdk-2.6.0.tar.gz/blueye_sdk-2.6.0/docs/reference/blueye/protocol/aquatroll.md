::: blueye.protocol.types.aquatroll
    options:
      show_if_no_docstring: True
      show_docstring_attributes: false
      summary:
        classes: true
        attributes: false
      filters:
        - "!^__"
