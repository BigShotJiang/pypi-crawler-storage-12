::: blueye.sdk.constants
    options:
      summary: False

