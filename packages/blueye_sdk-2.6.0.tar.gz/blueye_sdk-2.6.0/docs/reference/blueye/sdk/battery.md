::: blueye.sdk.battery
    options:
      summary: False
