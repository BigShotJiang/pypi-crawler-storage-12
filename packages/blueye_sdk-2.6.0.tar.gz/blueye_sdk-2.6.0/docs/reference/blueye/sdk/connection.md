::: blueye.sdk.connection
    options:
      show_bases: True
      show_symbol_type_heading: True
      members: True
      inherited_members: True
      docstring_options:
        show_if_no_docstrings: True
