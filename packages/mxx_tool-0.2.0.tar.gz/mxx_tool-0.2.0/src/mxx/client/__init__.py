"""
MXX Client Package

Command-line client for interacting with MXX Scheduler Server.
"""

from mxx.client.client import cli

__all__ = ['cli']
