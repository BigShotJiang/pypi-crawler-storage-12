
hook_types = [
    "any_cond",
    "all_cond",
    "action",
    "pre_action",
    "post_action",
    "on_true",
    "on_false",
    "on_error"
]
