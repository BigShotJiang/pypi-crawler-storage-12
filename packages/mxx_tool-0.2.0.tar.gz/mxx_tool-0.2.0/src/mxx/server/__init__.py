"""
MXX Server - Flask-based scheduler service for MXX runner.

Provides HTTP API for scheduling and managing MXX plugin jobs.
"""

__version__ = "0.1.0"
