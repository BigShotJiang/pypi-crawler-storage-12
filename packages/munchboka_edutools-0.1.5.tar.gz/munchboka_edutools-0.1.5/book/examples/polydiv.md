# Polydiv Examples


:::{polydiv}
---
p: x^3 - 3x^2 + 1
q: x - 1
width: 80%
---
:::


:::{polydiv}
---
width: 70%
p: x^3 + x^2 + 1
q: x^2 - 1
---
:::

