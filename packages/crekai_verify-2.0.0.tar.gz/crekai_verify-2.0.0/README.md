# CrekAI Verify

Easily verify your assignments with CrekAI directly from your Colab or Jupyter notebook.

## Installation
```bash
pip install crekai_verify
```
