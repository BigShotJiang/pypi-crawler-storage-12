'''
Created on Aug 24, 2020

@author: ballance
'''
from vsc.model.model_visitor import ModelVisitor

class NodeBuilder(ModelVisitor):
    """Builds Boolector nodes for elements of a solve-set"""
    

    