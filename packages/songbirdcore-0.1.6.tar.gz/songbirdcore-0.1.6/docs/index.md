# songbirdcore 🐦 music download engine

Hello, and welcome to `songbirdcore`.

Get started by installing the `songbirdcore` package

```bash
pip install songbirdcore
```

## API Documentation

To view what features are available, please see
the API documentation header at the top of this page!
