"""
Command-line utility for the Kamihi framework.

License:
    MIT

"""

from .cli import app

__all__ = ["app"]
