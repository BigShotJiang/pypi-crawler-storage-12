"""Client module for simplerpyc."""
