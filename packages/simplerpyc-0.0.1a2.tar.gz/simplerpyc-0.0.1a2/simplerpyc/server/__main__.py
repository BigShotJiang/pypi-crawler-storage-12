"""Entry point for python -m simplerpyc.server."""

from simplerpyc.server.server import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    main()  # pragma: no cover
