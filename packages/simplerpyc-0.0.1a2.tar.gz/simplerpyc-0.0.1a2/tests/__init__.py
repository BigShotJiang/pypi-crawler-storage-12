"""Tests for simplerpyc."""
