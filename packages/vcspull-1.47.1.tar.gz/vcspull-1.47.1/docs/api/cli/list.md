# vcspull list - `vcspull.cli.list`

```{eval-rst}
.. automodule:: vcspull.cli.list
   :members:
   :show-inheritance:
   :undoc-members:
```
