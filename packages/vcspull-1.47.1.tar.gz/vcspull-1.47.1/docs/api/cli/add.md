# vcspull add - `vcspull.cli.add`

```{eval-rst}
.. automodule:: vcspull.cli.add
   :members:
   :show-inheritance:
   :undoc-members:
```
