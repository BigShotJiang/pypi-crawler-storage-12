# vcspull discover - `vcspull.cli.discover`

```{eval-rst}
.. automodule:: vcspull.cli.discover
   :members:
   :show-inheritance:
   :undoc-members:
```
