# vcspull fmt - `vcspull.cli.fmt`

```{eval-rst}
.. automodule:: vcspull.cli.fmt
   :members:
   :show-inheritance:
   :undoc-members:
```
