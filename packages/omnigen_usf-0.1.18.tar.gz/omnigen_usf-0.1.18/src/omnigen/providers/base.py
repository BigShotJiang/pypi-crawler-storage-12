"""Base provider implementation."""

from omnigen.core.base import BaseLLMProvider

# Re-export for convenience
__all__ = ["BaseLLMProvider"]