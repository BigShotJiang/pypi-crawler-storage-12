/**
 * Utility for managing replayId persistence in localStorage
 * and URL reconstruction
 */

const REPLAY_ID_STORAGE_KEY = 'sage-replay-id';

/**
 * Get the stored replayId from localStorage
 */
export function getStoredReplayId(): string | null {
  try {
    return localStorage.getItem(REPLAY_ID_STORAGE_KEY);
  } catch (error) {
    console.warn('[ReplayIdManager] Failed to get stored replayId:', error);
    return null;
  }
}

/**
 * Store replayId in localStorage
 */
export function storeReplayId(replayId: string): void {
  try {
    localStorage.setItem(REPLAY_ID_STORAGE_KEY, replayId);
    console.log('[ReplayIdManager] Stored replayId:', replayId);
  } catch (error) {
    console.warn('[ReplayIdManager] Failed to store replayId:', error);
  }
}

/**
 * Remove replayId from localStorage
 */
export function removeStoredReplayId(): void {
  try {
    localStorage.removeItem(REPLAY_ID_STORAGE_KEY);
    console.log('[ReplayIdManager] Removed stored replayId');
  } catch (error) {
    console.warn('[ReplayIdManager] Failed to remove stored replayId:', error);
  }
}

/**
 * Reconstruct the URL with the replayId parameter
 * Preserves all existing URL parameters and adds/updates the replay parameter
 */
export function reconstructUrlWithReplayId(replayId: string | null): void {
  try {
    const url = new URL(window.location.href);

    if (replayId) {
      url.searchParams.set('replay', replayId);
    } else {
      url.searchParams.delete('replay');
    }

    // Only update URL if it actually changed
    const newUrl = url.toString();
    if (newUrl !== window.location.href) {
      // Use replaceState to avoid adding to browser history
      window.history.replaceState({}, '', newUrl);
      console.log(
        '[ReplayIdManager] Reconstructed URL with replayId:',
        replayId
      );
    }
  } catch (error) {
    console.warn('[ReplayIdManager] Failed to reconstruct URL:', error);
  }
}

/**
 * Get replayId from URL parameters
 */
export function getReplayIdFromUrl(): string | null {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('replay');
  } catch (error) {
    console.warn('[ReplayIdManager] Failed to get replayId from URL:', error);
    return null;
  }
}

/**
 * Initialize replayId management:
 * - If replayId is in URL, store it in localStorage
 * - If replayId is not in URL but exists in localStorage, restore it to URL (only if shouldReconstructUrl is true)
 * - If a new replayId is provided, update both URL and localStorage
 * @param shouldReconstructUrl If false, will not reconstruct URL from localStorage. Defaults to true for backwards compatibility.
 */
export async function initializeReplayIdManagement(
  shouldReconstructUrl: boolean = true
): Promise<string | null> {
  const urlReplayId = getReplayIdFromUrl();
  const storedReplayId = getStoredReplayId();

  if (urlReplayId) {
    // New replayId in URL - update localStorage
    if (urlReplayId !== storedReplayId) {
      storeReplayId(urlReplayId);
      console.log(
        '[ReplayIdManager] Updated stored replayId from URL:',
        urlReplayId
      );
    }
    return urlReplayId;
  } else if (storedReplayId && shouldReconstructUrl) {
    // No replayId in URL but exists in localStorage - restore to URL (only if shouldReconstructUrl is true)
    reconstructUrlWithReplayId(storedReplayId);
    console.log(
      '[ReplayIdManager] Restored replayId from localStorage to URL:',
      storedReplayId
    );
    return storedReplayId;
  } else if (storedReplayId && !shouldReconstructUrl) {
    // ReplayId exists in localStorage but we're not reconstructing URL
    console.log(
      '[ReplayIdManager] ReplayId exists in localStorage but URL reconstruction is disabled:',
      storedReplayId
    );
    return storedReplayId;
  }

  return null;
}
