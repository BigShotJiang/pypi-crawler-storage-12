from ._sign_wilcoxsign import test_sign, test_sign_Result
from ._sign_wilcoxsign import test_wilcox, test_wilcox_Result

from ._mannwhitney import test_mannwhitney, test_mannwhitney_Result
from ._kruskalwallis import test_kruskal, test_kruskal_Result

from ._friedman import test_friedman, test_friedman_Result

