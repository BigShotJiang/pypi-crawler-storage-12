from ._linearregress import linregress
from ._linear_simple import SimpleLinRegressResult
from ._linear_multiple import MultipleLinregress