from ._chisqtest import test_chisq, chisq_assoc_Result, chisquare_GoodnessFit_Result
from ._tally import tally, tally_Result