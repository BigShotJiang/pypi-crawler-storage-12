# Included fonts and their licenses

These fonts are are automatically downloaded using `scripts/download_fonts.sh`.

They are included for calculating string widths because they are
metric-compatible with the proprietary fonts commonly used in RTF documents.

## Liberation fonts

Liberation Serif, Liberation Sans, Liberation Mono

License: [SIL Open Font License, Version 1.1](https://github.com/liberationfonts/liberation-fonts/blob/main/LICENSE)

## Carlito

License: [SIL Open Font License, Version 1.1](https://github.com/googlefonts/carlito/blob/main/OFL.txt)

## Caladea

License: [SIL Open Font License, Version 1.1](https://github.com/huertatipografica/Caladea/blob/master/OFL.txt)

## Gelasio

License: [SIL Open Font License, Version 1.1](https://github.com/SorkinType/Gelasio/blob/main/OFL.txt)
