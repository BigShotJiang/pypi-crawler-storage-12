# RTFDocument

The `RTFDocument` class is the main entry point for creating RTF documents with rtflite. It orchestrates all components to generate properly formatted RTF output.

::: rtflite.encode.RTFDocument
    options:
      show_root_heading: false
      show_source: false