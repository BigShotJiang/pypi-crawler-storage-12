from enum import Enum

class SubscriptionAction(str, Enum):
    TERMINATE = 'terminate'
