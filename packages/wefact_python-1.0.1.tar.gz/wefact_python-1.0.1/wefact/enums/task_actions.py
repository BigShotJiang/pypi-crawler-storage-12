from enum import Enum


class TaskAction(str, Enum):
    CHANGE_STATUS = "changestatus"
