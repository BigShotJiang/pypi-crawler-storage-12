__version__ = "0.0.0"

def info():
    return "This is a dummy ofed-private-utils package for PyPI."
