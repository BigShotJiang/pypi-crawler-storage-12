"""Test suite for the bits_and_bobs package."""
