from .service import ContentService


__all__ = (
    "ContentService",
)
