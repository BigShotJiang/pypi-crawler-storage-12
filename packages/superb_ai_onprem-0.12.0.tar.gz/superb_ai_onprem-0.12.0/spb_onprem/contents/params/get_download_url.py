

def get_download_url_params(
    content_id: str,
):
    return {
        "id": content_id
    }