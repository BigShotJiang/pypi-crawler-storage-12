JavaScript API
==============

Client
------

.. js:autoclass:: Client
   :members:

.. js:autofunction:: createClient

List
----

.. js:autoclass:: List
   :members:

Dict
----

.. js:autoclass:: Dict
   :members:

Segments
--------

.. js:autoclass:: Segments
   :members:
