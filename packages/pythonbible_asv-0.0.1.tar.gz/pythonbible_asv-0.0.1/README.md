# pythonbible-asv

The American Standard Version (ASV) of the Bible in Python. For use with the `pythonbible` library.
