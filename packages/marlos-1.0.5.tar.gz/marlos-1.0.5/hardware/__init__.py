"""
MarlOS Hardware Integration
Contains Arduino and ESP firmware code for hardware integration
"""
