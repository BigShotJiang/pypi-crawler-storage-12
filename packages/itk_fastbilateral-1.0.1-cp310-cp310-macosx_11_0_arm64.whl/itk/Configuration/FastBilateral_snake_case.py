snake_case_functions = ('fast_bilateral_image_filter', )
