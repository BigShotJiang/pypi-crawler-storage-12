AclStatus
=========

.. currentmodule:: hdfs_native

.. autoclass:: AclStatus
   :show-inheritance:

   .. rubric:: Attributes Summary

   .. autosummary::

      ~AclStatus.entries
      ~AclStatus.group
      ~AclStatus.owner
      ~AclStatus.permission
      ~AclStatus.sticky

   .. rubric:: Attributes Documentation

   .. autoattribute:: entries
   .. autoattribute:: group
   .. autoattribute:: owner
   .. autoattribute:: permission
   .. autoattribute:: sticky
