# Here for backwards compatibility
from kumoai.artifact_export.config import OutputConfig  # noqa
