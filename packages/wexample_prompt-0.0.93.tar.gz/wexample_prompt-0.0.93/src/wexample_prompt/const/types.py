from __future__ import annotations

from typing import Union

LineMessage = Union[str, list[str]]
