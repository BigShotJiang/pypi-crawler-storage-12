STRING_TO_TYPE_MAP = {
    'str': str,
    'string': str,
    'int': int,
    'bigint': int,
    'integer': int,
    'number': int,
    'float': float,
    'bool': bool,
    'null': None,
    'undefined': None,
}
