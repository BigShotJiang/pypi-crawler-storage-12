#!/usr/bin/env python3

"""Handle the data percistency."""
