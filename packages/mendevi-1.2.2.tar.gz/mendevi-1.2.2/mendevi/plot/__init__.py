#!/usr/bin/env python3

"""Extract from database and plot."""
