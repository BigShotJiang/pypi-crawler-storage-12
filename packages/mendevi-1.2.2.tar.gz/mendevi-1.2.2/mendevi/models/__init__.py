#!/usr/bin/env python3

"""Regressive and predictive models."""

from .base import Model

__all__ = ["Model"]
