from . import wizard
from . import models
from .init_hook import enable_multi_locations
