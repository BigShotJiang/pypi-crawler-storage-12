# Publishing on PyPi

alibuild is available from PyPi. Package page at:

<https://pypi.python.org/pypi/alibuild/>

In order to publish a new version:

- Test, test, test.
- Create a new release in GitHub.
- The github action should automatically create a new release and upload the package to PyPi (it's a good idea to verify that the release was created and the package uploaded).
