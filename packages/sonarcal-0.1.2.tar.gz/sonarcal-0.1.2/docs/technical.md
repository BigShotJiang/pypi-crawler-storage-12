# Technical Manual

This will be the technical documentation for the program and
include API documentation if appropriate.

## Adding support for other sonars
