# User Manual
This will be the documentation for the program.

## How to use

![Main screen](assets/screenshot.png){ align=right }
/// caption
The main operation screen.
///


![](assets/Beam_example.png){ align=right }
/// caption
The seconday display of ping amplitudes.
///

## Configuration

some text

## Export of data

some text

