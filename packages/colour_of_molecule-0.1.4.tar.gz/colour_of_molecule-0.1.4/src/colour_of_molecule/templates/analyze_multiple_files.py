### category: Multiple_files_manipulation


print("file2")
