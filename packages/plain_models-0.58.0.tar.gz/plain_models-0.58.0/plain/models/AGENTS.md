# Plain Models AGENTS.md

- Use the `plain makemigrations` command to create new migrations. Only write migrations by hand if they are custom data migrations.
- Use `plain migrate --backup` to run migrations.
