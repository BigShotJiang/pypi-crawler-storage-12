class BadConfigError(Exception):
    """Raised when the configuration is invalid."""

    pass
