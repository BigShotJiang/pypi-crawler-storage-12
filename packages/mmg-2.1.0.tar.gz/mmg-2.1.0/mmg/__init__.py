#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from importlib.metadata import version


__version__ = version("mmg")
