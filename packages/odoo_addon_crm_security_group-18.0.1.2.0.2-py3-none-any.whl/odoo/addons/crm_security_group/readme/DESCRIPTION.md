This module adds new security options to CRM by creating 4 groups (Own
Documents Only, Team Documents Only, All Documents and Administrator)
to separate Sales and CRM apps permissions