"""
SUTRA - Simple Unified Tool for Relational Analysis
Natural Language to SQL Query System with Visualization

Installation:
    pip install sutra

Usage:
    from sutra import SUTRA
    
    sutra = SUTRA(api_key="your-openai-key")
    sutra.upload("data.csv")
    result = sutra.ask("Show me total sales", viz=True)

Author: Aditya Batta
Version: 0.1.0
"""

__version__ = "0.1.0"
__author__ = "Aditya Batta"

# Import from the single file
from .sutra import SUTRA, QueryResult, quick_start

__all__ = ["SUTRA", "QueryResult", "quick_start"]
