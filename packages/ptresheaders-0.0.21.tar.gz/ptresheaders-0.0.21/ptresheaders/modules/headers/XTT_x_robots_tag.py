from modules.headers._header_test_base import HeaderTestBase
from ptlibs.ptprinthelper import ptprint
from ptlibs.parsers.http_request_parser import HttpRequestParser


class XRobotsTag(HeaderTestBase):
    pass