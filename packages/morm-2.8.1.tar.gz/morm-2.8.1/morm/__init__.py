"""Minimal database object relational mapper.
"""
