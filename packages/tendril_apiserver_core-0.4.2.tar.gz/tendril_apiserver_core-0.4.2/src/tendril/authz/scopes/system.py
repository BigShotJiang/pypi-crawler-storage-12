

scopes = {
    'system:administration': "Perform system administrative actions",
    'system:monitoring': "Read-only system level information access"
}