

from fastapi import FastAPI
apiserver = FastAPI()
