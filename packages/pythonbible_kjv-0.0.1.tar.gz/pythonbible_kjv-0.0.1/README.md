# pythonbible-kjv

The King James Version (KJV) of the Bible in Python. For use with the `pythonbible` library.
