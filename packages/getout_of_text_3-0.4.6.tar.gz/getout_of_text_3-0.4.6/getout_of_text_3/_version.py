__version__ = "0.4.6"

def get_versions():
    return {"version": __version__}
