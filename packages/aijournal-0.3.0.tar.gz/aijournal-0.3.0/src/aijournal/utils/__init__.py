"""Stateless helpers shared across CLI, services, and pipelines."""
