"""Command modules provide the Typer-facing orchestration for each feature."""
