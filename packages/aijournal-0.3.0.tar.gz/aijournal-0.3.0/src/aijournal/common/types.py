"""Common typing aliases shared across the project."""

ISODateStr = str  # 'YYYY-MM-DD'
TimestampStr = str  # ISO8601 string
