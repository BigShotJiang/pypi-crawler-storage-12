"""Common primitives shared across aijournal modules."""
