"""Pipeline modules orchestrate end-to-end workflows for specific CLI commands."""
