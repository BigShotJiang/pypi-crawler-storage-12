"""Public API schemas exposed by aijournal services."""
