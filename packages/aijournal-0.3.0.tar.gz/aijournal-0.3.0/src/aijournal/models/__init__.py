"""Pydantic model package; import from explicit submodules (authoritative, derived, claim_atoms)."""

# Intentionally left empty to avoid implicit re-exports.
