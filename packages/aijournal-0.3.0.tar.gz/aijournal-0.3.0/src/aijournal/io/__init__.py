"""I/O helpers for YAML, artifacts, and related formats."""
