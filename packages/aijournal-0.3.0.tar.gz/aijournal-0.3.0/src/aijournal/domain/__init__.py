"""Domain models live in explicit submodules (changes, evidence, facts, persona, etc.)."""

# This package intentionally avoids re-export magic; import directly from the submodule you need.
