"""Treat shared test utilities as a true package for straightforward imports."""
