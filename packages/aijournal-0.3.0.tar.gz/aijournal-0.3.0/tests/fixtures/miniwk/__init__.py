"""Package marker for the mini workspace fixture bundle."""
