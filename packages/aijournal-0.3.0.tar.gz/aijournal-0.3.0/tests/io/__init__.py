"""Mark IO tests as a concrete package for linting purposes."""
