"""Bundle domain-level tests into a package to simplify discovery."""
