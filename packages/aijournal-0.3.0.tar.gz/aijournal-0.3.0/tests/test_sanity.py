def test_sanity() -> None:
    """Placeholder to keep pytest happy until real tests exist."""
    assert True
