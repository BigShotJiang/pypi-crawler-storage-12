"""Capture-service tests live here as a proper package for importer parity."""
