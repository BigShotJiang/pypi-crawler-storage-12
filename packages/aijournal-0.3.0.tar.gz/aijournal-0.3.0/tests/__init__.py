"""Explicitly package the test suite so imports resolve consistently."""
