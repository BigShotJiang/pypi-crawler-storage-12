"""Group scripted test helpers into a package for import clarity."""
