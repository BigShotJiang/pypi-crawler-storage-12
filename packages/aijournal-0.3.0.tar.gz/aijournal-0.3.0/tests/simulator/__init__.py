"""Group simulator tests into a concrete package for discovery."""
