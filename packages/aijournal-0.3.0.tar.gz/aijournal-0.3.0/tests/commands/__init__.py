"""Keep command tests in a real package so shared helpers import cleanly."""
