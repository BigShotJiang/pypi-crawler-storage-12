"""Keep pipeline tests grouped in a package for consistent discovery."""
