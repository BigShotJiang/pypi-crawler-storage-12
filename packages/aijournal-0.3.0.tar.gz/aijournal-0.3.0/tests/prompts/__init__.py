"""Allow prompt tests to act as a package and avoid implicit-namespace lint."""
