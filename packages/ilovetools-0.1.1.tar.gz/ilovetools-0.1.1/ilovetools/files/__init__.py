"""
File operations and management utilities
"""

__all__ = []