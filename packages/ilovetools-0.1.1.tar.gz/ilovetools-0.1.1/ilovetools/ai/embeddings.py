"""
Embedding utilities for text and vector operations
"""

__all__ = []