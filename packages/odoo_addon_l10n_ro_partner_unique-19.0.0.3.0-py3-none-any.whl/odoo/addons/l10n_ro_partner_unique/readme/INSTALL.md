To install this module, you need to:

1.  Clone the repository <https://github.com/OCA/l10n-romania>
2.  Add the path to this repository in your configuration (addons-path)
3.  Update the module list
4.  Search for "Romania - Partners Unique" in your addons
5.  Install the module
