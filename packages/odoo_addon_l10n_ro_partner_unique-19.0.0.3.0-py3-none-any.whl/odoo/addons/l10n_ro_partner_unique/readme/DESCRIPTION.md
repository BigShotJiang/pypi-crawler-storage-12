This module add condition for unique partners based on VAT and NRC
numbers.
