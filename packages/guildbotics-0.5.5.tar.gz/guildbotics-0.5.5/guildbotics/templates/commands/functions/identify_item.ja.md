---
name: identify_item
response_class: guildbotics.intelligences.common.DecisionResponse
description: 候補から最適な{item_type}を選び、根拠と信頼度を付して返します。
---

ユーザーからのメッセージを読み、最も適した{item_type}を決定してください。

- 選択可能な{item_type}：{candidates}
