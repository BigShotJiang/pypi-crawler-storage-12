---
name: identify_item
response_class: guildbotics.intelligences.common.DecisionResponse
description: Select the most suitable {item_type} from candidates with rationale and confidence.
---

Read the user's message and determine which {item_type} is most suitable.

- Available {item_type}s to choose from: {candidates}
