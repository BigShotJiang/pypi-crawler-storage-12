"""
AgentMap templates package.

Contains embedded prompt templates and system resources.
"""
