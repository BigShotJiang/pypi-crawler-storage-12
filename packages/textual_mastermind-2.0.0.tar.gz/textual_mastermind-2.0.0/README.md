# textual-mastermind

Mastermind game built with Textual


## Installation

```bash
$ pipx install textual-mastermind
```

## Running

```bash
$ mm
```


## License

`textual-mastermind` has been created by Rafal Padkowski. It is licensed under the terms
of the MIT license.
