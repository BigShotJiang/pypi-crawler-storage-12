"""WiiM HTTP API core client.

This module provides the base HTTP transport layer for communicating with WiiM devices.
It handles protocol detection, SSL/TLS, retry logic, and response parsing.
"""

from __future__ import annotations

import asyncio
import ipaddress
import json
import logging
import ssl
import time
from typing import Any
from urllib.parse import urlsplit

import aiohttp
from aiohttp import ClientSession

from ..exceptions import (
    WiiMConnectionError,
    WiiMError,
    WiiMInvalidDataError,
    WiiMRequestError,
    WiiMResponseError,
    WiiMTimeoutError,
)
from ..models import DeviceInfo, PlayerStatus
from .constants import (
    API_ENDPOINT_STATUS,
    DEFAULT_PORT,
    DEFAULT_TIMEOUT,
)
from .audio_pro import validate_audio_pro_response
from .parser import parse_player_status
from .ssl import create_wiim_ssl_context

_LOGGER = logging.getLogger(__name__)

HEADERS: dict[str, str] = {"Connection": "close"}


class BaseWiiMClient:
    """Base WiiM HTTP API client – transport & player-status parser only.

    This class provides the core HTTP transport layer for communicating with WiiM devices.
    It handles protocol detection (HTTP/HTTPS), SSL/TLS configuration, retry logic, and
    response parsing. High-level API methods are provided by mixin classes.
    """

    def __init__(
        self,
        host: str,
        port: int = DEFAULT_PORT,
        timeout: float = DEFAULT_TIMEOUT,
        ssl_context: ssl.SSLContext | None = None,
        session: ClientSession | None = None,
        capabilities: dict[str, Any] | None = None,
    ) -> None:
        """Instantiate the client.

        Args:
            host: Device hostname or IP. A trailing ":<port>" is respected.
            port: Optional override when *host* does **not** include a port.
            timeout: Network timeout (seconds).
            ssl_context: Custom SSL context (tests/advanced use-cases only).
            session: Optional shared *aiohttp* session.
            capabilities: Device capabilities for firmware-specific handling.
        """
        self._discovered_port: bool = False

        if ":" in host and not host.startswith("["):
            # Check if this is an IPv6 address or "host:port" format
            try:
                # Try to parse as IPv6 address
                ipaddress.IPv6Address(host)
                # If successful, it's a pure IPv6 address
                self._host = host
                self.port = port
            except ipaddress.AddressValueError:
                # Not a valid IPv6 address, check if it's "host:port" format
                try:
                    host_part, port_part = host.rsplit(":", 1)
                    self.port = int(port_part)
                    self._host = host_part
                    self._discovered_port = True
                except (ValueError, TypeError):
                    self._host = host
                    self.port = port
        elif host.startswith("[") and "]:" in host:
            # Handle IPv6 address with port in brackets: [2001:db8::1]:8080
            try:
                bracket_end = host.find("]:")
                if bracket_end > 0:
                    ipv6_part = host[1:bracket_end]  # Remove brackets
                    port_part = host[bracket_end + 2 :]  # Skip "]:"
                    self._host = ipv6_part
                    self.port = int(port_part)
                    self._discovered_port = True
                else:
                    self._host = host
                    self.port = port
            except (ValueError, TypeError):
                self._host = host
                self.port = port
        else:
            self._host = host
            self.port = port

        # Normalise host for URL contexts (IPv6 needs brackets).
        self._host_url = (
            f"[{self._host}]" if ":" in self._host and not self._host.startswith("[") else self._host
        )

        # Use firmware-specific timeout if provided
        self.timeout = capabilities.get("response_timeout", timeout) if capabilities else timeout
        self.ssl_context = ssl_context
        self._session = session
        self._capabilities = capabilities or {}

        # Start optimistic with HTTPS.
        self._endpoint: str | None = f"https://{self._host_url}:{self.port}"

        # Internal helpers for parser bookkeeping.
        self._last_track: str | None = None
        self._last_play_mode: str | None = None
        self._verify_ssl_default: bool = True

        # Basic mutex to avoid concurrent protocol-probe races.
        self._lock = asyncio.Lock()

        # Optional metrics collection (enabled by default, can be disabled)
        self._metrics_enabled = True
        self._total_requests = 0
        self._successful_requests = 0
        self._failed_requests = 0
        self._timeout_count = 0
        self._connection_error_count = 0
        self._request_times: list[float] = []  # Last 100 request times
        self._error_history: list[dict[str, Any]] = []  # Last 20 errors
        self._last_error: dict[str, Any] | None = None

    @property
    def capabilities(self) -> dict[str, Any]:
        """Expose device capabilities for entity setup."""
        return self._capabilities

    @property
    def host(self) -> str:
        """Host address (IP or hostname)."""
        return self._host

    @property
    def base_url(self) -> str | None:
        """Base URL used for the last successful request."""
        return self._endpoint

    def enable_metrics(self, enabled: bool = True) -> None:
        """Enable or disable metrics collection.

        Args:
            enabled: True to enable metrics collection, False to disable.
        """
        self._metrics_enabled = enabled

    @property
    def api_stats(self) -> dict[str, Any]:
        """Get API request statistics.

        Returns:
            Dictionary with request statistics including:
            - total_requests: Total number of requests made
            - successful_requests: Number of successful requests
            - failed_requests: Number of failed requests
            - timeout_count: Number of timeout errors
            - connection_error_count: Number of connection errors
            - success_rate: Success rate (0.0-1.0)
            - avg_latency_ms: Average request latency in milliseconds
            - last_error: Last error information (if any)
            - error_history: Last 20 errors
        """
        if not self._metrics_enabled:
            return {"metrics_enabled": False}

        success_rate = (
            self._successful_requests / self._total_requests
            if self._total_requests > 0
            else 0.0
        )

        avg_latency_ms = None
        if self._request_times:
            avg_latency_ms = sum(self._request_times) / len(self._request_times) * 1000

        return {
            "metrics_enabled": True,
            "total_requests": self._total_requests,
            "successful_requests": self._successful_requests,
            "failed_requests": self._failed_requests,
            "timeout_count": self._timeout_count,
            "connection_error_count": self._connection_error_count,
            "success_rate": success_rate,
            "avg_latency_ms": avg_latency_ms,
            "last_error": self._last_error,
            "error_history": self._error_history.copy(),
        }

    @property
    def connection_stats(self) -> dict[str, Any]:
        """Get connection quality statistics.

        Returns:
            Dictionary with connection statistics including:
            - avg_latency_ms: Average request latency in milliseconds
            - success_rate: Request success rate (0.0-1.0)
            - total_requests: Total number of requests
            - failed_requests: Number of failed requests
            - timeout_count: Number of timeout errors
            - connection_error_count: Number of connection errors
            - established_endpoint: Current working endpoint (if any)
        """
        if not self._metrics_enabled:
            return {"metrics_enabled": False}

        success_rate = (
            self._successful_requests / self._total_requests
            if self._total_requests > 0
            else 0.0
        )

        avg_latency_ms = None
        if self._request_times:
            avg_latency_ms = sum(self._request_times) / len(self._request_times) * 1000

        return {
            "metrics_enabled": True,
            "avg_latency_ms": avg_latency_ms,
            "success_rate": success_rate,
            "total_requests": self._total_requests,
            "failed_requests": self._failed_requests,
            "timeout_count": self._timeout_count,
            "connection_error_count": self._connection_error_count,
            "established_endpoint": self._endpoint,
        }

    # ------------------------------------------------------------------
    # SSL Context Management -------------------------------------------
    # ------------------------------------------------------------------

    async def _get_ssl_context(self) -> ssl.SSLContext:
        """Return a permissive SSL context able to talk to WiiM devices.

        For Audio Pro MkII devices, also loads client certificate for mutual TLS authentication.
        Uses executor for blocking SSL operations to avoid blocking the event loop.
        """
        if self.ssl_context is not None:
            return self.ssl_context

        self.ssl_context = await create_wiim_ssl_context(self.ssl_context)
        return self.ssl_context

    # ------------------------------------------------------------------
    # Request Methods ---------------------------------------------------
    # ------------------------------------------------------------------

    async def _request(
        self,
        endpoint: str,
        method: str = "GET",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Perform an HTTP(S) request with smart protocol fallback and firmware-specific handling.

        Protocol fallback strategy:
        1. Try established endpoint first (fast-path)
        2. Only do full probe if no established endpoint exists
        3. After successful connection, stick with working protocol/port
        4. Apply firmware-specific error handling and retries
        """
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            )

        kwargs.setdefault("headers", HEADERS)

        # Use firmware-specific retry logic
        retry_count = self._capabilities.get("retry_count", 3)
        is_legacy_device = self._capabilities.get("is_legacy_device", False)

        for attempt in range(retry_count):
            start_time = time.time() if self._metrics_enabled else None
            try:
                result = await self._request_with_protocol_fallback(endpoint, method, **kwargs)

                # Validate response for legacy firmware
                if is_legacy_device:
                    generation = self._capabilities.get("audio_pro_generation", "original")
                    _LOGGER.debug(
                        "Validating response for legacy device %s (generation: %s) on %s",
                        self.host,
                        generation,
                        endpoint,
                    )
                    result = self._validate_legacy_response(result, endpoint)

                # Track successful request
                if self._metrics_enabled and start_time:
                    elapsed = time.time() - start_time
                    self._total_requests += 1
                    self._successful_requests += 1
                    # Keep last 100 request times
                    self._request_times.append(elapsed)
                    if len(self._request_times) > 100:
                        self._request_times.pop(0)

                return result

            except (aiohttp.ClientError, json.JSONDecodeError) as err:
                # Track error metrics
                if self._metrics_enabled and start_time:
                    elapsed = time.time() - start_time
                    self._total_requests += 1
                    self._failed_requests += 1
                    # Keep last 100 request times (even for failures)
                    self._request_times.append(elapsed)
                    if len(self._request_times) > 100:
                        self._request_times.pop(0)

                    # Track specific error types
                    if isinstance(err, (asyncio.TimeoutError, aiohttp.ServerTimeoutError)):
                        self._timeout_count += 1
                    elif isinstance(err, (aiohttp.ClientConnectorError, aiohttp.ServerDisconnectedError)):
                        self._connection_error_count += 1

                    # Track error in history
                    error_info = {
                        "timestamp": time.time(),
                        "endpoint": endpoint,
                        "error_type": type(err).__name__,
                        "error_message": str(err),
                        "attempt": attempt + 1,
                        "latency_ms": elapsed * 1000,
                    }
                    self._last_error = error_info
                    self._error_history.append(error_info)
                    # Keep last 20 errors
                    if len(self._error_history) > 20:
                        self._error_history.pop(0)

                if attempt == retry_count - 1:
                    # Get comprehensive device info for enhanced error context
                    device_info = {}
                    try:
                        if hasattr(self, "_capabilities") and self._capabilities:
                            caps = self._capabilities
                            device_info = {
                                "firmware_version": caps.get("firmware_version", "unknown"),
                                "device_model": caps.get("device_type", "unknown"),
                                "device_name": caps.get("device_name", "unknown"),
                                "is_wiim_device": caps.get("is_wiim_device", False),
                                "is_legacy_device": caps.get("is_legacy_device", False),
                                "supports_metadata": caps.get("supports_metadata", False),
                                "supports_audio_output": caps.get("supports_audio_output", False),
                            }
                    except Exception:  # noqa: BLE001
                        pass  # Device info not available, continue without it

                    raise WiiMRequestError(
                        f"Request failed after {retry_count} attempts: {err}",
                        endpoint=endpoint,
                        attempts=retry_count,
                        last_error=err,
                        device_info=device_info,
                    ) from err

                # Exponential backoff for retries (longer for legacy devices)
                backoff_delay = 0.5 * (2**attempt)
                if is_legacy_device:
                    backoff_delay *= 2  # Double delay for legacy devices

                _LOGGER.debug(
                    "Request attempt %d/%d failed for %s, retrying in %.1fs: %s",
                    attempt + 1,
                    retry_count,
                    self._host,
                    backoff_delay,
                    err,
                )
                await asyncio.sleep(backoff_delay)

    async def _request_with_protocol_fallback(
        self,
        endpoint: str,
        method: str = "GET",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Perform HTTP(S) request with protocol fallback.

        Tries multiple protocol/port combinations based on device capabilities.
        """
        # Use longer timeout for Bluetooth connection operations (30 seconds)
        # Bluetooth pairing can take 15-20+ seconds, so we need a longer timeout
        is_bluetooth_connection = "connectbta2dpsynk" in endpoint.lower()
        request_timeout = 30.0 if is_bluetooth_connection else self.timeout

        # Fast-path: use established endpoint
        if self._endpoint:
            from urllib.parse import urlsplit

            try:
                p = urlsplit(self._endpoint)
                # Handle IPv6 addresses properly by adding brackets if needed
                hostname = p.hostname
                if hostname and ":" in hostname and not hostname.startswith("["):
                    hostname = f"[{hostname}]"
                url = f"{p.scheme}://{hostname}:{p.port}{endpoint}"
                if p.scheme == "https":
                    kwargs["ssl"] = await self._get_ssl_context()
                else:
                    kwargs.pop("ssl", None)

                async with asyncio.timeout(request_timeout):
                    resp = await self._session.request(method, url, **kwargs)
                    async with resp:
                        resp.raise_for_status()
                        text = await resp.text()

                        # Handle empty responses gracefully
                        if not text or text.strip() == "":
                            # For certain commands like reboot, empty response is expected
                            if "reboot" in endpoint.lower():
                                _LOGGER.debug(
                                    "Reboot command sent successfully (empty response expected)"
                                )
                                return {"raw": "OK"}
                            else:
                                _LOGGER.debug("Empty response from device for %s", endpoint)
                                return {"raw": ""}

                        if text.strip() == "OK":
                            return {"raw": "OK"}

                        # Try to parse JSON, but handle parsing errors gracefully
                        try:
                            return json.loads(text)
                        except json.JSONDecodeError as json_err:
                            # For certain commands, parsing errors are expected
                            if "reboot" in endpoint.lower():
                                _LOGGER.debug(
                                    "Reboot command sent successfully (parsing error expected): %s",
                                    json_err,
                                )
                                return {"raw": "OK"}
                            else:
                                # Re-raise for other commands
                                raise WiiMResponseError(
                                    f"Invalid JSON response from {self._endpoint}{endpoint}: {json_err}",
                                    endpoint=f"{self._endpoint}{endpoint}",
                                    last_error=json_err,
                                ) from json_err

            except Exception as err:  # noqa: BLE001
                _LOGGER.debug("Established endpoint %s failed: %s", self._endpoint, err)
                # Don't immediately fall back to full probe - this could be a temporary network issue
                # Only clear endpoint after multiple consecutive failures or specific error types
                if isinstance(err, (aiohttp.ClientConnectorError, aiohttp.ServerDisconnectedError)):
                    # Only log occasionally to reduce noise - this is normal during network issues
                    if not hasattr(self, "_connection_retry_count"):
                        self._connection_retry_count = 0
                    self._connection_retry_count += 1

                    # Only log the first few connection losses, then throttle
                    if self._connection_retry_count <= 3:
                        _LOGGER.warning(
                            "Connection lost to %s, will retry with protocol probe",
                            self._host,
                        )
                    elif self._connection_retry_count % 5 == 1:  # Every 5th failure
                        _LOGGER.debug(
                            "Connection still failing to %s (attempt %d)",
                            self._host,
                            self._connection_retry_count,
                        )

                    self._endpoint = None  # Clear to force probe
                else:
                    # For other errors (timeouts, HTTP errors), keep the endpoint and fail fast
                    # This avoids expensive re-probing on temporary issues
                    # Get comprehensive device info for enhanced error context
                    device_info = {}
                    try:
                        if hasattr(self, "_capabilities") and self._capabilities:
                            caps = self._capabilities
                            device_info = {
                                "firmware_version": caps.get("firmware_version", "unknown"),
                                "device_model": caps.get("device_type", "unknown"),
                                "device_name": caps.get("device_name", "unknown"),
                                "is_wiim_device": caps.get("is_wiim_device", False),
                                "is_legacy_device": caps.get("is_legacy_device", False),
                                "supports_metadata": caps.get("supports_metadata", False),
                                "supports_audio_output": caps.get("supports_audio_output", False),
                            }
                    except Exception:  # noqa: BLE001
                        pass  # Device info not available, continue without it

                    raise WiiMConnectionError(
                        f"Request to {self._endpoint}{endpoint} failed: {err}",
                        endpoint=f"{self._endpoint}{endpoint}",
                        last_error=err,
                        device_info=device_info,
                    ) from err

        # Initial probe or connection lost - try all protocols
        # Only log protocol probing occasionally to reduce noise during network issues
        if not hasattr(self, "_protocol_probe_count"):
            self._protocol_probe_count = 0
        self._protocol_probe_count += 1

        if self._protocol_probe_count <= 2:
            _LOGGER.info("No established endpoint for %s, performing protocol probe", self._host)
        elif self._protocol_probe_count % 3 == 1:  # Every 3rd probe
            _LOGGER.debug(
                "Protocol probe still needed for %s (attempt %d)",
                self._host,
                self._protocol_probe_count,
            )

        protocols: list[tuple[str, int, ssl.SSLContext | None]]

        # Use protocol priority from capabilities if available
        protocol_priority = self._capabilities.get("protocol_priority", ["https", "http"])
        _LOGGER.debug("Using protocol priority for %s: %s", self._host, protocol_priority)

        # Get SSL context once (cached after first call) and reuse for all HTTPS protocols
        ssl_ctx = await self._get_ssl_context()

        if self._discovered_port:
            # Build protocols based on discovered port and priority
            protocols = []
            for scheme in protocol_priority:
                if scheme == "https":
                    protocols.append((scheme, self.port, ssl_ctx))
                else:  # http
                    protocols.append((scheme, self.port, None))
        else:
            # Build protocols based on standard ports and priority
            protocols = []

            # Use preferred ports from capabilities if specified (Audio Pro MkII uses 4443)
            preferred_ports = self._capabilities.get("preferred_ports", [])

            for scheme in protocol_priority:
                if scheme == "https":
                    if preferred_ports:
                        # Audio Pro MkII: Use preferred ports (4443, 8443, 443)
                        for port in preferred_ports:
                            protocols.append((scheme, port, ssl_ctx))
                    else:
                        # Standard devices: Try common HTTPS ports
                        protocols.extend(
                            [
                                (scheme, 443, ssl_ctx),
                                (scheme, 4443, ssl_ctx),
                                (scheme, 8443, ssl_ctx),
                            ]
                        )
                else:  # http
                    protocols.extend(
                        [
                            (scheme, 80, None),
                            (scheme, 8080, None),
                        ]
                    )

            # Add custom port if not standard
            if self.port not in (80, 443, 4443, 8080):
                for scheme in protocol_priority:
                    if scheme == "https":
                        protocols.insert(0, (scheme, self.port, ssl_ctx))
                    else:  # http
                        protocols.insert(0, (scheme, self.port, None))

            # Add Audio Pro MkII specific endpoints as fallback
            # These devices may use different API structures or additional ports
            if self._capabilities.get("audio_pro_generation") in (
                "mkii",
                "w_generation",
            ):
                _LOGGER.debug("Adding Audio Pro MkII specific fallback endpoints")
                protocols.extend(
                    [
                        # Re-add common ports with higher priority for Audio Pro
                        ("https", 443, ssl_ctx),
                        ("https", 4443, ssl_ctx),
                        ("https", 8443, ssl_ctx),
                        ("http", 80, None),
                        ("http", 8080, None),
                        # Some Audio Pro devices may use port 8888
                        ("http", 8888, None),
                        ("https", 8888, ssl_ctx),
                    ]
                )

        last_error: Exception | None = None
        tried: list[str] = []

        for scheme, port, ssl_ctx in protocols:
            host_for_url = (
                f"[{self._host}]"
                if ":" in self._host and not self._host.startswith("[")
                else self._host
            )

            # Build candidate endpoint paths to try for this scheme/port
            paths_to_try: list[str] = [endpoint]
            if endpoint == API_ENDPOINT_STATUS:
                # Canonical LinkPlay fallbacks
                paths_to_try.extend(
                    [
                        "/httpapi.asp?command=getStatus",
                        "/httpapi.asp?command=getPlayerStatus",
                    ]
                )

                # Audio Pro MkII/W: try a few common REST/CGI variants
                if self._capabilities.get("audio_pro_generation") in (
                    "mkii",
                    "w_generation",
                ):
                    paths_to_try.extend(
                        [
                            "/api/status",
                            "/cgi-bin/status.cgi",
                            "/status",
                            "/api/v1/status",
                            "/device/status",
                        ]
                    )
                    if endpoint.startswith("/httpapi.asp"):
                        paths_to_try.append(endpoint.replace("/httpapi.asp", "", 1))

            # Configure SSL per scheme
            if scheme == "https":
                kwargs["ssl"] = ssl_ctx
            else:
                kwargs.pop("ssl", None)

            # Attempt each candidate path
            for path in paths_to_try:
                url = f"{scheme}://{host_for_url}:{port}{path}"
                tried.append(url)

                try:
                    async with asyncio.timeout(request_timeout):
                        resp = await self._session.request(method, url, **kwargs)
                        async with resp:
                            resp.raise_for_status()
                            text = await resp.text()

                            # Handle empty responses gracefully
                            if not text or text.strip() == "":
                                if "reboot" in path.lower():
                                    _LOGGER.debug(
                                        "Reboot command sent successfully (empty response expected)"
                                    )
                                    self._endpoint = f"{scheme}://{host_for_url}:{port}"
                                    _LOGGER.debug(
                                        "Established endpoint for %s: %s",
                                        self._host,
                                        self._endpoint,
                                    )
                                    return {"raw": "OK"}
                                _LOGGER.debug("Empty response from device for %s", path)
                                self._endpoint = f"{scheme}://{host_for_url}:{port}"
                                _LOGGER.debug(
                                    "Established endpoint for %s: %s",
                                    self._host,
                                    self._endpoint,
                                )
                                return {"raw": ""}

                            # SUCCESS: Lock in this base endpoint
                            self._endpoint = f"{scheme}://{host_for_url}:{port}"
                            _LOGGER.debug(
                                "Established endpoint for %s: %s",
                                self._host,
                                self._endpoint,
                            )

                            if text.strip() == "OK":
                                return {"raw": "OK"}

                            # Try to parse JSON, but handle parsing errors gracefully
                            try:
                                return json.loads(text)
                            except json.JSONDecodeError as json_err:
                                if "reboot" in path.lower():
                                    _LOGGER.debug(
                                        "Reboot command sent successfully (parsing error expected): %s",
                                        json_err,
                                    )
                                    return {"raw": "OK"}
                                # Provide context on invalid JSON
                                device_info = {}
                                try:
                                    if hasattr(self, "_capabilities") and self._capabilities:
                                        device_info = {
                                            "firmware_version": self._capabilities.get(
                                                "firmware_version", "unknown"
                                            ),
                                            "device_model": self._capabilities.get(
                                                "device_model", "unknown"
                                            ),
                                        }
                                except Exception:  # noqa: BLE001
                                    pass

                                raise WiiMResponseError(
                                    f"Invalid JSON response from {url}: {json_err}",
                                    endpoint=url,
                                    last_error=json_err,
                                    device_info=device_info,
                                ) from json_err

                except (TimeoutError, aiohttp.ClientError, json.JSONDecodeError) as err:
                    last_error = err
                    continue

        # Get device info for enhanced error context
        device_info = {}
        try:
            if hasattr(self, "_capabilities") and self._capabilities:
                device_info = {
                    "firmware_version": self._capabilities.get("firmware_version", "unknown"),
                    "device_model": self._capabilities.get("device_model", "unknown"),
                }
        except Exception:  # noqa: BLE001
            pass  # Device info not available, continue without it

        # Count total attempts (protocols tried)
        total_attempts = len(tried)

        raise WiiMConnectionError(
            f"Failed to communicate with {self._host} after trying: {', '.join(tried)}\nLast error: {last_error}",
            endpoint=endpoint,
            attempts=total_attempts,
            last_error=last_error,
            device_info=device_info,
            operation_context="protocol_fallback",
        )

    # ------------------------------------------------------------------
    # Legacy Response Validation ----------------------------------------
    # ------------------------------------------------------------------

    def _validate_legacy_response(
        self,
        response: dict[str, Any] | str,
        endpoint: str,
    ) -> dict[str, Any]:
        """Handle malformed responses from older firmware.

        Args:
            response: Raw API response (dict or string)
            endpoint: API endpoint that was called

        Returns:
            Validated response with safe defaults if needed
        """
        return validate_audio_pro_response(
            response,
            endpoint,
            self.host,
            self._capabilities,
        )

    # ------------------------------------------------------------------
    # Public API Methods -----------------------------------------------
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying *aiohttp* session."""
        if self._session and not self._session.closed:
            await self._session.close()
        self._session = None

    async def validate_connection(self) -> bool:
        """Return *True* if *getPlayerStatusEx* answers successfully."""
        try:
            await self.get_player_status()
            return True
        except WiiMError:
            return False

    async def get_device_name(self) -> str:
        """Return device-reported *DeviceName* or the raw IP if unavailable."""
        try:
            status = await self.get_player_status()
            if name := status.get("DeviceName"):
                return name.strip()
            info = await self.get_device_info()
            if name := info.get("DeviceName") or info.get("device_name"):
                return name.strip()
        except WiiMError:
            _LOGGER.debug("Falling back to IP for device name of %s", self._host)
        return self._host

    async def get_status(self) -> dict[str, Any]:
        """Return normalised output of *getStatusEx* (device-level info)."""
        raw = await self._request(API_ENDPOINT_STATUS)
        parsed, self._last_track = parse_player_status(raw, self._last_track)
        return parsed

    async def get_device_info(self) -> dict[str, Any]:
        """Lightweight wrapper around *getStatusEx* (raw JSON)."""
        try:
            return await self._request(API_ENDPOINT_STATUS)
        except WiiMError as err:
            _LOGGER.debug("get_device_info failed: %s", err)
            return {}

    async def get_player_status(self) -> dict[str, Any]:
        """Return parsed output of getPlayerStatusEx with Audio Pro MkII fallback.

        Audio Pro MkII devices don't support getPlayerStatusEx, so we use getStatusEx instead.
        The capability system automatically selects the right endpoint.
        """
        try:
            # Check if device supports getPlayerStatusEx (most devices do)
            if self._capabilities.get("supports_player_status_ex", True):
                # Standard devices use getPlayerStatusEx
                endpoint = "/httpapi.asp?command=getPlayerStatusEx"
            else:
                # Audio Pro MkII uses getStatusEx instead (from capabilities)
                endpoint = self._capabilities.get(
                    "status_endpoint", "/httpapi.asp?command=getStatusEx"
                )
                _LOGGER.debug("Using Audio Pro MkII fallback endpoint: %s", endpoint)

            try:
                raw = await self._request(endpoint)
                # Log raw HTTP response for debugging
                if _LOGGER.isEnabledFor(logging.DEBUG):
                    _LOGGER.debug(
                        "HTTP response from %s for %s: %s",
                        endpoint,
                        self.host,
                        raw,
                    )
            except WiiMRequestError as primary_err:
                # If getPlayerStatusEx fails (unsupported on some Audio Pro devices), try getStatusEx
                if endpoint.endswith("getPlayerStatusEx"):
                    fallback_endpoint = "/httpapi.asp?command=getStatusEx"
                    _LOGGER.debug(
                        "Primary status endpoint failed (%s); retrying with fallback %s",
                        endpoint,
                        fallback_endpoint,
                    )
                    raw = await self._request(fallback_endpoint)
                    # Log raw HTTP response from fallback endpoint
                    if _LOGGER.isEnabledFor(logging.DEBUG):
                        _LOGGER.debug(
                            "HTTP response from fallback %s for %s: %s",
                            fallback_endpoint,
                            self.host,
                            raw,
                        )
                else:
                    raise primary_err

            parsed, self._last_track = parse_player_status(raw, self._last_track)
            return parsed
        except Exception as err:
            # Log specific error types for debugging
            error_str = str(err).lower()
            if "404" in error_str:
                _LOGGER.debug("getPlayerStatusEx not supported by device at %s", self.host)
            elif "timeout" in error_str:
                _LOGGER.debug("Timeout getting player status from %s", self.host)
            else:
                _LOGGER.debug("get_player_status failed: %s", err)
            raise

    # ------------------------------------------------------------------
    # Typed Wrappers (Pydantic) ----------------------------------------
    # ------------------------------------------------------------------

    async def get_device_info_model(self) -> DeviceInfo:
        """Return :class:`DeviceInfo` parsed by *pydantic*."""
        return DeviceInfo.model_validate(await self.get_device_info())

    async def get_player_status_model(self) -> PlayerStatus:
        """Return :class:`PlayerStatus` parsed by *pydantic*."""
        return PlayerStatus.model_validate(await self.get_player_status())

