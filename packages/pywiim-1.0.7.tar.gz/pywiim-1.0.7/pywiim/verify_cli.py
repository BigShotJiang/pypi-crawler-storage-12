"""Command-line tool for testing all WiiM device features and endpoints.

This tool exercises all available commands and endpoints with safety constraints
(e.g., volume never exceeds 10%) to verify functionality without disrupting normal use.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from typing import Any

from .client import WiiMClient
from .exceptions import WiiMError
from .player import Player


class FeatureTester:
    """Test all device features and endpoints safely."""

    def __init__(self, player: Player) -> None:
        """Initialize tester with a Player instance."""
        self.player = player
        self.client = player.client
        self.results: dict[str, Any] = {
            "passed": [],
            "failed": [],
            "skipped": [],
            "warnings": [],
        }
        self.original_state: dict[str, Any] = {}

    async def save_state(self) -> None:
        """Save original device state for restoration."""
        print("💾 Saving original device state...")
        try:
            await self.player.refresh()
            self.original_state = {
                "volume": self.player.volume_level,
                "mute": self.player.is_muted,
                "source": self.player.source,
                "play_state": self.player.play_state,
            }
            print(f"   ✓ Volume: {self.original_state.get('volume')}")
            print(f"   ✓ Mute: {self.original_state.get('mute')}")
            print(f"   ✓ Source: {self.original_state.get('source')}")
            print(f"   ✓ Play state: {self.original_state.get('play_state')}")
        except Exception as e:
            print(f"   ⚠️  Could not save state: {e}")

    async def restore_state(self) -> None:
        """Restore original device state."""
        print("\n🔄 Restoring original device state...")
        try:
            if "volume" in self.original_state and self.original_state["volume"] is not None:
                await self.player.set_volume(self.original_state["volume"])
                await asyncio.sleep(0.5)
            if "mute" in self.original_state and self.original_state["mute"] is not None:
                await self.player.set_mute(self.original_state["mute"])
                await asyncio.sleep(0.5)
            if "source" in self.original_state and self.original_state["source"]:
                try:
                    await self.player.set_source(self.original_state["source"])
                    await asyncio.sleep(0.5)
                except Exception:
                    pass  # Source restore may fail if source unavailable
            print("   ✓ State restored")
        except Exception as e:
            print(f"   ⚠️  Could not fully restore state: {e}")

    async def test_device_info(self) -> None:
        """Test device information endpoints."""
        print("\n📋 Testing Device Information...")
        
        tests = [
            ("get_device_info_model", lambda: self.client.get_device_info_model()),
            ("get_device_info", lambda: self.client.get_device_info()),
            ("get_device_name", lambda: self.client.get_device_name()),
            ("get_firmware_info", lambda: self.client.get_firmware_info()),
        ]
        
        for name, test_func in tests:
            try:
                result = await test_func()
                self.results["passed"].append(f"device_info: {name}")
                print(f"   ✓ {name}")
            except Exception as e:
                self.results["failed"].append(f"device_info: {name} - {str(e)}")
                print(f"   ✗ {name}: {e}")

    async def test_status_endpoints(self) -> None:
        """Test status query endpoints."""
        print("\n📊 Testing Status Endpoints...")
        
        tests = [
            ("get_status", lambda: self.client.get_status()),
            ("get_player_status", lambda: self.client.get_player_status()),
            ("get_player_status_model", lambda: self.client.get_player_status_model()),
            ("get_meta_info", lambda: self.client.get_meta_info()),
        ]
        
        for name, test_func in tests:
            try:
                result = await test_func()
                self.results["passed"].append(f"status: {name}")
                print(f"   ✓ {name}")
            except Exception as e:
                self.results["failed"].append(f"status: {name} - {str(e)}")
                print(f"   ✗ {name}: {e}")

    async def test_playback_controls(self) -> None:
        """Test playback control commands."""
        print("\n▶️  Testing Playback Controls...")
        
        # Test play commands (non-destructive)
        tests = [
            ("play", lambda: self.client.play()),
            ("pause", lambda: self.client.pause()),
            ("resume", lambda: self.client.resume()),
            ("stop", lambda: self.client.stop()),
            ("next_track", lambda: self.client.next_track()),
            ("previous_track", lambda: self.client.previous_track()),
        ]
        
        for name, test_func in tests:
            try:
                await test_func()
                await asyncio.sleep(0.5)  # Brief delay between commands
                self.results["passed"].append(f"playback: {name}")
                print(f"   ✓ {name}")
            except Exception as e:
                self.results["failed"].append(f"playback: {name} - {str(e)}")
                print(f"   ✗ {name}: {e}")

    async def test_volume_controls(self) -> None:
        """Test volume and mute controls (safely)."""
        print("\n🔊 Testing Volume Controls (max 10%)...")
        
        # Save current volume
        try:
            await self.player.refresh()
            current_vol = self.player.volume_level or 0.0
        except Exception:
            current_vol = 0.0
        
        # Test volume set (max 10%)
        max_test_volume = min(0.10, current_vol + 0.05)  # Never exceed 10%, or current + 5%
        
        tests = [
            ("set_volume (5%)", lambda: self.client.set_volume(0.05)),
            ("set_volume (10%)", lambda: self.client.set_volume(max_test_volume)),
            ("set_mute (True)", lambda: self.client.set_mute(True)),
            ("set_mute (False)", lambda: self.client.set_mute(False)),
        ]
        
        for name, test_func in tests:
            try:
                await test_func()
                await asyncio.sleep(0.5)
                self.results["passed"].append(f"volume: {name}")
                print(f"   ✓ {name}")
            except Exception as e:
                self.results["failed"].append(f"volume: {name} - {str(e)}")
                print(f"   ✗ {name}: {e}")

    async def test_source_controls(self) -> None:
        """Test source switching."""
        print("\n📻 Testing Source Controls...")
        
        try:
            await self.player.refresh()
            available_sources = self.player.available_sources or []
            
            if not available_sources:
                self.results["skipped"].append("source: No sources available")
                print("   ⊘ No sources available to test")
                return
            
            # Test switching to first available source (if not already on it)
            current_source = self.player.source
            test_source = available_sources[0] if available_sources else None
            
            if test_source and test_source != current_source:
                try:
                    await self.client.set_source(test_source)
                    await asyncio.sleep(1.0)
                    await self.player.refresh()
                    if self.player.source == test_source:
                        self.results["passed"].append(f"source: set_source({test_source})")
                        print(f"   ✓ set_source({test_source})")
                    else:
                        self.results["warnings"].append(f"source: set_source({test_source}) - source may not have changed")
                        print(f"   ⚠️  set_source({test_source}) - may not have changed")
                except Exception as e:
                    self.results["failed"].append(f"source: set_source({test_source}) - {str(e)}")
                    print(f"   ✗ set_source({test_source}): {e}")
            else:
                self.results["skipped"].append(f"source: Already on {test_source} or no test source")
                print(f"   ⊘ Already on {test_source} or no test source")
        except Exception as e:
            self.results["failed"].append(f"source: Error testing sources - {str(e)}")
            print(f"   ✗ Error testing sources: {e}")

    async def test_audio_output(self) -> None:
        """Test audio output mode controls."""
        print("\n🔌 Testing Audio Output Controls...")
        
        if not self.client.capabilities.get("supports_audio_output", False):
            self.results["skipped"].append("audio_output: Not supported")
            print("   ⊘ Audio output controls not supported")
            return
        
        try:
            # Get current status
            status = await self.client.get_audio_output_status()
            if status:
                self.results["passed"].append("audio_output: get_audio_output_status")
                print("   ✓ get_audio_output_status")
            
            # Test setting output mode (if supported)
            available_modes = self.player.available_output_modes
            if available_modes:
                # Try setting to first available mode (if different from current)
                current_mode = self.player.audio_output_mode
                test_mode = available_modes[0] if available_modes else None
                
                if test_mode and test_mode != current_mode:
                    try:
                        await self.player.set_audio_output_mode(test_mode)
                        await asyncio.sleep(0.5)
                        self.results["passed"].append(f"audio_output: set_audio_output_mode({test_mode})")
                        print(f"   ✓ set_audio_output_mode({test_mode})")
                    except Exception as e:
                        self.results["failed"].append(f"audio_output: set_audio_output_mode({test_mode}) - {str(e)}")
                        print(f"   ✗ set_audio_output_mode({test_mode}): {e}")
                else:
                    self.results["skipped"].append(f"audio_output: Already on {test_mode} or no test mode")
                    print(f"   ⊘ Already on {test_mode} or no test mode")
        except Exception as e:
            self.results["failed"].append(f"audio_output: Error - {str(e)}")
            print(f"   ✗ Error: {e}")

    async def test_eq_controls(self) -> None:
        """Test EQ controls."""
        print("\n🎛️  Testing EQ Controls...")
        
        if not self.client.capabilities.get("supports_eq", False):
            self.results["skipped"].append("eq: Not supported")
            print("   ⊘ EQ not supported")
            return
        
        try:
            # Get current EQ
            eq = await self.client.get_eq()
            if eq:
                self.results["passed"].append("eq: get_eq")
                print("   ✓ get_eq")
            
            # Get EQ presets
            presets = await self.client.get_eq_presets()
            if presets:
                self.results["passed"].append("eq: get_eq_presets")
                print(f"   ✓ get_eq_presets ({len(presets)} presets)")
            
            # Test setting EQ preset (if available)
            if presets and len(presets) > 0:
                # Try "flat" preset if available, otherwise first preset
                test_preset = "flat" if "flat" in presets else presets[0]
                try:
                    await self.client.set_eq_preset(test_preset)
                    await asyncio.sleep(0.5)
                    self.results["passed"].append(f"eq: set_eq_preset({test_preset})")
                    print(f"   ✓ set_eq_preset({test_preset})")
                except Exception as e:
                    self.results["failed"].append(f"eq: set_eq_preset({test_preset}) - {str(e)}")
                    print(f"   ✗ set_eq_preset({test_preset}): {e}")
            
            # Test EQ enable/disable
            try:
                await self.client.set_eq_enabled(True)
                await asyncio.sleep(0.3)
                await self.client.set_eq_enabled(False)
                await asyncio.sleep(0.3)
                self.results["passed"].append("eq: set_eq_enabled")
                print("   ✓ set_eq_enabled")
            except Exception as e:
                self.results["failed"].append(f"eq: set_eq_enabled - {str(e)}")
                print(f"   ✗ set_eq_enabled: {e}")
        except Exception as e:
            self.results["failed"].append(f"eq: Error - {str(e)}")
            print(f"   ✗ Error: {e}")

    async def test_preset_controls(self) -> None:
        """Test preset controls."""
        print("\n⭐ Testing Preset Controls...")
        
        try:
            presets = await self.client.get_presets()
            if presets:
                self.results["passed"].append("preset: get_presets")
                print(f"   ✓ get_presets ({len(presets)} presets)")
                
                # Test playing a preset (if available)
                if len(presets) > 0:
                    preset_num = presets[0].get("number", 1)
                    try:
                        await self.client.play_preset(preset_num)
                        await asyncio.sleep(1.0)
                        self.results["passed"].append(f"preset: play_preset({preset_num})")
                        print(f"   ✓ play_preset({preset_num})")
                    except Exception as e:
                        self.results["failed"].append(f"preset: play_preset({preset_num}) - {str(e)}")
                        print(f"   ✗ play_preset({preset_num}): {e}")
            else:
                self.results["skipped"].append("preset: No presets available")
                print("   ⊘ No presets available")
        except Exception as e:
            # Presets may not be supported
            if "404" in str(e) or "not supported" in str(e).lower():
                self.results["skipped"].append(f"preset: Not supported - {str(e)}")
                print(f"   ⊘ Presets not supported")
            else:
                self.results["failed"].append(f"preset: Error - {str(e)}")
                print(f"   ✗ Error: {e}")

    async def test_multiroom_controls(self) -> None:
        """Test multiroom/group controls (read-only, non-destructive)."""
        print("\n👥 Testing Multiroom Controls (read-only)...")
        
        try:
            multiroom = await self.client.get_multiroom_status()
            if multiroom:
                self.results["passed"].append("multiroom: get_multiroom_status")
                print("   ✓ get_multiroom_status")
            
            slaves = await self.client.get_slaves()
            if slaves is not None:
                self.results["passed"].append("multiroom: get_slaves")
                print(f"   ✓ get_slaves ({len(slaves) if slaves else 0} slaves)")
            
            group_info = await self.client.get_device_group_info()
            if group_info:
                self.results["passed"].append("multiroom: get_device_group_info")
                print(f"   ✓ get_device_group_info (role: {group_info.role})")
        except Exception as e:
            self.results["failed"].append(f"multiroom: Error - {str(e)}")
            print(f"   ✗ Error: {e}")

    async def test_bluetooth_controls(self) -> None:
        """Test Bluetooth controls (read-only)."""
        print("\n📱 Testing Bluetooth Controls (read-only)...")
        
        try:
            history = await self.client.get_bluetooth_history()
            if history is not None:
                self.results["passed"].append("bluetooth: get_bluetooth_history")
                print(f"   ✓ get_bluetooth_history ({len(history) if history else 0} devices)")
        except Exception as e:
            # Bluetooth may not be supported
            if "not supported" in str(e).lower() or "404" in str(e):
                self.results["skipped"].append(f"bluetooth: Not supported")
                print("   ⊘ Bluetooth not supported")
            else:
                self.results["failed"].append(f"bluetooth: Error - {str(e)}")
                print(f"   ✗ Error: {e}")

    async def test_audio_settings(self) -> None:
        """Test audio settings endpoints."""
        print("\n🎚️  Testing Audio Settings...")
        
        try:
            status = await self.client.get_audio_settings_status()
            if status:
                self.results["passed"].append("audio_settings: get_audio_settings_status")
                print("   ✓ get_audio_settings_status")
        except Exception as e:
            if "not supported" in str(e).lower() or "404" in str(e):
                self.results["skipped"].append("audio_settings: Not supported")
                print("   ⊘ Audio settings not supported")
            else:
                self.results["failed"].append(f"audio_settings: Error - {str(e)}")
                print(f"   ✗ Error: {e}")

    async def test_lms_controls(self) -> None:
        """Test LMS/Squeezelite controls."""
        print("\n🎵 Testing LMS Integration...")
        
        try:
            state = await self.client.get_squeezelite_state()
            if state is not None:
                self.results["passed"].append("lms: get_squeezelite_state")
                print("   ✓ get_squeezelite_state")
        except Exception as e:
            if "not supported" in str(e).lower() or "404" in str(e):
                self.results["skipped"].append("lms: Not supported")
                print("   ⊘ LMS integration not supported")
            else:
                self.results["failed"].append(f"lms: Error - {str(e)}")
                print(f"   ✗ Error: {e}")

    async def test_misc_controls(self) -> None:
        """Test miscellaneous controls."""
        print("\n🔧 Testing Miscellaneous Controls...")
        
        # Test LED controls (if supported)
        try:
            # Just check if we can query LED status (don't change it)
            # Most devices don't have a getter, so we'll skip actual LED testing
            self.results["skipped"].append("misc: LED controls (skipped - no safe test)")
            print("   ⊘ LED controls (skipped - no safe read-only test)")
        except Exception:
            pass

    async def run_all_tests(self) -> dict[str, Any]:
        """Run all feature tests."""
        print("=" * 60)
        print("🧪 WiiM Device Feature Test Suite")
        print("=" * 60)
        print(f"\nDevice: {self.client.host}")
        
        # Save original state
        await self.save_state()
        
        # Detect capabilities
        try:
            await self.client._detect_capabilities()
            print(f"\n🔧 Capabilities detected: {self.client.capabilities.get('vendor', 'unknown')}")
        except Exception as e:
            print(f"\n⚠️  Could not detect capabilities: {e}")
        
        # Run all test suites
        await self.test_device_info()
        await self.test_status_endpoints()
        await self.test_playback_controls()
        await self.test_volume_controls()
        await self.test_source_controls()
        await self.test_audio_output()
        await self.test_eq_controls()
        await self.test_preset_controls()
        await self.test_multiroom_controls()
        await self.test_bluetooth_controls()
        await self.test_audio_settings()
        await self.test_lms_controls()
        await self.test_misc_controls()
        
        # Restore original state
        await self.restore_state()
        
        # Generate summary
        return self._generate_summary()

    def _generate_summary(self) -> dict[str, Any]:
        """Generate test summary."""
        total = len(self.results["passed"]) + len(self.results["failed"]) + len(self.results["skipped"])
        
        return {
            "total_tests": total,
            "passed": len(self.results["passed"]),
            "failed": len(self.results["failed"]),
            "skipped": len(self.results["skipped"]),
            "warnings": len(self.results["warnings"]),
            "results": self.results,
        }

    def print_summary(self) -> None:
        """Print test summary."""
        summary = self._generate_summary()
        
        print("\n" + "=" * 60)
        print("📊 TEST SUMMARY")
        print("=" * 60)
        print(f"\nTotal tests: {summary['total_tests']}")
        print(f"✅ Passed: {summary['passed']}")
        print(f"❌ Failed: {summary['failed']}")
        print(f"⊘ Skipped: {summary['skipped']}")
        if summary['warnings'] > 0:
            print(f"⚠️  Warnings: {summary['warnings']}")
        
        if self.results["failed"]:
            print("\n❌ Failed tests:")
            for failure in self.results["failed"]:
                print(f"   - {failure}")
        
        if self.results["warnings"]:
            print("\n⚠️  Warnings:")
            for warning in self.results["warnings"]:
                print(f"   - {warning}")
        
        print("\n" + "=" * 60)


async def main() -> int:
    """Main entry point for verify CLI."""
    parser = argparse.ArgumentParser(
        description="Verify all WiiM device features and endpoints",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic verification suite
  wiim-verify 192.168.1.68
  
  # Verbose output
  wiim-verify 192.168.1.68 --verbose
  
  # HTTPS device
  wiim-verify 192.168.1.68 --port 443
        """,
    )
    parser.add_argument(
        "device_ip",
        help="Device IP address or hostname",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=80,
        help="Device port (default: 80, use 443 for HTTPS)",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose logging",
    )
    
    args = parser.parse_args()
    
    # Configure logging
    import logging
    
    level = logging.DEBUG if args.verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    
    # Create client and player
    client = WiiMClient(host=args.device_ip, port=args.port)
    player = Player(client)
    
    tester = FeatureTester(player)
    
    try:
        summary = await tester.run_all_tests()
        tester.print_summary()
        
        # Return exit code based on results
        if summary["failed"] > 0:
            return 1
        return 0
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Testing interrupted by user")
        await tester.restore_state()
        return 1
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        await tester.restore_state()
        return 1
    finally:
        await client.close()


def cli_main() -> None:
    """CLI entry point."""
    sys.exit(asyncio.run(main()))


if __name__ == "__main__":
    cli_main()

