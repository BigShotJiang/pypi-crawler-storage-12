---
name: Feature request
about: Suggest an idea/feature for this project
title: ''
labels: 'kind/feature'
assignees: ''

---

### Motivation

Describe here the motivation of the request.

### Acceptance criteria

- [ ] A checklist of tasks to be done to assume the issue addressed