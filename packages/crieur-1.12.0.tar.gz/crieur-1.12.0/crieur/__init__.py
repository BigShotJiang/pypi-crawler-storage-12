from pathlib import Path

VERSION = "1.12.0"
ROOT_DIR = Path(__file__).parent
