"""Allow `python -m routheon_server`."""

from .cli import main

if __name__ == "__main__":
    main()

