# sage_setup: distribution = sagemath-sirocco
