# rag_lecture/__init__.py
from .core import RAGLecture

__all__ = ["RAGLecture"]
__version__ = "0.1.0"