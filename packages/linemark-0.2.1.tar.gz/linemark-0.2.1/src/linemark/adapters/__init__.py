"""Adapters layer: Concrete implementations of port interfaces."""
