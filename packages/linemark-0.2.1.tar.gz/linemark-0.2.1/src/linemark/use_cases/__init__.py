"""Use cases layer: Application logic and orchestration."""
