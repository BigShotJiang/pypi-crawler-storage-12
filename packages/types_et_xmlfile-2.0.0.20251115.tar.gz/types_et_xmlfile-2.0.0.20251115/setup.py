
from setuptools import setup

setup(package_data={'et_xmlfile-stubs': ['__init__.pyi', 'incremental_tree.pyi', 'xmlfile.pyi', 'METADATA.toml', 'py.typed']})
