## 2.0.0.20251115 (2025-11-15)

[et-xmlfile] Add stubs ([#14962](https://github.com/python/typeshed/pull/14962))

