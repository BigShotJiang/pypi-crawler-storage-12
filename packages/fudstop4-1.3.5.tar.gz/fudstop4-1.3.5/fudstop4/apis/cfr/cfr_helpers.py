def clean_string(s: str) -> str:
    return s.replace("ù", "-")  # Replace 'ù' with '