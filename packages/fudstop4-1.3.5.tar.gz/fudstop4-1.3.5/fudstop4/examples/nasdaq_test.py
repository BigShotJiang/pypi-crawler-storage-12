from apis.nasdaq.nasdaq_sdk import Nasdaq


nasdaq = Nasdaq()


nasdaq.economic_indicators()


nasdaq.bigmac()


nasdaq.inflation()


nasdaq.income_expenditures()

nasdaq.unemployment()


nasdaq.sp500()


nasdaq.repo()


nasdaq.gdp()

nasdaq.interest_rates()