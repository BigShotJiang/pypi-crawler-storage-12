# !/usr/bin/env python3
# -*- coding:utf-8 -*-

# @Time    : 2024/4/29 16:00
# @Author  : wangchongshi
# @Email   : wangchongshi.wcs@antgroup.com
# @FileName: peer_agent.py
from agentuniverse.agent.template.peer_agent_template import PeerAgentTemplate


class PeerAgent(PeerAgentTemplate):
    """Peer Agent class."""
