# !/usr/bin/env python3
# -*- coding:utf-8 -*-

# @Time    : 2024/10/17 11:09
# @Author  : wangchongshi
# @Email   : wangchongshi.wcs@antgroup.com
# @FileName: reviewing_agent.py
from agentuniverse.agent.template.reviewing_agent_template import ReviewingAgentTemplate


class ReviewingAgent(ReviewingAgentTemplate):
    """Reviewing Agent module."""
