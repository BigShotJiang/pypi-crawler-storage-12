# !/usr/bin/env python3
# -*- coding:utf-8 -*-

# @Time    : 2024/10/17 21:08
# @Author  : wangchongshi
# @Email   : wangchongshi.wcs@antgroup.com
# @FileName: expressing_agent.py
from agentuniverse.agent.template.expressing_agent_template import ExpressingAgentTemplate


class ExpressingAgent(ExpressingAgentTemplate):
    """Expressing Agent class."""
