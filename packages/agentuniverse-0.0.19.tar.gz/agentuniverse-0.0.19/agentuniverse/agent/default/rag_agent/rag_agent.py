# !/usr/bin/env python3
# -*- coding:utf-8 -*-

# @Time    : 2024/10/25 11:20
# @Author  : wangchongshi
# @Email   : wangchongshi.wcs@antgroup.com
# @FileName: rag_agent.py
from agentuniverse.agent.template.rag_agent_template import RagAgentTemplate


class RagAgent(RagAgentTemplate):
    """Rag Agent class."""
