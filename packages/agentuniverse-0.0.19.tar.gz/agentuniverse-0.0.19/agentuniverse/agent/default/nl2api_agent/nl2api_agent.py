# !/usr/bin/env python3
# -*- coding:utf-8 -*-

# @Time    : 2024/10/25 14:35
# @Author  : wangchongshi
# @Email   : wangchongshi.wcs@antgroup.com
# @FileName: nl2api_agent.py
from agentuniverse.agent.template.nl2api_agent_template import Nl2ApiAgentTemplate


class Nl2ApiAgent(Nl2ApiAgentTemplate):
    """Nl2Api Agent class."""
