# !/usr/bin/env python3
# -*- coding:utf-8 -*-

# @Time    : 2024/5/31 21:22
# @Author  : wangchongshi
# @Email   : wangchongshi.wcs@antgroup.com
# @FileName: react_agent.py
from agentuniverse.agent.template.react_agent_template import ReActAgentTemplate


class ReActAgent(ReActAgentTemplate):
    """ReAct Agent class."""
