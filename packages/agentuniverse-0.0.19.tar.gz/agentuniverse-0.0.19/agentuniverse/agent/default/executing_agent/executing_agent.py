# !/usr/bin/env python3
# -*- coding:utf-8 -*-

# @Time    : 2024/10/17 20:41
# @Author  : wangchongshi
# @Email   : wangchongshi.wcs@antgroup.com
# @FileName: executing_agent.py
from agentuniverse.agent.template.executing_agent_template import ExecutingAgentTemplate


class ExecutingAgent(ExecutingAgentTemplate):
    """Executing Agent class."""
