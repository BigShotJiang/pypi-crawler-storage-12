# !/usr/bin/env python3
# -*- coding:utf-8 -*-

# @Time    : 2024/10/17 21:01
# @Author  : wangchongshi
# @Email   : wangchongshi.wcs@antgroup.com
# @FileName: planning_agent.py
from agentuniverse.agent.template.planning_agent_template import PlanningAgentTemplate


class PlanningAgent(PlanningAgentTemplate):
    """Planning Agent class."""
