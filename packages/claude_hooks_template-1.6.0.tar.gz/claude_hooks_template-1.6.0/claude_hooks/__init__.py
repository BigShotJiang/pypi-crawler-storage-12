"""A simple CLI template for Python projects."""

__version__ = "0.1.0"
