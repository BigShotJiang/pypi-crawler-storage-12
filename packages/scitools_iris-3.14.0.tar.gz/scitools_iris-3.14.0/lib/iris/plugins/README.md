# Iris plugins

`iris.plugins` is a [namespace package] allowing arbitrary plugins to be
installed alongside Iris.

See [the Iris documentation][plugins] for more information.


[namespace package]: https://packaging.python.org/en/latest/guides/packaging-namespace-packages/
[plugins]: https://scitools-iris.readthedocs.io/en/latest/community/plugins.html
