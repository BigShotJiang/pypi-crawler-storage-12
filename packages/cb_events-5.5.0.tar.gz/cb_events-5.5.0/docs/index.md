```{include} ../README.md
```

```{toctree}
:maxdepth: 2
:hidden:

API Reference <api/index>
```
