"""
.. include:: ../../README.md
"""

from ._blob import TensorBlob

__version__ = "0.1.2"

__all__ = [
    "TensorBlob",
]
