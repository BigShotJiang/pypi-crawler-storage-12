# flake8: noqa: F401
from crawler_utils.opensearch.dupefilter import OpenSearchRFPDupeFilter
from crawler_utils.opensearch.items_pipeline import OpenSearchItemsPipeline
from crawler_utils.opensearch.requests_middleware import (
    OpenSearchRequestsDownloaderMiddleware,
)
