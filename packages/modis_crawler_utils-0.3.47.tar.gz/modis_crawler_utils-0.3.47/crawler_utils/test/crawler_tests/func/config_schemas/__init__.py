from .crawler_arguments_schema import CrawlerArgumentsSchema
from .spider_specification_schema import SpidersSpecificationSchema

__all__ = ["CrawlerArgumentsSchema", "SpidersSpecificationSchema"]
