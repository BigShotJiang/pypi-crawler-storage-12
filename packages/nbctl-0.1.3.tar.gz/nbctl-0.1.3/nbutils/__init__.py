"""nbutils - The Swiss Army Knife for Jupyter Notebooks"""

__version__ = "0.1.3"
__author__ = "Venkatachalam Subramanian Periya Subbu"
__email__ = "venkatachalam.sps@gmail.com"
