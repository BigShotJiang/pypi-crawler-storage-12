def main() -> None:
    print("Hello from mcp-fs!")
