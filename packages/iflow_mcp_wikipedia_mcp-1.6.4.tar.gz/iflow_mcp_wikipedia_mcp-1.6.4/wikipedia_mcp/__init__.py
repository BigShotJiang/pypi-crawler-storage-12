"""
Wikipedia MCP Server - A Model Context Protocol server for Wikipedia integration.
"""

__version__ = "1.6.0"
