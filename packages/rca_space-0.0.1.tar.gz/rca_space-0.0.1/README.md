The code responsible for generating the RCA spaces. For more details, refer to the project's GitHub repository: https://github.com/grynova-ccc/Reference-based-Coordinate-Assignment
