"""djangobible python library.

djangobible lets you easily associate Django models with Bible Scripture references and
search accordingly.
"""

from __future__ import annotations

__version__ = "0.3.0"

from pythonbible import *
