# 📦 Публикация SDK в npm

## Подготовка к публикации

### 1. Проверка файлов

Убедитесь, что все файлы на месте:

```
typescript/
├── package.json          ✅
├── README.md             ✅
├── LICENSE               ✅
├── tsconfig.json         ✅
├── src/
│   ├── index.ts          ✅
│   └── client.ts         ✅
└── dist/                 ✅ (создается после сборки)
```

### 2. Обновление версии

Перед каждой публикацией обновите версию в `package.json`:

```json
{
  "version": "0.1.0"  // → "0.1.1" для патча, "0.2.0" для минора, "1.0.0" для мажора
}
```

Также обновите версию в `src/index.ts`:

```typescript
export const VERSION = "0.1.0";
```

---

## Шаг 1: Регистрация на npm

1. Создайте аккаунт на https://www.npmjs.com/signup
2. Подтвердите email
3. Включите двухфакторную аутентификацию (рекомендуется)

---

## Шаг 2: Установка зависимостей

```bash
cd typescript
npm install
```

---

## Шаг 3: Сборка пакета

```bash
npm run build
```

Это создаст папку `dist/` с скомпилированными файлами:
- `index.js` и `index.d.ts` (основной экспорт)
- `client.js` и `client.d.ts` (клиент)
- Source maps для отладки

---

## Шаг 4: Проверка сборки (опционально)

```bash
# Проверка размера пакета
npm pack --dry-run
```

Это покажет, какие файлы будут включены в пакет.

---

## Шаг 5: Вход в npm

```bash
npm login
```

Введите:
- Username: ваш username на npm
- Password: ваш пароль
- Email: ваш email (для публикации)

---

## Шаг 6: Публикация в npm

### Первая публикация:

```bash
npm publish
```

### Обновление версии:

```bash
# Обновите версию в package.json и src/index.ts
npm version patch   # для 0.1.0 → 0.1.1
# или
npm version minor    # для 0.1.0 → 0.2.0
# или
npm version major    # для 0.1.0 → 1.0.0

# Затем опубликуйте
npm publish
```

---

## Шаг 7: Проверка публикации

После публикации (может занять несколько минут):

1. Проверьте страницу пакета:
   - https://www.npmjs.com/package/strayl-logging

2. Установите пакет:

```bash
npm install strayl-logging
```

3. Проверьте работу:

```typescript
import { StraylLogger } from 'strayl-logging';
console.log("✅ SDK установлен и работает!");
```

---

## Обновление версии

При обновлении пакета:

1. Обновите версию в `package.json`
2. Обновите версию в `src/index.ts`
3. Обновите `CHANGELOG.md` (если есть)
4. Соберите заново: `npm run build`
5. Опубликуйте: `npm publish`

Или используйте `npm version`:

```bash
npm version patch && npm publish
```

---

## Безопасность

### npm токены:

- ✅ Храните токены в безопасном месте
- ✅ Не коммитьте `.npmrc` с токенами в Git
- ✅ Используйте двухфакторную аутентификацию
- ✅ Можно использовать `.npmrc` файл (не коммитить!)

### Создание `.npmrc` (опционально):

Создайте файл `~/.npmrc`:

```
//registry.npmjs.org/:_authToken=ваш_токен_здесь
```

Тогда можно просто:
```bash
npm publish
```

---

## Автоматизация через GitHub Actions (опционально)

Можно настроить автоматическую публикацию при создании тега:

```yaml
# .github/workflows/publish.yml
name: Publish to npm

on:
  release:
    types: [created]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          registry-url: 'https://registry.npmjs.org'
      - run: cd typescript && npm install
      - run: cd typescript && npm run build
      - run: cd typescript && npm publish
        env:
          NODE_AUTH_TOKEN: ${{ secrets.NPM_TOKEN }}
```

---

## Чеклист перед публикацией

- [ ] Версия обновлена в `package.json`
- [ ] Версия обновлена в `src/index.ts`
- [ ] README.md актуален
- [ ] LICENSE файл добавлен
- [ ] Код протестирован
- [ ] Сборка успешна (`npm run build`)
- [ ] Проверка `npm pack --dry-run` прошла успешно
- [ ] Вход в npm выполнен (`npm login`)

---

## Полезные ссылки

- **npm**: https://www.npmjs.com
- **npm документация**: https://docs.npmjs.com/
- **TypeScript документация**: https://www.typescriptlang.org/docs/

---

**Готово! После публикации пользователи смогут установить SDK:**

```bash
npm install strayl-logging
```

