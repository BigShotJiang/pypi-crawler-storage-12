# 🚀 Быстрая публикация в npm

## За 5 минут

### 1. Установите зависимости

```bash
cd typescript
npm install
```

### 2. Соберите пакет

```bash
npm run build
```

### 3. Создайте аккаунт на npm

1. Зарегистрируйтесь: https://www.npmjs.com/signup
2. Подтвердите email

### 4. Войдите в npm

```bash
npm login
```

### 5. Опубликуйте

```bash
npm publish
```

### 6. Готово!

Теперь все могут установить:

```bash
npm install strayl-logging
```

---

📖 **Подробная инструкция:** см. `PUBLISH.md`

