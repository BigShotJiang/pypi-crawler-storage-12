# 🚀 Быстрая публикация в PyPI

## За 5 минут

### 1. Установите инструменты

```bash
pip install build twine
```

### 2. Соберите пакет

```bash
cd SDK/strayl_logging
python -m build
```

### 3. Создайте аккаунт на PyPI

1. Зарегистрируйтесь: https://pypi.org/account/register/
2. Создайте API токен: https://pypi.org/manage/account/token/
3. Скопируйте токен (начинается с `pypi-`)

### 4. Опубликуйте

```bash
python -m twine upload dist/*
```

Введите:
- Username: `__token__`
- Password: ваш токен

### 5. Готово! 

Теперь все могут установить:

```bash
pip install strayl-logging
```

---

📖 **Подробная инструкция:** см. `PUBLISH.md`

