"""
Strayl Logging SDK для Python.

Минималистичный SDK для отправки логов в Strayl Cortyx через API ключи.
"""

from .client import StraylLogger

__all__ = ["StraylLogger"]
__version__ = "0.2.0"

