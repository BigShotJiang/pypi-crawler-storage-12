from perf_sentinel.decorators.timing import perf_timing

__all__ = ['perf_timing']
