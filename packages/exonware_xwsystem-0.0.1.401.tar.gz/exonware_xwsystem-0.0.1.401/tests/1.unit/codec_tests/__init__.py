"""
#exonware/xwsystem/tests/1.unit/codec_tests/__init__.py

Unit tests for codec module.

Company: eXonware.com
Author: Eng. Muhammad AlShehri
Email: connect@exonware.com
Version: 0.0.1
Generation Date: 04-Nov-2025
"""

