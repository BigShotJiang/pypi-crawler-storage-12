"""Unit tests for io.codec sub-package."""

