#exonware/xwsystem/tests/core/runtime/__init__.py
"""
Runtime Core Tests Package

Tests for XSystem runtime utilities including environment management,
reflection, and runtime operations.
"""
