"""Core tests for xwsystem caching module."""
