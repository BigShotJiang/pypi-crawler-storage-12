#!/usr/bin/env -S uv run ipython -i
# isort: off
import ipython_playground

ipython_playground.output()
