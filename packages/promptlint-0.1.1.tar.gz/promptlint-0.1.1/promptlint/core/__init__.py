"""Core modules for prompt parsing and analysis."""
