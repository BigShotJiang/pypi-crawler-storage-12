"""Output reporters for different formats."""
