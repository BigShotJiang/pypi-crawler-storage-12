"""Analyzers for different prompt dimensions."""
