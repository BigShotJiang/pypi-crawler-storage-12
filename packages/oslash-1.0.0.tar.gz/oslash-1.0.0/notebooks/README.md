Here are some [IPython](http://ipython.org) notebooks. You can view them
using [NBViewer](http://nbviewer.ipython.org):

* [The Reader Monad](http://nbviewer.ipython.org/github/dbrattli/OSlash/blob/master/notebooks/Reader.ipynb)
