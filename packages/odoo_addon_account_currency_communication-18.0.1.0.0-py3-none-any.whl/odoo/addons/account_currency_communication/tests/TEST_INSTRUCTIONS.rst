Setup:

- Install module account_currency_communication.

Use:

- Go To *Invoicing > Communication > Currencies*.
- Enable and edit the EUR currency.
- Set the *Communication Standard* to "European".
- Create invoice for "Deco Addict" with EUR currency.
- Confirm the invoice.
- Check if correct communication standard is used.
