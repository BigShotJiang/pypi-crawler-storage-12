class Legacy:
    LEGACY_DATABASE = "database"
