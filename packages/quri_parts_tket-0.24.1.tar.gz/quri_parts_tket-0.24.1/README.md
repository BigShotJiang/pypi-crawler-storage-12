# QURI Parts tket

QURI Parts tket is a support library for using tket with QURI Parts.
You can combine your code written in QURI Parts with this library to execute it on tket.

## Documentation

[QURI Parts Documentation](https://quri-parts.qunasys.com)

## Installation

```
pip install quri-parts-tket
```

## License

Apache License 2.0
