#!/usr/bin/env python3
from niemarkov.niemarkov import MarkovChain, random_choice
__all__ = ['MarkovChain', 'random_choice']
