from sfctools import Agent

def gen_class(name):
    """
    Dummy sfctools class generator
    returns an sfctoosl agent class with given name
    """
    
    class MyClass(Agent):
        def __init__(self):
            super().__init__()
        def file_bankruptcy(self, event):
            pass # no bankruptcy mechanism in sfctools
    MyClass.__name__ = name
    return MyClass
