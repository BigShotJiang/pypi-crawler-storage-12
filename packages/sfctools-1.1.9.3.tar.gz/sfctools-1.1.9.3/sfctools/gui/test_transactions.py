
# (depricated code as of 08/2025) 

# from __future__ import annotations
# from sfctools import Agent, FlowMatrix 
# import numpy as np
# from sfctools import BalanceEntry,Accounts
# from sfctools import CashFlowEntry
# from sfctools import ICSEntry
# from sfctools import Clock
# CA = Accounts.CA
# KA = Accounts.KA

# def test(A: Agent, B: Agent, C: Agent, x: float):
# 	'''
	
# 	'''
# 	t=Clock().get_time()
# 	cond = (isinstance(x, float) or isinstance(x, int))
# 	if cond: assert not np.isnan(x)
# 	if cond: assert x < +np.inf
# 	if cond: assert x > -np.inf
# 	if cond: assert x >= 0, 'have to pass positive quantity: unidirectional transaction'
# 	A.balance_sheet.disengage()
# 	B.balance_sheet.disengage()
# 	A.bal.change_item('v', BalanceEntry.EQUITY, -x, suppress_stock=False)
# 	B.bal.change_item('v', BalanceEntry.EQUITY, +x, suppress_stock=False)
# 	A.bal.change_item('Deposits', BalanceEntry.ASSETS, -x, suppress_stock=False)
# 	B.bal.change_item('Other', BalanceEntry.ASSETS, +x, suppress_stock=False)
# 	C.bal.change_item('Other', BalanceEntry.ASSETS, -x, suppress_stock=False)
# 	C.bal.change_item('Deposits', BalanceEntry.LIABILITIES, -x, suppress_stock=True)
# 	A.balance_sheet.engage()
# 	B.balance_sheet.engage()
# 	FlowMatrix().log_flow((CA,CA), x, A, B, subject='Transfer test')
	


