
"""
This is the example from the JOSS paper publication.

__author__ Thomas Baldauf, DLR-VE
__date__ March 2023
"""
