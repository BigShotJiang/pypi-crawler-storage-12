"""
SFCTOOLS core features
----------------------
- agent.py
- balance_matrix.py
- clock.py
- flow_matrix.py
- settings.py
- world.py
"""
