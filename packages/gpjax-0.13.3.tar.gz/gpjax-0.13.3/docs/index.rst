.. raw:: html

    <script type="text/javascript">
        window.location.replace('https://docs.jaxgaussianprocesses.com/');
    </script>
