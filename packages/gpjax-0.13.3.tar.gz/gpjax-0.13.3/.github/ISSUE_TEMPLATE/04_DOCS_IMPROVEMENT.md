---
name: Documentation improvement
about: Suggest an area of documentation that could be improved
title: "docs: "
labels: "documentation"
assignees: ""
---
