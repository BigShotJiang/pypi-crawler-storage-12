from gpjax.kernels.approximations.rff import RFF

__all__ = ["RFF"]
