"""Module entry point for `python -m db_backup`"""
from .main import backup_cli

if __name__ == "__main__":
    backup_cli()
