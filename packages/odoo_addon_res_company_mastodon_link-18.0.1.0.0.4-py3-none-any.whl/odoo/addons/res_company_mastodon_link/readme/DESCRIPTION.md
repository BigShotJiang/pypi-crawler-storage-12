This module adds a new "Mastodon URL" field, at company level.

![res_company_form](../static/description/res_company_form.png)

Mastodon is a decentralized social network developed in Open Source.
More information at <https://joinmastodon.org/>.
