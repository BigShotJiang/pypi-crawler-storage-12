BASE_URL = "https://report.salonbookly.com"  # URL report service
TIMEOUT = 30  # Default Timeout
