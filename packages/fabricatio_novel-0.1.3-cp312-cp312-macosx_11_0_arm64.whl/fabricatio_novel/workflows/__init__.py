"""Workflows defined in fabricatio-novel."""
