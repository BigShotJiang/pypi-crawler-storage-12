from . import test_purchase_analytic_global
