from opsdevnz.octodns_hooks import *  # noqa: F401,F403
