******************************************
## Welcome to `ibm-watsonx-ai`
******************************************

``ibm-watsonx-ai`` is a library that allows to work with watsonx.ai service on [IBM Cloud](https://console.bluemix.net/catalog/services/machine-learning) and
IBM Cloud for Data. Train, test and deploy your models as APIs for application development, share with colleagues using this python library.

### [Package documentation](https://ibm.github.io/watsonx-ai-python-sdk)
==========================================
