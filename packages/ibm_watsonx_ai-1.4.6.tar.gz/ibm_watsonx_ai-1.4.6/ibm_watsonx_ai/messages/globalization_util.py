#  -----------------------------------------------------------------------------------------
#  (C) Copyright IBM Corp. 2023-2025.
#  https://opensource.org/licenses/BSD-3-Clause
#  -----------------------------------------------------------------------------------------


class GlobalizationUtil:
    @staticmethod
    def get_language():
        language = "en"
        return language
