"""Internal S3 wrapper implementation - not part of public API."""
