def main():
    return "Hello from langflow!"


if __name__ == "__main__":
    main()
