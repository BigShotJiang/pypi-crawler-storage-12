from typing import Any

from pydantic import BaseModel


class UserData(BaseModel):
    data: dict[str, Any] = {}
    state: str

    class Config:
        arbitrary_types_allowed = True


class USERDB:
    def __init__(self) -> None:
        self.db: dict[int, UserData] = {}

    def get_user(self, chat_id: int, init_state: str) -> UserData:
        try:
            return self.db[chat_id]
        except KeyError:
            user_data = UserData(data={}, state=init_state)
            self.db[chat_id] = user_data
            return user_data
