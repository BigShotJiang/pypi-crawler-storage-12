name = "yapper-tts"
version = "0.7.0"
github = f"https://github.com/n1teshy/{name}"
