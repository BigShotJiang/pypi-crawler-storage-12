"""PHX Loads (Ventilation, Lighting, Electric Equipment, Water."""
