#exonware/xwsystem/tests/core/cli/__init__.py
"""
CLI Core Tests Package

Tests for XSystem CLI functionality including console operations,
progress tracking, prompts, and table formatting.
"""
