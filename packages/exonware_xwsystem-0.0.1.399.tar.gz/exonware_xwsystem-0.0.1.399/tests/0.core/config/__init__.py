#exonware/xwsystem/tests/core/config/__init__.py
"""
Config Core Tests Package

Tests for XSystem configuration management including defaults,
performance modes, and logging setup.
"""
