#exonware/xwsystem/tests/core/structures/__init__.py
"""
Structures Core Tests Package

Tests for XSystem data structures including circular detection,
tree walking, and structure management.
"""
