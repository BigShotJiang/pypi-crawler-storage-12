#exonware/xwsystem/tests/core/ipc/__init__.py
"""
IPC Core Tests Package

Tests for XSystem inter-process communication including message queues,
pipes, process management, and shared memory.
"""
