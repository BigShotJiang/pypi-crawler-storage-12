from secrets_safe_library.constants.versions import Version

__all__ = ["Version"]
