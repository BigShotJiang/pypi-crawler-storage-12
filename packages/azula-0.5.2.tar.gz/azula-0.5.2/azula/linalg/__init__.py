r"""Linear algebra."""

from .solve import cg, gmres  # noqa: F401
