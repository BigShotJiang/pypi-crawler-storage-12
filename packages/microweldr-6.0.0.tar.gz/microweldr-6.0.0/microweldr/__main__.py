"""Main entry point for MicroWeldr package."""

from .cli.simple_main import main

if __name__ == "__main__":
    main()
