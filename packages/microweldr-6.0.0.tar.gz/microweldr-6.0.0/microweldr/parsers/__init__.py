"""File parsers for SVG and DXF input files."""
