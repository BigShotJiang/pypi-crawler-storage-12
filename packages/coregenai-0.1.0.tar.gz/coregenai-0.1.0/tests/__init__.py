"""Test suite for CoreGenAI."""
