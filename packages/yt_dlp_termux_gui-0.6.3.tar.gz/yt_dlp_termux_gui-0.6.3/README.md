# yt-dlp-termux-gui

Simple yet useful Termux GUI for [yt-dlp](https://github.com/yt-dlp/yt-dlp).

**Requires Python 3.8+**

## Tools

### Terminal

- [Termux](https://termux.dev)
  - [Termux:Widget Plugin](https://github.com/termux/termux-widget)
  - [Termux:GUI Plugin](https://github.com/termux/termux-gui)

### CLI

- [yt-dlp](https://github.com/yt-dlp/yt-dlp)
- [termux-api](https://github.com/termux/termux-api)
- [termuxgui](https://github.com/tareksander/termux-gui-python-bindings)

### Modules

- [curl_cffi](https://github.com/lexiforest/curl_cffi)
- [curl-impersonate-android](https://github.com/T0chi/curl-impersonate-android)

## How to use

```bash
Usage: yt-dlp-termux-gui [OPTIONS...] [COMMAND]

Commands:
deps --> Ensure dependencies (install missing packages)
launch --> Launch the GUI
widget --> Ensure Termux:Widget shortcut for the GUI

Options:
--verbose <silent|debug|info|warning|error|critical> --> Set logging level
--silent --> Disable ALL GUI logs in Termux
--widget-name --> Print widget name
--widget-script-name --> Print widget script filename
--settings --> Print current settings
--settings-path --> Print settings path
--settings-reset --> Reset settings
-h, --help --> Show this help message
-v, -V, --version --> Print version

Options [deps]:
--force --> Overwrite 'curl-impersonate' compiled binaries if they already exist

Options [launch]:
--no-activity-logs --> Disable GUI activity logs in Termux
--init-logs --> Enable GUI initialization logs in Termux by the GUI
```
