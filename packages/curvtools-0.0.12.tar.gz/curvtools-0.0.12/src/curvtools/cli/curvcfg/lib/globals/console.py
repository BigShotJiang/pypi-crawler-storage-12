from rich import console

# for pretty display
console = console.Console()