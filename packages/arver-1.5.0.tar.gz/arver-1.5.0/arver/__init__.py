"""Main ARver package."""

APPNAME = 'ARver'
VERSION = 'v1.5.0'
URL = 'https://github.com/arcctgx/ARver'
