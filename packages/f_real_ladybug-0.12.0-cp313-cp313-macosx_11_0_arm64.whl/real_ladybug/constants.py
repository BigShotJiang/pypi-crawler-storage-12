# Should be consistent with common/constants.h
ID = "_ID"
LABEL = "_LABEL"
SRC = "_SRC"
DST = "_DST"
NODES = "_NODES"
RELS = "_RELS"
