# Sampling

::: ls_mcmc.sampling