# Model

::: ls_mcmc.model