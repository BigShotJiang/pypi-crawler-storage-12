from .node_icon import icons

print("Available icons:")
print(*icons.keys(), sep=", ")
