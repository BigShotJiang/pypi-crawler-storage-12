This directory includes a chaos and load testing suite that can verify `docket` under
more real-world conditions.

This test suite should have a mode that can run in under a minute or two for use in CI,
but longer tests for performance are totally fine. Everything should be self-contained,
reproducible, and verifiable.
