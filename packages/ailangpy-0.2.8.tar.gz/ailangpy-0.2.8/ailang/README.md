# The Ai Programming Langauge

Documentation very much TODO
