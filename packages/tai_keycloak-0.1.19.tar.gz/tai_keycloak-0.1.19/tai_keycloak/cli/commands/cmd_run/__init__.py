"""Comando run para iniciar Keycloak"""
from .main import run
