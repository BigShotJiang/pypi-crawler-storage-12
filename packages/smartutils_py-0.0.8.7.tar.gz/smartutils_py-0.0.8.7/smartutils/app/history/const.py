from enum import Enum


class OpType(int, Enum):
    ADD = 1
    DEL = 2
    UPDATE = 3
