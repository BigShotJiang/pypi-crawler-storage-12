from smartutils.init.main import init, release, reset_all  # noqa: F401

__all__ = ["init", "release"]
