# from smartutils.config.const import ConfKey
# from smartutils.config.factory import ConfFactory
# from smartutils.config.schema.host import HostConf
#
# __all__ = ["OpenTelemetryConf"]
#
#
# @ConfFactory.register(ConfKey.OPEN_TELEMETRY, require=False)
# class OpenTelemetryConf(HostConf):
#     ...
