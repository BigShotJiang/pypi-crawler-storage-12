__project__ = "cas_sdss_mcp"  # Replace package_name with actual name (it's just a template).

try:
    from ._version import __version__
except ImportError:
    __version__ = ""
