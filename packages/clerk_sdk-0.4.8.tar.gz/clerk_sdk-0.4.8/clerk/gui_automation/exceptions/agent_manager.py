class NoClientsAvailable(Exception):
    pass


class ClientAvailabilityTimeout(Exception):
    pass
