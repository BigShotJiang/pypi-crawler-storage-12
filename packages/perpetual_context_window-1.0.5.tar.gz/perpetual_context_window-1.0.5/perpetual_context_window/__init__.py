# Module developed by Sapiens Technology® for building language model algorithms with a perpetual context window without complete forgetting of initial, intermediate, and final information.
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from .perpetual_context_window import *
# Module developed by Sapiens Technology® for building language model algorithms with a perpetual context window without complete forgetting of initial, intermediate, and final information.
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
