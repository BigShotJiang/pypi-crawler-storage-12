# -*- coding: utf-8 -*-

from pathlib import Path
import os

CELLORACLE_DATA_DIR = os.path.join(str(Path.home()), "celloracle_data")
WEB_PAR_DIR = "https://raw.githubusercontent.com/morris-lab/CellOracle/master/celloracle/data"
