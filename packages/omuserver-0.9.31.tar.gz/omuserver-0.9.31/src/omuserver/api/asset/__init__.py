from .extension import AssetExtension

__all__ = [
    "AssetExtension",
]
