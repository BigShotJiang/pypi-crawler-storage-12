É apenas necessário a instalação e configuração do módulo l10n_br_nfse.
