RECEPCIONAR_LOTE_RPS = ["RecepcionarLoteRpsV3", "RecepcionarLoteRps"]

CONSULTAR_SITUACAO_LOTE_RPS = ["ConsultarSituacaoLoteRpsV3", "ConsultarSituacaoLoteRps"]

CANCELAR_NFSE = (
    [
        "CancelarNfseV3",
        "CancelarNfse",
    ],
)

CONSULTAR_NFSE_POR_RPS = (
    [
        "ConsultarNfsePorRpsV3",
        "ConsultarNfsePorRps",
    ],
)
