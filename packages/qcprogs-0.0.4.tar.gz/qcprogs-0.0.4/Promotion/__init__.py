"""
promotionflow package
"""
from .__main__ import UI_app ,main_app
__version__ = "0.1.0"

__all__ = ["UI_app", "main_app"]