class BatchItemException(Exception):
    """Raised when batched operations receive invalid input."""
