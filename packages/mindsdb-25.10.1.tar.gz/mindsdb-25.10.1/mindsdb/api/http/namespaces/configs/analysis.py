from flask_restx import Namespace

ns_conf = Namespace('analysis', description='Dataset analysis')
