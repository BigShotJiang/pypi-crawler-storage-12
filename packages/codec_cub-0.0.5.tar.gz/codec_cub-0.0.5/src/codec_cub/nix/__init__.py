"""A codec for Nix files."""
