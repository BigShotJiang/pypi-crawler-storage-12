from django.apps import AppConfig


class DjangoInscodeConfig(AppConfig):
    name = "django_inscode"
    verbose_name = "Django Inscode"
