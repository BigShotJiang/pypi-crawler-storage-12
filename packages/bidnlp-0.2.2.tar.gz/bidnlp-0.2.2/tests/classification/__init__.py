"""
Tests for classification module
"""
