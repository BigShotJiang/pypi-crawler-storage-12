"""Tests for POS tagging module."""
