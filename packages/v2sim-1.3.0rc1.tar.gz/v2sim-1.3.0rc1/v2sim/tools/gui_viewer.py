from v2sim.gui.viewerbox import *

if __name__ == "__main__":
    app = ViewerBox()
    app.mainloop()