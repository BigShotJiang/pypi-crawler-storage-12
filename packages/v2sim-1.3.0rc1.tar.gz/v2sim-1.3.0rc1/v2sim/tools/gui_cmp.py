from v2sim.gui.cmpbox import CmpBox

    
if __name__ == "__main__":
    app = CmpBox()
    app.mainloop()