from v2sim.osmhelper import main, get_options

def entry():
    main(get_options())

if __name__ == "__main__":
    entry()