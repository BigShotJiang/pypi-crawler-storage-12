from .scandir_rs import *

__doc__ = scandir_rs.__doc__
if hasattr(scandir_rs, "__all__"):
    __all__ = scandir_rs.__all__