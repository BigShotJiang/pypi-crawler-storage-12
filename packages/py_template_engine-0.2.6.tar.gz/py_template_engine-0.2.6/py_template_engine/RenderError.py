class RenderError(Exception):
    pass
