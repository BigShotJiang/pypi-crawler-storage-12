======================
Other Useful Resources
======================

* Mock_ library documentation
* OpenStack Bootstrapping Hour: Mock Best Practices: `video
  <https://www.youtube.com/watch?v=jCWtLoSEfmw>`__ and `etherpad
  <https://etherpad.openstack.org/p/obh-mock-best-practices>`__

.. _Mock: http://www.voidspace.org.uk/python/mock/
