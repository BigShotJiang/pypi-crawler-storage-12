=======
Testing
=======

oslotest can be tested via ``tox``, like any other OpenStack project:

.. code-block:: shell

    tox -e py3
