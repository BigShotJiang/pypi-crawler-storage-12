from typing import ParamSpec, TypeVar

P = ParamSpec("P")
TResult = TypeVar("TResult")
