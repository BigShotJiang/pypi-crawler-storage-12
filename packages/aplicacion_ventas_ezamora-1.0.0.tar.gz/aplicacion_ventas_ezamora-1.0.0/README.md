# Aplicacion de Ventas
Este Paquete proporciona funcionalidades para gestionar ventas, incluyendo cálculos de precios,
impuestos y descuentos

## Instalación

Puedes Instalar el Paquete usando:

'''bash

pip install .
"