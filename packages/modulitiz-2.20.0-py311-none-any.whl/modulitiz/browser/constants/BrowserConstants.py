class BrowserConstants(object):
	"""
	Valori costanti vari
	"""
	NEVER_ASK_SAVE_FILES="application/octet-stream, application/binary, application/csv, application/excel, application/xml, text/plain, text/html, text/csv, text/comma-separated-values, text/xml"
