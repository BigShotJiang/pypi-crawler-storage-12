from nado_protocol.utils.backend import NadoClientOpts


class TriggerClientOpts(NadoClientOpts):
    """
    Model defining the configuration options for the Trigger Client.
    """
