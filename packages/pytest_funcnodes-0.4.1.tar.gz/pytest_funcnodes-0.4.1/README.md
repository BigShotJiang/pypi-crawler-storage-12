pytest package for funcnodes
