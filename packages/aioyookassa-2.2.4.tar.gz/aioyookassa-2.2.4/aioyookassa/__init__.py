from .core import YooKassa

__version__ = "2.2.4"

__all__ = ["__version__", "YooKassa"]
