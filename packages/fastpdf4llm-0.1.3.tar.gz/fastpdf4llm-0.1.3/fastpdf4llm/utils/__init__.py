"""Utility functions for PDF processing."""
