"""Data models for PDF processing."""
