# moai-lang-php - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **PHP**: 8.4.0
- **PHPUnit**: 11.5.0
- **Composer**: 2.8.0

---

_For detailed usage, see SKILL.md_
