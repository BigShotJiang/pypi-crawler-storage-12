from .fn import FnWithKwargs
from .parser import ConfigParser

__all__ = (
    "ConfigParser",
    "FnWithKwargs",
)
