# mestDS - Data simulation tool for model evaluation and stress testing

mestDS started as a small pilot project to familiarize with simulation of climate health data. August 2024, mestDS was uploaded to PiPy, and marks the start of this open source.
