# pythonbible-akjv

The American King James Version (AKJV) of the Bible in Python. For use with the `pythonbible` library.
