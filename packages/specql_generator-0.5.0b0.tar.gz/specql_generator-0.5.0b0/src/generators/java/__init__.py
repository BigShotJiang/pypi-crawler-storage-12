"""Java code generators for Spring Boot applications"""
