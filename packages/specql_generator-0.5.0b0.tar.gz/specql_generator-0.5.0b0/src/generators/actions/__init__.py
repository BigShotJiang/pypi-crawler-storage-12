"""
Action Compiler - Transform SpecQL actions to PL/pgSQL functions
"""
