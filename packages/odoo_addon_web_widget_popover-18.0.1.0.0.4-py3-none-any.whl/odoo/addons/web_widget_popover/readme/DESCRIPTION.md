The field will be rendered as a simple icon, that when hovered will display the field content as a tooltip.
