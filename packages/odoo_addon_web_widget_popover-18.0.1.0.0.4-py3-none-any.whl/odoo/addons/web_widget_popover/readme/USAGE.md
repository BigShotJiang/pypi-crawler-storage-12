Use the `popover` widget on `Char` or `Text` fields.

```xml
<field
    name="warning_message"
    widget="popover"
    icon="fa-warning"
    class="text-danger"
    nolabel="1"
/>
```
