from PySide6.QtWidgets import QScrollArea


class TransparentScrollArea(QScrollArea):
    pass
