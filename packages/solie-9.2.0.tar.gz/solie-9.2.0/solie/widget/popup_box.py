from PySide6.QtWidgets import QGroupBox


class PopupBox(QGroupBox):
    pass
