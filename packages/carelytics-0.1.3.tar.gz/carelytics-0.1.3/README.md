# Carelytics – Healthcare Data Analytics Library

*A modular Python package for healthcare data cleaning, validation, and revenue cycle insights.*

---

## Overview

**Carelytics** is a Python library designed to simplify **data analytics and automation in the healthcare domain**, especially focusing on **Revenue Cycle Management (RCM)** workflows.

It provides functions to:

* Validate and clean large healthcare datasets
* Analyze patient encounters, lab data, and vitals
* Standardize formats for interoperability (FHIR-ready)
* Support predictive modeling such as readmission and denial prediction

Built with **Pandas**, **NumPy**, and **Scikit-learn**, Carelytics empowers analysts, researchers, and developers to derive actionable insights from healthcare data quickly and efficiently.

---

## Package Architecture

```
carelytics/
│
├── data/                     # (Placeholder for sample data or CSVs)
│
├── fhir/                     # Handles healthcare interoperability (FHIR parsing)
│   ├── parser.py
│   └── validator.py
│
├── models/                   # Predictive models for healthcare analytics
│   ├── denial_prediction.py
│   └── readmission.py
│
├── utils/                    # Utility functions for data processing
│   ├── __init__.py
│   ├── cleaner.py
│   ├── deid.py               # De-identification utilities for PHI data
│   ├── validator.py          # Schema and datatype validation
│   └── __init__.py
│
├── claims.py                 # Claim-level metrics and KPIs
├── encounter.py              # Patient encounter analytics
├── lab.py                    # Lab result standardization
├── patient.py                # Patient-level summaries
└── vitals.py                 # Vital signs normalization and aggregation
```

Each module is reusable and can be independently imported.

---

## ⚙️ Core Functionalities

### 1. `carelytics.utils.validator`

Provides schema and datatype validation for healthcare datasets.

Example:

```python
from carelytics.utils.validator import validate_columns, validate_datatypes

validate_columns(df, ["patient_id", "age", "diagnosis"])
validate_datatypes(df, {"age": "int64", "diagnosis": "object"})
```

Output:

```
all required columns validated.
Column data types validated successfully.
```

---

### 2. `carelytics.utils.cleaner`

Includes data cleaning utilities like missing value handling, standardization, and column renaming.

```python
from carelytics.utils.cleaner import fill_missing

df = fill_missing(df, strategy="median")
```

---

### 3. `carelytics.models.denial_prediction`

Predicts claim denial probabilities based on payer data, CPT/ICD codes, and historical denials.

```python
from carelytics.models.denial_prediction import predict_denials
pred = predict_denials(df)
print(pred.head())
```

---

### 4. `carelytics.models.readmission`

Predicts hospital readmission likelihood using patient demographics and vitals.

---

### 5. `carelytics.claims`

Analyzes RCM claim metrics such as:

* Average AR days
* Net collection rate
* Denial rates

---

### 6. `carelytics.lab` & `carelytics.vitals`

Helps in normalizing patient lab values and vitals for statistical analysis.

---

### 7. `carelytics.utils.deid`

Supports data anonymization to remove or mask PHI (Protected Health Information) before analysis.

---

## Example Workflow

```python
import pandas as pd
from carelytics.utils import validator, cleaner
from carelytics.models import denial_prediction

# Load your healthcare dataset
df = pd.read_csv("claims.csv")

# Validate structure
validator.validate_columns(df, ["claim_id", "payer", "amount", "denial_flag"])

# Clean and prepare
df = cleaner.fill_missing(df, "median")

# Run prediction
pred = denial_prediction.predict_denials(df)
print(pred.head())
```

---

## Key Use Cases

| Use Case                 | Description                                              |
| ------------------------ | -------------------------------------------------------- |
| Hospital Analytics    | Clean and validate EHR data for performance dashboards   |
| RCM Optimization      | Predict denials, track collection efficiency             |
| Clinical Research     | Analyze patient lab results and vitals                   |
| Data Interoperability | FHIR parser ensures standard formats for sharing         |
| PHI Handling          | Built-in data de-identification ensures HIPAA compliance |

---

## Dependencies

* Python ≥ 3.7
* pandas
* numpy
* scikit-learn

Install all dependencies with:

```bash
pip install carelytics
```

---
## Authors & Contributors

Rohan Desai
Dallas, Texas, USA
Email: rohan.acme@gmail.com
GitHub: https://github.com/rohan-desai
LinkedIn: https://www.linkedin.com/in/rohandesai07/

Vaishnavi Sanjay Gadve
Irving, Texas, USA
Email: vaishnavigadve143@gmail.com
GitHub: https://github.com/vaish2412
LinkedIn: https://www.linkedin.com/in/vaishnavi-gadve-4b577512a/

---

##  License

MIT License
© 2025 Rohan Desai & Vaishnavi Sanjay Gadve