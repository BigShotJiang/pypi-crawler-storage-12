# Changelog

## 1.0.0 (2025-11-13)

Full Changelog: [v0.0.1...v1.0.0](https://github.com/avm-codes/sandbox-sdk-python/compare/v0.0.1...v1.0.0)

### Chores

* configure new SDK language ([ae1bc06](https://github.com/avm-codes/sandbox-sdk-python/commit/ae1bc06d0c6274651a194a434ae0240467dfc22a))
* update SDK settings ([50385a7](https://github.com/avm-codes/sandbox-sdk-python/commit/50385a71a857af075188c76f4363ef8c880f3b65))
* update SDK settings ([cde1082](https://github.com/avm-codes/sandbox-sdk-python/commit/cde108200bbc0424a6e7acc1d1217f3f5d613a7a))
