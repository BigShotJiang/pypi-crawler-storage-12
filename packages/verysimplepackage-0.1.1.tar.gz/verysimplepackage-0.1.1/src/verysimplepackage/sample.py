def printei(x: str) -> None:
    return(f"Printei de novo!: {x}")
