"""
valorant models.

Typings for the Valorant API
:copyright: (c) 2023-present STACiA
:license: MIT, see LICENSE for more details.
"""
