"""Unit tests for Jira MCP Server."""
