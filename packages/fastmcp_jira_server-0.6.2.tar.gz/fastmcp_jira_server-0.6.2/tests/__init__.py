"""Test suite for Jira MCP Server."""
