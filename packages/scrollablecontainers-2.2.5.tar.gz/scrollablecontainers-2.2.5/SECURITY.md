# Security Policy
Open an issue if you find any vulnerability. Can't be sure that I'll be able to fix it (since I work on this in my free
time, if any), but will definitely take a look.
