These are illustrative examples meant to show how the classes can be used. An actual GUI program could be structured
differently.
