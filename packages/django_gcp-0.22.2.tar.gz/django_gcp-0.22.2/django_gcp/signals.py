import logging

logger = logging.getLogger(__name__)


def register_signal_handlers():
    """Example of how to hook up signal handlers (from django rabid armadillo)"""
