"""Tests for hooks module."""

import json
import subprocess
from pathlib import Path
import pytest
from realign import hooks


def test_helper_finds_latest_session(git_repo, sample_session, monkeypatch):
    """Test that helper finds and processes the latest session."""
    # Set up environment
    monkeypatch.setenv("REALIGN_LOCAL_HISTORY_PATH", str(sample_session.parent))
    monkeypatch.chdir(git_repo)  # Change to git repo directory

    # Test process_sessions function directly
    result = hooks.process_sessions(pre_commit_mode=False)

    assert "summary" in result
    assert "session_relpaths" in result
    assert "redacted" in result
    # Note: summary might be empty if no sessions found, which is ok
    assert isinstance(result["session_relpaths"], list)


def test_helper_simple_summarize():
    """Test simple summarize function."""

    # Create raw content string (not a list)
    content = """{"role": "user", "content": "What is Python?"}
{"role": "assistant", "content": "Python is a high-level programming language."}
{"role": "user", "content": "Tell me more"}
{"role": "assistant", "content": "Python is known for its simple syntax and readability."}"""

    summary = hooks.simple_summarize(content, max_chars=200)
    assert len(summary) > 0
    assert len(summary) <= 200
    assert "Python" in summary or "user" in summary.lower()


def test_helper_no_session_graceful_fail(git_repo, temp_dir, monkeypatch):
    """Test that helper fails gracefully when no session is found."""
    # Set up environment with empty history dir
    empty_dir = temp_dir / "empty_histories"
    empty_dir.mkdir()
    monkeypatch.setenv("REALIGN_LOCAL_HISTORY_PATH", str(empty_dir))

    # Test process_sessions function directly
    result = hooks.process_sessions(pre_commit_mode=False)

    # Should succeed with empty result (not block commit)
    assert result["summary"] == ""
    assert result["session_relpaths"] == []


def test_helper_explicit_session_path(git_repo, sample_session):
    """Test helper with explicit session path."""
    # Test with explicit session path
    result = hooks.process_sessions(
        pre_commit_mode=False,
        session_path=str(sample_session)
    )

    assert len(result["summary"]) > 0
    assert "binary search" in result["summary"].lower() or "python" in result["summary"].lower()


def test_helper_creates_session_copy(git_repo, sample_session, monkeypatch):
    """Test that helper copies session to repo."""
    monkeypatch.setenv("REALIGN_LOCAL_HISTORY_PATH", str(sample_session.parent))
    monkeypatch.chdir(git_repo)  # Change to git repo directory

    # Initialize .realign directory
    realign_dir = git_repo / ".realign" / "sessions"
    realign_dir.mkdir(parents=True)

    # Run process_sessions
    result = hooks.process_sessions(pre_commit_mode=False)

    # Verify session was copied
    assert len(result["session_relpaths"]) > 0
    session_path = git_repo / result["session_relpaths"][0]
    assert session_path.exists()
    assert session_path.stat().st_size > 0

    # Verify content matches
    original_content = sample_session.read_text()
    copied_content = session_path.read_text()
    assert original_content == copied_content


def test_get_new_content_from_git_diff(git_repo, temp_dir):
    """Test that get_new_content_from_git_diff extracts only new content."""

    # Create a session file with initial content
    sessions_dir = git_repo / ".realign" / "sessions"
    sessions_dir.mkdir(parents=True)
    session_file = sessions_dir / "test_session.jsonl"

    initial_content = """{"role": "user", "content": "What is Python?"}
{"role": "assistant", "content": "Python is a programming language."}
"""
    session_file.write_text(initial_content)

    # Add and commit the initial session
    subprocess.run(["git", "add", str(session_file)], cwd=git_repo, check=True)
    subprocess.run(
        ["git", "commit", "-m", "Initial session", "--no-verify"],
        cwd=git_repo,
        check=True,
    )

    # Add new messages to the session
    new_lines = """{"role": "user", "content": "Tell me more"}
{"role": "assistant", "content": "Python is versatile and easy to learn."}
"""
    new_content = initial_content + new_lines
    session_file.write_text(new_content)

    # Extract new content
    session_relpath = ".realign/sessions/test_session.jsonl"
    new_content_result = hooks.get_new_content_from_git_diff(git_repo, session_relpath)

    # Should only get the 2 new lines
    assert "Tell me more" in new_content_result
    assert "versatile" in new_content_result
    # Should NOT include the old content
    assert new_content_result.count("What is Python?") == 0


def test_summary_only_new_content(git_repo, temp_dir):
    """Test that summary generation only processes new content."""

    # Test with raw content string
    new_content = """{"role": "user", "content": "How do I implement a binary search?"}
{"role": "assistant", "content": "Here's how to implement binary search in Python..."}"""

    summary = hooks.simple_summarize(new_content, max_chars=200)

    assert len(summary) > 0
    assert len(summary) <= 200
    assert "binary search" in summary.lower() or "user" in summary.lower()

    # Test with empty content
    empty_summary = hooks.simple_summarize("", max_chars=200)
    assert empty_summary == "No new content in this session"
