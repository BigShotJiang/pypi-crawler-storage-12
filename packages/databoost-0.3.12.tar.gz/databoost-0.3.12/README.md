# databoost

`databoost` is a Python library that **enhances your Data Science workflow** with:

- Custom metrics
- Advanced plots
- ML training & interpretability algorithms

And more in the future!

## Installation

```bash
pip install databoost
```