Interacting with SAR data in proven, but nonstandard ways in Python.

This module is not in the public API and may be removed in the future.
