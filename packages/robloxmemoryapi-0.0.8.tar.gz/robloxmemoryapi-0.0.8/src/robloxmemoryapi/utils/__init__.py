# Utility subpackage for memory access and offsets

