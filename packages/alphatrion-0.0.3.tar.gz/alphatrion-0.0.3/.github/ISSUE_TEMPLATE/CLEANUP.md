---
name: Clean Up Request
about: Suggest to clean up code, process or tech debt to the project
title: ''
labels: cleanup
assignees: ''

---

<!-- Please only use this template for submitting clean up requests -->

**What would you like to be cleaned**:

**Why is this needed**:
