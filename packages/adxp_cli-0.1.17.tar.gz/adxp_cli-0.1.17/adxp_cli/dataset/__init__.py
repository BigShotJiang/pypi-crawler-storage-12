"""
Dataset CLI 모듈

Dataset CRUD 기능을 제공하는 CLI입니다.
"""

from .cli import cli

__all__ = ["cli"]
