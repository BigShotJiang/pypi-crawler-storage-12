# coding=utf-8
"""Test scenarios."""

from pytest_bdd import scenarios

scenarios("../../tests/v1/features", "../../tests/v2/features")
