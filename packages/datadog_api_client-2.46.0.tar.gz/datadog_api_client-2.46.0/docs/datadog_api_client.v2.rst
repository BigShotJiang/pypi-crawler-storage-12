datadog\_api\_client.v2 package
===============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   datadog_api_client.v2.api
   datadog_api_client.v2.model

Module contents
---------------

.. automodule:: datadog_api_client.v2
   :members:
   :show-inheritance:
