datadog\_api\_client.v1 package
===============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   datadog_api_client.v1.api
   datadog_api_client.v1.model

Module contents
---------------

.. automodule:: datadog_api_client.v1
   :members:
   :show-inheritance:
