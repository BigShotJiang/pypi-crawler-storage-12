def test(ax_lang):
    assert ax_lang.eval(1) == 1
