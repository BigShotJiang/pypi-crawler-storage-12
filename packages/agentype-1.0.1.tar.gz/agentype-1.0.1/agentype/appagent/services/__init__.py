"""
agentype - App Agent 服务模块
Author: cuilei
Version: 1.0
"""

# 这个模块主要包含MCP服务器的实现
# 可以通过 python -m celltypeAppAgent.services.mcp_server 启动服务器

__all__ = []