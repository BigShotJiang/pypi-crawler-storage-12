#!/usr/bin/env python3
"""
agentype - 中文Prompt模块
Author: cuilei
Version: 2.0
"""

# 中文Prompt模块初始化文件
# 所有中文prompt都在此目录下的*_prompts.py文件中定义
