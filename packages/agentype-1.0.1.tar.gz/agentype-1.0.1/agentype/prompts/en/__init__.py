#!/usr/bin/env python3
"""
agentype - English prompt module
Author: cuilei (translated)
Version: 2.0
"""

# English prompt package initializer
# All English prompts are defined in the *_prompts.py modules in this package

