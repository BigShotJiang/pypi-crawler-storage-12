"""
agentype - 模块初始化
Author: cuilei
Version: 1.0
"""

from .settings import ConfigManager

__all__ = [
    "ConfigManager",
]

