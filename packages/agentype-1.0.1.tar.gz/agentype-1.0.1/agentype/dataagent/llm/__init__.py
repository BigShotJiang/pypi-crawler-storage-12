"""
agentype - 模块初始化
Author: cuilei
Version: 1.0
"""
