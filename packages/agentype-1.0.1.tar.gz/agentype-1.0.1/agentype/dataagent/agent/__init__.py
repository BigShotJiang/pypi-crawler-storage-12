"""
agentype - module
Author: cuilei
Version: 1.0
"""

from .data_processor_agent import DataProcessorReactAgent

__all__ = [
    'DataProcessorReactAgent'
]