"""
agentype - 配置管理模块
Author: cuilei
Version: 1.0
"""

from .settings import ConfigManager

__all__ = [
    'ConfigManager'
]