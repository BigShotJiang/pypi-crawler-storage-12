"""Events management services"""

from .events_manager import EventsManager, events_manager

__all__ = ['EventsManager', 'events_manager']

