# this request type is for models that add "reasoning_content"
# on top of the openai chat completions. it's important to be separate
# for providers that expect you to provide back the reasoning content to
# preserve best performance.
