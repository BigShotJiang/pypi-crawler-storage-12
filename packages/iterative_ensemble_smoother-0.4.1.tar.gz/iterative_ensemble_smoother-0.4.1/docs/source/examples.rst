Example Usage
=============

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Polynomial
   Oscillator
   LinearRegression
   Adaptive

* :ref:`genindex`
