from .spatial_selector import spatial_selector

__all__ = ["spatial_selector"]
