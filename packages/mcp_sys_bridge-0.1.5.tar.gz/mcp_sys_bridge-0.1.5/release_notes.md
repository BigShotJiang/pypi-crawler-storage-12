## What's Changed

- Merge pull request #4 from leynier/claude/add-system-notifications-013QcFEvGUKLjsbKzHbJAZMZ (18c6a84)
- chore: update lockfile to reflect version 0.1.5 (118bb8c)
- fix: set send_notification readOnlyHint to true (185c9f5)
- refactor: remove app_icon parameter from send_notification (b9951e0)
- feat: add cross-platform system notifications support (91620b6)
- Merge pull request #1 from leynier/codex/mejorar-documentación-del-readme (ba078c1)
- docs: refine installation and changelog (1fbc319)
- chore: update GitHub Actions workflow to use action-gh-release@v2 and remove changelog URL from release notes (1292c8b)

