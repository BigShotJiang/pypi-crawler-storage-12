Simple check:

- Open the contact "Mitchel Admin"
- Click "Message History"
- Check if message from "Coleen Diaz" is shown

Advanced check:

- Create a new contact "test"
- Ensure that history button is not shown
- Enter mail "test@example.com"
- Send a message "ping"
- Click the "Mail History" button
- Ensure the sent mail is shown

Notification check:

- Create a new contact "notify"
- Enter mail "notify@example.com"
- Add the contact as follower to "test"
- Send a message "ping" on "test"
- Click the "Mail History" button of "notify".
- Ensure the sent mail is shown
