'''
Created on 20251114
Update on 20251115
@author: Eduardo Pagotto
'''

__version__ : str = "1.0.0"
