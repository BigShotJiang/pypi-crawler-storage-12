from .output import *
from .node_coloring import *
from .edge_coloring import *
from .face_coloring import *
