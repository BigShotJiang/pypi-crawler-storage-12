from .jrdf import jrdf

def main() -> None:
    jrdf()
