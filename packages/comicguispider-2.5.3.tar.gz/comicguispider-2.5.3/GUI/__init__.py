#!/usr/bin/python
# -*- coding: utf-8 -*-
"""path to save factitious code, inherit-class from code of uic"""
