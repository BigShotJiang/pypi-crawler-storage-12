from __future__ import annotations

from .optmap import OpticalMap

__all__ = ["OpticalMap"]
