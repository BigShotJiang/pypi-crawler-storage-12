class PycapException(Exception):
    """General placeholder exception here"""

    pass
