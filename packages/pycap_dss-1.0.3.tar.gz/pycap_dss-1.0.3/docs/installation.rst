============
Installation
============

Install your cloned local version using command line::

    $ pip install -e .

