"""Test the adapters."""
