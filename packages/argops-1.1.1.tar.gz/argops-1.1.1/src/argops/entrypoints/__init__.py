"""Define the different ways to expose the program functionality."""
