"""Promote argo application between environments."""
