"""Initialization file for library."""

# pylint: disable=C0114

__version__ = "1.1.3"
