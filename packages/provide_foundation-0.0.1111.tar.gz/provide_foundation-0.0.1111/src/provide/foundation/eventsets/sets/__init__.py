#
# SPDX-FileCopyrightText: Copyright (c) 2025 provide.io llc. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#

"""Event set collection modules."""

from __future__ import annotations

__all__: list[str] = []

# 🧱🏗️🔚
