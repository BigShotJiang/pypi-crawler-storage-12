"""
Annotator module for annotation workflow management
"""
from .AnnotatorManager import AnnotatorManager

__all__ = ['AnnotatorManager']
