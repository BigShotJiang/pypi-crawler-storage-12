"""
Initializer module for application setup
"""
from .AppInitializer import AppInitializer

__all__ = ['AppInitializer']
