"""
Configuration management module
"""
from .ConfigurationManager import ConfigurationManager

__all__ = ['ConfigurationManager']
