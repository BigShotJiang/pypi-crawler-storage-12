"""
Models module for the annotator service
"""
from .AIModel import AIModel

__all__ = ['AIModel']
