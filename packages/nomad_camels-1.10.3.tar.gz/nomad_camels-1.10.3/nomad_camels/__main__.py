if __name__ == "__main__":
    from .CAMELS_start import start_camels

    start_camels()
