from . import packages, sygic_maps

ROUTERS = [sygic_maps.ROUTER, packages.ROUTER]
