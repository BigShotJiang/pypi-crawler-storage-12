__version__ = '1.16.0'


import pathlib

PACKAGE_NAME = pathlib.Path(__file__).parent.name
