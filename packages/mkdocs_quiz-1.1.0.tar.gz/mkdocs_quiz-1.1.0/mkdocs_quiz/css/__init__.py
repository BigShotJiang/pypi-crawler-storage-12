"""CSS resources for MkDocs Quiz Plugin."""
