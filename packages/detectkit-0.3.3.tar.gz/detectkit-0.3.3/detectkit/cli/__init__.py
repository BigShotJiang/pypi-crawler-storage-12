"""Command-line interface for detectk."""
