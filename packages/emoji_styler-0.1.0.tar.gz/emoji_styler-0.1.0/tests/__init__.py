"""Tests for emoji-styler package."""
