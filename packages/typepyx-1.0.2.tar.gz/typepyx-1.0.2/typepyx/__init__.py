from .core import NType, setType

__all__ = ["NType", "setType"]