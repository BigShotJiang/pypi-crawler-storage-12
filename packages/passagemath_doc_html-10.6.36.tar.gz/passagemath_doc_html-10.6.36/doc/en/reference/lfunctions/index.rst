`L`-Functions
=============

Sage includes several standard open source packages for computing
with `L`-functions.

.. toctree::
   :maxdepth: 1

   sage/lfunctions/lcalc
   sage/lfunctions/sympow
   sage/lfunctions/dokchitser
   sage/lfunctions/zero_sums
   sage/lfunctions/pari

.. include:: ../footer.txt
