import lyrpy.LUos as LUos

if __name__ == "__main__":
    print(LUos.cHOME)