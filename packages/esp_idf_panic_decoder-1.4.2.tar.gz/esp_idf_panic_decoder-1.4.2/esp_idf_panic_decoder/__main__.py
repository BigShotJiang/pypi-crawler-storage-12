from .gdb_panic_server import main

if __name__ == '__main__':
    main()
