This module allows to have three successive discounts on every purchase
order line.
