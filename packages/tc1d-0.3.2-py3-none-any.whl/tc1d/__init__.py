import importlib.metadata
from .tc1d import init_params, prep_model

# Versioning
__version__ = importlib.metadata.version("tc1d")
