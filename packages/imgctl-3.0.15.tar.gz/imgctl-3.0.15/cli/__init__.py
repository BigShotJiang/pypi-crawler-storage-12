"""
CLI модули imgctl

Содержит интерфейс командной строки и команды.
"""

from .main import main

__all__ = ["main"]
