* Nipyapi version:
* NiFi version:
* NiFi-Registry version:
* Python version:
* Operating System:

### Description

Describe what you were trying to get done, or what you would like the package to do.  
Tell us what happened, what went wrong, and what you expected to happen.

### What I Did

Paste the command(s) you ran and the output.  
If there was a crash, please include the traceback here.

### Urgency

Please give a brief description of how critical this issue is to you.  
For example, if it's blocking your Production environment, or perhaps you are just notifying us of something you found but isn't blocking your workflow.
