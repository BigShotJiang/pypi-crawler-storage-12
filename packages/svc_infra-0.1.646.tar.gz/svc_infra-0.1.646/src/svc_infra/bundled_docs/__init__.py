# Bundled docs package for zip-safe importlib.resources access
