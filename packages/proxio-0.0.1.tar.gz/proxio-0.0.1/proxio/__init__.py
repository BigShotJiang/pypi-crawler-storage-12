__version__ = "0.0.1" # Hatch will update this

def version():
    """Returns the current version."""
    return __version__
