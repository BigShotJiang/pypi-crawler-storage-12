"""
This module is the core of the CorpTools Ecosystem
"""
__version__ = "2.15.1"
__url__ = "https://github.com/Solar-Helix-Independent-Transport/allianceauth-corp-tools"
