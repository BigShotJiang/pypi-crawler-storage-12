# Rat types
RAT_CAPITAL_GROUPS = [
    1880,
    1879,
    1412,
    1681,
    1683,
    1685,
    1691,
    1687,
    1689,
    1804,
    4572,
    1724,
    1725
]

RAT_TITAN_GROUPS = [
    1878,
    1682,
    1684,
    1686,
    1690,
]

RAT_SUPER_GROUPS = [
    1692,
    1688,
    1731,
    1465,
    1052
]

RAT_OFFICER_GROUPS = [
    553,
    559,
    564,
    1174,
    569,
    574
]

RAT_OFFICER_CRUISER_GROUPS = [
    4795,
    4797,
    4799,
    4801,
    4803,
]

RAT_OFFICER_FRIGATE_GROUPS = [
    4796,
    4798,
    4800,
    4802,
    4804
]

MINING_GAS_GROUPS = [
    711
]

MINING_ICE_GROUPS = [
    465,
    903
]

MINING_MOON_GROUPS = [
    1884,
    1920,
    1921,
    1922,
    1920
]

MINING_ORE_GROUPS = [
    450,
    451,
    452,
    453,
    454,
    455,
    456,
    457,
    458,
    459,
    460,
    461,
    462,
    467,
    468,
    469,
    2024,
    4029,
    4030,
    4031,
    4513,
    4514,
    4515,
    4516,
    4568,
    4756,
    4757,
    4758,
    4759,
]
