import CharacterAtAGlance from "./AtAGlance";

const CharacterOverview = () => {
  return (
    <>
      <CharacterAtAGlance />
    </>
  );
};

export default CharacterOverview;
