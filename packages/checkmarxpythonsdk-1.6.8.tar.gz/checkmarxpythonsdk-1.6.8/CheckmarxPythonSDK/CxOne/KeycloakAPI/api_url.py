api_url = "/auth/admin/realms"
