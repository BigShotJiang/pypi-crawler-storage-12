# src/pyaps/datamanagement/__init__.py
from .client import DataManagementClient

__all__ = [
    "DataManagementClient",
]
