from .RePU import RePU


class ReCU(RePU):
    def __init__(self):
        super().__init__(alpha=3)
