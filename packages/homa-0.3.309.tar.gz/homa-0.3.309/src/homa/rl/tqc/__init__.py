from .QuantileMultiCritic import QuantileMultiCritic
from .QuantileCritic import QuantileCritic
