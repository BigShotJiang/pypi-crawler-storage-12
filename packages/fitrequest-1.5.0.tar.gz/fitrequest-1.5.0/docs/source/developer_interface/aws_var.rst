AWSVar
======

.. autopydantic_model:: fitrequest.aws_var.AWSVar



AWSSecretTypeEnum
=================

.. autoclass:: fitrequest.aws_var.AWSSecretTypeEnum



AWSRegionEnum
=============

.. autoclass:: fitrequest.aws_var.AWSRegionEnum
