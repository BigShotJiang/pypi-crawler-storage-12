Auth
====

.. autopydantic_model:: fitrequest.auth.Auth
