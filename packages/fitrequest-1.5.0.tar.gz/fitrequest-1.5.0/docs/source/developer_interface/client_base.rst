FitRequestBase
==============

.. autoclass:: fitrequest.client_base.FitRequestBase
