FitConfig
=========

.. autopydantic_model:: fitrequest.fit_config.FitConfig
