MethodConfig
============

.. autopydantic_model:: fitrequest.method_config.MethodConfig


RequestVerb
-----------

.. autoclass:: fitrequest.method_config.RequestVerb
