Developer Interface
===================

This section documents the pydantic models and functions used by fitrequest to validate and generated the final
fitrequest class and methods.


.. toctree::
   :maxdepth: 3
   :titlesonly:
   :glob:

   *
   decorators/index
