Session
=======

.. autoclass:: fitrequest.session.Session
