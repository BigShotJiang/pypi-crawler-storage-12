ResponseFormatter
=================

.. autoclass:: fitrequest.response.ResponseFormatter
