Response
========

.. autoclass:: fitrequest.response.Response
