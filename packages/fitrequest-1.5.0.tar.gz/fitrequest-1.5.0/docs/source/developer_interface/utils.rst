Utils
=====

.. autofunction:: fitrequest.utils.extract_method_params
.. autofunction:: fitrequest.utils.string_varnames
.. autofunction:: fitrequest.utils.format_url
.. autofunction:: fitrequest.utils.extract_url_params
.. autofunction:: fitrequest.utils.is_basemodel_subclass
.. autofunction:: fitrequest.utils.check_reserved_names

.. autodata:: fitrequest.utils.reserved_httpx_names

.. autodata:: fitrequest.utils.reserved_fitrequest_names
