Generator
=========

.. autoclass:: fitrequest.generator.Generator
