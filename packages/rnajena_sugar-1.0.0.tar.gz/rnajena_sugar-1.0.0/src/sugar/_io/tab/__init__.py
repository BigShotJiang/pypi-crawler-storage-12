"""
Tabular formats, e.g. TSV, CSV, created by BLAST, MMseqs2 and others
"""