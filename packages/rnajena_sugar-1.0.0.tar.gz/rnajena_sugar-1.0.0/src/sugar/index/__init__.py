"""
sugar.index -- File indexing and querying tools
"""
