"""
sugar.core -- Sequence and feature classes
"""
