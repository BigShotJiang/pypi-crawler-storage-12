"""
sugar.web -- Download online resources (entrez)
"""
from sugar.web._entrez import Entrez
