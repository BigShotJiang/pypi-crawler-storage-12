To use this module, you need to:

1.  Go to either *Sales \> Products \> Discount & Loyalty* or *Sales \>
    Products \> Gift cards & eWallet*
2.  Open a program record and you'll see the chatter where you can place
    messages and schedule activities.
