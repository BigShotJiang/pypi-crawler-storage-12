This module extends the functionality of sale coupon programs to allow
to register messages and activities in every record.
