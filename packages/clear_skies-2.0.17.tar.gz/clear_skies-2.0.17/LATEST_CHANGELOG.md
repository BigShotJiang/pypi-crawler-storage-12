## [2.0.17] - 2025-11-17

### Changed
- Connections take three by @tnijboer in [#33](https://github.com/clearskies-py/clearskies/pull/33)
- Use bindings with caching off, more injectable properties by @cmancone in [#34](https://github.com/clearskies-py/clearskies/pull/34)

### Fixed
- Move all tests to the tests folder by @cmancone in [#36](https://github.com/clearskies-py/clearskies/pull/36)
- Move all tests to the tests folder
- Use getattr instead of .get on model by @tnijboer in [#35](https://github.com/clearskies-py/clearskies/pull/35)

