#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" Constants declarations """

# These get overwritten at build time. See build.sh
VERSION = '1.2.0'
BUILD = '2161445665'
NAME = 'egos-helpers'
