from typing import Optional, Union, List

example: Optional[Union[int, List[int]]] = None
