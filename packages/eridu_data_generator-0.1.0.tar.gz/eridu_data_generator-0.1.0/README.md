# Eridu Data Generator
A package for generating mock cloud financial data.
