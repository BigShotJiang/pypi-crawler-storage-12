"""
Streamlit App for pyfuzzy-toolbox
Web interface for ANFIS and Fuzzy Systems
"""

__all__ = []
