"""Modules for pyfuzzy-toolbox Streamlit interface"""

from . import anfis_module
from . import wang_mendel_module
