# Copyright 2019-2025 SURF, GÉANT.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


class SearchUtilsError(Exception):
    """Base exception for this module."""

    pass


class ProductNotInRegistryError(SearchUtilsError):
    """Raised when a product is not found in the model registry."""

    pass


class ModelLoadError(SearchUtilsError):
    """Raised when a Pydantic model fails to load from a subscription."""

    pass


class InvalidCursorError(SearchUtilsError):
    """Raised when cursor cannot be decoded."""

    pass


class QueryStateNotFoundError(SearchUtilsError):
    """Raised when a query state cannot be found in the database."""

    pass
