"""Auto-generated file containing build-time git tag and hash."""

GIT_TAG = "v0.2.3"
GIT_HASH = "eec0ba0"
