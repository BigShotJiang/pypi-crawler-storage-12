from . import res_partner
from . import survey_question
from . import survey_survey
from . import survey_user_input
