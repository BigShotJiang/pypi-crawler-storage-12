/* global angular */
(function () {
  'use strict';

  angular.module('blocks.error', ['ngMaterial', 'ngclipboard']);
})();
