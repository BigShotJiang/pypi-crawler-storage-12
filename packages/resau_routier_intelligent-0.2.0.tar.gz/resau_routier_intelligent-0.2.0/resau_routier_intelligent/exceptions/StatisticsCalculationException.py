class StatisticsCalculationException(Exception):
    """Exception raised when statistics calculation fails."""

    pass
