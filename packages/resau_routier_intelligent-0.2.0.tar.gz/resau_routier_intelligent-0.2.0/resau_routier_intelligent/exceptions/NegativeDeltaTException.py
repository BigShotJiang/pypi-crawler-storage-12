class NegativeDeltaTException(ValueError):
    """Exception raised when delta_t is negative."""

    pass
