class ConfigFileException(Exception):
    """Exception raised for configuration file error scenarios."""

    pass
