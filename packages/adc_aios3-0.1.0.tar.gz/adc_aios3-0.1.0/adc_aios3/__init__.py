"""AioS3 - Async S3 client with lifecycle management."""

from .client import S3Client

__version__ = "0.1.0"
__all__ = ["S3Client"] 