"""Pytest configuration."""

import pytest

pytest_plugins = ["pytest_asyncio"] 