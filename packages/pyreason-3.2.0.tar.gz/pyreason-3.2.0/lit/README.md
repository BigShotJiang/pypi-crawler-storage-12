# PyReason Literature Page

Extended paper with supplemental and appendix sections: https://arxiv.org/abs/2302.13482 
