# Run this script after cloning repository to generate the numba caches. This script runs the hello-world program internally
print('Initializing PyReason caches')
import pyreason as pr
    
