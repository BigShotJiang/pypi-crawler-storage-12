- Daniel Reis \<<dreis.pt@hotmail.com>\>

- Maxime Chambreuil \<<maxime.chambreuil@savoirfairelinux.com>\>

- Gervais Naoussi \<<gervaisnaoussi@gmail.com>\>

- Dave Lasley \<<dave@laslabs.com>\>

- [Tecnativa](https://www.tecnativa.com):

  > - Sergio Teruel

- David Alonso \<<david.alonso@solvos.es>\>
