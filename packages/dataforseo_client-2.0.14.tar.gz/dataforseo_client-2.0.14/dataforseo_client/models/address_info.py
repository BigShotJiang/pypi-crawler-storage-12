from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from pydantic import BaseModel, ConfigDict, Field, StrictFloat, StrictInt, StrictStr, StrictBool
from typing import Any, ClassVar, Dict, List, Optional, Union
from typing import Optional, Set, Any, Dict, List
from typing_extensions import Self




class AddressInfo(BaseModel):
    """
    AddressInfo
    """ # noqa: E501
    borough: Optional[StrictStr] = Field(default=None, description=r"administrative unit or district the local establishment belongs to")
    address: Optional[StrictStr] = Field(default=None, description=r"street address of the local establishment")
    city: Optional[StrictStr] = Field(default=None, description=r"name of the city where the local establishment is located")
    zip: Optional[StrictStr] = Field(default=None, description=r"ZIP code of the local establishment")
    region: Optional[StrictStr] = Field(default=None, description=r"DMA region the local establishment belongs to")
    country_code: Optional[StrictStr] = Field(default=None, description=r"ISO country code of the local establishment")
    __properties: ClassVar[List[str]] = [
        "borough", 
        "address", 
        "city", 
        "zip", 
        "region", 
        "country_code", 
        ]

    additional_properties: Dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )

    def to_str(self) -> str:
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        excluded_fields: Set[str] = set([
        ])

        _dict = {}

        _dict['borough'] = self.borough
        _dict['address'] = self.address
        _dict['city'] = self.city
        _dict['zip'] = self.zip
        _dict['region'] = self.region
        _dict['country_code'] = self.country_code
        return _dict


    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "borough": obj.get("borough"),
            "address": obj.get("address"),
            "city": obj.get("city"),
            "zip": obj.get("zip"),
            "region": obj.get("region"),
            "country_code": obj.get("country_code"),
        })

        additional_properties = {k: v for k, v in obj.items() if k not in cls.__properties}
        _obj.additional_properties = additional_properties
        return _obj