"""
測試 fixtures 模組
"""