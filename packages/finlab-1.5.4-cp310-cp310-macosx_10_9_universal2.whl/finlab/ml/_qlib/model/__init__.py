# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

import warnings

from .base import Model


__all__ = ["Model", "warnings"]
