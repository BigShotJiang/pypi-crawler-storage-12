<template>
  <div class="h-full animate-pulse rounded-2xl border border-slate-800 bg-slate-950/40 p-5">
    <div class="h-5 w-3/4 rounded bg-slate-800/70" />
    <div class="mt-3 h-4 w-full rounded bg-slate-800/50" />
    <div class="mt-2 h-4 w-5/6 rounded bg-slate-800/50" />
  </div>
</template>
