<template>
  <div class="flex justify-center items-center" role="status">
    <div class="animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent"></div>
    <span class="sr-only">Loading...</span>
  </div>
</template>
