Das jetzige Automatisierungsprogramm leicht verändern, sodass die docstrings in ein temp directory geschrieben werden
Daraus wird dann die JSON COde DOkumentation erstellt. Vue Vitepress Komponenten nutzen diese Daten daann zum Anzeigen
der Code Dokumentation.

Vielleicht statdessen sidecars oder ähnliches verwenden? Automatisierte generierung der Sidecars
mit Automatic Github Issues that are solved by  Copilot!
Github Actions automatisierung?!
Examles mit Code anzeigen? soctest oder soas?