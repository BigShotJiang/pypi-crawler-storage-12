# [Module Name] Guidelines

**Location:** `path/to/module`  
**Parent Guidelines:** [Link to parent AGENTS.md]  
**Last Updated:** YYYY-MM-DD

## Quick Reference
[Table or bullet list of key points]

## Purpose
[What this module does]

## Structure
[Directory layout]

## Guidelines
[Specific rules with examples]

## Testing
[Where tests go, how to run them]

## Examples
[Code snippets showing correct usage]

## Common Mistakes
[Anti-patterns to avoid]