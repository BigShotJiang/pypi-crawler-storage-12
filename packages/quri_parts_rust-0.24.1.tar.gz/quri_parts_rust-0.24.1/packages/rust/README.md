# QURI Parts Rust

This library is a dependency of some QURI Parts packages, and not intended to be used directly. See [QURI Parts Documentation](https://quri-parts.qunasys.com) for public APIs.

## Build

run `make` at the quri-parts project root

```bash
make
```

## License

Apache License 2.0
