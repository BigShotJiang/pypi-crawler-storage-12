# SpringGen

A simple interactive CLI tool to generate Spring Boot CRUD boilerplate code.

## Installation

```bash
pip install springgen
```

## Usage

```bash
springgen
```


## Configure folder names:

```bash
springgen --config
```