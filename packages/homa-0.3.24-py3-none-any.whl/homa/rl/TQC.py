class TQC:
    pass
