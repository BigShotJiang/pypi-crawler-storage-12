"""
Django RemixIcon - A simple Django package for integrating RemixIcon.
"""

__version__ = "2.0.2"

default_app_config = "django_remix_icon.apps.DjangoRemixIconConfig"
