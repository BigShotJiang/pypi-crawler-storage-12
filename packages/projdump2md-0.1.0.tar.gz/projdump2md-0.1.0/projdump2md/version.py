"""
Copyright (C) 2025, Jabez Winston C

Author  : Jabez Winston C <jabezwinston@gmail.com>
License : MIT
Date    : 14-Nov-2025

"""

VERSION='0.1.0'