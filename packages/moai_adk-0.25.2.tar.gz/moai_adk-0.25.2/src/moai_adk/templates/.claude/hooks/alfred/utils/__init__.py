"""
Utility modules for Alfred hooks.

This package contains utility functions and configuration
for Alfred hook scripts integration.
"""

__version__ = "1.0.0"
__author__ = "MoAI-ADK Team"
