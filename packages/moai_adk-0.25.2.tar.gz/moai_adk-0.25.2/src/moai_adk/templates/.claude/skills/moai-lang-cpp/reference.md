# moai-lang-cpp - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **C++**: 23
- **GCC**: 14.2.0
- **Google Test**: 1.15.0
- **clang-format**: 19.1.7

---

_For detailed usage, see SKILL.md_
