# Session Summary

## Current Task
- Feature: [description]
- SPEC: [ID]
- Status: [phase]

## Key Files
- Test: [path]
- Impl: [path]
- Config: [path]

## Important Context
- [Key insights]
- [Related features]

## Assumptions Made
- [List assumptions]
