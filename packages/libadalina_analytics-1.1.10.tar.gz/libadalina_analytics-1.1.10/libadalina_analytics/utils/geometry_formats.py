from enum import Enum


class GeometryFormats(Enum):
    WKT = "WKT"
    GEOJSON = "GeoJSON"