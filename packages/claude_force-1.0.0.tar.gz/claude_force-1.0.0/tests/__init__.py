"""
Tests for claude-force multi-agent orchestration system.
"""
