"""
Copyright © 2025  Bartłomiej Duda
License: GPL-3.0 License
"""

from typing import Final

# DLL log file located in C:\Users\<username>\AppData\Local\Temp on Windows
DLL_LOG_FILE_NAME: Final[str] = "reversebox_dll_file_log.txt"
