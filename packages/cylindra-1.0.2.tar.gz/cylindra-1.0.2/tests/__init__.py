"""
Image files are contained in this test directory.

- beta-tubulin.mrc
The original data of this image is deposited on https://www.ebi.ac.uk/emdb/EMD-7974.
This sample image is created by erasing irrelevant monomers and rescaling it.
"""
