from pathlib import Path

TEST_DIR = Path(__file__).parent
PROJECT_DIR_13PF = TEST_DIR / "test_project_13pf"
PROJECT_DIR_14PF = TEST_DIR / "test_project_14pf"
