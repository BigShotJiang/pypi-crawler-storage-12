# cylindra.plugin

This submodule includes functions for plugin management.

::: cylindra.plugin
    options:
        show_signature_annotations: false
        heading_level: 4
