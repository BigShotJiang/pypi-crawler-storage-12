# cylindra_builtins.imod

This built-in plugin submodule provides functions to work with IMOD file formats.

::: cylindra_builtins.imod
    options:
        show_signature_annotations: false
        heading_level: 4
