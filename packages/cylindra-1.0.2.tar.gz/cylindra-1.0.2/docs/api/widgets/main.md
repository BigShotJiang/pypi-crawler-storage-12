# cylindra.widgets.main.CylindraMainWidget

::: cylindra.widgets.main.CylindraMainWidget
    options:
        show_signature_annotations: false
        heading_level: 4
