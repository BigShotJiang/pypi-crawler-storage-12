# cylindra.widgets.sta.SubtomogramAveraging

Methods are available in the namespace `ui.sta`.

::: cylindra.widgets.sta.SubtomogramAveraging
    options:
        show_signature_annotations: false
        heading_level: 4
