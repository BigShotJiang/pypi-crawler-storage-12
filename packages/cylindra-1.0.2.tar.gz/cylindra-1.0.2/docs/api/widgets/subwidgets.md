# cylindra.widgets.subwidgets

## Simulator

Methods are available in the namespace `ui.simulator`.

::: cylindra.widgets.subwidgets.Simulator
    options:
        show_signature_annotations: false
        heading_level: 4

## Spline Slicer

Methods are available in the namespace `ui.spline_slicer`.

::: cylindra.widgets.subwidgets.SplineSlicer
    options:
        show_signature_annotations: false
        heading_level: 4
