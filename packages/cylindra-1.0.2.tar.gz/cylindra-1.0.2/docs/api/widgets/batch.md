# cylindra.widgets.batch

## CylindraBatchWidget

Methods are available in the namespace `ui.batch`.

::: cylindra.widgets.batch.CylindraBatchWidget
    options:
        show_signature_annotations: false
        heading_level: 4

## BatchSubtomogramAveraging

Methods are available in the namespace `ui.batch.sta`.

::: cylindra.widgets.batch.sta.BatchSubtomogramAveraging
    options:
        show_signature_annotations: false
        heading_level: 4
