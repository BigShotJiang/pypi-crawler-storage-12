# Average Across Projects

Subtomogram averaging and analysis can be similarly done as with
[single tomogram](../alignment/conventional.md). All the functions are in the
menubars on the right side. Instead of selecting a molecules-layer, for batch analysis
you'll need to select a loader created as in [Construct Batch Loaders](construct.md).
