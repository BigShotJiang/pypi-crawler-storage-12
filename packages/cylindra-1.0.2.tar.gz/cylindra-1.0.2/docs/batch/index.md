# Working with Many Projects

`cylindra` provides methods and widgets to analyze across projects.

- [Collect projects](collect_projects.md)
- [Construct batch loaders](construct.md)
- [Average across projects](average.md)
