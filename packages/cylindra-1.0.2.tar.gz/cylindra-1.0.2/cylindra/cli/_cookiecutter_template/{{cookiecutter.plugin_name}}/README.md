# {{cookiecutter.plugin_name}}

{{cookiecutter.short_description}}

This plugin was generated with [cookiecutter](https://github.com/cookiecutter/cookiecutter).

## Installation

```bash
pip install {{cookiecutter.plugin_name}}
```
