pub mod hash_1d;
pub mod hash_2d;

pub use hash_1d::HashMap1D;
pub use hash_2d::HashMap2D;
