VERSION = "0.0.5"
BROADCAST_PORT = 33311
running = True
debug = False
do_not_log = ["DiscoveryManager", "Listener"]
