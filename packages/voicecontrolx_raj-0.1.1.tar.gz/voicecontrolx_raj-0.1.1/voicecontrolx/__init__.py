# voicecontrolx/__init__.py
from .core import listen_offline, speak, download_vosk_model
from .actions import open_application, tell_time, take_screenshot, lock_pc
