
## v0.1.0 - (06-05-2025)

- First release of `GNN SDK`
