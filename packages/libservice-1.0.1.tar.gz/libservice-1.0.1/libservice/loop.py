import asyncio

loop = asyncio.new_event_loop()
