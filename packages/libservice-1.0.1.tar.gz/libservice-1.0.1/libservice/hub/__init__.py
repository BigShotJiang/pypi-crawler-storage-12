from .client import HubClient


hub = HubClient()
