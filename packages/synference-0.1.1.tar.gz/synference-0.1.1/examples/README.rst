Examples
=========

Below are some simple examples to get you started with synference. For more detailed examples, check out the `Examples <../auto_examples/index>`_ page.