# Copyright (c) Microsoft. All rights reserved.

from semantic_kernel.utils.authentication.entra_id_authentication import get_entra_auth_token

__all__ = ["get_entra_auth_token"]
