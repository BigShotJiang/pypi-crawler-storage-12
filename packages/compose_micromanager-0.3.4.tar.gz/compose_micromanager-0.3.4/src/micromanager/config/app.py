from micromanager.config.config import AppConfig


app_config = AppConfig()
