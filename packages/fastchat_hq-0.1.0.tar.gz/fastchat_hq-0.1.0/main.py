def main():
    print("Hello from fastchat-hq!")


if __name__ == "__main__":
    main()
