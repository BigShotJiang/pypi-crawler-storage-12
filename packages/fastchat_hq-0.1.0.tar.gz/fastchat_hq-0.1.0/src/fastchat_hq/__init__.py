"""
fastchat-hq - 高性能 OpenAI Chat Completions 异步客户端
"""

from .chat import OpenAIChatClient

__version__ = "0.1.0"
__all__ = ["OpenAIChatClient"]
