from NaxToPy.Modules.static.metallic.neuber.N2PNeuber import N2PNeuber
__all__ = ["N2PNeuber"]