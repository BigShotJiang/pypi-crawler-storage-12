File handling toolbox for Microservice Developers, Data Engineers and
Data Scientists working in Python

** Documentation **

https://mjooln.readthedocs.io/
