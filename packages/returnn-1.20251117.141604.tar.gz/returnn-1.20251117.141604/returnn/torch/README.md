See here for some initial discussion:
https://github.com/rwth-i6/returnn/issues/1120
