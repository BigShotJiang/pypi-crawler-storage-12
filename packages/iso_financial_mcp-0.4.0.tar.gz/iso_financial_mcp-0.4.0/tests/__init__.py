"""
Test suite for IsoFinancial-MCP meta-tools optimization.

Run tests with: uv run pytest tests/ -v
"""
