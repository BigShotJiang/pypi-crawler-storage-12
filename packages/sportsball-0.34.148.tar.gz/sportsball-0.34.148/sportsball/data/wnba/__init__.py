"""The wnba data sportsball module."""

from .combined.wnba_combined_league_model import \
    WNBACombinedLeagueModel as WNBALeagueModel

__all__ = ("WNBALeagueModel",)
