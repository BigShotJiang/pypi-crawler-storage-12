"""The nba data sportsball module."""

from .combined.nba_combined_league_model import \
    NBACombinedLeagueModel as NBALeagueModel

__all__ = ("NBALeagueModel",)
