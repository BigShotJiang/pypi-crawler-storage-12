"""The nfl data sportsball module."""

# ruff: noqa: F401
from .combined.nfl_combined_league_model import \
    NFLCombinedLeagueModel as NFLLeagueModel
