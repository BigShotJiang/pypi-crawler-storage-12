"""The hkjc data sportsball module."""

from .hkjc.hkjc_hkjc_league_model import HKJCHKJCLeagueModel as HKJCLeagueModel

__all__ = ("HKJCLeagueModel",)
