"""The nhl data sportsball module."""

# ruff: noqa: F401
from .combined.nhl_combined_league_model import \
    NHLCombinedLeagueModel as NHLLeagueModel
