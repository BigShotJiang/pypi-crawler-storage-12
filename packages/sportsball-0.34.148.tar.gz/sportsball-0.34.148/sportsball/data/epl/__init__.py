"""The epl data sportsball module."""

from .combined.epl_combined_league_model import \
    EPLCombinedLeagueModel as EPLLeagueModel

__all__ = ("EPLLeagueModel",)
