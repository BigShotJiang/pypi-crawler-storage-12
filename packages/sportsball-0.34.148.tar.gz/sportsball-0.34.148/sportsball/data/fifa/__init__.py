"""The fifa data sportsball module."""

from .combined.fifa_combined_league_model import \
    FIFACombinedLeagueModel as FIFALeagueModel

__all__ = ("FIFALeagueModel",)
