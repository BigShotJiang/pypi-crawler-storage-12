"""The WTA data sportsball module."""

from .combined.wta_combined_league_model import \
    WTACombinedLeagueModel as WTALeagueModel

__all__ = ("WTALeagueModel",)
