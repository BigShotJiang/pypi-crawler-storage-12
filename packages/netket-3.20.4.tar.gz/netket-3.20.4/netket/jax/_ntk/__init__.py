from .logic import empirical_ntk_by_jacobian
