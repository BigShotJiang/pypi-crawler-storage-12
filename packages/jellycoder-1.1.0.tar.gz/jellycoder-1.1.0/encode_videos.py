# Configuration defaults – tweak if you need different trade-offs
"""Backward-compatible wrapper that runs the jelly_coder CLI."""

from jelly_coder.cli import main


if __name__ == "__main__":
    main()
