'''
Author: Mr.Car
Date: 2025-03-21 14:44:15
'''
"""
Weather Server Package
"""

from .server import server, get_weather, get_weather_forecast

__version__ = "1.0.0" 