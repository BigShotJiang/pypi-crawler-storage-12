"""
Comment usage examples for ManifoldBot.

This package contains examples demonstrating the comment functionality,
including AI-powered comment generation and market interaction patterns.
"""