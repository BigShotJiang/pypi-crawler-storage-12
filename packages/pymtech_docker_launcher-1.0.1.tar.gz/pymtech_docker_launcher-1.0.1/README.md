# Launcher for pymtech docker containers

This is a launcher made for automating the deployment of odoo docker containers.