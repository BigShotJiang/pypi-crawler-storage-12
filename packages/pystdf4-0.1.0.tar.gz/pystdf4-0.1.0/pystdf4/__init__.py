from .IO.stfd4write import Stfd4Writer

__version__ = "0.1.0"
__all__ = ["Stfd4Writer"]
