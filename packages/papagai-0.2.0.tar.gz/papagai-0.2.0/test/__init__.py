#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later

"""Test suite for papagai."""

import logging

logger = logging.getLogger("papagai.test")
