from typing import Any

ConfigDict = dict[Any, Any]
