from enum import Enum


class OutputFormat(str, Enum):
    jpeg = "jpeg"
    png = "png"
