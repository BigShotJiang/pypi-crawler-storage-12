"""Metadata for vcspull."""

from __future__ import annotations

__title__ = "vcspull"
__package_name__ = "vcspull"
__description__ = "Repo manager and syncer for git, mercurial, and svn"
__version__ = "1.47.0"
__author__ = "Tony Narlock"
__github__ = "https://github.com/vcs-python/vcspull"
__docs__ = "https://vcspull.git-pull.com"
__tracker__ = "https://github.com/vcs-python/vcspull/issues"
__pypi__ = "https://pypi.org/project/vcspull/"
__email__ = "tony@git-pull.com"
__license__ = "MIT"
__copyright__ = "Copyright 2013- Tony Narlock"
