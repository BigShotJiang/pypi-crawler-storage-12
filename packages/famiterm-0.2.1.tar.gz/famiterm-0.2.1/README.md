famiterm
--------

A NES emulator running in the terminal.

![](https://github.com/vxgmichel/famiterm/raw/main/demo.gif)

It uses the [gambaterm](https://github.com/vxgmichel/gambatte-terminal) frontend.

Also, it only runs Super Mario Bros.

