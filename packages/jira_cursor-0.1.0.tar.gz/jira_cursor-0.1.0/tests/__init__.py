"""Tests for jira-cursor package."""

