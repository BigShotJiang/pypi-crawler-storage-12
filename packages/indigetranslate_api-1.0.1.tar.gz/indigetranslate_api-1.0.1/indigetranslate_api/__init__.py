from .client import IndigeTranslate, TranslationResult

__all__ = ["IndigeTranslate", "TranslationResult"]