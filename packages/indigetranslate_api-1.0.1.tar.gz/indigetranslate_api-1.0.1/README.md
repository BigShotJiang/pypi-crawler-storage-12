# IndigeTranslate API — Cliente oficial en Python

API de traducciones de lenguas indígenas.

## Instalación

```bash
pip install indigetranslate-api