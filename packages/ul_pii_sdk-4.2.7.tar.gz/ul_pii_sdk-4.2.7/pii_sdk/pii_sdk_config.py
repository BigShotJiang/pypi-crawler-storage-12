from typing import NamedTuple


class PiiSdkConfig(NamedTuple):
    api_url: str
    api_token: str
