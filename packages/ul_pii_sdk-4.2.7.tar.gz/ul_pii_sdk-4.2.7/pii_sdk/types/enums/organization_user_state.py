from enum import Enum


class OrganizationUserState(Enum):
    active = "ACTIVE"
    blocked = "BLOCKED"
