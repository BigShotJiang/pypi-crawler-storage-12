# Generated file
import collections

BuildInfo = collections.namedtuple(
    'BuildInfo',
    ['version', 'built_at', 'sha', 'branch', 'tag'],
)

BUILD_INFO = BuildInfo(
    version='v0.1.0~59ebd0c',
    built_at='2025-11-14 14:06:04Z',
    sha='59ebd0c1bd9b89db44b8f0131adf124618ffe42e',
    branch='HEAD',
    tag='v0.1.0',
)
