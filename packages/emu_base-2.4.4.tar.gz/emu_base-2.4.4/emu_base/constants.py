import torch


DEVICE_COUNT = torch.cuda.device_count()
