"""Setup script for legacy compatibility"""
from setuptools import setup

setup()
