"""
End-to-End Tests for Bluma Python SDK

These tests validate the full request flow: SDK → API → Database → Response
"""
