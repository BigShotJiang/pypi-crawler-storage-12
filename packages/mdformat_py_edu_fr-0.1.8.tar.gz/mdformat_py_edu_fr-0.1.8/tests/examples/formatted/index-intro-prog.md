---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
    format_version: 0.13
kernelspec:
  display_name: Python 3 (ipykernel)
  language: python
  name: python3
learning:
  objectives:
    understand: [Markdown, MyST]
  prerequisites:
    understand: ["mode \xE9dition", mode commande]
---

+++ {"tags": ["locked"], "grade_id": "cell-2df857546d357cc2"}

# Introduction à la programmation, avec Python et Jupyter

(structurer)=
### 5 - Structurer un programme : les fonctions
