# SPDX-License-Identifier: MIT
# Copyright (c) 2021, Ahmed M. Alaa, Boris van Breugel, Evgeny Saveliev, Mihaela van der Schaar