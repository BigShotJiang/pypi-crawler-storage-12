bool get_music_playing (void);
bool set_music_playing (bool new_value);

int get_musicnum (void);
int set_musicnum (int new_value);
