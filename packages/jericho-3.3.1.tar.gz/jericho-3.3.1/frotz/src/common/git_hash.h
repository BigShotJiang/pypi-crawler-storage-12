#define GIT_HASH "f31bcb937c45d45ad3136f6459621edca2f949a6"
#define GIT_HASH_SHORT "f31bcb9"
#define GIT_TAG ""
#define GIT_BRANCH "master"
