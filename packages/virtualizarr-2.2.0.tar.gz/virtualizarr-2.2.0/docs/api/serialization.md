# Serialization

::: virtualizarr.accessor.VirtualiZarrDatasetAccessor.to_icechunk
::: virtualizarr.accessor.VirtualiZarrDatasetAccessor.to_kerchunk

::: virtualizarr.accessor.VirtualiZarrDataTreeAccessor.to_icechunk
