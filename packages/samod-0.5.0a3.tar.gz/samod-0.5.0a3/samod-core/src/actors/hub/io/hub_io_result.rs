#[derive(Debug)]
pub enum HubIoResult {
    Send,
    Disconnect,
}
