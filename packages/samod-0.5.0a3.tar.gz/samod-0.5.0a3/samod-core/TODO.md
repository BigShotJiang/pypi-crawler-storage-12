* Update storage trait to be fallible
* Handle panics in with_document
* Move connection status event to dochandle
