# oddments

<div>

[![Package version](https://img.shields.io/pypi/v/oddments?color=%2334D058&label=pypi)](https://pypi.org/project/oddments/)
[![License](https://img.shields.io/github/license/zteinck/oddments)](https://github.com/zteinck/oddments/blob/master/LICENSE)

</div>

`oddments` is a Python package that offers a collection of general-purpose utilities.

## Installation
```sh
pip install oddments
```
