==========
wagtailosm
==========

This project was made very quickly and encourages you to contribute just as quickly and directly to its documentation and code. Or make it your own immediately!

.. image::
   ./screen.png


Contents
________

.. toctree::
   :maxdepth: 2

   usage

Feedback
________

Opening PRs on the main repo is encouraged: http://github.com/benjaoming/wagtailosm main repository.
