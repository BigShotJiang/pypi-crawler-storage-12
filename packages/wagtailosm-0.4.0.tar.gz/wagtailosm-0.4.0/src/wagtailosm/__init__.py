__author__ = 'Benjamin Bach'
__email__ = 'benjamin@overtag.dk'
__version__ = '0.3'
