Practicing an example of optimizing Python with C/C++. 
