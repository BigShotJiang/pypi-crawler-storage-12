from .DiversityIsAllYouNeed import DiversityIsAllYouNeed
from .SoftActorCritic import SoftActorCritic
from .TQC import TQC
from .DQN import DQN
from .DRQN import DRQN
from .utils import soft_update
