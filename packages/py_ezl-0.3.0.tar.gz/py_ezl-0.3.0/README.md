```bash
pip install py-ezl

# or if you are smart 
uv add py-ezl
```

minimal ETL framework