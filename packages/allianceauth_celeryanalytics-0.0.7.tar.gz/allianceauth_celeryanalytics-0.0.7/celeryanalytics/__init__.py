"""
Celery Task and Worker Analytics for Alliance Auth
"""
__version__ = "0.0.7"
__title__ = "CeleryAnalytics"
