"Modern-DI-LiteStar"
==

Integration of [Modern-DI](https://github.com/modern-python/modern-di) to LiteStar

📚 [Documentation](https://modern-di.readthedocs.io)
