"""wlater MCP Server - Read-only Google Keep access for AI assistants."""

__version__ = "0.1.0"
