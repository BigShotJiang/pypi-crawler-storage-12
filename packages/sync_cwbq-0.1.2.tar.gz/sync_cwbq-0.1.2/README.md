# 数据同步

同步mongodb数据到数仓