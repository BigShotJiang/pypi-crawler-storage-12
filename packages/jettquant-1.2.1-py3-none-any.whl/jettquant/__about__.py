# SPDX-FileCopyrightText: 2025-present jett <jett2025ab@outlook.com>
#
# SPDX-License-Identifier: MIT
__version__ = "1.2.1"
__author__ = "jett"
