from __future__ import annotations

"""
Common Types
"""
