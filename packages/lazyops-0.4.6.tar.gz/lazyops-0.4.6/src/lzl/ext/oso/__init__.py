"""
Oso Module with some additional functionalities
"""

from .errors import OsoException, ForbiddenError, NotFoundError
from .base import Oso

