# Extractous Extension

This extension wraps around the [Extractous](https://github.com/yobix-ai/extractous/tree/main) that provides some additional utilities and type checking for the Extractous API.

