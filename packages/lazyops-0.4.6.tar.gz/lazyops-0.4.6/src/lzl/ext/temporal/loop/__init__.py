"""
Temporal Loop Extension

Original Source: https://github.com/ant31/temporal-loop
Credits: https://github.com/ant31
"""

