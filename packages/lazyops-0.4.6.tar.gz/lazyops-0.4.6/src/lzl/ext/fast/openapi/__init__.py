"""
FastAPI Extensions: OpenAPI Documentation Generators

Supported: 
- `scalar`
"""

from .scalar import Scalar