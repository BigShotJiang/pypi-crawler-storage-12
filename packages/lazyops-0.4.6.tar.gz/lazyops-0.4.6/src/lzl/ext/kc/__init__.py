"""
K8s Operator V2

- Requires `kr8s` package.
"""

