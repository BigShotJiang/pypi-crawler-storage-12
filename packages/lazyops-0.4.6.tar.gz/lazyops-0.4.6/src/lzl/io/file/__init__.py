from __future__ import annotations

"""
A Rewrite of the `fileio` library
"""

from .main import File, FileLike, PathLike