"""
SearxNG API Client
"""
