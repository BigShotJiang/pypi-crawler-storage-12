from __future__ import annotations

import typing as t
from lzl.api import aiohttpx
from lzl.api.searxng.models import ResultItem


"""
https://github.com/BrainBlend-AI/atomic-agents/blob/main/atomic-examples/orchestration-agent/orchestration_agent/tools/searxng_search.py
"""