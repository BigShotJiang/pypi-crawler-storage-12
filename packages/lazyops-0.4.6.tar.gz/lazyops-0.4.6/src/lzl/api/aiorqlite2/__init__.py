"""
RQLite Adapted from `pyrqlite`
"""

