"""
Modal Utilities
"""

from .types import ModalClass, NoStdStreams