from .base import BaseWorkflowContext

class WorkflowContext(BaseWorkflowContext):
    """
    The Workflow Context
    """
    pass