
CURRENT_VERSION = '{{ version }}'
LAST_VERSION = '{{ last_version }}'