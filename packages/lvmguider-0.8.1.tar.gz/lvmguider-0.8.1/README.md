# lvmguider

![Versions](https://img.shields.io/badge/python->3.10-blue)
[![Lint](https://github.com/sdss/lvmguider/actions/workflows/lint.yml/badge.svg)](https://github.com/sdss/lvmguider/actions/workflows/lint.yml)

A package for LVM guiding and focusing.
