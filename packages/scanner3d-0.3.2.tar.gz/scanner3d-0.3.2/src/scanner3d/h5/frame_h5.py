class FrameH5:
    VALUES        = "values"
    X_SEQ         = "x_seq"
    Y_SEQ         = "y_seq"
    Z             = "z"
    PROFILE       = "profile"
    GRID_META     = "grid_meta"
    FORMAT_VERSION = "format_version"