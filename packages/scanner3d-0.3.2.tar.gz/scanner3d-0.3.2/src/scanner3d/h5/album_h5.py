class AlbumH5:
    FRAMES = "frames"
    Z_SEQ = "z_seq"
    Z_VALUES = "values"
    Z_UNITS = "units"
    Z_DESC = "description"
    SCANNER = "scanner"
