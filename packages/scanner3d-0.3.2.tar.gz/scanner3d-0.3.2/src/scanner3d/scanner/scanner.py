from dataclasses import dataclass, field
from typing import Tuple
from scanner3d.camera3d import Camera3D



@dataclass(frozen=True, slots=True)
class Scanner:
    name: str
    cameras: Tuple["Camera3D", ...] = field(default_factory=tuple)