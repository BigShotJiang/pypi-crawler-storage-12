from __future__ import annotations
from dataclasses import dataclass
from zempy.zosapi.tools.general.enums.quick_focus_criterion import QuickFocusCriterion


@dataclass(frozen=True)
class QuickFocusSettings:
    criterion: QuickFocusCriterion = QuickFocusCriterion.SpotSizeRadial
    use_centroid: bool = True