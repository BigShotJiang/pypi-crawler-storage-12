# Funcnodes Pydantic

Funcnodes Pydantic exposes small, composable nodes that load, validate, inspect, and mutate [Pydantic](https://docs.pydantic.dev/) models inside FuncNodes graphs. It follows the Shelf/DAG patterns of funcnodes so workers can discover nodes automatically.
