History
=======

1.0.1 (2019-12-10)
------------------

* Include the certificate in the source package
* Use a bigger certificate

1.0.0 (2019-09-05)
------------------

* Dropped support for Python 2.7 and 3.4

0.6.0 - released as tag only
----------------------------

* Added fixture scope configuration.
* Added ``ftpserver_TLS`` as TLS version of the fixture.

0.5.0 (2018-12-04)
------------------

* Added support for Windows.
* Added hightlevel interface.

0.1.0 (2016-12-09)
------------------

* First release on PyPI.
