"""gustaf/gustaf/version.py.

Current version.
"""

version = "0.1.2"
