from supervision.assets.downloader import download_assets
from supervision.assets.list import VideoAssets

__all__ = ["VideoAssets", "download_assets"]
