'''An internal Django backend to wagtail-newsletter.

This is a simple, basic internal backend for wagtail-newsletter, allowing you to manage your mailing lists internally and send them out through Django's standard email capabilities.
'''

__version__ = '0.5.8'
