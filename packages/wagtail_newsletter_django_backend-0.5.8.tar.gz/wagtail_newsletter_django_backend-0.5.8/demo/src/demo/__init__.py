'''A demo site for wagtail-newsletter-django-backend.
'''

__version__ = '0.0.1'
