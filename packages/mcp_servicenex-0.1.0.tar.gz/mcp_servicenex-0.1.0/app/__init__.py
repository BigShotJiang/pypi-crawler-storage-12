"""
ServiceNex MCP Server

A Model Context Protocol server for accessing ServiceNex knowledge base and support tickets.
"""

__version__ = "1.0.0"

