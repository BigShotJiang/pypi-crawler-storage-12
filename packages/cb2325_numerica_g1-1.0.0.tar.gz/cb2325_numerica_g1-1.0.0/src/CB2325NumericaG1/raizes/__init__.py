#descomente essas linhas e coloque o nome das funcoes de vcs em func1 e func2
from .raizes_bissecao import bissecao
from .raizes_secante import secante
from .raizes_newton_raphson import newton_raphson