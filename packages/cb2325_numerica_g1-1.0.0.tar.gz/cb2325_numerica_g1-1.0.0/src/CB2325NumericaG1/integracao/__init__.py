#descomente essas linhas e coloque o nome das funcoes de vcs em func1 e func2
from .integracao_trapezio_simpson13 import trapezio, simpson13
from .integracao_estocastica import monte_carlo_one_variable, monte_carlo_two_variables 
