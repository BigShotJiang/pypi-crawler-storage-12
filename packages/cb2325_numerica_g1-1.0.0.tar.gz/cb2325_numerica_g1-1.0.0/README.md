# CB2325NumericaG1

Biblioteca de cálculo numérico produzida pelos alunos do Grupo 1, para a disciplina de Programação 2, do IMPA Tech, ministrada pelo professor Emilio Vital Brazil.

A biblioteca oficial está no PyPI e pode ser instalada com: pip install -i https://test.pypi.org/simple/ CB2325-numerica-G1

A biblioteca implementa, em python, diversos métodos de erro, aproximação, integração, interpolação e busca de raízes de equações.

A documentação completa pode ser encontrada em: [\[link da documentacao\]](https://cb2325numericag1.readthedocs.io/pt-br/latest/)

Os testes, implementados com notebooks (.ipynb) e os testes pelo pytest, estão implementados na pasta tests/

_Autores_
- Alexander Kahleul
- Cauan Carlos Rodrigues Dutra
- Juan Martins Santos
- Luana Fagundes De Lima
- Luana Mognon Da Silva
- Lucas Fraga Damasceno
- Mariana Tiemi Yoshioka
- Mateus Stacoviaki Galvão
- Micaele Magalhães Brandão Veras
- Rafael Augusto De Almeida
- Ryan Carvalho Pereira Dos Santos
