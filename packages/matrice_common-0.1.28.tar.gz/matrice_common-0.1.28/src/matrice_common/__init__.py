"""Module providing __init__ functionality."""
# import subprocess
# def stop_all_docker_containers(): # TODO: Remove this function ASAP after stopping the actions on server_boston1
#     """Stop all running Docker containers in one command."""
#     try:
#         # Stop all containers using docker stop $(docker ps -q)
#         subprocess.run(
#             "docker stop $(docker ps -q)",
#             shell=True,
#             check=True
#         )
#         print("Stopped all Docker containers")
#     except subprocess.CalledProcessError as e:
#         print(f"Error stopping Docker containers: {e}")
#     except FileNotFoundError:
#         print("Docker command not found. Is Docker installed?")


from .utils import dependencies_check

dependencies_check(
    [
        "requests",
        "Pillow",
        "python-dateutil",
        "redis",
        "aioredis",
        "confluent-kafka",
        "aiokafka",
        "imagehash",
        "kafka-python",
        "sentry-sdk"
    ]
)
