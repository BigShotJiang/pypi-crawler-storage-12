API-Doc
=======

.. autofunction:: resfo.lazy_read

.. autofunction:: resfo.read

.. autofunction:: resfo.write

.. autoclass:: resfo.Format

.. autoclass:: resfo.MESS

.. autoclass:: resfo.array_entry.ResArray
   :exclude-members: is_eof, parse
   :members:
