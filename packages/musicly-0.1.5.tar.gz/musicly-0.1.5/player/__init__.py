#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Terminal music player using YT-DLP and Just Playback
"""

__author__ = "Maria Kevin"
__version__ = "0.1.0"
