"""
允许通过 python -m intsig_mcp_atlassian 运行
"""

from intsig_mcp_atlassian import main

if __name__ == "__main__":
    main()
