from .document import Document, EmbeddedDocument

__all__ = ["Document", "EmbeddedDocument"]
