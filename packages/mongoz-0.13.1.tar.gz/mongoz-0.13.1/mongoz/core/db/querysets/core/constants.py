VALUE_EQUALITY = ["eq", "neq", "contains", "icontains", "pattern", "startswith", "endswith", "istartswith", "iendswith"]
LIST_EQUALITY = ["in", "not_in"]
ORDER_EQUALITY = ["asc", "desc"]
GREATNESS_EQUALITY = ["lt", "lte", "gt", "gte", "exists"]
