To use this module, you need to:

1.  Open a new session of the configured point of sale.
2.  You will see that you can print receipts before completing the
    sale.
