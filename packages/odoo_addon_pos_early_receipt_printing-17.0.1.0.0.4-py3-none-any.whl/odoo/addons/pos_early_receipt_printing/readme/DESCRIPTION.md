This module allows you to display the option to print bills from the POS
even if it is not a restaurant type.
