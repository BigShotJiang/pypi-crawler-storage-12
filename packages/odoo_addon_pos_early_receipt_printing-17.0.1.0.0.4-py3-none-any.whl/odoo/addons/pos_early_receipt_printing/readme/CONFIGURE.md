To configure this module, you need to:

1. Go to Point of Sale module.
2. Select the Point of Sale -> Settings.
3. Checks 'Early Receipt Printing'.
