"""Package for creating and manipulating graphs."""
