#!/usr/bin/env bash

pipx install uv
