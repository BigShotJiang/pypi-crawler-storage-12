# Grabpy

Simple respectful web scraper
