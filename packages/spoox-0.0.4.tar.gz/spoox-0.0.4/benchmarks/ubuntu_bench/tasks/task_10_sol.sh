# 1. remove 'sleep(8)' from my_function.py
cp -f /opt/sample_solution/my_function_under_4s.py ~/scripts/my_function.py

# 2. create a main program that uses my_function
sudo mv /opt/sample_solution/main /usr/local/bin/