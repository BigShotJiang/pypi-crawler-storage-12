"""Integration tests for CPPython examples."""
