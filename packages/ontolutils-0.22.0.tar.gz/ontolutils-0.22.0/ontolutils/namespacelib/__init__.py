"""Auto-generated file. Do not edit!"""
import sys

from . import __dev
from ._iana_utils import IANA
from .codemeta import CODEMETA
from .m4i import M4I
from .obo import OBO
from .qudt_kind import QUDT_KIND
from .qudt_unit import QUDT_UNIT
from .schema import SCHEMA
from .hdf5 import HDF5
from .spdx import SPDX
from ..cache import package_user_dir

sys.path.insert(0, str(package_user_dir))
