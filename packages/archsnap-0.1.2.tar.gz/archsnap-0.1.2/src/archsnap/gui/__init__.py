from .init_gui import init_gui

# Allow importing the init_gui function directly from the init_gui module
__all__ = ['init_gui']
