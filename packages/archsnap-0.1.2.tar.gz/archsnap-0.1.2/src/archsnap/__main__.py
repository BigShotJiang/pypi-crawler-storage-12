from archsnap.main import main

# This is the entry point for the ArchSnap application
if __name__ == '__main__':
    main()
