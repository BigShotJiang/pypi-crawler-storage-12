"""
Decision tree implementation for public domain validation.
This module handles structured decision tree workflows.
"""
from typing import Dict, Any, Optional
from datetime import datetime

from .utils.date_utils import calculate_pd_year, calculate_years_until_pd, is_in_public_domain
from .utils.result_builder import create_base_result, add_explanation, set_confidence
from .laws.country_law_manager import CountryLawManager


class DecisionTreeValidator:
    """
    Implements the public domain decision tree workflow as specified.
    Provides a structured approach to assess if a work is in the public domain
    based on various factors.
    """

    def __init__(self, country_law_manager: Optional[CountryLawManager] = None):
        """
        Initialize the DecisionTreeValidator.
        
        Args:
            country_law_manager: Optional country law manager.
                                If not provided, will create a default instance.
        """
        self.country_law_manager = country_law_manager or CountryLawManager()
    
    def assess_public_domain_status(
        self,
        title: str = "",
        author_death_year: int | None = None,
        publication_year: int | None = None,
        work_type: str = "individual",  # "individual", "corporate", "anonymous", "government"
        country: str = "worldwide",
        nationality: str = "worldwide",
        published_with_copyright_notice: bool = True,
        copyright_renewed: bool = True
    ) -> Dict[str, Any]:
        """
        Main entry point for the public domain decision tree assessment.

        Args:
            title: Title of the work
            author_death_year: Year the author died (for individual works)
            publication_year: Year of first publication
            work_type: Type of work ('individual', 'corporate', 'anonymous', 'government')
            country: Country of origin/publishing
            nationality: Author's nationality at time of creation/death
            published_with_copyright_notice: Whether work was published with copyright notice
            copyright_renewed: Whether copyright was renewed (for works 1928-1963 in US)

        Returns:
            Dictionary with PD status and detailed explanation following the decision tree
        """
        # Step 1: Determine Work Type
        classified_work_type = self._determine_work_type(title, work_type, publication_year)

        result = create_base_result()
        result["work_type_classified"] = classified_work_type
        add_explanation(result, f"Classified work type as: {classified_work_type}")

        # Step 2: Apply the main decision tree logic based on publication year and work type
        if publication_year is not None:
            # Branch: Decision Tree Branch 1: Works Published BEFORE 1923 (US Context) - these are clearly PD
            if country.upper() == "US" and publication_year < 1923:
                result = self._assess_pre_1928_publication(result, publication_year, country)

            # Branch: Decision Tree Branch 2: Works Published 1923-1977 (US Context - with 95-year rule)
            elif country.upper() == "US" and 1923 <= publication_year <= 1977:
                # If we have both publication and author death, use the dual-rule approach
                if author_death_year is not None:
                    result = self._assess_1928_1977_publication(
                        result, publication_year, author_death_year, country, copyright_renewed
                    )
                else:
                    # If only publication year, use the 95-year publication rule
                    pd_year = publication_year + 95
                    result["is_public_domain"] = is_in_public_domain(pd_year)
                    result["pd_year"] = pd_year
                    result["years_until_pd"] = calculate_years_until_pd(pd_year)
                    add_explanation(result,
                        f"US 1923-1977 rule with no author death data: Published in {publication_year}, copyright expires {pd_year} (95 years from publication). "
                        f"Currently {'in' if result['is_public_domain'] else 'not in'} public domain."
                    )
                    set_confidence(result, 85)

            # Branch: Decision Tree Branch 3: Works Created/Published AFTER 1977 (US Context - Life + 70)
            elif country.upper() == "US" and publication_year >= 1978:
                result = self._assess_post_1977_publication(
                    result, publication_year, author_death_year, work_type, country
                )

            # For non-US jurisdictions, use general copyright terms
            else:
                result = self._assess_non_us_publication(
                    result, publication_year, author_death_year, work_type, country, nationality
                )
        else:
            # No publication date - rely on author death date
            if author_death_year is not None:
                result = self._assess_by_author_death_date(
                    result, author_death_year, work_type, country, nationality
                )
            else:
                add_explanation(result, "Cannot determine public domain status without publication year or author death year")

        return result

    def _determine_work_type(self, title: str, provided_work_type: str, publication_year: int | None) -> str:
        """Determine the work type based on title, provided type, and publication year."""
        title_lower = title.lower()

        # Check for specific work types based on title and context
        if "anonymous" in title_lower or "pseudonymous" in title_lower:
            return "anonymous"
        elif "government" in title_lower or "federal" in title_lower:
            return "government"
        elif provided_work_type in ["individual", "corporate", "anonymous", "government", "joint"]:
            return provided_work_type
        elif publication_year and publication_year < 1900:
            return "historical_document"
        elif "film" in title_lower or "movie" in title_lower or "cinema" in title_lower:
            return "cinematographic"
        elif "music" in title_lower or "song" in title_lower or "composition" in title_lower:
            return "musical"
        elif "paint" in title_lower or "sculpture" in title_lower or "art" in title_lower:
            return "artistic"
        else:
            return "literary"  # Default to literary for books and similar

    def _assess_pre_1928_publication(self, result: Dict[str, Any], publication_year: int, country: str) -> Dict[str, Any]:
        """Assess works published before 1928 in the US context."""
        result["is_public_domain"] = True
        result["pd_year"] = publication_year
        add_explanation(result,
            f"Work published in {publication_year} in the US is in the public domain (published before 1928 threshold)"
        )
        set_confidence(result, 95)
        return result

    def _assess_1928_1977_publication(
        self,
        result: Dict[str, Any],
        publication_year: int,
        author_death_year: int | None,
        country: str,
        copyright_renewed: bool
    ) -> Dict[str, Any]:
        """Assess works published between 1928-1977 in the US context."""
        if 1928 <= publication_year <= 1963:
            if copyright_renewed:
                # Copyright term is 95 years from publication
                pd_year = publication_year + 95
                result["is_public_domain"] = is_in_public_domain(pd_year)
                result["pd_year"] = pd_year
                result["years_until_pd"] = calculate_years_until_pd(pd_year)
                add_explanation(result,
                    f"Work published {publication_year} in US (1928-1963) with copyright renewed. "
                    f"Expires in {pd_year} (95 years from publication). "
                    f"Currently {'in' if result['is_public_domain'] else 'not in'} public domain."
                )
                set_confidence(result, 90)
            else:
                # Copyright term expired (original term was 28 years, not renewed)
                pd_year = publication_year + 28  # Original term was 28 years
                result["is_public_domain"] = True  # Since 28 years passed long ago
                result["pd_year"] = pd_year
                add_explanation(result,
                    f"Work published {publication_year} in US (1928-1963) without copyright renewal. "
                    f"Original copyright expired in {pd_year}. Work is in public domain."
                )
                set_confidence(result, 95)
        elif 1964 <= publication_year <= 1977:
            # Copyright term is 95 years from publication (automatic renewal)
            pd_year = publication_year + 95
            result["is_public_domain"] = is_in_public_domain(pd_year)
            result["pd_year"] = pd_year
            result["years_until_pd"] = calculate_years_until_pd(pd_year)
            add_explanation(result,
                f"Work published {publication_year} in US (1964-1977) with automatic copyright renewal. "
                f"Expires in {pd_year} (95 years from publication). "
                f"Currently {'in' if result['is_public_domain'] else 'not in'} public domain."
            )
            set_confidence(result, 90)

        return result

    def _assess_post_1977_publication(
        self,
        result: Dict[str, Any],
        publication_year: int,
        author_death_year: int | None,
        work_type: str,
        country: str
    ) -> Dict[str, Any]:
        """Assess works published after 1977 in the US context."""
        if work_type == "individual":
            # Determine PD status based on author's death year plus 70 years
            if author_death_year:
                pd_year = calculate_pd_year(author_death_year, 70)  # +70 years after death
                result["is_public_domain"] = is_in_public_domain(pd_year)
                result["pd_year"] = pd_year
                result["years_until_pd"] = calculate_years_until_pd(pd_year)
                add_explanation(result,
                    f"Individual-authored work published in {publication_year}. "
                    f"Author died in {author_death_year}. Public domain at {pd_year} (life + 70). "
                    f"Currently {'in' if result['is_public_domain'] else 'not in'} public domain."
                )
                set_confidence(result, 90)
            else:
                # Without author death year, estimate based on publication
                years_since_publication = datetime.now().year - publication_year
                # We can't properly determine this without author death year in the post-1977 context
                add_explanation(result,
                    f"Individual-authored work published in {publication_year} after 1977. "
                    f"Cannot determine exact PD status without author death year."
                )
                set_confidence(result, 60)
        elif work_type == "anonymous" or work_type == "corporate":
            # For anonymous or corporate works: 95 years from publication OR 120 years from creation, whichever is shorter
            pd_by_pub = publication_year + 95
            pd_by_creation = publication_year + 120  # Assuming creation year is same as publication year
            pd_year = min(pd_by_pub, pd_by_creation)

            result["is_public_domain"] = is_in_public_domain(pd_year)
            result["pd_year"] = pd_year
            result["years_until_pd"] = calculate_years_until_pd(pd_year)
            add_explanation(result,
                f"{work_type.title()}-authored work published in {publication_year}. "
                f"Public domain at {pd_year} (95 years from publication or 120 years from creation, whichever is shorter). "
                f"Currently {'in' if result['is_public_domain'] else 'not in'} public domain."
            )
            set_confidence(result, 85)

        return result

    def _assess_non_us_publication(
        self,
        result: Dict[str, Any],
        publication_year: int,
        author_death_year: int | None,
        work_type: str,
        country: str,
        nationality: str
    ) -> Dict[str, Any]:
        """Assess publications in non-US jurisdictions and US when needed."""
        # Get copyright term for the specific country
        copyright_term = self.country_law_manager.get_copyright_term(country.upper(), nationality.upper())

        if work_type == "individual" and author_death_year:
            # Use life + copyright_term rule
            pd_year = calculate_pd_year(author_death_year, copyright_term)
            result["is_public_domain"] = is_in_public_domain(pd_year)
            result["pd_year"] = pd_year
            result["years_until_pd"] = calculate_years_until_pd(pd_year)
            add_explanation(result,
                f"Individual-authored work by {nationality} author, published in {publication_year} in {country}. "
                f"Author died in {author_death_year}. Public domain at {pd_year} (life + {copyright_term}). "
                f"Currently {'in' if result['is_public_domain'] else 'not in'} public domain."
            )
            set_confidence(result, 85)
        elif publication_year:
            # Handle special publication rules for US
            if country.upper() == "US":
                # Check for US works published before 1923 (should be PD)
                if publication_year < 1923:
                    result["is_public_domain"] = True
                    result["pd_year"] = publication_year
                    add_explanation(result,
                        "Published before 1923 in the US (now in public domain)")
                    set_confidence(result, 95)
                    return result
                # Check for US works published 1923-1977 (95 years from publication)
                elif 1923 <= publication_year <= 1977:
                    # For US works 1923-1977, it's 95 years from publication regardless of author death
                    pd_year = publication_year + 95
                    result["is_public_domain"] = is_in_public_domain(pd_year)
                    result["pd_year"] = pd_year
                    result["years_until_pd"] = calculate_years_until_pd(pd_year)
                    add_explanation(result,
                        f"US 1923-1977 rule: Published in {publication_year}, copyright expires {pd_year} (95 years from publication). "
                        f"{'Public domain' if result['is_public_domain'] else 'Still under copyright'}.")
                    set_confidence(result, 90)
                    return result

            # For non-US or other US cases, use publication-based term with standard copyright term
            pd_year = publication_year + copyright_term
            result["is_public_domain"] = is_in_public_domain(pd_year)
            result["pd_year"] = pd_year
            result["years_until_pd"] = calculate_years_until_pd(pd_year)
            add_explanation(result,
                f"Work published in {publication_year} in {country}. "
                f"Copyright term is {copyright_term} years. Public domain at {pd_year}. "
                f"Currently {'in' if result['is_public_domain'] else 'not in'} public domain."
            )
            set_confidence(result, 75)
        else:
            add_explanation(result,
                f"Cannot determine PD status for work from {country}/{nationality} without publication or death year."
            )
            set_confidence(result, 40)

        return result

    def _assess_by_author_death_date(
        self,
        result: Dict[str, Any],
        author_death_year: int,
        work_type: str,
        country: str,
        nationality: str
    ) -> Dict[str, Any]:
        """Assess PD status based on author death date."""
        # Get copyright term for the specific country
        copyright_term = self.country_law_manager.get_copyright_term(country.upper(), nationality.upper())

        pd_year = calculate_pd_year(author_death_year, copyright_term)

        result["is_public_domain"] = is_in_public_domain(pd_year)
        result["pd_year"] = pd_year
        result["years_until_pd"] = calculate_years_until_pd(pd_year)

        add_explanation(result,
            f"Individual-authored work by {nationality} author. "
            f"Author died in {author_death_year}. Public domain at {pd_year} (life + {copyright_term}). "
            f"Currently {'in' if result['is_public_domain'] else 'not in'} public domain."
        )

        if work_type == "government":
            # Government works in some jurisdictions are immediately in public domain
            if country.upper() == "US":
                result["is_public_domain"] = True
                result["pd_year"] = author_death_year  # Government works are immediately PD
                add_explanation(result,
                    f"Work created by US federal government employee is in public domain by law."
                )
                set_confidence(result, 95)
            elif country.upper() in ["UK", "CA", "AU"]:
                # These jurisdictions have crown copyright with different terms
                # For simplicity here, we'll note it but use the standard term
                pass

        set_confidence(result, 85)
        return result