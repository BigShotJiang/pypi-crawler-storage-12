# flake8: noqa

# import apis into api package
from wink_sdk_analytics.api.affiliate_api import AffiliateApi
from wink_sdk_analytics.api.analytics_api import AnalyticsApi

