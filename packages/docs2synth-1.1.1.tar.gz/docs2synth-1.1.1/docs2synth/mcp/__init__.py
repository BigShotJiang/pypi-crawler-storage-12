"""MCP provider integration for Docs2Synth."""

from .server import build_server

__all__ = ["build_server"]
