"""Human annotation tools for QA pairs."""

from docs2synth.annotation.data_manager import AnnotationDataManager

__all__ = ["AnnotationDataManager"]
