from enum import Enum;


class MeasurementType(Enum):
    XRD = 0