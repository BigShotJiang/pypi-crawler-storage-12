

class UnequalSequenceLength(Exception):
    pass;