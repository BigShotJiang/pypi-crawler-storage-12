# Measurement

This package defines the entities, value objects and services that are central to the measurement domain.