from baseapp_core.tests.settings import *  # noqa
