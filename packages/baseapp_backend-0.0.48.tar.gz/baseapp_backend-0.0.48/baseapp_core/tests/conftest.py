from baseapp_core.graphql.testing.fixtures import *  # noqa

from .fixtures import *  # noqa
