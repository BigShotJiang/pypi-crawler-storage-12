from .object_types import CommentsInterface  # noqa
