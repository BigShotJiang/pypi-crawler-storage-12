from .utils import send_notification  # noqa

default_app_config = "baseapp_notifications.apps.NotificationsConfig"
