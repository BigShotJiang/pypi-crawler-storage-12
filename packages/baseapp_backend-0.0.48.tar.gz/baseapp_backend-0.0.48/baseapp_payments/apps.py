from django.apps import AppConfig


class PackageConfig(AppConfig):
    name = "baseapp_payments"
    label = "baseapp_payments"
