import baseapp_e2e.tests.factories as f

f.ModeFactory()
