from baseapp_core.graphql.testing.fixtures import *  # noqa
from baseapp_core.tests.fixtures import *  # noqa
