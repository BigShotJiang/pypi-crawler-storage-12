from playwright.sync_api import Page, TimeoutError as PWTimeoutError
from typing import Optional, Sequence, Dict
from .exceptions import PublishError
from .utils.log import get_logger
import time
import random

logger = get_logger("facebook_posting")

def _rand(min_s=1, max_s=3) -> float:
    """Delay aleatorio en segundos para simular interacción humana."""
    return float(random.randint(min_s, max_s))

def _rand_ms(min_ms=50, max_ms=100) -> int:
    """Delay aleatorio en milisegundos para tipeo en el editor."""
    return random.randint(min_ms, max_ms)

def _open_create_post(page: Page) -> None:
    """Abre el compositor de publicaciones en el contexto actual."""
    selector = 'div[role="button"] >> text=Escribe algo...'
    page.wait_for_selector(selector, timeout=8000)
    page.locator(selector).first.click()
    time.sleep(_rand())

def _find_file_input(page: Page):
    """Encuentra el input de archivos para adjuntar multimedia."""
    inp = page.locator('input[type="file"][multiple]')
    inp.wait_for(state="attached", timeout=5000)
    return inp

def publish(page: Page, text: str, photos: Optional[Sequence[str]] = None) -> bool:
    """Publica texto y multimedia en el contexto actual.

    Args:
        page: Página Playwright activa.
        text: Texto de la publicación.
        photos: Rutas de archivos a adjuntar.
    Returns:
        True si se confirma la publicación.
    Raises:
        PublishError: Si no se confirma el envío de la publicación.
    """
    logger.info("[Post] Iniciando publicación...")
    _open_create_post(page)

    if photos:
        try:
            foto_btn = page.get_by_role("button", name="Foto/video").first
            foto_btn.click()
        except Exception:
            page.locator('div[aria-label="Foto/video"][role="button"]').first.click()

        inp = _find_file_input(page)
        inp.set_input_files(list(photos))
        time.sleep(_rand(1, 2))

    editor = page.locator('div[role="textbox"][contenteditable="true"][aria-placeholder="Crea una publicación pública..."]')
    editor.wait_for(state="visible", timeout=8000)
    editor.click()
    editor.type(text, delay=_rand_ms())

    pub_btn = page.locator('div[aria-label="Publicar"][role="button"]').first
    pub_btn.click()
    time.sleep(_rand())
    try:
        page.wait_for_selector('div[aria-label="Publicar"][role="button"]', state="detached", timeout=10000)
        logger.info("[Post] Publicación enviada.")
        time.sleep(_rand())
        return True
    except PWTimeoutError:
        raise PublishError("No se confirmó la publicación")

def publish_to_groups(page: Page, group_urls: Sequence[str], text: str, photos: Optional[Sequence[str]] = None, delay_between: Optional[float] = None) -> Dict[str, dict]:
    """Publica en múltiples grupos y devuelve resultados por grupo.

    Args:
        page: Página Playwright activa.
        group_urls: URLs de grupos destino.
        text: Texto de la publicación.
        photos: Rutas de archivos a adjuntar.
        delay_between: Delay entre publicaciones en segundos.
    Returns:
        Diccionario `{url: {"ok": bool, "error"?: str}}`.
    """
    logger.info(f"[MultiPost] Publicando en {len(group_urls)} grupos...")
    results: Dict[str, dict] = {}
    for url in group_urls:
        try:
            from .groups import enter_group_by_url
            enter_group_by_url(page, url)
            page.wait_for_load_state('networkidle')
            ok = publish(page, text, photos)
            page.go_back()
            time.sleep(delay_between or _rand())
            results[url] = {"ok": ok}
        except Exception as e:
            logger.info(f"[MultiPost] Error publicando en {url}: {e}")
            results[url] = {"ok": False, "error": str(e)}
    return results
