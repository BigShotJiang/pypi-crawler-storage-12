# Python Examples

## 1. Start the Producer

Navigate to the `python_examples` directory and run:

```bash
python producer.py
```

## 2. Start the Consumer

Still in the `python_examples` directory, run the consumer using a separate terminal:

```bash
python consumer.py
```

Here's how the output should look (show images of the output):
![Output Sample](example_screenshot.png)
