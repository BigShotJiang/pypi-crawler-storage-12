/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Distributed under BSD 3-Clause license.                                   *
 * Copyright by The HDF Group.                                               *
 * Copyright by the Illinois Institute of Technology.                        *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of Hermes. The full Hermes copyright notice, including  *
 * terms governing use, modification, and redistribution, is contained in    *
 * the COPYING file, which can be found at the top directory. If you do not  *
 * have access to the file, you may request a copy from help@hdfgroup.org.   *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef WRP_CTE_ABSTRACT_MAPPER_H
#define WRP_CTE_ABSTRACT_MAPPER_H

#include "chimaera/chimaera.h"

namespace wrp::cae {

/**
 * Define different types of mappers supported by POSIX Adapter.
 * Also define its construction in the MapperFactory.
 */
enum class MapperType {
  kBalancedMapper
};

/**
 A structure to represent BLOB placement
*/
struct BlobPlacement {
  size_t page_;       /**< The index in the array placements */
  size_t bucket_off_; /**< Offset from file start (for FS) */
  size_t blob_off_;   /**< Offset from BLOB start */
  size_t blob_size_;  /**< Size after offset to read */

  /** create a BLOB name from index. */
  static chi::string CreateBlobName(size_t page) {
    chi::string buf(sizeof(page));
    hipc::LocalSerialize srl(buf);
    srl << page;
    return buf;
  }

  /** create a BLOB name from index. */
  chi::string CreateBlobName() const {
    chi::string buf(sizeof(page_));
    hipc::LocalSerialize srl(buf);
    srl << page_;
    return buf;
  }

  /** decode \a blob_name BLOB name to index.  */
  template<typename StringT>
  void DecodeBlobName(const StringT &blob_name, size_t page_size) {
    hipc::LocalDeserialize srl(blob_name);
    srl >> page_;
    bucket_off_ = page_ * page_size;
    blob_off_ = 0;
  }
};

typedef std::vector<BlobPlacement> BlobPlacements;

/**
   A class to represent abstract mapper
*/
class AbstractMapper {
 public:
  /** Virtual destructor */
  virtual ~AbstractMapper() = default;

  /**
   * This method maps the current operation to Hermes data structures.
   *
   * @param off offset
   * @param size size
   * @param page_size the page division factor
   * @param ps BLOB placement
   *
   */
  virtual void map(size_t off, size_t size, size_t page_size,
                   BlobPlacements &ps) = 0;
};
}  // namespace wrp::cae

#endif  // WRP_CTE_ABSTRACT_MAPPER_H
