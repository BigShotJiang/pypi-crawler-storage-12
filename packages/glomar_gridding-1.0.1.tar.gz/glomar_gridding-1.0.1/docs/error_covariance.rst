Error Covariance
----------------

.. automodule:: glomar_gridding.error_covariance
   :members:
