# spellcheckers

Check images (or text) for spelling errors using OpenAI Vision.


## Usage

```python

from spellcheckers import check_image, check_text

result = check_image("file.png", api_key="sk-...")
print(result)  # True = reject (spelling error). False = accept.

result = check_text("This is a test.", api_key="sk-...")
print(result)  # True = reject (spelling error). False = accept.

```
