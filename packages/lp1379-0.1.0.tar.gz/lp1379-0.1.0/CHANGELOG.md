# Changelog

## 0.1.0 (2025-11-14)


### Features

* importable rust function ([da79800](https://github.com/WardDeb/listening_post_1379/commit/da79800194f76e417374670fc1203e8f6a07b95b))
