"""IriusRisk CLI - A command line interface for IriusRisk API v2."""

__version__ = "0.1.0"
