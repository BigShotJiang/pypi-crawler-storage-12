from osbot_utils.helpers.html.tags.Tag__Base import Tag__Base


class Tag__HR(Tag__Base):
    tag_name    = 'hr'