========
Database
========

The `django_marina.db` module contains database related extensions.

.. autoclass:: django_marina.db.models.ProtectedModelMixin

.. autoclass:: django_marina.db.migrations.DisableMigrations