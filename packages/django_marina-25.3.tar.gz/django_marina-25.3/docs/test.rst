====
Test
====

The `test` module offers extra functions for unit tests.

.. autoclass:: django_marina.test.clients.ExtendedClient
   :members:

.. autoclass:: django_marina.test.test_cases.ExtendedTestCase
   :members:

.. autoclass:: django_marina.test.runners.TempMediaDiscoverRunner
