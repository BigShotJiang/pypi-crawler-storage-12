The dbt Cloud CLI, powered by dbt Cloud, allows you to develop and run dbt commands against your dbt Cloud development environment from your local command line.

**[dbt](https://www.getdbt.com/)** enables data analysts and engineers to transform their data using the same practices that software engineers use to build applications.

## Get started
This package installs the dbt Cloud CLI, which allows you to run dbt commands against your dbt Cloud development environment from your local command line.

- [Install the dbt Cloud CLI](https://docs.getdbt.com/docs/cloud/cloud-cli-installation)
- Read the [introduction](https://docs.getdbt.com/docs/introduction/) and [viewpoint](https://docs.getdbt.com/docs/about/viewpoint/)

## Understanding dbt

Analysts using dbt can transform their data by simply writing select statements, while dbt handles turning these statements into tables and views in a data warehouse.

These select statements, or "models", form a dbt project. Models frequently build on top of one another – dbt makes it easy to [manage relationships](https://docs.getdbt.com/docs/ref) between models, and [visualize these relationships](https://docs.getdbt.com/docs/documentation), as well as assure the quality of your transformations through [testing](https://docs.getdbt.com/docs/testing).

dbt Cloud is the fastest and most reliable way to deploy dbt. Develop using the dbt Cloud CLI or browser-based IDE, test, schedule, and investigate data models in a unified web-based UI. It also offers a hosted architecture. Learn more about [dbt Cloud features](https://docs.getdbt.com/docs/cloud/about-cloud/dbt-cloud-features) and try one of the [quickstarts](https://docs.getdbt.com/docs/get-started-dbt).

![dbt Explorer DAG](https://github.com/dbt-labs/dbti/assets/89008547/94c4d31b-6fa2-46e6-b0d7-77f77d32f9df)

## Join the dbt Community

- Be part of the conversation in the [dbt Community Slack](http://community.getdbt.com/)
- Read more on the [dbt Community Discourse](https://discourse.getdbt.com)
