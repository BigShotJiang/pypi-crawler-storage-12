Sedona Configuration
====================

The sedona_configuration module provides functions for configuring and initializing Apache Sedona.

.. automodule:: libadalina_core.sedona_configuration
   :members:
   :show-inheritance:
