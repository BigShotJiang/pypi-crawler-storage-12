Readers
=======

The readers module provides functions for reading geospatial data from various sources.

.. automodule:: libadalina_core.readers
   :members:
   :show-inheritance: