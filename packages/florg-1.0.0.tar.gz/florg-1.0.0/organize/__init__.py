"""CLI Batch File Renamer/Organizer"""

__version__ = "1.0.0"


