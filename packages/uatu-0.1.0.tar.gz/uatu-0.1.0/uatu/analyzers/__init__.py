"""Pattern analyzers for detecting common system issues."""
