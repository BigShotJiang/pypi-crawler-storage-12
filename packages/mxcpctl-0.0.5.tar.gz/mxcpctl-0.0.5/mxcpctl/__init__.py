"""mxcpctl - CLI tool for MXCP instance management."""

__version__ = "0.1.0"
