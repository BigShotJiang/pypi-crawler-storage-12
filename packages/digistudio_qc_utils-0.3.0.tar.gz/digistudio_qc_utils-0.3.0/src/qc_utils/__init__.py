"""qc-utils: CLI utilities for QFieldCloud (upload to GCP, clean old files, etc.)."""

__version__ = "0.1.0"
