"""
Odoo MCP Server - MCP Server for Odoo Integration
"""
