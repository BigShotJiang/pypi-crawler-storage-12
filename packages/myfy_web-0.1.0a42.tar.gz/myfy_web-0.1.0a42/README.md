# myfy-web

Web/HTTP module for the myfy framework.

Provides FastAPI-like routing with DI-powered handlers.

See the [main README](../../README.md) for documentation.
