function(element, attributeName) {    let value = element.getAttribute(attributeName);    return value === '' ? 'true' : value;}
// sourceURL=__InjectedScript_WebDriver_GetElementAttribute.js
