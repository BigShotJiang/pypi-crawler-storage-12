
class StopLoopException(Exception):
    """This raise the errror when due numerical precision zoro rates are non-zero but very close to zero."""
    pass