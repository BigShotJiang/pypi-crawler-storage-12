"""
World3 module.
"""
from .world3 import World3
