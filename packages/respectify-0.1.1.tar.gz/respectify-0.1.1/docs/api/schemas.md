# Schemas

Pydantic schemas for all Respectify API responses.

```{eval-rst}
.. automodule:: respectify.schemas
   :members:
   :undoc-members:
   :show-inheritance:
```