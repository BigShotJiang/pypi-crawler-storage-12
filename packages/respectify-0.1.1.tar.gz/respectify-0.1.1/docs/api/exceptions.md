# Exceptions

Exception classes for handling Respectify API errors.

```{eval-rst}
.. automodule:: respectify.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
```