import json
import logging
import os
from typing import Any, Dict, Optional, Union

logger = logging.getLogger("processcube.configuration")

from ..helpers import str2bool


# Sentinel value to distinguish "no default provided" from "default is None"
class _NoDefault:
    """Sentinel class to indicate no default value was provided."""

    pass


NO_DEFAULT = _NoDefault()


class Config:
    """
    Configuration management with hierarchical access and environment variable overrides.

    Supports reading configuration from dictionaries, files (JSON), or strings.
    Can override values from environment variables.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize Config with a dictionary.

        Args:
            config: Configuration dictionary.
        """
        if not isinstance(config, dict):
            raise TypeError(f"Config must be a dictionary, got {type(config).__name__}")
        self._config = config

    def get(self, *parts: str, default: Any = NO_DEFAULT) -> Any:
        """
        Get a configuration value using hierarchical key path.

        Supports both dictionary-based access and environment variable fallback.

        Args:
            *parts: Hierarchical path to the configuration value (e.g., 'db', 'host', 'url')
            default: Default value if configuration key is not found.
                    If not provided and key is missing, raises AssertionError.

        Returns:
            The configuration value, or default if provided and key is not found.

        Raises:
            AssertionError: If configuration is empty or required key is missing and no default provided.
            TypeError: If configuration is not a dictionary at an intermediate level.

        Example:
            >>> config = Config({'db': {'host': 'localhost', 'port': 5432}})
            >>> config.get('db', 'host')
            'localhost'
            >>> config.get('db', 'password', default='secret')
            'secret'
        """
        if not isinstance(self._config, dict):
            raise AssertionError(f"Configuration is not a dictionary: {self._config}")

        if not parts:
            raise ValueError("At least one configuration key part must be provided")

        # Try to get value from nested dictionary
        current_value = self._config
        path_str = "->".join(parts)

        for i, part in enumerate(parts):
            # If current value is not a dict, we can't navigate deeper
            if not isinstance(current_value, dict):
                if default is not NO_DEFAULT:
                    return default

                remaining_path = "->".join(parts[i:])
                raise AssertionError(
                    f"Cannot access '{remaining_path}' - intermediate value is not a dictionary. "
                    f"Full path: {path_str}, Current value type: {type(current_value).__name__}"
                )

            # Check if key exists in dictionary
            if part in current_value:
                current_value = current_value[part]
            else:
                # Try environment variable as fallback
                env_value = self.get_from_env(*parts[: i + 1])
                if env_value is not None:
                    return env_value

                # No key and no env var
                if default is not NO_DEFAULT:
                    return default

                # Construct helpful error message
                available_keys = (
                    list(current_value.keys())
                    if isinstance(current_value, dict)
                    else []
                )
                raise AssertionError(
                    f"Configuration key '{part}' not found in {path_str}. "
                    f"Available keys: {available_keys}. "
                    f"Also checked environment variable: {':'.join(parts[:i + 1]).upper()}"
                )

        return current_value

    @staticmethod
    def get_from_env(*parts: str) -> Optional[str]:
        """
        Get a configuration value from an environment variable.

        Environment variable names are constructed by joining parts with a separator
        (default ':') and converting to uppercase.

        Args:
            *parts: Key path parts to construct environment variable name.

        Returns:
            Environment variable value, or None if not set.

        Example:
            >>> os.environ['DB:HOST'] = 'db.example.com'
            >>> Config.get_from_env('db', 'host')
            'db.example.com'
        """
        if not parts:
            return None

        sep = os.environ.get("CONFIG_ENV_SEP", ":")
        env_var_name = sep.join(parts).upper()
        return os.environ.get(env_var_name)

    @staticmethod
    def override_from_env() -> bool:
        """
        Check if configuration overrides from environment variables are enabled.

        Returns:
            True if CONFIG_OVERRIDE_FROM_ENV is set to a truthy value (default: True).
        """
        return str2bool(os.environ.get("CONFIG_OVERRIDE_FROM_ENV", "True"))

    @staticmethod
    def from_env(env_name: str = "CONFIG_FILE") -> "Config":
        """
        Load configuration from a file path specified in an environment variable.

        Args:
            env_name: Name of the environment variable containing the config file path.
                     Defaults to 'CONFIG_FILE'.

        Returns:
            Config instance loaded from the file.

        Raises:
            AssertionError: If the environment variable is not set or file doesn't exist.
        """
        filename = os.environ.get(env_name)

        if filename is None:
            raise AssertionError(
                f"Environment variable '{env_name}' is not set. "
                f"Please set it to point to a valid configuration file."
            )

        return Config.from_file(filename)

    @staticmethod
    def from_file(filename: str) -> "Config":
        """
        Load configuration from a JSON file.

        Args:
            filename: Path to the JSON configuration file.

        Returns:
            Config instance loaded from the file.

        Raises:
            AssertionError: If the file doesn't exist or is not a regular file.
            json.JSONDecodeError: If the file is not valid JSON.
            IOError: If the file cannot be read.
        """
        if not os.path.isfile(filename):
            raise AssertionError(
                f"Configuration file not found or is not a regular file: {filename}"
            )

        try:
            with open(filename, "r") as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            raise AssertionError(f"Invalid JSON in configuration file {filename}: {e}")
        except IOError as e:
            raise AssertionError(f"Cannot read configuration file {filename}: {e}")

        if not isinstance(data, dict):
            raise AssertionError(
                f"Configuration file must contain a JSON object (dictionary), got {type(data).__name__}"
            )

        return Config(data)

    @staticmethod
    def from_json_str(json_string: str) -> "Config":
        """
        Load configuration from a JSON string.

        Args:
            json_string: JSON string containing the configuration.

        Returns:
            Config instance loaded from the string.

        Raises:
            json.JSONDecodeError: If the string is not valid JSON.
            AssertionError: If the parsed JSON is not a dictionary.
        """
        if not json_string:
            raise ValueError("Configuration JSON string cannot be empty")

        try:
            data = json.loads(json_string)
        except json.JSONDecodeError as e:
            raise AssertionError(f"Invalid JSON in configuration string: {e}")

        if not isinstance(data, dict):
            raise AssertionError(
                f"Configuration must be a JSON object (dictionary), got {type(data).__name__}"
            )

        return Config(data)
