import logging

from processcube_sdk.configuration.config_accessor import ConfigAccessor

logger = logging.getLogger("processcube.debugging")

# Global flag to ensure debugger is only started once
_debugger_started = False


def start_debugging() -> None:
    """
    Start the debugpy debugger based on configuration.

    Reads debugging configuration from environment variables:
    - DEBUGGING_ENABLED: Enable/disable debugging (default: False)
    - DEBUGGING_HOSTNAME: Hostname to listen on (default: 'localhost')
    - DEBUGGING_PORT: Port to listen on (default: 5678)
    - DEBUGGING_WAIT_FOR_CLIENT: Wait for debugger client to connect (default: False)
    - DEBUGGING_LOG_TO: Log output destination (default: 'stdout')

    This function is safe to call multiple times; it will only start the debugger once.
    """
    global _debugger_started

    # Only start debugger once
    if _debugger_started:
        logger.debug("Debugger already started, skipping initialization")
        return

    _debugger_started = True

    # Load configuration
    ConfigAccessor.ensure_from_env()
    debugging_enabled = ConfigAccessor.current().get(
        "debugging", "enabled", default=False
    )

    logger.info(f"Debugging is enabled: {debugging_enabled}")

    if not debugging_enabled:
        logger.debug("Debugging is disabled, skipping debugger setup")
        return

    # Import debugpy only if debugging is enabled
    try:
        import debugpy
    except ImportError as e:
        logger.error(
            f"Failed to import debugpy: {e}. "
            "Please install it with: pip install debugpy"
        )
        return

    # Get debugging configuration
    hostname: str = ConfigAccessor.current().get(
        "debugging", "hostname", default="localhost"
    )
    port: int = ConfigAccessor.current().get("debugging", "port", default=5678)
    wait_for_client: bool = ConfigAccessor.current().get(
        "debugging", "wait_for_client", default=False
    )

    # Setup debugger listener
    logger.info(f"Setting up debugger listener on {hostname}:{port}")
    try:
        debugpy.listen((hostname, port))
    except Exception as e:
        logger.error(f"Failed to start debugpy listener: {e}")
        return

    # Wait for client if configured
    if wait_for_client:
        logger.info("Debugging: waiting for client to connect...")
        try:
            debugpy.wait_for_client()
            logger.info("Debugging: client connected")
        except Exception as e:
            logger.error(f"Error while waiting for debugger client: {e}")
    else:
        logger.info(
            "Debugging: running without waiting for client connection. "
            "You can connect to the debugger at any time and set breakpoints."
        )
