"""
FastAPI utilities for ProcessCube SDK.

Provides authentication and authorization utilities for FastAPI applications,
including OAuth2-based Google authentication and authorization.
"""
