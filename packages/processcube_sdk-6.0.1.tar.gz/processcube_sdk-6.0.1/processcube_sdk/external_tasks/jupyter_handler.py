"""Jupyter notebook handler for external tasks."""

import logging
import os
from dataclasses import dataclass
from typing import Any, Dict, Optional

from processcube_sdk.jupyter import NotebookRunner

from .base_handler import BaseHandler

logger = logging.getLogger("processcube.external_tasks")


@dataclass
class JupyterConfig:
    """Configuration for Jupyter notebook execution.

    Attributes:
        notebooks_path: Path to directory containing notebook files.
        notebook_name: Name of the notebook to execute (without .ipynb extension).
        temp_path: Temporary directory for storing executed notebook outputs.
    """

    notebooks_path: str
    notebook_name: str
    temp_path: str


class JupyterHandler(BaseHandler):
    """
    External task handler that executes Jupyter notebooks.

    Executes parameterized notebooks using Papermill and extracts
    results using Scrapbook for return to the process engine.
    """

    def __init__(
        self,
        topic: str = "jupyter_notebook",
        jupyter_config: Optional[JupyterConfig] = None,
    ) -> None:
        """
        Initialize the Jupyter handler.

        Args:
            topic: The topic/type of external task. Defaults to 'jupyter_notebook'.
            jupyter_config: Configuration for notebook execution paths.

        Raises:
            ValueError: If jupyter_config is None.
        """
        super().__init__(topic)

        if jupyter_config is None:
            logger.error("JupyterConfig is required for JupyterHandler")
            raise ValueError("jupyter_config parameter is required")

        self._jupyter_config: JupyterConfig = jupyter_config
        logger.debug(
            f"Initialized JupyterHandler for topic '{topic}' with config: "
            f"notebooks_path={jupyter_config.notebooks_path}, "
            f"notebook_name={jupyter_config.notebook_name}"
        )

    def get_input_filename(self) -> str:
        """
        Get the full path to the input notebook file.

        Returns:
            Absolute path to the notebook file (.ipynb).

        Raises:
            ValueError: If notebook file doesn't exist.
        """
        notebook_name = self._jupyter_config.notebook_name
        notebooks_path = self._jupyter_config.notebooks_path

        input_filename = os.path.join(notebooks_path, f"{notebook_name}.ipynb")

        if not os.path.exists(input_filename):
            logger.error(f"Notebook file not found: {input_filename}")
            raise ValueError(f"Notebook file not found: {input_filename}")

        logger.debug(f"Resolved input filename: {input_filename}")
        return input_filename

    def prepare_parameters(self, **additional_parameters: Any) -> Dict[str, Any]:
        """
        Prepare parameters for notebook execution.

        Args:
            **additional_parameters: Parameters to pass to the notebook.

        Returns:
            Dictionary of prepared parameters.
        """
        parameters: Dict[str, Any] = {}
        parameters.update(additional_parameters)
        logger.debug(f"Prepared {len(parameters)} parameters for notebook execution")
        return parameters

    def handle_task(
        self, payload: Dict[str, Any], task: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Execute a Jupyter notebook with task payload as parameters.

        Args:
            payload: Task payload containing parameters for the notebook.
            task: Optional task metadata (included in notebook parameters).

        Returns:
            Dictionary of notebook results extracted via scrapbook.

        Raises:
            ValueError: If notebook execution fails or required files missing.
        """
        try:
            logger.debug(
                f"Starting Jupyter notebook execution for topic '{self.get_topic()}'"
            )

            input_filename = self.get_input_filename()

            # Prepare parameters from payload
            parameters = self.prepare_parameters(**payload)
            parameters["task"] = task

            # Execute notebook
            temp_path = self._jupyter_config.temp_path
            runner = NotebookRunner(temp_path)

            logger.debug(f"Executing notebook: {input_filename}")
            runner.execute(input_filename, parameters)

            # Extract results
            results = runner.result_to_dict()
            logger.info(
                f"Successfully executed notebook '{self._jupyter_config.notebook_name}' "
                f"with {len(results)} results"
            )

            return results

        except Exception as e:
            logger.error(
                f"Failed to execute notebook '{self._jupyter_config.notebook_name}': {e}",
                exc_info=True,
            )
            raise
