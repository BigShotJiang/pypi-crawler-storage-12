import logging
from typing import List, Optional, Dict, Any

from processcube_sdk.configuration import ConfigAccessor
from processcube_client.external_task import ExternalTaskClient

logger = logging.getLogger("processcube.external_tasks")


def start_external_task(
    handler_factories: List,
    loop: Optional[Any] = None,
    identity: Optional[str] = None,
    session: Optional[Any] = None,
    options: Optional[Dict[str, Any]] = None,
    run_forever: bool = True,
    **kwargs,
) -> None:
    """
    Start external task worker(s) with full parameter support.

    Args:
        handler_factories: List of handler factories to create external task handlers
        loop: Optional event loop for async operations
        identity: Optional identity/credentials for the external task client
        session: Optional session object for HTTP client
        options: Optional options dict for subscribe_to_external_task_for_topic
        run_forever: Whether to run the client blocking (True) or non-blocking (False)
        **kwargs: Additional keyword arguments passed to ExternalTaskClient
    """
    ConfigAccessor.ensure_from_env()
    config = ConfigAccessor.current()

    engine_url = config.get("engine", "url")

    # Create client with all supported parameters
    client_kwargs = kwargs.copy()
    if loop is not None:
        client_kwargs["loop"] = loop
    if identity is not None:
        client_kwargs["identity"] = identity
    if session is not None:
        client_kwargs["session"] = session

    client = ExternalTaskClient(engine_url, **client_kwargs)

    # Default options if not provided
    if options is None:
        options = {}

    for factory in handler_factories:
        handler = factory.create_external_task(config)

        logger.info(f"Starting external task worker for topic '{handler.get_topic()}'")

        # Subscribe with options support
        subscribe_kwargs = options.copy()
        if loop is not None and "loop" not in subscribe_kwargs:
            subscribe_kwargs["loop"] = loop

        client.subscribe_to_external_task_for_topic(
            handler.get_topic(), handler, subscribe_kwargs
        )

    # Start client with run_forever control
    client.start(run_forever=run_forever)
