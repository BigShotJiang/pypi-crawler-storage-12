"""Handler for checking running process instances."""

import logging
from typing import Any, Dict, Optional

from processcube_client.core.api import Client, ProcessInstanceQueryRequest

from ...configuration import Config
from ...oauth.identity_provider import IdentityProvider
from ..base_handler import BaseHandler

# Default engine URL for local development
DEFAULT_ENGINE_URL = "http://localhost:56100"

logger = logging.getLogger(__name__)


class CheckRunningProcessInstanceHandler(BaseHandler):
    """
    External task handler that checks for running instances of a process model.

    Queries the process engine to determine if other instances of the same
    process model are currently running, useful for orchestrating process flows.
    """

    def __init__(self, config: Config) -> None:
        """
        Initialize the handler.

        Args:
            config: ProcessCube SDK configuration object.

        Raises:
            TypeError: If config is not a Config instance.
        """
        super().__init__("check_running_process_instance")
        self._engine_url = config.get("engine", "url", default=DEFAULT_ENGINE_URL)
        self._config = config
        logger.debug(
            f"Initialized CheckRunningProcessInstanceHandler with engine URL: {self._engine_url}"
        )

    def handle_task(
        self, payload: Dict[str, Any], task: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Check for other running instances of a process model.

        Queries the process engine for running instances of the specified
        process model, excluding the current instance.

        Args:
            payload: Task payload (unused for this handler).
            task: Task metadata containing processModelId and processInstanceId.

        Returns:
            Dictionary with other_instance structure containing:
            - running: True if other instances are running
            - not_running: True if no other instances are running
            - count: Number of other running instances
            - error_message: Error message if query failed

        Raises:
            KeyError: If task is missing required processModelId or processInstanceId.
        """
        if task is None:
            logger.error(
                "Task metadata is required for CheckRunningProcessInstanceHandler"
            )
            raise ValueError("task parameter is required")

        process_model_id = task.get("processModelId", "unknown")
        process_instance_id = task.get("processInstanceId", "unknown")

        logger.debug(
            f"Checking running instances for process_model_id='{process_model_id}', "
            f"process_instance_id='{process_instance_id}'"
        )

        running = False
        other_instance_count = 0
        error_message = ""

        try:
            # Query for running instances of this process model
            query = ProcessInstanceQueryRequest(
                process_model_id=process_model_id, state="running"
            )

            # Create API client with optional identity
            api_client = Client(self._engine_url, identity=self.get_identity())
            result = api_client.process_instance_query(query)

            # Filter out the current instance
            filtered_result = [
                entry
                for entry in result
                if entry.process_instance_id != process_instance_id
            ]

            other_instance_count = len(filtered_result)
            running = other_instance_count > 0

            logger.debug(
                f"Found {other_instance_count} other running instances "
                f"for process_model_id='{process_model_id}'"
            )

        except Exception as e:
            msg = f"Failed to query running process instances: {e}"
            logger.error(msg, exc_info=True)
            error_message = msg
            running = True  # Assume other instances might be running on error

        other_instance_result = {
            "other_instance": {
                "running": running,
                "not_running": not running,
                "count": other_instance_count,
                "error_message": error_message,
            }
        }

        logger.info(
            f"Process model '{process_model_id}' instance '{process_instance_id}': "
            f"other_instances_running={running}, count={other_instance_count}"
        )

        return other_instance_result

    def get_identity(self) -> Optional[IdentityProvider]:
        """
        Get identity provider for authenticated API calls.

        Loads OAuth2 identity provider configuration from configuration and creates
        an IdentityProvider instance if external_task_worker config exists.

        Returns:
            IdentityProvider instance if configured, None otherwise.

        Raises:
            KeyError: If external_task_worker config is incomplete.
        """
        try:
            # Check if external task worker config exists
            worker_config = self._config.get("external_task_worker", default={})

            if not worker_config:
                logger.debug(
                    "No external_task_worker configuration found, using unauthenticated client"
                )
                return None

            # Load OAuth2 credentials from config
            authority_url = self._config.get("external_task_worker", "authority_url")
            client_name = self._config.get("external_task_worker", "client_name")
            client_secret = self._config.get("external_task_worker", "client_secret")
            client_scopes = self._config.get("external_task_worker", "client_scopes")

            logger.debug(f"Creating IdentityProvider for client: {client_name}")

            identity_provider = IdentityProvider(
                authority_url, client_name, client_secret, client_scopes
            )

            return identity_provider

        except KeyError as e:
            logger.warning(f"Incomplete external_task_worker configuration: {e}")
            return None
        except Exception as e:
            logger.error(f"Failed to create identity provider: {e}", exc_info=True)
            return None


def create_external_task(config: Config) -> BaseHandler:
    """
    Factory function to create a CheckRunningProcessInstanceHandler.

    Args:
        config: ProcessCube SDK configuration object.

    Returns:
        CheckRunningProcessInstanceHandler instance.

    Raises:
        TypeError: If config is not a Config instance.
    """
    if not isinstance(config, Config):
        raise TypeError(f"config must be a Config instance, got {type(config)}")

    logger.debug("Creating CheckRunningProcessInstanceHandler")
    handler = CheckRunningProcessInstanceHandler(config)

    return handler
