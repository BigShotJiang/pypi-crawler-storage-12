import logging
import sys
from typing import Optional

from ..configuration.config_accessor import ConfigAccessor

# Default log format template
DEFAULT_LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


def setup_logging(
    default_log_level: int = logging.INFO,
    log_format: Optional[str] = None,
    stream: Optional[object] = None,
) -> logging.Logger:
    """
    Configure logging for the ProcessCube SDK application.

    Reads logging configuration from the current configuration instance.
    Supports configuration overrides via environment variables.

    Configuration keys:
    - logging:level: Log level as string ('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL')
                     Default: 'INFO'

    Args:
        default_log_level: Default logging level if not configured.
                          Defaults to logging.INFO.
        log_format: Custom log format string using Python logging format.
                   If None, uses DEFAULT_LOG_FORMAT.
                   Format: '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        stream: Output stream for logging (sys.stdout, sys.stderr, etc).
               Defaults to sys.stderr (standard Python logging default).

    Returns:
        The configured root logger instance.

    Raises:
        AssertionError: If configuration cannot be loaded (ConfigAccessor not initialized).
        ValueError: If the log level specified in config is invalid.

    Example:
        >>> logger = setup_logging()
        >>> logger.info("Application started")

        >>> logger = setup_logging(default_log_level=logging.DEBUG)
        >>> logger.debug("Debug message")
    """
    # Ensure configuration is loaded
    ConfigAccessor.ensure_from_env()
    config = ConfigAccessor.current()

    # Get log level from configuration
    try:
        logging_level_str = config.get("logging", "level", default="info")
    except Exception as e:
        # If logging config doesn't exist, use default
        logging_level_str = "info"

    # Convert string to logging level constant
    try:
        log_level = getattr(logging, logging_level_str.upper())
    except AttributeError:
        # Invalid log level string
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        raise ValueError(
            f"Invalid logging level '{logging_level_str}'. "
            f"Must be one of: {', '.join(valid_levels)}"
        )

    # Use provided format or default
    if log_format is None:
        log_format = DEFAULT_LOG_FORMAT

    # Configure basic logging with the specified parameters
    logging.basicConfig(
        level=log_level,
        format=log_format,
        stream=stream or sys.stderr,
        force=True,  # Force reconfiguration even if logging was already configured
    )

    # Get and return the root logger
    root_logger = logging.getLogger()

    # Log that logging was configured
    root_logger.debug(f"Logging configured with level: {logging_level_str.upper()}")

    return root_logger
