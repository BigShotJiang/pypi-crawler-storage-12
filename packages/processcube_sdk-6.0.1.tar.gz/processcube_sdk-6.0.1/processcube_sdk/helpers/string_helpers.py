"""String utility functions for ProcessCube SDK."""

from typing import Union


def str2bool(value: Union[str, bool, None]) -> bool:
    """
    Convert a string representation to a boolean value.

    Args:
        value: String value to convert ("yes", "true", "t", "1" for True).
               Also handles boolean and None inputs directly.

    Returns:
        bool: True if value is one of the truthy strings, False otherwise.

    Examples:
        >>> str2bool("yes")
        True
        >>> str2bool("true")
        True
        >>> str2bool("false")
        False
        >>> str2bool(None)
        False
        >>> str2bool(True)
        True
    """
    # Handle boolean and None inputs directly
    if isinstance(value, bool):
        return value
    if value is None:
        return False

    # Handle string inputs
    if isinstance(value, str):
        return value.lower() in ("yes", "true", "t", "1")

    return False
