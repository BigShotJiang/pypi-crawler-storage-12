import logging


root_logger = logging.getLogger("regex_automata")
