from setuptools import setup

# actual metadata in pyproject.toml
if __name__ == "__main__":
    setup()
