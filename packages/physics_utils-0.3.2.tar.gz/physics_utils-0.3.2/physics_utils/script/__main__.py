from . import main
from sys import argv

if __name__ == "__main__":
    main.main(argv)