============
Installation
============

At the command line::

    $ pip install mistral-lib

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv mistral-lib
    $ pip install mistral-lib
