=====
Usage
=====

To use mistral-lib in a project::

    import mistral_lib
