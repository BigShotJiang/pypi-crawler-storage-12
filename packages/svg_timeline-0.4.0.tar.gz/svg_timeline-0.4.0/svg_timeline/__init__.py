""" the svg-timeline package """
__version__ = '0.2.2'
