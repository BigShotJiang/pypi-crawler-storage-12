from acai_aws.common.records.requirements import requirements as msk_requirements


requirements = msk_requirements
