The subdirectory of this directory contains a build of the WASI Preview 1
component adapter.  It was built from commit `ab5a4484` of
https://github.com/bytecodealliance/wasmtime
