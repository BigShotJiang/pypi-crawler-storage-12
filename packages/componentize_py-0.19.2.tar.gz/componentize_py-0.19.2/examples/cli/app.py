from wit_world import exports

class Run(exports.Run):
    def run(self) -> None:
        print("Hello, world!")
