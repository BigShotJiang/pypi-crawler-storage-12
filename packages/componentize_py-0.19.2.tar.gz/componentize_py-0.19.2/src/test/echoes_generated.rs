#![allow(warnings)]
include!(concat!(env!("OUT_DIR"), "/echoes_generated.rs"));
