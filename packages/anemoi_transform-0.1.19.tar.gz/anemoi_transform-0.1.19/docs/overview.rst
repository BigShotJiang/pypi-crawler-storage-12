##########
 Overview
##########

The aim of `anemoi-transform` is to have all data transformation
functions in one place, so they can be easily reused across different
anemoi projects. The same data transforms are used when creating
datasets with :ref:`anemoi-datasets <anemoi-datasets:index-page>` and
when running models with :ref:`anemoi-inference
<anemoi-inference:index-page>`.
