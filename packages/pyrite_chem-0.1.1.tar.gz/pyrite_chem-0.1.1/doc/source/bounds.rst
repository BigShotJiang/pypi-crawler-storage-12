
.. automodule:: pyrite.bounds
   :no-members:
   :no-inherited-members:
   :no-special-members:
