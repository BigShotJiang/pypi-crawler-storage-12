:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.PlantsPLP.</div>
   <div class="empty"></div>

get_step
=================================

.. currentmodule:: pyrite.scoring

.. automethod:: PlantsPLP.get_step