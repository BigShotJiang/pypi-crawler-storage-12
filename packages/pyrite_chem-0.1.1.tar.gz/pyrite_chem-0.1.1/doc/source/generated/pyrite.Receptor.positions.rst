:orphan:

.. raw:: html

   <div class="prename">pyrite.Receptor.</div>
   <div class="empty"></div>

pyrite.Receptor.positions
=========================

.. currentmodule:: pyrite

.. autoproperty:: Receptor.positions