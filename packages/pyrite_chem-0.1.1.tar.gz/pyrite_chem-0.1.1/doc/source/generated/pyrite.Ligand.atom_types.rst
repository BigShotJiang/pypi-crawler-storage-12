:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

pyrite.Ligand.atom_types
========================

.. currentmodule:: pyrite

.. autoproperty:: Ligand.atom_types