:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.dependencies.Dependency.</div>
   <div class="empty"></div>

compute
==============================================

.. currentmodule:: pyrite.scoring.dependencies

.. automethod:: Dependency.compute