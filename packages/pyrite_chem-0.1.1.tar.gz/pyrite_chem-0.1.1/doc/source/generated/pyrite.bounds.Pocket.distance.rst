:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Pocket.</div>
   <div class="empty"></div>

distance
=============================

.. currentmodule:: pyrite.bounds

.. automethod:: Pocket.distance