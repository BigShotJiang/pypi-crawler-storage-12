:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Bounds.</div>
   <div class="empty"></div>

squared_distance
=====================================

.. currentmodule:: pyrite.bounds

.. automethod:: Bounds.squared_distance