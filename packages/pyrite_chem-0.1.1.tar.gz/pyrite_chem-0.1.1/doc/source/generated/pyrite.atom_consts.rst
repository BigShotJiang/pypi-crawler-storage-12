﻿pyrite.atom\_consts
===================

.. automodule:: pyrite.atom_consts

   
   .. rubric:: Classes

   .. autosummary::
   
      Atom
      AtomType
   