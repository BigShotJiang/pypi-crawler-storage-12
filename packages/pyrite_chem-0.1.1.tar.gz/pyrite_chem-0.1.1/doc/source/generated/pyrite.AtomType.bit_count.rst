:orphan:

.. raw:: html

   <div class="prename">pyrite.AtomType.</div>
   <div class="empty"></div>

bit_count
=========================

.. currentmodule:: pyrite

.. automethod:: AtomType.bit_count