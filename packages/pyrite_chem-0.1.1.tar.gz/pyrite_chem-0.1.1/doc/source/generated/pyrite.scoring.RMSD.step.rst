:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.RMSD.</div>
   <div class="empty"></div>

step
========================

.. currentmodule:: pyrite.scoring

.. automethod:: RMSD.step