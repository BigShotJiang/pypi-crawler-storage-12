:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.RectangularBounds.</div>
   <div class="empty"></div>

transform_sample_to_2pi
=======================================================

.. currentmodule:: pyrite.bounds

.. automethod:: RectangularBounds.transform_sample_to_2pi