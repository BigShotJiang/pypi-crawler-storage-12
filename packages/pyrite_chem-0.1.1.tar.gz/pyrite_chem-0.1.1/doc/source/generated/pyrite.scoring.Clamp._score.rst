:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Clamp.</div>
   <div class="empty"></div>

_score
===========================

.. currentmodule:: pyrite.scoring

.. automethod:: Clamp._score