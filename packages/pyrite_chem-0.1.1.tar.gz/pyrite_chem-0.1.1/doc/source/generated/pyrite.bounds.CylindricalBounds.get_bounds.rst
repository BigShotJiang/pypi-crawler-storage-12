:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.CylindricalBounds.</div>
   <div class="empty"></div>

get_bounds
==========================================

.. currentmodule:: pyrite.bounds

.. automethod:: CylindricalBounds.get_bounds