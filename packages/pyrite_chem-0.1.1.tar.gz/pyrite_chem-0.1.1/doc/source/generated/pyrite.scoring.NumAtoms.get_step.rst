:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NumAtoms.</div>
   <div class="empty"></div>

get_step
================================

.. currentmodule:: pyrite.scoring

.. automethod:: NumAtoms.get_step