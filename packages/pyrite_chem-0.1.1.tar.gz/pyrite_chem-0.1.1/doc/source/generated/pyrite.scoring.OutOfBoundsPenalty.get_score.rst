:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.OutOfBoundsPenalty.</div>
   <div class="empty"></div>

get_score
===========================================

.. currentmodule:: pyrite.scoring

.. automethod:: OutOfBoundsPenalty.get_score