:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.ConstantTerm.</div>
   <div class="empty"></div>

clamp
=================================

.. currentmodule:: pyrite.scoring

.. automethod:: ConstantTerm.clamp