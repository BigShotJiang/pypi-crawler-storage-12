:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NonHydrophobic.</div>
   <div class="empty"></div>

get_step
======================================

.. currentmodule:: pyrite.scoring

.. automethod:: NonHydrophobic.get_step