:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

set_dihedral_angles
=================================

.. currentmodule:: pyrite

.. automethod:: Ligand.set_dihedral_angles