:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.InternalOverlap.</div>
   <div class="empty"></div>

get_step
=======================================

.. currentmodule:: pyrite.scoring

.. automethod:: InternalOverlap.get_step