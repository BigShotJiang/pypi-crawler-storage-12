:orphan:

.. raw:: html

   <div class="prename">pyrite.Viewer.</div>
   <div class="empty"></div>

add
=================

.. currentmodule:: pyrite

.. automethod:: Viewer.add