:orphan:

.. raw:: html

   <div class="prename">pyrite.AtomType.</div>
   <div class="empty"></div>

bit_length
==========================

.. currentmodule:: pyrite

.. automethod:: AtomType.bit_length