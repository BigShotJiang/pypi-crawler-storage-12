:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.CylindricalBounds.</div>
   <div class="empty"></div>

place_grid
==========================================

.. currentmodule:: pyrite.bounds

.. automethod:: CylindricalBounds.place_grid