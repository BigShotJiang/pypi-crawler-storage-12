﻿.. raw:: html

   <div class="prename">pyrite.scoring.dependencies.</div>
   <div class="empty"></div>

KDTreeCache
=======================================

.. currentmodule:: pyrite.scoring.dependencies


.. autoclass:: KDTreeCache
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         KDTreeCache.get_tree
      
  

  
  
  