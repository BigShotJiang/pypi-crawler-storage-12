:orphan:

.. raw:: html

   <div class="prename">pyrite.AtomType.</div>
   <div class="empty"></div>

pyrite.AtomType.Magnesium
=========================

.. currentmodule:: pyrite

.. autoattribute:: AtomType.Magnesium