:orphan:

.. raw:: html

   <div class="prename">pyrite.AtomType.</div>
   <div class="empty"></div>

pyrite.AtomType.NitrogenDonorAcceptor
=====================================

.. currentmodule:: pyrite

.. autoattribute:: AtomType.NitrogenDonorAcceptor