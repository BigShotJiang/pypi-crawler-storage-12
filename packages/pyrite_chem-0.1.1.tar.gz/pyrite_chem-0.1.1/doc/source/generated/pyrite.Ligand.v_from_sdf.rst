:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

v_from_sdf
========================

.. currentmodule:: pyrite

.. automethod:: Ligand.v_from_sdf