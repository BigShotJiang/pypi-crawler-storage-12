:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.dependencies.Dependency.</div>
   <div class="empty"></div>

merge_all
================================================

.. currentmodule:: pyrite.scoring.dependencies

.. automethod:: Dependency.merge_all