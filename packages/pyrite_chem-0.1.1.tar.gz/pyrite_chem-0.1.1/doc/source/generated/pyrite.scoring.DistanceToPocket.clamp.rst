:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.DistanceToPocket.</div>
   <div class="empty"></div>

clamp
=====================================

.. currentmodule:: pyrite.scoring

.. automethod:: DistanceToPocket.clamp