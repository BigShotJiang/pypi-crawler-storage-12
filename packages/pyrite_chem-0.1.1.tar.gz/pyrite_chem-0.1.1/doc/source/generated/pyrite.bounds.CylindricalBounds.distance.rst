:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.CylindricalBounds.</div>
   <div class="empty"></div>

distance
========================================

.. currentmodule:: pyrite.bounds

.. automethod:: CylindricalBounds.distance