:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Pocket.</div>
   <div class="empty"></div>

to_pqr
===========================

.. currentmodule:: pyrite.bounds

.. automethod:: Pocket.to_pqr