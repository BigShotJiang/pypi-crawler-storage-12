:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.protein._PLP.</div>
   <div class="empty"></div>

potential_two_piece
===============================================

.. currentmodule:: pyrite.scoring.protein

.. automethod:: _PLP.potential_two_piece