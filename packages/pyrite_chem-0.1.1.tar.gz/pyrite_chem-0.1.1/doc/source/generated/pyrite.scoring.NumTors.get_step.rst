:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NumTors.</div>
   <div class="empty"></div>

get_step
===============================

.. currentmodule:: pyrite.scoring

.. automethod:: NumTors.get_step