:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.dependencies.Dependency.</div>
   <div class="empty"></div>

group_key
================================================

.. currentmodule:: pyrite.scoring.dependencies

.. automethod:: Dependency.group_key