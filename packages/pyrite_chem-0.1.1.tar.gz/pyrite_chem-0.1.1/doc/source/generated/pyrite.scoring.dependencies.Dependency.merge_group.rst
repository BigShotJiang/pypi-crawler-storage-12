:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.dependencies.Dependency.</div>
   <div class="empty"></div>

merge_group
==================================================

.. currentmodule:: pyrite.scoring.dependencies

.. automethod:: Dependency.merge_group