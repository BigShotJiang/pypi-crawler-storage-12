:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Repulsion.</div>
   <div class="empty"></div>

_score
===============================

.. currentmodule:: pyrite.scoring

.. automethod:: Repulsion._score