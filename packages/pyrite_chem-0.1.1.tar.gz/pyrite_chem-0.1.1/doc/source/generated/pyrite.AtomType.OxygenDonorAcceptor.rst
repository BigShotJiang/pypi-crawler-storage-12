:orphan:

.. raw:: html

   <div class="prename">pyrite.AtomType.</div>
   <div class="empty"></div>

pyrite.AtomType.OxygenDonorAcceptor
===================================

.. currentmodule:: pyrite

.. autoattribute:: AtomType.OxygenDonorAcceptor