:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.RectangularBounds.</div>
   <div class="empty"></div>

is_within
=========================================

.. currentmodule:: pyrite.bounds

.. automethod:: RectangularBounds.is_within