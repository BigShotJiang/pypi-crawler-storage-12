:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.ConstantTerm.</div>
   <div class="empty"></div>

get_score
=====================================

.. currentmodule:: pyrite.scoring

.. automethod:: ConstantTerm.get_score