:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

transform
=======================

.. currentmodule:: pyrite

.. automethod:: Ligand.transform