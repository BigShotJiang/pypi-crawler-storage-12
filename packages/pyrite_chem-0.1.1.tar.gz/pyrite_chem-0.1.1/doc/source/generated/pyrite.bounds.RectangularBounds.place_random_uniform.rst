:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.RectangularBounds.</div>
   <div class="empty"></div>

place_random_uniform
====================================================

.. currentmodule:: pyrite.bounds

.. automethod:: RectangularBounds.place_random_uniform