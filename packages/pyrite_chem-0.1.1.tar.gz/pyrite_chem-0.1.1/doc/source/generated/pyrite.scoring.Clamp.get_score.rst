:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Clamp.</div>
   <div class="empty"></div>

get_score
==============================

.. currentmodule:: pyrite.scoring

.. automethod:: Clamp.get_score