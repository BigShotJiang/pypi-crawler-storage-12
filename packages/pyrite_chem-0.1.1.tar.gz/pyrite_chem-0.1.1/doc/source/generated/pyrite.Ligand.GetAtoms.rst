:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

GetAtoms
======================

.. currentmodule:: pyrite

.. automethod:: Ligand.GetAtoms