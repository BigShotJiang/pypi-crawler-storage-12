:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.protein._SlopeStep.</div>
   <div class="empty"></div>

get_score
===========================================

.. currentmodule:: pyrite.scoring.protein

.. automethod:: _SlopeStep.get_score