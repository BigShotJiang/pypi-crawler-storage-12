:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Pocket.</div>
   <div class="empty"></div>

transform_sample_to_bounds
===============================================

.. currentmodule:: pyrite.bounds

.. automethod:: Pocket.transform_sample_to_bounds