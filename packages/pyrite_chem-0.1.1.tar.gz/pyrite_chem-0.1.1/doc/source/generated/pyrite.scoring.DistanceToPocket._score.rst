:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.DistanceToPocket.</div>
   <div class="empty"></div>

_score
======================================

.. currentmodule:: pyrite.scoring

.. automethod:: DistanceToPocket._score