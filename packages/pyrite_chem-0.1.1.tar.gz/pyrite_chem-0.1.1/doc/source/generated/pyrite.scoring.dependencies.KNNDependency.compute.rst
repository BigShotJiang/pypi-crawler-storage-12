:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.dependencies.KNNDependency.</div>
   <div class="empty"></div>

compute
=================================================

.. currentmodule:: pyrite.scoring.dependencies

.. automethod:: KNNDependency.compute