:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.dependencies.KNNDependency.</div>
   <div class="empty"></div>

merge_group
=====================================================

.. currentmodule:: pyrite.scoring.dependencies

.. automethod:: KNNDependency.merge_group