:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Hydrophobic.</div>
   <div class="empty"></div>

_score
=================================

.. currentmodule:: pyrite.scoring

.. automethod:: Hydrophobic._score