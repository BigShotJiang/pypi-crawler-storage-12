:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.WeightedBoundsOverlap.</div>
   <div class="empty"></div>

_score
===========================================

.. currentmodule:: pyrite.scoring

.. automethod:: WeightedBoundsOverlap._score