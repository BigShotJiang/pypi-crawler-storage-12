﻿.. raw:: html

   <div class="prename">pyrite.scoring.</div>
   <div class="empty"></div>

Hydrophobic
==========================

.. currentmodule:: pyrite.scoring


.. autoclass:: Hydrophobic
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         Hydrophobic._score
         Hydrophobic.clamp
         Hydrophobic.get_dependencies
         Hydrophobic.get_score
         Hydrophobic.get_step
         Hydrophobic.step
      
         Hydrophobic._score
  

  
  
  