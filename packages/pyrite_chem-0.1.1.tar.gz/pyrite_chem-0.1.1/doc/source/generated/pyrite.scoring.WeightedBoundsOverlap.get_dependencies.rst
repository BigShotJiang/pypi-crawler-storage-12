:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.WeightedBoundsOverlap.</div>
   <div class="empty"></div>

get_dependencies
=====================================================

.. currentmodule:: pyrite.scoring

.. automethod:: WeightedBoundsOverlap.get_dependencies