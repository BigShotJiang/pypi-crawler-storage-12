:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Hydrophobic.</div>
   <div class="empty"></div>

get_dependencies
===========================================

.. currentmodule:: pyrite.scoring

.. automethod:: Hydrophobic.get_dependencies