:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.RectangularBounds.</div>
   <div class="empty"></div>

from_ligand
===========================================

.. currentmodule:: pyrite.bounds

.. automethod:: RectangularBounds.from_ligand