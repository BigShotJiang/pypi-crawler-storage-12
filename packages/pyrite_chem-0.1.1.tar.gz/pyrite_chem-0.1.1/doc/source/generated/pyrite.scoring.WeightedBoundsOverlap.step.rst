:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.WeightedBoundsOverlap.</div>
   <div class="empty"></div>

step
=========================================

.. currentmodule:: pyrite.scoring

.. automethod:: WeightedBoundsOverlap.step