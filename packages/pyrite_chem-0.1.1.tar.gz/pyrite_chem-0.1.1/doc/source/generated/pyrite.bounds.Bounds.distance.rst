:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Bounds.</div>
   <div class="empty"></div>

distance
=============================

.. currentmodule:: pyrite.bounds

.. automethod:: Bounds.distance