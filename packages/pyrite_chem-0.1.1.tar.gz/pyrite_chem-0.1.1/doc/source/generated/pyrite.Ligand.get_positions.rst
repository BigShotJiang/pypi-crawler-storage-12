:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

get_positions
===========================

.. currentmodule:: pyrite

.. automethod:: Ligand.get_positions