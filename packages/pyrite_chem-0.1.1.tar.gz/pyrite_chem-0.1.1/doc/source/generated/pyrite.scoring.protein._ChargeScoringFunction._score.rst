:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.protein._ChargeScoringFunction.</div>
   <div class="empty"></div>

_score
====================================================

.. currentmodule:: pyrite.scoring.protein

.. automethod:: _ChargeScoringFunction._score