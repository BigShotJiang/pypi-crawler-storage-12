:orphan:

.. raw:: html

   <div class="prename">pyrite.Viewer.</div>
   <div class="empty"></div>

add_v
===================

.. currentmodule:: pyrite

.. automethod:: Viewer.add_v