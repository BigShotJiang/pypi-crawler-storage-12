:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.protein._SlopeStep.</div>
   <div class="empty"></div>

clamp
=======================================

.. currentmodule:: pyrite.scoring.protein

.. automethod:: _SlopeStep.clamp