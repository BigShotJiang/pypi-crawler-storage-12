"""This is a minimum working example of a test framework."""


def greet(name: str) -> str:
    """Return a greeting message."""
    return f"Hello, {name}!"
