"""file-tree-display - A utility for generating a visually structured directory tree.
Copyright (c) 2025 Yaron Dayan
"""
