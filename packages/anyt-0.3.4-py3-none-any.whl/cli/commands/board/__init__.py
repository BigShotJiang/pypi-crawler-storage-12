"""Board and visualization commands.

Use direct imports:
    from cli.commands.board.commands import app, show_board, show_timeline
"""
