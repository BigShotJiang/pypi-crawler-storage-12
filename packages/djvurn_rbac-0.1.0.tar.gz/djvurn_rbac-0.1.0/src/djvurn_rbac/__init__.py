"""
Djvurn Rbac

RBAC with teams and DRF integration
"""

__version__ = "0.1.0"
__author__ = "Gojjo Tech"
__email__ = "dev@gojjo.tech"

default_app_config = "djvurn_rbac.apps.RbacConfig"
