"""Shared utilities for MCP services"""
