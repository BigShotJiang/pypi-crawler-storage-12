from typing import Optional

from ._version import __version__

TA_EPSILON: float = 1e-8
MIN_SAMPLES: Optional[int] = None
