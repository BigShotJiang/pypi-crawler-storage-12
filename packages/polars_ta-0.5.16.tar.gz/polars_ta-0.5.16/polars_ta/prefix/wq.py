from polars_ta.wq import *  # noqa
