"""I/O Registry"""

from .keyvalue_registry import KeyValueRegistry


class IORegistry(KeyValueRegistry):
    """Association I/O Registry"""
