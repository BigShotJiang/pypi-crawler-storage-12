.. _sdp-workflow:

================================
Science Data Processing Workflow
================================

General Workflow for Generating Association Products
====================================================

See :ref:`asn-associations-and-roman` for an overview of how Roman uses
associations. This document describes how associations are used by the
ground processing system to execute the stage 2 and stage 3 pipelines.
