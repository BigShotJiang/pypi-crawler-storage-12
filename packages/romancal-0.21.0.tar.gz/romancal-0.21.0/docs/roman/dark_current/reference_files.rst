Reference File
==============
The ``dark`` step uses a DARK reference file.

.. include:: ../references_general/dark_reffile.inc
