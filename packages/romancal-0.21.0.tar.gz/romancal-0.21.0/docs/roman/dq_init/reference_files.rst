Reference Files
===============
The ``dq_init`` step uses a MASK reference file.

A list of the allowed DQ values are:

.. include:: ../references_general/dq_flags.inc

.. include:: ../references_general/mask_reffile.inc
