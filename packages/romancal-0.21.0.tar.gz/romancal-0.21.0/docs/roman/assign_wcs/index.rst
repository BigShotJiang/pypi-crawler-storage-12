.. _assign_wcs_step:

==========
Assign WCS
==========

.. toctree::
   :maxdepth: 1

   main.rst

.. automodapi:: romancal.assign_wcs
