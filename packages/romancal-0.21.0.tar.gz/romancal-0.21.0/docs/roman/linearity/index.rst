.. _linearity_step:

====================
Linearity Correction
====================

.. toctree::
   :maxdepth: 2

   description.rst
   arguments.rst
   reference_files.rst

.. automodapi:: romancal.linearity
