Arguments
=========

The linearity correction has no step-specific arguments.
