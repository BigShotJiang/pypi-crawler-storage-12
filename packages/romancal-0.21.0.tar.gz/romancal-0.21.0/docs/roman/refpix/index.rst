.. _refpix:

==========================
Reference Pixel Correction
==========================

.. toctree::
   :maxdepth: 2

   description.rst
