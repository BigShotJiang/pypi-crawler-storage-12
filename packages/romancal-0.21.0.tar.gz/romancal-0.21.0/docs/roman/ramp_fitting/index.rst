.. _ramp_fitting_step:

============
Ramp Fitting
============

.. toctree::
   :maxdepth: 2

   ols-description.rst
   likelihood-description.rst
   arguments.rst
   reference_files.rst

.. automodapi:: romancal.ramp_fitting
