.. _flatfield_step:

====================
Flatfield Correction
====================
.. toctree::
   :maxdepth: 2

   main.rst
   reference_files.rst

.. automodapi:: romancal.flatfield
