RDA Python Package to gather and view data usage metrics.
