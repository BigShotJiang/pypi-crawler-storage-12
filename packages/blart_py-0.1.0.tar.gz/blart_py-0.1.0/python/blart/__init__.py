"""High-performance adaptive radix tree for Python."""

from blart._blart import PyTreeMap as TreeMap

__version__ = "0.1.0"
__all__ = ["TreeMap"]
