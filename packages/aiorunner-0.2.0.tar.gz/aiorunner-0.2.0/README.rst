=========
Aiorunner
=========

Handle signals and cleanup context.