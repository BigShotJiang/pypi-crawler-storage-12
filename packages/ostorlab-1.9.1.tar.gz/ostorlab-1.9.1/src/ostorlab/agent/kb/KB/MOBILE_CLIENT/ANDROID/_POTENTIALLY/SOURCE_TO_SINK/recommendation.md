Recommendation varies on the class of vulnerability identified.
