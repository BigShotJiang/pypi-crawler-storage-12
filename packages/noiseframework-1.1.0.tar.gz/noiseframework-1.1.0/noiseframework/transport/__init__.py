"""Transport layer for post-handshake encrypted communication."""
