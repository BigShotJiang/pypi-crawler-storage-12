# ESI notes

## extractions endpoint

- ESI will only return the currently active extractions of a corporation.
- Canceled and completed extractions are removed from the response.

## Notifications

- Moon notifications will not always show the core ore type for extractions, but not give any info about the ore quality => it is not possible to determine if an extraction was jackpot or not
