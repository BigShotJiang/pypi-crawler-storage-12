"""Python unit tests for sagemaker_jupyterlab_extension_common."""
