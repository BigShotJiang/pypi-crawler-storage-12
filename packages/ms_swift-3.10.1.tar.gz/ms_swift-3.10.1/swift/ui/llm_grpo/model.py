# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.model import Model


class GRPOModel(Model):
    group = 'llm_grpo'
