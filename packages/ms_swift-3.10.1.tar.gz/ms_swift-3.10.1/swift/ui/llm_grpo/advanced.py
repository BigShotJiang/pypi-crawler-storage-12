# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.advanced import Advanced


class GRPOAdvanced(Advanced):

    group = 'llm_grpo'
