# Copyright (c) Alibaba, Inc. and its affiliates.
from .app import webui_main
