# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.megatron import megatron_export_main

if __name__ == '__main__':
    megatron_export_main()
