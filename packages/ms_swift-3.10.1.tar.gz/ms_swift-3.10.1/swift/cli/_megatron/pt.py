# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.megatron import megatron_pt_main

if __name__ == '__main__':
    megatron_pt_main()
