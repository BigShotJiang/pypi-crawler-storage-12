# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.llm import deploy_main

if __name__ == '__main__':
    deploy_main()
