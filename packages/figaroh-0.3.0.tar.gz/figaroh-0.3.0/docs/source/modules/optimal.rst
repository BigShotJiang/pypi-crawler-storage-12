figaroh.optimal package
========================

.. automodule:: figaroh.optimal
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

figaroh.optimal.base_optimal_calibration module
------------------------------------------------

.. automodule:: figaroh.optimal.base_optimal_calibration
   :members:
   :undoc-members:
   :show-inheritance:

figaroh.optimal.base_optimal_trajectory module
-----------------------------------------------

.. automodule:: figaroh.optimal.base_optimal_trajectory
   :members:
   :undoc-members:
   :show-inheritance:
