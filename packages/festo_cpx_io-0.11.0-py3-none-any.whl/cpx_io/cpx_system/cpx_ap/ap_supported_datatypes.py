"""All implemented datatypes"""

SUPPORTED_DATATYPES = ["UINT16", "INT16", "UINT8", "INT8", "BOOL"]
SUPPORTED_IOL_DATATYPES = ["UINT8"]
SUPPORTED_ISDU_DATATYPES = [
    "str",
    "int",
    "uint",
    "sint",
    "raw",
    "bool",
    "float",
]
