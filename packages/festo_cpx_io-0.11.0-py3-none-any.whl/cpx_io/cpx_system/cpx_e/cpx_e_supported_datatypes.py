"""All implemented datatypes"""

SUPPORTED_ISDU_DATATYPES = [
    "str",
    "raw",
    "bool",
    "uint8",
    "uint16",
    "uint32",
    "int8",
    "int16",
    "int32",
    "float32",
]
