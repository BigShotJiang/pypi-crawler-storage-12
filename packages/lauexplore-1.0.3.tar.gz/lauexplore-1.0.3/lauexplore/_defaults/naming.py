

dataframe_name = {
    "intensity": "Intensity",
    "Intensity": "Intensity",
    "h": "h",
    "k": "k",
    "l": "l",
    "pixDev": "pixel dev",
    "PixDev": "pixel dev",
    "Energy": "Energy",
    "energy(keV)": "Energy",
    "Xexp": "Xexp",
    "Yexp": "Yexp",
    "2theta": "2θexp",
    "Chi": "χexp",
    "2theta_exp": "2θexp",
    "chi_exp": "χexp",
    "Xtheo": "Xtheo",
    "Ytheo": "Ytheo",
    "2theta_theo": "2θtheo",
    "chi_theo": "χtheo",
    "Qx": "Qx",
    "Qy": "Qy",
    "Qz": "Qz",
    "grainindex": "grain idx",
    "GrainIndex": "grain idx"
}