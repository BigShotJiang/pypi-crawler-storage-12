class YAMLFile:
    def __init__(self):
        raise RuntimeError("YAML file parsing is not implemented yet.")
