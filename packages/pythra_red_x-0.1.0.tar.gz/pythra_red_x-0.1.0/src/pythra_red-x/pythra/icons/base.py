# pythra/icons.py
# This file is auto-generated. Do not edit manually.

from dataclasses import dataclass

@dataclass(frozen=True)
class IconData:
    """An immutable data class representing an icon from a font."""
    name: str
    fontFamily: str