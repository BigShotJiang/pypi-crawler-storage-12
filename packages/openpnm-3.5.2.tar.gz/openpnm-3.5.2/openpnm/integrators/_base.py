__all__ = ['Integrator']


class Integrator:
    """Base class for integrators."""
    ...
