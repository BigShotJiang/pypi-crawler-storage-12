r"""
Throat Perimeter Models
-----------------------

This model contains a selection of functions for calcuating the
throat perimeter assuming a circular/square/rectangular cross-section

"""

from ._funcs import *
