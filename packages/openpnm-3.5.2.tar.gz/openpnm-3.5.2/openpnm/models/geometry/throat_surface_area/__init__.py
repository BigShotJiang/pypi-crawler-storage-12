r"""
Throat Surface Area Models
--------------------------

This model contains a selection of functions for calcuating the
throat surface area

"""

from ._funcs import *
