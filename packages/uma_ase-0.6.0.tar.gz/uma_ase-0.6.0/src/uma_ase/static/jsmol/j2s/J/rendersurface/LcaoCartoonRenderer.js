Clazz.declarePackage("J.rendersurface");
Clazz.load(["J.rendersurface.IsosurfaceRenderer"], "J.rendersurface.LcaoCartoonRenderer", null, function(){
var c$ = Clazz.declareType(J.rendersurface, "LcaoCartoonRenderer", J.rendersurface.IsosurfaceRenderer);
});
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
