Clazz.declarePackage("J.adapter.smarter");
Clazz.declareInterface(J.adapter.smarter, "MSInterface");
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
