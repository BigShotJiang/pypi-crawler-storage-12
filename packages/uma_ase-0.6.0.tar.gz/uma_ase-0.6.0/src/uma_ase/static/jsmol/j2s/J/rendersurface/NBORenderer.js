Clazz.declarePackage("J.rendersurface");
Clazz.load(["J.rendersurface.MolecularOrbitalRenderer"], "J.rendersurface.NBORenderer", null, function(){
var c$ = Clazz.declareType(J.rendersurface, "NBORenderer", J.rendersurface.MolecularOrbitalRenderer);
});
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
