Clazz.declarePackage("J.api");
Clazz.load(["J.api.FontManager"], "J.api.GenericPlatform", null, function(){
var c$ = Clazz.declareInterface(J.api, "GenericPlatform", J.api.FontManager);
});
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
