Clazz.declarePackage("J.api");
(function(){
var c$ = Clazz.declareInterface(J.api, "JmolDataManager");
})();
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
