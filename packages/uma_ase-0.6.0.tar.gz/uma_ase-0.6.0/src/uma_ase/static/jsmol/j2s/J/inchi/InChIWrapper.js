Clazz.declarePackage("J.inchi");
(function(){
var c$ = Clazz.declareType(J.inchi, "InChIWrapper", null);
})();
;//5.0.1-v4 Thu Feb 06 17:01:22 CST 2025
