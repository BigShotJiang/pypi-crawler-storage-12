Clazz.declarePackage("J.api.js");
Clazz.declareInterface(J.api.js, "JSmolAppletObject", javajs.api.js.JSAppletObject);
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
