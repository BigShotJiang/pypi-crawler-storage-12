Clazz.declarePackage("J.inchi");
Clazz.declareInterface(J.inchi, "InChIStructureProvider");
;//5.0.1-v4 Thu Feb 06 17:30:00 CST 2025
