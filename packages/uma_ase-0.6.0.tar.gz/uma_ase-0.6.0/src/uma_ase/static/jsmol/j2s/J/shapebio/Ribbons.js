Clazz.declarePackage("J.shapebio");
Clazz.load(["J.shapebio.BioShapeCollection"], "J.shapebio.Ribbons", null, function(){
var c$ = Clazz.declareType(J.shapebio, "Ribbons", J.shapebio.BioShapeCollection);
});
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
