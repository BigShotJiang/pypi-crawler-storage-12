Clazz.declarePackage("J.api");
Clazz.declareInterface(J.api, "GenericMouseInterface");
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
