Clazz.declarePackage("J.quantum");
Clazz.load(["J.quantum.QuantumCalculation"], "J.quantum.QuantumPlaneCalculation", null, function(){
var c$ = Clazz.declareType(J.quantum, "QuantumPlaneCalculation", J.quantum.QuantumCalculation);
});
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
