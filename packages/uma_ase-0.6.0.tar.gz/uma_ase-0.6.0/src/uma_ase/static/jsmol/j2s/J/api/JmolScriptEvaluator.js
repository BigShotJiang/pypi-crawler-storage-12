Clazz.declarePackage("J.api");
Clazz.declareInterface(J.api, "JmolScriptEvaluator");
;//5.0.1-v7 Mon Jul 28 06:27:19 CDT 2025
