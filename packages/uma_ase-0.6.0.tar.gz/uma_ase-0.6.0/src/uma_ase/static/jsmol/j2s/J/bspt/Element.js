Clazz.declarePackage("J.bspt");
(function(){
var c$ = Clazz.decorateAsClass(function(){
this.bspt = null;
this.count = 0;
Clazz.instantialize(this, arguments);}, J.bspt, "Element", null);
})();
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
