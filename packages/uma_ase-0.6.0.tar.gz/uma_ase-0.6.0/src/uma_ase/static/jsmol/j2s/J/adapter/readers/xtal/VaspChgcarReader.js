Clazz.declarePackage("J.adapter.readers.xtal");
Clazz.load(["J.adapter.readers.xtal.VaspPoscarReader"], "J.adapter.readers.xtal.VaspChgcarReader", null, function(){
var c$ = Clazz.declareType(J.adapter.readers.xtal, "VaspChgcarReader", J.adapter.readers.xtal.VaspPoscarReader);
});
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
