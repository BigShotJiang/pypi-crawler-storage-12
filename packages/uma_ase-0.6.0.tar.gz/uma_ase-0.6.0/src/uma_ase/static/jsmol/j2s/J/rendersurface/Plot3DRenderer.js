Clazz.declarePackage("J.rendersurface");
Clazz.load(["J.rendersurface.PmeshRenderer"], "J.rendersurface.Plot3DRenderer", null, function(){
var c$ = Clazz.declareType(J.rendersurface, "Plot3DRenderer", J.rendersurface.PmeshRenderer);
});
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
