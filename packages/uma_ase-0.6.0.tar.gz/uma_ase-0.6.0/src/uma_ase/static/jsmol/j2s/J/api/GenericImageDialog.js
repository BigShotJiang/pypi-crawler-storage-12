Clazz.declarePackage("J.api");
Clazz.declareInterface(J.api, "GenericImageDialog");
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
