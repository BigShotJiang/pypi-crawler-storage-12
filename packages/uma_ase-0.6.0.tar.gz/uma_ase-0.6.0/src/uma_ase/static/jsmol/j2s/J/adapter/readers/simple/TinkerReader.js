Clazz.declarePackage("J.adapter.readers.simple");
Clazz.load(["J.adapter.readers.simple.FoldingXyzReader"], "J.adapter.readers.simple.TinkerReader", null, function(){
var c$ = Clazz.declareType(J.adapter.readers.simple, "TinkerReader", J.adapter.readers.simple.FoldingXyzReader);
});
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
