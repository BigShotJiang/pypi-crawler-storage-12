Clazz.declarePackage("J.render");
Clazz.load(["J.render.FontLineShapeRenderer", "JU.P3", "$.P3i"], "J.render.LabelsRenderer", ["JM.Text", "J.render.TextRenderer", "JU.Font", "JV.JC"], function(){
var c$ = Clazz.decorateAsClass(function(){
this.minZ = null;
this.ascent = 0;
this.descent = 0;
this.sppa = 0;
this.xy = null;
this.screen = null;
this.fidPrevious = 0;
this.pTemp = null;
this.bgcolix = 0;
this.labelColix = 0;
this.fid = 0;
this.atom = null;
this.atomPt = null;
this.doPointer = 0;
this.offset = 0;
this.textAlign = 0;
this.pointer = 0;
this.zSlab = -2147483648;
this.zBox = 0;
this.boxXY = null;
this.scalePixelsPerMicron = 0;
this.mode = 0;
Clazz.instantialize(this, arguments);}, J.render, "LabelsRenderer", J.render.FontLineShapeRenderer);
Clazz.prepareFields (c$, function(){
this.minZ =  Clazz.newIntArray (1, 0);
this.xy =  Clazz.newFloatArray (3, 0);
this.screen =  new JU.P3i();
this.pTemp =  new JU.P3();
});
Clazz.defineMethod(c$, "setRenderVars", 
function(){
this.sppa = this.vwr.getScalePixelsPerAngstrom(true);
this.scalePixelsPerMicron = (this.vwr.getBoolean(603979847) ? this.sppa * 10000 : 0);
this.imageFontScaling = this.vwr.imageFontScaling;
});
Clazz.overrideMethod(c$, "render", 
function(){
this.fidPrevious = 0;
var labels = this.shape;
var labelStrings = labels.strings;
var fids = labels.fids;
var offsets = labels.offsets;
if (labelStrings == null) return false;
var atoms = this.ms.at;
var backgroundColixContrast = this.vwr.cm.colixBackgroundContrast;
var backgroundColor = this.vwr.getBackgroundArgb();
this.setRenderVars();
var iGroup = -1;
this.minZ[0] = 2147483647;
var isAntialiased = this.g3d.isAntialiased();
for (var i = labelStrings.length; --i >= 0; ) {
this.atomPt = this.atom = atoms[i];
if (!this.isVisibleForMe(this.atom)) continue;
var label = labelStrings[i];
if (label == null || label.length == 0 || labels.mads != null && labels.mads[i] < 0) continue;
this.labelColix = labels.getColix2(i, this.atom, false);
this.bgcolix = labels.getColix2(i, this.atom, true);
if (this.bgcolix == 0 && this.vwr.gdata.getColorArgbOrGray(this.labelColix) == backgroundColor) this.labelColix = backgroundColixContrast;
this.fid = ((fids == null || i >= fids.length || fids[i] == 0) ? labels.zeroFontId : fids[i]);
this.offset = (offsets == null || i >= offsets.length ? 0 : offsets[i]);
var labelsFront = ((this.offset & 32) != 0);
var labelsGroup = ((this.offset & 16) != 0);
this.textAlign = JV.JC.getAlignment(this.offset);
this.pointer = JV.JC.getPointer(this.offset);
this.doPointer = (this.pointer & 1);
var isAbsolute = this.offset & 64;
this.mode = (this.doPointer | isAbsolute | (isAntialiased ? 4 : 0));
this.zSlab = this.atom.sZ - Clazz.doubleToInt(this.atom.sD / 2) - 3;
if (this.zSlab < 1) this.zSlab = 1;
this.zBox = this.zSlab;
if (labelsGroup) {
var group = this.atom.group;
var ig = group.groupIndex;
if (ig != iGroup) {
group.getMinZ(atoms, this.minZ);
iGroup = ig;
}this.zBox = this.minZ[0];
} else if (labelsFront) {
this.zBox = 1;
}if (this.zBox < 1) this.zBox = 1;
var text = labels.getLabel(i);
this.boxXY = (!this.isExport || this.vwr.creatingImage ? labels.getBox(i) :  Clazz.newFloatArray (5, 0));
if (this.boxXY == null) labels.putBox(i, this.boxXY =  Clazz.newFloatArray (5, 0));
text = this.renderLabelOrMeasure(text, label);
if (text != null) {
labels.putLabel(i, text);
}if (isAntialiased) {
this.boxXY[0] /= 2;
this.boxXY[1] /= 2;
}this.boxXY[4] = this.zBox;
}
return false;
});
Clazz.defineMethod(c$, "renderLabelOrMeasure", 
function(text, label){
var newText = false;
var pointerColix = ((this.pointer & 2) != 0 && this.bgcolix != 0 ? this.bgcolix : this.labelColix);
if (text == null) {
var isLeft = (this.textAlign == 4 || this.textAlign == 0);
if (this.fid != this.fidPrevious || this.ascent == 0) {
this.vwr.gdata.setFont(JU.Font.getFont3D(this.fid));
this.fidPrevious = this.fid;
this.font3d = this.vwr.gdata.getFont3DCurrent();
if (isLeft) {
this.ascent = this.font3d.getAscent();
this.descent = this.font3d.getDescent();
}}var isSimple = isLeft && (this.imageFontScaling == 1 && this.scalePixelsPerMicron == 0 && label.indexOf("|") < 0 && label.indexOf("\n") < 0 && label.indexOf("<su") < 0 && label.indexOf("<co") < 0);
if (isSimple) {
this.boxXY[0] = this.atomPt.sX;
this.boxXY[1] = this.atomPt.sY;
J.render.TextRenderer.renderSimpleLabel(this.g3d, this.font3d, label, this.labelColix, this.bgcolix, this.boxXY, this.zBox, this.zSlab, JV.JC.getXOffset(this.offset), JV.JC.getYOffset(this.offset), this.ascent, this.descent, pointerColix, (this.doPointer == 0 ? 0 : this.vwr.getInt(553648147)), this.mode);
return null;
}text = JM.Text.newLabel(this.vwr, this.font3d, label, this.labelColix, this.bgcolix, this.textAlign, 0);
text.atomX = this.atomPt.sX;
text.atomY = this.atomPt.sY;
text.atomZ = this.zSlab;
text.setXYZs(this.atomPt.sX, this.atomPt.sY, this.zBox, this.zSlab);
newText = true;
} else {
if (text.font == null) text.setFontFromFid(this.fid);
text.atomX = this.atomPt.sX;
text.atomY = this.atomPt.sY;
text.atomZ = this.zSlab;
if (text.pymolOffset == null) {
text.setXYZs(this.atomPt.sX, this.atomPt.sY, this.zBox, this.zSlab);
text.colix = this.labelColix;
text.bgcolix = this.bgcolix;
} else {
text.getPymolScreenOffset(this.atomPt, this.screen, this.zSlab, this.pTemp, this.sppa);
}}if (text.pymolOffset == null) {
if (text.font == null) text.setFontFromFid(this.font3d.fid);
text.setOffset(this.offset);
if (this.textAlign != 0) text.setAlignment(this.textAlign);
}text.pointer = this.pointer;
this.renderText(text, null, pointerColix, this.mode);
return (newText ? text : null);
}, "JM.Text,~S");
Clazz.defineMethod(c$, "renderText", 
function(text, pTemp, pointerColix, mode){
return J.render.TextRenderer.render(this.vwr, text, this.g3d, this.scalePixelsPerMicron, this.imageFontScaling, this.boxXY, this.xy, pTemp, pointerColix, (this.doPointer == 0 ? 0 : this.vwr.getInt(553648147)), mode);
}, "JM.Text,JU.P3i,~N,~N");
});
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
