Clazz.declarePackage("J.api.js");
Clazz.declareInterface(J.api.js, "JmolToJSmolInterface", javajs.api.js.J2SObjectInterface);
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
