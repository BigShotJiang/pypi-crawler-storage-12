"""uma-ase: UMA machine-learning force fields wrapped with ASE tools."""

from __future__ import annotations

__all__ = [
    "__version__",
]

__version__ = "0.6.0"
