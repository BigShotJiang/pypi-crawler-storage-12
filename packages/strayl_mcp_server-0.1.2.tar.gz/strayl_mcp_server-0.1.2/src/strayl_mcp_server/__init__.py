"""Strayl MCP Server - MCP server for log search."""

__version__ = "0.1.0"
