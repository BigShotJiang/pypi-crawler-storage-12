class CompositeScheduleNotFoundError(Exception):
    pass


class ChargepointNotFoundError(Exception):
    pass
