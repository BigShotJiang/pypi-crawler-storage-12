import unittest
import inspect
import files_sdk
from tests.base import TestBase
from files_sdk.models import InvoiceLineItem
from files_sdk import invoice_line_item

class InvoiceLineItemTest(TestBase):
    pass 
    # Instance Methods

    # Static Methods
if __name__ == '__main__':
    unittest.main()