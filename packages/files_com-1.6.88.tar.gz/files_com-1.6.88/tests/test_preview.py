import unittest
import inspect
import files_sdk
from tests.base import TestBase
from files_sdk.models import Preview
from files_sdk import preview

class PreviewTest(TestBase):
    pass 
    # Instance Methods

    # Static Methods
if __name__ == '__main__':
    unittest.main()