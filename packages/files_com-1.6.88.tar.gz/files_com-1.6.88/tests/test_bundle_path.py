import unittest
import inspect
import files_sdk
from tests.base import TestBase
from files_sdk.models import BundlePath
from files_sdk import bundle_path

class BundlePathTest(TestBase):
    pass 
    # Instance Methods

    # Static Methods
if __name__ == '__main__':
    unittest.main()