"""Coinbase WebSocket provider."""

from .provider import CoinbaseWSProvider

__all__ = ["CoinbaseWSProvider"]
