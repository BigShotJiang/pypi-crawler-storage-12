"""Coinbase REST provider."""

from .provider import CoinbaseRESTProvider

__all__ = ["CoinbaseRESTProvider"]
