"""Hyperliquid REST provider package."""
