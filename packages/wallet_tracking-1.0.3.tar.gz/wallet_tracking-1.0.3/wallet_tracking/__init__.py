"""
Wallet Tracking Package
"""

from .tracker import WalletTracker

__all__ = ['WalletTracker']
__version__ = '1.0.2'

