---
search:
  exclude: true
---

::: examples.scripts.base_setup
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"
        