from ...utilities.zmq.communicable.request import AnalysisRequest


class Work(AnalysisRequest):
    pass
