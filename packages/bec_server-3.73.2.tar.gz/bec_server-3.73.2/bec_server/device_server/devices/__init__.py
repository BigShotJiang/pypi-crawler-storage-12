import logging

import bec_lib

from .device_serializer import is_serializable

loggers = logging.getLogger(__name__)
