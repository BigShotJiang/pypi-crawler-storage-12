# pyDetektia
