"""mcrentcast - Rentcast MCP Server with intelligent caching and rate limiting."""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"