let global = {
    "state":{
    },
    "i18n":{
    },
    "settings":{
    },
    "user":{
    },
}
export default global
