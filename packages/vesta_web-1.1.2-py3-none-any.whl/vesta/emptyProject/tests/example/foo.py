def run():
    resList = []
    resList.append(dummy())
    return resList

def dummy():
    return ("dummy",True)
