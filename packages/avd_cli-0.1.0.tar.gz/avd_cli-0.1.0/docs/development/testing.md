# Testing

AVD CLI uses pytest for comprehensive testing.

## Running Tests

```bash
uv run pytest tests/
```

See [Testing Strategy](https://github.com/titom73/avd-cli/blob/main/spec/infrastructure-testing-strategy.md).
