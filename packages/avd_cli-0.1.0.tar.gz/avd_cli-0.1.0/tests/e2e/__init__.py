#!/usr/bin/env python
# coding: utf-8 -*-

"""End-to-end tests package initialization."""

# This file intentionally left empty to mark the directory as a Python package
