"""unidep - Unified Conda and Pip requirements management."""

__version__ = "2.0.0"
