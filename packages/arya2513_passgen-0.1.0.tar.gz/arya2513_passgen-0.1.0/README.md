# My Package (Password Generator)

This is a simple random password generator, created by following the PyPI guide.

## Usage

```python
# Remember to use the 'name' from your pyproject.toml
from arya2513-passgen import generate_password

print(generate_password(16))