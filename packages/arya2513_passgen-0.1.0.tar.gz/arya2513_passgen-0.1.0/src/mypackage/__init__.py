__all__ = ["generate_password"]
__version__ = "0.1.0"

from .core import generate_password