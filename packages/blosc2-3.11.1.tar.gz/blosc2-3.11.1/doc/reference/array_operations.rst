Operations with arrays
----------------------

.. toctree::
    :maxdepth: 1

    ufuncs
    reduction_functions
    linalg
    additional_funcs
    index_funcs
