"""Legal domain - Terms, privacy, and compliance."""
