import os
from setuptools import setup, find_packages


def get_version():
    here = os.path.abspath(os.path.dirname(__file__))
    init_path = os.path.join(here, "pyextract", "__init__.py")
    with open(init_path, encoding="utf-8") as f:
        for line in f:
            if line.startswith("__version__"):
                return line.split("=")[1].strip().strip("\"'")
    raise RuntimeError("Unable to find version string in __init__.py!")


setup(
    name="pyextract_junbo",
    version=get_version(),
    description="Python tools for extracting and handling archives/logs",
    long_description=open("README_PYPI.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Junbo Zheng",
    author_email="3273070@qq.com",
    url="https://github.com/Junbo-Zheng/pyextract",
    packages=["pyextract"],
    python_requires=">=3.7",
    license="Apache-2.0",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
    ],
    install_requires=[],
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "pyextract = pyextract.pyextract:main",
            "pyextract-assert = pyextract.pyextract_assert:main",
            "pyextract-gzlog = pyextract.pyextract_gzlog:main",
            "pyextract-targz = pyextract.pyextract_targz:main",
            "pyextract-unzip = pyextract.pyextract_unzip:main",
        ],
    },
)
