# /// script
# dependencies = ["rich"]
# ///

import rich

rich.print("[blue]This worked!")
