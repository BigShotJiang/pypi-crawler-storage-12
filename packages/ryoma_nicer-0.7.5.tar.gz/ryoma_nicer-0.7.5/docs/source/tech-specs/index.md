(ryoma-tech-specs)=

# Tech specs

This document describes the technical specifications of the project.

```{toctree}
:maxdepth: 2

tech_spec_v1
```
