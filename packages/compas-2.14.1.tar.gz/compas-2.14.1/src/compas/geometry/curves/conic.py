from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from .curve import Curve


class Conic(Curve):
    """Base class for curves that are conic sections."""
