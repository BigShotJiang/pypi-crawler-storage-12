class AssemblyError(Exception):
    pass


class FeatureError(Exception):
    pass
