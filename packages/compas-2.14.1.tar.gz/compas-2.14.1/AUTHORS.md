# Credits

## Project Lead

- Tom Van Mele <<tom.v.mele@gmail.com>> [@brgcode](https://github.com/brgcode), [@tomvanmele](https://github.com/tomvanmele)

## Main Developers

- Gonzalo Casas <<casas@arch.ethz.ch>> [@gonzalocasas](https://github.com/gonzalocasas)
- Romana Rust <<rust@arch.ethz.ch>> [@romanarust](https://github.com/romanarust)
- Mathias Bernhard <<mathias.bernhard@epfl.ch>> [@worbit](https://github.com/worbit)

## Contributors

- Andrew Liew <<a.liew@sheffield.ac.uk>> [@andrewliew](https://github.com/andrewliew)
- Tomás Méndez Echenagucia <<mendez@arch.ethz.ch>> [@tmsmendez](https://github.com/tmsmendez)
- Matthias Rippmann <<rippmann@arch.ethz.ch>> [@Rippmann](https://github.com/Rippmann)
- Kathrin Dörfler <<doerfler@arch.ethz.ch>> [@Kathrin3010](https://github.com/Kathrin3010)
- Robin Oval <<oval@arch.ethz.ch>> [@robin-oval](https://github.com/robin-oval)
- Rafael Pastrana <<pastrana@arch.ethz.ch>> [@arpastrana](https://github.com/arpastrana)
- Achilleas Xydis <<xydis@arch.ethz.ch>> [@Achillx](https://github.com/Achillx)
- Elitsa Dimitrova <<e.dimitrova77@gmail.com>> [@elidim](https://github.com/elidim)
- Li Chen <<li.chen@arch.ethz.ch>> [@licini](https://github.com/licini)
- Anton Johansson <<anton@tetov.se>> [@tetov](https://github.com/tetov)
- Victor Leung <<yck011522@gmail.com>> [@yck011522](https://github.com/yck011522)
- Robin Jodon <<robin.jodon@epfl.ch>> [@rojodon](https://github.com/rjodon)
- Nik Eftekhar Olivo <<eftekhar@arch.ethz.ch>> [@nikeftekhar](https://github.com/nikeftekhar)
- Beverly Lytle <<lytle@arch.ethz.ch>> [@beverlylytle](https://github.com/beverlylytle>)
- Juney Lee <<juney.lee@arch.ethz.ch>> [@juney-lee](https://github.com/juney-lee)
- Xingxin He <<xingxin.he@mail.polimi.it>> [@XingxinHE](https://github.com/XingxinHE)
- Robin Godwyll <<rodwyll+github@gmail.com>> [@robin-gdwl](https://github.com/robin-gdwl)
- Mattis Koh <<mattiskoh@gmail.com>> [@mattiskoh](https://github.com/mattiskoh)
- Andrea Ghensi <<a.ghensi@swsglobal.com>> [@sanzoghenzo](https://github.com/sanzoghenzo)
- Nizar Taha <<taha@arch.ethz.ch>> [@nizartaha](https://github.com/nizartaha)
- Gene Ting-Chun Kao <<kao@arch.ethz.ch>> [@GeneKao](https://github.com/GeneKao)
- Chen Kasirer <<kasirer@arch.ethz.ch>> [@chenkasirer](https://github.com/chenkasirer)
- Aleksandra Apolinarska <<apolinarska@arch.ethz.ch>> [@funkchaser](https://github.com/funkchaser)
- Nickolas Maslarinos <<maslarinosnickolas@gmail.com>> [@nmaslarinos](https://github.com/nmaslarinos)
- Katerina Toumpektsi <<e.toumpeksti@gmail.com>> [@katarametin](https://github.com/katarametin)
- Joelle Baehr-Bruyere <<joelle.baehr-bruyere@epfl.ch>> [@baehrjo](https://github.com/baehrjo)
- Adam Anouar <<aanouar@student.ethz.ch>> [@AdamAnouar](https://github.com/AdamAnouar)
- Joseph Kenny <<kenny@arch.ethz.ch>> [@jckenny59](https://github.com/jckenny59)
- Panayiotis Papacharalambous <<papacharalambous@arch.ethz.ch>> [@papachap](https://github.com/papachap)
- Oliver Bucklin <<obucklin@arch.ethz.ch>> [@obucklin](https://github.com/obucklin)
- Dominik Reisach <<reisach@arch.ethz.ch>> [@dominikreisach](https://github.com/dominikreisach)
