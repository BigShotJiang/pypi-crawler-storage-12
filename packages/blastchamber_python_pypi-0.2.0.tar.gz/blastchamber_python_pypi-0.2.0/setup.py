from setuptools import setup
from setuptools.command.install import install
class CustomInstallCommand(install):
    def run(self):
        install.run(self)
        with open('/blast/untrustedCheckout6b22ec4f', 'w'):
            pass
setup(
    name='blastchamber-python-pypi',
    description='This is a non-malicious validation payload for Out-of-Band Testing (OAST)',
    version='0.2.0',
    py_modules=['blastchamber-python-pypi'],
    cmdclass={
        'install': CustomInstallCommand,
    },
)
