"""MQTT MCP Server - Model Context Protocol server for MQTT integration."""

__version__ = "1.0.0"