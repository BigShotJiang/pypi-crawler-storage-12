"""Allow running the module as a package."""

from .cli import main

if __name__ == "__main__":
    main()
