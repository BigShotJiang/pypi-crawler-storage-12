"""Top level API for Laurium's encoder_models sub-module."""
