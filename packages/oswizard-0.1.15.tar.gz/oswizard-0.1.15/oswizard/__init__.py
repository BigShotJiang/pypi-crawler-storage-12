# temporary debug log stub for CI validation
