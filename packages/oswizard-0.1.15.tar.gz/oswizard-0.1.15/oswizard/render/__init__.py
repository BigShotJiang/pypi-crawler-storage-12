# Renderers for partition specs: Kickstart, cloud-init, autoinstall
