from __future__ import annotations

from django.apps import AppConfig


class OSMFieldConfig(AppConfig):
    name = "osm_field"
    verbose_name = "OSM Field"
