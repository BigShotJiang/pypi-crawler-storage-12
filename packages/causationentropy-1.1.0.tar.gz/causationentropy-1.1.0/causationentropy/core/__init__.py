__version__ = "1.0.0"
from . import discovery, information, linalg, plotting, stats
from .discovery import discover_network
