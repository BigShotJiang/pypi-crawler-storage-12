from . import core, datasets, tests
from .core import discovery
from .core.discovery import discover_network
from .datasets import synthetic

__version__ = "0.1.0"
