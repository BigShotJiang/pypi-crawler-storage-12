"""Utility modules for d2spy."""

from d2spy.utils.logging_config import get_logger, setup_logging

__all__ = ["get_logger", "setup_logging"]
