#!/bin/bash

mypy django_pyoidc 
