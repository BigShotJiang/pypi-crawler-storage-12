1.0.5
-----
- fix project name in sphinx metadata
- fix missing django 5.2 and python 3.13 classifiers in pyproject.toml

1.0.4
-----
- switch jwt library to pyjwt


1.0.3
-----
- fix drf spectacular schema generation

1.0.0
----

First release !
