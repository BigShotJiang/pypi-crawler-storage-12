from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = "tests.e2e.test_app"
