# Very simpel front app using OIDC

Inspired by the Keycloak demo project (Apache2 License):

* https://github.com/keycloak/keycloak-demo/tree/master/demo-app

Used to test OIDC front interaction with our Django backend in API mode.
