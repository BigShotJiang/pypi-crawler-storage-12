from __future__ import annotations

from cf_ips_to_hcloud_fw.version import __VERSION__ as __VERSION__
