from __future__ import annotations

__VERSION__ = "1.1.0"
