:::darkseid.comic.MetadataFormat
:::darkseid.comic.ComicError
:::darkseid.comic.ComicArchiveError
:::darkseid.comic.ComicMetadataError
:::darkseid.comic.Comic
