:::darkseid.archivers.ArchiverError
:::darkseid.archivers.ArchiverReadError
:::darkseid.archivers.ArchiverWriteError
:::darkseid.archivers.Archiver
