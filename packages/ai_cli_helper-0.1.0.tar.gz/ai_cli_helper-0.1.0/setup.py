#!/usr/bin/env python3
"""setup.py for ai-cli package"""

from setuptools import setup, find_packages
from setuptools.command.install import install
import os
import sys

# 定义安装后命令类
class PostInstallCommand(install):
    """安装后自动执行命令"""
    def run(self):
        # 先运行标准安装
        install.run(self)
        
        # 然后执行自定义脚本
        print("正在执行安装后配置...")
        try:
            # 尝试导入并执行setup_error_tracker函数
            import subprocess
            subprocess.call([sys.executable, 'post_install.py'])
        except Exception as e:
            print(f"安装后配置出错: {e}")
            print("请手动运行 'error-tracker' 命令来配置错误捕获功能。")

# 读取README.md内容作为长描述
with open(os.path.join(os.path.dirname(__file__), 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='ai-cli',
    version='0.1.0',
    description='AI辅助的命令行工具，提供错误捕获和bash历史管理功能',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='guozhibing',
    author_email='guozhib@qq.com',
    url='https://github.com/yougebug/ai-cli',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    package_data={
        '': ['config/*.json'],
    },
    include_package_data=True,
    entry_points={
        'console_scripts': [
            'ai-cli=src.cli:main',
            'error-tracker=src.app:setup_error_tracker',
        ],
    },
    cmdclass={
        'install': PostInstallCommand,
    },
    python_requires='>=3.6',
    install_requires=[
        # 当前项目没有外部依赖，可以根据需要添加
    ],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Topic :: System :: Shells',
        'Topic :: Terminals',
    ],
    keywords='bash, cli, error-tracking, helper',
    license='MIT',
    zip_safe=False,
)
