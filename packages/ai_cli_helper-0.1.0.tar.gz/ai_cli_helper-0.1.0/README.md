# ai-cli

![Python](https://img.shields.io/badge/Python-3.6%2B-blue.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)

一个AI辅助的命令行工具，提供错误捕获和bash历史管理功能，让你的命令行体验更加高效和友好。

## 功能特性

- **错误捕获功能**：自动捕获bash命令执行错误，并保存详细的错误信息到日志文件
- **实时Bash历史**：获取并展示bash内存中的实时历史命令
- **轻量级设计**：仅依赖Python标准库，无需额外安装依赖

## 安装

### 从PyPI安装

```bash
pip install ai-cli
```

### 从源码安装

```bash
# 克隆仓库
git clone https://github.com/yourusername/ai-cli.git
cd ai-cli

# 安装开发模式
pip install -e .
```

## 使用方法

### 错误捕获功能

```bash
# 安装错误捕获功能到bashrc
error-tracker

# 重新加载bashrc以应用更改
source ~/.bashrc
```

之后，当你执行的命令失败时，错误详情会自动保存到`/tmp/last_error_details.txt`文件中。

### Bash历史查询

```bash
# 使用命令行工具查询当前bash历史
ai-cli
```

## 项目结构

```
ai-cli/
├── ai_cli/         # 主源码目录
│   ├── __init__.py        # 包初始化文件
│   ├── app.py             # 错误捕获功能实现
│   ├── cli.py             # 命令行界面
│   └── config/            # 配置文件目录
│       └── __init__.py
├── setup.py               # 安装配置文件
├── requirements.txt       # 依赖列表
├── MANIFEST.in            # 打包配置文件
├── README.md              # 项目说明文档
└── LICENSE                # 许可证文件
```

## 开发

### 安装开发依赖

```bash
pip install -r requirements.txt
```

### 运行测试

```bash
pytest
```

### 代码风格检查

```bash
flake8
black ai_cli
```

## 贡献

欢迎提交Issues和Pull Requests！

## 许可证

本项目采用MIT许可证 - 详见LICENSE文件