#!/usr/bin/env python3
"""配置文件目录"""