# 路径配置文件
# 此文件用于存储和管理项目中使用的各种路径配置

import os
from pathlib import Path

# 项目根目录
PROJECT_ROOT = Path(__file__).parent.parent.parent

# 源代码目录
SRC_DIR = PROJECT_ROOT / "src"

# 配置文件目录
CONFIG_DIR = SRC_DIR / "config"

# 日志文件目录
LOG_DIR = PROJECT_ROOT / "logs"
os.makedirs(LOG_DIR, exist_ok=True)

# 错误日志文件
ERROR_LOG_FILE = LOG_DIR / "error.log"

# OpenAI配置文件路径
OPENAI_CONFIG_FILE = PROJECT_ROOT / "openai_config.json"

# Bash历史记录文件路径
BASH_HISTORY_FILE = os.path.expanduser("~/.bash_history")