# OpenAI大模型接口文件
# 定义与OpenAI API交互的标准接口

import json
import os
from typing import Dict, List, Optional, Any
from src.config.path_config import OPENAI_CONFIG_FILE


class OpenAIClient:
    """
    OpenAI API客户端类，提供标准化的接口调用方法
    """
    
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        """
        初始化OpenAI客户端
        
        Args:
            api_key: OpenAI API密钥，如果为None则从配置文件读取
            base_url: API基础URL，默认为OpenAI官方地址
        """
        self.api_key = api_key or self._get_api_key_from_config()
        self.base_url = base_url or "https://api.openai.com/v1"
        
        if not self.api_key:
            raise ValueError("API key is required")
    
    def _get_api_key_from_config(self) -> Optional[str]:
        """
        从配置文件中读取API密钥
        """
        if os.path.exists(OPENAI_CONFIG_FILE):
            try:
                with open(OPENAI_CONFIG_FILE, 'r') as f:
                    config = json.load(f)
                    return config.get('api_key')
            except Exception:
                pass
        return None
    
    def format_messages(self, messages: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """
        格式化消息列表以符合OpenAI API要求
        
        Args:
            messages: 消息列表，每个消息包含role和content
        
        Returns:
            格式化后的消息列表
        """
        # 确保每个消息都包含role和content字段
        formatted_messages = []
        for msg in messages:
            if 'role' in msg and 'content' in msg:
                formatted_messages.append({
                    'role': msg['role'],
                    'content': msg['content']
                })
        return formatted_messages
    
    def prepare_chat_request(self, messages: List[Dict[str, str]], model: str = "gpt-3.5-turbo", **kwargs) -> Dict[str, Any]:
        """
        准备聊天完成请求的数据
        
        Args:
            messages: 消息列表
            model: 使用的模型名称
            **kwargs: 其他请求参数
        
        Returns:
            准备好的请求数据
        """
        formatted_messages = self.format_messages(messages)
        request_data = {
            'model': model,
            'messages': formatted_messages
        }
        request_data.update(kwargs)
        return request_data
    
    def get_headers(self) -> Dict[str, str]:
        """
        获取API请求头
        
        Returns:
            请求头字典
        """
        return {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}'
        }


def get_openai_client() -> OpenAIClient:
    """
    获取OpenAI客户端实例
    
    Returns:
        OpenAIClient实例
    """
    return OpenAIClient()


def setup_openai_config(api_key: str, base_url: Optional[str] = None) -> bool:
    """
    设置OpenAI配置
    
    Args:
        api_key: OpenAI API密钥
        base_url: API基础URL
    
    Returns:
        是否设置成功
    """
    config = {'api_key': api_key}
    if base_url:
        config['base_url'] = base_url
    
    try:
        os.makedirs(os.path.dirname(OPENAI_CONFIG_FILE), exist_ok=True)
        with open(OPENAI_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
        # 设置文件权限，确保只有用户可读写
        os.chmod(OPENAI_CONFIG_FILE, 0o600)
        return True
    except Exception:
        return False