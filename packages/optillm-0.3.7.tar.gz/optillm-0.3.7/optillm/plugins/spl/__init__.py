"""
System Prompt Learning (SPL) plugin module initialization.
"""

from .main import run_spl

__all__ = ['run_spl']
