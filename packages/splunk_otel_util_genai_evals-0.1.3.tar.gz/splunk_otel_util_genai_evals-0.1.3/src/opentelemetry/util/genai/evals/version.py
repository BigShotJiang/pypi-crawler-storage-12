"""Version metadata for opentelemetry-util-genai-evals."""

__version__ = "0.1.3"
