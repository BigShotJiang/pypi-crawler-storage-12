# The name for the environment variable that stores KONDUKTOR user hash
USER_ID_ENV_VAR = 'KONDUKTOR_USER_ID'

# The name for the environment variable that stores KONDUKTOR user name.
USER_ENV_VAR = 'KONDUKTOR_USER'
