"""Common maths routines."""
