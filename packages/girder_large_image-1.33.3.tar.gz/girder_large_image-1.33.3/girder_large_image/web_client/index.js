import * as views from './views';

export {
    views
};
