# LICENSE

dtool-lookup-gui makes all its materials publicly available under [open source][osi] licenses.

Documents and data are made available under a CC-BY-SA license.
Software are made available under an MIT license.

## Documents and data

Documentation and graphics in this repository are licensed under a [Creative Commons Attribution-ShareAlike 4.0 International License][cc-by-sa].

## Software

Software provided are made available under the [OSI][osi]-approved [MIT license][mit-license].

[cc-by-sa]: https://creativecommons.org/licenses/by-sa/4.0/
[mit-license]: https://opensource.org/licenses/mit-license.html
[osi]: https://opensource.org
