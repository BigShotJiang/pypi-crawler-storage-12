.. include:: ../../CONTRIBUTING.md
   :parser: myst_parser.sphinx_
