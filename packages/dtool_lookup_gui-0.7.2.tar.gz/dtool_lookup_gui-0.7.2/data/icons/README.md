Icons by Michal Rössler / livMatS, University of Freiburg, 2022

`dtool_logo.svg` is the single source for all other generated logo files. 

Run

    bash maintenance/convert_icons.sh

from repository root to (re-)generate all formats after modifications to `dtool_logo.svg`.
