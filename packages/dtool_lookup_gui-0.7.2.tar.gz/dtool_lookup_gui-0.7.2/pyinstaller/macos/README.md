# Build on MacOS

First run

    bash pyinstaller/macos/build-app.sh

to generate `dtool-lookup-gui.app`, then run

    bash pyinstaller/macos/build-dmg.sh

to bundle DMG `dtool-lookup-gui-macos.dmg`.
