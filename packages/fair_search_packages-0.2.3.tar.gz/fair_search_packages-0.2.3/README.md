# 공평 검색 알고리즘

[GitHub](https://github.com/kmu-comnet/fair-search)