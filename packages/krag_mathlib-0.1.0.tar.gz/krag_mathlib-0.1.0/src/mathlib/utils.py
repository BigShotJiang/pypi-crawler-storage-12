"""
mathlib.utils

A collection of utility functions for the mathlib package.
"""

def hello():
    return "Hello mathlib"
