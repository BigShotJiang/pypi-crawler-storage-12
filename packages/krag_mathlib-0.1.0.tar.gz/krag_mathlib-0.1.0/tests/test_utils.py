from mathlib.utils import hello

def test_hello():
    assert hello() == "Hello mathlib"
