Adds a Selection field in the form to select how did the respondent know about the cooperative.
