* `Coop IT Easy SC <https://coopiteasy.be>`_:

  * Victor Champonnois
