# eeg-step

[![PyPI](https://img.shields.io/pypi/v/eeg-step?label=PyPI)](https://pypi.org/project/eeg-step)
[![Python](https://img.shields.io/python/required-version-toml?tomlFilePath=https%3A%2F%2Fraw.githubusercontent.com%2Falexenge%2Feeg-step%2Frefs%2Fheads%2Fmain%2Fpyproject.toml&label=Python)](https://www.python.org)
[![License](https://img.shields.io/github/license/alexenge/eeg-step?label=License)](https://github.com/alexenge/eeg-step?tab=readme-ov-file#MIT-1-ov-file)
[![Docs](https://img.shields.io/readthedocs/eeg-step?label=Docs)](https://eeg-step.readthedocs.io)
[![Workflow](https://img.shields.io/github/actions/workflow/status/alexenge/eeg-step/workflow.yml?label=Workflow)](https://github.com/alexenge/eeg-step/actions/workflows/workflow.yml)
[![Coverage](https://img.shields.io/codecov/c/github/alexenge/eeg-step/main?label=Coverage)](https://codecov.io/gh/alexenge/eeg-step)

Single-trial EEG pipeline
