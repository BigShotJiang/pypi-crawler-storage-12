================
imio.events.core
================

User documentation
