"""
.. deprecated:: 0.2.2
    Moved to `alphabase.spectral_library.translate <https://alphabase.readthedocs.io/en/latest/spectral_library/translate.html>`_.
"""

from alphabase.spectral_library.translate import *
