__version__ = "1.4.1"
# This information is duplicated in pyproject.toml:
__author_email__ = "jalew.zwf@qq.com"
__github__ = "https://github.com/MannLabs/peptdeep"
__doc__ = "https://alphapeptdeep.readthedocs.io/en/latest/"
__license__ = "Apache 2.0"
