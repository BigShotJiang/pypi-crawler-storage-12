from peptdeep.protein import fasta
