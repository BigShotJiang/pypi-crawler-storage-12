import os

CONST_FOLDER = os.path.dirname(__file__)
