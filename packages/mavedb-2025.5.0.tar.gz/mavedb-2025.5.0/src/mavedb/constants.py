import os

MAVEDB_BASE_GIT = "https://github.com/VariantEffect/mavedb-api"
MAVEDB_FRONTEND_URL = os.getenv("MAVE_FRONTEND_URL", "https://mavedb.org")
