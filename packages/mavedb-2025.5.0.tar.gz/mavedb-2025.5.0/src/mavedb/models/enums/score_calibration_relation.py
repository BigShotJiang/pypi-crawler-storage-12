import enum


class ScoreCalibrationRelation(enum.Enum):
    threshold = "threshold"
    classification = "classification"
    method = "method"
