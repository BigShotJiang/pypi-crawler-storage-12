import enum


class UserRole(enum.Enum):
    admin = "admin"
    mapper = "mapper"
