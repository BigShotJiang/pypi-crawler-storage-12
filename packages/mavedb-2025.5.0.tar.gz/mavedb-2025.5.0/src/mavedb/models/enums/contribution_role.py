import enum


class ContributionRole(enum.Enum):
    admin = "admin"
    editor = "editor"
    viewer = "viewer"
