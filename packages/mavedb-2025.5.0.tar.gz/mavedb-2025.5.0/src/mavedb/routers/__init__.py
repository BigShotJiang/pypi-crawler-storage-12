# Import view models up front so any deferred forward references are resolved prior to OpenAPI spec generation.
from mavedb import view_models as view_models
