valid_sequence_types = ["infer", "dna", "protein"]
strict_valid_sequence_types = ["dna", "protein"]
