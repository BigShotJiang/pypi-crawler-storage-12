valid_dbnames = ["UniProt", "RefSeq", "Ensembl"]
