class MappingDataDoesntExistException(ValueError):
    pass
