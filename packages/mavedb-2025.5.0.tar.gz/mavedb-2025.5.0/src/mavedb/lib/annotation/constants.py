GENERIC_DISEASE_MEDGEN_CODE = "C0012634"
MEDGEN_SYSTEM = "https://www.ncbi.nlm.nih.gov/medgen/"
