from artifact_core._base.primitives.artifact_type import ArtifactType


class BinaryClassificationArrayType(ArtifactType):
    CONFUSION_MATRIX = "confusion_matrix"
