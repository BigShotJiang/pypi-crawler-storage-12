from artifact_core._base.primitives.artifact_type import ArtifactType


class BinaryClassificationArrayCollectionType(ArtifactType):
    CONFUSION_MATRICES = "confusion_matrices"
