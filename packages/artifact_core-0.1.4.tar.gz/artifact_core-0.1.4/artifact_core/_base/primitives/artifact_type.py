from enum import Enum


class ArtifactType(Enum):
    pass
