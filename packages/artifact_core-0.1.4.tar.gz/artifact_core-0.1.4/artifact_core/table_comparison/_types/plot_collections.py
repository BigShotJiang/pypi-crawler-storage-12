from artifact_core._base.primitives.artifact_type import ArtifactType


class TableComparisonPlotCollectionType(ArtifactType):
    PDF = "pdf"
    CDF = "cdf"
    CORRELATION_HEATMAPS = "correlation_heatmaps"
