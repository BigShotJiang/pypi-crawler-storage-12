from artifact_core._base.primitives.artifact_type import ArtifactType


class TableComparisonScoreCollectionType(ArtifactType):
    JS_DISTANCE = "js_distance"
