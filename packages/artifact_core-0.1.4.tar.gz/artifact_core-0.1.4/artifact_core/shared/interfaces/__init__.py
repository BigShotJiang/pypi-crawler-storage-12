from artifact_core._interfaces.serializable import Serializable
