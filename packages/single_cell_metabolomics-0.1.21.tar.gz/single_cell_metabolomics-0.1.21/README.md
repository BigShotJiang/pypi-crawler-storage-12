# ylc-single-cell-metabolomics

### Building command
```
uv version --bump patch &&
rm -r dist/ &&
uv build &&
uv publish
```