from contextlib import suppress
with suppress(ImportError): 
    from pytest_readme import setup
    setup()

