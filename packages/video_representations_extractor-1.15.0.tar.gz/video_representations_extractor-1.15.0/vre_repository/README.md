# VRE built-in repository of representations

These are the representations that are implemented on top of the main VRE library & runtime.

