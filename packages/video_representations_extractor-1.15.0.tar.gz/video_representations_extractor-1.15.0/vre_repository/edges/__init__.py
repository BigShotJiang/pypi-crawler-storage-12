"""init file"""
from .edges_representation import EdgesRepresentation
