"""init file"""
from .mask2former import Mask2Former
