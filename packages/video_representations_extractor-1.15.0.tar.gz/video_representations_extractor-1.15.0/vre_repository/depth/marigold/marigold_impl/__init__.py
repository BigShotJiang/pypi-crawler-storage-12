"""init file"""
from .marigold_pipeline import MarigoldPipeline
