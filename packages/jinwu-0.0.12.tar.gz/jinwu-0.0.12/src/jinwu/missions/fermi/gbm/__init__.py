'''
Date: 2025-04-23 11:31:03
LastEditors: Xinxiang Sun sunxinxiang24@mails.ucas.ac.cn
LastEditTime: 2025-04-23 11:32:33
FilePath: /research/autohea/autohea/missions/fermi/gbm/__init__.py
'''
from .GBMObservation import GBMObservation

__all__ = ['GBMObservation']