"""tanabesugano: A Python package for Tanabe-Sugano diagrams."""

from __future__ import annotations


__version__ = "1.5.0"
