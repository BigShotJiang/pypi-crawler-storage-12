from ravyn.core.directives.cli import ravyn_cli


def run_cli() -> None:
    ravyn_cli()


if __name__ == "__main__":  # pragma: no cover
    ravyn_cli()
