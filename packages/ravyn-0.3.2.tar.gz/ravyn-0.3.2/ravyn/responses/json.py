from lilya.responses import JSONResponse as BaseJSONResponse

__all__ = ["BaseJSONResponse"]
