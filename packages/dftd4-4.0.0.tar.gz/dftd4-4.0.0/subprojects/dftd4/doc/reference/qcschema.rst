.. automodule:: dftd4.qcschema
   :members:
