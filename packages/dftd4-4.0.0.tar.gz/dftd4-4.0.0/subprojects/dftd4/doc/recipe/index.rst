Recipes
=======

This section deals with solving specific task with DFT-D4 by providing step by step recipes.


.. toctree::

   installation
   vasp
