def clamp(n, smallest, largest):
    return max(smallest, min(n, largest))
