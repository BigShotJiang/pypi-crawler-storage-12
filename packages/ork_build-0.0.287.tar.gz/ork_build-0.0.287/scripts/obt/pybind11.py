/usr/bin/python3.7 -m pip install pytest
git clone
build
(sudo ;<) install
