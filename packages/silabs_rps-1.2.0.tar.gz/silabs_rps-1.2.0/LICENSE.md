**Copyright 2025 Silicon Laboratories Inc. [https://www.silabs.com](https://www.silabs.com/)**

SPDX-License-Identifier: LicenseRef-MSLA

The licensor of this software is Silicon Laboratories Inc.  
Your use of this software is governed by the terms of the Silicon Labs Master Software License Agreement (MSLA) available at
[https://www.silabs.com/about-us/legal/master-software-license-agreement](https://www.silabs.com/about-us/legal/master-software-license-agreement). This software is distributed to you in Source Code format and is governed by the sections of the MSLA applicable to Source Code.
