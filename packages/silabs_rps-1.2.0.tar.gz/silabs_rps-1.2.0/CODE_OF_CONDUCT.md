# Silicon Labs Community Terms of Use

Please read the full Terms of Use and Code of Conduct in the [agreements-and-guidelines](https://github.com/SiliconLabsSoftware/agreements-and-guidelines) repository: [Code of Conduct](https://github.com/SiliconLabsSoftware/agreements-and-guidelines/blob/main/code_of_conduct.md)
