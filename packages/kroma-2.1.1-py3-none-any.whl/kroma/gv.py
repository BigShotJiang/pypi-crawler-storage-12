ANSI = "\033["
RESET = f"{ANSI}0m"
