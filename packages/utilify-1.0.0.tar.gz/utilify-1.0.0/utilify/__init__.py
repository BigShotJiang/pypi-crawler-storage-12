# utilify initializer
from Strings import strings
from Variable import variable
from decorators import timer, encrypted, run_once, delayed
from core import *
