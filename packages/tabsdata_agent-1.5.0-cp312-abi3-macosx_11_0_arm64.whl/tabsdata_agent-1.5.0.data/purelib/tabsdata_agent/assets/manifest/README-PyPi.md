<!--
Copyright 2025 Tabs Data Inc.
-->

![Tabsdata](https://docs.tabsdata.com/tabsdata.png)

<div align="center">
    <a href="https://tabsdata.com">Tabsdata</a> |
    <a href="https://docs.tabsdata.com/1.5.0/guide/intro.html">User Guide</a> |
    <a href="https://docs.tabsdata.com/1.5.0/api_ref/index.html">API Reference</a>
</div>

# License

Your use of this product is subject to the terms of use available at https://tabsdata.com/license.