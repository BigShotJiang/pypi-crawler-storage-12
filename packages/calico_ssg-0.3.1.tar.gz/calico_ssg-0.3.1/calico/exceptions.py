class PageDoesNotExist(Exception):
    pass
