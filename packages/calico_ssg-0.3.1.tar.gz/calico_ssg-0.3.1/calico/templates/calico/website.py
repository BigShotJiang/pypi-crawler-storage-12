from calico.app import Calico


app = Calico(
    # theme = ['picocss']
    # settings go here
)
