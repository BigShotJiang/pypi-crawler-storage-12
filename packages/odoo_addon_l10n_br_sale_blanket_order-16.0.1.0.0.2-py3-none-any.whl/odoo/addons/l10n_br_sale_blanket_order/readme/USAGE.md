To use this module, you need to:

1.  Go to Sale
2.  Create or select a Sale Blanket Order
3.  Confirm the Sale Blanket Order
4.  Create Sale Order
