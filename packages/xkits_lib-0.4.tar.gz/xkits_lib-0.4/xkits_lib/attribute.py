# coding:utf-8

__project__ = "xkits-lib"
__version__ = "0.4"
__urlhome__ = "https://github.com/bondbox/xlibrary/"
__description__ = "Common library"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
