# Transformer Lab SDK

Python SDK for interacting with Transformer Lab.
You can use this to write plugins and ML scripts that integrate with Transformer Lab.

## Development

### Running tests

This repo uses pytest. After installing the package (editable is fine), run:

```bash
pytest
```
