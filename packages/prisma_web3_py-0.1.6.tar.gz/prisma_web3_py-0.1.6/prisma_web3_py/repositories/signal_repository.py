"""
Signal repository with specialized query methods.
"""

from typing import Optional, List
from datetime import datetime, timedelta
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import selectinload
import logging

from .base_repository import BaseRepository
from ..models.signal import Signal
from ..models.token import Token

logger = logging.getLogger(__name__)


class SignalRepository(BaseRepository[Signal]):
    """Repository for Signal model operations."""

    def __init__(self):
        super().__init__(Signal)

    async def get_recent_signals(
        self,
        session: AsyncSession,
        signal_type: Optional[str] = None,
        chain: Optional[str] = None,
        hours: int = 24,
        limit: int = 100
    ) -> List[Signal]:
        """
        Get recent signals within specified time window.

        Args:
            session: Database session
            signal_type: Filter by signal type (optional)
            chain: Filter by chain (optional)
            hours: Time window in hours
            limit: Maximum number of results

        Returns:
            List of recent signals
        """
        try:
            time_threshold = datetime.utcnow() - timedelta(hours=hours)

            query = (
                select(Signal)
                .where(Signal.last_occurrence >= time_threshold)
                .options(selectinload(Signal.token))
            )

            if signal_type:
                query = query.where(Signal.signal_type == signal_type)

            if chain:
                query = query.where(Signal.chain == chain)

            query = query.order_by(Signal.last_occurrence.desc()).limit(limit)

            result = await session.execute(query)
            return list(result.scalars().all())
        except SQLAlchemyError as e:
            logger.error(f"Error getting recent signals: {e}")
            return []

    async def get_signal_by_token(
        self,
        session: AsyncSession,
        chain: str,
        token_address: str,
        signal_type: Optional[str] = None
    ) -> List[Signal]:
        """
        Get signals for a specific token.

        Args:
            session: Database session
            chain: Blockchain name
            token_address: Token contract address
            signal_type: Filter by signal type (optional)

        Returns:
            List of signals for the token
        """
        try:
            query = select(Signal).where(
                Signal.chain == chain,
                Signal.token_address == token_address
            )

            if signal_type:
                query = query.where(Signal.signal_type == signal_type)

            query = query.order_by(Signal.last_occurrence.desc())

            result = await session.execute(query)
            return list(result.scalars().all())
        except SQLAlchemyError as e:
            logger.error(f"Error getting signals for token: {e}")
            return []

    async def upsert_signal(
        self,
        session: AsyncSession,
        chain: str,
        token_address: str,
        source: str,
        signal_type: str,
        is_first: bool = False
    ) -> Optional[Signal]:
        """
        Insert or update signal occurrence.

        Args:
            session: Database session
            chain: Blockchain name
            token_address: Token contract address
            source: Signal source
            signal_type: Type of signal
            is_first: Whether this is the first occurrence

        Returns:
            Signal instance or None if failed
        """
        try:
            # Check if signal exists
            existing = await session.execute(
                select(Signal).where(
                    Signal.chain == chain,
                    Signal.token_address == token_address,
                    Signal.source == source,
                    Signal.signal_type == signal_type
                )
            )
            signal = existing.scalar_one_or_none()

            now = datetime.utcnow()

            if signal:
                # Update existing signal
                signal.last_occurrence = now
                signal.occurrence_count = (signal.occurrence_count or 0) + 1
                signal.updated_at = now
            else:
                # Create new signal
                signal = Signal(
                    chain=chain,
                    token_address=token_address,
                    source=source,
                    signal_type=signal_type,
                    is_first=is_first,
                    last_occurrence=now,
                    occurrence_count=1
                )
                session.add(signal)

            await session.flush()
            await session.refresh(signal)
            return signal

        except SQLAlchemyError as e:
            logger.error(f"Error upserting signal: {e}")
            return None

    async def get_signal_counts_by_type(
        self,
        session: AsyncSession,
        chain: Optional[str] = None,
        hours: int = 24
    ) -> dict:
        """
        Get signal counts grouped by type.

        Args:
            session: Database session
            chain: Filter by chain (optional)
            hours: Time window in hours

        Returns:
            Dictionary with signal_type as key and count as value
        """
        try:
            time_threshold = datetime.utcnow() - timedelta(hours=hours)

            query = (
                select(Signal.signal_type, func.count(Signal.id))
                .where(Signal.last_occurrence >= time_threshold)
                .group_by(Signal.signal_type)
            )

            if chain:
                query = query.where(Signal.chain == chain)

            result = await session.execute(query)
            return dict(result.all())
        except SQLAlchemyError as e:
            logger.error(f"Error getting signal counts: {e}")
            return {}

    async def get_trending_tokens_by_signals(
        self,
        session: AsyncSession,
        chain: Optional[str] = None,
        signal_type: Optional[str] = None,
        hours: int = 24,
        limit: int = 20
    ) -> List[tuple[Token, int]]:
        """
        Get trending tokens based on signal frequency.

        Args:
            session: Database session
            chain: Filter by chain (optional)
            signal_type: Filter by signal type (optional)
            hours: Time window in hours
            limit: Maximum number of results

        Returns:
            List of (Token, signal_count) tuples
        """
        try:
            time_threshold = datetime.utcnow() - timedelta(hours=hours)

            query = (
                select(
                    Token,
                    func.count(Signal.id).label('signal_count')
                )
                .join(Signal, (Token.chain == Signal.chain) & (Token.token_address == Signal.token_address))
                .where(Signal.last_occurrence >= time_threshold)
                .group_by(Token.id)
                .order_by(func.count(Signal.id).desc())
                .limit(limit)
            )

            if chain:
                query = query.where(Token.chain == chain)

            if signal_type:
                query = query.where(Signal.signal_type == signal_type)

            result = await session.execute(query)
            return [(row[0], row[1]) for row in result.all()]
        except SQLAlchemyError as e:
            logger.error(f"Error getting trending tokens: {e}")
            return []
