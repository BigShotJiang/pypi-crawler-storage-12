# textual-enhanced

This library is a mildly-opinionated set of enhancements and extras for the
Textual framework, mainly aimed at how I like my own Textual apps to look
and work. I've written this as a common set of tweaks I want for my own
Textual apps. It might be useful for yours too.

See [the online documentation](https://textual-enhanced.davep.dev/) for more
background and details.

[//]: # (README.md ends here)
