"""Gather all the scripts used to support the sepal-ui interface (widgets and map).

Example:
    .. jupyter-execute::

        from sepal_ui.scripts import utils as su

        su.random_string(5)
"""
