/* force the resize event. useful for drawer clicks*/
window.dispatchEvent(new Event("resize"));
