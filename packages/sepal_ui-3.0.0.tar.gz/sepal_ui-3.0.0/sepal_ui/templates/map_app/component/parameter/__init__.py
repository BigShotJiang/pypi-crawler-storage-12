"""module to gather all the parameters used in the application.

if you only have few widgets, a module is not necessary and you can simply use a parameter.py file. Iin a big module with lot of custom parameters, it can make sense to split things in separate files for the sake of maintenance.
If you use a module import all the functions here to only have 1 call to make
"""

from .directory import *
