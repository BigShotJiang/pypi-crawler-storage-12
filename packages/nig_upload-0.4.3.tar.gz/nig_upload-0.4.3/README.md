# nig-cli

CLI script for automated uploads