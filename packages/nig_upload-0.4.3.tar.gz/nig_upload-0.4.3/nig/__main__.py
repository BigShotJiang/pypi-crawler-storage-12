def main() -> None:
    from nig.upload import app

    app()


if __name__ == "__main__":
    main()
