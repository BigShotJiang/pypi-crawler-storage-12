"""Main entry point for the WeFact CLI tool"""

from .cli import main

if __name__ == "__main__":
    main()
