# Version Information for WeFact Package

"""Package version."""

__version__ = "1.0.2"

__author__ = "Sjoerd Zaalberg van Zelst"
__email__ = "hello@zzinnovate.com"
__license__ = "MIT"