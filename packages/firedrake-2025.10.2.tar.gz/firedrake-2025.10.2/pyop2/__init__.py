"""
PyOP2 is a library for parallel computations on unstructured meshes.
"""
from pyop2.op2 import *  # noqa
