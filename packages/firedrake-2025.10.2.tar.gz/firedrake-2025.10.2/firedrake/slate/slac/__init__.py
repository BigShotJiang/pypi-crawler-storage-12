from firedrake.slate.slac.compiler import *  # noqa: F401
