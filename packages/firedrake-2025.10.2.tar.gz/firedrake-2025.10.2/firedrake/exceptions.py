

class ConvergenceError(Exception):
    """Error raised when a solver fails to converge"""
