"""text to pandas"""
from .component import Playground