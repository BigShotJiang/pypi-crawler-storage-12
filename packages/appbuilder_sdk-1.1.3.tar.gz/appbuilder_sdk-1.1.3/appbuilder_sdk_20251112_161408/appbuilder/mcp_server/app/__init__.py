"""
MCP Server for AppBuilder App.

This module provides functionality for App operations.
"""

from .app_server import server

__all__ = ["server"]
