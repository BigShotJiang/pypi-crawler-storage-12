YES = 0
RETRY = 0
OK = 0
NO = 1
CANCEL = 2
YES_ALWAYS = 3
NO_ALWAYS = 4

# Icon constants for generic_dialog
ICON_QUESTION = "question"
ICON_WARNING = "warning"
ICON_ERROR = "error"
ICON_INFO = "info"