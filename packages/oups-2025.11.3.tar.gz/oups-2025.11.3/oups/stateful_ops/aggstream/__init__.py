#!/usr/bin/env python3
"""
Created on Wed Dec  1 18:35:00 2021.

@author: pierrot

"""
from .aggstream import AggStream
from .segmentby import by_x_rows


__all__ = ["AggStream", "by_x_rows"]
