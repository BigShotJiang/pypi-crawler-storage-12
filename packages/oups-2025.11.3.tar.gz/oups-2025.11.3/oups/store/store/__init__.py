#!/usr/bin/env python3
"""
Store for oups library.
"""

from .store import Store


__all__ = [
    "Store",
]
