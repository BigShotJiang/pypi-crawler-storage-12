# from html_compose import HTML5Document
# from html_compose.document import _resource_import, document_generator
# from html_compose.live.gallery import showcase

# document_generator(
#     js=[
#         _resource_import(
#             "https://cdnjs.cloudflare.com/ajax/libs/livereload/3.2.2/livereload.js"
#         ),
#         _resource_import(
#             "https://unpkg.com/htmx.org@1.9.10/dist/htmx.min.js", "htmx"
#         ),
#         _resource_import("./static/main.js", preload=True),
#     ]
# )


#  the first question is how does the library have a structure of a document
# to frame the rest in
# im attaching @showcase to functions that return html
