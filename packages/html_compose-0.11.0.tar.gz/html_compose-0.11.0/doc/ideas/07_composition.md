# Advanced composition

you can validate your document structure using pytest and the vscode renderer?
a jupyter notebook that runs files in your folder so you dont have to maintain cells
autogenerating the jupyter notebook

how could you use this python library to contain the test suite

