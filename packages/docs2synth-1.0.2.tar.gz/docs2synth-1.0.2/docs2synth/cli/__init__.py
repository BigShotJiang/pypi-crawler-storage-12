"""Command-line interface package for Docs2Synth."""

from docs2synth.cli.cli_main import cli, main

__all__ = ["cli", "main"]
