from __future__ import annotations

# Shared utilities for MCP (kept intentionally minimal)
