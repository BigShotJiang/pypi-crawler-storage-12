# Constants 

DEFAULT_BASE_URL = "https://base.manager.iblai.app"
DEFAULT_WEBSOCKET_URL = "wss://asgi.data.iblai.app"
