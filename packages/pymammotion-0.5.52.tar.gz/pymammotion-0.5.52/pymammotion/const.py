"""App key and secret as taken from the mammotion android app."""

APP_KEY = "34231230"
APP_SECRET = "1ba85698bb10e19c6437413b61ba3445"
APP_VERSION = "1.11.130"
ALIYUN_DOMAIN = "api.link.aliyun.com"
MAMMOTION_DOMAIN = "https://id.mammotion.com"
MAMMOTION_API_DOMAIN = "https://domestic.mammotion.com"
MAMMOTION_CLIENT_ID = "MADKALUBAS"
MAMMOTION_CLIENT_SECRET = "GshzGRZJjuMUgd2sYHM7"

MAMMOTION_OUATH2_CLIENT_ID = "GxebgSt8si6pKqR"
MAMMOTION_OUATH2_CLIENT_SECRET = "JP0508SRJFa0A90ADpzLINDBxMa4Vj"
