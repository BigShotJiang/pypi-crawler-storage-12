"""LLM Analyser - CSV data processing with LLM-powered structured output generation."""

__version__ = "0.1.1"
