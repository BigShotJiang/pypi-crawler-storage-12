Add containers to purchase orders and stock pickings.

![Purchase container image](../static/description/img.png)
