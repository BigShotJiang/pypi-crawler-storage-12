from setuptools import setup, find_packages

# 使用pyproject.toml进行主要配置，setup.py保留必要的动态设置
setup(
    packages=find_packages(),
)


