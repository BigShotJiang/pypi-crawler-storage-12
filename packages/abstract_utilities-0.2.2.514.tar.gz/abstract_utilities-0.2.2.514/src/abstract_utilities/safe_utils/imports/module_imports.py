from ...type_utils import is_number
from ...class_utils import get_caller_dir
