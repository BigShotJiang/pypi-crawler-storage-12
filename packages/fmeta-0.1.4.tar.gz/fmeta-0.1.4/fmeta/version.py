__version__ = "0.1.4"
__author__ = "Benevant Mathew"
__email__ = "benevantmathewv@gmail.com"

if __name__ == "__main__":
    print(__version__)
