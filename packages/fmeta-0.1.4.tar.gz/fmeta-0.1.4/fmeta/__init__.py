"""
fmeta: A light weight File Metadata lister.
"""
__title__ = "fmeta"
__author__ = "Benevant Mathew"
__license__ = "MIT License"