"""Core implementation of the Go/NO GO validator."""

from gng.core.validator import GoNoGoValidator

__all__ = ["GoNoGoValidator"]
