
from setuptools import setup

setup(package_data={'xdg-stubs': ['BaseDirectory.pyi', 'Config.pyi', 'DesktopEntry.pyi', 'Exceptions.pyi', 'IconTheme.pyi', 'IniFile.pyi', 'Locale.pyi', 'Menu.pyi', 'MenuEditor.pyi', 'Mime.pyi', 'RecentFiles.pyi', '__init__.pyi', 'util.pyi', 'METADATA.toml', 'py.typed']})
