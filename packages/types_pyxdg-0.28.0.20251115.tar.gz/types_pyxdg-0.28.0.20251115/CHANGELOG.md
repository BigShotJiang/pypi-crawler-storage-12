## 0.28.0.20251115 (2025-11-15)

[pyxdg] Annotate Incompletes and fix getFiles return annotation ([#15028](https://github.com/python/typeshed/pull/15028))

## 0.28.0.20250622 (2025-06-22)

[pyxdg] Remove from pyrightconfig (#14309)

## 0.28.0.20240106 (2024-01-06)

Update typing_extensions imports in third-party stubs (#11245)

## 0.28.0.1 (2023-11-09)

Bump flake8-pyi to 23.11.0 (#10997)

## 0.28.0.0 (2023-11-07)

Add pyxdg stubs (#10163)

Co-authored-by: Alex Waygood <Alex.Waygood@Gmail.com>

