import os

os.environ["TELEMETRY_DISABLED"] = "true"
