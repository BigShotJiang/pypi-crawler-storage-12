# Changelog

## 1.8.2 (2025-11-12)

Full Changelog: [v1.8.1...v1.8.2](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v1.8.1...v1.8.2)

### Bug Fixes

* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([749180b](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/749180bbc866d3fce61807ca03fe3696e4b78110))

## 1.8.1 (2025-11-11)

Full Changelog: [v1.8.0...v1.8.1](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v1.8.0...v1.8.1)

### Bug Fixes

* compat with Python 3.14 ([c0a0706](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/c0a0706a7281f8eb9ed10a2213f8eba5499bf5fb))


### Chores

* **package:** drop Python 3.8 support ([d27fd00](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/d27fd002c13f8b20d432133d89f3206169762d71))

## 1.8.0 (2025-11-04)

Full Changelog: [v1.7.0...v1.8.0](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v1.7.0...v1.8.0)

### Features

* **api:** manual updates ([1f92152](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/1f921523a019cf286dc398b2127dc6009903cced))

## 1.7.0 (2025-11-04)

Full Changelog: [v1.6.0...v1.7.0](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v1.6.0...v1.7.0)

### Features

* **api:** manual updates ([e5283a7](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/e5283a73792eb1e885d1bf95bdd259b91ffeb31d))

## 1.6.0 (2025-11-04)

Full Changelog: [v1.5.0...v1.6.0](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v1.5.0...v1.6.0)

### Features

* **api:** manual updates ([02c3850](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/02c385072284fb0f01f602924ec3057c5e086bf4))

## 1.5.0 (2025-11-04)

Full Changelog: [v1.4.0...v1.5.0](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v1.4.0...v1.5.0)

### Features

* **api:** manual updates ([05dc70a](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/05dc70af7c8b226b70efad91abec6877ebf7a7af))

## 1.4.0 (2025-11-04)

Full Changelog: [v1.3.0...v1.4.0](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v1.3.0...v1.4.0)

### Features

* **api:** manual updates ([bbaf168](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/bbaf1688d4d1ea01d170d1a5e76a8529355e21b3))


### Chores

* **internal:** grammar fix (it's -&gt; its) ([3431d83](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/3431d83dc40eb5d429ae78822e8a3002cd3e4906))

## 1.3.0 (2025-11-03)

Full Changelog: [v1.2.0...v1.3.0](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v1.2.0...v1.3.0)

### Features

* **api:** manual updates ([04a1cfb](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/04a1cfb6244c7d3d55a0b64fc5bfadc804c34520))

## 1.2.0 (2025-11-03)

Full Changelog: [v1.1.0...v1.2.0](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v1.1.0...v1.2.0)

### Features

* **api:** manual updates ([679968f](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/679968f795e9e643595c61af2dfd684f5b21e120))

## 1.1.0 (2025-11-03)

Full Changelog: [v1.0.1...v1.1.0](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v1.0.1...v1.1.0)

### Features

* **api:** manual updates ([a0ff678](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/a0ff678ce059982bca83273748e0819e61ea6259))


### Chores

* **internal/tests:** avoid race condition with implicit client cleanup ([3e6cc4e](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/3e6cc4ea726815ce76134fa4cb2602fbdd0e902b))

## 1.0.1 (2025-10-30)

Full Changelog: [v1.0.0...v1.0.1](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v1.0.0...v1.0.1)

### Bug Fixes

* **client:** close streams without requiring full consumption ([bb3166f](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/bb3166fb267a0b25f27d73cead1261c40d5f7af9))


### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([e216c0e](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/e216c0e8b7baf28e001e9eab80377894b6bf0f7f))

## 1.0.0 (2025-10-15)

Full Changelog: [v0.1.0...v1.0.0](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v0.1.0...v1.0.0)

### Chores

* update SDK settings ([0c5c64a](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/0c5c64af3e9eff718eeaf4d9097308fdf42351a9))

## 0.1.0 (2025-10-15)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/LinXueyuanStdio/agentlin-client-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([5d62563](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/5d625637e111757cd1ce8b83988e99b3e6af4033))
* **api:** manual updates ([1d5cd77](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/1d5cd777fd00cef3e9677c5efdc700375b0ec9e6))
* **api:** manual updates ([07ab37d](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/07ab37d3ddd983ff06821b469ffb2e5235ae2f29))
* **api:** manual updates ([6ce99e2](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/6ce99e2d0df907c3e3173a3d751a0eb70801ba91))
* **api:** manual updates ([02588ab](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/02588ab897269c98a06ef46c8a276b3ecdf63bad))
* **api:** manual updates ([16e44a9](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/16e44a9d54ccfbe05760d9e089822bc5f698c767))
* **api:** manual updates ([f21e45f](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/f21e45f8d1b6d9ec32a636a05542635a78fdb360))
* **api:** manual updates ([553d47b](https://github.com/LinXueyuanStdio/agentlin-client-python/commit/553d47bee958c29a511c7161362a427d1f821840))
