# pythonbible-bbe

The Bible in Basic English (BBE) version of the Bible in Python. For use with the `pythonbible` library.
