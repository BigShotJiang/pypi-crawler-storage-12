"""Service layer on top of repository layer. Provides core methods to interact with database."""
