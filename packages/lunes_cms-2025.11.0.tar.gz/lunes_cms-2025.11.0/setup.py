#!/usr/bin/env python3
"""
Minimal setup.py for legacy builds.
See pyproject.toml for all setup configuration options.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
