"""
This is the content management system for backend users which contains all database models, views, forms and templates.
"""
