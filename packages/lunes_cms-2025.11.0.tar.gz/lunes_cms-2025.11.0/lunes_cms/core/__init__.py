"""
This is the project's main app which contains all configuration files.
"""
