"""
Content Management System for the Lunes Vocabulary Trainer App
"""

__version__ = "2025.11.0"
