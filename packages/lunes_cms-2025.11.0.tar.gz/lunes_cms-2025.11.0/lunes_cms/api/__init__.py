"""
This is the app which contains all API routes and classes which map the cms models to API JSON responses.
This is not the API documentation itself, but the Django developer documentation.
The usage documentation can be found here: https://lunes.tuerantuer.org/api/docs/
"""
