"""
The second version of the Lunes API.
The usage documentation can be found here: https://lunes.tuerantuer.org/api/v2/docs/
"""
