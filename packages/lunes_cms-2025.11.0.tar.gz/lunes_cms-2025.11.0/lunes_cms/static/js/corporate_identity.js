/*
Adapting the footer to display "Tür an Tür Digitalfabrik gGmbH" instead
of "Jazzmin Version".
*/
let footerDiv = document.querySelector('footer div')
if (footerDiv) footerDiv.innerHTML = "<b>Tür an Tür Digitalfabrik gGmbH</b>";
