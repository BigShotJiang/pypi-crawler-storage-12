"""
This is the app which handles the public upload of images.
"""
