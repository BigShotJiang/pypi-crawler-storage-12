# AccuralAI RAG TODO

- [ ] Add vector-database adapters (Qdrant, Weaviate, Milvus) mapped to `HybridSearchEngine` (see `plan/high-performance-rag.md`).
- [ ] Wire CLI commands to toggle RAG pipelines and stream retrieval traces.
- [ ] Expand benchmarking harness for latency/recall comparison against baseline implementations.
