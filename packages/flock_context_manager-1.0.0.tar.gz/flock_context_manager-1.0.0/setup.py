# SPDX-FileCopyrightText: 2024-2025 Joe Pitt
#
# SPDX-License-Identifier: GPL-3.0-only

"""Setup file for get_latest_version"""

from setuptools import setup

if __name__ == "__main__":
    setup()
