import logging

logger = logging.getLogger("abstra")

__all__ = ["logger"]
