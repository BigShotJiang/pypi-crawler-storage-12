# Documentation

This directory contains documentation for the Python IDA SDK.

Documentation is hosted on GitHub Pages at: https://national-id-program-ethiopia.github.io/python-ida-sdk

## Local Development

To build documentation locally, use MkDocs or Sphinx (to be configured).


