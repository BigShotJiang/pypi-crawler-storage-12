"""Constants for IDA SDK"""

