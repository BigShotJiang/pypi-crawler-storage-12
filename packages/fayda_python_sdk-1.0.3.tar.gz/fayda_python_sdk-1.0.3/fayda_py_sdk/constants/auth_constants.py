"""Authentication constants"""

DEFAULT_SUBID = "0"
SSL = "SSL"
AUTH_REQUEST_ID = "mosip.identity.auth"
EKYC_REQUEST_ID = "mosip.identity.kyc"
OTP_REQUEST_ID = "mosip.identity.otp"
TRANSACTION_ID = "1234567890"

