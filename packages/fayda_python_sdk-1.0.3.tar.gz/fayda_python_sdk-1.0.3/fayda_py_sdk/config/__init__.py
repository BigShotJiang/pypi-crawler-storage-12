"""Configuration classes"""

