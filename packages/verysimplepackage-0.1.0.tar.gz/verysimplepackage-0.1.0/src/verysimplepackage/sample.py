def printei(x: str) -> None:
    return(f"Printei: {x}")
