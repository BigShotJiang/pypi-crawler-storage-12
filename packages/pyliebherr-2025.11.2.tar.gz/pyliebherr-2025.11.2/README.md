# PyLiebherr:  Access the Smart Home Device API Library

![PyPI - Version](https://img.shields.io/pypi/v/pyliebherr)

Python library to access the [Liebherr Smart Home API](https://developer.liebherr.com/apis/smartdevice-homeapi/) (account required).