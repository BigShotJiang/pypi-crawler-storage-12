from . import fastapi

__all__ = ["fastapi"]
__version__ = "0.2.0"
