"""
Tests for WorkRB checkpoint and resume functionality.
"""
