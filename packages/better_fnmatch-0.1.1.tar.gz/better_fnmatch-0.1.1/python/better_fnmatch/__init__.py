# noqa: D104
# SPDX-FileCopyrightText: 2025 László Vaskó <opensource@vlaci.email.com>
#
# SPDX-License-Identifier: EUPL-1.2

from .better_fnmatch import fnmatch as fnmatch
