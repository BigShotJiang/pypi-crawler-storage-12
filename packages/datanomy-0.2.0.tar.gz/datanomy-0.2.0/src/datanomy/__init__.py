"""Datanomy - Explore the anatomy of your columnar data."""

from importlib.metadata import version

__version__ = version("datanomy")
