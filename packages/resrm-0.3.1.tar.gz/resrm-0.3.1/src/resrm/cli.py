from resrm.core import main
