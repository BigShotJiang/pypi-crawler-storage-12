from CheeseSignal.signal import Receiver, Signal
