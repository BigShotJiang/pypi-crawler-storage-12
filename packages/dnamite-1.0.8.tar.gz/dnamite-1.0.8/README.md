# DNAMite

DNAMite: a package for Discrete Neural Additive Models. 

<p align="center">
  <img src="docs/dynamite.png" alt="dnamite-logo">
</p>

### Installation

Run `pip install dnamite`.

### Documentation

[Official DNAMite Documentation](https://dnamite.readthedocs.io/en/latest/).