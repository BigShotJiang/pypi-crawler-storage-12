"""State management - refresh, UPnP integration, state synchronization."""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..models import DeviceInfo, PlayerStatus
    from . import Player

_LOGGER = logging.getLogger(__name__)

# Standard sources that shouldn't be cleared when checking for multiroom/master names
STANDARD_SOURCES = {
    "spotify",
    "tidal",
    "amazon",
    "qobuz",
    "deezer",
    "wifi",
    "bluetooth",
    "linein",
    "coax",
    "optical",
    "usb",
    "airplay",
    "dlna",
    "unknown",
}


class StateManager:
    """Manages player state refresh and UPnP integration."""

    def __init__(self, player: Player) -> None:
        """Initialize state manager.

        Args:
            player: Parent Player instance.
        """
        self.player = player

    def apply_diff(self, changes: dict[str, Any]) -> bool:
        """Apply state changes from UPnP events.

        Args:
            changes: Dictionary with state fields from UPnP event.

        Returns:
            True if state changed, False otherwise.
        """
        if not changes:
            return False

        # Track if state actually changed
        old_state = {
            "play_state": self.player.play_state,
            "volume": self.player.volume_level,
            "muted": self.player.is_muted,
            "title": self.player.media_title,
            "position": self.player.media_position,
        }

        # Update from UPnP
        self.update_from_upnp(changes)

        # Check if state changed
        new_state = {
            "play_state": self.player.play_state,
            "volume": self.player.volume_level,
            "muted": self.player.is_muted,
            "title": self.player.media_title,
            "position": self.player.media_position,
        }

        return old_state != new_state

    def update_from_upnp(self, data: dict[str, Any]) -> None:
        """Update state from UPnP event data.

        Args:
            data: Dictionary with state fields from UPnP event.
        """
        self.player._state_synchronizer.update_from_upnp(data)

        # Get merged state and update cached models
        merged = self.player._state_synchronizer.get_merged_state()

        # Update cached status_model with merged state
        if self.player._status_model:
            # Update fields from merged state
            for field_name in ["play_state", "position", "duration", "source"]:
                if field_name in merged and merged[field_name] is not None:
                    setattr(self.player._status_model, field_name, merged[field_name])

            # Update volume and mute
            if "volume" in merged and merged["volume"] is not None:
                vol = merged["volume"]
                if isinstance(vol, float) and 0.0 <= vol <= 1.0:
                    self.player._status_model.volume = int(vol * 100)
                else:
                    self.player._status_model.volume = int(vol) if vol is not None else None

            if "muted" in merged and merged["muted"] is not None:
                self.player._status_model.mute = merged["muted"]

            # Update metadata
            for field_name in ["title", "artist", "album"]:
                if field_name in merged:
                    setattr(self.player._status_model, field_name, merged.get(field_name))

            if "image_url" in merged:
                self.player._status_model.entity_picture = merged.get("image_url")
                self.player._status_model.cover_url = merged.get("image_url")

    async def _get_master_name(self, device_info: DeviceInfo | None, status: PlayerStatus | None) -> str | None:
        """Get master device name."""
        # First try: Use Group object if available
        if (
            self.player._group is not None
            and self.player._group.master is not None
            and self.player._group.master != self.player
        ):
            if self.player._group.master._device_info is None or self.player._group.master.name is None:
                try:
                    await self.player._group.master.refresh()
                except Exception:
                    pass
            return self.player._group.master.name or self.player._group.master.host

        # Second try: Use master_ip from device_info/status
        if device_info:
            master_ip = device_info.master_ip or (status.master_ip if status else None)
            if master_ip:
                master_client = None
                try:
                    from ..client import WiiMClient

                    master_client = WiiMClient(master_ip)
                    master_name = await master_client.get_device_name()
                    return master_name
                except Exception as e:
                    _LOGGER.debug("Failed to get master name from IP %s: %s", master_ip, e)
                    return master_ip
                finally:
                    if master_client is not None:
                        try:
                            await master_client.close()
                        except Exception:
                            pass

        return None

    async def refresh(self) -> None:
        """Refresh cached state from device."""
        try:
            status = await self.player.client.get_player_status_model()
            device_info = await self.player.client.get_device_info_model()

            # Update StateSynchronizer with HTTP data
            status_dict = status.model_dump(exclude_none=False) if status else {}
            if "entity_picture" in status_dict:
                status_dict["image_url"] = status_dict.pop("entity_picture")
            for field_name in ["title", "artist", "album", "image_url"]:
                if field_name not in status_dict:
                    status_dict[field_name] = None

            # Replace "multiroom" with master's name for slaves
            if status_dict.get("source") == "multiroom":
                master_name = await self._get_master_name(device_info, status)
                if master_name:
                    status_dict["source"] = master_name
                    _LOGGER.debug(
                        "Replacing 'multiroom' with master name '%s' for slave %s", master_name, self.player.host
                    )

            self.player._state_synchronizer.update_from_http(status_dict)

            # Update cached models
            self.player._status_model = status
            if self.player._status_model and self.player._status_model.source == "multiroom":
                master_name = await self._get_master_name(device_info, status)
                if master_name:
                    self.player._status_model.source = master_name
                    _LOGGER.debug(
                        "Updated status_model source to master name '%s' for slave %s", master_name, self.player.host
                    )

            self.player._device_info = device_info
            self.player._last_refresh = time.time()
            self.player._available = True

            # Clear source if device is no longer a slave
            if self.player._status_model and self.player._status_model.source:
                current_source = self.player._status_model.source
                is_currently_solo = (
                    self.player._group is None
                    and (not device_info.master_ip and not device_info.master_uuid)
                    and (device_info.group == "0" or not device_info.group)
                    and (not status.master_ip and not status.master_uuid)
                )
                source_is_multiroom_or_master = current_source == "multiroom" or (
                    current_source not in STANDARD_SOURCES and current_source is not None
                )
                if is_currently_solo and source_is_multiroom_or_master:
                    self.player._status_model.source = None
                    self.player._status_model._multiroom_mode = None
                    self.player._state_synchronizer.update_from_http({"source": None})
                    _LOGGER.debug(
                        "Cleared source for device %s - no longer a slave (was: %s)", self.player.host, current_source
                    )

            # Update cached status_model from merged state
            merged = self.player._state_synchronizer.get_merged_state()
            if self.player._status_model:
                for field_name in ["play_state", "position", "duration", "source"]:
                    if field_name in merged and merged[field_name] is not None:
                        value = merged[field_name]
                        if field_name == "source" and value == "multiroom":
                            master_name = await self._get_master_name(
                                self.player._device_info, self.player._status_model
                            )
                            if master_name:
                                value = master_name
                                self.player._state_synchronizer.update_from_http({"source": master_name})
                                _LOGGER.debug(
                                    "Replaced 'multiroom' with master name '%s' in merged state for slave %s",
                                    master_name,
                                    self.player.host,
                                )
                        setattr(self.player._status_model, field_name, value)

                # Check again if source should be cleared after merged state update
                if self.player._status_model.source:
                    current_source = self.player._status_model.source
                    is_currently_solo = (
                        self.player._group is None
                        and (not device_info.master_ip and not device_info.master_uuid)
                        and (device_info.group == "0" or not device_info.group)
                        and (not status.master_ip and not status.master_uuid)
                    )
                    source_is_multiroom_or_master = current_source == "multiroom" or (
                        current_source not in STANDARD_SOURCES and current_source is not None
                    )
                    if is_currently_solo and source_is_multiroom_or_master:
                        self.player._status_model.source = None
                        self.player._status_model._multiroom_mode = None
                        self.player._state_synchronizer.update_from_http({"source": None})
                        _LOGGER.debug(
                            "Cleared source for device %s after merged state update - no longer a slave (was: %s)",
                            self.player.host,
                            current_source,
                        )

                # Update volume and mute
                if "volume" in merged and merged["volume"] is not None:
                    vol = merged["volume"]
                    if isinstance(vol, float) and 0.0 <= vol <= 1.0:
                        self.player._status_model.volume = int(vol * 100)
                    else:
                        self.player._status_model.volume = int(vol) if vol is not None else None

                if "muted" in merged and merged["muted"] is not None:
                    self.player._status_model.mute = merged["muted"]

                # Update metadata from merged state
                for field_name in ["title", "artist", "album"]:
                    value = merged.get(field_name)
                    current_value = getattr(self.player._status_model, field_name, None)
                    if value != current_value:
                        setattr(self.player._status_model, field_name, value)
                        if _LOGGER.isEnabledFor(logging.DEBUG):
                            _LOGGER.debug("Updated %s from merged state: %s -> %s", field_name, current_value, value)

                if "image_url" in merged:
                    self.player._status_model.entity_picture = merged.get("image_url")
                    self.player._status_model.cover_url = merged.get("image_url")

            # Fetch audio output status if device supports it
            if self.player.client.capabilities.get("supports_audio_output", False):
                try:
                    audio_output_status = await self.player.client.get_audio_output_status()
                    self.player._audio_output_status = audio_output_status
                except Exception as err:
                    _LOGGER.debug("Failed to fetch audio output status for %s: %s", self.player.host, err)
                    self.player._audio_output_status = None

            # Synchronize group state from device state
            from .groupops import GroupOperations

            await GroupOperations(self.player)._synchronize_group_state()

            # Notify callback
            if self.player._on_state_changed:
                try:
                    self.player._on_state_changed()
                except Exception as err:
                    _LOGGER.debug("Error calling on_state_changed callback for %s: %s", self.player.host, err)

        except Exception as err:
            device_context = f"host={self.player.host}"
            if self.player._device_info:
                device_context += (
                    f", model={self.player._device_info.model}, firmware={self.player._device_info.firmware}"
                )
            _LOGGER.warning("Failed to refresh state for %s: %s", device_context, err)
            self.player._available = False
            raise

    async def get_device_info(self) -> DeviceInfo:
        """Get device information (always queries device)."""
        return await self.player.client.get_device_info_model()

    async def get_status(self) -> PlayerStatus:
        """Get current player status (always queries device)."""
        return await self.player.client.get_player_status_model()

    async def get_play_state(self) -> str:
        """Get current playback state by querying device."""
        status = await self.get_status()
        return status.play_state or "stop"
