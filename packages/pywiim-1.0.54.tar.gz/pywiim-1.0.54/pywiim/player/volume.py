"""Volume and mute control."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from . import Player


class VolumeControl:
    """Manages volume and mute operations."""

    def __init__(self, player: Player) -> None:
        """Initialize volume control.

        Args:
            player: Parent Player instance.
        """
        self.player = player

    async def set_volume(self, volume: float) -> None:
        """Set volume level (0.0-1.0).

        Args:
            volume: Volume level from 0.0 to 1.0.
        """
        await self.player.client.set_volume(volume)

    async def set_mute(self, mute: bool) -> None:
        """Set mute state.

        Args:
            mute: True to mute, False to unmute.
        """
        await self.player.client.set_mute(mute)

    async def get_volume(self) -> float | None:
        """Get current volume level by querying device."""
        from .statemgr import StateManager

        status = await StateManager(self.player).get_status()
        return status.volume / 100.0 if status.volume is not None else None

    async def get_muted(self) -> bool | None:
        """Get current mute state by querying device."""
        from .statemgr import StateManager

        status = await StateManager(self.player).get_status()
        return status.mute
