"""Property getters for player state and metadata."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from . import Player


class PlayerProperties:
    """Provides property access to player state and metadata."""

    def __init__(self, player: Player) -> None:
        """Initialize properties.

        Args:
            player: Parent Player instance.
        """
        self.player = player

    # === Volume and Mute ===

    @property
    def volume_level(self) -> float | None:
        """Current volume level (0.0-1.0) from cached status."""
        if self.player._status_model is None or self.player._status_model.volume is None:
            return None
        return max(0.0, min(float(self.player._status_model.volume), 100.0)) / 100.0

    @property
    def is_muted(self) -> bool | None:
        """Current mute state from cached status."""
        if self.player._status_model is None:
            return None

        mute_val = self.player._status_model.mute
        if mute_val is None:
            return None

        if isinstance(mute_val, (bool, int)):
            return bool(int(mute_val))

        mute_str = str(mute_val).strip().lower()
        if mute_str in ("1", "true", "yes", "on"):
            return True
        if mute_str in ("0", "false", "no", "off"):
            return False
        return None

    # === Playback State ===

    @property
    def play_state(self) -> str | None:
        """Current playback state from cached status."""
        if self.player._status_model is None:
            return None
        return self.player._status_model.play_state

    # === Media Metadata ===

    def _status_field(self, *names: str) -> str | None:
        """Return the first non-empty attribute from cached PlayerStatus."""
        if self.player._status_model is None:
            return None

        for n in names:
            if hasattr(self.player._status_model, n):
                val = getattr(self.player._status_model, n)
                if isinstance(val, str) and val.strip().lower() in {"unknown", "unknow", "none"}:
                    continue
                if val not in (None, ""):
                    return str(val) if val is not None else None
        return None

    @property
    def media_title(self) -> str | None:
        """Current track title from cached status."""
        return self._status_field("title")

    @property
    def media_artist(self) -> str | None:
        """Current track artist from cached status."""
        return self._status_field("artist")

    @property
    def media_album(self) -> str | None:
        """Current track album from cached status."""
        return self._status_field("album", "album_name")

    @property
    def media_duration(self) -> int | None:
        """Current track duration in seconds from cached status."""
        duration = self._status_field("duration")
        try:
            if duration is not None:
                result = int(float(duration))
                if result == 0:
                    return None
                return result
            return None
        except (TypeError, ValueError):
            return None

    @property
    def media_position(self) -> int | None:
        """Current playback position in seconds with hybrid estimation."""
        position = self._status_field("position", "seek")
        try:
            if position is not None:
                pos_value = int(float(position))
                if pos_value < 0:
                    return None

                duration_value = self.media_duration
                if duration_value is not None and duration_value > 0:
                    if pos_value > duration_value:
                        pos_value = duration_value
            else:
                pos_value = None
        except (TypeError, ValueError):
            pos_value = None

        # Determine if actively playing
        play_state = self.play_state
        is_playing = play_state and play_state.lower() in ("play", "playing", "load")

        # Get track signature to detect track changes
        try:
            title = self._status_field("title") or ""
            artist = self._status_field("artist") or ""
            album = self._status_field("album") or ""
            current_signature = f"{title}|{artist}|{album}"
        except Exception:
            current_signature = ""

        # Detect track changes
        track_changed = (
            current_signature
            and self.player._last_track_signature
            and current_signature != self.player._last_track_signature
        )

        # Detect seeks
        position_jumped = False
        if pos_value is not None and self.player._last_position is not None:
            jump_backward = pos_value + 2 < self.player._last_position
            jump_forward = pos_value > self.player._last_position + 10
            position_jumped = jump_backward or jump_forward

        # Reset estimation on track changes, seeks, or None position
        if track_changed or position_jumped or pos_value is None:
            self.player._estimated_position = None
            self.player._estimation_start_time = None
            self.player._estimation_base_position = None

        # Update estimation base when we get a new position
        if pos_value is not None:
            if (
                self.player._estimation_base_position is None
                or abs(pos_value - self.player._estimation_base_position) > 2
            ):
                self.player._estimation_base_position = pos_value
                self.player._estimation_start_time = time.time()
                self.player._estimated_position = pos_value

        # Estimate position while playing
        if (
            is_playing
            and self.player._estimation_base_position is not None
            and self.player._estimation_start_time is not None
        ):
            elapsed = time.time() - self.player._estimation_start_time
            estimated = self.player._estimation_base_position + int(elapsed)

            duration_value = self.media_duration
            if duration_value is not None and duration_value > 0:
                estimated = min(estimated, duration_value)

            max_drift = 30
            if estimated <= self.player._estimation_base_position + max_drift:
                self.player._estimated_position = estimated
                return estimated

        # Return actual position (not playing, or estimation not available)
        if pos_value is not None:
            self.player._estimated_position = pos_value
            return pos_value

        return self.player._estimated_position

    @property
    def media_position_updated_at(self) -> float | None:
        """Timestamp when media position was last updated."""
        current_position = self.media_position

        try:
            title = self._status_field("title") or ""
            artist = self._status_field("artist") or ""
            album = self._status_field("album") or ""
            current_signature = f"{title}|{artist}|{album}"
        except Exception:
            current_signature = ""

        previous_position = self.player._last_position
        previous_signature = self.player._last_track_signature

        play_state = self.play_state
        is_playing = play_state and play_state.lower() in ("play", "playing", "load")

        track_changed = current_signature and current_signature != previous_signature
        position_decreased = (
            current_position is not None and previous_position is not None and current_position + 2 < previous_position
        )

        if (track_changed or position_decreased) and current_position is not None:
            self.player._last_position_update = time.time()
            self.player._last_position = current_position
            self.player._last_track_signature = current_signature
        elif (
            is_playing
            and current_position is not None
            and previous_position is not None
            and current_position > previous_position
        ):
            self.player._last_position_update = time.time()
            self.player._last_position = current_position
            self.player._last_track_signature = current_signature or previous_signature
        elif previous_position is None and current_position is not None:
            self.player._last_position_update = time.time()
            self.player._last_position = current_position
            self.player._last_track_signature = current_signature or previous_signature
        elif is_playing and current_position is not None:
            self.player._last_position_update = time.time()
            self.player._last_position = current_position
            self.player._last_track_signature = current_signature or previous_signature

        if self.player._last_position_update is None:
            self.player._last_position_update = time.time()

        return self.player._last_position_update

    @property
    def media_image_url(self) -> str | None:
        """Media image URL from cached status."""
        return self._status_field("entity_picture", "cover_url")

    @property
    def source(self) -> str | None:
        """Current source from cached status."""
        if self.player._status_model is None:
            return None
        return self.player._status_model.source

    # === Shuffle and Repeat ===

    @property
    def shuffle_state(self) -> bool | None:
        """Shuffle state from cached status."""
        if self.player._status_model is None:
            return None

        shuffle_val = getattr(self.player._status_model, "shuffle", None)
        if shuffle_val is not None:
            if isinstance(shuffle_val, (bool, int)):
                return bool(int(shuffle_val))
            shuffle_str = str(shuffle_val).strip().lower()
            return shuffle_str in {"1", "true", "shuffle"}

        loop_mode = getattr(self.player._status_model, "loop_mode", None)
        if loop_mode is not None:
            try:
                loop_val = int(loop_mode)
                is_shuffle = bool(loop_val & 4)
                return is_shuffle
            except (TypeError, ValueError):
                pass

        play_mode = getattr(self.player._status_model, "play_mode", None)
        if play_mode is not None:
            mode_str = str(play_mode).strip().lower()
            return "shuffle" in mode_str

        return None

    @property
    def repeat_mode(self) -> str | None:
        """Repeat mode from cached status: 'one', 'all', or 'off'."""
        if self.player._status_model is None:
            return None

        repeat_val = getattr(self.player._status_model, "repeat", None)
        if repeat_val is not None:
            repeat_str = str(repeat_val).strip().lower()
            if repeat_str in {"one", "single", "repeat_one", "repeatone", "1"}:
                return "one"
            elif repeat_str in {"all", "repeat_all", "repeatall", "2"}:
                return "all"
            else:
                return "off"

        loop_mode = getattr(self.player._status_model, "loop_mode", None)
        if loop_mode is not None:
            try:
                loop_val = int(loop_mode)
                is_repeat_one = bool(loop_val & 1)
                is_repeat_all = bool(loop_val & 2)
                if is_repeat_one:
                    return "one"
                elif is_repeat_all:
                    return "all"
            except (TypeError, ValueError):
                pass

        play_mode = getattr(self.player._status_model, "play_mode", None)
        if play_mode is not None:
            mode_str = str(play_mode).strip().lower()
            if "repeat_one" in mode_str or mode_str in {"one", "single"}:
                return "one"
            elif "repeat_all" in mode_str or mode_str in {"all"}:
                return "all"
            elif "repeat" in mode_str and "shuffle" not in mode_str:
                return "all"

        return "off"

    @property
    def eq_preset(self) -> str | None:
        """Current EQ preset from cached status."""
        if self.player._status_model is None:
            return None
        return self.player._status_model.eq_preset

    @property
    def shuffle(self) -> bool | None:
        """Shuffle state from cached status (alias for shuffle_state)."""
        return self.shuffle_state

    @property
    def repeat(self) -> str | None:
        """Repeat mode from cached status (alias for repeat_mode)."""
        return self.repeat_mode

    @property
    def wifi_rssi(self) -> int | None:
        """Wi-Fi signal strength (RSSI) from cached status."""
        if self.player._status_model is None:
            return None
        return self.player._status_model.wifi_rssi

    # === Available Sources and Outputs ===

    @property
    def available_sources(self) -> list[str] | None:
        """Available input sources from cached device info."""
        if self.player._device_info is None:
            return None

        if self.player._device_info.input_list is not None:
            return [source for source in self.player._device_info.input_list if source and source.lower() != "wifi"]

        physical_inputs = []

        if self.player._device_info and self.player._device_info.plm_support is not None:
            try:
                if isinstance(self.player._device_info.plm_support, str):
                    plm_value = (
                        int(self.player._device_info.plm_support.replace("0x", "").replace("0X", ""), 16)
                        if "x" in self.player._device_info.plm_support.lower()
                        else int(self.player._device_info.plm_support)
                    )
                else:
                    plm_value = int(self.player._device_info.plm_support)

                if plm_value & (1 << 0):
                    physical_inputs.append("line_in")
                if plm_value & (1 << 1):
                    physical_inputs.append("bluetooth")
                if plm_value & (1 << 2):
                    physical_inputs.append("usb")
                if plm_value & (1 << 3):
                    physical_inputs.append("optical")
                if plm_value & (1 << 5):
                    physical_inputs.append("coaxial")
                if plm_value & (1 << 7):
                    physical_inputs.append("line_in_2")
            except (ValueError, TypeError):
                pass

        if not physical_inputs and self.player._device_info and self.player._device_info.model:
            model_lower = self.player._device_info.model.lower()
            physical_inputs.append("bluetooth")
            if "wiim mini" in model_lower:
                physical_inputs.extend(["line_in", "optical"])
            elif "wiim amp" in model_lower:
                physical_inputs.append("line_in")
            elif "wiim ultra" in model_lower:
                physical_inputs.extend(["line_in", "optical", "coaxial", "usb", "hdmi"])
            elif "wiim pro" in model_lower or "wiim" in model_lower:
                physical_inputs.extend(["line_in", "optical", "coaxial"])
            else:
                physical_inputs.extend(["line_in", "optical"])
        elif not physical_inputs:
            physical_inputs.extend(["bluetooth", "line_in", "optical"])

        always_available = [
            "spotify",
            "airplay",
            "dlna",
            "amazon",
            "tidal",
            "qobuz",
            "deezer",
            "iheartradio",
            "pandora",
            "tunein",
        ]

        all_sources = list(dict.fromkeys(physical_inputs + always_available))
        return all_sources

    @property
    def audio_output_mode(self) -> str | None:
        """Current audio output mode as friendly name."""
        if self.player._audio_output_status is None:
            return None

        hardware_mode = self.player._audio_output_status.get("hardware")
        if hardware_mode is None:
            return None

        source = self.player._audio_output_status.get("source")
        if source == 1 or source == "1":
            return "Bluetooth Out"

        try:
            mode_int = int(hardware_mode) if isinstance(hardware_mode, str) else hardware_mode
        except (ValueError, TypeError):
            return None

        return self.player.client.audio_output_mode_to_name(mode_int)

    @property
    def audio_output_mode_int(self) -> int | None:
        """Current audio output mode as integer."""
        if self.player._audio_output_status is None:
            return None

        source = self.player._audio_output_status.get("source")
        if source == 1 or source == "1":
            return 4

        hardware_mode = self.player._audio_output_status.get("hardware")
        if hardware_mode is None:
            return None

        try:
            return int(hardware_mode) if isinstance(hardware_mode, str) else hardware_mode
        except (ValueError, TypeError):
            return None

    @property
    def available_output_modes(self) -> list[str]:
        """Available audio output modes for this device."""
        if not self.player.client.capabilities.get("supports_audio_output", False):
            return []

        model = None
        if self.player._device_info:
            model = self.player._device_info.model

        if not model:
            return ["Line Out", "Optical Out", "Coax Out", "Bluetooth Out"]

        model_lower = model.lower()

        if "wiim amp" in model_lower:
            return ["Line Out"]
        elif "wiim mini" in model_lower:
            return ["Line Out", "Optical Out"]
        elif "wiim ultra" in model_lower:
            return ["Line Out", "Optical Out", "Coax Out", "Bluetooth Out", "HDMI Out"]
        elif "wiim pro" in model_lower or "wiim" in model_lower:
            return ["Line Out", "Optical Out", "Coax Out", "Bluetooth Out"]
        else:
            return ["Line Out", "Optical Out", "Coax Out", "Bluetooth Out"]

    @property
    def is_bluetooth_output_active(self) -> bool:
        """Check if Bluetooth output is currently active."""
        if self.player._audio_output_status is None:
            return False

        source = self.player._audio_output_status.get("source")
        return source == 1
