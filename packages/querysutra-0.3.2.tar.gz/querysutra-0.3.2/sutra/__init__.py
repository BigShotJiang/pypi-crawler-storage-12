"""
QuerySUTRA - Structured-Unstructured-Text-Retrieval-Architecture
Creates multiple structured tables from ANY data with AI

v0.3.2 - Professional release with comprehensive README
"""

__version__ = "0.3.2"

from sutra.sutra import SUTRA, QueryResult, quick_start

__all__ = ["SUTRA", "QueryResult", "quick_start"]
