class AiSkill:
    def __init__(self, host_url: str, object_uuid: str):
        self.host_url = host_url
        self.object_uuid = object_uuid
