from dbt_mcp.prompts.prompts import get_prompt  # noqa: F401
