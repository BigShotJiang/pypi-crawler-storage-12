The column name to trace lineage for.
