The fully qualified dbt model identifier (e.g., "model.my_project_name.my_model").

Do not use just the model name, always use the model full identifier. If you don't have the full identifier, the project name is the field `name:` in the `dbt_project.yml` file at the root of the dbt project.