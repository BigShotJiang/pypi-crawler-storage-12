List the resources in the your dbt project.
