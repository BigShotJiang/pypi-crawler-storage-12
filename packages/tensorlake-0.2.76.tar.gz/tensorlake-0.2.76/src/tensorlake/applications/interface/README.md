This package defined public Applications SDK interface.
No implementation details should be included here. Only the interfaces.