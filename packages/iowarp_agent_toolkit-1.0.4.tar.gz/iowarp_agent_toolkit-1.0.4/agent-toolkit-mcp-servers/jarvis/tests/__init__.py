"""Tests for Jarvis MCP - Pipeline Management for High-Performance Computing."""
