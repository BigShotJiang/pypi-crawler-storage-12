"""Placeholder test to prevent pytest exit code 5 (no tests collected)."""


def test_placeholder():
    """Placeholder test that always passes."""
    assert True
