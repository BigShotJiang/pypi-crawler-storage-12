"""
Tests package for Slurm MCP server.
Contains comprehensive test suites for all components.
"""
