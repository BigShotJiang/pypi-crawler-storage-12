"""
Pandas MCP Package

This package provides comprehensive pandas data analysis capabilities through the Model Context Protocol.
"""

__version__ = "1.0.0"
__author__ = "IoWarp Scientific MCPs"
__email__ = "contact@iowarp.org"
