"""
Tests for Plot MCP server.
"""
