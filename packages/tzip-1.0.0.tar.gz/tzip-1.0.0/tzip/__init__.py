"""tzip package

This package contains one CLI-facing module: tzip.
"""

__all__ = ["tzip"]
