from aiogram.fsm.state import StatesGroup, State


class MenuStates(StatesGroup):
    main1 = State()
    main2 = State()
