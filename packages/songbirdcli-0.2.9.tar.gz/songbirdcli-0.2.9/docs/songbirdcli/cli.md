# cli

::: songbirdcli.cli
    handler: python
