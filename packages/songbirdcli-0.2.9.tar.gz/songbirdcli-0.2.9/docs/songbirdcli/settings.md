# settings

::: songbirdcli.settings
    handler: python
