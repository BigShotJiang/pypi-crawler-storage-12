from nkotranslit.convert import NkoLatinConverter

__VERSION__ = '1.0.0'
__all__ = [
        'NkoLatinConverter',    
]

