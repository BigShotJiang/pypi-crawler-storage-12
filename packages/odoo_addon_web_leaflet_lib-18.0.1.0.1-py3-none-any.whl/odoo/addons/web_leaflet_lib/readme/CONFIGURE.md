- Go to Settings \> Technical \> Parameters \> System Parameters
- Create or edit the parameter with the key `leaflet.tile_url`
- As a value, set the url of the tiles server you chose. (See
  description)
