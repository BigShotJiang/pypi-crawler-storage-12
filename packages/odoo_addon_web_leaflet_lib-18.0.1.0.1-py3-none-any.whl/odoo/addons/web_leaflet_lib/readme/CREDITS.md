The module embed the Leaflet.js library.
