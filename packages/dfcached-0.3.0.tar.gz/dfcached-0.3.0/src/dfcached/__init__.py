from .decorator import persist_cache

__all__ = ["persist_cache"]

