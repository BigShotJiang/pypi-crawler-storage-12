To use this module, you need to:

1.  Merge purchase order with required criteria
