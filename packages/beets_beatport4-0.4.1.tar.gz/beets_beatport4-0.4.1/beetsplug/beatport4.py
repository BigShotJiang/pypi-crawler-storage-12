# This file is part of beets.
# Copyright 2016, Adrian Sampson.
# Copyright 2022, Szymon "Samik" Tarasiński.
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.

"""Adds Beatport release and track search support to the autotagger
"""

from __future__ import annotations

import json
import os
import re
import tempfile
import time
from datetime import timedelta, datetime
from json import JSONDecodeError
from urllib.parse import urlparse, parse_qs, urlencode
from collections.abc import Sequence

from beets import art
from beets.dbcore.types import MusicalKey

import beets
import beets.ui
import requests
from beets.autotag.hooks import AlbumInfo, TrackInfo
from beets.autotag.match import distance
from beets.metadata_plugins import MetadataSourcePlugin
from beets.util import cached_classproperty
import confuse  # type: ignore[import-untyped]
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from beets.library import Item

USER_AGENT = f'beets/{beets.__version__} +https://beets.io/'


class BeatportAPIError(Exception):
    pass


class BeatportOAuthToken:
    def __init__(self, data):
        self.access_token = str(data['access_token'])
        if 'expires_at' in data:
            self.expires_at = data['expires_at']
        else:
            self.expires_at = time.time() + int(data['expires_in'])
        self.refresh_token = str(data['refresh_token'])

    def is_expired(self):
        """ Checks if token is expired
        """
        return time.time() + 30 >= self.expires_at

    def encode(self):
        """ Encodes the class into json serializable object
        """
        return {
            'access_token': self.access_token,
            'expires_at': self.expires_at,
            'refresh_token': self.refresh_token
        }


class BeatportLabel:
    def __init__(self, data):
        self.id = str(data['id'])
        self.name = str(data['name'])

    def __str__(self):
        return "<BeatportLabel: {}>".format(self.name)

    def __repr__(self):
        return str(self)


class BeatportArtist:
    def __init__(self, data):
        self.id = str(data['id'])
        self.name = str(data['name'])

    def __str__(self):
        return "<BeatportArtist: {}>".format(self.name)

    def __repr__(self):
        return str(self)


class BeatportRelease:
    def __init__(self, data):
        self.id = str(data['id'])
        self.name = str(data['name'])
        self.artists = []
        self.tracks = []
        self.type = None
        if 'artists' in data:
            self.artists = [BeatportArtist(x) for x in data['artists'] if
                            x is not None]
        if 'label' in data:
            self.label = BeatportLabel(data['label'])
        if 'catalog_number' in data:
            self.catalog_number = str(data['catalog_number'])
        if 'slug' in data:
            self.url = "https://beatport.com/release/{}/{}" \
                .format(data['slug'], data['id'])
        if 'type' in data:
            self.type = data['type']['name']
        if 'publish_date' in data:
            self.publish_date = datetime.strptime(
                data['publish_date'], '%Y-%m-%d')

    def __str__(self):
        if len(self.artists) < 4:
            artist_str = ", ".join(x.name for x in self.artists)
        else:
            artist_str = "Various Artists"
        return "<BeatportRelease: {} - {} ({})>" \
            .format(artist_str, self.name, self.catalog_number)

    def __repr__(self):
        return str(self)


class BeatportTrack:
    def __init__(self, data):
        self.id = str(data['id'])
        self.name = str(data['name'])
        self.artists = [BeatportArtist(x) for x in data['artists'] if
                        x is not None]
        self.length = timedelta(milliseconds=data.get('length_ms', 0) or 0)
        self.number = None
        self.initial_key = None
        self.url = None
        self.bpm = None
        self.genre = None
        self.image_url = None
        self.image_dynamic_url = None
        if not self.length:
            try:
                min, sec = (data.get('length', '0:0') or '0:0').split(':')
                self.length = timedelta(minutes=int(min), seconds=int(sec))
            except ValueError:
                pass
        if data.get('key') and data['key']['name']:
            self.initial_key = self._normalize_key(str(data['key']['name']))
        if data.get('bpm'):
            self.bpm = int(data['bpm'])
        if 'sub_genre' in data and data['sub_genre']:
            self.genre = str(data['sub_genre']['name'])
        elif 'genre' in data and data['genre']:
            self.genre = str(data['genre']['name'])
        if 'mix_name' in data:
            self.mix_name = data['mix_name']
        if 'number' in data:
            self.number = data['number']
        if 'release' in data:
            self.release = BeatportRelease(data['release'])
            if 'image' in data['release']:
                if 'uri' in data['release']['image']:
                    self.image_url = data['release']['image']['uri']
                if 'dynamic_uri' in data['release']['image']:
                    self.image_dynamic_url = data['release']['image'][
                        'dynamic_uri']
        if 'remixers' in data:
            self.remixers = data['remixers']
        if 'slug' in data:
            self.url = "https://beatport.com/track/{}/{}" \
                .format(data['slug'], data['id'])

    def __str__(self):
        artist_str = ", ".join(x.name for x in self.artists)
        return "<BeatportTrack: {} - {} ({})>" \
            .format(artist_str, self.name, self.mix_name)

    def __repr__(self):
        return str(self)

    def _normalize_key(self, key):
        """ Normalize new Beatport key name format (e.g "Eb Major, C# Minor)
         for backwards compatibility

        :param key:    Key name
        """
        (letter_sign, chord) = key.split(" ")
        return MusicalKey().normalize((letter_sign + chord.lower())[:-2])


class BeatportMyAccount:
    def __init__(self, data):
        self.id = str(data['id'])
        self.email = str(data['email'])
        self.username = str(data['username'])

    def __str__(self):
        return "<BeatportMyAccount: {} <{}>>" \
            .format(self.username, self.email)

    def __repr__(self):
        return str(self)


class Beatport4Client:
    def __init__(self, log, client_id=None, username=None, password=None,
                 beatport_token=None):
        """ Initiate the client and make sure it is correctly authorized
        If beatport_token is passed, it is used to make a call to
        /my/account endpoint to check if the token is access_token is valid

        If the token is not passed, or it is invalid, it authorizes the user
        using username and password credentials given in the config
        and uses the token obtained in this way

        :param beatport_token:    BeatportOAuthToken
        """
        self._api_base = 'https://api.beatport.com/v4'
        self._api_client_id = client_id
        self._beatport_redirect_uri = '{}/auth/o/post-message/' \
            .format(self._api_base)
        self.username = username
        self.password = password
        self.beatport_token = beatport_token
        self._log = log

        # Token from the file passed
        if self.beatport_token and not self.beatport_token.is_expired():
            self._log.debug('Trying beatport token loaded from file')
            try:
                my_account = self.get_my_account()
                self._log.debug(
                    'Beatport authorized with stored token as {0} <{1}>',
                    my_account.username, my_account.email)
            except BeatportAPIError:
                # Token from the file could be invalid, authorize and fetch new
                self._log.debug('Beatport token loaded from file invalid')
                self.beatport_token = self._authorize()
        elif self.username and self.password:
            self.beatport_token = self._authorize()
        else:
            raise BeatportAPIError(
                'Neither Beatport username/password, nor access token is given.'
            )

    def _fetch_beatport_client_id(self):
        """ Fetch Beatport API client ID from the docs script
        """
        html = requests.get('https://api.beatport.com/v4/docs/').content.decode(
            'utf-8')
        scripts_matches = re.findall(r"src=.(.*js)", html)
        for script_url in scripts_matches:
            url = 'https://api.beatport.com{}'.format(script_url)
            js = requests.get(url.format(script_url)).content.decode('utf-8')
            client_id_matches = re.findall(r"API_CLIENT_ID: \'(.*)\'", js)
            if client_id_matches:
                return client_id_matches[0]
        raise BeatportAPIError('Could not fetch API_CLIENT_ID')

    def _authorize(self):
        """ Authorize client and fetch access token.
        Uses username and password provided by the user in the config.
        Uses authorization_code grant type in Beatport OAuth flow.

        :returns:               Beatport OAuth token
        :rtype:                 :py:class:`BeatportOAuthToken`
        """
        self._log.debug('Started authorizing to the API using '
                        'username and password')
        if self._api_client_id is None:
            self._api_client_id = self._fetch_beatport_client_id()

        with requests.Session() as s:
            # Login to get session id and csrf token cookies
            response = s.post(url=self._make_url('/auth/login/'),
                              json={
                                  'username': self.username,
                                  'password': self.password
                              })
            data = response.json()
            if 'username' not in data or 'email' not in data:
                # response contains error message from Beatport API
                self._log.debug('Beatport auth error: {0}', data)
                raise BeatportAPIError(data)

            self._log.debug(
                'Authorized with username and password as {0} <{1}>',
                data['username'], data['email'])

            # Fetch authorization code
            response = s.get(url=self._make_url('/auth/o/authorize/', query={
                'response_type': 'code',
                'client_id': self._api_client_id,
                'redirect_uri': self._beatport_redirect_uri
            }), allow_redirects=False)

            if 'invalid_request' in response.content.decode('utf-8'):
                raise BeatportAPIError(
                    re.findall(r"<p>(.*)</p>",
                               response.content.decode('utf-8'))[0]
                )

            # Auth code is available in the Location header
            next_url = urlparse(self._make_url(response.headers['Location']))
            auth_code = parse_qs(next_url.query)['code'][0]

            self._log.debug('Authorization code: {0}', auth_code)

            # Exchange authorization code for access token
            response = s.post(url=self._make_url('/auth/o/token/', query={
                'code': auth_code,
                'grant_type': 'authorization_code',
                'redirect_uri': self._beatport_redirect_uri,
                'client_id': self._api_client_id
            }))
            data = response.json()
            self._log.debug('Exchanged authorization code for '
                            'the access token: {0}', json.dumps(data))

            return BeatportOAuthToken(data)

    def get_my_account(self):
        """ Get information about current account.

        :returns:               The user account information
        :rtype:                 :py:class:`BeatportMyAccount`
        """
        response = self._get('/my/account')
        return BeatportMyAccount(response)

    def search(self, query, model='releases', details=True):
        """ Perform a search of the Beatport catalogue.

        :param query:           Query string
        :param model:           Type of releases to search for, can be
                                'release' or 'track'
        :param details:         Retrieve additional information about the
                                search results. Currently this will fetch
                                the tracklist for releases and do nothing for
                                tracks
        :returns:               Search results
        :rtype:                 generator that yields
                                py:class:`BeatportRelease` or
                                :py:class:`BeatportTrack`
        """
        response = self._get('catalog/search', q=query, per_page=5, type=model)
        if model == 'releases':
            for release in response['releases']:
                if details:
                    release = self.get_release(release['id'])
                    if release:
                        yield release
                    continue
                yield BeatportRelease(release)
        elif model == 'tracks':
            for track in response['tracks']:
                yield BeatportTrack(track)

    def get_release(self, beatport_id):
        """ Get information about a single release.

        :param beatport_id:     Beatport ID of the release
        :returns:               The matching release
        :rtype:                 :py:class:`BeatportRelease`
        """
        try:
            response = self._get(f'/catalog/releases/{beatport_id}/')
        except BeatportAPIError as e:
            self._log.debug((str(e)))
            return None
        if response:
            release = BeatportRelease(response)
            release.tracks = self.get_release_tracks(beatport_id)
            return release
        return None

    def get_release_tracks(self, beatport_id):
        """ Get all tracks for a given release.

        :param beatport_id:     Beatport ID of the release
        :returns:               Tracks in the matching release
        :rtype:                 list of :py:class:`BeatportTrack`
        """
        try:
            response = self._get(f'/catalog/releases/{beatport_id}/tracks/',
                                 per_page=100)
        except BeatportAPIError as e:
            self._log.debug((str(e)))
            return []
        # we are not using BeatportTrack(t) because "number" field is missing
        return [self.get_track(t['id']) for t in response if t is not None]

    def get_track(self, beatport_id):
        """ Get information about a single track.

        :param beatport_id:     Beatport ID of the track
        :returns:               The matching track
        :rtype:                 :py:class:`BeatportTrack`
        """
        try:
            response = self._get(f'/catalog/tracks/{beatport_id}/')
        except BeatportAPIError as e:
            self._log.debug(str(e))
            return None
        return BeatportTrack(response)

    def _make_url(self, endpoint, query=None):
        """ Get complete URL for a given API endpoint. """
        if not endpoint.startswith('/'):
            endpoint = '/' + endpoint
        if query:
            return self._api_base + endpoint + '?' + urlencode(query)
        return self._api_base + endpoint

    def get_image(self, beatport_id, width=None, height=None):
        """ Fetches image from Beatport in a binary format

        :param beatport_id: Beatport ID of the track
        :param width:       Width of the image to fetch using dynamic uri
        :param height:      Height of the image to fetch using dynamic uri
        :returns:           Image as a binary data or None if one not found
        """
        track = self.get_track(beatport_id)
        if track is None:
            return None

        if width == 0:
            width = None
        if height == 0:
            height = None

        if width is not None or height is not None:
            image_url = track.image_dynamic_url.format(
                w=width or height,
                h=height or width
            )
        else:
            image_url = track.image_url
        if image_url is None:
            return None

        try:
            headers = self._get_request_headers()
            self._log.debug("Fetching image from URL: {}".format(image_url))
            response = requests.get(image_url, headers=headers)
        except Exception as e:
            raise BeatportAPIError(
                "Error fetching image from Beatport: {}"
                .format(e)
            )
        if not response:
            raise BeatportAPIError(
                "Error {} for '{}"
                .format(response.status_code, image_url)
            )

        return response.content

    def _get(self, endpoint, **kwargs):
        """ Perform a GET request on a given API endpoint.

        Automatically extracts result data from the response and converts HTTP
        exceptions into :py:class:`BeatportAPIError` objects.
        """
        try:
            headers = self._get_request_headers()
            response = requests.get(self._make_url(endpoint),
                                    params=kwargs,
                                    headers=headers)
        except Exception as e:
            raise BeatportAPIError(
                "Error connecting to Beatport API: {}"
                .format(e)
            )
        if not response or response.status_code >= 400:
            raise BeatportAPIError(
                "Error {0.status_code} for '{0.request.path_url}"
                .format(response)
            )

        json_response = response.json()

        # Handle both list and single entity responses
        if 'results' in json_response:
            return json_response['results']
        return json_response

    def _get_request_headers(self):
        """Formats Authorization and User-Agent HTTP client request headers

        :returns: HTTP client request headers
        """
        return {
            'Authorization': 'Bearer {}'
            .format(self.beatport_token.access_token),
            'User-Agent': USER_AGENT
        }


class Beatport4Plugin(MetadataSourcePlugin):
    @cached_classproperty
    def data_source(cls) -> str:
        return 'Beatport'

    def __init__(self):
        super().__init__()
        self.config.add({
            'tokenfile': 'beatport_token.json',
            'data_source_mismatch_penalty': 0.5,
            'username': None,
            'password': None,
            'client_id': None,
            'art': False,
            'art_overwrite': False,
            'art_width': None,
            'art_height': None,
        })
        self.client = None
        self.register_listener('import_begin', self.setup)
        self.register_listener('import_task_files', self.import_task_files)

    def setup(self):
        """Loads access token from the file, initializes the client
        and writes the token to the file if new one is fetched during
        client authorization
        """
        beatport_token = None
        # Get the OAuth token from a file
        try:
            with open(self._tokenfile()) as f:
                beatport_token = BeatportOAuthToken(json.load(f))

        except (OSError, AttributeError, JSONDecodeError, KeyError):
            # File does not exist, or has invalid format
            pass

        try:
            self.client = Beatport4Client(
                log=self._log,
                client_id=self.config['client_id'].get(),
                username=self.config['username'].get(),
                password=self.config['password'].get(),
                beatport_token=beatport_token
            )
        except BeatportAPIError as e:
            # Invalid client_id, username/password or other problems
            beets.ui.print_(str(e))

            # Retry manually
            token = self._prompt_for_token()

            self.client = Beatport4Client(
                log=self._log,
                client_id=None,
                username=None,
                password=None,
                beatport_token=token
            )

        with open(self._tokenfile(), 'w') as f:
            json.dump(self.client.beatport_token.encode(), f)

    def import_task_files(self, task):
        """import_task_files event listener fires after track has been written
        Based on 'embed_art' config value and a data source,
        tries to fetch image for a track and embeds it into a track file

        :param task: import_task_files event parameter
        """
        try:
            if self.config['art'].get():
                if task.match.info.data_source != self.data_source:
                    return

                if not self.config['art_overwrite'].get() and \
                        art.get_art(self._log, task.item):
                    self._log.debug(
                        'File already contains an art, skipping fetching new')
                    return

                for track in task.imported_items():
                    track_id = track.get('mb_trackid')
                    image_data = self.client.get_image(
                        track_id,
                        self.config['art_width'].get(),
                        self.config['art_height'].get(),
                    )
                    if image_data is None:
                        return

                    temp_image = tempfile.NamedTemporaryFile(delete=False)
                    temp_image.write(image_data)

                    art.embed_item(self._log, task.item, temp_image.name)
                    temp_image.close()
                    os.remove(temp_image.name)
        except (OSError, BeatportAPIError, AttributeError) as e:
            self._log.debug('Failed to embed image: {}'.format(str(e)))

    def _prompt_for_token(self):
        """Prompts user to paste the OAuth token in the console and
        writes the contents to the beatport_token.json file.
        Returns parsed JSON.
        """
        data = json.loads(beets.ui.input_(
            "Could not fetch token. Check your beatport username and password "
            "in the config, or try to get token manually.\n"
            "Login at https://api.beatport.com/v4/docs/ "
            "and paste /token endpoint response from the browser:"))

        return BeatportOAuthToken(data)

    def _tokenfile(self):
        """Get the path to the JSON file for storing the OAuth token.
        """
        return self.config['tokenfile'].get(confuse.Filename(in_app_dir=True))

    def candidates(
        self,
        items: Sequence[Item],
        artist: str,
        album: str,
        va_likely: bool,
    ) -> list[AlbumInfo]:
        """Returns a list of AlbumInfo objects for beatport search results
        matching release and artist (if not various).
        """
        if va_likely:
            query = album
        else:
            query = f'{artist} {album}'
        try:
            return self._get_releases(query)
        except BeatportAPIError as e:
            self._log.debug('API Error: {0} (query: {1})', e, query)
            return []

    def item_candidates(
        self, item: Item, artist: str, title: str
    ) -> list[TrackInfo]:
        """Returns a list of TrackInfo objects for beatport search results
        matching title and artist.
        """
        query = f'{artist} {title}'
        try:
            return self._get_tracks(query)
        except BeatportAPIError as e:
            self._log.debug('API Error: {0} (query: {1})', e, query)
            return []

    def album_for_id(self, album_id: str) -> AlbumInfo | None:
        """Fetches a release by its Beatport ID or URL and returns an AlbumInfo
        object or None if the query is not a valid ID or release is not found.
        """
        if not album_id:
            self._log.debug('No release ID provided.')
            return None
        self._log.debug('Searching for release {0}', album_id)
        match = re.search(r'(^|beatport\.com/release/.+/)(\d+)$', album_id)
        if not match:
            self._log.debug('Not a valid Beatport release ID.')
            return None
        release = self.client.get_release(match.group(2))
        if release:
            return self._get_album_info(release)
        return None

    def track_for_id(self, track_id: str) -> TrackInfo | None:
        """Fetches a track by its Beatport ID and returns a
        TrackInfo object or None if the track is not a valid
        Beatport ID or track is not found.
        """
        self._log.debug('Searching for track {0}', track_id)
        match = re.search(r'(^|beatport\.com/track/.+/)(\d+)$', track_id)
        if not match:
            self._log.debug('Not a valid Beatport track ID.')
            return None
        bp_track = self.client.get_track(match.group(2))
        if bp_track is not None:
            return self._get_track_info(bp_track)
        return None

    def _get_releases(self, query):
        """Returns a list of AlbumInfo objects for a beatport search query.
        """
        # Strip non-word characters from query. Things like "!" and "-" can
        # cause a query to return no results, even if they match the artist or
        # album title. Use `re.UNICODE` flag to avoid stripping non-english
        # word characters.
        query = re.sub(r'\W+', ' ', query, flags=re.UNICODE)
        # Strip medium information from query, Things like "CD1" and "disk 1"
        # can also negate an otherwise positive result.
        query = re.sub(r'\b(CD|disc)\s*\d+', '', query, flags=re.I)
        albums = [self._get_album_info(x)
                  for x in self.client.search(query)]
        return albums

    def _get_album_info(self, release):
        """Returns an AlbumInfo object for a Beatport Release object.
        """
        va = len(release.artists) > 3
        artist, artist_id = self._get_artist(
            ((artist.id, artist.name) for artist in release.artists if
             artist is not None)
        )
        if va:
            artist = "Various Artists"
        tracks = [self._get_track_info(x) for x in release.tracks if
                  x is not None]

        return AlbumInfo(album=release.name, album_id=release.id,
                         artist=artist, artist_id=artist_id, tracks=tracks,
                         albumtype=release.type, va=va,
                         year=release.publish_date.year,
                         month=release.publish_date.month,
                         day=release.publish_date.day,
                         label=release.label.name,
                         catalognum=release.catalog_number, media='Digital',
                         data_source=self.data_source, data_url=release.url,
                         genre=None)

    def _get_track_info(self, track):
        """Returns a TrackInfo object for a Beatport Track object.
        """
        title = track.name
        if track.mix_name != "Original Mix":
            title += f" ({track.mix_name})"
        artist, artist_id = self._get_artist(
            ((artist.id, artist.name) for artist in track.artists if
             artist is not None)
        )
        length = track.length.total_seconds()
        return TrackInfo(title=title, track_id=track.id,
                         artist=artist, artist_id=artist_id,
                         length=length, index=track.number,
                         medium_index=track.number,
                         data_source=self.data_source, data_url=track.url,
                         bpm=track.bpm, initial_key=track.initial_key,
                         genre=track.genre)

    def _get_artist(self, artists):
        """Returns an artist string (all artists) and an artist_id (the main
        artist) for a list of Beatport release or track artists.
        """
        return MetadataSourcePlugin.get_artist(
            artists=artists, id_key=0, name_key=1
        )

    def _get_tracks(self, query):
        """Returns a list of TrackInfo objects for a Beatport query.
        """
        bp_tracks = self.client.search(query, model='tracks')
        tracks = [self._get_track_info(x) for x in bp_tracks if x is not None]
        return tracks
