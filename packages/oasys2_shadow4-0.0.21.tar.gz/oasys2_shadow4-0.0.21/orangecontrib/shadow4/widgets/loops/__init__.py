NAME = "Shadow4 \u23F5 Loops"

DESCRIPTION = "Loops."

BACKGROUND = "#b9d47a"

ICON = "icons/loops.png"

PRIORITY = 4.4