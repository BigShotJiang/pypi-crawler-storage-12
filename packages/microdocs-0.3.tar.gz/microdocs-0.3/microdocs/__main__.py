"""Entry point for python -m microdocs."""

from __future__ import annotations

from microdocs.cli import main

if __name__ == "__main__":
    main()
