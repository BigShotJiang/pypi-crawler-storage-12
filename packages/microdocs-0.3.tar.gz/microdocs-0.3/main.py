"""Development entry point for running microdocs CLI directly."""

from microdocs.cli import app

if __name__ == "__main__":
    app()
