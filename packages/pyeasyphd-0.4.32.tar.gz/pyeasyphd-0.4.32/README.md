# pyeasyphd

![Visitors](https://visitor-badge.laobi.icu/badge?page_id=Easy-PhD.pyeasyphd)
[![License](https://img.shields.io/badge/license-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.en.html)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyeasyphd)
[![PyPI](https://img.shields.io/pypi/v/pyeasyphd)](https://pypi.org/project/pyeasyphd/)
[![Commitizen friendly](https://img.shields.io/badge/commitizen-friendly-brightgreen.svg)](http://commitizen.github.io/cz-cli/)
