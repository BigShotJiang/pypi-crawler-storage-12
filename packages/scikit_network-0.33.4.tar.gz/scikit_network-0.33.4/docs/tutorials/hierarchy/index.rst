Hierarchy
*********


.. toctree::

   paris
   louvain_recursion
   louvain_iteration
