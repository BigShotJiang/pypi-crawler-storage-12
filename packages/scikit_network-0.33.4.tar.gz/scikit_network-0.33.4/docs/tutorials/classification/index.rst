Classification
**************


.. toctree::

    pagerank
    diffusion
    propagation
    knn
    metrics
