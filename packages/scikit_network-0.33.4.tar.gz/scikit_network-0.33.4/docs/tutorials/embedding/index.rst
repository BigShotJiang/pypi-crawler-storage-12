Embedding
*********


.. toctree::

   spectral
   svd
   gsvd
   pca
   random_projection
   louvain_embedding
   spring
   forceatlas



