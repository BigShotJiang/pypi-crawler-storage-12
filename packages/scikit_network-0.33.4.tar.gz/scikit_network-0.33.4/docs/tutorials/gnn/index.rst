GNN
**************


.. toctree::

    gnn_classifier
