.. _linkpred:

Link prediction
***************

Link prediction algorithms.

The attribute ``links_``  gives the predicted links of each node as a sparse matrix.


Nearest neighbors
-----------------

.. autoclass:: sknetwork.linkpred.NNLinker

