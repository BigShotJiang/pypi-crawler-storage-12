.. _regression:

Regression
**********

Regression algorithms.

The attribute ``values_`` assigns a value to each node of the graph.

Diffusion
---------
.. autoclass:: sknetwork.regression.Diffusion

Dirichlet
---------
.. autoclass:: sknetwork.regression.Dirichlet

