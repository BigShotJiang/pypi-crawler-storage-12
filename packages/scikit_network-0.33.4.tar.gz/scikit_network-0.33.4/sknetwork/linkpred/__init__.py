"""link prediction module"""
from sknetwork.linkpred.nn import NNLinker
