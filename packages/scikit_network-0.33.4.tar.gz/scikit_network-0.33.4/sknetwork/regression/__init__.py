"""regression module"""
from sknetwork.regression.base import BaseRegressor
from sknetwork.regression.diffusion import Diffusion, Dirichlet

