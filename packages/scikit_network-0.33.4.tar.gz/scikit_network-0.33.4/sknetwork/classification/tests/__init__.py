"""tests for classification"""
