"""tests for visualization"""
