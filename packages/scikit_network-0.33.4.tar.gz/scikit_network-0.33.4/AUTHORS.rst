=======
Credits
=======

The project started with the Master internship of Bertrand Charpentier and
the PhD theses of Nathan de Lara and Quentin Lutz, under the supervision of Thomas Bonald at Télécom Paris,
Institut Polytechnique de Paris.

Development Lead
----------------

* Thomas Bonald <thomas.bonald@telecom-paris.fr>
* Simon Delarue <simon.delarue@telecom-paris.fr>
* Marc Jeanmougin <marc.jeanmougin@telecom-paris.fr>

Former lead
-----------

* Quentin Lutz <quentin.lutz@telecom-paris-alumni.fr>
* Nathan de Lara <nathan.de-lara@polytechnique.org>

Contributors
------------

* Bertrand Charpentier
* Maximilien Danisch
* François Durand
* Alexandre Hollocou
* Fabien Mathieu
* Yohann Robert
* Julien Simonnet
* Alexis Barreaux
* Rémi Jaylet
* Victor Manach
* Pierre Pébereau
* Armand Boschin
* Tiphaine Viard
* Flávio Juvenal
* Wenzhuo Zhao
* Henry Carscadden
* Yiwen Peng
* Ahmed Zaiou
* Laurène David
