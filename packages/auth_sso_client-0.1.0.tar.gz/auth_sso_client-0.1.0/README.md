## auth-sso-client SDK

这个目录包含可独立打包的客户端 SDK，用于在 Python/FastAPI 应用中集成基于 auth_server 的企业微信 SSO 能力。

目录结构：

- `pyproject.toml`：SDK 的打包与依赖配置；
- `auth_sso_client/`：实际 Python 包源码。

SDK 的具体用法与 API 说明见包内文档：

- 包源码：`auth_root/client_sdk/auth_sso_client/*.py`
- 详细 README：`auth_root/app/auth_sso_client/README.md`（当前仍放在 auth_server 子项目中，后续可迁移到 SDK 根目录）。

