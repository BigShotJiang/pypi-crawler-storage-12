## cdf 

### Improved

- [alpha] When uploading instances using the `cdf data upload` command,
Toolkit now skips read-only properties as these cannot be set through
the API. This means, for example, CogniteAsset and CogniteFile instances
can now be uploaded and will not fail anymore.

## templates

No changes.