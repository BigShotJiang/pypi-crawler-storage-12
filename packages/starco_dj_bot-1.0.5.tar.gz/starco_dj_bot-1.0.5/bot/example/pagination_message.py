from ..ext.base import Base,MH,QH
from ..models import Message
class NodeUser(Base):
    def __init__(self):
        super().__init__('user',1)

    def n_test(self):
        e = MH()
        e.filters = self.match_filter('n_test')
        async def act():
            def formater(item):
                return {'key': item.pk, 'data': item.message_id}
            self.pagination('test', Message.objects.all(), formater, 11, '\n-------------\n', True)
            msg,btn = await self.make_pagination_pm('test', 1)
            await self.bot.send_message(self.update.effective_chat.id, msg, reply_markup=btn)

        e.callback = act