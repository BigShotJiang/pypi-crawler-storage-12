from ..core.base import Base
from bot.utils.mixin.is_chat_member import ChatMemberCheck,IsChatMemberMixin,ChatInfo

class NodeUser(Base,IsChatMemberMixin):
    def __init__(self):
        super().__init__('user',1)
        self.chats_must_be_joined = [
            ChatInfo('🌟 کانال اطلاع رسانی 🌟', '@yozdlb'),
        ]

    async def after_setup(self):
        print('after_setupafter_setupafter_setup')
        c = ChatMemberCheck(self.chats_must_be_joined, self)
        result = await c.check(
            '✨ جهت اطلاع از اخرین اخبار ربات عضو شوید.',
            '✅ عضو شدم',
            'start',
            self.update.effective_user.id
        )
        if not result:
            self.allow_continue = False
            return
        else:
            self.allow_continue = True