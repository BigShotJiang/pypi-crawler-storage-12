from django.core.management import call_command
from django.core.management.base import BaseCommand
from pathlib import Path
from django.conf import settings
import os,json
from bot.models import User
from dotenv import load_dotenv
from bot.core.used_texts_key import keys
load_dotenv()

role_class='''
from bot.core.base import Base, MH
class Node{}(Base):
    def __init__(self):
        super().__init__('{}')
        self.menu_btns = []
        self.menu_btns_pattern = 2
        # self.add_middleware(middleware_func)
        # self.add_command('start','start')
        # self.add_command('help','help')

    def n_start(self):
        e = MH()
        e.filters = '/start'
        async def act():
            await self.start_action()

        e.callback = act
        self.node(e)
'''

class Command(BaseCommand):
    help = 'Creates bot_panel directory structure in Django root'

    def add_arguments(self, parser):
        parser.add_argument(
            '--force',
            action='store_true',
            help='Force creation even if directory exists',
        )

    def handle(self, *args, **options):
        # Get Django project root (where manage.py is located)
        django_root = Path(settings.BASE_DIR)
        call_command('bot_env', add_missing=True, show_values=True)
        load_dotenv()
        bot_panel_dir = django_root /os.getenv('PANEL_DIR')

        try:
            # Create main bot_panel directory
            bot_panel_dir.mkdir(exist_ok=True)
            self.stdout.write(
                self.style.SUCCESS(f'Created directory: {bot_panel_dir}')
            )

            # Create __init__.py
            init_file = bot_panel_dir / '__init__.py'
            init_file.touch()
            self.stdout.write(
                self.style.SUCCESS(f'Created file: {init_file}')
            )

            # Create core subdirectory
            core_dir = bot_panel_dir / 'texts'
            core_dir.mkdir(exist_ok=True)
            self.stdout.write(
                self.style.SUCCESS(f'Created directory: {core_dir}')
            )
            core_dir = bot_panel_dir / 'roles'
            core_dir.mkdir(exist_ok=True)
            self.stdout.write(
                self.style.SUCCESS(f'Created directory: {core_dir}')
            )
            for i in User.LEVELS:
                target_dir = bot_panel_dir/ 'roles' / i
                target_dir.mkdir(exist_ok=True)

                file_path = target_dir / '__init__.py'
                if not file_path.exists():
                    txt=role_class.format(i.title(),i)
                    with open(file_path, 'w') as f:
                        f.write(txt)
                    self.stdout.write(
                        self.style.SUCCESS(f'Created file: {file_path}')
                    )

                self.stdout.write(
                    self.style.SUCCESS(f'Created directory: {core_dir}')
                )

            for i in User.LANGUAGES:
                target_dir = bot_panel_dir/ 'texts' / i
                target_dir.mkdir(exist_ok=True)
                file_path = target_dir / 'text.json'
                if not file_path.exists():
                    with open(file_path,'w') as f:
                        f.write(json.dumps({i: '' for i in keys}))
                    self.stdout.write(
                        self.style.SUCCESS(f'Created file: {file_path}')
                    )
                self.stdout.write(
                    self.style.SUCCESS(f'Created directory: {core_dir}')
                )
            #     file_path = core_dir / filename
            #     if not file_path.exists() or force:
            #         file_path.touch()
            #         self.stdout.write(
            #             self.style.SUCCESS(f'Created file: {file_path}')
            #         )

            self.stdout.write(
                self.style.SUCCESS(
                    '\nbot_panel directory structure created successfully!'
                )
            )

        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f'Error creating bot_panel directory: {str(e)}')
            )