import os
from time import sleep
from telegram.ext.filters import *
from django.core.cache import cache
from threading import Thread

class LevelFilter(BaseFilter):
    __slots__ = ("parent","admins")

    def __init__(self, parent,admins):
        super().__init__()
        self.parent = parent
        self.admins=admins

    def check_update(self, update):
        out= self.filter(update)
        return out

    def filter(self, update) -> bool:
        if not update.message:
            return False
        try:

            level = self.parent._level
            admins = self.admins
            user_id = update.message.from_user.id
            if user_id in admins:
                if level=='admin':
                    print(f"is admin")
                    return True
                return False

            cache_key=f"users_level"
            users_level = cache.get(cache_key)
            if users_level:
                if users_level.get(user_id):
                    return users_level.get(user_id)==level
            else:
                Thread(target=self.parent._set_users_level,kwargs={'empty_cache':True}).start()
                sleep(1)
                users_level = cache.get(cache_key)
                print(f"{user_id},{ users_level.get(user_id)},{users_level=}",level)
                if users_level:
                    return users_level.get(user_id,os.getenv('DEFAULT_LEVEL')) == level
                else:return False

            return level ==os.getenv('DEFAULT_LEVEL')
        except Exception as e:
            print(e)
            return False

class MatchText(BaseFilter):
    __slots__ = ('text',"parent",'exact')

    def __init__(self,text, parent,exact=True):
        super().__init__()
        self.parent = parent
        self.exact=exact
        self.text=text


    def check_update(self, update):
        out= self.filter(update)
        return out

    def filter(self, update) -> bool:
        if not update.effective_message:
            return False
        try:
            text = update.effective_message.text
            ttext=self.text
            if self.exact:
                return ttext==text
            else:
                return ttext in text
        except Exception as e:
            print(e)
        return False


class IsConversation(BaseFilter):
    __slots__ = ("parent","status","default")

    def __init__(self,parent,status,default=True):
        super().__init__()
        self.parent = parent
        self.status = status
        self.default=default


    def check_update(self, update):
        out= self.filter(update)
        return out

    def filter(self, update) -> bool:
        if not update.effective_message:
            return False
        try:
            return self.parent.context.user_data.get('is_conversation',self.default)==self.status
        except Exception as e:
            print(e)
        return self.default==self.status


class StatFilter(BaseFilter):
    __slots__ = ("parent","stat")

    def __init__(self,parent,stat):
        super().__init__()
        self.parent = parent
        self.stat = stat


    def check_update(self, update):
        out= self.filter(update)
        return out

    def filter(self, update) -> bool:
        if not update.effective_message:
            return False
        try:
            return self.parent.context.user_data.get('stat',{}).get('filter')==self.stat
        except Exception as e:
            print(e)
        return False

