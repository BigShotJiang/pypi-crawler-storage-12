# MES Test Data Library

A Python library for querying test data from MES systems using internal control codes.

## Installation

```bash
pip install mestestdata