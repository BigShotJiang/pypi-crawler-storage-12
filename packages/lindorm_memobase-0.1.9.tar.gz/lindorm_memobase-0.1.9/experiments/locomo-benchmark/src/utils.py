TECHNIQUES = ["mem0", "rag", "langmem", "zep", "openai", "memobase", "lindorm"]

METHODS = ["add", "search"]
