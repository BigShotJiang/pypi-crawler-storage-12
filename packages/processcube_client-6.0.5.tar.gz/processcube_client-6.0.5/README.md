# Client zur Anbindung des ProcessCube®

Der [ProcessCube®](https://www.5minds.de/processcube/) ist ein BPMN-Engine
der mittels [Python](http://processcube.io/docs/engine/clients/python/) 
angebunden werden kann. Die Beispiel sind unter [Developer-Seite](http://processcube.io/) 
zu finden.
