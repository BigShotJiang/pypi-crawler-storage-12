import setuptools
import re

try:
    from pip.req import parse_requirements
except ImportError:  # pip >= 10.0.0
    from pip._internal.req import parse_requirements

# TODO: mm - twine benutzen https://pypi.org/project/twine/
#
# Kurzanleitung
#    https://medium.com/@joel.barmettler/how-to-upload-your-python-package-to-pypi-65edc5fe9c56


parsed_reqs = parse_requirements('requirements.txt', session='hack')
installed_reqs = [str(ir.requirement) for ir in parsed_reqs]

with open("README.md", "r") as fh:
    long_description = fh.read()

# Normalize version string to be PEP 440 compliant
# CI tools might generate versions like '6.0.5-main-hash-random' which are invalid
# This fixes them to be valid: '6.0.5.dev0' for non-primary branches
raw_version = setuptools.sic('6.0.5-main-3f3079-mhg9elnd')
if '-main-' in raw_version or '-develop-' in raw_version:
    # Extract base version and convert to dev version
    base_version = raw_version.split('-')[0]
    if '-develop-' in raw_version:
        version = f"{base_version}.dev0"
    else:
        # For main branch, just use base version
        version = base_version
elif '-beta-' in raw_version:
    # Convert beta format: '6.0.4-beta-hash' to '6.0.4b1'
    parts = raw_version.split('-')
    version = f"{parts[0]}b1"
else:
    version = raw_version

setuptools.setup(
    name='processcube_client',
    version=version,
    author="5Minds IT-Solutions GmbH & Co. KG",
    author_email="ProcessCube@5Minds.de",
    description="A Client for the workflow engine of the ProcessCube platform.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    keywords="workflow-engine atlas-engine client bpmn",
    url="https://github.com/5minds/processcube_client.py",
    packages=setuptools.find_packages(),
    install_requires=installed_reqs,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
