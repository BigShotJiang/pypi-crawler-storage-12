# genoray-cli
CLI for genoray
