## 0.1.1 (2025-11-13)

### Fix

- dosage field handling for SVAR writing

## 0.1.0 (2025-10-09)

### Feat

- commit for bumping
