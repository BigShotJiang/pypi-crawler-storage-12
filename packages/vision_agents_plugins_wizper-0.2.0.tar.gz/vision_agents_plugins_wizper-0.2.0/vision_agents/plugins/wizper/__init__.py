from .stt import STT

# Re-export under the new namespace for convenience

__all__ = ["STT"]
