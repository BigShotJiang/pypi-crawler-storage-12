"""
API Routes Package

This package contains modular route definitions for the Squirrels API server.
""" 