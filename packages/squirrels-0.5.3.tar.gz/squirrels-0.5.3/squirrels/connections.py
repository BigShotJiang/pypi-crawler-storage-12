from ._manifest import ConnectionProperties, ConnectionTypeEnum

__all__ = ["ConnectionProperties", "ConnectionTypeEnum"]
