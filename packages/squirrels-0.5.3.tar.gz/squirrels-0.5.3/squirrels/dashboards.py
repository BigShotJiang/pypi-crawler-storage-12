from ._dashboards import PngDashboard, HtmlDashboard

__all__ = ["PngDashboard", "HtmlDashboard"]
