"""
Tests for Debian Repository Manager
"""
