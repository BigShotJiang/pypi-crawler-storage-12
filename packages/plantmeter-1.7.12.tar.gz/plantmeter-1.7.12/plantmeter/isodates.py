from somutils.isodates import *

import warnings
warnings.warn(
    "Please use somutils.isodates instead of plantmonitor.isodates",
    DeprecationWarning,
    stacklevel=2,
)


