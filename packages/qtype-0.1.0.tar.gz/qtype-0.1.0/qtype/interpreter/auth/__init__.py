"""
Authorization context managers for QType interpreter.
"""
