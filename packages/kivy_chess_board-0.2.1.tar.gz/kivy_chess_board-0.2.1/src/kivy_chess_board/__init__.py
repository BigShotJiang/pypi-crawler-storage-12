"""
.. include:: ../../README.md
"""

__docformat__ = "numpy"
from .chess_board import ChessBoard

__all__ = ["ChessBoard"]
