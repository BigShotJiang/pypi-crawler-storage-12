from llm_repeator_redis.arch_services import ArchFromRedisWorker

def main():
    ArchFromRedisWorker().run()

if __name__ == '__main__':
    main()
