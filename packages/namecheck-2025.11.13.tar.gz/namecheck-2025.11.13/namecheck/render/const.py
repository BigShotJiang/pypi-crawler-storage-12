## colors
PINK = "rgb(255,117,207)"
BLUE = "rgb(87,199,255)"
GREEN = "rgb(90,247,142)"
RED = "rgb(255,92,103)"
ORANGE = "rgb(255,201,140)"

## formatting
INDENT = " " * 3
