from pydantic import BaseModel, Field


IN_DIM = 63
NUM_POINTS = 21
