---
name: Feature Request
about: Suggest a feature to the project
title: ''
labels: feature
assignees: ''

---

<!-- Please only use this template for submitting feature requests -->

**What would you like to be added**:

**Why is this needed**:

**Completion requirements**:

This feature requires the following artifacts:

- [ ] Design doc
- [ ] API change
- [ ] Docs update

The artifacts should be linked in subsequent comments.
