"""Tests for Nomic partner integration."""
