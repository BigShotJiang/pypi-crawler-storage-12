'''
Date: 2025-04-27 15:18:24
LastEditors: Xinxiang Sun sunxinxiang24@mails.ucas.ac.cn
LastEditTime: 2025-06-09 08:48:57
FilePath: /research/autohea/src/autohea/core/fit.py
'''
import elisa.models as em
from elisa.models import *


