"""CLI entry point when running as python -m docs2synth.cli"""

from docs2synth.cli import main

if __name__ == "__main__":
    main()
