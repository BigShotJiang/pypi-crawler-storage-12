class Calculator:
    def add(self, a, b):
        """Adds two numbers together"""
        return a + b
    def divide(self, a, b):
        """Divides two numbers together"""
        return a / b;
    def subtract(self, a, b):
        """Subtracts two numbers together"""
        return a - b;

    def multiply(self, a, b):
        """Multiplies two numbers together"""
        return a*b;