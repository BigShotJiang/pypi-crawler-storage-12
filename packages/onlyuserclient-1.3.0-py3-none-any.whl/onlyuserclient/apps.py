from django.apps import AppConfig


class OnlyuserclientConfig(AppConfig):
    name = 'onlyuserclient'
