'''onlyuser 客户端开发包
'''

__version__='1.3.0'

VERSION = __version__