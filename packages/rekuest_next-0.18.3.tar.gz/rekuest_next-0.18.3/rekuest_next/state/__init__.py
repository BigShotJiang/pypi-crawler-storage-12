"""Functions to manage the state of the application."""
