#!/usr/bin/env python3
"""Setup script for backward compatibility with older pip versions."""

from setuptools import setup

# Configuration is in pyproject.toml
setup()