pytest-logikal
==============
Common tools for Python testing implemented as a `pytest <https://docs.pytest.org/>`_ plugin.

Getting Started
---------------
You can find the project documentation under `docs.logikal.io/pytest-logikal/
<https://docs.logikal.io/pytest-logikal/>`_.
