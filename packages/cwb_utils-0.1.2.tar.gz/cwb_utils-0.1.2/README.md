# utils

### install

~~~shell
pip install cwb-utils
~~~