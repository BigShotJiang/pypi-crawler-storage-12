from .nif_device import NonInteractingFermionicDevice  # Alias
from .nif_device import NonInteractingFermionicDevice as NIFDevice
