import { ReactWidget } from '@jupyterlab/ui-components';
import * as React from 'react';
import { ReplayLoadingOverlay } from './ReplayLoadingOverlay';

/**
 * Widget wrapper for the ReplayLoadingOverlay component
 * This creates a full-page loading overlay for replay mode
 */
export class ReplayLoadingOverlayWidget extends ReactWidget {
  private overlayVisible: boolean = false;

  constructor() {
    super();
    this.addClass('sage-replay-loading-overlay-widget');
    this.id = 'sage-replay-loading-overlay-widget';
  }

  /**
   * Show the loading overlay
   */
  public show(): void {
    this.overlayVisible = true;
    this.update();
  }

  /**
   * Hide the loading overlay
   */
  public hide(): void {
    this.overlayVisible = false;
    this.update();
  }

  /**
   * Check if the overlay is currently visible
   */
  public getIsVisible(): boolean {
    return this.overlayVisible;
  }

  /**
   * Render the React component
   */
  render(): JSX.Element {
    return <ReplayLoadingOverlay isVisible={this.overlayVisible} />;
  }
}
