# Multi-Fabric Example

Coming soon. See [examples/atd-inventory](https://github.com/titom73/avd-cli/tree/main/examples/atd-inventory) for reference.
