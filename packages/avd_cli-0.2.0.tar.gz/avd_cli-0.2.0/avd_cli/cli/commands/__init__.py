from avd_cli.cli.commands import generate  # noqa: F401
from avd_cli.cli.commands import info  # noqa: F401
