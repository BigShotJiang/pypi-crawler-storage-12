# leaf-1a

## Table of Contents

- [Management](#management)
  - [Management Interfaces](#management-interfaces)
  - [IP Name Servers](#ip-name-servers)
  - [Domain Lookup](#domain-lookup)
  - [Clock Settings](#clock-settings)
  - [Management API HTTP](#management-api-http)
- [Authentication](#authentication)
  - [Local Users](#local-users)
  - [Enable Password](#enable-password)
- [Monitoring](#monitoring)
  - [TerminAttr Daemon](#terminattr-daemon)
- [MLAG](#mlag)
  - [MLAG Summary](#mlag-summary)
  - [MLAG Device Configuration](#mlag-device-configuration)
- [Spanning Tree](#spanning-tree)
  - [Spanning Tree Summary](#spanning-tree-summary)
  - [Spanning Tree Device Configuration](#spanning-tree-device-configuration)
- [Internal VLAN Allocation Policy](#internal-vlan-allocation-policy)
  - [Internal VLAN Allocation Policy Summary](#internal-vlan-allocation-policy-summary)
  - [Internal VLAN Allocation Policy Device Configuration](#internal-vlan-allocation-policy-device-configuration)
- [VLANs](#vlans)
  - [VLANs Summary](#vlans-summary)
  - [VLANs Device Configuration](#vlans-device-configuration)
- [MAC Address Table](#mac-address-table)
  - [MAC Address Table Summary](#mac-address-table-summary)
  - [MAC Address Table Device Configuration](#mac-address-table-device-configuration)
- [Interfaces](#interfaces)
  - [Interface Defaults](#interface-defaults)
  - [Ethernet Interfaces](#ethernet-interfaces)
  - [Port-Channel Interfaces](#port-channel-interfaces)
  - [VLAN Interfaces](#vlan-interfaces)
- [Routing](#routing)
  - [Service Routing Protocols Model](#service-routing-protocols-model)
  - [IP Routing](#ip-routing)
  - [IPv6 Routing](#ipv6-routing)
- [Multicast](#multicast)
  - [IP IGMP Snooping](#ip-igmp-snooping)
- [802.1X Port Security](#8021x-port-security)
  - [802.1X Summary](#8021x-summary)
- [VRF Instances](#vrf-instances)
  - [VRF Instances Summary](#vrf-instances-summary)
  - [VRF Instances Device Configuration](#vrf-instances-device-configuration)

## Management

### Management Interfaces

#### Management Interfaces Summary

##### IPv4

| Management Interface | Description | Type | VRF | IP Address | Gateway |
| -------------------- | ----------- | ---- | --- | ---------- | ------- |
| Management1 | OOB_MANAGEMENT | oob | MGMT | 192.168.0.14/24 | - |

##### IPv6

| Management Interface | Description | Type | VRF | IPv6 Address | IPv6 Gateway |
| -------------------- | ----------- | ---- | --- | ------------ | ------------ |
| Management1 | OOB_MANAGEMENT | oob | MGMT | - | - |

#### Management Interfaces Device Configuration

```eos
!
interface Management1
   description OOB_MANAGEMENT
   no shutdown
   vrf MGMT
   ip address 192.168.0.14/24
```

### IP Name Servers

#### IP Name Servers Summary

| Name Server | VRF | Priority |
| ----------- | --- | -------- |
| 8.8.8.8 | MGMT | - |
| 1.1.1.1 | MGMT | - |

#### IP Name Servers Device Configuration

```eos
ip name-server vrf MGMT 1.1.1.1
ip name-server vrf MGMT 8.8.8.8
```

### Domain Lookup

#### DNS Domain Lookup Summary

| Source interface | vrf |
| ---------------- | --- |
| Management1 | MGMT |

#### DNS Domain Lookup Device Configuration

```eos
ip domain lookup vrf MGMT source-interface Management1
```

### Clock Settings

#### Clock Timezone Settings

Clock Timezone is set to **Europe/Paris**.

#### Clock Device Configuration

```eos
!
clock timezone Europe/Paris
```

### Management API HTTP

#### Management API HTTP Summary

| HTTP | HTTPS | UNIX-Socket | Default Services |
| ---- | ----- | ----------- | ---------------- |
| False | True | - | - |

#### Management API VRF Access

| VRF Name | IPv4 ACL | IPv6 ACL |
| -------- | -------- | -------- |
| MGMT | - | - |

#### Management API HTTP Device Configuration

```eos
!
management api http-commands
   protocol https
   no shutdown
   !
   vrf MGMT
      no shutdown
```

## Authentication

### Local Users

#### Local Users Summary

| User | Privilege | Role | Disabled | Shell |
| ---- | --------- | ---- | -------- | ----- |
| admin | 15 | network-admin | False | - |
| cvpadmin | 15 | network-admin | False | - |
| demo | 15 | network-admin | False | - |

#### Local Users Device Configuration

```eos
!
username admin privilege 15 role network-admin nopassword
username admin ssh-key ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCc9Fn0YN2MCogG2+cpWfZN8EMbL201WyMHI9v4uha0w6njm6OZmRQ/QJSz+hnNTkyj9pVTmFi7m039tCo4lezS/y6mQ5QZcylKiydQ2oGB6pzK6EpKEFj+1n+RvcKMkPUiVkgx/LgllaRG8+qFx96tXVkZOj/w17eVZzs6FvM9xwEENERCFEdh4fqVOb/mr7zVWjzDS8OWucSF6RuNWSW27OUzPp6QV0gGxytu4REfQbfitdy9HNaBtwU3dsf/LbcCtl1PAfVLM42ECMTq5La1nkW2P7NrVc5txDb+9uO1c2F9vfDOyMNnpLEBeStSb361yhbI4nOEcFs+amXMdM27
username cvpadmin privilege 15 role network-admin secret sha512 <removed>
username cvpadmin ssh-key ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCc9Fn0YN2MCogG2+cpWfZN8EMbL201WyMHI9v4uha0w6njm6OZmRQ/QJSz+hnNTkyj9pVTmFi7m039tCo4lezS/y6mQ5QZcylKiydQ2oGB6pzK6EpKEFj+1n+RvcKMkPUiVkgx/LgllaRG8+qFx96tXVkZOj/w17eVZzs6FvM9xwEENERCFEdh4fqVOb/mr7zVWjzDS8OWucSF6RuNWSW27OUzPp6QV0gGxytu4REfQbfitdy9HNaBtwU3dsf/LbcCtl1PAfVLM42ECMTq5La1nkW2P7NrVc5txDb+9uO1c2F9vfDOyMNnpLEBeStSb361yhbI4nOEcFs+amXMdM27
username demo privilege 15 role network-admin secret sha512 <removed>
username demo ssh-key ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCc9Fn0YN2MCogG2+cpWfZN8EMbL201WyMHI9v4uha0w6njm6OZmRQ/QJSz+hnNTkyj9pVTmFi7m039tCo4lezS/y6mQ5QZcylKiydQ2oGB6pzK6EpKEFj+1n+RvcKMkPUiVkgx/LgllaRG8+qFx96tXVkZOj/w17eVZzs6FvM9xwEENERCFEdh4fqVOb/mr7zVWjzDS8OWucSF6RuNWSW27OUzPp6QV0gGxytu4REfQbfitdy9HNaBtwU3dsf/LbcCtl1PAfVLM42ECMTq5La1nkW2P7NrVc5txDb+9uO1c2F9vfDOyMNnpLEBeStSb361yhbI4nOEcFs+amXMdM27
```

### Enable Password

Enable password has been disabled

## Monitoring

### TerminAttr Daemon

#### TerminAttr Daemon Summary

| CV Compression | CloudVision Servers | VRF | Authentication | Smash Excludes | Ingest Exclude | Bypass AAA |
| -------------- | ------------------- | --- | -------------- | -------------- | -------------- | ---------- |
| gzip | 192.168.0.5:9910 | MGMT | token,/tmp/token | ale,flexCounter,hardware,kni,pulse,strata | - | False |

#### TerminAttr Daemon Device Configuration

```eos
!
daemon TerminAttr
   exec /usr/bin/TerminAttr -cvaddr=192.168.0.5:9910 -cvauth=token,/tmp/token -cvvrf=MGMT -smashexcludes=ale,flexCounter,hardware,kni,pulse,strata -taillogs -cvsourceintf=Management1
   no shutdown
```

## MLAG

### MLAG Summary

| Domain-id | Local-interface | Peer-address | Peer-link |
| --------- | --------------- | ------------ | --------- |
| IDF1 | Vlan4094 | 10.255.255.5 | Port-Channel49 |

Dual primary detection is disabled.

### MLAG Device Configuration

```eos
!
mlag configuration
   domain-id IDF1
   local-interface Vlan4094
   peer-address 10.255.255.5
   peer-link Port-Channel49
   reload-delay mlag 300
   reload-delay non-mlag 330
```

## Spanning Tree

### Spanning Tree Summary

STP mode: **mstp**

#### MSTP Instance and Priority

| Instance(s) | Priority |
| -------- | -------- |
| 0 | 16384 |

#### Global Spanning-Tree Settings

- Spanning Tree disabled for VLANs: **4094**

### Spanning Tree Device Configuration

```eos
!
spanning-tree mode mstp
no spanning-tree vlan-id 4094
spanning-tree mst 0 priority 16384
```

## Internal VLAN Allocation Policy

### Internal VLAN Allocation Policy Summary

| Policy Allocation | Range Beginning | Range Ending |
| ------------------| --------------- | ------------ |
| ascending | 1006 | 1199 |

### Internal VLAN Allocation Policy Device Configuration

```eos
!
vlan internal order ascending range 1006 1199
```

## VLANs

### VLANs Summary

| VLAN ID | Name | Trunk Groups |
| ------- | ---- | ------------ |
| 100 | campus-users | - |
| 300 | campus-voice | - |
| 666 | GARBAGE_USERS | - |
| 667 | GARBAGE_PHONES | - |
| 4094 | MLAG | MLAG |

### VLANs Device Configuration

```eos
!
vlan 100
   name campus-users
!
vlan 300
   name campus-voice
!
vlan 666
   name GARBAGE_USERS
!
vlan 667
   name GARBAGE_PHONES
!
vlan 4094
   name MLAG
   trunk group MLAG
```

## MAC Address Table

### MAC Address Table Summary

- MAC address table entry maximum age: 300 seconds

### MAC Address Table Device Configuration

```eos
!
mac address-table aging-time 300
```

## Interfaces

### Interface Defaults

#### Interface Defaults Summary

- Default Routed Interface MTU: 1500

#### Interface Defaults Device Configuration

```eos
!
interface defaults
   mtu 1500
```

### Ethernet Interfaces

#### Ethernet Interfaces Summary

##### L2

| Interface | Description | Mode | VLANs | Native VLAN | Trunk Group | Channel-Group |
| --------- | ----------- | ---- | ----- | ----------- | ----------- | ------------- |
| Ethernet10 | 802.1x Standard Port - EAPoL with Multi Host | trunk phone | - | 666 | - | - |
| Ethernet11 | 802.1x Standard Port - EAPoL with Multi Host | trunk phone | - | 666 | - | - |
| Ethernet12 | 802.1x Standard Port - EAPoL with Multi Host | trunk phone | - | 666 | - | - |
| Ethernet13 | 802.1x Standard Port - EAPoL with Multi Host | trunk phone | - | 666 | - | - |
| Ethernet14 | 802.1x Standard Port - EAPoL with Multi Host | trunk phone | - | 666 | - | - |
| Ethernet15 | 802.1x Standard Port - EAPoL with Multi Host | trunk phone | - | 666 | - | - |
| Ethernet49 | MLAG_leaf-1b_Ethernet49 | *trunk | *- | *- | *MLAG | 49 |
| Ethernet50 | MLAG_leaf-1b_Ethernet50 | *trunk | *- | *- | *MLAG | 49 |
| Ethernet55 | L2_spine01_Ethernet1 | *trunk | *100,300,666-667 | *- | *- | 55 |

*Inherited from Port-Channel Interface

##### Phone Interfaces

| Interface | Mode | Native VLAN | Phone VLAN | Phone VLAN Mode |
| --------- | ---- | ----------- | ---------- | --------------- |
| Ethernet10 | trunk phone | 666 | 667 | untagged |
| Ethernet11 | trunk phone | 666 | 667 | untagged |
| Ethernet12 | trunk phone | 666 | 667 | untagged |
| Ethernet13 | trunk phone | 666 | 667 | untagged |
| Ethernet14 | trunk phone | 666 | 667 | untagged |
| Ethernet15 | trunk phone | 666 | 667 | untagged |

#### Ethernet Interfaces Device Configuration

```eos
!
interface Ethernet10
   description 802.1x Standard Port - EAPoL with Multi Host
   no shutdown
   switchport trunk native vlan 666
   switchport phone vlan 667
   switchport phone trunk untagged
   switchport mode trunk phone
   switchport
   spanning-tree portfast
   spanning-tree bpduguard enable
   dot1x pae authenticator
   dot1x authentication failure action traffic allow vlan 666
   dot1x reauthentication
   dot1x port-control auto
   dot1x host-mode multi-host authenticated
   dot1x mac based authentication
   dot1x timeout tx-period 3
   dot1x timeout reauth-period server
   dot1x reauthorization request limit 3
   dot1x unauthorized native vlan membership egress
!
interface Ethernet11
   description 802.1x Standard Port - EAPoL with Multi Host
   no shutdown
   switchport trunk native vlan 666
   switchport phone vlan 667
   switchport phone trunk untagged
   switchport mode trunk phone
   switchport
   spanning-tree portfast
   spanning-tree bpduguard enable
   dot1x pae authenticator
   dot1x authentication failure action traffic allow vlan 666
   dot1x reauthentication
   dot1x port-control auto
   dot1x host-mode multi-host authenticated
   dot1x mac based authentication
   dot1x timeout tx-period 3
   dot1x timeout reauth-period server
   dot1x reauthorization request limit 3
   dot1x unauthorized native vlan membership egress
!
interface Ethernet12
   description 802.1x Standard Port - EAPoL with Multi Host
   no shutdown
   switchport trunk native vlan 666
   switchport phone vlan 667
   switchport phone trunk untagged
   switchport mode trunk phone
   switchport
   spanning-tree portfast
   spanning-tree bpduguard enable
   dot1x pae authenticator
   dot1x authentication failure action traffic allow vlan 666
   dot1x reauthentication
   dot1x port-control auto
   dot1x host-mode multi-host authenticated
   dot1x mac based authentication
   dot1x timeout tx-period 3
   dot1x timeout reauth-period server
   dot1x reauthorization request limit 3
   dot1x unauthorized native vlan membership egress
!
interface Ethernet13
   description 802.1x Standard Port - EAPoL with Multi Host
   no shutdown
   switchport trunk native vlan 666
   switchport phone vlan 667
   switchport phone trunk untagged
   switchport mode trunk phone
   switchport
   spanning-tree portfast
   spanning-tree bpduguard enable
   dot1x pae authenticator
   dot1x authentication failure action traffic allow vlan 666
   dot1x reauthentication
   dot1x port-control auto
   dot1x host-mode multi-host authenticated
   dot1x mac based authentication
   dot1x timeout tx-period 3
   dot1x timeout reauth-period server
   dot1x reauthorization request limit 3
   dot1x unauthorized native vlan membership egress
!
interface Ethernet14
   description 802.1x Standard Port - EAPoL with Multi Host
   no shutdown
   switchport trunk native vlan 666
   switchport phone vlan 667
   switchport phone trunk untagged
   switchport mode trunk phone
   switchport
   spanning-tree portfast
   spanning-tree bpduguard enable
   dot1x pae authenticator
   dot1x authentication failure action traffic allow vlan 666
   dot1x reauthentication
   dot1x port-control auto
   dot1x host-mode multi-host authenticated
   dot1x mac based authentication
   dot1x timeout tx-period 3
   dot1x timeout reauth-period server
   dot1x reauthorization request limit 3
   dot1x unauthorized native vlan membership egress
!
interface Ethernet15
   description 802.1x Standard Port - EAPoL with Multi Host
   no shutdown
   switchport trunk native vlan 666
   switchport phone vlan 667
   switchport phone trunk untagged
   switchport mode trunk phone
   switchport
   spanning-tree portfast
   spanning-tree bpduguard enable
   dot1x pae authenticator
   dot1x authentication failure action traffic allow vlan 666
   dot1x reauthentication
   dot1x port-control auto
   dot1x host-mode multi-host authenticated
   dot1x mac based authentication
   dot1x timeout tx-period 3
   dot1x timeout reauth-period server
   dot1x reauthorization request limit 3
   dot1x unauthorized native vlan membership egress
!
interface Ethernet49
   description MLAG_leaf-1b_Ethernet49
   no shutdown
   channel-group 49 mode active
!
interface Ethernet50
   description MLAG_leaf-1b_Ethernet50
   no shutdown
   channel-group 49 mode active
!
interface Ethernet55
   description L2_spine01_Ethernet1
   no shutdown
   channel-group 55 mode active
```

### Port-Channel Interfaces

#### Port-Channel Interfaces Summary

##### L2

| Interface | Description | Mode | VLANs | Native VLAN | Trunk Group | LACP Fallback Timeout | LACP Fallback Mode | MLAG ID | EVPN ESI |
| --------- | ----------- | ---- | ----- | ----------- | ------------| --------------------- | ------------------ | ------- | -------- |
| Port-Channel49 | MLAG_leaf-1b_Port-Channel49 | trunk | - | - | MLAG | - | - | - | - |
| Port-Channel55 | L2_CAMPUS_SPINES_Port-Channel1 | trunk | 100,300,666-667 | - | - | - | - | 55 | - |

#### Port-Channel Interfaces Device Configuration

```eos
!
interface Port-Channel49
   description MLAG_leaf-1b_Port-Channel49
   no shutdown
   switchport mode trunk
   switchport trunk group MLAG
   switchport
!
interface Port-Channel55
   description L2_CAMPUS_SPINES_Port-Channel1
   no shutdown
   switchport trunk allowed vlan 100,300,666-667
   switchport mode trunk
   switchport
   mlag 55
```

### VLAN Interfaces

#### VLAN Interfaces Summary

| Interface | Description | VRF |  MTU | Shutdown |
| --------- | ----------- | --- | ---- | -------- |
| Vlan4094 | MLAG | default | 1500 | False |

##### IPv4

| Interface | VRF | IP Address | IP Address Virtual | IP Router Virtual Address | ACL In | ACL Out |
| --------- | --- | ---------- | ------------------ | ------------------------- | ------ | ------- |
| Vlan4094 |  default  |  10.255.255.4/31  |  -  |  -  |  -  |  -  |

#### VLAN Interfaces Device Configuration

```eos
!
interface Vlan4094
   description MLAG
   no shutdown
   mtu 1500
   no autostate
   ip address 10.255.255.4/31
```

## Routing

### Service Routing Protocols Model

Multi agent routing protocol model enabled

```eos
!
service routing protocols model multi-agent
```

### IP Routing

#### IP Routing Summary

| VRF | Routing Enabled |
| --- | --------------- |
| default | False |
| MGMT | False |

#### IP Routing Device Configuration

```eos
no ip routing vrf MGMT
```

### IPv6 Routing

#### IPv6 Routing Summary

| VRF | Routing Enabled |
| --- | --------------- |
| default | False |
| MGMT | false |

## Multicast

### IP IGMP Snooping

#### IP IGMP Snooping Summary

| IGMP Snooping | Fast Leave | Interface Restart Query | Proxy | Restart Query Interval | Robustness Variable |
| ------------- | ---------- | ----------------------- | ----- | ---------------------- | ------------------- |
| Enabled | - | - | - | - | - |

#### IP IGMP Snooping Device Configuration

```eos
```

## 802.1X Port Security

### 802.1X Summary

#### 802.1X Interfaces

| Interface | PAE Mode | Supplicant Profile | State | Phone Force Authorized | Reauthentication | Auth Failure Action | Host Mode | Mac Based Auth | Eapol |
| --------- | -------- | ------------------ | ----- | ---------------------- | ---------------- | ------------------- | --------- | -------------- | ----- |
| Ethernet10 | authenticator | - | auto | - | True | allow vlan 666 | multi-host | True | - |
| Ethernet11 | authenticator | - | auto | - | True | allow vlan 666 | multi-host | True | - |
| Ethernet12 | authenticator | - | auto | - | True | allow vlan 666 | multi-host | True | - |
| Ethernet13 | authenticator | - | auto | - | True | allow vlan 666 | multi-host | True | - |
| Ethernet14 | authenticator | - | auto | - | True | allow vlan 666 | multi-host | True | - |
| Ethernet15 | authenticator | - | auto | - | True | allow vlan 666 | multi-host | True | - |

## VRF Instances

### VRF Instances Summary

| VRF Name | IP Routing |
| -------- | ---------- |
| MGMT | disabled |

### VRF Instances Device Configuration

```eos
!
vrf instance MGMT
```
