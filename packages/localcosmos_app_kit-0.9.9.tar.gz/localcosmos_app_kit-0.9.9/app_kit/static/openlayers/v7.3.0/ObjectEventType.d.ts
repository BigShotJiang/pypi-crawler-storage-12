declare namespace _default {
    const PROPERTYCHANGE: string;
}
export default _default;
export type Types = 'propertychange';
//# sourceMappingURL=ObjectEventType.d.ts.map