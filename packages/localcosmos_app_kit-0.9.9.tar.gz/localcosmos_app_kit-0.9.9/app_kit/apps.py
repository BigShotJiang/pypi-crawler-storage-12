from django.apps import AppConfig


class AppKitConfig(AppConfig):
    name = 'app_kit'
