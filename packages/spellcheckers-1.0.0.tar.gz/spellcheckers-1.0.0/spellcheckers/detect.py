import string
import index


def detect_language(text):
    words = text.split(" ")
    word_count = len(words)
    word_iter = 0
    word = ""
    result_dict = dict()
    while word_iter < word_count:
        word = words[word_iter]
        if(word):
            orig_word = word
            
            for punct in string.punctuation:
                word = word.replace(punct, " ")
            length = len(word)
            index = 0
            
            while index < length:
                letter = word[index]
                if not letter.isalpha():
                    index = index + 1
                    continue
                if ((ord(letter) >= 0x0D00) & (ord(letter) <= 0x0D7F)):
                    result_dict[orig_word] = "ml_IN"
                    break
                if ((ord(letter) >= 0x0980) & (ord(letter) <= 0x09FF)):
                    result_dict[orig_word] = "bn_IN"
                    break
                if ((ord(letter) >= 0x0900) & (ord(letter) <= 0x097F)):
                    result_dict[orig_word] = "hi_IN"
                    break
                if ((ord(letter) >= 0x0A80) & (ord(letter) <= 0x0AFF)):
                    result_dict[orig_word] = "gu_IN"
                    break
                if ((ord(letter) >= 0x0A00) & (ord(letter) <= 0x0A7F)):
                    result_dict[orig_word] = "pa_IN"
                    break
                if ((ord(letter) >= 0x0C80) & (ord(letter) <= 0x0CFF)):
                    result_dict[orig_word] = "kn_IN"
                    break
                if ((ord(letter) >= 0x0B00) & (ord(letter) <= 0x0B7F)):
                    result_dict[orig_word] = "or_IN"
                    break
                if ((ord(letter) >= 0x0B80) & (ord(letter) <= 0x0BFF)):
                    result_dict[orig_word] = "ta_IN"
                    break
                if ((ord(letter) >= 0x0C00) & (ord(letter) <= 0x0C7F)):
                    result_dict[orig_word] = "te_IN"
                    break
                if ((letter <= u'z')):
                    result_dict[orig_word] = "en_US"
                    break
                index = index + 1
        word_iter = word_iter + 1
    return result_dict

index_component = index.Index()
index_component.run_index("ma_IN.index")

if __name__ == "__main__":
    sample_text = "नमस्कार, ഞാൻ മലയാളം സംസാരിക്കുന്നു."
    detected = detect_language(sample_text)
    for word, lang in detected.items():
        print(f"{word}: {lang}")
