import os
import base64
import json
import requests
import detect


def encode_image_from_path(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")


def encode_image_from_bytes(image_bytes):
    return base64.b64encode(image_bytes).decode("utf-8")


def extract_json_content(response_text):
    try:
        response_json = json.loads(response_text)
        content = response_json["choices"][0]["message"]["content"]
        content_json = json.loads(content.replace("'", '"'))
        return content_json.get("reject", "false").lower() == "true"
    except (KeyError, IndexError, json.JSONDecodeError) as e:
        return None


def detect_text(input_text):
    detected = detect.detect_language(input_text)
    for word, lang in detected.items():
        print(f"{word}: {lang}")


def check_text(text, api_key):
    if not api_key:
        raise ValueError("OpenAI API Key is required.")
    
    prompt = (
        "Check this text carefully to review the spelling. "
        "If there are spelling errors we must reject it. "
        "Return your answer in this exact format with no additional commentary: {'reject': 'true' or 'false'}."
    )

    payload = {
        "model": "gpt-4o",
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"{prompt}\n\nText: {text}",
                    }
                ],
            }
        ],
        "max_tokens": 30,
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }

    try:
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers=headers,
            json=payload,
        )
        response.raise_for_status()
        must_reject = extract_json_content(response.text)
        return bool(must_reject)
    except Exception:
        return False


def check_image(image, api_key):
    if not api_key:
        raise ValueError("OpenAI API Key is required.")

    if isinstance(image, (str, os.PathLike)):
        base64_image = encode_image_from_path(str(image))
    elif isinstance(image, (bytes, bytearray)):
        base64_image = encode_image_from_bytes(bytes(image))
    else:
        raise TypeError("image must be a file path or bytes")

    prompt = (
        "Check this image carefully to review the spelling. "
        "If there are spelling errors we must reject it. "
        "Return your answer in this exact format with no additional commentary: {'reject': 'true' or 'false'}."
    )

    payload = {
        "model": "gpt-4o",
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": prompt,
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/webp;base64,{base64_image}",
                            "detail": "low",
                        },
                    },
                ],
            }
        ],
        "max_tokens": 30,
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }

    try:
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers=headers,
            json=payload,
        )
        response.raise_for_status()
        must_reject = extract_json_content(response.text)
        return bool(must_reject)
    except Exception as e:
        return False
