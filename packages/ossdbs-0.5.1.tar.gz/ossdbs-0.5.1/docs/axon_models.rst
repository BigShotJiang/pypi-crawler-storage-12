Axon models
===========

TODO

API reference
-------------


Axon models
^^^^^^^^^^^

.. automodule:: ossdbs.axon_processing.AxonModels
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ossdbs.axon_processing.MRG2002
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ossdbs.axon_processing.McNeal1976
    :members:
    :undoc-members:
    :show-inheritance:



Neuron simulator
^^^^^^^^^^^^^^^^

.. automodule:: ossdbs.axon_processing.NeuronSimulator
    :members:
    :undoc-members:
    :show-inheritance:
