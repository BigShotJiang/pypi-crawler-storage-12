# Copyright 2023, 2024 Konstantin Butenko, Jan Philipp Payonk, Julius Zimmermann
# SPDX-License-Identifier: GPL-3.0-or-later

MATERIALS = {"Blood": 4, "Gray matter": 1, "White matter": 2, "CSF": 3, "Unknown": 0}
