# Copyright 2023, 2024 Julius Zimmermann
# SPDX-License-Identifier: GPL-3.0-or-later

"""Lead-DBS interface: generate input files for OSS-DBS."""
