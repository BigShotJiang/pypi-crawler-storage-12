# make sure OSS-DBS is properly installed!

# call the conversion script
# the first argument is the stimulation directory
prepareaxonmodel . --hemi_side 1 --description_file oss-dbs_parameters.mat 
