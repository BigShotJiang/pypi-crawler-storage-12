#!/usr/bin/env python
from ResourceBlock import ResourceBlock as Module
