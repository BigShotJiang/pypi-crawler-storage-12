



### <a name="manual"></a> Measure block

This block allows to measure avaliable width. This function might be useful
for inserting real-scale graphics (same font size as in rest of the document)

| Key       |      Description      | Default |
|:----------|:--------------------- | :---- |
| type      |  measure                 |  


Example:
```YAML
- type     : measure
```

Back to [Documentation](../../../README.md#block_basic)
