


### <a name="manual"></a> Table of content block

Inserts table of content calculated from chapter blocks.

| Key       |      Description      |
|:----------|:--------------------- |
| type      |  toc                 |  

Example:
```YAML
- type     : toc
```

Back to [Documentation](../../../README.md#block_structure)
