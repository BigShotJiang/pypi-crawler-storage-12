#!/usr/bin/env python
from NewpageBlock import NewpageBlock as Module
