def initialize():
    global currentLink
    currentLink = 0