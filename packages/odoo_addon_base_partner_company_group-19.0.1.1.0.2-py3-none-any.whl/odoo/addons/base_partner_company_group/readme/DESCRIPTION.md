This Module adds a company group field to companies, which is also
propagated to contacts and allows to search and group for the company
group in contact. If you need company group field in leads, sale orders
or invoices please install crm_partner_company_group,
sale_partner_company_group or account_partner_company_group accordingly.
