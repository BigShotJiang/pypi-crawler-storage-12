#
# SPDX-FileCopyrightText: Copyright (c) 2025 provide.io llc. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#

"""TODO: Add module docstring."""

from pyvider.data_sources.decorators import register_data_source

__all__ = [
    "register_data_source",
]

# 🐍🏗️🔚
