"""Library version."""

VERSION = "2025.11.1"
