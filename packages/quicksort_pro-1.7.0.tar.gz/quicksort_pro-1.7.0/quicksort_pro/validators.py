def validate_and_prepare(data, required_keys):
    """
    Validate that all items in data have required keys and prepare for processing.
    
    Args:
        data: List of dictionaries to validate
        required_keys: List of keys that must be present
    
    Returns:
        Validated and cleaned data
    
    Raises:
        ValueError: If validation fails
    """
    if not data:
        return []
    
    cleaned = []
    for i, item in enumerate(data):
        if not isinstance(item, dict):
            raise ValueError(f"Item at index {i} is not a dictionary")
        
        for key in required_keys:
            if key not in item:
                raise ValueError(f"Item at index {i} missing required key: {key}")
        
        cleaned.append(item)
    
    return cleaned


def clean_numeric_data(data, key, default=0.0):
    """
    Clean numeric data in a list of dictionaries, replacing invalid values.
    
    Args:
        data: List of dictionaries
        key: Key containing numeric data
        default: Default value for invalid entries
    
    Returns:
        Cleaned data with valid numeric values
    """
    cleaned = []
    
    for item in data:
        cleaned_item = item.copy()
        try:
            value = item.get(key, default)
            if isinstance(value, str):
                value = value.replace(',', '').replace('$', '').replace('£', '').replace('€', '')
                cleaned_item[key] = float(value)
            else:
                cleaned_item[key] = float(value)
        except (ValueError, TypeError):
            cleaned_item[key] = float(default)
        
        cleaned.append(cleaned_item)
    
    return cleaned
