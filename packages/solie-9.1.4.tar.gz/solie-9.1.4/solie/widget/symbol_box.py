from PySide6.QtWidgets import QGroupBox


class SymbolBox(QGroupBox):
    pass
