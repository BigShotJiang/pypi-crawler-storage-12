"""
Mojentic context module for managing shared working memory and context.
"""

from .shared_working_memory import SharedWorkingMemory
