Welcome to rkstiff's documentation!
====================================

.. include:: ../../README.md
   :parser: myst_parser.sphinx_

.. toctree::
   :maxdepth: 2
   :caption: Contents
   :hidden:

   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
