"""Integration tests for msvcpp-normalize-pe."""
