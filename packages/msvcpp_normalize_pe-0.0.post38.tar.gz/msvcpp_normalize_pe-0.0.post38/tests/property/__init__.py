"""Property-based tests for msvcpp-normalize-pe."""
