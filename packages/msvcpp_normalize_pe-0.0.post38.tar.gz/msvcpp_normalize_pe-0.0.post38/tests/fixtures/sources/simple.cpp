// tests/fixtures/sources/simple.cpp
// Minimal program for testing basic PE structure
#include <iostream>

int main() {
    std::cout << "msvcpp-normalize-pe test" << std::endl;
    return 0;
}
