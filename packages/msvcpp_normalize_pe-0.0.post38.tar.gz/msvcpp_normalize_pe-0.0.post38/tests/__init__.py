"""Test suite for msvcpp-normalize-pe."""
