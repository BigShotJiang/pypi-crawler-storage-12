"""Unit tests for msvcpp-normalize-pe."""
