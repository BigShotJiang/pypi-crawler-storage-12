"""Single source of truth for ChunkHound version."""

__version__ = "4.0.1"
