"""Language detection utilities."""

from .language_detector import detect_language

__all__ = ["detect_language"]
