"""ChunkHound API package - provides CLI and server interfaces."""

from chunkhound.version import __version__

__all__: list[str] = []
