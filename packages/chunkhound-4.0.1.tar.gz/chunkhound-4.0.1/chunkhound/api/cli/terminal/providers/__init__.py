"""Platform-specific terminal input providers."""
