qBittorrent Web API Client
==========================

.. include:: introduction.rst

.. toctree::
    :hidden:
    :maxdepth: 1

    Introduction <introduction.rst>
    Behavior & Configuration <behavior&configuration.rst>
    Async Support <async.rst>
    Performance <performance.rst>
    Exceptions <exceptions.rst>
    API Reference <api.rst>
