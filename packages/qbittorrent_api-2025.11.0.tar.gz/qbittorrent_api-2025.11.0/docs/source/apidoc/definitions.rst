Definitions
===========

.. automodule:: qbittorrentapi.definitions
    :members:
    :exclude-members: TorrentStates
    :undoc-members:
    :show-inheritance:
