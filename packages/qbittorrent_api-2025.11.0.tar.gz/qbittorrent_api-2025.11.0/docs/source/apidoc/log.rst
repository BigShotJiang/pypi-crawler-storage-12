Log
===

.. autoclass:: qbittorrentapi.log.LogAPIMixIn
    :members:
    :undoc-members:
    :exclude-members: log
    :show-inheritance:

.. autoclass:: qbittorrentapi.log.Log
    :members:
    :undoc-members:
    :special-members: __call__

.. autoclass:: qbittorrentapi.log.LogPeersList
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: qbittorrentapi.log.LogPeer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: qbittorrentapi.log.LogMainList
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: qbittorrentapi.log.LogEntry
    :members:
    :undoc-members:
    :show-inheritance:
