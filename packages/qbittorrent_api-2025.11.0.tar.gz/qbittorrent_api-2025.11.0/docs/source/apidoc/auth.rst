Authentication
==============

.. autoclass:: qbittorrentapi.auth.AuthAPIMixIn
    :members:
    :undoc-members:
    :exclude-members: auth, authorization
    :show-inheritance:

.. autoclass:: qbittorrentapi.auth.Authorization
    :members:
    :undoc-members:
