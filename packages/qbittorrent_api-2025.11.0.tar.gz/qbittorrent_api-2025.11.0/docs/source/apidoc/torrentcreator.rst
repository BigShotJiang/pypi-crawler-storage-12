Torrent Creator
===============

.. autoclass:: qbittorrentapi.torrentcreator.TorrentCreatorAPIMixIn
    :members:
    :undoc-members:
    :exclude-members: torrentcreator, torrentcreator_addTask, torrentcreator_torrentFile, torrentcreator_deleteTask
    :show-inheritance:

.. autoclass:: qbittorrentapi.torrentcreator.TorrentCreator
    :members:
    :undoc-members:
    :exclude-members: addTask, torrentFile, deleteTask

.. autoclass:: qbittorrentapi.torrentcreator.TorrentCreatorTaskDictionary
    :members:
    :undoc-members:
    :show-inheritance:
    :exclude-members: torrentFile, deleteTask

.. autoclass:: qbittorrentapi.torrentcreator.TorrentCreatorTaskStatus
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: qbittorrentapi.torrentcreator.TaskStatus
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: qbittorrentapi.torrentcreator.TorrentCreatorTaskStatusList
    :members:
    :undoc-members:
    :show-inheritance:
