Version
=======

.. autoclass:: qbittorrentapi._version_support.Version
    :members:
    :undoc-members:
