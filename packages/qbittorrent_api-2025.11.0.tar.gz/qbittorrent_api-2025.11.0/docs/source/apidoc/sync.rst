Sync
====

.. autoclass:: qbittorrentapi.sync.SyncAPIMixIn
    :members:
    :undoc-members:
    :exclude-members: sync, sync_torrentPeers
    :show-inheritance:

.. autoclass:: qbittorrentapi.sync.Sync
    :members:
    :undoc-members:
    :special-members: __call__

.. autoclass:: qbittorrentapi.sync.SyncMainDataDictionary
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: qbittorrentapi.sync.SyncTorrentPeersDictionary
    :members:
    :undoc-members:
    :show-inheritance:
