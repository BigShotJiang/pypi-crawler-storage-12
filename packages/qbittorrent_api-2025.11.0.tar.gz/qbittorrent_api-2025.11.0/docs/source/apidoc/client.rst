Client
======

.. autoclass:: qbittorrentapi.client.Client
    :members:
    :undoc-members:
    :show-inheritance:
