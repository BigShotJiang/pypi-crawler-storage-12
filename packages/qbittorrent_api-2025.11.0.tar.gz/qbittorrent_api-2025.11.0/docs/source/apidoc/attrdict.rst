AttrDict (internal)
===================

Copyright (c) 2013 Brendan Curran-Johnson

.. autoclass:: qbittorrentapi._attrdict.AttrDict
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: qbittorrentapi._attrdict.MutableAttr
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: qbittorrentapi._attrdict.Attr
    :members:
    :undoc-members:
    :show-inheritance:
