Exceptions
==========

.. automodule:: qbittorrentapi.exceptions
    :show-inheritance:
    :members:
    :undoc-members:
    :member-order: bysource
