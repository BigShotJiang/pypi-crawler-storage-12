"""Tests for the effects framework."""
