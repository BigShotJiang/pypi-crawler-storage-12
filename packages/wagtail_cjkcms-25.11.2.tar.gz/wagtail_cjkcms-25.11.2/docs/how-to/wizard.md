# Guide to HOWTOs

This section is aimed to help new users navigate through the "How to" section.

## Installation and configuration

### Starting new site?

### Working on existing, non-cjkcms Wagtail site?

## Single-site apps vs reusable apps

### Developing app bespoke for a site

### Developing reusable app

1. Adding blocks from multiple applications to main project
