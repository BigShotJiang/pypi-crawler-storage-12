# clear-embeds

## Required for: [oembed custom finder](../how-to/oembed_finder.md)

If you created embeds before adding the custom finder, or if vimeo does not display protected videos, run following command to remove instances of Embed model (otherwise the old embeds will not work)
```
./manage.py clear-embeds
```
