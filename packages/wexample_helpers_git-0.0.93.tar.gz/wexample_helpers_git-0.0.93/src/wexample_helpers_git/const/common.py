from __future__ import annotations

# filestate: python-constant-sort
GIT_PROVIDER_GITHUB = "github"
GIT_PROVIDER_GITLAB = "gitlab"

GIT_BRANCH_MAIN: str = "main"
