"""Metadata for Workflow Linter."""

__version__ = "2.1.0"
