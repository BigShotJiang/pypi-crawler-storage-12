from PyViCare.PyViCareGazBoiler import GazBoiler
from PyViCare.PyViCareHeatPump import HeatPump


class Hybrid(GazBoiler, HeatPump):
    pass
