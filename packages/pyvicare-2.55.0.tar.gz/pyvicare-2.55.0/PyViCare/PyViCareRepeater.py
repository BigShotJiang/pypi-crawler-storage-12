from PyViCare.PyViCareDevice import ZigbeeDevice


class Repeater(ZigbeeDevice):

    pass
