# simpleqlearn

A minimal, well-documented **Q-learning table update** function.

## Install
```bash
pip install simpleqlearn
