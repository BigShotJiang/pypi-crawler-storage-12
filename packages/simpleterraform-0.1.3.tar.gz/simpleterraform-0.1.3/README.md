
# Simpleterraform

A powerful CLI tool that automatically generates Terraform modules for AWS infrastructure with simple interactive prompts.

## ✨ Features

- 🌐 **Networking** - VPC, Subnets, Route Tables
- 🔒 **Security** - Security Groups  
- 💻 **Compute** - EC2, Auto Scaling, Load Balancer
- 🗄️ **Database** - RDS, Parameter Groups
- 📊 **Storage** - S3, EBS, EFS
- 📈 **Monitoring** - CloudWatch, Alarms
- ☸️ **Kubernetes** - EKS Cluster
- 🐳 **ECS** - Container Services

## 🚀 Quick Start

### Installation
```bash
pip install simpleterraform
```

### Usage
```bash
terraformgen
```

## 📖 How to Use

1. **Install the package**:
   ```bash
   pip install simpleterraform
   ```

2. **Run the tool**:
   ```bash
   terraformgen
   ```

3. **Follow the prompts**:
   - Enter your project name
   - Select module type
   - Configure resources
   - Get generated Terraform code!

## 🎯 Example

```bash
$ terraformgen

==================================================
🚀 TERRAFORM MODULE GENERATOR
==================================================

📁 Project Setup:
Enter your project name: my-app

📦 Available Modules:
1. Networking 🌐
2. Security 🔒
3. Compute 💻
...

✅ Select module number (1-8): 1
```

## 📁 Output

Generated Terraform files in `terraform-modules/` directory:
```
terraform-modules/
└── my-app-networking/
    ├── main.tf
    ├── variables.tf
    └── outputs.tf
```

## 🛠 Requirements

- Python 3.7+
- Terraform (for applying generated code)

## 📞 Support

- Email: 1109souravkumar@gmail.com

---

## What You Get
- ✅ 8 AWS modules ready to use
- ✅ Interactive configuration  
- ✅ Production-ready Terraform code
- ✅ Zero setup required

## Modules
- 🌐 Networking
- 🔒 Security
- 💻 Compute
- 🗄️ Database
- 📊 Storage
- 📈 Monitoring
- ☸️ Kubernetes
- 🐳 ECS

**Just run `terraformgen` and start building!** 🚀