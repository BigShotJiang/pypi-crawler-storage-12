..
    Copyright (C) 2020 CERN.
    Copyright (C) 2020 Northwestern University.

    Invenio-Drafts-Resources is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

==========================
 Invenio-Drafts-Resources
==========================

.. image:: https://img.shields.io/travis/inveniosoftware/Invenio-Drafts-Resources.svg
        :target: https://github.com/inveniosoftware//actions?query=workflow%3ACIInvenio-Drafts-Resources

.. image:: https://img.shields.io/coveralls/inveniosoftware/Invenio-Drafts-Resources.svg
        :target: https://coveralls.io/r/inveniosoftware/Invenio-Drafts-Resources

.. image:: https://img.shields.io/github/tag/inveniosoftware/Invenio-Drafts-Resources.svg
        :target: https://github.com/inveniosoftware/Invenio-Drafts-Resources/releases

.. image:: https://img.shields.io/pypi/dm/Invenio-Drafts-Resources.svg
        :target: https://pypi.python.org/pypi/Invenio-Drafts-Resources

.. image:: https://img.shields.io/github/license/inveniosoftware/Invenio-Drafts-Resources.svg
        :target: https://github.com/inveniosoftware/Invenio-Drafts-Resources/blob/master/LICENSE

Invenio Drafts Resources module to create REST APIs

TODO: Please provide feature overview of module

Further documentation is available on
https://Invenio-Drafts-Resources.readthedocs.io/
