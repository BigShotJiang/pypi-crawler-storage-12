{
    "name": "Sale Order Line Pricelist Fixed Discount",
    "summary": """
        Add discount from pricelist with fixed price.
    """,
    "author": "Mint System GmbH",
    "website": "https://github.com/Mint-system/",
    "category": "Sales",
    "version": "18.0.1.0.0",
    "license": "AGPL-3",
    "depends": ["sale", "product_pricelist_fixed_discount"],
    "installable": True,
    "application": False,
    "auto_install": False,
    "images": ["images/screen.png"],
}
