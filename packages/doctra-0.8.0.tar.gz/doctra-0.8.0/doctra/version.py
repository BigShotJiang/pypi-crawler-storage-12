"""Version information for Doctra."""
__version__ = '0.8.0'
