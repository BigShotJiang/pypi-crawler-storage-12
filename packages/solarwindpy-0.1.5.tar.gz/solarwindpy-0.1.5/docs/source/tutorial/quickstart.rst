Quickstart
==========

Get up and running with SolarWindPy.

Installation
------------

.. code-block:: bash

   pip install solarwindpy

Basic Usage
-----------

.. code-block:: python

   import solarwindpy as sw
   sw.__version__

