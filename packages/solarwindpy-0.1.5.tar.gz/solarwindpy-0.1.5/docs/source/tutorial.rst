Tutorial
========

This section walks through a short example using SolarWindPy.

.. toctree::
   :maxdepth: 1

   tutorial/quickstart
