=========================
Documentation Review Plan
=========================

The project documentation is reviewed every quarter to ensure accuracy and
relevance. Reviews should use the `Documentation Review` issue template and
include running `doc8` and rebuilding the Sphinx documentation.

