API Reference
=============

Complete API documentation for all modules, classes, and functions.

.. toctree::
   :maxdepth: 4

   api/modules
