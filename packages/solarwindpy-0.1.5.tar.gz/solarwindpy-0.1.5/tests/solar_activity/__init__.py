"""Tests for the solar_activity module."""
