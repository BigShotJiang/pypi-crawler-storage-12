"""Tests for sunspot_number package."""
