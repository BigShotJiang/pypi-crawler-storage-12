# Plotting labels tests
