# Plotting module tests
