"""Sunspot number data utilities."""

from . import sidc  # noqa: F401
