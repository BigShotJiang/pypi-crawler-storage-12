'''
# Nets.Secure Module

Modules - 
    - data_security - module for protect any data.
'''

from .data_security import (ClassApi as DatsSecureApi)