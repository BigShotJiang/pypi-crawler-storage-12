'''
# Simple Frame
Simplified module of framework for beginers.
'''

from .simple_frames import *
from .simple_nets import *