raise Exception(
    'MainMenu/M has moved out of iommi.experimental. Update imports and remove the .experimental part.'
)
