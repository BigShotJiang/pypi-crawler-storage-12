class RubiconException(Exception):
    pass
