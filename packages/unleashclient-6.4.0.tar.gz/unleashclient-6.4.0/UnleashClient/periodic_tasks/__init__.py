# ruff: noqa: F401
from .send_metrics import aggregate_and_send_metrics
