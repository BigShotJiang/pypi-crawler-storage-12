****************************************
Events
****************************************

.. autoenum :: UnleashClient.events.UnleashEventType

.. autoclass:: UnleashClient.events.UnleashEvent
