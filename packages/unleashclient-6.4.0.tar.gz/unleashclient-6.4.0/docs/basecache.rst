****************************************
BaseCache
****************************************

.. autoclass:: UnleashClient.cache.BaseCache

	.. automethod:: set

	.. automethod:: mset

	.. automethod:: get

	.. automethod:: exists

	.. automethod:: destroy
