****************************************
Strategy
****************************************

.. autoclass:: UnleashClient.strategies.Strategy

	.. automethod:: execute

	.. automethod:: load_provisioning

	.. automethod:: apply
