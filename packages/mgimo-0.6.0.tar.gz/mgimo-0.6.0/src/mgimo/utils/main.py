def hello():
    return "MGIMO finished"
