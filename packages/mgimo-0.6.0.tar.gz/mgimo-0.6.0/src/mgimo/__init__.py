from mgimo.utils.main import hello

__all__ = ["hello"]  # ruff wants it
