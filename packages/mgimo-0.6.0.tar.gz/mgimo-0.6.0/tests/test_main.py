from mgimo import hello


def test_hello():
    assert hello().startswith("MGIMO")
