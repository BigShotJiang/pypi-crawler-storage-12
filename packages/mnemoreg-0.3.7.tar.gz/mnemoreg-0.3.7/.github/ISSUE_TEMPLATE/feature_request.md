---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

### Summary
A short summary of the feature.

### Use case
Why is this useful? Include examples and expected API.

### Alternatives considered
If applicable, other approaches or libraries considered.

### Proposed changes
If you have an idea for implementation, sketch it here.
