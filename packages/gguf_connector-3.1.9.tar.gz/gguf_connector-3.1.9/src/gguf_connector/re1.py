
from .remover import GGUFRemoverApp
import tkinter

root = tkinter.Tk()
app = GGUFRemoverApp(root)
root.mainloop()