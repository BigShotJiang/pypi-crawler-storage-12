"""Top-level package for aa-contacts."""

__author__ = """Matteo Ghia"""
__email__ = 'matteo.ghia@yahoo.it'
__version__ = '0.10.2'

__github_url__ = 'https://github.com/Maestro-Zacht/aa-contacts'
__app_name_ua__ = 'aa-contacts'
__esi_compatibility_date__ = '2025-11-06'
