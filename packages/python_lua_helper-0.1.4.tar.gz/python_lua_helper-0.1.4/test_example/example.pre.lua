loader.log("example.pre.lua: message from optional pre script, you can define any extra lua logic for use in user config script")
