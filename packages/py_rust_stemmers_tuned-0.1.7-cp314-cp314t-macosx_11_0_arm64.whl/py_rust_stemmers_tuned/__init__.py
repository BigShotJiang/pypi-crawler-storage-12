from .py_rust_stemmers_tuned import *

__doc__ = py_rust_stemmers_tuned.__doc__
if hasattr(py_rust_stemmers_tuned, "__all__"):
    __all__ = py_rust_stemmers_tuned.__all__