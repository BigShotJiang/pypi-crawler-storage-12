from liblaf.lime.cli.parse import Lime


async def lime(self: Lime) -> None:
    raise NotImplementedError
