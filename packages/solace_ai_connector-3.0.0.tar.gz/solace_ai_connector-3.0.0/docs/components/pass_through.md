# PassThrough

What goes in comes out

## Configuration Parameters

```yaml
component_name: <user-supplied-name>
component_module: pass_through
component_config:
```

No configuration parameters


## Component Input Schema

```
{
  <freeform-object>
}
```


## Component Output Schema

```
{
  <freeform-object>
}
```
