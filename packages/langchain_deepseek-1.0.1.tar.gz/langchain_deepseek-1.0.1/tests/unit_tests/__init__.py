"""Unit tests for `langchain_deepseek` package."""
