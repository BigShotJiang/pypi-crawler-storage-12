#!/usr/bin/env python
"""Install script for module installation. Compatibility stub because pyproject.toml is used."""

import setuptools

if __name__ == '__main__':
    setuptools.setup()
