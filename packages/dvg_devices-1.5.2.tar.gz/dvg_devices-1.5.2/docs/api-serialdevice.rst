SerialDevice
===================
.. autoclass:: dvg_devices.BaseDevice.SerialDevice
   :members: ,
   :member-order: bysource

Methods
--------------------

.. automethod:: dvg_devices.BaseDevice.SerialDevice.set_ID_validation_query
.. automethod:: dvg_devices.BaseDevice.SerialDevice.set_read_termination
.. automethod:: dvg_devices.BaseDevice.SerialDevice.set_write_termination
.. automethod:: dvg_devices.BaseDevice.SerialDevice.readline
.. automethod:: dvg_devices.BaseDevice.SerialDevice.write
.. automethod:: dvg_devices.BaseDevice.SerialDevice.query
.. automethod:: dvg_devices.BaseDevice.SerialDevice.query_bytes
.. automethod:: dvg_devices.BaseDevice.SerialDevice.query_ascii_values
.. automethod:: dvg_devices.BaseDevice.SerialDevice.connect_at_port
.. automethod:: dvg_devices.BaseDevice.SerialDevice.scan_ports
.. automethod:: dvg_devices.BaseDevice.SerialDevice.auto_connect
.. automethod:: dvg_devices.BaseDevice.SerialDevice.close