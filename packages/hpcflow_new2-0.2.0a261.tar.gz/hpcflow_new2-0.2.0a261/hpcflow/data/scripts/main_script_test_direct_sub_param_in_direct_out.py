def main_script_test_direct_sub_param_in_direct_out(a):
    # process
    p2 = a + 100

    # return outputs
    return {"p2": p2}
