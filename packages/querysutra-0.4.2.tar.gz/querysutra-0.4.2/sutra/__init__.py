"""
QuerySUTRA v0.4.2
"""

__version__ = "0.4.2"

from sutra.sutra import SUTRA, QueryResult, quick_start

__all__ = ["SUTRA", "QueryResult", "quick_start"]
