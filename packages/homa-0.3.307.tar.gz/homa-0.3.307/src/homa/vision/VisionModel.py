class VisionModel:
    pass
