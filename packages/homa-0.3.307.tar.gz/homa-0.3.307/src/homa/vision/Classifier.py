from .VisionModel import VisionModel


class Classifier(VisionModel):
    pass
