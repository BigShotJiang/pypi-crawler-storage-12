from .RePU import RePU


class ReQU(RePU):
    def __init__(self):
        super().__init__(alpha=2)
