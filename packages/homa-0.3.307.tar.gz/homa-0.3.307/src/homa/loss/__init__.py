from .LogitNormLoss import LogitNormLoss
from .Loss import Loss
