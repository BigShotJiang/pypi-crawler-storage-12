# API Documentation: autosar_data.abstraction.datatype

::: autosar_data.abstraction.datatype
