# rdapy/rate/__init__.py

from .normalize import *
from .dra_ratings import *

name = "rate"
