# rdapy/minority/__init__.py

from .minority import *
from .majority_minority import *

name = "minority"
