# rdapy/equal/__init__.py

from .population import *

name = "equal"
