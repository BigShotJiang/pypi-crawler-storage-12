# rdapy/graph/__init__.py

from .connected import *
from .embedded import *

name = "graph"
