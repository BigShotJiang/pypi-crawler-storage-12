from gscoordinator.coordinator import launch_graphscope

launch_graphscope()
