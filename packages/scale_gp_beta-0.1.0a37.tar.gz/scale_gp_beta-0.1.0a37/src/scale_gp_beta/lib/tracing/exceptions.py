from scale_gp_beta._exceptions import SGPClientError


class ParamsCreationError(SGPClientError):
    pass
