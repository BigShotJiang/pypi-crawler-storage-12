from typing_extensions import Any, Dict

SpanInputParam = Dict[str, Any]
SpanOutputParam = Dict[str, Any]
SpanMetadataParam = Dict[str, Any]
