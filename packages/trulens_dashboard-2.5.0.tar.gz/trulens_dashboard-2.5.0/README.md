# trulens-dashboard

## Install Node.js

See [the Node.js website](https://nodejs.org/en/download/package-manager) for details

## Building

Build with `python -m build`
