__title__ = "django project base"
__version__ = "0.81.1"
default_app_config = "django_project_base.apps.DjangoProjectBaseConfig"

VERSION = __version__
