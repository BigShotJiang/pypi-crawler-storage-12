# Textzle Text Adventure Game Engine
# Learn more at https://codeberg.org/splot-dev/textzle
