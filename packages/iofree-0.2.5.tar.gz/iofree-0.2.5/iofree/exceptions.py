class NoResult(Exception):
    """"""


class ParseError(Exception):
    """"""
