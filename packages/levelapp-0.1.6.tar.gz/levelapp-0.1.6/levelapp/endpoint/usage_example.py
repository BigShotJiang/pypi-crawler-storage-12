import asyncio
import os
from pathlib import Path
from levelapp.endpoint.manager import EndpointConfig


async def main():
    manager = EndpointConfig(config_path=Path("../config/dashq_api.yaml"))

    mappings = manager.build_response_mapping(
        [
            {"field_path": "payload.message", "extract_as": "agent_reply"},
            {"field_path": "payload.metadata", "extract_as": "metadata"},
            {"field_path": "eventType", "extract_as": "event_type"},
            {"field_path": "payload.handoffMetadata", "extract_as": "handoff_metadata"},
        ]
    )

    print(f"Generated Mappings:\n{mappings}\n---")

    context = {
        "conversation_id": "238484ef-403b-43c5-9908-884486149d0b",
        "user_message": "Hello, world!"
    }

    tester = manager.get_tester(endpoint_name="dashq")
    os.environ["ENVIRONMENT"] = "test"
    results = await tester.test(context=context)
    print(f"Test results:\n{results}\n---")

    extracted_data = await manager.extract_response_data(
        endpoint_name="dashq",
        context=context,
        mappings=mappings,
    )
    print(f"Extracted Data:\n{extracted_data}\n---")

if __name__ == '__main__':
    asyncio.run(main())
