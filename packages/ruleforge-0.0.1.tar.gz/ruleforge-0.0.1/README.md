#Documentation
I'll update later since it's an MVP product, wait till stable version

Undergoing - cythonization and some more feature addition
