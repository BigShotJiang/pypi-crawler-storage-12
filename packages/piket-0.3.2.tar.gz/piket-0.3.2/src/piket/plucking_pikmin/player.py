from enum import IntEnum


# fmt: off
class Player(IntEnum):
    OLIMAR  = 0
    LOUIE   = 1
# fmt: on
