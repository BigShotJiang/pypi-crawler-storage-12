from enum import IntEnum


# fmt: off
class Object(IntEnum):
    NONE        = 0
    FIRE        = 1
    WATER       = 2
    ELECTRICITY = 3
    POISON      = 4
    GOAL        = 5
# fmt: on
