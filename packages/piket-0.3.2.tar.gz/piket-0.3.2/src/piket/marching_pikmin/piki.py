from enum import IntEnum


# fmt: off
class Piki(IntEnum):
    RED     = 0
    BLUE    = 1
    YELLOW  = 2
    PURPLE  = 3
    WHITE   = 4
# fmt: on
