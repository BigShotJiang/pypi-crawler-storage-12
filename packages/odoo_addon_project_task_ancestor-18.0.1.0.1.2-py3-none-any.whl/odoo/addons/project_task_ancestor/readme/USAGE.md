To use this module, you need to organize tasks in a hierarchical structure, 
where tasks can be nested within others.
The top-level parent task in this hierarchy is the ancestor task.

In both the Project and Timesheet apps, you can Group by the ancestor task, 
and this field is also available for use in Project and Timesheet reports.