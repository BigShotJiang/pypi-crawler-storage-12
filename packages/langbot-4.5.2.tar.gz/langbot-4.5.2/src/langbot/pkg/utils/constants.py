semantic_version = 'v4.5.2'

required_database_version = 11
"""Tag the version of the database schema, used to check if the database needs to be migrated"""

debug_mode = False

edition = 'community'
