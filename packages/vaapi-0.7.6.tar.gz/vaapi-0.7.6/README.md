# Berlin United - Visual Analytics Tool
Work in progress for an Analytics tool tailored to the needs of RoboCup SPL.

***
**Github**: https://github.com/efcy/visual_analytics
***

The repo contains some demos demonstrating how to use the sdk.

## How to build the SDK
You need to increment the version number in the __init__.py 
If the dependencies changed you need to update the dependencies list in the pyproject.toml
