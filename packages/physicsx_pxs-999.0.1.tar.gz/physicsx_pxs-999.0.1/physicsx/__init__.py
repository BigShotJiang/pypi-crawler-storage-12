"""
PhysicsX namespace package.

This is a namespace package that allows multiple distributions to provide
packages under the 'physicsx' namespace.
"""

# This is a namespace package - no content needed
__path__ = __import__('pkgutil').extend_path(__path__, __name__)
