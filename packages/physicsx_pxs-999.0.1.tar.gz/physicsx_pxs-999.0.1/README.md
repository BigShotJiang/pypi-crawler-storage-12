# ⚠️  MALICIOUS PACKAGE PROOF-OF-CONCEPT ⚠️

## 🚨 WARNING - READ THIS FIRST 🚨

**THIS IS A SECURITY DEMONSTRATION PACKAGE**

This package is a **malicious proof-of-concept** designed to demonstrate a **confusion attack** (also known as a dependency confusion or namespace shadowing attack).

**DO NOT USE THIS PACKAGE IN PRODUCTION!**

**DO NOT INSTALL THIS PACKAGE UNLESS YOU UNDERSTAND THE SECURITY IMPLICATIONS!**

---

## Purpose

This PoC demonstrates how a malicious package on public PyPI can shadow an internal company package with the same name, exploiting the Artifactory HTTP 403 issue that prevents package managers from falling back to the correct internal repository.

When imported, this package will:
- ✓ Display a large warning banner
- ✓ Attempt to read `~/.netrc` and other sensitive files
- ✓ Show proof of file access (file size, permissions, preview)
- ✓ Demonstrate security implications

---

## How to Build & Publish

```bash
# Build distribution packages
python -m build

# Upload to PyPI (requires PyPI account and token)
twine upload dist/*
```

⚠️  **CRITICAL WARNING**: This is for authorized security testing only.

---

## How to Test

Test direct installation:

```bash
pip install physicsx.pxs
python -c "import physicsx.pxs"
```

Expected behavior: Warning banner and file access demonstration.

---

## Expected Behavior

When imported, displays:
- Warning banner identifying this as a malicious PoC
- File access demonstration (attempts to read ~/.netrc)
- List of other sensitive files it could access
- Security implications explanation

---

## Cleanup

```bash
# Uninstall the package
pip uninstall -y physicsx.pxs

# Clear cache
pip cache purge
```

⚠️ **Note**: PyPI packages cannot be easily deleted, only "yanked".

---

## Legal & Ethical Considerations

**This PoC is for authorized security testing only.**

This package is provided "as is" for security demonstration purposes. Do not use for unauthorized testing or malicious purposes.

---

## References

- [PEP 503](https://peps.python.org/pep-0503/) - Simple Repository API
- [PEP 708](https://peps.python.org/pep-0708/) - Extending the Repository API
- [Dependency Confusion Attack](https://medium.com/@alex.birsan/dependency-confusion-4a5d60fec610)
