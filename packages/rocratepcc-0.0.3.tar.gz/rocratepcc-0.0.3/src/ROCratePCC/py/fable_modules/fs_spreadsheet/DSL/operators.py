from __future__ import annotations
from .expression import (OptionalSource_1__ctor_2B595, OptionalSource_1, RequiredSource_1__ctor_2B595, RequiredSource_1)

optional: OptionalSource_1[None] = OptionalSource_1__ctor_2B595(None)

required: RequiredSource_1[None] = RequiredSource_1__ctor_2B595(None)

__all__ = ["optional", "required"]

