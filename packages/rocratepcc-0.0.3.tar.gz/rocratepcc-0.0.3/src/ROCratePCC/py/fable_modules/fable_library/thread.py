import time


def sleep(milliseconds: int) -> None:
    time.sleep(milliseconds / 1000.0)
