from __future__ import annotations
from collections.abc import Callable
from typing import Any
from .py.main import Author, Constraint, Profile, License, CustomResourceDescriptor, Specification, Example, Guidance, UsedType, TextualResource, ResourceDescriptor, RootDataEntity