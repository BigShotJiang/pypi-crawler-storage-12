"""
AI module for LegalMind
"""

from .legal_ai import LegalMind

__all__ = ['LegalMind']
