# qrgenkit

A simple QR code generation utility with list, range, and single generators.