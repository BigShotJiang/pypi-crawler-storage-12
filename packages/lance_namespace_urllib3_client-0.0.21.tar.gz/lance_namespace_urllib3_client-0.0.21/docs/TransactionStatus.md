# TransactionStatus


## Enum

* `QUEUED` (value: `'QUEUED'`)

* `RUNNING` (value: `'RUNNING'`)

* `SUCCEEDED` (value: `'SUCCEEDED'`)

* `FAILED` (value: `'FAILED'`)

* `CANCELED` (value: `'CANCELED'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


