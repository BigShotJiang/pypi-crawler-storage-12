"""Runtime configuration constants for the Simulacrum SDK."""

BASE_URL: str = "https://api.smlcrm.com/"
"""Default base URL for Simulacrum API requests."""
