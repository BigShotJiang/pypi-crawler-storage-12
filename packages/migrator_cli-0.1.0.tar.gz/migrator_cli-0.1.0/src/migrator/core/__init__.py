"""Core business logic for migrator"""
