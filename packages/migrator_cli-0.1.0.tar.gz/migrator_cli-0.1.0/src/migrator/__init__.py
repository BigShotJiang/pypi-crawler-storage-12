"""Migrator - Universal migration CLI for Python apps"""

__version__ = "0.1.0"
