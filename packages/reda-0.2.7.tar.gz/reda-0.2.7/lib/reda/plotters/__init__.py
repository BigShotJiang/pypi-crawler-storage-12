"""
Various tools for data visualization
"""
from . import histograms
from . import plots2d
from .plots2d import matplot
from .histograms import plot_histograms
