"""
Different data containers available in REDA
"""
