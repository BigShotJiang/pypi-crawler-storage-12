This is a CRTomo mesh (elem.dat,elec.dat) and corresponding electrode
positions.

They are used to compare geometric factors computed with PyGimli and CRMod.
