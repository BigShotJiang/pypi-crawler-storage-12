# Copyright 2014 Davide Corio <davide.corio@abstract.it>

from . import link_e_invoice_ir_attachment
from . import account
from . import company
from . import partner
from . import ir_attachment
