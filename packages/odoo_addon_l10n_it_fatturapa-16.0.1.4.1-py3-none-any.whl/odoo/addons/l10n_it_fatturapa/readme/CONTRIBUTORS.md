- Davide Corio

- Lorenzo Battistini \<<https://github.com/eLBati>\>

- Roberto Onnis

- Alessio Gerace

- Sergio Zanchetta \<<https://github.com/primes2h>\>

- Gianluigi Tiesi \<<https://github.com/sherpya>\>

- Roberto Fichera \<<https://github.com/robyf70>\>

- Marco Colombo \<<https://github.com/TheMule71>\>

- [Ooops](https://www.ooops404.com):

  > - Giovanni Serra \<<giovanni@gslab.it>\>
- [Aion Tech](https://aiontech.company/):
  - Simone Rubino \<<simone.rubino@aion-tech.it>\>
- [Stesi Consulting](https://www.stesi.consulting):
  - Michele Di Croce \<<dicroce.m@stesi.consulting>\>
