**Italiano**

Il modulo NON È compatibile con il modulo standard l10n_it_edi.

**English**

The module is NOT compatible with the standard l10n_it_edi module.
