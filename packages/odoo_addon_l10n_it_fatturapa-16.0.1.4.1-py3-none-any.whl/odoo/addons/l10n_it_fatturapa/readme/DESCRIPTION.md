**Italiano**

Modulo base per gestire le fatture elettroniche.

<https://www.fatturapa.gov.it>

Consultare anche i file README di l10n_it_fatturapa_out e
l10n_it_fatturapa_in.

**English**

Base module to handle Electronic Invoices.

<https://www.fatturapa.gov.it>

See also l10n_it_fatturapa_out and l10n_it_fatturapa_in README files.
