**Italiano**

In caso di problemi dovuti all'incompatibilità con il modulo
autoinstallante l10n_it_edi, per installare questo modulo è necessario:

1.  Installare l10n_it
2.  Disinstallare l10n_it_edi
3.  Installare l10n_it_fatturapa

**English**

In case of issues due to the incompatibility with the auto-installing
module l10n_it_edi, in order to install this module you have to:

1.  Install l10n_it
2.  Uninstall l10n_it_edi
3.  Install l10n_it_fatturapa
