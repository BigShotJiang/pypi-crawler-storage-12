A CLA (Contributor License Agreement) is a document that specifies how a
project is allowed to use your code.

People willing to contribute to this project must agree to the terms of the CLA
before their code can be used.

Copy the following message in the email body, change {date} and {name} and
attach the CLA file (docs/legal/CLA.txt)

> {date}
>
> I hereby agree to the terms of the attached contributor license agreement.
>
> I furthermore declare that I am authorized and able to make this agreement
> and sign this declaration.
>
> Signed,
>
> {name}

Then send it to <contributions@oceandatalab.com>
You will receive a notification and more information once the email has been
read and approved.
