# Icons

Icons in this directory are provided by [Font Awesome](https://fontawesome.com/).