"""
COGNAC: COoperative Graph-based Networked Agent Challenges
for Multi-Agent Reinforcement Learning
"""

__all__ = [
    "core",
    "env",
    "utils",
]
