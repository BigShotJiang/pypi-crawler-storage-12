"""MkDocs Quiz Plugin - Create interactive quizzes in your MkDocs documentation."""

__version__ = "1.0.0"

from mkdocs_quiz.plugin import MkDocsQuizPlugin

__all__ = ["MkDocsQuizPlugin"]
