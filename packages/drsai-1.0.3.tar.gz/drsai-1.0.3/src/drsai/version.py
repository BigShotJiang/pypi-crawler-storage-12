
__version__ = "1.0.3"
__appname__ = 'drsai'
__author__ = 'hepai'
__email__ = 'xiongdb@ihep.ac.cn/hepai@ihep.ac.cn'
__description__ = "Developed by Dr. Sai's team at the Institute of High Energy Physics, Chinese Academy of Sciences (IHEP, CAS), this is a development framework designed for both single-agent and multi-agent collaborative systems"