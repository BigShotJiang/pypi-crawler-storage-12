from foo import obj_i

obj_baz = 4
