from .. import foo_d 

obj_sub_a_xxx = 88
