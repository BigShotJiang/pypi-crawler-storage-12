foo_i = 0
