import bar
from foo import foo_b
from foo.foo_c import obj_c
from .. import sample_d
from ..sample_e import jkl
from sample_f import *
import sample_g.other

def x():
    return 5
