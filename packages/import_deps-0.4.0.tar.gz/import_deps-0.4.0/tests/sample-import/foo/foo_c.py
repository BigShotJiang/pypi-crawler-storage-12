from . import foo_i

obj_c = 3
