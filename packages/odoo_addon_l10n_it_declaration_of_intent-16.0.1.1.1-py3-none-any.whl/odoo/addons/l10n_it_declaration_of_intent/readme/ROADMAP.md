Improve management of currency (see
<https://github.com/OCA/l10n-italy/issues/2428>).
