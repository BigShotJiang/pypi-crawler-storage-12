Per ogni cliente o fornitore soggetto a dichiarazione d'intento, creare
una dichiarazione d'intento inserendo tutti i dati e selezionando la
posizione fiscale dedicata.

Nota che il menu Fatturazione \> Contabilità \> Dichiarazioni d'intento
è visibile solo per gli utenti nel gruppo Mostrare funzionalità
contabili complete.

In fase di fatturazione, utilizzare la posizione fiscale apposita.
