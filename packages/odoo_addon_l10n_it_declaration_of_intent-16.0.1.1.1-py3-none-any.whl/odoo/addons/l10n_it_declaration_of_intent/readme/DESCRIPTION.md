**Italiano**

Questo modulo consente di gestire le dichiarazioni d'intento.

**English**

This module allows you to manage declarations of intent.
