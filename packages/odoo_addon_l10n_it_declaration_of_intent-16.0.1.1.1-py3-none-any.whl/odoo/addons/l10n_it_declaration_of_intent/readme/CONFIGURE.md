Creare:

1.  un'imposta di tipo vendite con importo 0.  
    Ad esempio "Non imponibile art.8c Lettera intento"

2.  una posizione fiscale per le dichiarazioni d'intento, avente:
    - il flag Valida per dichiarazione d'intento attivato,

    - una mappatura delle imposte opportuna.  
      Ad esempio tra "IVA al 22% (debito) (Vendita)" e "Non imponibile
      art.8c Lettera intento".

In Impostazioni \> Utenti e aziende, selezionare un'azienda e, nella
scheda Dichiarazioni d'intento, definire un plafond annuale.
