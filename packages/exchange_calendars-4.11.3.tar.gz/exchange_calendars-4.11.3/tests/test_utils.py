import pandas as pd


def T(x):  # noqa: N802
    return pd.Timestamp(x)
