# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.

from arista.syslog.v1 import syslog_pb2 as models
import arista.syslog.v1.services
