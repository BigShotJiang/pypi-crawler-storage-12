# Copyright (c) 2024 University of Maryland

import os
from jupyter_server._tz import utcnow
from tornado.ioloop import PeriodicCallback
import psutil
from functools import partial

__version__ = "0.1.5"


async def update_last_activity(settings, logger, percent_min=70):
    """Checks for CPU usage and update the last activity if there is activity

    Parameters
    ----------
    settings: dict
        ServerApp setting dict
    logger: logging object
    percent_min: int
        Minimum CPU activity to consider as running.
    """
    # consider individual cpu's separately
    isactive = sum(psutil.cpu_percent(percpu=True)) > percent_min
    text = f"jupyter_cpu_alive activity: {isactive}"
    sep = '\n    '
    if isactive:
        now = utcnow()
        settings['api_last_activity'] = now
        text += f'{sep}activity updated to: {now}'
    # log all settings that have 'activity' in the key
    for key in settings.keys():
        if 'activity' in key:
            text += f'{sep}{key}: {settings[key]}'
    logger.info(text)


def _jupyter_server_extension_points():
    return [{
        "module": "jupyter_cpu_alive"
    }]


def load_jupyter_server_extension(nb_app):
    # minimum cpu percentage
    default_percent_min = 70
    try:
        percent_min = os.environ.get('JUPYTER_CPU_ALIVE_PERCENT_MIN', 70)
        percent_min = float(percent_min)
    except ValueError:
        nb_app.log.info(('jupyter_cpu_alive: JUPYTER_CPU_ALIVE_PERCENT_MIN '
                         'cannot be converted to a float; using '
                         f'{default_percent_min}'))
        percent_min = default_percent_min

    # interval in seconds; default is 5 min
    default_interval = 5*60
    try:
        interval = os.environ.get(
            'JUPYTER_CPU_ALIVE_INTERVAL',
            default_interval
        )
        interval = float(interval)
    except ValueError:
        nb_app.log.info(('jupyter_cpu_alive: JUPYTER_CPU_ALIVE_INTERVAL '
                         'cannot be converted to a float; using '
                         f'{default_interval}'))
        interval = default_interval

    func = partial(
        update_last_activity,
        settings=nb_app.web_app.settings,
        logger=nb_app.log,
        percent_min=percent_min,
    )
    # note that this needs the interval in milliseconds
    pc = PeriodicCallback(func, interval*1e3)
    nb_app.log.info(('jupyter_cpu_alive starting with: percent_min: '
                     f'{percent_min}, interval: {interval}'))
    pc.start()
