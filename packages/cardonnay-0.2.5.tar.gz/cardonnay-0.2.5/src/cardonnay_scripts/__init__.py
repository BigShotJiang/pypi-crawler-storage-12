from importlib import resources

SCRIPTS_ROOT = resources.files(__package__) / "scripts"
