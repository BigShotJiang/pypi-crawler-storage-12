

class AdminAuth:
    """
    This class is used to authenticate the admin user.
    """