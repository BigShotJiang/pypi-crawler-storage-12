"""Setup configuration for PyKit package."""

from setuptools import setup

setup()
