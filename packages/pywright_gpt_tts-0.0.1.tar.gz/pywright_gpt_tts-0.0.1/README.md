# pywright-gpt-tts
Python Module for ChatGPT TTS
