from .core import GeneralIntelligence, Knowledge

__version__ = "0.1.0"
