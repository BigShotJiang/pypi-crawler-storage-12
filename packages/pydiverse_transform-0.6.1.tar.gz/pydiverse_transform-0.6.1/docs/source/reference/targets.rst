=========================
Backends / Export Targets
=========================

.. currentmodule:: pydiverse.transform
.. autosummary::
    :toctree: _generated/
    :nosignatures:
    :template: short_title.rst

    DuckDb
    Pandas
    Polars
    SqlAlchemy
