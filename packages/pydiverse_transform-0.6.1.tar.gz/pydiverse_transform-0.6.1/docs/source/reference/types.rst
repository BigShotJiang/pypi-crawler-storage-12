=====
Types
=====

.. currentmodule:: pydiverse.transform
.. autosummary::
    :toctree: _generated/
    :nosignatures:
    :template: short_title.rst

    Dtype
    Bool
    Date
    Datetime
    Decimal
    Float
    Float32
    Float64
    Int
    Int8
    Int16
    Int32
    Int64
    String
    UInt8
    UInt16
    UInt32
    UInt64
