===============
Sorting Markers
===============

.. currentmodule:: pydiverse.transform.ColExpr
.. autosummary::
    :toctree: _generated/
    :nosignatures:
    :template: short_title.rst

    ascending
    descending
    nulls_first
    nulls_last
