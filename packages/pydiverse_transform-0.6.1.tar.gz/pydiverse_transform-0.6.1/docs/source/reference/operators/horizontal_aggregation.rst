======================
Horizontal Aggregation
======================

.. currentmodule:: pydiverse.transform
.. autosummary::
    :toctree: _generated/
    :nosignatures:
    :template: short_title.rst

    coalesce
    count
    all
    any
    max
    min
    sum
