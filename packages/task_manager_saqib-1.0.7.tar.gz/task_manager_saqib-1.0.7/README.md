A simple Python-based Task Manager that allows adding, removing, updating, and viewing tasks.
## Usage
```python
import task_manager as tm

tm.Add()
tm.Remove()
tm.Update()