from invoke_toolkit import task


@task()
def task1(c): ...
