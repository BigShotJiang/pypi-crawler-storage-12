from ._web_surfer import WebSurfer, WebSurferConfig
from ._cua_web_surfer import WebSurferCUA

__all__ = [
    "WebSurfer",
    "WebSurferConfig",
    "WebSurferCUA",
]
