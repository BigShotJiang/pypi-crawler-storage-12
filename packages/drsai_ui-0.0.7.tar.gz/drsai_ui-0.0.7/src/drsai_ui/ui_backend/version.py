VERSION = "0.0.7"
__version__ = VERSION
APP_NAME = "Dr.Sai-UI"
