import sdevpy as sd
from sdevpy import example
from sdevpy import settings
from sdevpy.projects import datafiles


a = example.add_one(2)
print(a)

print(settings.WORKFOLDER)

print(sd.__version__)

