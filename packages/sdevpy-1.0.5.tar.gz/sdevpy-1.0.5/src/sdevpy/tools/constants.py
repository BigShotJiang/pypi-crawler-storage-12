""" Set contants """
import math

BPS10 = 10.0 / 10000.0

TWO_PI = 2.0 * math.pi
