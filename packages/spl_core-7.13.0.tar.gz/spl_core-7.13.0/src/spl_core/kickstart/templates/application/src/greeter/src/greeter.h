#ifndef GREETER_H
#define GREETER_H

extern const char* get_greeting();

#endif // GREETER_H
