# Software Detailed Design

```{toctree}
:maxdepth: 2
:caption: Table of Contents
:class: toc
```

## Introduction

This is the documentation for the ``Main`` component.

The application will say
{% if config.LANG_DE %}
``Hallo Welt``
{% else %}
``Hello World``
{% endif %}
.
