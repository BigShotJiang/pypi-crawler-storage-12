#pragma once

#ifdef _MSC_VER
#define ETL_ENDIAN_NATIVE 0
#endif
