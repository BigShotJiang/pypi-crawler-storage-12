"""Integration tests package.

These tests run against real aptly installation in Docker
to verify end-to-end functionality.
"""
