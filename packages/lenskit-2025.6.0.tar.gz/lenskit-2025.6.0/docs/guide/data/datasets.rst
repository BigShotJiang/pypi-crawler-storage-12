Standard Datasets
~~~~~~~~~~~~~~~~~

LensKit provides support for automatically importing a small but growing
collection of data sets.  In many cases, these data sets can be imported
directly from the compressed files downloaded from their original sources.

.. toctree::
    :maxdepth: 1

    movielens
    amazon
