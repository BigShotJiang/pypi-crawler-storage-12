temporal_sum
============

.. autofunction:: eo_processor.temporal_sum
   :noindex:
