"""Initialise login module."""
