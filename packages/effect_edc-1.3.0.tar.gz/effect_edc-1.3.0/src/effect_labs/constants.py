BLOOD_CULTURE = "blood_culture"
CHEMISTRY = "chemistry"
CSF_CULTURE = "csf_culture"
