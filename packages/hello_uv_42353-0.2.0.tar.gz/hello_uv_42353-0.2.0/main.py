def main():
    print("Hello from hello-uv!")


if __name__ == "__main__":
    main()
