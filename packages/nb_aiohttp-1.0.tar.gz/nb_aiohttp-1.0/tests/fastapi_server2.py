

from fastapi_server1 import start

if __name__ == '__main__':
    start(8007)