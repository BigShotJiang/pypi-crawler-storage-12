"""Should eventually contain routines to generate the symbolic expression for internal energy and pressure, given
the abundances available in a network.
"""
