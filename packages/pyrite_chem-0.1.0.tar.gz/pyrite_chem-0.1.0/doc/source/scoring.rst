
.. automodule:: pyrite.scoring
   :no-members:
   :no-inherited-members:
   :no-special-members:
