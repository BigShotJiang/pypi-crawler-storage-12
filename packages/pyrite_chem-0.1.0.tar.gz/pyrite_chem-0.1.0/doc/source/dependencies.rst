
.. automodule:: pyrite.scoring.dependencies
   :no-members:
   :no-inherited-members:
   :no-special-members:
