:orphan:

.. raw:: html

   <div class="prename">pyrite.AtomType.</div>
   <div class="empty"></div>

pyrite.AtomType.Iron
====================

.. currentmodule:: pyrite

.. autoattribute:: AtomType.Iron