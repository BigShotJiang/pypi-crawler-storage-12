:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Repulsion.</div>
   <div class="empty"></div>

get_step
=================================

.. currentmodule:: pyrite.scoring

.. automethod:: Repulsion.get_step