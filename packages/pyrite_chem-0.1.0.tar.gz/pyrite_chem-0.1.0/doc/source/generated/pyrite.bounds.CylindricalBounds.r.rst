:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.CylindricalBounds.</div>
   <div class="empty"></div>

pyrite.bounds.CylindricalBounds.r
=================================

.. currentmodule:: pyrite.bounds

.. autoattribute:: CylindricalBounds.r