:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Gaussian.</div>
   <div class="empty"></div>

step
============================

.. currentmodule:: pyrite.scoring

.. automethod:: Gaussian.step