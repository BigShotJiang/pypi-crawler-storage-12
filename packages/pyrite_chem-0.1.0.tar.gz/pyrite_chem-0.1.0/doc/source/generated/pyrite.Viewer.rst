﻿.. raw:: html

   <div class="prename">pyrite.</div>
   <div class="empty"></div>

Viewer
=============

.. currentmodule:: pyrite


.. autoclass:: Viewer
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         Viewer.add
         Viewer.add_v
         Viewer.show
      
  

  
  
  