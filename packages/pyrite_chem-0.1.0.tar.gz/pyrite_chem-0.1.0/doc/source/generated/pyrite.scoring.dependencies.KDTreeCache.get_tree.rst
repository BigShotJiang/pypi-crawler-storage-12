:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.dependencies.KDTreeCache.</div>
   <div class="empty"></div>

get_tree
================================================

.. currentmodule:: pyrite.scoring.dependencies

.. automethod:: KDTreeCache.get_tree