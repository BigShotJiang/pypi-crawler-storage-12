:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.SphericalBounds.</div>
   <div class="empty"></div>

squared_distance
==============================================

.. currentmodule:: pyrite.bounds

.. automethod:: SphericalBounds.squared_distance