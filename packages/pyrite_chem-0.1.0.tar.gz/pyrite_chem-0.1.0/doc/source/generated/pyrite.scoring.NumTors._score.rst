:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NumTors.</div>
   <div class="empty"></div>

_score
=============================

.. currentmodule:: pyrite.scoring

.. automethod:: NumTors._score