:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.WeightedBoundsOverlap.</div>
   <div class="empty"></div>

get_step
=============================================

.. currentmodule:: pyrite.scoring

.. automethod:: WeightedBoundsOverlap.get_step