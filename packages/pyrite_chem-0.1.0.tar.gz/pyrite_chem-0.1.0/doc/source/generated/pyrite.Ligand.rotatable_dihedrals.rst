:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

pyrite.Ligand.rotatable_dihedrals
=================================

.. currentmodule:: pyrite

.. autoproperty:: Ligand.rotatable_dihedrals