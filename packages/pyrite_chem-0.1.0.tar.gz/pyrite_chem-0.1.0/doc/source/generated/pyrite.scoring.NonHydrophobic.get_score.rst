:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NonHydrophobic.</div>
   <div class="empty"></div>

get_score
=======================================

.. currentmodule:: pyrite.scoring

.. automethod:: NonHydrophobic.get_score