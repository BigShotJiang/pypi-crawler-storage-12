:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NumProteinAtomsWithinA.</div>
   <div class="empty"></div>

get_dependencies
======================================================

.. currentmodule:: pyrite.scoring

.. automethod:: NumProteinAtomsWithinA.get_dependencies