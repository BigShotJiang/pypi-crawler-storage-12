:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.ConstantTerm.</div>
   <div class="empty"></div>

get_dependencies
============================================

.. currentmodule:: pyrite.scoring

.. automethod:: ConstantTerm.get_dependencies