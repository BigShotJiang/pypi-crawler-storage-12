:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

pyrite.Ligand.center_atom
=========================

.. currentmodule:: pyrite

.. autoproperty:: Ligand.center_atom