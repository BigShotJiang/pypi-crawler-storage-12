:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.CylindricalBounds.</div>
   <div class="empty"></div>

get_translation_bounds
======================================================

.. currentmodule:: pyrite.bounds

.. automethod:: CylindricalBounds.get_translation_bounds