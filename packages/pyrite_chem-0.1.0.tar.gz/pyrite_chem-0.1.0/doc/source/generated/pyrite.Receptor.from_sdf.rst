:orphan:

.. raw:: html

   <div class="prename">pyrite.Receptor.</div>
   <div class="empty"></div>

from_sdf
========================

.. currentmodule:: pyrite

.. automethod:: Receptor.from_sdf