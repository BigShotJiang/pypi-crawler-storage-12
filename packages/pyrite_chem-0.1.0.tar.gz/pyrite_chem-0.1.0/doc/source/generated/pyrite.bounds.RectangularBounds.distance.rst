:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.RectangularBounds.</div>
   <div class="empty"></div>

distance
========================================

.. currentmodule:: pyrite.bounds

.. automethod:: RectangularBounds.distance