:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.ConstantTerm.</div>
   <div class="empty"></div>

get_step
====================================

.. currentmodule:: pyrite.scoring

.. automethod:: ConstantTerm.get_step