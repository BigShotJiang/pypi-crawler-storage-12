:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Bounds.</div>
   <div class="empty"></div>

place_grid
===============================

.. currentmodule:: pyrite.bounds

.. automethod:: Bounds.place_grid