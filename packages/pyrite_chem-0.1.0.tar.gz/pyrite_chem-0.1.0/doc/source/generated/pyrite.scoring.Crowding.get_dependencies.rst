:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Crowding.</div>
   <div class="empty"></div>

get_dependencies
========================================

.. currentmodule:: pyrite.scoring

.. automethod:: Crowding.get_dependencies