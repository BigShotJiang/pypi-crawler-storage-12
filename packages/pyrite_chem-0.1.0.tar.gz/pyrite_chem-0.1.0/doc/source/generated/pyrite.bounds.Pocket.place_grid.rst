:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Pocket.</div>
   <div class="empty"></div>

place_grid
===============================

.. currentmodule:: pyrite.bounds

.. automethod:: Pocket.place_grid