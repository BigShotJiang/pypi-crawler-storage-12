:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.AD4Solvation.</div>
   <div class="empty"></div>

clamp
=================================

.. currentmodule:: pyrite.scoring

.. automethod:: AD4Solvation.clamp