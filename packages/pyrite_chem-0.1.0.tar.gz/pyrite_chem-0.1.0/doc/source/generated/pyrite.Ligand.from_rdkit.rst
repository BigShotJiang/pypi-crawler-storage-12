:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

from_rdkit
========================

.. currentmodule:: pyrite

.. automethod:: Ligand.from_rdkit