:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NonHydrophobic.</div>
   <div class="empty"></div>

clamp
===================================

.. currentmodule:: pyrite.scoring

.. automethod:: NonHydrophobic.clamp