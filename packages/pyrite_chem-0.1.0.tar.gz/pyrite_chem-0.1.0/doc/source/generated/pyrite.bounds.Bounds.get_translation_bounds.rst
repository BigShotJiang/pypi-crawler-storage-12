:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Bounds.</div>
   <div class="empty"></div>

get_translation_bounds
===========================================

.. currentmodule:: pyrite.bounds

.. automethod:: Bounds.get_translation_bounds