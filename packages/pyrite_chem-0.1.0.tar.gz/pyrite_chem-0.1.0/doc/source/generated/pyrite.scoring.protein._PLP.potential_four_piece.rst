:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.protein._PLP.</div>
   <div class="empty"></div>

potential_four_piece
================================================

.. currentmodule:: pyrite.scoring.protein

.. automethod:: _PLP.potential_four_piece