:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.SphericalBounds.</div>
   <div class="empty"></div>

place_grid
========================================

.. currentmodule:: pyrite.bounds

.. automethod:: SphericalBounds.place_grid