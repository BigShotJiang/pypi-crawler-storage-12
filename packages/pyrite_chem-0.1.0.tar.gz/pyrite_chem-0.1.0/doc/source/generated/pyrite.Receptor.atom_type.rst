:orphan:

.. raw:: html

   <div class="prename">pyrite.Receptor.</div>
   <div class="empty"></div>

atom_type
=========================

.. currentmodule:: pyrite

.. automethod:: Receptor.atom_type