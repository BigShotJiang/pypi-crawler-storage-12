:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

place_in
======================

.. currentmodule:: pyrite

.. automethod:: Ligand.place_in