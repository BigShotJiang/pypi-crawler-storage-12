:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.ElectroStatic.</div>
   <div class="empty"></div>

_score
===================================

.. currentmodule:: pyrite.scoring

.. automethod:: ElectroStatic._score