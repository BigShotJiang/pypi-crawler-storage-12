:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.LJ.</div>
   <div class="empty"></div>

_score
========================

.. currentmodule:: pyrite.scoring

.. automethod:: LJ._score