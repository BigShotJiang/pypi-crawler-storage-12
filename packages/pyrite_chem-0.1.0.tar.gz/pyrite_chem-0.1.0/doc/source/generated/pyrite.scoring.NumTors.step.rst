:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NumTors.</div>
   <div class="empty"></div>

step
===========================

.. currentmodule:: pyrite.scoring

.. automethod:: NumTors.step