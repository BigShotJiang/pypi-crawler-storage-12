:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

v_to_sdf
======================

.. currentmodule:: pyrite

.. automethod:: Ligand.v_to_sdf