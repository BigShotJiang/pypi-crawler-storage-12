:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Gaussian.</div>
   <div class="empty"></div>

get_dependencies
========================================

.. currentmodule:: pyrite.scoring

.. automethod:: Gaussian.get_dependencies