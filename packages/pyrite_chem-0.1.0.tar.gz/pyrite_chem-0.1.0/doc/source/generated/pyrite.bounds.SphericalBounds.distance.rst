:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.SphericalBounds.</div>
   <div class="empty"></div>

distance
======================================

.. currentmodule:: pyrite.bounds

.. automethod:: SphericalBounds.distance