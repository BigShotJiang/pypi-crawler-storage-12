:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NonDirHBondLJ.</div>
   <div class="empty"></div>

clamp
==================================

.. currentmodule:: pyrite.scoring

.. automethod:: NonDirHBondLJ.clamp