:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Bounds.</div>
   <div class="empty"></div>

transform_sample_to_2pi
============================================

.. currentmodule:: pyrite.bounds

.. automethod:: Bounds.transform_sample_to_2pi