:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NumProteinAtomsWithinA.</div>
   <div class="empty"></div>

get_score
===============================================

.. currentmodule:: pyrite.scoring

.. automethod:: NumProteinAtomsWithinA.get_score