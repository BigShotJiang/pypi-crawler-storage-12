:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

pyrite.Ligand.position
======================

.. currentmodule:: pyrite

.. autoproperty:: Ligand.position