:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Crowding.</div>
   <div class="empty"></div>

register_pose
=====================================

.. currentmodule:: pyrite.scoring

.. automethod:: Crowding.register_pose