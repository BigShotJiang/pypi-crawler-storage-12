:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Pocket.</div>
   <div class="empty"></div>

from_receptor
==================================

.. currentmodule:: pyrite.bounds

.. automethod:: Pocket.from_receptor