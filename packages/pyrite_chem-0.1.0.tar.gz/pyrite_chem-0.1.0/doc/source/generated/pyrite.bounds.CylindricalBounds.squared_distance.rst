:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.CylindricalBounds.</div>
   <div class="empty"></div>

squared_distance
================================================

.. currentmodule:: pyrite.bounds

.. automethod:: CylindricalBounds.squared_distance