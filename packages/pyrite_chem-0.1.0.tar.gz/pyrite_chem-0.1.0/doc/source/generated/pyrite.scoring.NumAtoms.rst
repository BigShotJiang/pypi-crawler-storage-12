﻿.. raw:: html

   <div class="prename">pyrite.scoring.</div>
   <div class="empty"></div>

NumAtoms
=======================

.. currentmodule:: pyrite.scoring


.. autoclass:: NumAtoms
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         NumAtoms._score
         NumAtoms.clamp
         NumAtoms.get_dependencies
         NumAtoms.get_score
         NumAtoms.get_step
         NumAtoms.step
      
  

  
  
  