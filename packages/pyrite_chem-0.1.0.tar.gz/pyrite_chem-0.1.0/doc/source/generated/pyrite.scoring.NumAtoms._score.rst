:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NumAtoms.</div>
   <div class="empty"></div>

_score
==============================

.. currentmodule:: pyrite.scoring

.. automethod:: NumAtoms._score