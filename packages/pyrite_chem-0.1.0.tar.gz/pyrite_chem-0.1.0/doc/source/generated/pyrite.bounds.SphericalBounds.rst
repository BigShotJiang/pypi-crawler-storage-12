﻿.. raw:: html

   <div class="prename">pyrite.bounds.</div>
   <div class="empty"></div>

SphericalBounds
=============================

.. currentmodule:: pyrite.bounds


.. autoclass:: SphericalBounds
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         SphericalBounds.distance
         SphericalBounds.get_bounds
         SphericalBounds.get_translation_bounds
         SphericalBounds.is_within
         SphericalBounds.place_grid
         SphericalBounds.place_random_uniform
         SphericalBounds.squared_distance
         SphericalBounds.transform_sample_to_2pi
         SphericalBounds.transform_sample_to_bounds
      
  

  
  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         SphericalBounds.r
  
  