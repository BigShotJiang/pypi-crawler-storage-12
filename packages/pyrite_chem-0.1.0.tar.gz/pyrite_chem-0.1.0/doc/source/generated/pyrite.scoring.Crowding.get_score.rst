:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Crowding.</div>
   <div class="empty"></div>

get_score
=================================

.. currentmodule:: pyrite.scoring

.. automethod:: Crowding.get_score