:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.protein._ChargeScoringFunction.</div>
   <div class="empty"></div>

clamp
===================================================

.. currentmodule:: pyrite.scoring.protein

.. automethod:: _ChargeScoringFunction.clamp