:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.OutOfBoundsPenalty.</div>
   <div class="empty"></div>

clamp
=======================================

.. currentmodule:: pyrite.scoring

.. automethod:: OutOfBoundsPenalty.clamp