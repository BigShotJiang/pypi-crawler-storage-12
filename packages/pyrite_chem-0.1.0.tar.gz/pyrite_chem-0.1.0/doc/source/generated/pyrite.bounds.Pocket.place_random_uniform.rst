:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Pocket.</div>
   <div class="empty"></div>

place_random_uniform
=========================================

.. currentmodule:: pyrite.bounds

.. automethod:: Pocket.place_random_uniform