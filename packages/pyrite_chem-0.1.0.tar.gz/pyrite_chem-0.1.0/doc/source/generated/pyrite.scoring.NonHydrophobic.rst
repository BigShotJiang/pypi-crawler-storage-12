﻿.. raw:: html

   <div class="prename">pyrite.scoring.</div>
   <div class="empty"></div>

NonHydrophobic
=============================

.. currentmodule:: pyrite.scoring


.. autoclass:: NonHydrophobic
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         NonHydrophobic._score
         NonHydrophobic.clamp
         NonHydrophobic.get_dependencies
         NonHydrophobic.get_score
         NonHydrophobic.get_step
         NonHydrophobic.step
      
         NonHydrophobic._score
  

  
  
  