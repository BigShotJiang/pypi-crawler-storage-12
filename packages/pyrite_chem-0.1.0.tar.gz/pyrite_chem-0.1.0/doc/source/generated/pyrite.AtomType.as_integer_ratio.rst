:orphan:

.. raw:: html

   <div class="prename">pyrite.AtomType.</div>
   <div class="empty"></div>

as_integer_ratio
================================

.. currentmodule:: pyrite

.. automethod:: AtomType.as_integer_ratio