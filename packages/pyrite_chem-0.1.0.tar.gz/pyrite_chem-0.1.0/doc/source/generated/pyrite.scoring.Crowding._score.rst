:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Crowding.</div>
   <div class="empty"></div>

_score
==============================

.. currentmodule:: pyrite.scoring

.. automethod:: Crowding._score