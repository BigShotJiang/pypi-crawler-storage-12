:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

update
====================

.. currentmodule:: pyrite

.. automethod:: Ligand.update