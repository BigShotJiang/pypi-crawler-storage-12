:orphan:

.. raw:: html

   <div class="prename">pyrite.Receptor.</div>
   <div class="empty"></div>

get_positions
=============================

.. currentmodule:: pyrite

.. automethod:: Receptor.get_positions