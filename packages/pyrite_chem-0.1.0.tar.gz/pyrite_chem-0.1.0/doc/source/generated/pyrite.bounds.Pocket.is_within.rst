:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Pocket.</div>
   <div class="empty"></div>

is_within
==============================

.. currentmodule:: pyrite.bounds

.. automethod:: Pocket.is_within