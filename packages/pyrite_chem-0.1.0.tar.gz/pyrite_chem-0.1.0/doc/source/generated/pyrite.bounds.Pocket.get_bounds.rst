:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Pocket.</div>
   <div class="empty"></div>

get_bounds
===============================

.. currentmodule:: pyrite.bounds

.. automethod:: Pocket.get_bounds