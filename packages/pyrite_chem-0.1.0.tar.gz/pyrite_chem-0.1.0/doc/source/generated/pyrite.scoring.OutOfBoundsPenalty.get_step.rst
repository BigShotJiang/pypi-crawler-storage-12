:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.OutOfBoundsPenalty.</div>
   <div class="empty"></div>

get_step
==========================================

.. currentmodule:: pyrite.scoring

.. automethod:: OutOfBoundsPenalty.get_step