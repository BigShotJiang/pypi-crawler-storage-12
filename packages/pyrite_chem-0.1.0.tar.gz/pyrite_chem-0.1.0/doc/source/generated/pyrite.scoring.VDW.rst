﻿.. raw:: html

   <div class="prename">pyrite.scoring.</div>
   <div class="empty"></div>

VDW
==================

.. currentmodule:: pyrite.scoring


.. autoclass:: VDW
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         VDW._score
         VDW.clamp
         VDW.get_dependencies
         VDW.get_score
         VDW.get_step
         VDW.step
      
         VDW._score
  

  
  
  