:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.ConstantTerm.</div>
   <div class="empty"></div>

step
================================

.. currentmodule:: pyrite.scoring

.. automethod:: ConstantTerm.step