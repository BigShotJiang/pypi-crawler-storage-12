:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Pocket.</div>
   <div class="empty"></div>

intersect
==============================

.. currentmodule:: pyrite.bounds

.. automethod:: Pocket.intersect