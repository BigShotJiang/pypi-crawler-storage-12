:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

GetConformer
==========================

.. currentmodule:: pyrite

.. automethod:: Ligand.GetConformer