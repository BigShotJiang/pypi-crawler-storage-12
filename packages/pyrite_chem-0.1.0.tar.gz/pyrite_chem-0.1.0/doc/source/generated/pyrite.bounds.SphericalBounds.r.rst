:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.SphericalBounds.</div>
   <div class="empty"></div>

pyrite.bounds.SphericalBounds.r
===============================

.. currentmodule:: pyrite.bounds

.. autoattribute:: SphericalBounds.r