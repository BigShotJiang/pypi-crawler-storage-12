:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.ScoringFunction.</div>
   <div class="empty"></div>

clamp
====================================

.. currentmodule:: pyrite.scoring

.. automethod:: ScoringFunction.clamp