:orphan:

.. raw:: html

   <div class="prename">pyrite.Receptor.</div>
   <div class="empty"></div>

set_draw_options
================================

.. currentmodule:: pyrite

.. automethod:: Receptor.set_draw_options