:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.RectangularBounds.</div>
   <div class="empty"></div>

get_translation_bounds
======================================================

.. currentmodule:: pyrite.bounds

.. automethod:: RectangularBounds.get_translation_bounds