:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.ScoringFunction.</div>
   <div class="empty"></div>

get_score
========================================

.. currentmodule:: pyrite.scoring

.. automethod:: ScoringFunction.get_score