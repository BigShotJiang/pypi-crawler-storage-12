﻿.. raw:: html

   <div class="prename">pyrite.scoring.</div>
   <div class="empty"></div>

Gaussian
=======================

.. currentmodule:: pyrite.scoring


.. autoclass:: Gaussian
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         Gaussian._score
         Gaussian.clamp
         Gaussian.get_dependencies
         Gaussian.get_score
         Gaussian.get_step
         Gaussian.step
      
  

  
  
  