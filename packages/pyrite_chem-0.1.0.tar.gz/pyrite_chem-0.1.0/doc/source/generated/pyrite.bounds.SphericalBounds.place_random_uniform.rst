:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.SphericalBounds.</div>
   <div class="empty"></div>

place_random_uniform
==================================================

.. currentmodule:: pyrite.bounds

.. automethod:: SphericalBounds.place_random_uniform