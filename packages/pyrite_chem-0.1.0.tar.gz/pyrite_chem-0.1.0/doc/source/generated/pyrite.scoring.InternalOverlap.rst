﻿.. raw:: html

   <div class="prename">pyrite.scoring.</div>
   <div class="empty"></div>

InternalOverlap
==============================

.. currentmodule:: pyrite.scoring


.. autoclass:: InternalOverlap
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         InternalOverlap._score
         InternalOverlap.clamp
         InternalOverlap.get_dependencies
         InternalOverlap.get_score
         InternalOverlap.get_step
         InternalOverlap.step
      
  

  
  
  