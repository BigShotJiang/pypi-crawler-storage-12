:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Crowding.</div>
   <div class="empty"></div>

get_step
================================

.. currentmodule:: pyrite.scoring

.. automethod:: Crowding.get_step