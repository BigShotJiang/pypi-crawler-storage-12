:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.LJ.</div>
   <div class="empty"></div>

clamp
=======================

.. currentmodule:: pyrite.scoring

.. automethod:: LJ.clamp