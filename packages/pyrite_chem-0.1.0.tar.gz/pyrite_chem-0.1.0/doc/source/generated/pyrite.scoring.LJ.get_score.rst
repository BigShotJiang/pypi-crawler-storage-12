:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.LJ.</div>
   <div class="empty"></div>

get_score
===========================

.. currentmodule:: pyrite.scoring

.. automethod:: LJ.get_score