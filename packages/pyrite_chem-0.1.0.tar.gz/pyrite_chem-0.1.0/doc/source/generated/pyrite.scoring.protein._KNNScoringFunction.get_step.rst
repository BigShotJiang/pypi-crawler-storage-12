:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.protein._KNNScoringFunction.</div>
   <div class="empty"></div>

get_step
===================================================

.. currentmodule:: pyrite.scoring.protein

.. automethod:: _KNNScoringFunction.get_step