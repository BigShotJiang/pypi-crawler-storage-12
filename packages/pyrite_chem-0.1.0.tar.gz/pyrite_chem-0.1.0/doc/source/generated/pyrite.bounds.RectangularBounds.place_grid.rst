:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.RectangularBounds.</div>
   <div class="empty"></div>

place_grid
==========================================

.. currentmodule:: pyrite.bounds

.. automethod:: RectangularBounds.place_grid