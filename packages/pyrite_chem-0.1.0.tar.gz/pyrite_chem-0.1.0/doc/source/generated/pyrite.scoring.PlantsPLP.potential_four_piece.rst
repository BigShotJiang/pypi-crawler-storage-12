:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.PlantsPLP.</div>
   <div class="empty"></div>

potential_four_piece
=============================================

.. currentmodule:: pyrite.scoring

.. automethod:: PlantsPLP.potential_four_piece