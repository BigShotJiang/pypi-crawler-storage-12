:orphan:

.. raw:: html

   <div class="prename">pyrite.AtomType.</div>
   <div class="empty"></div>

pyrite.AtomType.Zinc
====================

.. currentmodule:: pyrite

.. autoattribute:: AtomType.Zinc