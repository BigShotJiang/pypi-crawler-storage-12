﻿.. raw:: html

   <div class="prename">pyrite.bounds.</div>
   <div class="empty"></div>

CylindricalBounds
===============================

.. currentmodule:: pyrite.bounds


.. autoclass:: CylindricalBounds
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         CylindricalBounds.distance
         CylindricalBounds.get_bounds
         CylindricalBounds.get_translation_bounds
         CylindricalBounds.is_within
         CylindricalBounds.place_grid
         CylindricalBounds.place_random_uniform
         CylindricalBounds.squared_distance
         CylindricalBounds.transform_sample_to_2pi
         CylindricalBounds.transform_sample_to_bounds
      
  

  
  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         CylindricalBounds.r
  
  