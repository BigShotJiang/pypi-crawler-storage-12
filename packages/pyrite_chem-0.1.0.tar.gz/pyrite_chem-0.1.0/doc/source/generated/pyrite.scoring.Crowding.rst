﻿.. raw:: html

   <div class="prename">pyrite.scoring.</div>
   <div class="empty"></div>

Crowding
=======================

.. currentmodule:: pyrite.scoring


.. autoclass:: Crowding
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         Crowding._score
         Crowding.clamp
         Crowding.get_dependencies
         Crowding.get_score
         Crowding.get_step
         Crowding.register_pose
         Crowding.step
      
  

  
  
  