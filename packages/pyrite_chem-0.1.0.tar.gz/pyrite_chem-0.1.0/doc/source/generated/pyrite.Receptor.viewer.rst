:orphan:

.. raw:: html

   <div class="prename">pyrite.Receptor.</div>
   <div class="empty"></div>

pyrite.Receptor.viewer
======================

.. currentmodule:: pyrite

.. autoproperty:: Receptor.viewer