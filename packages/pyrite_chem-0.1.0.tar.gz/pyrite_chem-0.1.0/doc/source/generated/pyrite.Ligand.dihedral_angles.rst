:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

pyrite.Ligand.dihedral_angles
=============================

.. currentmodule:: pyrite

.. autoproperty:: Ligand.dihedral_angles