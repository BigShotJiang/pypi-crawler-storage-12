:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NonDirHBond.</div>
   <div class="empty"></div>

get_dependencies
===========================================

.. currentmodule:: pyrite.scoring

.. automethod:: NonDirHBond.get_dependencies