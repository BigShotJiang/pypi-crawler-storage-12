:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Clamp.</div>
   <div class="empty"></div>

get_dependencies
=====================================

.. currentmodule:: pyrite.scoring

.. automethod:: Clamp.get_dependencies