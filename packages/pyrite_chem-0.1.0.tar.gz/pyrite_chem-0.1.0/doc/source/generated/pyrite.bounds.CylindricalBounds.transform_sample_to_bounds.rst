:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.CylindricalBounds.</div>
   <div class="empty"></div>

transform_sample_to_bounds
==========================================================

.. currentmodule:: pyrite.bounds

.. automethod:: CylindricalBounds.transform_sample_to_bounds