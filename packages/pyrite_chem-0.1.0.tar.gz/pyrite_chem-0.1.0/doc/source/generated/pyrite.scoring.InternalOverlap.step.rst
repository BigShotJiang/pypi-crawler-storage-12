:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.InternalOverlap.</div>
   <div class="empty"></div>

step
===================================

.. currentmodule:: pyrite.scoring

.. automethod:: InternalOverlap.step