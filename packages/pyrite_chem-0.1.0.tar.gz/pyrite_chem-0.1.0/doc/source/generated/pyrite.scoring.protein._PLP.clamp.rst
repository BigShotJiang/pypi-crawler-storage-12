:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.protein._PLP.</div>
   <div class="empty"></div>

clamp
=================================

.. currentmodule:: pyrite.scoring.protein

.. automethod:: _PLP.clamp