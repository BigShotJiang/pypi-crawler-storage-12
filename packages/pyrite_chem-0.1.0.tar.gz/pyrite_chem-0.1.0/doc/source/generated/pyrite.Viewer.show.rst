:orphan:

.. raw:: html

   <div class="prename">pyrite.Viewer.</div>
   <div class="empty"></div>

show
==================

.. currentmodule:: pyrite

.. automethod:: Viewer.show