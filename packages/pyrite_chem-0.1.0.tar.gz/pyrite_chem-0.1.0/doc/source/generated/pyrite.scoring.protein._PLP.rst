﻿.. raw:: html

   <div class="prename">pyrite.scoring.protein.</div>
   <div class="empty"></div>

_PLP
===========================

.. currentmodule:: pyrite.scoring.protein


.. autoclass:: _PLP
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         _PLP._score
         _PLP.clamp
         _PLP.get_dependencies
         _PLP.get_score
         _PLP.get_step
         _PLP.potential_four_piece
         _PLP.potential_two_piece
         _PLP.step
      
         _PLP._score
  

  
  
  