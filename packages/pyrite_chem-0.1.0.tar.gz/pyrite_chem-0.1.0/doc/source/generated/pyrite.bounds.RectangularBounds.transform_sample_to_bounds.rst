:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.RectangularBounds.</div>
   <div class="empty"></div>

transform_sample_to_bounds
==========================================================

.. currentmodule:: pyrite.bounds

.. automethod:: RectangularBounds.transform_sample_to_bounds