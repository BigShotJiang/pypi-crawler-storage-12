:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

pyrite.Ligand.svg
=================

.. currentmodule:: pyrite

.. autoproperty:: Ligand.svg