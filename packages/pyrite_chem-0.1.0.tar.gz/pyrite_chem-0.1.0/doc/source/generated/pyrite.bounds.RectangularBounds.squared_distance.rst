:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.RectangularBounds.</div>
   <div class="empty"></div>

squared_distance
================================================

.. currentmodule:: pyrite.bounds

.. automethod:: RectangularBounds.squared_distance