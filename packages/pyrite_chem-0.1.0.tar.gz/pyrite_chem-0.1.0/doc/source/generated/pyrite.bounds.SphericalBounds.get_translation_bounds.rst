:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.SphericalBounds.</div>
   <div class="empty"></div>

get_translation_bounds
====================================================

.. currentmodule:: pyrite.bounds

.. automethod:: SphericalBounds.get_translation_bounds