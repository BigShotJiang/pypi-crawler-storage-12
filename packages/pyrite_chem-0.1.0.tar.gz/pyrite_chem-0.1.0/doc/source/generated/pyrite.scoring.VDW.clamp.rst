:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.VDW.</div>
   <div class="empty"></div>

clamp
========================

.. currentmodule:: pyrite.scoring

.. automethod:: VDW.clamp