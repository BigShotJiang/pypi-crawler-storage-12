:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

to_sdf
====================

.. currentmodule:: pyrite

.. automethod:: Ligand.to_sdf