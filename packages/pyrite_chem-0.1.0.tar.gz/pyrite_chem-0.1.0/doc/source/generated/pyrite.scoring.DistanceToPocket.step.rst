:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.DistanceToPocket.</div>
   <div class="empty"></div>

step
====================================

.. currentmodule:: pyrite.scoring

.. automethod:: DistanceToPocket.step