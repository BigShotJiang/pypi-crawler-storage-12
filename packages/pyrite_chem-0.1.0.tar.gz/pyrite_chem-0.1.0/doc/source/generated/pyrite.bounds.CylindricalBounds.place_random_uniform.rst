:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.CylindricalBounds.</div>
   <div class="empty"></div>

place_random_uniform
====================================================

.. currentmodule:: pyrite.bounds

.. automethod:: CylindricalBounds.place_random_uniform