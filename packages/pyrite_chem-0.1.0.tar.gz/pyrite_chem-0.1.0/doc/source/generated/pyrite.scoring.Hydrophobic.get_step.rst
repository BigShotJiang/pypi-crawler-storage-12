:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Hydrophobic.</div>
   <div class="empty"></div>

get_step
===================================

.. currentmodule:: pyrite.scoring

.. automethod:: Hydrophobic.get_step