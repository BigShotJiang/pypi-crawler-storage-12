:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.Hydrophobic.</div>
   <div class="empty"></div>

step
===============================

.. currentmodule:: pyrite.scoring

.. automethod:: Hydrophobic.step