:orphan:

.. raw:: html

   <div class="prename">pyrite.AtomType.</div>
   <div class="empty"></div>

conjugate
=========================

.. currentmodule:: pyrite

.. automethod:: AtomType.conjugate