:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NumAtoms.</div>
   <div class="empty"></div>

step
============================

.. currentmodule:: pyrite.scoring

.. automethod:: NumAtoms.step