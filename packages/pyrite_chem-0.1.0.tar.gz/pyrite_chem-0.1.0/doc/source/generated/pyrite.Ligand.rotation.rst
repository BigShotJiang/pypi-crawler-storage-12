:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

pyrite.Ligand.rotation
======================

.. currentmodule:: pyrite

.. autoproperty:: Ligand.rotation