:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.protein._SlopeStep.</div>
   <div class="empty"></div>

_score
========================================

.. currentmodule:: pyrite.scoring.protein

.. automethod:: _SlopeStep._score