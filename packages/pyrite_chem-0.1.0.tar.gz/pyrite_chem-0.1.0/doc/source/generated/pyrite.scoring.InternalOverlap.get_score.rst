:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.InternalOverlap.</div>
   <div class="empty"></div>

get_score
========================================

.. currentmodule:: pyrite.scoring

.. automethod:: InternalOverlap.get_score