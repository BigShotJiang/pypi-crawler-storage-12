﻿.. raw:: html

   <div class="prename">pyrite.scoring.</div>
   <div class="empty"></div>

WeightedBoundsOverlap
====================================

.. currentmodule:: pyrite.scoring


.. autoclass:: WeightedBoundsOverlap
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         WeightedBoundsOverlap._score
         WeightedBoundsOverlap.clamp
         WeightedBoundsOverlap.get_dependencies
         WeightedBoundsOverlap.get_score
         WeightedBoundsOverlap.get_step
         WeightedBoundsOverlap.step
      
  

  
  
  