:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.ScoringFunction.</div>
   <div class="empty"></div>

get_step
=======================================

.. currentmodule:: pyrite.scoring

.. automethod:: ScoringFunction.get_step