:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.VDW.</div>
   <div class="empty"></div>

get_score
============================

.. currentmodule:: pyrite.scoring

.. automethod:: VDW.get_score