﻿.. raw:: html

   <div class="prename">pyrite.bounds.</div>
   <div class="empty"></div>

Pocket
====================

.. currentmodule:: pyrite.bounds


.. autoclass:: Pocket
   :private-members: _score
   :no-members:
   :no-inherited-members:
   :no-special-members:


  
   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         Pocket.distance
         Pocket.from_pqr
         Pocket.from_receptor
         Pocket.get_bounds
         Pocket.get_translation_bounds
         Pocket.intersect
         Pocket.is_within
         Pocket.place_grid
         Pocket.place_random_uniform
         Pocket.squared_distance
         Pocket.to_pqr
         Pocket.transform_sample_to_2pi
         Pocket.transform_sample_to_bounds
      
  

  
  
  