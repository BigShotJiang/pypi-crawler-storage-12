:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

from_pdb
======================

.. currentmodule:: pyrite

.. automethod:: Ligand.from_pdb