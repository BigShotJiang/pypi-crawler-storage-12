:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.RectangularBounds.</div>
   <div class="empty"></div>

get_bounds
==========================================

.. currentmodule:: pyrite.bounds

.. automethod:: RectangularBounds.get_bounds