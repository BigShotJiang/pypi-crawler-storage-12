:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Pocket.</div>
   <div class="empty"></div>

squared_distance
=====================================

.. currentmodule:: pyrite.bounds

.. automethod:: Pocket.squared_distance