:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NumProteinAtomsWithinA.</div>
   <div class="empty"></div>

clamp
===========================================

.. currentmodule:: pyrite.scoring

.. automethod:: NumProteinAtomsWithinA.clamp