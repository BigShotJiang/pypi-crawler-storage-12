:orphan:

.. raw:: html

   <div class="prename">pyrite.Receptor.</div>
   <div class="empty"></div>

pyrite.Receptor.atom_types
==========================

.. currentmodule:: pyrite

.. autoproperty:: Receptor.atom_types