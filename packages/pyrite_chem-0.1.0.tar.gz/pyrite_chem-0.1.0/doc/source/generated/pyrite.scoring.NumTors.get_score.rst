:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.NumTors.</div>
   <div class="empty"></div>

get_score
================================

.. currentmodule:: pyrite.scoring

.. automethod:: NumTors.get_score