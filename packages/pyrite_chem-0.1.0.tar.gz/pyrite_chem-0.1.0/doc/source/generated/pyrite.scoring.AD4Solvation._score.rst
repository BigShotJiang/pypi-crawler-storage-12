:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.AD4Solvation.</div>
   <div class="empty"></div>

_score
==================================

.. currentmodule:: pyrite.scoring

.. automethod:: AD4Solvation._score