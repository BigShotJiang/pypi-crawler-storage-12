:orphan:

.. raw:: html

   <div class="prename">pyrite.Ligand.</div>
   <div class="empty"></div>

from_smiles
=========================

.. currentmodule:: pyrite

.. automethod:: Ligand.from_smiles