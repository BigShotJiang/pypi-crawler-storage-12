:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Pocket.</div>
   <div class="empty"></div>

from_pqr
=============================

.. currentmodule:: pyrite.bounds

.. automethod:: Pocket.from_pqr