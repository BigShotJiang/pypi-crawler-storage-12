:orphan:

.. raw:: html

   <div class="prename">pyrite.AtomType.</div>
   <div class="empty"></div>

from_bytes
==========================

.. currentmodule:: pyrite

.. automethod:: AtomType.from_bytes