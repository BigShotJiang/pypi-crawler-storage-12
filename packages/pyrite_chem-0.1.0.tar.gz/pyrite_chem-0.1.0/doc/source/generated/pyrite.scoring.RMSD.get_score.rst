:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.RMSD.</div>
   <div class="empty"></div>

get_score
=============================

.. currentmodule:: pyrite.scoring

.. automethod:: RMSD.get_score