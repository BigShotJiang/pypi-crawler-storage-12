:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.InternalOverlap.</div>
   <div class="empty"></div>

get_dependencies
===============================================

.. currentmodule:: pyrite.scoring

.. automethod:: InternalOverlap.get_dependencies