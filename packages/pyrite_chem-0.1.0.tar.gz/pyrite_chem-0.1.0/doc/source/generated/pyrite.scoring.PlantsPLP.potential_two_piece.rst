:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.PlantsPLP.</div>
   <div class="empty"></div>

potential_two_piece
============================================

.. currentmodule:: pyrite.scoring

.. automethod:: PlantsPLP.potential_two_piece