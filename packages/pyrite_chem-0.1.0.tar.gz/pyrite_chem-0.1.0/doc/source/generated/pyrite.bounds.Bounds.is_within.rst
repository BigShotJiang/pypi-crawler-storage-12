:orphan:

.. raw:: html

   <div class="prename">pyrite.bounds.Bounds.</div>
   <div class="empty"></div>

is_within
==============================

.. currentmodule:: pyrite.bounds

.. automethod:: Bounds.is_within