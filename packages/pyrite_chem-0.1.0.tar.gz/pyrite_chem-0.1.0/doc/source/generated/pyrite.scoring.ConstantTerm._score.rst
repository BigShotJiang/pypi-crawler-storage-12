:orphan:

.. raw:: html

   <div class="prename">pyrite.scoring.ConstantTerm.</div>
   <div class="empty"></div>

_score
==================================

.. currentmodule:: pyrite.scoring

.. automethod:: ConstantTerm._score