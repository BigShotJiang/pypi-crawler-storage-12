from __future__ import annotations

websocket_urlpatterns: list = []


__all__ = ["websocket_urlpatterns"]
