from .collectors_api_v1_status_retrieve import *
from .collectors_healthy_retrieve import *
from .collectors_retrieve import *

ENDPOINT_NAMES = [
    "collectors_retrieve",
    "collectors_api_v1_status_retrieve",
    "collectors_healthy_retrieve",
]
