"""Building blocks for the LangCode CLI."""

