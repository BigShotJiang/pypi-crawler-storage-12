"""Re-export the shared base system instructions."""

from __future__ import annotations

from ..static_values import BASE_SYSTEM
