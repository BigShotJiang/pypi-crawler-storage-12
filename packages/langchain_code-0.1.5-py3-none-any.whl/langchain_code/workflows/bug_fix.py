"""Bug-fixing workflow instruction seed."""

from __future__ import annotations

from ..static_values import BUGFIX_INSTR
