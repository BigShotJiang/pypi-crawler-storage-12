"""Re-export the autopilot instruction seed."""

from __future__ import annotations

from ..static_values import AUTO_DEEP_INSTR
