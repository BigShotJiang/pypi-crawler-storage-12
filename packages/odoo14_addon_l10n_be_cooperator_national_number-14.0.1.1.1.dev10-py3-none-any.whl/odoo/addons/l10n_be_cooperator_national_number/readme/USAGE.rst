On the company, two new toggles 'Display National Number' and 'Require National
Number' are added. In order to expose the functionality of this module, you must
enable these toggles for every company that wishes to use it. 'Display' shows
the field and allows it to be filled in. 'Require' makes the field mandatory.
