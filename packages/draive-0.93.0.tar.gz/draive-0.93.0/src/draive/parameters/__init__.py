from draive.parameters.function import ParametrizedFunction
from draive.parameters.model import DataModel

__all__ = (
    "DataModel",
    "ParametrizedFunction",
)
