from __future__ import annotations

import contextlib
import logging
from functools import lru_cache

from .. import envs
from . import pyixml
from .__types__ import Detector, Device, Devices, ManufacturerEnum
from .__utils__ import (
    PCIDevice,
    byte_to_mebibyte,
    get_brief_version,
    get_pci_devices,
    get_utilization,
    support_command,
)

logger = logging.getLogger(__name__)


class IluvatarDetector(Detector):
    """
    Detect Iluvatar GPUs.
    """

    @staticmethod
    @lru_cache
    def is_supported() -> bool:
        """
        Check if the Iluvatar detector is supported.

        Returns:
            True if supported, False otherwise.

        """
        supported = False
        if envs.GPUSTACK_RUNTIME_DETECT.lower() not in ("auto", "iluvatar"):
            logger.debug("Iluvatar detection is disabled by environment variable")
            return supported

        pci_devs = IluvatarDetector.detect_pci_devices()
        if not pci_devs:
            logger.debug("No Iluvatar PCI devices found")

        supported = support_command("ixsmi")

        return supported

    @staticmethod
    @lru_cache
    def detect_pci_devices() -> dict[str, PCIDevice] | None:
        # See https://pcisig.com/membership/member-companies?combine=Iluvatar.
        pci_devs = get_pci_devices(vendor="0x1e3e")
        if not pci_devs:
            return None
        return {dev.address: dev for dev in pci_devs}

    def __init__(self):
        super().__init__(ManufacturerEnum.ILUVATAR)

    def detect(self) -> Devices | None:
        """
        Detect Iluvatar GPUs using ixsmi tool.

        Returns:
            A list of detected Iluvatar GPU devices,
            or None if not supported.

        Raises:
            If there is an error during detection.

        """
        if not self.is_supported():
            return None

        ret: Devices = []

        try:
            pyixml.nvmlInit()

            sys_driver_ver = pyixml.nvmlSystemGetDriverVersion()

            sys_runtime_ver_original = pyixml.nvmlSystemGetCudaDriverVersion()
            sys_runtime_ver_original = ".".join(
                map(
                    str,
                    [
                        sys_runtime_ver_original // 1000,
                        (sys_runtime_ver_original % 1000) // 10,
                        (sys_runtime_ver_original % 10),
                    ],
                ),
            )
            sys_runtime_ver = get_brief_version(
                sys_runtime_ver_original,
            )

            dev_count = pyixml.nvmlDeviceGetCount()
            for dev_idx in range(dev_count):
                dev = pyixml.nvmlDeviceGetHandleByIndex(dev_idx)

                dev_is_vgpu = False
                dev_index = dev_idx
                dev_uuid = pyixml.nvmlDeviceGetUUID(dev)
                dev_name = pyixml.nvmlDeviceGetName(dev)

                dev_cores = pyixml.nvmlDeviceGetNumGpuCores(dev)

                dev_mem, dev_mem_used = 0, 0
                with contextlib.suppress(pyixml.NVMLError):
                    dev_mem_info = pyixml.nvmlDeviceGetMemoryInfo(dev)
                    dev_mem = byte_to_mebibyte(  # byte to MiB
                        dev_mem_info.total,
                    )
                    dev_mem_used = byte_to_mebibyte(  # byte to MiB
                        dev_mem_info.used,
                    )

                dev_util_rates = pyixml.nvmlDeviceGetUtilizationRates(dev)

                dev_temp = pyixml.nvmlDeviceGetTemperature(
                    dev,
                    pyixml.NVML_TEMPERATURE_GPU,
                )

                dev_power, dev_power_used = None, None
                with contextlib.suppress(pyixml.NVMLError):
                    dev_power = pyixml.nvmlDeviceGetPowerManagementDefaultLimit(dev)
                    dev_power = dev_power // 1000  # mW to W
                    dev_power_used = (
                        pyixml.nvmlDeviceGetPowerUsage(dev) // 1000
                    )  # mW to W

                dev_cc = None
                with contextlib.suppress(pyixml.NVMLError):
                    dev_cc_t = pyixml.nvmlDeviceGetCudaComputeCapability(dev)
                    if dev_cc_t:
                        dev_cc = ".".join(map(str, dev_cc_t))

                dev_appendix = {
                    "vgpu": dev_is_vgpu,
                }

                ret.append(
                    Device(
                        manufacturer=self.manufacturer,
                        index=dev_index,
                        name=dev_name,
                        uuid=dev_uuid,
                        driver_version=sys_driver_ver,
                        runtime_version=sys_runtime_ver,
                        runtime_version_original=sys_runtime_ver_original,
                        compute_capability=dev_cc,
                        cores=dev_cores,
                        cores_utilization=dev_util_rates.gpu,
                        memory=dev_mem,
                        memory_used=dev_mem_used,
                        memory_utilization=get_utilization(dev_mem_used, dev_mem),
                        temperature=dev_temp,
                        power=dev_power,
                        power_used=dev_power_used,
                        appendix=dev_appendix,
                    ),
                )

        except Exception:
            if logger.isEnabledFor(logging.DEBUG):
                logger.exception("Failed to process devices fetching")
            raise

        return ret
