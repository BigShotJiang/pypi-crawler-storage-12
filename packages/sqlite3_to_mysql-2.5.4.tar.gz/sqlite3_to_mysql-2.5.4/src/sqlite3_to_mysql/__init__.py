"""Utility to transfer data from SQLite 3 to MySQL."""

__version__ = "2.5.4"

from .transporter import SQLite3toMySQL
