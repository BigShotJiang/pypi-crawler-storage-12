var qi = Object.defineProperty;
var tn = (a) => {
  throw TypeError(a);
};
var Li = (a, e, t) => e in a ? qi(a, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : a[e] = t;
var O = (a, e, t) => Li(a, typeof e != "symbol" ? e + "" : e, t), Ni = (a, e, t) => e.has(a) || tn("Cannot " + t);
var nn = (a, e, t) => e.has(a) ? tn("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(a) : e.set(a, t);
var We = (a, e, t) => (Ni(a, e, "access private method"), t);
const {
  HtmlTagHydration: Oi,
  SvelteComponent: zi,
  attr: an,
  binding_callbacks: Pi,
  children: Mi,
  claim_element: Ui,
  claim_html_tag: Hi,
  detach: ln,
  element: Gi,
  init: ji,
  insert_hydration: Zi,
  listen: Vi,
  noop: rn,
  safe_not_equal: Yi,
  toggle_class: on
} = window.__gradio__svelte__internal, { createEventDispatcher: Xi, onMount: Wi, tick: Jr } = window.__gradio__svelte__internal;
function Ki(a) {
  let e, t, n, i, r;
  return {
    c() {
      e = Gi("div"), t = new Oi(!1), this.h();
    },
    l(l) {
      e = Ui(l, "DIV", { class: !0 });
      var o = Mi(e);
      t = Hi(o, !1), o.forEach(ln), this.h();
    },
    h() {
      t.a = null, an(e, "class", n = "prose " + /*elem_classes*/
      a[0].join(" ") + " svelte-py6oj0"), on(e, "hide", !/*visible*/
      a[2]);
    },
    m(l, o) {
      Zi(l, e, o), t.m(
        /*value*/
        a[1],
        e
      ), a[7](e), i || (r = Vi(
        e,
        "click",
        /*handle_delegated_click*/
        a[4]
      ), i = !0);
    },
    p(l, [o]) {
      o & /*value*/
      2 && t.p(
        /*value*/
        l[1]
      ), o & /*elem_classes*/
      1 && n !== (n = "prose " + /*elem_classes*/
      l[0].join(" ") + " svelte-py6oj0") && an(e, "class", n), o & /*elem_classes, visible*/
      5 && on(e, "hide", !/*visible*/
      l[2]);
    },
    i: rn,
    o: rn,
    d(l) {
      l && ln(e), a[7](null), i = !1, r();
    }
  };
}
function Qi(a) {
  var e;
  const t = Object.assign({}, a.dataset);
  return a.tagName === "TR" && Object.keys(t).length === 0 && Array.from(a.querySelectorAll("td")).forEach((i, r) => {
    var l;
    t[`col_${r}`] = ((l = i.textContent) === null || l === void 0 ? void 0 : l.trim()) || "";
  }), Object.keys(t).length === 0 && (t.value = ((e = a.textContent) === null || e === void 0 ? void 0 : e.trim()) || ""), t;
}
function Ji(a) {
  let e = a.parentElement;
  for (; e; ) {
    const t = window.getComputedStyle(e);
    if (t.overflow === "auto" || t.overflow === "scroll" || t.overflowY === "auto" || t.overflowY === "scroll")
      return e;
    e = e.parentElement;
  }
  return null;
}
function ea(a, e, t) {
  var n = this && this.__awaiter || function(w, f, p, h) {
    function g(D) {
      return D instanceof p ? D : new p(function($) {
        $(D);
      });
    }
    return new (p || (p = Promise))(function(D, $) {
      function A(B) {
        try {
          T(h.next(B));
        } catch (I) {
          $(I);
        }
      }
      function E(B) {
        try {
          T(h.throw(B));
        } catch (I) {
          $(I);
        }
      }
      function T(B) {
        B.done ? D(B.value) : g(B.value).then(A, E);
      }
      T((h = h.apply(w, f || [])).next());
    });
  };
  let { elem_classes: i = [] } = e, { value: r } = e, { visible: l = !0 } = e, { autoscroll: o = !1 } = e, { selectable_elements: s = null } = e;
  const c = Xi();
  let u, _ = null;
  function d() {
    return u ? _ ? _.offsetHeight + _.scrollTop >= _.scrollHeight - 100 : window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 100 : !0;
  }
  function m() {
    u && (_ ? _.scrollTo(0, _.scrollHeight) : window.scrollTo(0, document.documentElement.scrollHeight));
  }
  function b(w) {
    if (!s || s.length === 0) {
      c("click");
      return;
    }
    const f = w.target;
    for (const p of s) {
      const h = f.closest(p);
      if (h) {
        const g = Qi(h);
        c("select", { index: p, value: g });
        return;
      }
    }
    c("click");
  }
  function v() {
    return n(this, void 0, void 0, function* () {
      !o || !u || (_ || (_ = Ji(u)), d() && (yield new Promise((w) => setTimeout(w, 300)), m()));
    });
  }
  Wi(() => {
    o && m(), v();
  });
  function y(w) {
    Pi[w ? "unshift" : "push"](() => {
      u = w, t(3, u);
    });
  }
  return a.$$set = (w) => {
    "elem_classes" in w && t(0, i = w.elem_classes), "value" in w && t(1, r = w.value), "visible" in w && t(2, l = w.visible), "autoscroll" in w && t(5, o = w.autoscroll), "selectable_elements" in w && t(6, s = w.selectable_elements);
  }, a.$$.update = () => {
    a.$$.dirty & /*value*/
    2 && c("change"), a.$$.dirty & /*value, autoscroll*/
    34 && r && o && v();
  }, [
    i,
    r,
    l,
    u,
    b,
    o,
    s,
    y
  ];
}
class ta extends zi {
  constructor(e) {
    super(), ji(this, e, ea, Ki, Yi, {
      elem_classes: 0,
      value: 1,
      visible: 2,
      autoscroll: 5,
      selectable_elements: 6
    });
  }
}
function Le(a) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; a > 1e3 && t < e.length - 1; )
    a /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(a) ? a : a.toFixed(1)) + n;
}
function st() {
}
const ai = typeof window < "u";
let sn = ai ? () => window.performance.now() : () => Date.now(), li = ai ? (a) => requestAnimationFrame(a) : st;
const Oe = /* @__PURE__ */ new Set();
function ri(a) {
  Oe.forEach((e) => {
    e.c(a) || (Oe.delete(e), e.f());
  }), Oe.size !== 0 && li(ri);
}
function na(a) {
  let e;
  return Oe.size === 0 && li(ri), { promise: new Promise((t) => {
    Oe.add(e = { c: a, f: t });
  }), abort() {
    Oe.delete(e);
  } };
}
const Ie = [];
function ia(a, e = st) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function i(l) {
    if (s = l, ((o = a) != o ? s == s : o !== s || o && typeof o == "object" || typeof o == "function") && (a = l, t)) {
      const c = !Ie.length;
      for (const u of n) u[1](), Ie.push(u, a);
      if (c) {
        for (let u = 0; u < Ie.length; u += 2) Ie[u][0](Ie[u + 1]);
        Ie.length = 0;
      }
    }
    var o, s;
  }
  function r(l) {
    i(l(a));
  }
  return { set: i, update: r, subscribe: function(l, o = st) {
    const s = [l, o];
    return n.add(s), n.size === 1 && (t = e(i, r) || st), l(a), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function un(a) {
  return Object.prototype.toString.call(a) === "[object Date]";
}
function qt(a, e, t, n) {
  if (typeof t == "number" || un(t)) {
    const i = n - t, r = (t - e) / (a.dt || 1 / 60), l = (r + (a.opts.stiffness * i - a.opts.damping * r) * a.inv_mass) * a.dt;
    return Math.abs(l) < a.opts.precision && Math.abs(i) < a.opts.precision ? n : (a.settled = !1, un(t) ? new Date(t.getTime() + l) : t + l);
  }
  if (Array.isArray(t)) return t.map((i, r) => qt(a, e[r], t[r], n[r]));
  if (typeof t == "object") {
    const i = {};
    for (const r in t) i[r] = qt(a, e[r], t[r], n[r]);
    return i;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function cn(a, e = {}) {
  const t = ia(a), { stiffness: n = 0.15, damping: i = 0.8, precision: r = 0.01 } = e;
  let l, o, s, c = a, u = a, _ = 1, d = 0, m = !1;
  function b(y, w = {}) {
    u = y;
    const f = s = {};
    return a == null || w.hard || v.stiffness >= 1 && v.damping >= 1 ? (m = !0, l = sn(), c = y, t.set(a = u), Promise.resolve()) : (w.soft && (d = 1 / (60 * (w.soft === !0 ? 0.5 : +w.soft)), _ = 0), o || (l = sn(), m = !1, o = na((p) => {
      if (m) return m = !1, o = null, !1;
      _ = Math.min(_ + d, 1);
      const h = { inv_mass: _, opts: v, settled: !0, dt: 60 * (p - l) / 1e3 }, g = qt(h, c, a, u);
      return l = p, c = a, t.set(a = g), h.settled && (o = null), !h.settled;
    })), new Promise((p) => {
      o.promise.then(() => {
        f === s && p();
      });
    }));
  }
  const v = { set: b, update: (y, w) => b(y(u, a), w), subscribe: t.subscribe, stiffness: n, damping: i, precision: r };
  return v;
}
const {
  SvelteComponent: aa,
  append_hydration: _e,
  attr: x,
  children: ne,
  claim_element: la,
  claim_svg_element: de,
  component_subscribe: _n,
  detach: K,
  element: ra,
  init: oa,
  insert_hydration: sa,
  noop: dn,
  safe_not_equal: ua,
  set_style: Ke,
  svg_element: pe,
  toggle_class: pn
} = window.__gradio__svelte__internal, { onMount: ca } = window.__gradio__svelte__internal;
function _a(a) {
  let e, t, n, i, r, l, o, s, c, u, _, d;
  return {
    c() {
      e = ra("div"), t = pe("svg"), n = pe("g"), i = pe("path"), r = pe("path"), l = pe("path"), o = pe("path"), s = pe("g"), c = pe("path"), u = pe("path"), _ = pe("path"), d = pe("path"), this.h();
    },
    l(m) {
      e = la(m, "DIV", { class: !0 });
      var b = ne(e);
      t = de(b, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var v = ne(t);
      n = de(v, "g", { style: !0 });
      var y = ne(n);
      i = de(y, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ne(i).forEach(K), r = de(y, "path", { d: !0, fill: !0, class: !0 }), ne(r).forEach(K), l = de(y, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ne(l).forEach(K), o = de(y, "path", { d: !0, fill: !0, class: !0 }), ne(o).forEach(K), y.forEach(K), s = de(v, "g", { style: !0 });
      var w = ne(s);
      c = de(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ne(c).forEach(K), u = de(w, "path", { d: !0, fill: !0, class: !0 }), ne(u).forEach(K), _ = de(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ne(_).forEach(K), d = de(w, "path", { d: !0, fill: !0, class: !0 }), ne(d).forEach(K), w.forEach(K), v.forEach(K), b.forEach(K), this.h();
    },
    h() {
      x(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), x(i, "fill", "#FF7C00"), x(i, "fill-opacity", "0.4"), x(i, "class", "svelte-43sxxs"), x(r, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), x(r, "fill", "#FF7C00"), x(r, "class", "svelte-43sxxs"), x(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), x(l, "fill", "#FF7C00"), x(l, "fill-opacity", "0.4"), x(l, "class", "svelte-43sxxs"), x(o, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), x(o, "fill", "#FF7C00"), x(o, "class", "svelte-43sxxs"), Ke(n, "transform", "translate(" + /*$top*/
      a[1][0] + "px, " + /*$top*/
      a[1][1] + "px)"), x(c, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), x(c, "fill", "#FF7C00"), x(c, "fill-opacity", "0.4"), x(c, "class", "svelte-43sxxs"), x(u, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), x(u, "fill", "#FF7C00"), x(u, "class", "svelte-43sxxs"), x(_, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), x(_, "fill", "#FF7C00"), x(_, "fill-opacity", "0.4"), x(_, "class", "svelte-43sxxs"), x(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), x(d, "fill", "#FF7C00"), x(d, "class", "svelte-43sxxs"), Ke(s, "transform", "translate(" + /*$bottom*/
      a[2][0] + "px, " + /*$bottom*/
      a[2][1] + "px)"), x(t, "viewBox", "-1200 -1200 3000 3000"), x(t, "fill", "none"), x(t, "xmlns", "http://www.w3.org/2000/svg"), x(t, "class", "svelte-43sxxs"), x(e, "class", "svelte-43sxxs"), pn(
        e,
        "margin",
        /*margin*/
        a[0]
      );
    },
    m(m, b) {
      sa(m, e, b), _e(e, t), _e(t, n), _e(n, i), _e(n, r), _e(n, l), _e(n, o), _e(t, s), _e(s, c), _e(s, u), _e(s, _), _e(s, d);
    },
    p(m, [b]) {
      b & /*$top*/
      2 && Ke(n, "transform", "translate(" + /*$top*/
      m[1][0] + "px, " + /*$top*/
      m[1][1] + "px)"), b & /*$bottom*/
      4 && Ke(s, "transform", "translate(" + /*$bottom*/
      m[2][0] + "px, " + /*$bottom*/
      m[2][1] + "px)"), b & /*margin*/
      1 && pn(
        e,
        "margin",
        /*margin*/
        m[0]
      );
    },
    i: dn,
    o: dn,
    d(m) {
      m && K(e);
    }
  };
}
function da(a, e, t) {
  let n, i;
  var r = this && this.__awaiter || function(m, b, v, y) {
    function w(f) {
      return f instanceof v ? f : new v(function(p) {
        p(f);
      });
    }
    return new (v || (v = Promise))(function(f, p) {
      function h($) {
        try {
          D(y.next($));
        } catch (A) {
          p(A);
        }
      }
      function g($) {
        try {
          D(y.throw($));
        } catch (A) {
          p(A);
        }
      }
      function D($) {
        $.done ? f($.value) : w($.value).then(h, g);
      }
      D((y = y.apply(m, b || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const o = cn([0, 0]);
  _n(a, o, (m) => t(1, n = m));
  const s = cn([0, 0]);
  _n(a, s, (m) => t(2, i = m));
  let c;
  function u() {
    return r(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 140]), s.set([-125, -140])]), yield Promise.all([o.set([-125, 140]), s.set([125, -140])]), yield Promise.all([o.set([-125, 0]), s.set([125, -0])]), yield Promise.all([o.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function _() {
    return r(this, void 0, void 0, function* () {
      yield u(), c || _();
    });
  }
  function d() {
    return r(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 0]), s.set([-125, 0])]), _();
    });
  }
  return ca(() => (d(), () => c = !0)), a.$$set = (m) => {
    "margin" in m && t(0, l = m.margin);
  }, [l, n, i, o, s];
}
class pa extends aa {
  constructor(e) {
    super(), oa(this, e, da, _a, ua, { margin: 0 });
  }
}
const {
  SvelteComponent: fa,
  append_hydration: Lt,
  assign: ha,
  attr: G,
  binding_callbacks: ma,
  children: Ue,
  claim_element: oi,
  claim_space: si,
  claim_svg_element: $t,
  create_slot: ga,
  detach: ve,
  element: ui,
  empty: fn,
  get_all_dirty_from_scope: ba,
  get_slot_changes: va,
  get_spread_update: Da,
  init: ya,
  insert_hydration: Ze,
  listen: wa,
  noop: $a,
  safe_not_equal: Fa,
  set_dynamic_element_data: hn,
  set_style: R,
  space: ci,
  svg_element: Ft,
  toggle_class: M,
  transition_in: _i,
  transition_out: di,
  update_slot_base: Ea
} = window.__gradio__svelte__internal;
function mn(a) {
  let e, t, n, i, r;
  return {
    c() {
      e = Ft("svg"), t = Ft("line"), n = Ft("line"), this.h();
    },
    l(l) {
      e = $t(l, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var o = Ue(e);
      t = $t(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Ue(t).forEach(ve), n = $t(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Ue(n).forEach(ve), o.forEach(ve), this.h();
    },
    h() {
      G(t, "x1", "1"), G(t, "y1", "9"), G(t, "x2", "9"), G(t, "y2", "1"), G(t, "stroke", "gray"), G(t, "stroke-width", "0.5"), G(n, "x1", "5"), G(n, "y1", "9"), G(n, "x2", "9"), G(n, "y2", "5"), G(n, "stroke", "gray"), G(n, "stroke-width", "0.5"), G(e, "class", "resize-handle svelte-239wnu"), G(e, "xmlns", "http://www.w3.org/2000/svg"), G(e, "viewBox", "0 0 10 10");
    },
    m(l, o) {
      Ze(l, e, o), Lt(e, t), Lt(e, n), i || (r = wa(
        e,
        "mousedown",
        /*resize*/
        a[27]
      ), i = !0);
    },
    p: $a,
    d(l) {
      l && ve(e), i = !1, r();
    }
  };
}
function ka(a) {
  var _;
  let e, t, n, i, r;
  const l = (
    /*#slots*/
    a[31].default
  ), o = ga(
    l,
    a,
    /*$$scope*/
    a[30],
    null
  );
  let s = (
    /*resizable*/
    a[19] && mn(a)
  ), c = [
    { "data-testid": (
      /*test_id*/
      a[11]
    ) },
    { id: (
      /*elem_id*/
      a[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((_ = a[7]) == null ? void 0 : _.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      a[20] ? "rtl" : "ltr"
    }
  ], u = {};
  for (let d = 0; d < c.length; d += 1)
    u = ha(u, c[d]);
  return {
    c() {
      e = ui(
        /*tag*/
        a[25]
      ), o && o.c(), t = ci(), s && s.c(), this.h();
    },
    l(d) {
      e = oi(
        d,
        /*tag*/
        (a[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var m = Ue(e);
      o && o.l(m), t = si(m), s && s.l(m), m.forEach(ve), this.h();
    },
    h() {
      hn(
        /*tag*/
        a[25]
      )(e, u), M(
        e,
        "hidden",
        /*visible*/
        a[14] === !1 || /*visible*/
        a[14] === "hidden"
      ), M(
        e,
        "padded",
        /*padding*/
        a[10]
      ), M(
        e,
        "flex",
        /*flex*/
        a[1]
      ), M(
        e,
        "border_focus",
        /*border_mode*/
        a[9] === "focus"
      ), M(
        e,
        "border_contrast",
        /*border_mode*/
        a[9] === "contrast"
      ), M(e, "hide-container", !/*explicit_call*/
      a[12] && !/*container*/
      a[13]), M(
        e,
        "fullscreen",
        /*fullscreen*/
        a[0]
      ), M(
        e,
        "animating",
        /*fullscreen*/
        a[0] && /*preexpansionBoundingRect*/
        a[24] !== null
      ), M(
        e,
        "auto-margin",
        /*scale*/
        a[17] === null
      ), R(
        e,
        "height",
        /*fullscreen*/
        a[0] ? void 0 : (
          /*get_dimension*/
          a[26](
            /*height*/
            a[2]
          )
        )
      ), R(
        e,
        "min-height",
        /*fullscreen*/
        a[0] ? void 0 : (
          /*get_dimension*/
          a[26](
            /*min_height*/
            a[3]
          )
        )
      ), R(
        e,
        "max-height",
        /*fullscreen*/
        a[0] ? void 0 : (
          /*get_dimension*/
          a[26](
            /*max_height*/
            a[4]
          )
        )
      ), R(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        a[24] ? `${/*preexpansionBoundingRect*/
        a[24].top}px` : "0px"
      ), R(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        a[24] ? `${/*preexpansionBoundingRect*/
        a[24].left}px` : "0px"
      ), R(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        a[24] ? `${/*preexpansionBoundingRect*/
        a[24].width}px` : "0px"
      ), R(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        a[24] ? `${/*preexpansionBoundingRect*/
        a[24].height}px` : "0px"
      ), R(
        e,
        "width",
        /*fullscreen*/
        a[0] ? void 0 : typeof /*width*/
        a[5] == "number" ? `calc(min(${/*width*/
        a[5]}px, 100%))` : (
          /*get_dimension*/
          a[26](
            /*width*/
            a[5]
          )
        )
      ), R(
        e,
        "border-style",
        /*variant*/
        a[8]
      ), R(
        e,
        "overflow",
        /*allow_overflow*/
        a[15] ? (
          /*overflow_behavior*/
          a[16]
        ) : "hidden"
      ), R(
        e,
        "flex-grow",
        /*scale*/
        a[17]
      ), R(e, "min-width", `calc(min(${/*min_width*/
      a[18]}px, 100%))`), R(e, "border-width", "var(--block-border-width)");
    },
    m(d, m) {
      Ze(d, e, m), o && o.m(e, null), Lt(e, t), s && s.m(e, null), a[32](e), r = !0;
    },
    p(d, m) {
      var b;
      o && o.p && (!r || m[0] & /*$$scope*/
      1073741824) && Ea(
        o,
        l,
        d,
        /*$$scope*/
        d[30],
        r ? va(
          l,
          /*$$scope*/
          d[30],
          m,
          null
        ) : ba(
          /*$$scope*/
          d[30]
        ),
        null
      ), /*resizable*/
      d[19] ? s ? s.p(d, m) : (s = mn(d), s.c(), s.m(e, null)) : s && (s.d(1), s = null), hn(
        /*tag*/
        d[25]
      )(e, u = Da(c, [
        (!r || m[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          d[11]
        ) },
        (!r || m[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          d[6]
        ) },
        (!r || m[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((b = d[7]) == null ? void 0 : b.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!r || m[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        d[20] ? "rtl" : "ltr")) && { dir: i }
      ])), M(
        e,
        "hidden",
        /*visible*/
        d[14] === !1 || /*visible*/
        d[14] === "hidden"
      ), M(
        e,
        "padded",
        /*padding*/
        d[10]
      ), M(
        e,
        "flex",
        /*flex*/
        d[1]
      ), M(
        e,
        "border_focus",
        /*border_mode*/
        d[9] === "focus"
      ), M(
        e,
        "border_contrast",
        /*border_mode*/
        d[9] === "contrast"
      ), M(e, "hide-container", !/*explicit_call*/
      d[12] && !/*container*/
      d[13]), M(
        e,
        "fullscreen",
        /*fullscreen*/
        d[0]
      ), M(
        e,
        "animating",
        /*fullscreen*/
        d[0] && /*preexpansionBoundingRect*/
        d[24] !== null
      ), M(
        e,
        "auto-margin",
        /*scale*/
        d[17] === null
      ), m[0] & /*fullscreen, height*/
      5 && R(
        e,
        "height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*height*/
            d[2]
          )
        )
      ), m[0] & /*fullscreen, min_height*/
      9 && R(
        e,
        "min-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*min_height*/
            d[3]
          )
        )
      ), m[0] & /*fullscreen, max_height*/
      17 && R(
        e,
        "max-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*max_height*/
            d[4]
          )
        )
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && R(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].top}px` : "0px"
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && R(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].left}px` : "0px"
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && R(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].width}px` : "0px"
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && R(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].height}px` : "0px"
      ), m[0] & /*fullscreen, width*/
      33 && R(
        e,
        "width",
        /*fullscreen*/
        d[0] ? void 0 : typeof /*width*/
        d[5] == "number" ? `calc(min(${/*width*/
        d[5]}px, 100%))` : (
          /*get_dimension*/
          d[26](
            /*width*/
            d[5]
          )
        )
      ), m[0] & /*variant*/
      256 && R(
        e,
        "border-style",
        /*variant*/
        d[8]
      ), m[0] & /*allow_overflow, overflow_behavior*/
      98304 && R(
        e,
        "overflow",
        /*allow_overflow*/
        d[15] ? (
          /*overflow_behavior*/
          d[16]
        ) : "hidden"
      ), m[0] & /*scale*/
      131072 && R(
        e,
        "flex-grow",
        /*scale*/
        d[17]
      ), m[0] & /*min_width*/
      262144 && R(e, "min-width", `calc(min(${/*min_width*/
      d[18]}px, 100%))`);
    },
    i(d) {
      r || (_i(o, d), r = !0);
    },
    o(d) {
      di(o, d), r = !1;
    },
    d(d) {
      d && ve(e), o && o.d(d), s && s.d(), a[32](null);
    }
  };
}
function gn(a) {
  let e;
  return {
    c() {
      e = ui("div"), this.h();
    },
    l(t) {
      e = oi(t, "DIV", { class: !0 }), Ue(e).forEach(ve), this.h();
    },
    h() {
      G(e, "class", "placeholder svelte-239wnu"), R(
        e,
        "height",
        /*placeholder_height*/
        a[22] + "px"
      ), R(
        e,
        "width",
        /*placeholder_width*/
        a[23] + "px"
      );
    },
    m(t, n) {
      Ze(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && R(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && R(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && ve(e);
    }
  };
}
function Ca(a) {
  let e, t, n, i = (
    /*tag*/
    a[25] && ka(a)
  ), r = (
    /*fullscreen*/
    a[0] && gn(a)
  );
  return {
    c() {
      i && i.c(), e = ci(), r && r.c(), t = fn();
    },
    l(l) {
      i && i.l(l), e = si(l), r && r.l(l), t = fn();
    },
    m(l, o) {
      i && i.m(l, o), Ze(l, e, o), r && r.m(l, o), Ze(l, t, o), n = !0;
    },
    p(l, o) {
      /*tag*/
      l[25] && i.p(l, o), /*fullscreen*/
      l[0] ? r ? r.p(l, o) : (r = gn(l), r.c(), r.m(t.parentNode, t)) : r && (r.d(1), r = null);
    },
    i(l) {
      n || (_i(i, l), n = !0);
    },
    o(l) {
      di(i, l), n = !1;
    },
    d(l) {
      l && (ve(e), ve(t)), i && i.d(l), r && r.d(l);
    }
  };
}
function Aa(a, e, t) {
  let { $$slots: n = {}, $$scope: i } = e, { height: r = void 0 } = e, { min_height: l = void 0 } = e, { max_height: o = void 0 } = e, { width: s = void 0 } = e, { elem_id: c = "" } = e, { elem_classes: u = [] } = e, { variant: _ = "solid" } = e, { border_mode: d = "base" } = e, { padding: m = !0 } = e, { type: b = "normal" } = e, { test_id: v = void 0 } = e, { explicit_call: y = !1 } = e, { container: w = !0 } = e, { visible: f = !0 } = e, { allow_overflow: p = !0 } = e, { overflow_behavior: h = "auto" } = e, { scale: g = null } = e, { min_width: D = 0 } = e, { flex: $ = !1 } = e, { resizable: A = !1 } = e, { rtl: E = !1 } = e, { fullscreen: T = !1 } = e, B = T, I, ue = b === "fieldset" ? "fieldset" : "div", te = 0, Ce = 0, X = null;
  function ce(F) {
    T && F.key === "Escape" && t(0, T = !1);
  }
  const N = (F) => {
    if (F !== void 0) {
      if (typeof F == "number")
        return F + "px";
      if (typeof F == "string")
        return F;
    }
  }, j = (F) => {
    let U = F.clientY;
    const we = (ge) => {
      const Fe = ge.clientY - U;
      U = ge.clientY, t(21, I.style.height = `${I.offsetHeight + Fe}px`, I);
    }, W = () => {
      window.removeEventListener("mousemove", we), window.removeEventListener("mouseup", W);
    };
    window.addEventListener("mousemove", we), window.addEventListener("mouseup", W);
  };
  function me(F) {
    ma[F ? "unshift" : "push"](() => {
      I = F, t(21, I);
    });
  }
  return a.$$set = (F) => {
    "height" in F && t(2, r = F.height), "min_height" in F && t(3, l = F.min_height), "max_height" in F && t(4, o = F.max_height), "width" in F && t(5, s = F.width), "elem_id" in F && t(6, c = F.elem_id), "elem_classes" in F && t(7, u = F.elem_classes), "variant" in F && t(8, _ = F.variant), "border_mode" in F && t(9, d = F.border_mode), "padding" in F && t(10, m = F.padding), "type" in F && t(28, b = F.type), "test_id" in F && t(11, v = F.test_id), "explicit_call" in F && t(12, y = F.explicit_call), "container" in F && t(13, w = F.container), "visible" in F && t(14, f = F.visible), "allow_overflow" in F && t(15, p = F.allow_overflow), "overflow_behavior" in F && t(16, h = F.overflow_behavior), "scale" in F && t(17, g = F.scale), "min_width" in F && t(18, D = F.min_width), "flex" in F && t(1, $ = F.flex), "resizable" in F && t(19, A = F.resizable), "rtl" in F && t(20, E = F.rtl), "fullscreen" in F && t(0, T = F.fullscreen), "$$scope" in F && t(30, i = F.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && T !== B && (t(29, B = T), T ? (t(24, X = I.getBoundingClientRect()), t(22, te = I.offsetHeight), t(23, Ce = I.offsetWidth), window.addEventListener("keydown", ce)) : (t(24, X = null), window.removeEventListener("keydown", ce))), a.$$.dirty[0] & /*visible*/
    16384 && (f || t(1, $ = !1));
  }, [
    T,
    $,
    r,
    l,
    o,
    s,
    c,
    u,
    _,
    d,
    m,
    v,
    y,
    w,
    f,
    p,
    h,
    g,
    D,
    A,
    E,
    I,
    te,
    Ce,
    X,
    ue,
    N,
    j,
    b,
    B,
    i,
    n,
    me
  ];
}
class Sa extends fa {
  constructor(e) {
    super(), ya(
      this,
      e,
      Aa,
      Ca,
      Fa,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Ht() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Be = Ht();
function pi(a) {
  Be = a;
}
const fi = /[&<>"']/, Ta = new RegExp(fi.source, "g"), hi = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Ba = new RegExp(hi.source, "g"), xa = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, bn = (a) => xa[a];
function Q(a, e) {
  if (e) {
    if (fi.test(a))
      return a.replace(Ta, bn);
  } else if (hi.test(a))
    return a.replace(Ba, bn);
  return a;
}
const Ia = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Ra(a) {
  return a.replace(Ia, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const qa = /(^|[^\[])\^/g;
function L(a, e) {
  let t = typeof a == "string" ? a : a.source;
  e = e || "";
  const n = {
    replace: (i, r) => {
      let l = typeof r == "string" ? r : r.source;
      return l = l.replace(qa, "$1"), t = t.replace(i, l), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function vn(a) {
  try {
    a = encodeURI(a).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return a;
}
const He = { exec: () => null };
function Dn(a, e) {
  const t = a.replace(/\|/g, (r, l, o) => {
    let s = !1, c = l;
    for (; --c >= 0 && o[c] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let i = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; i < n.length; i++)
    n[i] = n[i].trim().replace(/\\\|/g, "|");
  return n;
}
function Qe(a, e, t) {
  const n = a.length;
  if (n === 0)
    return "";
  let i = 0;
  for (; i < n && a.charAt(n - i - 1) === e; )
    i++;
  return a.slice(0, n - i);
}
function La(a, e) {
  if (a.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < a.length; n++)
    if (a[n] === "\\")
      n++;
    else if (a[n] === e[0])
      t++;
    else if (a[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function yn(a, e, t, n) {
  const i = e.href, r = e.title ? Q(e.title) : null, l = a[1].replace(/\\([\[\]])/g, "$1");
  if (a[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const o = {
      type: "link",
      raw: t,
      href: i,
      title: r,
      text: l,
      tokens: n.inlineTokens(l)
    };
    return n.state.inLink = !1, o;
  }
  return {
    type: "image",
    raw: t,
    href: i,
    title: r,
    text: Q(l)
  };
}
function Na(a, e) {
  const t = a.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((i) => {
    const r = i.match(/^\s+/);
    if (r === null)
      return i;
    const [l] = r;
    return l.length >= n.length ? i.slice(n.length) : i;
  }).join(`
`);
}
class ct {
  // set by the lexer
  constructor(e) {
    O(this, "options");
    O(this, "rules");
    // set by the lexer
    O(this, "lexer");
    this.options = e || Be;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : Qe(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], i = Na(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const i = Qe(n, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (n = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = Qe(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const r = this.lexer.blockTokens(n);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: t[0],
        tokens: r,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const i = n.length > 1, r = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = i ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = i ? n : "[*+-]");
      const l = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let o = "", s = "", c = !1;
      for (; e; ) {
        let u = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        o = t[0], e = e.substring(o.length);
        let _ = t[2].split(`
`, 1)[0].replace(/^\t+/, (w) => " ".repeat(3 * w.length)), d = e.split(`
`, 1)[0], m = 0;
        this.options.pedantic ? (m = 2, s = _.trimStart()) : (m = t[2].search(/[^ ]/), m = m > 4 ? 1 : m, s = _.slice(m), m += t[1].length);
        let b = !1;
        if (!_ && /^ *$/.test(d) && (o += d + `
`, e = e.substring(d.length + 1), u = !0), !u) {
          const w = new RegExp(`^ {0,${Math.min(3, m - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), f = new RegExp(`^ {0,${Math.min(3, m - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), p = new RegExp(`^ {0,${Math.min(3, m - 1)}}(?:\`\`\`|~~~)`), h = new RegExp(`^ {0,${Math.min(3, m - 1)}}#`);
          for (; e; ) {
            const g = e.split(`
`, 1)[0];
            if (d = g, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), p.test(d) || h.test(d) || w.test(d) || f.test(e))
              break;
            if (d.search(/[^ ]/) >= m || !d.trim())
              s += `
` + d.slice(m);
            else {
              if (b || _.search(/[^ ]/) >= 4 || p.test(_) || h.test(_) || f.test(_))
                break;
              s += `
` + d;
            }
            !b && !d.trim() && (b = !0), o += g + `
`, e = e.substring(g.length + 1), _ = d.slice(m);
          }
        }
        r.loose || (c ? r.loose = !0 : /\n *\n *$/.test(o) && (c = !0));
        let v = null, y;
        this.options.gfm && (v = /^\[[ xX]\] /.exec(s), v && (y = v[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), r.items.push({
          type: "list_item",
          raw: o,
          task: !!v,
          checked: y,
          loose: !1,
          text: s,
          tokens: []
        }), r.raw += o;
      }
      r.items[r.items.length - 1].raw = o.trimEnd(), r.items[r.items.length - 1].text = s.trimEnd(), r.raw = r.raw.trimEnd();
      for (let u = 0; u < r.items.length; u++)
        if (this.lexer.state.top = !1, r.items[u].tokens = this.lexer.blockTokens(r.items[u].text, []), !r.loose) {
          const _ = r.items[u].tokens.filter((m) => m.type === "space"), d = _.length > 0 && _.some((m) => /\n.*\n/.test(m.raw));
          r.loose = d;
        }
      if (r.loose)
        for (let u = 0; u < r.items.length; u++)
          r.items[u].loose = !0;
      return r;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), i = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", r = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: i,
        title: r
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Dn(t[1]), i = t[2].replace(/^\||\| *$/g, "").split("|"), r = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === i.length) {
      for (const o of i)
        /^ *-+: *$/.test(o) ? l.align.push("right") : /^ *:-+: *$/.test(o) ? l.align.push("center") : /^ *:-+ *$/.test(o) ? l.align.push("left") : l.align.push(null);
      for (const o of n)
        l.header.push({
          text: o,
          tokens: this.lexer.inline(o)
        });
      for (const o of r)
        l.rows.push(Dn(o, l.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: Q(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const l = Qe(n.slice(0, -1), "\\");
        if ((n.length - l.length) % 2 === 0)
          return;
      } else {
        const l = La(t[2], "()");
        if (l > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let i = t[2], r = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        l && (i = l[1], r = l[3]);
      } else
        r = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(n) ? i = i.slice(1) : i = i.slice(1, -1)), yn(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: r && r.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const i = (n[2] || n[1]).replace(/\s+/g, " "), r = t[i.toLowerCase()];
      if (!r) {
        const l = n[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return yn(n, r, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const l = [...i[0]].length - 1;
      let o, s, c = l, u = 0;
      const _ = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (_.lastIndex = 0, t = t.slice(-1 * e.length + l); (i = _.exec(t)) != null; ) {
        if (o = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !o)
          continue;
        if (s = [...o].length, i[3] || i[4]) {
          c += s;
          continue;
        } else if ((i[5] || i[6]) && l % 3 && !((l + s) % 3)) {
          u += s;
          continue;
        }
        if (c -= s, c > 0)
          continue;
        s = Math.min(s, s + c + u);
        const d = [...i[0]][0].length, m = e.slice(0, l + i.index + d + s);
        if (Math.min(l, s) % 2) {
          const v = m.slice(1, -1);
          return {
            type: "em",
            raw: m,
            text: v,
            tokens: this.lexer.inlineTokens(v)
          };
        }
        const b = m.slice(2, -2);
        return {
          type: "strong",
          raw: m,
          text: b,
          tokens: this.lexer.inlineTokens(b)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(n), r = /^ /.test(n) && / $/.test(n);
      return i && r && (n = n.substring(1, n.length - 1)), n = Q(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, i;
      return t[2] === "@" ? (n = Q(t[1]), i = "mailto:" + n) : (n = Q(t[1]), i = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: i,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, r;
      if (t[2] === "@")
        i = Q(t[0]), r = "mailto:" + i;
      else {
        let l;
        do
          l = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (l !== t[0]);
        i = Q(t[0]), t[1] === "www." ? r = "http://" + t[0] : r = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: r,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = Q(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Oa = /^(?: *(?:\n|$))+/, za = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Pa = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Ve = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Ma = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, mi = /(?:[*+-]|\d{1,9}[.)])/, gi = L(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, mi).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Gt = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Ua = /^[^\n]+/, jt = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Ha = L(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", jt).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Ga = L(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, mi).getRegex(), Dt = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Zt = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, ja = L("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Zt).replace("tag", Dt).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), bi = L(Gt).replace("hr", Ve).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Dt).getRegex(), Za = L(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", bi).getRegex(), Vt = {
  blockquote: Za,
  code: za,
  def: Ha,
  fences: Pa,
  heading: Ma,
  hr: Ve,
  html: ja,
  lheading: gi,
  list: Ga,
  newline: Oa,
  paragraph: bi,
  table: He,
  text: Ua
}, wn = L("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Ve).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Dt).getRegex(), Va = {
  ...Vt,
  table: wn,
  paragraph: L(Gt).replace("hr", Ve).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", wn).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Dt).getRegex()
}, Ya = {
  ...Vt,
  html: L(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Zt).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: He,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: L(Gt).replace("hr", Ve).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", gi).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, vi = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Xa = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Di = /^( {2,}|\\)\n(?!\s*$)/, Wa = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Ye = "\\p{P}\\p{S}", Ka = L(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Ye).getRegex(), Qa = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Ja = L(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Ye).getRegex(), el = L("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Ye).getRegex(), tl = L("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Ye).getRegex(), nl = L(/\\([punct])/, "gu").replace(/punct/g, Ye).getRegex(), il = L(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), al = L(Zt).replace("(?:-->|$)", "-->").getRegex(), ll = L("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", al).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), _t = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, rl = L(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", _t).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), yi = L(/^!?\[(label)\]\[(ref)\]/).replace("label", _t).replace("ref", jt).getRegex(), wi = L(/^!?\[(ref)\](?:\[\])?/).replace("ref", jt).getRegex(), ol = L("reflink|nolink(?!\\()", "g").replace("reflink", yi).replace("nolink", wi).getRegex(), Yt = {
  _backpedal: He,
  // only used for GFM url
  anyPunctuation: nl,
  autolink: il,
  blockSkip: Qa,
  br: Di,
  code: Xa,
  del: He,
  emStrongLDelim: Ja,
  emStrongRDelimAst: el,
  emStrongRDelimUnd: tl,
  escape: vi,
  link: rl,
  nolink: wi,
  punctuation: Ka,
  reflink: yi,
  reflinkSearch: ol,
  tag: ll,
  text: Wa,
  url: He
}, sl = {
  ...Yt,
  link: L(/^!?\[(label)\]\((.*?)\)/).replace("label", _t).getRegex(),
  reflink: L(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", _t).getRegex()
}, Nt = {
  ...Yt,
  escape: L(vi).replace("])", "~|])").getRegex(),
  url: L(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, ul = {
  ...Nt,
  br: L(Di).replace("{2,}", "*").getRegex(),
  text: L(Nt.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Je = {
  normal: Vt,
  gfm: Va,
  pedantic: Ya
}, ze = {
  normal: Yt,
  gfm: Nt,
  breaks: ul,
  pedantic: sl
};
class De {
  constructor(e) {
    O(this, "tokens");
    O(this, "options");
    O(this, "state");
    O(this, "tokenizer");
    O(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Be, this.options.tokenizer = this.options.tokenizer || new ct(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Je.normal,
      inline: ze.normal
    };
    this.options.pedantic ? (t.block = Je.pedantic, t.inline = ze.pedantic) : this.options.gfm && (t.block = Je.gfm, this.options.breaks ? t.inline = ze.breaks : t.inline = ze.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Je,
      inline: ze
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new De(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new De(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (o, s, c) => s + "    ".repeat(c.length));
    let n, i, r, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((o) => (n = o.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (r = e, this.options.extensions && this.options.extensions.startBlock) {
          let o = 1 / 0;
          const s = e.slice(1);
          let c;
          this.options.extensions.startBlock.forEach((u) => {
            c = u.call({ lexer: this }, s), typeof c == "number" && c >= 0 && (o = Math.min(o, c));
          }), o < 1 / 0 && o >= 0 && (r = e.substring(0, o + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(r))) {
          i = t[t.length - 1], l && i.type === "paragraph" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n), l = r.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && i.type === "text" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (e) {
          const o = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(o);
            break;
          } else
            throw new Error(o);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, i, r, l = e, o, s, c;
    if (this.tokens.links) {
      const u = Object.keys(this.tokens.links);
      if (u.length > 0)
        for (; (o = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          u.includes(o[0].slice(o[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (o = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (o = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, o.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (c = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((u) => (n = u.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, l, c)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (r = e, this.options.extensions && this.options.extensions.startInline) {
          let u = 1 / 0;
          const _ = e.slice(1);
          let d;
          this.options.extensions.startInline.forEach((m) => {
            d = m.call({ lexer: this }, _), typeof d == "number" && d >= 0 && (u = Math.min(u, d));
          }), u < 1 / 0 && u >= 0 && (r = e.substring(0, u + 1));
        }
        if (n = this.tokenizer.inlineText(r)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (c = n.raw.slice(-1)), s = !0, i = t[t.length - 1], i && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const u = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(u);
            break;
          } else
            throw new Error(u);
        }
      }
    return t;
  }
}
class dt {
  constructor(e) {
    O(this, "options");
    this.options = e || Be;
  }
  code(e, t, n) {
    var r;
    const i = (r = (t || "").match(/^\S*/)) == null ? void 0 : r[0];
    return e = e.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + Q(i) + '">' + (n ? e : Q(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : Q(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const i = t ? "ol" : "ul", r = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + i + r + `>
` + e + "</" + i + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const i = vn(e);
    if (i === null)
      return n;
    e = i;
    let r = '<a href="' + e + '"';
    return t && (r += ' title="' + t + '"'), r += ">" + n + "</a>", r;
  }
  image(e, t, n) {
    const i = vn(e);
    if (i === null)
      return n;
    e = i;
    let r = `<img src="${e}" alt="${n}"`;
    return t && (r += ` title="${t}"`), r += ">", r;
  }
  text(e) {
    return e;
  }
}
class Xt {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class ye {
  constructor(e) {
    O(this, "options");
    O(this, "renderer");
    O(this, "textRenderer");
    this.options = e || Be, this.options.renderer = this.options.renderer || new dt(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Xt();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new ye(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new ye(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const r = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[r.type]) {
        const l = r, o = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          n += o || "";
          continue;
        }
      }
      switch (r.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = r;
          n += this.renderer.heading(this.parseInline(l.tokens), l.depth, Ra(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = r;
          n += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = r;
          let o = "", s = "";
          for (let u = 0; u < l.header.length; u++)
            s += this.renderer.tablecell(this.parseInline(l.header[u].tokens), { header: !0, align: l.align[u] });
          o += this.renderer.tablerow(s);
          let c = "";
          for (let u = 0; u < l.rows.length; u++) {
            const _ = l.rows[u];
            s = "";
            for (let d = 0; d < _.length; d++)
              s += this.renderer.tablecell(this.parseInline(_[d].tokens), { header: !1, align: l.align[d] });
            c += this.renderer.tablerow(s);
          }
          n += this.renderer.table(o, c);
          continue;
        }
        case "blockquote": {
          const l = r, o = this.parse(l.tokens);
          n += this.renderer.blockquote(o);
          continue;
        }
        case "list": {
          const l = r, o = l.ordered, s = l.start, c = l.loose;
          let u = "";
          for (let _ = 0; _ < l.items.length; _++) {
            const d = l.items[_], m = d.checked, b = d.task;
            let v = "";
            if (d.task) {
              const y = this.renderer.checkbox(!!m);
              c ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = y + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = y + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: y + " "
              }) : v += y + " ";
            }
            v += this.parse(d.tokens, c), u += this.renderer.listitem(v, b, !!m);
          }
          n += this.renderer.list(u, o, s);
          continue;
        }
        case "html": {
          const l = r;
          n += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = r;
          n += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = r, o = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; i + 1 < e.length && e[i + 1].type === "text"; )
            l = e[++i], o += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          n += t ? this.renderer.paragraph(o) : o;
          continue;
        }
        default: {
          const l = 'Token with "' + r.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const r = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[r.type]) {
        const l = this.options.extensions.renderers[r.type].call({ parser: this }, r);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(r.type)) {
          n += l || "";
          continue;
        }
      }
      switch (r.type) {
        case "escape": {
          const l = r;
          n += t.text(l.text);
          break;
        }
        case "html": {
          const l = r;
          n += t.html(l.text);
          break;
        }
        case "link": {
          const l = r;
          n += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = r;
          n += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = r;
          n += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = r;
          n += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = r;
          n += t.codespan(l.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const l = r;
          n += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = r;
          n += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + r.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
}
class Ge {
  constructor(e) {
    O(this, "options");
    this.options = e || Be;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
O(Ge, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Te, Ot, $i;
class cl {
  constructor(...e) {
    nn(this, Te);
    O(this, "defaults", Ht());
    O(this, "options", this.setOptions);
    O(this, "parse", We(this, Te, Ot).call(this, De.lex, ye.parse));
    O(this, "parseInline", We(this, Te, Ot).call(this, De.lexInline, ye.parseInline));
    O(this, "Parser", ye);
    O(this, "Renderer", dt);
    O(this, "TextRenderer", Xt);
    O(this, "Lexer", De);
    O(this, "Tokenizer", ct);
    O(this, "Hooks", Ge);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, r;
    let n = [];
    for (const l of e)
      switch (n = n.concat(t.call(this, l)), l.type) {
        case "table": {
          const o = l;
          for (const s of o.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of o.rows)
            for (const c of s)
              n = n.concat(this.walkTokens(c.tokens, t));
          break;
        }
        case "list": {
          const o = l;
          n = n.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = l;
          (r = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && r[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((s) => {
            const c = o[s].flat(1 / 0);
            n = n.concat(this.walkTokens(c, t));
          }) : o.tokens && (n = n.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const i = { ...n };
      if (i.async = this.defaults.async || i.async || !1, n.extensions && (n.extensions.forEach((r) => {
        if (!r.name)
          throw new Error("extension name required");
        if ("renderer" in r) {
          const l = t.renderers[r.name];
          l ? t.renderers[r.name] = function(...o) {
            let s = r.renderer.apply(this, o);
            return s === !1 && (s = l.apply(this, o)), s;
          } : t.renderers[r.name] = r.renderer;
        }
        if ("tokenizer" in r) {
          if (!r.level || r.level !== "block" && r.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[r.level];
          l ? l.unshift(r.tokenizer) : t[r.level] = [r.tokenizer], r.start && (r.level === "block" ? t.startBlock ? t.startBlock.push(r.start) : t.startBlock = [r.start] : r.level === "inline" && (t.startInline ? t.startInline.push(r.start) : t.startInline = [r.start]));
        }
        "childTokens" in r && r.childTokens && (t.childTokens[r.name] = r.childTokens);
      }), i.extensions = t), n.renderer) {
        const r = this.defaults.renderer || new dt(this.defaults);
        for (const l in n.renderer) {
          if (!(l in r))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const o = l, s = n.renderer[o], c = r[o];
          r[o] = (...u) => {
            let _ = s.apply(r, u);
            return _ === !1 && (_ = c.apply(r, u)), _ || "";
          };
        }
        i.renderer = r;
      }
      if (n.tokenizer) {
        const r = this.defaults.tokenizer || new ct(this.defaults);
        for (const l in n.tokenizer) {
          if (!(l in r))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const o = l, s = n.tokenizer[o], c = r[o];
          r[o] = (...u) => {
            let _ = s.apply(r, u);
            return _ === !1 && (_ = c.apply(r, u)), _;
          };
        }
        i.tokenizer = r;
      }
      if (n.hooks) {
        const r = this.defaults.hooks || new Ge();
        for (const l in n.hooks) {
          if (!(l in r))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const o = l, s = n.hooks[o], c = r[o];
          Ge.passThroughHooks.has(l) ? r[o] = (u) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(r, u)).then((d) => c.call(r, d));
            const _ = s.call(r, u);
            return c.call(r, _);
          } : r[o] = (...u) => {
            let _ = s.apply(r, u);
            return _ === !1 && (_ = c.apply(r, u)), _;
          };
        }
        i.hooks = r;
      }
      if (n.walkTokens) {
        const r = this.defaults.walkTokens, l = n.walkTokens;
        i.walkTokens = function(o) {
          let s = [];
          return s.push(l.call(this, o)), r && (s = s.concat(r.call(this, o))), s;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return De.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return ye.parse(e, t ?? this.defaults);
  }
}
Te = new WeakSet(), Ot = function(e, t) {
  return (n, i) => {
    const r = { ...i }, l = { ...this.defaults, ...r };
    this.defaults.async === !0 && r.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const o = We(this, Te, $i).call(this, !!l.silent, !!l.async);
    if (typeof n > "u" || n === null)
      return o(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(n) : n).then((s) => e(s, l)).then((s) => l.hooks ? l.hooks.processAllTokens(s) : s).then((s) => l.walkTokens ? Promise.all(this.walkTokens(s, l.walkTokens)).then(() => s) : s).then((s) => t(s, l)).then((s) => l.hooks ? l.hooks.postprocess(s) : s).catch(o);
    try {
      l.hooks && (n = l.hooks.preprocess(n));
      let s = e(n, l);
      l.hooks && (s = l.hooks.processAllTokens(s)), l.walkTokens && this.walkTokens(s, l.walkTokens);
      let c = t(s, l);
      return l.hooks && (c = l.hooks.postprocess(c)), c;
    } catch (s) {
      return o(s);
    }
  };
}, $i = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const i = "<p>An error occurred:</p><pre>" + Q(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(i) : i;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const Se = new cl();
function q(a, e) {
  return Se.parse(a, e);
}
q.options = q.setOptions = function(a) {
  return Se.setOptions(a), q.defaults = Se.defaults, pi(q.defaults), q;
};
q.getDefaults = Ht;
q.defaults = Be;
q.use = function(...a) {
  return Se.use(...a), q.defaults = Se.defaults, pi(q.defaults), q;
};
q.walkTokens = function(a, e) {
  return Se.walkTokens(a, e);
};
q.parseInline = Se.parseInline;
q.Parser = ye;
q.parser = ye.parse;
q.Renderer = dt;
q.TextRenderer = Xt;
q.Lexer = De;
q.lexer = De.lex;
q.Tokenizer = ct;
q.Hooks = Ge;
q.parse = q;
q.options;
q.setOptions;
q.use;
q.walkTokens;
q.parseInline;
ye.parse;
De.lex;
const _l = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, dl = Object.hasOwnProperty;
class Fi {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let i = pl(e, t === !0);
    const r = i;
    for (; dl.call(n.occurrences, i); )
      n.occurrences[r]++, i = r + "-" + n.occurrences[r];
    return n.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function pl(a, e) {
  return typeof a != "string" ? "" : (e || (a = a.toLowerCase()), a.replace(_l, "").replace(/ /g, "-"));
}
new Fi();
var $n = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, fl = { exports: {} };
(function(a) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, r = 0, l = {}, o = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function f(p) {
          return p instanceof s ? new s(p.type, f(p.content), p.alias) : Array.isArray(p) ? p.map(f) : p.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(f) {
          return Object.prototype.toString.call(f).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(f) {
          return f.__id || Object.defineProperty(f, "__id", { value: ++r }), f.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function f(p, h) {
          h = h || {};
          var g, D;
          switch (o.util.type(p)) {
            case "Object":
              if (D = o.util.objId(p), h[D])
                return h[D];
              g = /** @type {Record<string, any>} */
              {}, h[D] = g;
              for (var $ in p)
                p.hasOwnProperty($) && (g[$] = f(p[$], h));
              return (
                /** @type {any} */
                g
              );
            case "Array":
              return D = o.util.objId(p), h[D] ? h[D] : (g = [], h[D] = g, /** @type {Array} */
              /** @type {any} */
              p.forEach(function(A, E) {
                g[E] = f(A, h);
              }), /** @type {any} */
              g);
            default:
              return p;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(f) {
          for (; f; ) {
            var p = i.exec(f.className);
            if (p)
              return p[1].toLowerCase();
            f = f.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(f, p) {
          f.className = f.className.replace(RegExp(i, "gi"), ""), f.classList.add("language-" + p);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if (document.currentScript && document.currentScript.tagName === "SCRIPT")
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (g) {
            var f = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(g.stack) || [])[1];
            if (f) {
              var p = document.getElementsByTagName("script");
              for (var h in p)
                if (p[h].src == f)
                  return p[h];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(f, p, h) {
          for (var g = "no-" + p; f; ) {
            var D = f.classList;
            if (D.contains(p))
              return !0;
            if (D.contains(g))
              return !1;
            f = f.parentElement;
          }
          return !!h;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(f, p) {
          var h = o.util.clone(o.languages[f]);
          for (var g in p)
            h[g] = p[g];
          return h;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(f, p, h, g) {
          g = g || /** @type {any} */
          o.languages;
          var D = g[f], $ = {};
          for (var A in D)
            if (D.hasOwnProperty(A)) {
              if (A == p)
                for (var E in h)
                  h.hasOwnProperty(E) && ($[E] = h[E]);
              h.hasOwnProperty(A) || ($[A] = D[A]);
            }
          var T = g[f];
          return g[f] = $, o.languages.DFS(o.languages, function(B, I) {
            I === T && B != f && (this[B] = $);
          }), $;
        },
        // Traverse a language definition with Depth First Search
        DFS: function f(p, h, g, D) {
          D = D || {};
          var $ = o.util.objId;
          for (var A in p)
            if (p.hasOwnProperty(A)) {
              h.call(p, A, p[A], g || A);
              var E = p[A], T = o.util.type(E);
              T === "Object" && !D[$(E)] ? (D[$(E)] = !0, f(E, h, null, D)) : T === "Array" && !D[$(E)] && (D[$(E)] = !0, f(E, h, A, D));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(f, p) {
        o.highlightAllUnder(document, f, p);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(f, p, h) {
        var g = {
          callback: h,
          container: f,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        o.hooks.run("before-highlightall", g), g.elements = Array.prototype.slice.apply(g.container.querySelectorAll(g.selector)), o.hooks.run("before-all-elements-highlight", g);
        for (var D = 0, $; $ = g.elements[D++]; )
          o.highlightElement($, p === !0, g.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(f, p, h) {
        var g = o.util.getLanguage(f), D = o.languages[g];
        o.util.setLanguage(f, g);
        var $ = f.parentElement;
        $ && $.nodeName.toLowerCase() === "pre" && o.util.setLanguage($, g);
        var A = f.textContent, E = {
          element: f,
          language: g,
          grammar: D,
          code: A
        };
        function T(I) {
          E.highlightedCode = I, o.hooks.run("before-insert", E), E.element.innerHTML = E.highlightedCode, o.hooks.run("after-highlight", E), o.hooks.run("complete", E), h && h.call(E.element);
        }
        if (o.hooks.run("before-sanity-check", E), $ = E.element.parentElement, $ && $.nodeName.toLowerCase() === "pre" && !$.hasAttribute("tabindex") && $.setAttribute("tabindex", "0"), !E.code) {
          o.hooks.run("complete", E), h && h.call(E.element);
          return;
        }
        if (o.hooks.run("before-highlight", E), !E.grammar) {
          T(o.util.encode(E.code));
          return;
        }
        if (p && n.Worker) {
          var B = new Worker(o.filename);
          B.onmessage = function(I) {
            T(I.data);
          }, B.postMessage(JSON.stringify({
            language: E.language,
            code: E.code,
            immediateClose: !0
          }));
        } else
          T(o.highlight(E.code, E.grammar, E.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(f, p, h) {
        var g = {
          code: f,
          grammar: p,
          language: h
        };
        if (o.hooks.run("before-tokenize", g), !g.grammar)
          throw new Error('The language "' + g.language + '" has no grammar.');
        return g.tokens = o.tokenize(g.code, g.grammar), o.hooks.run("after-tokenize", g), s.stringify(o.util.encode(g.tokens), g.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(f, p) {
        var h = p.rest;
        if (h) {
          for (var g in h)
            p[g] = h[g];
          delete p.rest;
        }
        var D = new _();
        return d(D, D.head, f), u(f, D, p, D.head, 0), b(D);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(f, p) {
          var h = o.hooks.all;
          h[f] = h[f] || [], h[f].push(p);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(f, p) {
          var h = o.hooks.all[f];
          if (!(!h || !h.length))
            for (var g = 0, D; D = h[g++]; )
              D(p);
        }
      },
      Token: s
    };
    n.Prism = o;
    function s(f, p, h, g) {
      this.type = f, this.content = p, this.alias = h, this.length = (g || "").length | 0;
    }
    s.stringify = function f(p, h) {
      if (typeof p == "string")
        return p;
      if (Array.isArray(p)) {
        var g = "";
        return p.forEach(function(T) {
          g += f(T, h);
        }), g;
      }
      var D = {
        type: p.type,
        content: f(p.content, h),
        tag: "span",
        classes: ["token", p.type],
        attributes: {},
        language: h
      }, $ = p.alias;
      $ && (Array.isArray($) ? Array.prototype.push.apply(D.classes, $) : D.classes.push($)), o.hooks.run("wrap", D);
      var A = "";
      for (var E in D.attributes)
        A += " " + E + '="' + (D.attributes[E] || "").replace(/"/g, "&quot;") + '"';
      return "<" + D.tag + ' class="' + D.classes.join(" ") + '"' + A + ">" + D.content + "</" + D.tag + ">";
    };
    function c(f, p, h, g) {
      f.lastIndex = p;
      var D = f.exec(h);
      if (D && g && D[1]) {
        var $ = D[1].length;
        D.index += $, D[0] = D[0].slice($);
      }
      return D;
    }
    function u(f, p, h, g, D, $) {
      for (var A in h)
        if (!(!h.hasOwnProperty(A) || !h[A])) {
          var E = h[A];
          E = Array.isArray(E) ? E : [E];
          for (var T = 0; T < E.length; ++T) {
            if ($ && $.cause == A + "," + T)
              return;
            var B = E[T], I = B.inside, ue = !!B.lookbehind, te = !!B.greedy, Ce = B.alias;
            if (te && !B.pattern.global) {
              var X = B.pattern.toString().match(/[imsuy]*$/)[0];
              B.pattern = RegExp(B.pattern.source, X + "g");
            }
            for (var ce = B.pattern || B, N = g.next, j = D; N !== p.tail && !($ && j >= $.reach); j += N.value.length, N = N.next) {
              var me = N.value;
              if (p.length > f.length)
                return;
              if (!(me instanceof s)) {
                var F = 1, U;
                if (te) {
                  if (U = c(ce, j, f, ue), !U || U.index >= f.length)
                    break;
                  var Fe = U.index, we = U.index + U[0].length, W = j;
                  for (W += N.value.length; Fe >= W; )
                    N = N.next, W += N.value.length;
                  if (W -= N.value.length, j = W, N.value instanceof s)
                    continue;
                  for (var ge = N; ge !== p.tail && (W < we || typeof ge.value == "string"); ge = ge.next)
                    F++, W += ge.value.length;
                  F--, me = f.slice(j, W), U.index -= j;
                } else if (U = c(ce, 0, me, ue), !U)
                  continue;
                var Fe = U.index, xe = U[0], C = me.slice(0, Fe), en = me.slice(Fe + xe.length), yt = j + me.length;
                $ && yt > $.reach && ($.reach = yt);
                var Xe = N.prev;
                C && (Xe = d(p, Xe, C), j += C.length), m(p, Xe, F);
                var Ri = new s(A, I ? o.tokenize(xe, I) : xe, Ce, xe);
                if (N = d(p, Xe, Ri), en && d(p, N, en), F > 1) {
                  var wt = {
                    cause: A + "," + T,
                    reach: yt
                  };
                  u(f, p, h, N.prev, j, wt), $ && wt.reach > $.reach && ($.reach = wt.reach);
                }
              }
            }
          }
        }
    }
    function _() {
      var f = { value: null, prev: null, next: null }, p = { value: null, prev: f, next: null };
      f.next = p, this.head = f, this.tail = p, this.length = 0;
    }
    function d(f, p, h) {
      var g = p.next, D = { value: h, prev: p, next: g };
      return p.next = D, g.prev = D, f.length++, D;
    }
    function m(f, p, h) {
      for (var g = p.next, D = 0; D < h && g !== f.tail; D++)
        g = g.next;
      p.next = g, g.prev = p, f.length -= D;
    }
    function b(f) {
      for (var p = [], h = f.head.next; h !== f.tail; )
        p.push(h.value), h = h.next;
      return p;
    }
    if (!n.document)
      return n.addEventListener && (o.disableWorkerMessageHandler || n.addEventListener("message", function(f) {
        var p = JSON.parse(f.data), h = p.language, g = p.code, D = p.immediateClose;
        n.postMessage(o.highlight(g, o.languages[h], h)), D && n.close();
      }, !1)), o;
    var v = o.util.currentScript();
    v && (o.filename = v.src, v.hasAttribute("data-manual") && (o.manual = !0));
    function y() {
      o.manual || o.highlightAll();
    }
    if (!o.manual) {
      var w = document.readyState;
      w === "loading" || w === "interactive" && v && v.defer ? document.addEventListener("DOMContentLoaded", y) : window.requestAnimationFrame ? window.requestAnimationFrame(y) : window.setTimeout(y, 16);
    }
    return o;
  }(e);
  a.exports && (a.exports = t), typeof $n < "u" && ($n.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, r) {
      var l = {};
      l["language-" + r] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[r]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var o = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      o["language-" + r] = {
        pattern: /[\s\S]+/,
        inside: t.languages[r]
      };
      var s = {};
      s[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: o
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, i) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: t.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var r = n.languages.markup;
    r && (r.tag.addInlined("style", "css"), r.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", i = function(v, y) {
      return "✖ Error " + v + " while fetching file: " + y;
    }, r = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, o = "data-src-status", s = "loading", c = "loaded", u = "failed", _ = "pre[data-src]:not([" + o + '="' + c + '"]):not([' + o + '="' + s + '"])';
    function d(v, y, w) {
      var f = new XMLHttpRequest();
      f.open("GET", v, !0), f.onreadystatechange = function() {
        f.readyState == 4 && (f.status < 400 && f.responseText ? y(f.responseText) : f.status >= 400 ? w(i(f.status, f.statusText)) : w(r));
      }, f.send(null);
    }
    function m(v) {
      var y = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(v || "");
      if (y) {
        var w = Number(y[1]), f = y[2], p = y[3];
        return f ? p ? [w, Number(p)] : [w, void 0] : [w, w];
      }
    }
    t.hooks.add("before-highlightall", function(v) {
      v.selector += ", " + _;
    }), t.hooks.add("before-sanity-check", function(v) {
      var y = (
        /** @type {HTMLPreElement} */
        v.element
      );
      if (y.matches(_)) {
        v.code = "", y.setAttribute(o, s);
        var w = y.appendChild(document.createElement("CODE"));
        w.textContent = n;
        var f = y.getAttribute("data-src"), p = v.language;
        if (p === "none") {
          var h = (/\.(\w+)$/.exec(f) || [, "none"])[1];
          p = l[h] || h;
        }
        t.util.setLanguage(w, p), t.util.setLanguage(y, p);
        var g = t.plugins.autoloader;
        g && g.loadLanguages(p), d(
          f,
          function(D) {
            y.setAttribute(o, c);
            var $ = m(y.getAttribute("data-range"));
            if ($) {
              var A = D.split(/\r\n?|\n/g), E = $[0], T = $[1] == null ? A.length : $[1];
              E < 0 && (E += A.length), E = Math.max(0, Math.min(E - 1, A.length)), T < 0 && (T += A.length), T = Math.max(0, Math.min(T, A.length)), D = A.slice(E, T).join(`
`), y.hasAttribute("data-start") || y.setAttribute("data-start", String(E + 1));
            }
            w.textContent = D, t.highlightElement(w);
          },
          function(D) {
            y.setAttribute(o, u), w.textContent = D;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(y) {
        for (var w = (y || document).querySelectorAll(_), f = 0, p; p = w[f++]; )
          t.highlightElement(p);
      }
    };
    var b = !1;
    t.fileHighlight = function() {
      b || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), b = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(fl);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(a) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  a.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, a.languages.tex = a.languages.latex, a.languages.context = a.languages.latex;
})(Prism);
(function(a) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  a.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = a.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], r = n.variable[1].inside, l = 0; l < i.length; l++)
    r[i[l]] = a.languages.bash[i[l]];
  a.languages.sh = a.languages.bash, a.languages.shell = a.languages.bash;
})(Prism);
Prism.languages.c = Prism.languages.extend("clike", {
  comment: {
    pattern: /\/\/(?:[^\r\n\\]|\\(?:\r\n?|\n|(?![\r\n])))*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  string: {
    // https://en.cppreference.com/w/c/language/string_literal
    pattern: /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"/,
    greedy: !0
  },
  "class-name": {
    pattern: /(\b(?:enum|struct)\s+(?:__attribute__\s*\(\([\s\S]*?\)\)\s*)?)\w+|\b[a-z]\w*_t\b/,
    lookbehind: !0
  },
  keyword: /\b(?:_Alignas|_Alignof|_Atomic|_Bool|_Complex|_Generic|_Imaginary|_Noreturn|_Static_assert|_Thread_local|__attribute__|asm|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|typeof|union|unsigned|void|volatile|while)\b/,
  function: /\b[a-z_]\w*(?=\s*\()/i,
  number: /(?:\b0x(?:[\da-f]+(?:\.[\da-f]*)?|\.[\da-f]+)(?:p[+-]?\d+)?|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?)[ful]{0,4}/i,
  operator: />>=?|<<=?|->|([-+&|:])\1|[?:~]|[-+*/%&|^!=<>]=?/
});
Prism.languages.insertBefore("c", "string", {
  char: {
    // https://en.cppreference.com/w/c/language/character_constant
    pattern: /'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n]){0,32}'/,
    greedy: !0
  }
});
Prism.languages.insertBefore("c", "string", {
  macro: {
    // allow for multiline macro definitions
    // spaces after the # character compile fine with gcc
    pattern: /(^[\t ]*)#\s*[a-z](?:[^\r\n\\/]|\/(?!\*)|\/\*(?:[^*]|\*(?!\/))*\*\/|\\(?:\r\n|[\s\S]))*/im,
    lookbehind: !0,
    greedy: !0,
    alias: "property",
    inside: {
      string: [
        {
          // highlight the path of the include statement as a string
          pattern: /^(#\s*include\s*)<[^>]+>/,
          lookbehind: !0
        },
        Prism.languages.c.string
      ],
      char: Prism.languages.c.char,
      comment: Prism.languages.c.comment,
      "macro-name": [
        {
          pattern: /(^#\s*define\s+)\w+\b(?!\()/i,
          lookbehind: !0
        },
        {
          pattern: /(^#\s*define\s+)\w+\b(?=\()/i,
          lookbehind: !0,
          alias: "function"
        }
      ],
      // highlight macro directives as keywords
      directive: {
        pattern: /^(#\s*)[a-z]+/,
        lookbehind: !0,
        alias: "keyword"
      },
      "directive-hash": /^#/,
      punctuation: /##|\\(?=[\r\n])/,
      expression: {
        pattern: /\S[\s\S]*/,
        inside: Prism.languages.c
      }
    }
  }
});
Prism.languages.insertBefore("c", "function", {
  // highlight predefined macros as constants
  constant: /\b(?:EOF|NULL|SEEK_CUR|SEEK_END|SEEK_SET|__DATE__|__FILE__|__LINE__|__TIMESTAMP__|__TIME__|__func__|stderr|stdin|stdout)\b/
});
delete Prism.languages.c.boolean;
(function(a) {
  var e = /\b(?:alignas|alignof|asm|auto|bool|break|case|catch|char|char16_t|char32_t|char8_t|class|co_await|co_return|co_yield|compl|concept|const|const_cast|consteval|constexpr|constinit|continue|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|final|float|for|friend|goto|if|import|inline|int|int16_t|int32_t|int64_t|int8_t|long|module|mutable|namespace|new|noexcept|nullptr|operator|override|private|protected|public|register|reinterpret_cast|requires|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|try|typedef|typeid|typename|uint16_t|uint32_t|uint64_t|uint8_t|union|unsigned|using|virtual|void|volatile|wchar_t|while)\b/, t = /\b(?!<keyword>)\w+(?:\s*\.\s*\w+)*\b/.source.replace(/<keyword>/g, function() {
    return e.source;
  });
  a.languages.cpp = a.languages.extend("c", {
    "class-name": [
      {
        pattern: RegExp(/(\b(?:class|concept|enum|struct|typename)\s+)(?!<keyword>)\w+/.source.replace(/<keyword>/g, function() {
          return e.source;
        })),
        lookbehind: !0
      },
      // This is intended to capture the class name of method implementations like:
      //   void foo::bar() const {}
      // However! The `foo` in the above example could also be a namespace, so we only capture the class name if
      // it starts with an uppercase letter. This approximation should give decent results.
      /\b[A-Z]\w*(?=\s*::\s*\w+\s*\()/,
      // This will capture the class name before destructors like:
      //   Foo::~Foo() {}
      /\b[A-Z_]\w*(?=\s*::\s*~\w+\s*\()/i,
      // This also intends to capture the class name of method implementations but here the class has template
      // parameters, so it can't be a namespace (until C++ adds generic namespaces).
      /\b\w+(?=\s*<(?:[^<>]|<(?:[^<>]|<[^<>]*>)*>)*>\s*::\s*\w+\s*\()/
    ],
    keyword: e,
    number: {
      pattern: /(?:\b0b[01']+|\b0x(?:[\da-f']+(?:\.[\da-f']*)?|\.[\da-f']+)(?:p[+-]?[\d']+)?|(?:\b[\d']+(?:\.[\d']*)?|\B\.[\d']+)(?:e[+-]?[\d']+)?)[ful]{0,4}/i,
      greedy: !0
    },
    operator: />>=?|<<=?|->|--|\+\+|&&|\|\||[?:~]|<=>|[-+*/%&|^!=<>]=?|\b(?:and|and_eq|bitand|bitor|not|not_eq|or|or_eq|xor|xor_eq)\b/,
    boolean: /\b(?:false|true)\b/
  }), a.languages.insertBefore("cpp", "string", {
    module: {
      // https://en.cppreference.com/w/cpp/language/modules
      pattern: RegExp(
        /(\b(?:import|module)\s+)/.source + "(?:" + // header-name
        /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|<[^<>\r\n]*>/.source + "|" + // module name or partition or both
        /<mod-name>(?:\s*:\s*<mod-name>)?|:\s*<mod-name>/.source.replace(/<mod-name>/g, function() {
          return t;
        }) + ")"
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        string: /^[<"][\s\S]+/,
        operator: /:/,
        punctuation: /\./
      }
    },
    "raw-string": {
      pattern: /R"([^()\\ ]{0,16})\([\s\S]*?\)\1"/,
      alias: "string",
      greedy: !0
    }
  }), a.languages.insertBefore("cpp", "keyword", {
    "generic-function": {
      pattern: /\b(?!operator\b)[a-z_]\w*\s*<(?:[^<>]|<[^<>]*>)*>(?=\s*\()/i,
      inside: {
        function: /^\w+/,
        generic: {
          pattern: /<[\s\S]+/,
          alias: "class-name",
          inside: a.languages.cpp
        }
      }
    }
  }), a.languages.insertBefore("cpp", "operator", {
    "double-colon": {
      pattern: /::/,
      alias: "punctuation"
    }
  }), a.languages.insertBefore("cpp", "class-name", {
    // the base clause is an optional list of parent classes
    // https://en.cppreference.com/w/cpp/language/class
    "base-clause": {
      pattern: /(\b(?:class|struct)\s+\w+\s*:\s*)[^;{}"'\s]+(?:\s+[^;{}"'\s]+)*(?=\s*[;{])/,
      lookbehind: !0,
      greedy: !0,
      inside: a.languages.extend("cpp", {})
    }
  }), a.languages.insertBefore("inside", "double-colon", {
    // All untokenized words that are not namespaces should be class names
    "class-name": /\b[a-z_]\w*\b(?!\s*::)/i
  }, a.languages.cpp["base-clause"]);
})(Prism);
Prism.languages.json = {
  property: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?=\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?!\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  comment: {
    pattern: /\/\/.*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  number: /-?\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b/i,
  punctuation: /[{}[\],]/,
  operator: /:/,
  boolean: /\b(?:false|true)\b/,
  null: {
    pattern: /\bnull\b/,
    alias: "keyword"
  }
};
Prism.languages.webmanifest = Prism.languages.json;
Prism.languages.sql = {
  comment: {
    pattern: /(^|[^\\])(?:\/\*[\s\S]*?\*\/|(?:--|\/\/|#).*)/,
    lookbehind: !0
  },
  variable: [
    {
      pattern: /@(["'`])(?:\\[\s\S]|(?!\1)[^\\])+\1/,
      greedy: !0
    },
    /@[\w.$]+/
  ],
  string: {
    pattern: /(^|[^@\\])("|')(?:\\[\s\S]|(?!\2)[^\\]|\2\2)*\2/,
    greedy: !0,
    lookbehind: !0
  },
  identifier: {
    pattern: /(^|[^@\\])`(?:\\[\s\S]|[^`\\]|``)*`/,
    greedy: !0,
    lookbehind: !0,
    inside: {
      punctuation: /^`|`$/
    }
  },
  function: /\b(?:AVG|COUNT|FIRST|FORMAT|LAST|LCASE|LEN|MAX|MID|MIN|MOD|NOW|ROUND|SUM|UCASE)(?=\s*\()/i,
  // Should we highlight user defined functions too?
  keyword: /\b(?:ACTION|ADD|AFTER|ALGORITHM|ALL|ALTER|ANALYZE|ANY|APPLY|AS|ASC|AUTHORIZATION|AUTO_INCREMENT|BACKUP|BDB|BEGIN|BERKELEYDB|BIGINT|BINARY|BIT|BLOB|BOOL|BOOLEAN|BREAK|BROWSE|BTREE|BULK|BY|CALL|CASCADED?|CASE|CHAIN|CHAR(?:ACTER|SET)?|CHECK(?:POINT)?|CLOSE|CLUSTERED|COALESCE|COLLATE|COLUMNS?|COMMENT|COMMIT(?:TED)?|COMPUTE|CONNECT|CONSISTENT|CONSTRAINT|CONTAINS(?:TABLE)?|CONTINUE|CONVERT|CREATE|CROSS|CURRENT(?:_DATE|_TIME|_TIMESTAMP|_USER)?|CURSOR|CYCLE|DATA(?:BASES?)?|DATE(?:TIME)?|DAY|DBCC|DEALLOCATE|DEC|DECIMAL|DECLARE|DEFAULT|DEFINER|DELAYED|DELETE|DELIMITERS?|DENY|DESC|DESCRIBE|DETERMINISTIC|DISABLE|DISCARD|DISK|DISTINCT|DISTINCTROW|DISTRIBUTED|DO|DOUBLE|DROP|DUMMY|DUMP(?:FILE)?|DUPLICATE|ELSE(?:IF)?|ENABLE|ENCLOSED|END|ENGINE|ENUM|ERRLVL|ERRORS|ESCAPED?|EXCEPT|EXEC(?:UTE)?|EXISTS|EXIT|EXPLAIN|EXTENDED|FETCH|FIELDS|FILE|FILLFACTOR|FIRST|FIXED|FLOAT|FOLLOWING|FOR(?: EACH ROW)?|FORCE|FOREIGN|FREETEXT(?:TABLE)?|FROM|FULL|FUNCTION|GEOMETRY(?:COLLECTION)?|GLOBAL|GOTO|GRANT|GROUP|HANDLER|HASH|HAVING|HOLDLOCK|HOUR|IDENTITY(?:COL|_INSERT)?|IF|IGNORE|IMPORT|INDEX|INFILE|INNER|INNODB|INOUT|INSERT|INT|INTEGER|INTERSECT|INTERVAL|INTO|INVOKER|ISOLATION|ITERATE|JOIN|KEYS?|KILL|LANGUAGE|LAST|LEAVE|LEFT|LEVEL|LIMIT|LINENO|LINES|LINESTRING|LOAD|LOCAL|LOCK|LONG(?:BLOB|TEXT)|LOOP|MATCH(?:ED)?|MEDIUM(?:BLOB|INT|TEXT)|MERGE|MIDDLEINT|MINUTE|MODE|MODIFIES|MODIFY|MONTH|MULTI(?:LINESTRING|POINT|POLYGON)|NATIONAL|NATURAL|NCHAR|NEXT|NO|NONCLUSTERED|NULLIF|NUMERIC|OFF?|OFFSETS?|ON|OPEN(?:DATASOURCE|QUERY|ROWSET)?|OPTIMIZE|OPTION(?:ALLY)?|ORDER|OUT(?:ER|FILE)?|OVER|PARTIAL|PARTITION|PERCENT|PIVOT|PLAN|POINT|POLYGON|PRECEDING|PRECISION|PREPARE|PREV|PRIMARY|PRINT|PRIVILEGES|PROC(?:EDURE)?|PUBLIC|PURGE|QUICK|RAISERROR|READS?|REAL|RECONFIGURE|REFERENCES|RELEASE|RENAME|REPEAT(?:ABLE)?|REPLACE|REPLICATION|REQUIRE|RESIGNAL|RESTORE|RESTRICT|RETURN(?:ING|S)?|REVOKE|RIGHT|ROLLBACK|ROUTINE|ROW(?:COUNT|GUIDCOL|S)?|RTREE|RULE|SAVE(?:POINT)?|SCHEMA|SECOND|SELECT|SERIAL(?:IZABLE)?|SESSION(?:_USER)?|SET(?:USER)?|SHARE|SHOW|SHUTDOWN|SIMPLE|SMALLINT|SNAPSHOT|SOME|SONAME|SQL|START(?:ING)?|STATISTICS|STATUS|STRIPED|SYSTEM_USER|TABLES?|TABLESPACE|TEMP(?:ORARY|TABLE)?|TERMINATED|TEXT(?:SIZE)?|THEN|TIME(?:STAMP)?|TINY(?:BLOB|INT|TEXT)|TOP?|TRAN(?:SACTIONS?)?|TRIGGER|TRUNCATE|TSEQUAL|TYPES?|UNBOUNDED|UNCOMMITTED|UNDEFINED|UNION|UNIQUE|UNLOCK|UNPIVOT|UNSIGNED|UPDATE(?:TEXT)?|USAGE|USE|USER|USING|VALUES?|VAR(?:BINARY|CHAR|CHARACTER|YING)|VIEW|WAITFOR|WARNINGS|WHEN|WHERE|WHILE|WITH(?: ROLLUP|IN)?|WORK|WRITE(?:TEXT)?|YEAR)\b/i,
  boolean: /\b(?:FALSE|NULL|TRUE)\b/i,
  number: /\b0x[\da-f]+\b|\b\d+(?:\.\d*)?|\B\.\d+\b/i,
  operator: /[-+*\/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?|\b(?:AND|BETWEEN|DIV|ILIKE|IN|IS|LIKE|NOT|OR|REGEXP|RLIKE|SOUNDS LIKE|XOR)\b/i,
  punctuation: /[;[\]()`,.]/
};
(function(a) {
  var e = /\b(?:abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|exports|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|module|native|new|non-sealed|null|open|opens|package|permits|private|protected|provides|public|record(?!\s*[(){}[\]<>=%~.:,;?+\-*/&|^])|requires|return|sealed|short|static|strictfp|super|switch|synchronized|this|throw|throws|to|transient|transitive|try|uses|var|void|volatile|while|with|yield)\b/, t = /(?:[a-z]\w*\s*\.\s*)*(?:[A-Z]\w*\s*\.\s*)*/.source, n = {
    pattern: RegExp(/(^|[^\w.])/.source + t + /[A-Z](?:[\d_A-Z]*[a-z]\w*)?\b/.source),
    lookbehind: !0,
    inside: {
      namespace: {
        pattern: /^[a-z]\w*(?:\s*\.\s*[a-z]\w*)*(?:\s*\.)?/,
        inside: {
          punctuation: /\./
        }
      },
      punctuation: /\./
    }
  };
  a.languages.java = a.languages.extend("clike", {
    string: {
      pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"/,
      lookbehind: !0,
      greedy: !0
    },
    "class-name": [
      n,
      {
        // variables, parameters, and constructor references
        // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
        pattern: RegExp(/(^|[^\w.])/.source + t + /[A-Z]\w*(?=\s+\w+\s*[;,=()]|\s*(?:\[[\s,]*\]\s*)?::\s*new\b)/.source),
        lookbehind: !0,
        inside: n.inside
      },
      {
        // class names based on keyword
        // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
        pattern: RegExp(/(\b(?:class|enum|extends|implements|instanceof|interface|new|record|throws)\s+)/.source + t + /[A-Z]\w*\b/.source),
        lookbehind: !0,
        inside: n.inside
      }
    ],
    keyword: e,
    function: [
      a.languages.clike.function,
      {
        pattern: /(::\s*)[a-z_]\w*/,
        lookbehind: !0
      }
    ],
    number: /\b0b[01][01_]*L?\b|\b0x(?:\.[\da-f_p+-]+|[\da-f_]+(?:\.[\da-f_p+-]+)?)\b|(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?\d[\d_]*)?[dfl]?/i,
    operator: {
      pattern: /(^|[^.])(?:<<=?|>>>?=?|->|--|\+\+|&&|\|\||::|[?:~]|[-+*/%&|^!=<>]=?)/m,
      lookbehind: !0
    },
    constant: /\b[A-Z][A-Z_\d]+\b/
  }), a.languages.insertBefore("java", "string", {
    "triple-quoted-string": {
      // http://openjdk.java.net/jeps/355#Description
      pattern: /"""[ \t]*[\r\n](?:(?:"|"")?(?:\\.|[^"\\]))*"""/,
      greedy: !0,
      alias: "string"
    },
    char: {
      pattern: /'(?:\\.|[^'\\\r\n]){1,6}'/,
      greedy: !0
    }
  }), a.languages.insertBefore("java", "class-name", {
    annotation: {
      pattern: /(^|[^.])@\w+(?:\s*\.\s*\w+)*/,
      lookbehind: !0,
      alias: "punctuation"
    },
    generics: {
      pattern: /<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&))*>)*>)*>)*>/,
      inside: {
        "class-name": n,
        keyword: e,
        punctuation: /[<>(),.:]/,
        operator: /[?&|]/
      }
    },
    import: [
      {
        pattern: RegExp(/(\bimport\s+)/.source + t + /(?:[A-Z]\w*|\*)(?=\s*;)/.source),
        lookbehind: !0,
        inside: {
          namespace: n.inside.namespace,
          punctuation: /\./,
          operator: /\*/,
          "class-name": /\w+/
        }
      },
      {
        pattern: RegExp(/(\bimport\s+static\s+)/.source + t + /(?:\w+|\*)(?=\s*;)/.source),
        lookbehind: !0,
        alias: "static",
        inside: {
          namespace: n.inside.namespace,
          static: /\b\w+$/,
          punctuation: /\./,
          operator: /\*/,
          "class-name": /\w+/
        }
      }
    ],
    namespace: {
      pattern: RegExp(
        /(\b(?:exports|import(?:\s+static)?|module|open|opens|package|provides|requires|to|transitive|uses|with)\s+)(?!<keyword>)[a-z]\w*(?:\.[a-z]\w*)*\.?/.source.replace(/<keyword>/g, function() {
          return e.source;
        })
      ),
      lookbehind: !0,
      inside: {
        punctuation: /\./
      }
    }
  });
})(Prism);
Prism.languages.go = Prism.languages.extend("clike", {
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"|`[^`]*`/,
    lookbehind: !0,
    greedy: !0
  },
  keyword: /\b(?:break|case|chan|const|continue|default|defer|else|fallthrough|for|func|go(?:to)?|if|import|interface|map|package|range|return|select|struct|switch|type|var)\b/,
  boolean: /\b(?:_|false|iota|nil|true)\b/,
  number: [
    // binary and octal integers
    /\b0(?:b[01_]+|o[0-7_]+)i?\b/i,
    // hexadecimal integers and floats
    /\b0x(?:[a-f\d_]+(?:\.[a-f\d_]*)?|\.[a-f\d_]+)(?:p[+-]?\d+(?:_\d+)*)?i?(?!\w)/i,
    // decimal integers and floats
    /(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?[\d_]+)?i?(?!\w)/i
  ],
  operator: /[*\/%^!=]=?|\+[=+]?|-[=-]?|\|[=|]?|&(?:=|&|\^=?)?|>(?:>=?|=)?|<(?:<=?|=|-)?|:=|\.\.\./,
  builtin: /\b(?:append|bool|byte|cap|close|complex|complex(?:64|128)|copy|delete|error|float(?:32|64)|u?int(?:8|16|32|64)?|imag|len|make|new|panic|print(?:ln)?|real|recover|rune|string|uintptr)\b/
});
Prism.languages.insertBefore("go", "string", {
  char: {
    pattern: /'(?:\\.|[^'\\\r\n]){0,10}'/,
    greedy: !0
  }
});
delete Prism.languages.go["class-name"];
(function(a) {
  for (var e = /\/\*(?:[^*/]|\*(?!\/)|\/(?!\*)|<self>)*\*\//.source, t = 0; t < 2; t++)
    e = e.replace(/<self>/g, function() {
      return e;
    });
  e = e.replace(/<self>/g, function() {
    return /[^\s\S]/.source;
  }), a.languages.rust = {
    comment: [
      {
        pattern: RegExp(/(^|[^\\])/.source + e),
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /b?"(?:\\[\s\S]|[^\\"])*"|b?r(#*)"(?:[^"]|"(?!\1))*"\1/,
      greedy: !0
    },
    char: {
      pattern: /b?'(?:\\(?:x[0-7][\da-fA-F]|u\{(?:[\da-fA-F]_*){1,6}\}|.)|[^\\\r\n\t'])'/,
      greedy: !0
    },
    attribute: {
      pattern: /#!?\[(?:[^\[\]"]|"(?:\\[\s\S]|[^\\"])*")*\]/,
      greedy: !0,
      alias: "attr-name",
      inside: {
        string: null
        // see below
      }
    },
    // Closure params should not be confused with bitwise OR |
    "closure-params": {
      pattern: /([=(,:]\s*|\bmove\s*)\|[^|]*\||\|[^|]*\|(?=\s*(?:\{|->))/,
      lookbehind: !0,
      greedy: !0,
      inside: {
        "closure-punctuation": {
          pattern: /^\||\|$/,
          alias: "punctuation"
        },
        rest: null
        // see below
      }
    },
    "lifetime-annotation": {
      pattern: /'\w+/,
      alias: "symbol"
    },
    "fragment-specifier": {
      pattern: /(\$\w+:)[a-z]+/,
      lookbehind: !0,
      alias: "punctuation"
    },
    variable: /\$\w+/,
    "function-definition": {
      pattern: /(\bfn\s+)\w+/,
      lookbehind: !0,
      alias: "function"
    },
    "type-definition": {
      pattern: /(\b(?:enum|struct|trait|type|union)\s+)\w+/,
      lookbehind: !0,
      alias: "class-name"
    },
    "module-declaration": [
      {
        pattern: /(\b(?:crate|mod)\s+)[a-z][a-z_\d]*/,
        lookbehind: !0,
        alias: "namespace"
      },
      {
        pattern: /(\b(?:crate|self|super)\s*)::\s*[a-z][a-z_\d]*\b(?:\s*::(?:\s*[a-z][a-z_\d]*\s*::)*)?/,
        lookbehind: !0,
        alias: "namespace",
        inside: {
          punctuation: /::/
        }
      }
    ],
    keyword: [
      // https://github.com/rust-lang/reference/blob/master/src/keywords.md
      /\b(?:Self|abstract|as|async|await|become|box|break|const|continue|crate|do|dyn|else|enum|extern|final|fn|for|if|impl|in|let|loop|macro|match|mod|move|mut|override|priv|pub|ref|return|self|static|struct|super|trait|try|type|typeof|union|unsafe|unsized|use|virtual|where|while|yield)\b/,
      // primitives and str
      // https://doc.rust-lang.org/stable/rust-by-example/primitives.html
      /\b(?:bool|char|f(?:32|64)|[ui](?:8|16|32|64|128|size)|str)\b/
    ],
    // functions can technically start with an upper-case letter, but this will introduce a lot of false positives
    // and Rust's naming conventions recommend snake_case anyway.
    // https://doc.rust-lang.org/1.0.0/style/style/naming/README.html
    function: /\b[a-z_]\w*(?=\s*(?:::\s*<|\())/,
    macro: {
      pattern: /\b\w+!/,
      alias: "property"
    },
    constant: /\b[A-Z_][A-Z_\d]+\b/,
    "class-name": /\b[A-Z]\w*\b/,
    namespace: {
      pattern: /(?:\b[a-z][a-z_\d]*\s*::\s*)*\b[a-z][a-z_\d]*\s*::(?!\s*<)/,
      inside: {
        punctuation: /::/
      }
    },
    // Hex, oct, bin, dec numbers with visual separators and type suffix
    number: /\b(?:0x[\dA-Fa-f](?:_?[\dA-Fa-f])*|0o[0-7](?:_?[0-7])*|0b[01](?:_?[01])*|(?:(?:\d(?:_?\d)*)?\.)?\d(?:_?\d)*(?:[Ee][+-]?\d+)?)(?:_?(?:f32|f64|[iu](?:8|16|32|64|size)?))?\b/,
    boolean: /\b(?:false|true)\b/,
    punctuation: /->|\.\.=|\.{1,3}|::|[{}[\];(),:]/,
    operator: /[-+*\/%!^]=?|=[=>]?|&[&=]?|\|[|=]?|<<?=?|>>?=?|[@?]/
  }, a.languages.rust["closure-params"].inside.rest = a.languages.rust, a.languages.rust.attribute.inside.string = a.languages.rust.string;
})(Prism);
(function(a) {
  var e = /\/\*[\s\S]*?\*\/|\/\/.*|#(?!\[).*/, t = [
    {
      pattern: /\b(?:false|true)\b/i,
      alias: "boolean"
    },
    {
      pattern: /(::\s*)\b[a-z_]\w*\b(?!\s*\()/i,
      greedy: !0,
      lookbehind: !0
    },
    {
      pattern: /(\b(?:case|const)\s+)\b[a-z_]\w*(?=\s*[;=])/i,
      greedy: !0,
      lookbehind: !0
    },
    /\b(?:null)\b/i,
    /\b[A-Z_][A-Z0-9_]*\b(?!\s*\()/
  ], n = /\b0b[01]+(?:_[01]+)*\b|\b0o[0-7]+(?:_[0-7]+)*\b|\b0x[\da-f]+(?:_[\da-f]+)*\b|(?:\b\d+(?:_\d+)*\.?(?:\d+(?:_\d+)*)?|\B\.\d+)(?:e[+-]?\d+)?/i, i = /<?=>|\?\?=?|\.{3}|\??->|[!=]=?=?|::|\*\*=?|--|\+\+|&&|\|\||<<|>>|[?~]|[/^|%*&<>.+-]=?/, r = /[{}\[\](),:;]/;
  a.languages.php = {
    delimiter: {
      pattern: /\?>$|^<\?(?:php(?=\s)|=)?/i,
      alias: "important"
    },
    comment: e,
    variable: /\$+(?:\w+\b|(?=\{))/,
    package: {
      pattern: /(namespace\s+|use\s+(?:function\s+)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
      lookbehind: !0,
      inside: {
        punctuation: /\\/
      }
    },
    "class-name-definition": {
      pattern: /(\b(?:class|enum|interface|trait)\s+)\b[a-z_]\w*(?!\\)\b/i,
      lookbehind: !0,
      alias: "class-name"
    },
    "function-definition": {
      pattern: /(\bfunction\s+)[a-z_]\w*(?=\s*\()/i,
      lookbehind: !0,
      alias: "function"
    },
    keyword: [
      {
        pattern: /(\(\s*)\b(?:array|bool|boolean|float|int|integer|object|string)\b(?=\s*\))/i,
        alias: "type-casting",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /([(,?]\s*)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|object|self|static|string)\b(?=\s*\$)/i,
        alias: "type-hint",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|never|object|self|static|string|void)\b/i,
        alias: "return-type",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b(?:array(?!\s*\()|bool|float|int|iterable|mixed|object|string|void)\b/i,
        alias: "type-declaration",
        greedy: !0
      },
      {
        pattern: /(\|\s*)(?:false|null)\b|\b(?:false|null)(?=\s*\|)/i,
        alias: "type-declaration",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b(?:parent|self|static)(?=\s*::)/i,
        alias: "static-context",
        greedy: !0
      },
      {
        // yield from
        pattern: /(\byield\s+)from\b/i,
        lookbehind: !0
      },
      // `class` is always a keyword unlike other keywords
      /\bclass\b/i,
      {
        // https://www.php.net/manual/en/reserved.keywords.php
        //
        // keywords cannot be preceded by "->"
        // the complex lookbehind means `(?<!(?:->|::)\s*)`
        pattern: /((?:^|[^\s>:]|(?:^|[^-])>|(?:^|[^:]):)\s*)\b(?:abstract|and|array|as|break|callable|case|catch|clone|const|continue|declare|default|die|do|echo|else|elseif|empty|enddeclare|endfor|endforeach|endif|endswitch|endwhile|enum|eval|exit|extends|final|finally|fn|for|foreach|function|global|goto|if|implements|include|include_once|instanceof|insteadof|interface|isset|list|match|namespace|never|new|or|parent|print|private|protected|public|readonly|require|require_once|return|self|static|switch|throw|trait|try|unset|use|var|while|xor|yield|__halt_compiler)\b/i,
        lookbehind: !0
      }
    ],
    "argument-name": {
      pattern: /([(,]\s*)\b[a-z_]\w*(?=\s*:(?!:))/i,
      lookbehind: !0
    },
    "class-name": [
      {
        pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self|\s+static))\s+|\bcatch\s*\()\b[a-z_]\w*(?!\\)\b/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\|\s*)\b[a-z_]\w*(?!\\)\b/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b[a-z_]\w*(?!\\)\b(?=\s*\|)/i,
        greedy: !0
      },
      {
        pattern: /(\|\s*)(?:\\?\b[a-z_]\w*)+\b/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+\b(?=\s*\|)/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self\b|\s+static\b))\s+|\bcatch\s*\()(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /\b[a-z_]\w*(?=\s*\$)/i,
        alias: "type-declaration",
        greedy: !0
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
        alias: ["class-name-fully-qualified", "type-declaration"],
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /\b[a-z_]\w*(?=\s*::)/i,
        alias: "static-context",
        greedy: !0
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*::)/i,
        alias: ["class-name-fully-qualified", "static-context"],
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /([(,?]\s*)[a-z_]\w*(?=\s*\$)/i,
        alias: "type-hint",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /([(,?]\s*)(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
        alias: ["class-name-fully-qualified", "type-hint"],
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)\b[a-z_]\w*(?!\\)\b/i,
        alias: "return-type",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        alias: ["class-name-fully-qualified", "return-type"],
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      }
    ],
    constant: t,
    function: {
      pattern: /(^|[^\\\w])\\?[a-z_](?:[\w\\]*\w)?(?=\s*\()/i,
      lookbehind: !0,
      inside: {
        punctuation: /\\/
      }
    },
    property: {
      pattern: /(->\s*)\w+/,
      lookbehind: !0
    },
    number: n,
    operator: i,
    punctuation: r
  };
  var l = {
    pattern: /\{\$(?:\{(?:\{[^{}]+\}|[^{}]+)\}|[^{}])+\}|(^|[^\\{])\$+(?:\w+(?:\[[^\r\n\[\]]+\]|->\w+)?)/,
    lookbehind: !0,
    inside: a.languages.php
  }, o = [
    {
      pattern: /<<<'([^']+)'[\r\n](?:.*[\r\n])*?\1;/,
      alias: "nowdoc-string",
      greedy: !0,
      inside: {
        delimiter: {
          pattern: /^<<<'[^']+'|[a-z_]\w*;$/i,
          alias: "symbol",
          inside: {
            punctuation: /^<<<'?|[';]$/
          }
        }
      }
    },
    {
      pattern: /<<<(?:"([^"]+)"[\r\n](?:.*[\r\n])*?\1;|([a-z_]\w*)[\r\n](?:.*[\r\n])*?\2;)/i,
      alias: "heredoc-string",
      greedy: !0,
      inside: {
        delimiter: {
          pattern: /^<<<(?:"[^"]+"|[a-z_]\w*)|[a-z_]\w*;$/i,
          alias: "symbol",
          inside: {
            punctuation: /^<<<"?|[";]$/
          }
        },
        interpolation: l
      }
    },
    {
      pattern: /`(?:\\[\s\S]|[^\\`])*`/,
      alias: "backtick-quoted-string",
      greedy: !0
    },
    {
      pattern: /'(?:\\[\s\S]|[^\\'])*'/,
      alias: "single-quoted-string",
      greedy: !0
    },
    {
      pattern: /"(?:\\[\s\S]|[^\\"])*"/,
      alias: "double-quoted-string",
      greedy: !0,
      inside: {
        interpolation: l
      }
    }
  ];
  a.languages.insertBefore("php", "variable", {
    string: o,
    attribute: {
      pattern: /#\[(?:[^"'\/#]|\/(?![*/])|\/\/.*$|#(?!\[).*$|\/\*(?:[^*]|\*(?!\/))*\*\/|"(?:\\[\s\S]|[^\\"])*"|'(?:\\[\s\S]|[^\\'])*')+\](?=\s*[a-z$#])/im,
      greedy: !0,
      inside: {
        "attribute-content": {
          pattern: /^(#\[)[\s\S]+(?=\]$)/,
          lookbehind: !0,
          // inside can appear subset of php
          inside: {
            comment: e,
            string: o,
            "attribute-class-name": [
              {
                pattern: /([^:]|^)\b[a-z_]\w*(?!\\)\b/i,
                alias: "class-name",
                greedy: !0,
                lookbehind: !0
              },
              {
                pattern: /([^:]|^)(?:\\?\b[a-z_]\w*)+/i,
                alias: [
                  "class-name",
                  "class-name-fully-qualified"
                ],
                greedy: !0,
                lookbehind: !0,
                inside: {
                  punctuation: /\\/
                }
              }
            ],
            constant: t,
            number: n,
            operator: i,
            punctuation: r
          }
        },
        delimiter: {
          pattern: /^#\[|\]$/,
          alias: "punctuation"
        }
      }
    }
  }), a.hooks.add("before-tokenize", function(s) {
    if (/<\?/.test(s.code)) {
      var c = /<\?(?:[^"'/#]|\/(?![*/])|("|')(?:\\[\s\S]|(?!\1)[^\\])*\1|(?:\/\/|#(?!\[))(?:[^?\n\r]|\?(?!>))*(?=$|\?>|[\r\n])|#\[|\/\*(?:[^*]|\*(?!\/))*(?:\*\/|$))*?(?:\?>|$)/g;
      a.languages["markup-templating"].buildPlaceholders(s, "php", c);
    }
  }), a.hooks.add("after-tokenize", function(s) {
    a.languages["markup-templating"].tokenizePlaceholders(s, "php");
  });
})(Prism);
(function(a) {
  var e = /[*&][^\s[\]{},]+/, t = /!(?:<[\w\-%#;/?:@&=+$,.!~*'()[\]]+>|(?:[a-zA-Z\d-]*!)?[\w\-%#;/?:@&=+$.~*'()]+)?/, n = "(?:" + t.source + "(?:[ 	]+" + e.source + ")?|" + e.source + "(?:[ 	]+" + t.source + ")?)", i = /(?:[^\s\x00-\x08\x0e-\x1f!"#%&'*,\-:>?@[\]`{|}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]|[?:-]<PLAIN>)(?:[ \t]*(?:(?![#:])<PLAIN>|:<PLAIN>))*/.source.replace(/<PLAIN>/g, function() {
    return /[^\s\x00-\x08\x0e-\x1f,[\]{}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]/.source;
  }), r = /"(?:[^"\\\r\n]|\\.)*"|'(?:[^'\\\r\n]|\\.)*'/.source;
  function l(o, s) {
    s = (s || "").replace(/m/g, "") + "m";
    var c = /([:\-,[{]\s*(?:\s<<prop>>[ \t]+)?)(?:<<value>>)(?=[ \t]*(?:$|,|\]|\}|(?:[\r\n]\s*)?#))/.source.replace(/<<prop>>/g, function() {
      return n;
    }).replace(/<<value>>/g, function() {
      return o;
    });
    return RegExp(c, s);
  }
  a.languages.yaml = {
    scalar: {
      pattern: RegExp(/([\-:]\s*(?:\s<<prop>>[ \t]+)?[|>])[ \t]*(?:((?:\r?\n|\r)[ \t]+)\S[^\r\n]*(?:\2[^\r\n]+)*)/.source.replace(/<<prop>>/g, function() {
        return n;
      })),
      lookbehind: !0,
      alias: "string"
    },
    comment: /#.*/,
    key: {
      pattern: RegExp(/((?:^|[:\-,[{\r\n?])[ \t]*(?:<<prop>>[ \t]+)?)<<key>>(?=\s*:\s)/.source.replace(/<<prop>>/g, function() {
        return n;
      }).replace(/<<key>>/g, function() {
        return "(?:" + i + "|" + r + ")";
      })),
      lookbehind: !0,
      greedy: !0,
      alias: "atrule"
    },
    directive: {
      pattern: /(^[ \t]*)%.+/m,
      lookbehind: !0,
      alias: "important"
    },
    datetime: {
      pattern: l(/\d{4}-\d\d?-\d\d?(?:[tT]|[ \t]+)\d\d?:\d{2}:\d{2}(?:\.\d*)?(?:[ \t]*(?:Z|[-+]\d\d?(?::\d{2})?))?|\d{4}-\d{2}-\d{2}|\d\d?:\d{2}(?::\d{2}(?:\.\d*)?)?/.source),
      lookbehind: !0,
      alias: "number"
    },
    boolean: {
      pattern: l(/false|true/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    null: {
      pattern: l(/null|~/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    string: {
      pattern: l(r),
      lookbehind: !0,
      greedy: !0
    },
    number: {
      pattern: l(/[+-]?(?:0x[\da-f]+|0o[0-7]+|(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|\.inf|\.nan)/.source, "i"),
      lookbehind: !0
    },
    tag: t,
    important: e,
    punctuation: /---|[:[\]{}\-,|>?]|\.\.\./
  }, a.languages.yml = a.languages.yaml;
})(Prism);
(function(a) {
  function e(t, n) {
    return "___" + t.toUpperCase() + n + "___";
  }
  Object.defineProperties(a.languages["markup-templating"] = {}, {
    buildPlaceholders: {
      /**
       * Tokenize all inline templating expressions matching `placeholderPattern`.
       *
       * If `replaceFilter` is provided, only matches of `placeholderPattern` for which `replaceFilter` returns
       * `true` will be replaced.
       *
       * @param {object} env The environment of the `before-tokenize` hook.
       * @param {string} language The language id.
       * @param {RegExp} placeholderPattern The matches of this pattern will be replaced by placeholders.
       * @param {(match: string) => boolean} [replaceFilter]
       */
      value: function(t, n, i, r) {
        if (t.language === n) {
          var l = t.tokenStack = [];
          t.code = t.code.replace(i, function(o) {
            if (typeof r == "function" && !r(o))
              return o;
            for (var s = l.length, c; t.code.indexOf(c = e(n, s)) !== -1; )
              ++s;
            return l[s] = o, c;
          }), t.grammar = a.languages.markup;
        }
      }
    },
    tokenizePlaceholders: {
      /**
       * Replace placeholders with proper tokens after tokenizing.
       *
       * @param {object} env The environment of the `after-tokenize` hook.
       * @param {string} language The language id.
       */
      value: function(t, n) {
        if (t.language !== n || !t.tokenStack)
          return;
        t.grammar = a.languages[n];
        var i = 0, r = Object.keys(t.tokenStack);
        function l(o) {
          for (var s = 0; s < o.length && !(i >= r.length); s++) {
            var c = o[s];
            if (typeof c == "string" || c.content && typeof c.content == "string") {
              var u = r[i], _ = t.tokenStack[u], d = typeof c == "string" ? c : c.content, m = e(n, u), b = d.indexOf(m);
              if (b > -1) {
                ++i;
                var v = d.substring(0, b), y = new a.Token(n, a.tokenize(_, t.grammar), "language-" + n, _), w = d.substring(b + m.length), f = [];
                v && f.push.apply(f, l([v])), f.push(y), w && f.push.apply(f, l([w])), typeof c == "string" ? o.splice.apply(o, [s, 1].concat(f)) : c.content = f;
              }
            } else c.content && l(c.content);
          }
          return o;
        }
        l(t.tokens);
      }
    }
  });
})(Prism);
new Fi();
const hl = (a) => {
  const e = {};
  for (let t = 0, n = a.length; t < n; t++) {
    const i = a[t];
    for (const r in i)
      e[r] ? e[r] = e[r].concat(i[r]) : e[r] = i[r];
  }
  return e;
}, ml = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], gl = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], bl = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
hl([
  Object.fromEntries(ml.map((a) => [a, ["*"]])),
  Object.fromEntries(gl.map((a) => [a, ["svg:*"]])),
  Object.fromEntries(bl.map((a) => [a, ["math:*"]]))
]);
const {
  HtmlTagHydration: eo,
  SvelteComponent: to,
  attr: no,
  binding_callbacks: io,
  children: ao,
  claim_element: lo,
  claim_html_tag: ro,
  detach: oo,
  element: so,
  init: uo,
  insert_hydration: co,
  noop: _o,
  safe_not_equal: po,
  toggle_class: fo
} = window.__gradio__svelte__internal, { afterUpdate: ho, tick: mo, onMount: go } = window.__gradio__svelte__internal, {
  SvelteComponent: bo,
  attr: vo,
  children: Do,
  claim_component: yo,
  claim_element: wo,
  create_component: $o,
  destroy_component: Fo,
  detach: Eo,
  element: ko,
  init: Co,
  insert_hydration: Ao,
  mount_component: So,
  safe_not_equal: To,
  transition_in: Bo,
  transition_out: xo
} = window.__gradio__svelte__internal, {
  SvelteComponent: Io,
  attr: Ro,
  check_outros: qo,
  children: Lo,
  claim_component: No,
  claim_element: Oo,
  claim_space: zo,
  create_component: Po,
  create_slot: Mo,
  destroy_component: Uo,
  detach: Ho,
  element: Go,
  empty: jo,
  get_all_dirty_from_scope: Zo,
  get_slot_changes: Vo,
  group_outros: Yo,
  init: Xo,
  insert_hydration: Wo,
  mount_component: Ko,
  safe_not_equal: Qo,
  space: Jo,
  toggle_class: es,
  transition_in: ts,
  transition_out: ns,
  update_slot_base: is
} = window.__gradio__svelte__internal, {
  SvelteComponent: vl,
  append_hydration: Et,
  attr: Re,
  children: Fn,
  claim_component: Dl,
  claim_element: En,
  claim_space: yl,
  claim_text: wl,
  create_component: $l,
  destroy_component: Fl,
  detach: kt,
  element: kn,
  init: El,
  insert_hydration: kl,
  mount_component: Cl,
  safe_not_equal: Al,
  set_data: Sl,
  space: Tl,
  text: Bl,
  toggle_class: Ee,
  transition_in: xl,
  transition_out: Il
} = window.__gradio__svelte__internal;
function Rl(a) {
  let e, t, n, i, r, l, o;
  return n = new /*Icon*/
  a[1]({}), {
    c() {
      e = kn("label"), t = kn("span"), $l(n.$$.fragment), i = Tl(), r = Bl(
        /*label*/
        a[0]
      ), this.h();
    },
    l(s) {
      e = En(s, "LABEL", {
        for: !0,
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var c = Fn(e);
      t = En(c, "SPAN", { class: !0 });
      var u = Fn(t);
      Dl(n.$$.fragment, u), u.forEach(kt), i = yl(c), r = wl(
        c,
        /*label*/
        a[0]
      ), c.forEach(kt), this.h();
    },
    h() {
      Re(t, "class", "svelte-igqdol"), Re(e, "for", ""), Re(e, "data-testid", "block-label"), Re(e, "dir", l = /*rtl*/
      a[5] ? "rtl" : "ltr"), Re(e, "class", "svelte-igqdol"), Ee(e, "hide", !/*show_label*/
      a[2]), Ee(e, "sr-only", !/*show_label*/
      a[2]), Ee(
        e,
        "float",
        /*float*/
        a[4]
      ), Ee(
        e,
        "hide-label",
        /*disable*/
        a[3]
      );
    },
    m(s, c) {
      kl(s, e, c), Et(e, t), Cl(n, t, null), Et(e, i), Et(e, r), o = !0;
    },
    p(s, [c]) {
      (!o || c & /*label*/
      1) && Sl(
        r,
        /*label*/
        s[0]
      ), (!o || c & /*rtl*/
      32 && l !== (l = /*rtl*/
      s[5] ? "rtl" : "ltr")) && Re(e, "dir", l), (!o || c & /*show_label*/
      4) && Ee(e, "hide", !/*show_label*/
      s[2]), (!o || c & /*show_label*/
      4) && Ee(e, "sr-only", !/*show_label*/
      s[2]), (!o || c & /*float*/
      16) && Ee(
        e,
        "float",
        /*float*/
        s[4]
      ), (!o || c & /*disable*/
      8) && Ee(
        e,
        "hide-label",
        /*disable*/
        s[3]
      );
    },
    i(s) {
      o || (xl(n.$$.fragment, s), o = !0);
    },
    o(s) {
      Il(n.$$.fragment, s), o = !1;
    },
    d(s) {
      s && kt(e), Fl(n);
    }
  };
}
function ql(a, e, t) {
  let { label: n = null } = e, { Icon: i } = e, { show_label: r = !0 } = e, { disable: l = !1 } = e, { float: o = !0 } = e, { rtl: s = !1 } = e;
  return a.$$set = (c) => {
    "label" in c && t(0, n = c.label), "Icon" in c && t(1, i = c.Icon), "show_label" in c && t(2, r = c.show_label), "disable" in c && t(3, l = c.disable), "float" in c && t(4, o = c.float), "rtl" in c && t(5, s = c.rtl);
  }, [n, i, r, l, o, s];
}
class Ll extends vl {
  constructor(e) {
    super(), El(this, e, ql, Rl, Al, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4,
      rtl: 5
    });
  }
}
const {
  SvelteComponent: as,
  assign: ls,
  children: rs,
  claim_element: os,
  compute_rest_props: ss,
  create_slot: us,
  detach: cs,
  element: _s,
  exclude_internal_props: ds,
  get_all_dirty_from_scope: ps,
  get_slot_changes: fs,
  get_spread_update: hs,
  init: ms,
  insert_hydration: gs,
  listen: bs,
  safe_not_equal: vs,
  set_attributes: Ds,
  set_style: ys,
  toggle_class: ws,
  transition_in: $s,
  transition_out: Fs,
  update_slot_base: Es
} = window.__gradio__svelte__internal, { createEventDispatcher: ks } = window.__gradio__svelte__internal, {
  SvelteComponent: Nl,
  append_hydration: ut,
  attr: $e,
  bubble: Ol,
  check_outros: zl,
  children: zt,
  claim_component: Pl,
  claim_element: Pt,
  claim_space: Cn,
  claim_text: Ml,
  construct_svelte_component: An,
  create_component: Sn,
  create_slot: Ul,
  destroy_component: Tn,
  detach: je,
  element: Mt,
  get_all_dirty_from_scope: Hl,
  get_slot_changes: Gl,
  group_outros: jl,
  init: Zl,
  insert_hydration: Ei,
  listen: Vl,
  mount_component: Bn,
  safe_not_equal: Yl,
  set_data: Xl,
  set_style: qe,
  space: xn,
  text: Wl,
  toggle_class: H,
  transition_in: Ct,
  transition_out: At,
  update_slot_base: Kl
} = window.__gradio__svelte__internal;
function In(a) {
  let e, t;
  return {
    c() {
      e = Mt("span"), t = Wl(
        /*label*/
        a[1]
      ), this.h();
    },
    l(n) {
      e = Pt(n, "SPAN", { class: !0 });
      var i = zt(e);
      t = Ml(
        i,
        /*label*/
        a[1]
      ), i.forEach(je), this.h();
    },
    h() {
      $e(e, "class", "svelte-y0enk4");
    },
    m(n, i) {
      Ei(n, e, i), ut(e, t);
    },
    p(n, i) {
      i & /*label*/
      2 && Xl(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && je(e);
    }
  };
}
function Ql(a) {
  let e, t, n, i, r, l, o, s, c = (
    /*show_label*/
    a[2] && In(a)
  );
  var u = (
    /*Icon*/
    a[0]
  );
  function _(b, v) {
    return {};
  }
  u && (i = An(u, _()));
  const d = (
    /*#slots*/
    a[15].default
  ), m = Ul(
    d,
    a,
    /*$$scope*/
    a[14],
    null
  );
  return {
    c() {
      e = Mt("button"), c && c.c(), t = xn(), n = Mt("div"), i && Sn(i.$$.fragment), r = xn(), m && m.c(), this.h();
    },
    l(b) {
      e = Pt(b, "BUTTON", {
        class: !0,
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0
      });
      var v = zt(e);
      c && c.l(v), t = Cn(v), n = Pt(v, "DIV", { class: !0 });
      var y = zt(n);
      i && Pl(i.$$.fragment, y), r = Cn(y), m && m.l(y), y.forEach(je), v.forEach(je), this.h();
    },
    h() {
      $e(n, "class", "svelte-y0enk4"), H(
        n,
        "x-small",
        /*size*/
        a[4] === "x-small"
      ), H(
        n,
        "small",
        /*size*/
        a[4] === "small"
      ), H(
        n,
        "large",
        /*size*/
        a[4] === "large"
      ), H(
        n,
        "medium",
        /*size*/
        a[4] === "medium"
      ), $e(e, "class", "icon-button svelte-y0enk4"), e.disabled = /*disabled*/
      a[7], $e(
        e,
        "aria-label",
        /*label*/
        a[1]
      ), $e(
        e,
        "aria-haspopup",
        /*hasPopup*/
        a[8]
      ), $e(
        e,
        "title",
        /*label*/
        a[1]
      ), H(
        e,
        "pending",
        /*pending*/
        a[3]
      ), H(
        e,
        "padded",
        /*padded*/
        a[5]
      ), H(
        e,
        "highlight",
        /*highlight*/
        a[6]
      ), H(
        e,
        "transparent",
        /*transparent*/
        a[9]
      ), qe(
        e,
        "--border-color",
        /*border*/
        a[11]
      ), qe(e, "color", !/*disabled*/
      a[7] && /*_color*/
      a[12] ? (
        /*_color*/
        a[12]
      ) : "var(--block-label-text-color)"), qe(e, "--bg-color", /*disabled*/
      a[7] ? "auto" : (
        /*background*/
        a[10]
      ));
    },
    m(b, v) {
      Ei(b, e, v), c && c.m(e, null), ut(e, t), ut(e, n), i && Bn(i, n, null), ut(n, r), m && m.m(n, null), l = !0, o || (s = Vl(
        e,
        "click",
        /*click_handler*/
        a[16]
      ), o = !0);
    },
    p(b, [v]) {
      if (/*show_label*/
      b[2] ? c ? c.p(b, v) : (c = In(b), c.c(), c.m(e, t)) : c && (c.d(1), c = null), v & /*Icon*/
      1 && u !== (u = /*Icon*/
      b[0])) {
        if (i) {
          jl();
          const y = i;
          At(y.$$.fragment, 1, 0, () => {
            Tn(y, 1);
          }), zl();
        }
        u ? (i = An(u, _()), Sn(i.$$.fragment), Ct(i.$$.fragment, 1), Bn(i, n, r)) : i = null;
      }
      m && m.p && (!l || v & /*$$scope*/
      16384) && Kl(
        m,
        d,
        b,
        /*$$scope*/
        b[14],
        l ? Gl(
          d,
          /*$$scope*/
          b[14],
          v,
          null
        ) : Hl(
          /*$$scope*/
          b[14]
        ),
        null
      ), (!l || v & /*size*/
      16) && H(
        n,
        "x-small",
        /*size*/
        b[4] === "x-small"
      ), (!l || v & /*size*/
      16) && H(
        n,
        "small",
        /*size*/
        b[4] === "small"
      ), (!l || v & /*size*/
      16) && H(
        n,
        "large",
        /*size*/
        b[4] === "large"
      ), (!l || v & /*size*/
      16) && H(
        n,
        "medium",
        /*size*/
        b[4] === "medium"
      ), (!l || v & /*disabled*/
      128) && (e.disabled = /*disabled*/
      b[7]), (!l || v & /*label*/
      2) && $e(
        e,
        "aria-label",
        /*label*/
        b[1]
      ), (!l || v & /*hasPopup*/
      256) && $e(
        e,
        "aria-haspopup",
        /*hasPopup*/
        b[8]
      ), (!l || v & /*label*/
      2) && $e(
        e,
        "title",
        /*label*/
        b[1]
      ), (!l || v & /*pending*/
      8) && H(
        e,
        "pending",
        /*pending*/
        b[3]
      ), (!l || v & /*padded*/
      32) && H(
        e,
        "padded",
        /*padded*/
        b[5]
      ), (!l || v & /*highlight*/
      64) && H(
        e,
        "highlight",
        /*highlight*/
        b[6]
      ), (!l || v & /*transparent*/
      512) && H(
        e,
        "transparent",
        /*transparent*/
        b[9]
      ), v & /*border*/
      2048 && qe(
        e,
        "--border-color",
        /*border*/
        b[11]
      ), v & /*disabled, _color*/
      4224 && qe(e, "color", !/*disabled*/
      b[7] && /*_color*/
      b[12] ? (
        /*_color*/
        b[12]
      ) : "var(--block-label-text-color)"), v & /*disabled, background*/
      1152 && qe(e, "--bg-color", /*disabled*/
      b[7] ? "auto" : (
        /*background*/
        b[10]
      ));
    },
    i(b) {
      l || (i && Ct(i.$$.fragment, b), Ct(m, b), l = !0);
    },
    o(b) {
      i && At(i.$$.fragment, b), At(m, b), l = !1;
    },
    d(b) {
      b && je(e), c && c.d(), i && Tn(i), m && m.d(b), o = !1, s();
    }
  };
}
function Jl(a, e, t) {
  let n, { $$slots: i = {}, $$scope: r } = e, { Icon: l } = e, { label: o = "" } = e, { show_label: s = !1 } = e, { pending: c = !1 } = e, { size: u = "small" } = e, { padded: _ = !0 } = e, { highlight: d = !1 } = e, { disabled: m = !1 } = e, { hasPopup: b = !1 } = e, { color: v = "var(--block-label-text-color)" } = e, { transparent: y = !1 } = e, { background: w = "var(--block-background-fill)" } = e, { border: f = "transparent" } = e;
  function p(h) {
    Ol.call(this, a, h);
  }
  return a.$$set = (h) => {
    "Icon" in h && t(0, l = h.Icon), "label" in h && t(1, o = h.label), "show_label" in h && t(2, s = h.show_label), "pending" in h && t(3, c = h.pending), "size" in h && t(4, u = h.size), "padded" in h && t(5, _ = h.padded), "highlight" in h && t(6, d = h.highlight), "disabled" in h && t(7, m = h.disabled), "hasPopup" in h && t(8, b = h.hasPopup), "color" in h && t(13, v = h.color), "transparent" in h && t(9, y = h.transparent), "background" in h && t(10, w = h.background), "border" in h && t(11, f = h.border), "$$scope" in h && t(14, r = h.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty & /*highlight, color*/
    8256 && t(12, n = d ? "var(--color-accent)" : v);
  }, [
    l,
    o,
    s,
    c,
    u,
    _,
    d,
    m,
    b,
    y,
    w,
    f,
    n,
    v,
    r,
    i,
    p
  ];
}
class ki extends Nl {
  constructor(e) {
    super(), Zl(this, e, Jl, Ql, Yl, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 13,
      transparent: 9,
      background: 10,
      border: 11
    });
  }
}
const {
  SvelteComponent: Cs,
  append_hydration: As,
  attr: Ss,
  binding_callbacks: Ts,
  children: Bs,
  claim_element: xs,
  create_slot: Is,
  detach: Rs,
  element: qs,
  get_all_dirty_from_scope: Ls,
  get_slot_changes: Ns,
  init: Os,
  insert_hydration: zs,
  safe_not_equal: Ps,
  toggle_class: Ms,
  transition_in: Us,
  transition_out: Hs,
  update_slot_base: Gs
} = window.__gradio__svelte__internal, {
  SvelteComponent: js,
  append_hydration: Zs,
  attr: Vs,
  children: Ys,
  claim_svg_element: Xs,
  detach: Ws,
  init: Ks,
  insert_hydration: Qs,
  noop: Js,
  safe_not_equal: eu,
  svg_element: tu
} = window.__gradio__svelte__internal, {
  SvelteComponent: nu,
  append_hydration: iu,
  attr: au,
  children: lu,
  claim_svg_element: ru,
  detach: ou,
  init: su,
  insert_hydration: uu,
  noop: cu,
  safe_not_equal: _u,
  svg_element: du
} = window.__gradio__svelte__internal, {
  SvelteComponent: pu,
  append_hydration: fu,
  attr: hu,
  children: mu,
  claim_svg_element: gu,
  detach: bu,
  init: vu,
  insert_hydration: Du,
  noop: yu,
  safe_not_equal: wu,
  svg_element: $u
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fu,
  append_hydration: Eu,
  attr: ku,
  children: Cu,
  claim_svg_element: Au,
  detach: Su,
  init: Tu,
  insert_hydration: Bu,
  noop: xu,
  safe_not_equal: Iu,
  svg_element: Ru
} = window.__gradio__svelte__internal, {
  SvelteComponent: qu,
  append_hydration: Lu,
  attr: Nu,
  children: Ou,
  claim_svg_element: zu,
  detach: Pu,
  init: Mu,
  insert_hydration: Uu,
  noop: Hu,
  safe_not_equal: Gu,
  svg_element: ju
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zu,
  append_hydration: Vu,
  attr: Yu,
  children: Xu,
  claim_svg_element: Wu,
  detach: Ku,
  init: Qu,
  insert_hydration: Ju,
  noop: ec,
  safe_not_equal: tc,
  svg_element: nc
} = window.__gradio__svelte__internal, {
  SvelteComponent: ic,
  append_hydration: ac,
  attr: lc,
  children: rc,
  claim_svg_element: oc,
  detach: sc,
  init: uc,
  insert_hydration: cc,
  noop: _c,
  safe_not_equal: dc,
  svg_element: pc
} = window.__gradio__svelte__internal, {
  SvelteComponent: fc,
  append_hydration: hc,
  attr: mc,
  children: gc,
  claim_svg_element: bc,
  detach: vc,
  init: Dc,
  insert_hydration: yc,
  noop: wc,
  safe_not_equal: $c,
  svg_element: Fc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ec,
  append_hydration: kc,
  attr: Cc,
  children: Ac,
  claim_svg_element: Sc,
  detach: Tc,
  init: Bc,
  insert_hydration: xc,
  noop: Ic,
  safe_not_equal: Rc,
  svg_element: qc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lc,
  append_hydration: Nc,
  attr: Oc,
  children: zc,
  claim_svg_element: Pc,
  detach: Mc,
  init: Uc,
  insert_hydration: Hc,
  noop: Gc,
  safe_not_equal: jc,
  svg_element: Zc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vc,
  append_hydration: Yc,
  attr: Xc,
  children: Wc,
  claim_svg_element: Kc,
  detach: Qc,
  init: Jc,
  insert_hydration: e_,
  noop: t_,
  safe_not_equal: n_,
  svg_element: i_
} = window.__gradio__svelte__internal, {
  SvelteComponent: a_,
  append_hydration: l_,
  attr: r_,
  children: o_,
  claim_svg_element: s_,
  detach: u_,
  init: c_,
  insert_hydration: __,
  noop: d_,
  safe_not_equal: p_,
  svg_element: f_
} = window.__gradio__svelte__internal, {
  SvelteComponent: er,
  append_hydration: St,
  attr: fe,
  children: et,
  claim_svg_element: tt,
  detach: Pe,
  init: tr,
  insert_hydration: nr,
  noop: Tt,
  safe_not_equal: ir,
  set_style: be,
  svg_element: nt
} = window.__gradio__svelte__internal;
function ar(a) {
  let e, t, n, i;
  return {
    c() {
      e = nt("svg"), t = nt("g"), n = nt("path"), i = nt("path"), this.h();
    },
    l(r) {
      e = tt(r, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = et(e);
      t = tt(l, "g", { transform: !0 });
      var o = et(t);
      n = tt(o, "path", { d: !0, style: !0 }), et(n).forEach(Pe), o.forEach(Pe), i = tt(l, "path", { d: !0, style: !0 }), et(i).forEach(Pe), l.forEach(Pe), this.h();
    },
    h() {
      fe(n, "d", "M18,6L6.087,17.913"), be(n, "fill", "none"), be(n, "fill-rule", "nonzero"), be(n, "stroke-width", "2px"), fe(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), fe(i, "d", "M4.364,4.364L19.636,19.636"), be(i, "fill", "none"), be(i, "fill-rule", "nonzero"), be(i, "stroke-width", "2px"), fe(e, "width", "100%"), fe(e, "height", "100%"), fe(e, "viewBox", "0 0 24 24"), fe(e, "version", "1.1"), fe(e, "xmlns", "http://www.w3.org/2000/svg"), fe(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), fe(e, "xml:space", "preserve"), fe(e, "stroke", "currentColor"), be(e, "fill-rule", "evenodd"), be(e, "clip-rule", "evenodd"), be(e, "stroke-linecap", "round"), be(e, "stroke-linejoin", "round");
    },
    m(r, l) {
      nr(r, e, l), St(e, t), St(t, n), St(e, i);
    },
    p: Tt,
    i: Tt,
    o: Tt,
    d(r) {
      r && Pe(e);
    }
  };
}
class Ci extends er {
  constructor(e) {
    super(), tr(this, e, null, ar, ir, {});
  }
}
const {
  SvelteComponent: h_,
  append_hydration: m_,
  attr: g_,
  children: b_,
  claim_svg_element: v_,
  claim_text: D_,
  detach: y_,
  init: w_,
  insert_hydration: $_,
  noop: F_,
  safe_not_equal: E_,
  svg_element: k_,
  text: C_
} = window.__gradio__svelte__internal, {
  SvelteComponent: lr,
  append_hydration: rr,
  attr: Me,
  children: Rn,
  claim_svg_element: qn,
  detach: Bt,
  init: or,
  insert_hydration: sr,
  noop: xt,
  safe_not_equal: ur,
  svg_element: Ln
} = window.__gradio__svelte__internal;
function cr(a) {
  let e, t;
  return {
    c() {
      e = Ln("svg"), t = Ln("path"), this.h();
    },
    l(n) {
      e = qn(n, "svg", { width: !0, height: !0, viewBox: !0 });
      var i = Rn(e);
      t = qn(i, "path", { fill: !0, d: !0 }), Rn(t).forEach(Bt), i.forEach(Bt), this.h();
    },
    h() {
      Me(t, "fill", "currentColor"), Me(t, "d", "m31 16l-7 7l-1.41-1.41L28.17 16l-5.58-5.59L24 9l7 7zM1 16l7-7l1.41 1.41L3.83 16l5.58 5.59L8 23l-7-7zm11.42 9.484L17.64 6l1.932.517L14.352 26z"), Me(e, "width", "100%"), Me(e, "height", "100%"), Me(e, "viewBox", "0 0 32 32");
    },
    m(n, i) {
      sr(n, e, i), rr(e, t);
    },
    p: xt,
    i: xt,
    o: xt,
    d(n) {
      n && Bt(e);
    }
  };
}
class _r extends lr {
  constructor(e) {
    super(), or(this, e, null, cr, ur, {});
  }
}
const {
  SvelteComponent: A_,
  append_hydration: S_,
  attr: T_,
  children: B_,
  claim_svg_element: x_,
  detach: I_,
  init: R_,
  insert_hydration: q_,
  noop: L_,
  safe_not_equal: N_,
  svg_element: O_
} = window.__gradio__svelte__internal, {
  SvelteComponent: z_,
  append_hydration: P_,
  attr: M_,
  children: U_,
  claim_svg_element: H_,
  detach: G_,
  init: j_,
  insert_hydration: Z_,
  noop: V_,
  safe_not_equal: Y_,
  svg_element: X_
} = window.__gradio__svelte__internal, {
  SvelteComponent: W_,
  append_hydration: K_,
  attr: Q_,
  children: J_,
  claim_svg_element: ed,
  detach: td,
  init: nd,
  insert_hydration: id,
  noop: ad,
  safe_not_equal: ld,
  svg_element: rd
} = window.__gradio__svelte__internal, {
  SvelteComponent: od,
  append_hydration: sd,
  attr: ud,
  children: cd,
  claim_svg_element: _d,
  detach: dd,
  init: pd,
  insert_hydration: fd,
  noop: hd,
  safe_not_equal: md,
  svg_element: gd
} = window.__gradio__svelte__internal, {
  SvelteComponent: bd,
  append_hydration: vd,
  attr: Dd,
  children: yd,
  claim_svg_element: wd,
  detach: $d,
  init: Fd,
  insert_hydration: Ed,
  noop: kd,
  safe_not_equal: Cd,
  svg_element: Ad
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sd,
  append_hydration: Td,
  attr: Bd,
  children: xd,
  claim_svg_element: Id,
  detach: Rd,
  init: qd,
  insert_hydration: Ld,
  noop: Nd,
  safe_not_equal: Od,
  svg_element: zd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pd,
  append_hydration: Md,
  attr: Ud,
  children: Hd,
  claim_svg_element: Gd,
  detach: jd,
  init: Zd,
  insert_hydration: Vd,
  noop: Yd,
  safe_not_equal: Xd,
  svg_element: Wd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kd,
  append_hydration: Qd,
  attr: Jd,
  children: ep,
  claim_svg_element: tp,
  detach: np,
  init: ip,
  insert_hydration: ap,
  noop: lp,
  safe_not_equal: rp,
  svg_element: op
} = window.__gradio__svelte__internal, {
  SvelteComponent: sp,
  append_hydration: up,
  attr: cp,
  children: _p,
  claim_svg_element: dp,
  detach: pp,
  init: fp,
  insert_hydration: hp,
  noop: mp,
  safe_not_equal: gp,
  svg_element: bp
} = window.__gradio__svelte__internal, {
  SvelteComponent: vp,
  append_hydration: Dp,
  attr: yp,
  children: wp,
  claim_svg_element: $p,
  detach: Fp,
  init: Ep,
  insert_hydration: kp,
  noop: Cp,
  safe_not_equal: Ap,
  svg_element: Sp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tp,
  append_hydration: Bp,
  attr: xp,
  children: Ip,
  claim_svg_element: Rp,
  detach: qp,
  init: Lp,
  insert_hydration: Np,
  noop: Op,
  safe_not_equal: zp,
  svg_element: Pp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mp,
  append_hydration: Up,
  attr: Hp,
  children: Gp,
  claim_svg_element: jp,
  detach: Zp,
  init: Vp,
  insert_hydration: Yp,
  noop: Xp,
  safe_not_equal: Wp,
  svg_element: Kp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qp,
  append_hydration: Jp,
  attr: ef,
  children: tf,
  claim_svg_element: nf,
  detach: af,
  init: lf,
  insert_hydration: rf,
  noop: of,
  safe_not_equal: sf,
  svg_element: uf
} = window.__gradio__svelte__internal, {
  SvelteComponent: cf,
  append_hydration: _f,
  attr: df,
  children: pf,
  claim_svg_element: ff,
  detach: hf,
  init: mf,
  insert_hydration: gf,
  noop: bf,
  safe_not_equal: vf,
  svg_element: Df
} = window.__gradio__svelte__internal, {
  SvelteComponent: yf,
  append_hydration: wf,
  attr: $f,
  children: Ff,
  claim_svg_element: Ef,
  detach: kf,
  init: Cf,
  insert_hydration: Af,
  noop: Sf,
  safe_not_equal: Tf,
  svg_element: Bf
} = window.__gradio__svelte__internal, {
  SvelteComponent: xf,
  append_hydration: If,
  attr: Rf,
  children: qf,
  claim_svg_element: Lf,
  detach: Nf,
  init: Of,
  insert_hydration: zf,
  noop: Pf,
  safe_not_equal: Mf,
  svg_element: Uf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hf,
  append_hydration: Gf,
  attr: jf,
  children: Zf,
  claim_svg_element: Vf,
  detach: Yf,
  init: Xf,
  insert_hydration: Wf,
  noop: Kf,
  safe_not_equal: Qf,
  svg_element: Jf
} = window.__gradio__svelte__internal, {
  SvelteComponent: eh,
  append_hydration: th,
  attr: nh,
  children: ih,
  claim_svg_element: ah,
  detach: lh,
  init: rh,
  insert_hydration: oh,
  noop: sh,
  safe_not_equal: uh,
  svg_element: ch
} = window.__gradio__svelte__internal, {
  SvelteComponent: _h,
  append_hydration: dh,
  attr: ph,
  children: fh,
  claim_svg_element: hh,
  detach: mh,
  init: gh,
  insert_hydration: bh,
  noop: vh,
  safe_not_equal: Dh,
  svg_element: yh
} = window.__gradio__svelte__internal, {
  SvelteComponent: wh,
  append_hydration: $h,
  attr: Fh,
  children: Eh,
  claim_svg_element: kh,
  detach: Ch,
  init: Ah,
  insert_hydration: Sh,
  noop: Th,
  safe_not_equal: Bh,
  svg_element: xh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ih,
  append_hydration: Rh,
  attr: qh,
  children: Lh,
  claim_svg_element: Nh,
  detach: Oh,
  init: zh,
  insert_hydration: Ph,
  noop: Mh,
  safe_not_equal: Uh,
  svg_element: Hh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gh,
  append_hydration: jh,
  attr: Zh,
  children: Vh,
  claim_svg_element: Yh,
  detach: Xh,
  init: Wh,
  insert_hydration: Kh,
  noop: Qh,
  safe_not_equal: Jh,
  svg_element: em
} = window.__gradio__svelte__internal, {
  SvelteComponent: tm,
  append_hydration: nm,
  attr: im,
  children: am,
  claim_svg_element: lm,
  detach: rm,
  init: om,
  insert_hydration: sm,
  noop: um,
  safe_not_equal: cm,
  svg_element: _m
} = window.__gradio__svelte__internal, {
  SvelteComponent: dm,
  append_hydration: pm,
  attr: fm,
  children: hm,
  claim_svg_element: mm,
  detach: gm,
  init: bm,
  insert_hydration: vm,
  noop: Dm,
  safe_not_equal: ym,
  svg_element: wm
} = window.__gradio__svelte__internal, {
  SvelteComponent: $m,
  append_hydration: Fm,
  attr: Em,
  children: km,
  claim_svg_element: Cm,
  detach: Am,
  init: Sm,
  insert_hydration: Tm,
  noop: Bm,
  safe_not_equal: xm,
  svg_element: Im
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rm,
  append_hydration: qm,
  attr: Lm,
  children: Nm,
  claim_svg_element: Om,
  detach: zm,
  init: Pm,
  insert_hydration: Mm,
  noop: Um,
  safe_not_equal: Hm,
  svg_element: Gm
} = window.__gradio__svelte__internal, {
  SvelteComponent: jm,
  append_hydration: Zm,
  attr: Vm,
  children: Ym,
  claim_svg_element: Xm,
  detach: Wm,
  init: Km,
  insert_hydration: Qm,
  noop: Jm,
  safe_not_equal: eg,
  svg_element: tg
} = window.__gradio__svelte__internal, {
  SvelteComponent: ng,
  append_hydration: ig,
  attr: ag,
  children: lg,
  claim_svg_element: rg,
  detach: og,
  init: sg,
  insert_hydration: ug,
  noop: cg,
  safe_not_equal: _g,
  svg_element: dg
} = window.__gradio__svelte__internal, {
  SvelteComponent: pg,
  append_hydration: fg,
  attr: hg,
  children: mg,
  claim_svg_element: gg,
  detach: bg,
  init: vg,
  insert_hydration: Dg,
  noop: yg,
  safe_not_equal: wg,
  svg_element: $g
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fg,
  append_hydration: Eg,
  attr: kg,
  children: Cg,
  claim_svg_element: Ag,
  detach: Sg,
  init: Tg,
  insert_hydration: Bg,
  noop: xg,
  safe_not_equal: Ig,
  svg_element: Rg
} = window.__gradio__svelte__internal, {
  SvelteComponent: qg,
  append_hydration: Lg,
  attr: Ng,
  children: Og,
  claim_svg_element: zg,
  detach: Pg,
  init: Mg,
  insert_hydration: Ug,
  noop: Hg,
  safe_not_equal: Gg,
  svg_element: jg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zg,
  append_hydration: Vg,
  attr: Yg,
  children: Xg,
  claim_svg_element: Wg,
  detach: Kg,
  init: Qg,
  insert_hydration: Jg,
  noop: e0,
  safe_not_equal: t0,
  svg_element: n0
} = window.__gradio__svelte__internal, {
  SvelteComponent: i0,
  append_hydration: a0,
  attr: l0,
  children: r0,
  claim_svg_element: o0,
  detach: s0,
  init: u0,
  insert_hydration: c0,
  noop: _0,
  safe_not_equal: d0,
  set_style: p0,
  svg_element: f0
} = window.__gradio__svelte__internal, {
  SvelteComponent: h0,
  append_hydration: m0,
  attr: g0,
  children: b0,
  claim_svg_element: v0,
  detach: D0,
  init: y0,
  insert_hydration: w0,
  noop: $0,
  safe_not_equal: F0,
  svg_element: E0
} = window.__gradio__svelte__internal, {
  SvelteComponent: k0,
  append_hydration: C0,
  attr: A0,
  children: S0,
  claim_svg_element: T0,
  detach: B0,
  init: x0,
  insert_hydration: I0,
  noop: R0,
  safe_not_equal: q0,
  svg_element: L0
} = window.__gradio__svelte__internal, {
  SvelteComponent: N0,
  append_hydration: O0,
  attr: z0,
  children: P0,
  claim_svg_element: M0,
  detach: U0,
  init: H0,
  insert_hydration: G0,
  noop: j0,
  safe_not_equal: Z0,
  svg_element: V0
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y0,
  append_hydration: X0,
  attr: W0,
  children: K0,
  claim_svg_element: Q0,
  detach: J0,
  init: e1,
  insert_hydration: t1,
  noop: n1,
  safe_not_equal: i1,
  svg_element: a1
} = window.__gradio__svelte__internal, {
  SvelteComponent: l1,
  append_hydration: r1,
  attr: o1,
  children: s1,
  claim_svg_element: u1,
  detach: c1,
  init: _1,
  insert_hydration: d1,
  noop: p1,
  safe_not_equal: f1,
  svg_element: h1
} = window.__gradio__svelte__internal, {
  SvelteComponent: m1,
  append_hydration: g1,
  attr: b1,
  children: v1,
  claim_svg_element: D1,
  detach: y1,
  init: w1,
  insert_hydration: $1,
  noop: F1,
  safe_not_equal: E1,
  svg_element: k1
} = window.__gradio__svelte__internal, {
  SvelteComponent: C1,
  append_hydration: A1,
  attr: S1,
  children: T1,
  claim_svg_element: B1,
  detach: x1,
  init: I1,
  insert_hydration: R1,
  noop: q1,
  safe_not_equal: L1,
  svg_element: N1
} = window.__gradio__svelte__internal, {
  SvelteComponent: O1,
  append_hydration: z1,
  attr: P1,
  children: M1,
  claim_svg_element: U1,
  detach: H1,
  init: G1,
  insert_hydration: j1,
  noop: Z1,
  safe_not_equal: V1,
  svg_element: Y1
} = window.__gradio__svelte__internal, {
  SvelteComponent: X1,
  append_hydration: W1,
  attr: K1,
  children: Q1,
  claim_svg_element: J1,
  claim_text: eb,
  detach: tb,
  init: nb,
  insert_hydration: ib,
  noop: ab,
  safe_not_equal: lb,
  svg_element: rb,
  text: ob
} = window.__gradio__svelte__internal, {
  SvelteComponent: sb,
  append_hydration: ub,
  attr: cb,
  children: _b,
  claim_svg_element: db,
  detach: pb,
  init: fb,
  insert_hydration: hb,
  noop: mb,
  safe_not_equal: gb,
  svg_element: bb
} = window.__gradio__svelte__internal, {
  SvelteComponent: vb,
  append_hydration: Db,
  attr: yb,
  children: wb,
  claim_svg_element: $b,
  detach: Fb,
  init: Eb,
  insert_hydration: kb,
  noop: Cb,
  safe_not_equal: Ab,
  svg_element: Sb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tb,
  append_hydration: Bb,
  attr: xb,
  children: Ib,
  claim_svg_element: Rb,
  detach: qb,
  init: Lb,
  insert_hydration: Nb,
  noop: Ob,
  safe_not_equal: zb,
  svg_element: Pb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mb,
  append_hydration: Ub,
  attr: Hb,
  children: Gb,
  claim_svg_element: jb,
  detach: Zb,
  init: Vb,
  insert_hydration: Yb,
  noop: Xb,
  safe_not_equal: Wb,
  svg_element: Kb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qb,
  append_hydration: Jb,
  attr: ev,
  children: tv,
  claim_svg_element: nv,
  detach: iv,
  init: av,
  insert_hydration: lv,
  noop: rv,
  safe_not_equal: ov,
  svg_element: sv
} = window.__gradio__svelte__internal, {
  SvelteComponent: uv,
  append_hydration: cv,
  attr: _v,
  children: dv,
  claim_svg_element: pv,
  detach: fv,
  init: hv,
  insert_hydration: mv,
  noop: gv,
  safe_not_equal: bv,
  svg_element: vv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dv,
  append_hydration: yv,
  attr: wv,
  children: $v,
  claim_svg_element: Fv,
  detach: Ev,
  init: kv,
  insert_hydration: Cv,
  noop: Av,
  safe_not_equal: Sv,
  svg_element: Tv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bv,
  append_hydration: xv,
  attr: Iv,
  children: Rv,
  claim_svg_element: qv,
  claim_text: Lv,
  detach: Nv,
  init: Ov,
  insert_hydration: zv,
  noop: Pv,
  safe_not_equal: Mv,
  svg_element: Uv,
  text: Hv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gv,
  append_hydration: jv,
  attr: Zv,
  children: Vv,
  claim_svg_element: Yv,
  claim_text: Xv,
  detach: Wv,
  init: Kv,
  insert_hydration: Qv,
  noop: Jv,
  safe_not_equal: eD,
  svg_element: tD,
  text: nD
} = window.__gradio__svelte__internal, {
  SvelteComponent: iD,
  append_hydration: aD,
  attr: lD,
  children: rD,
  claim_svg_element: oD,
  claim_text: sD,
  detach: uD,
  init: cD,
  insert_hydration: _D,
  noop: dD,
  safe_not_equal: pD,
  svg_element: fD,
  text: hD
} = window.__gradio__svelte__internal, {
  SvelteComponent: mD,
  append_hydration: gD,
  attr: bD,
  children: vD,
  claim_svg_element: DD,
  detach: yD,
  init: wD,
  insert_hydration: $D,
  noop: FD,
  safe_not_equal: ED,
  svg_element: kD
} = window.__gradio__svelte__internal, {
  SvelteComponent: CD,
  append_hydration: AD,
  attr: SD,
  children: TD,
  claim_svg_element: BD,
  detach: xD,
  init: ID,
  insert_hydration: RD,
  noop: qD,
  safe_not_equal: LD,
  svg_element: ND
} = window.__gradio__svelte__internal, {
  SvelteComponent: OD,
  append_hydration: zD,
  attr: PD,
  children: MD,
  claim_svg_element: UD,
  detach: HD,
  init: GD,
  insert_hydration: jD,
  noop: ZD,
  safe_not_equal: VD,
  svg_element: YD
} = window.__gradio__svelte__internal, {
  SvelteComponent: XD,
  append_hydration: WD,
  attr: KD,
  children: QD,
  claim_svg_element: JD,
  detach: ey,
  init: ty,
  insert_hydration: ny,
  noop: iy,
  safe_not_equal: ay,
  svg_element: ly
} = window.__gradio__svelte__internal, {
  SvelteComponent: ry,
  append_hydration: oy,
  attr: sy,
  children: uy,
  claim_svg_element: cy,
  detach: _y,
  init: dy,
  insert_hydration: py,
  noop: fy,
  safe_not_equal: hy,
  svg_element: my
} = window.__gradio__svelte__internal, {
  SvelteComponent: gy,
  append_hydration: by,
  attr: vy,
  children: Dy,
  claim_svg_element: yy,
  detach: wy,
  init: $y,
  insert_hydration: Fy,
  noop: Ey,
  safe_not_equal: ky,
  svg_element: Cy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ay,
  append_hydration: Sy,
  attr: Ty,
  children: By,
  claim_svg_element: xy,
  detach: Iy,
  init: Ry,
  insert_hydration: qy,
  noop: Ly,
  safe_not_equal: Ny,
  svg_element: Oy
} = window.__gradio__svelte__internal, {
  SvelteComponent: zy,
  append_hydration: Py,
  attr: My,
  children: Uy,
  claim_svg_element: Hy,
  detach: Gy,
  init: jy,
  insert_hydration: Zy,
  noop: Vy,
  safe_not_equal: Yy,
  svg_element: Xy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wy,
  append_hydration: Ky,
  attr: Qy,
  children: Jy,
  claim_svg_element: ew,
  detach: tw,
  init: nw,
  insert_hydration: iw,
  noop: aw,
  safe_not_equal: lw,
  svg_element: rw
} = window.__gradio__svelte__internal, {
  SvelteComponent: ow,
  append_hydration: sw,
  attr: uw,
  children: cw,
  claim_svg_element: _w,
  detach: dw,
  init: pw,
  insert_hydration: fw,
  noop: hw,
  safe_not_equal: mw,
  svg_element: gw
} = window.__gradio__svelte__internal, {
  SvelteComponent: bw,
  append_hydration: vw,
  attr: Dw,
  children: yw,
  claim_svg_element: ww,
  detach: $w,
  init: Fw,
  insert_hydration: Ew,
  noop: kw,
  safe_not_equal: Cw,
  svg_element: Aw
} = window.__gradio__svelte__internal, dr = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Nn = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
dr.reduce(
  (a, { color: e, primary: t, secondary: n }) => ({
    ...a,
    [e]: {
      primary: Nn[e][t],
      secondary: Nn[e][n]
    }
  }),
  {}
);
const it = (a) => typeof a == "number" ? a + "px" : a, {
  SvelteComponent: Sw,
  claim_component: Tw,
  create_component: Bw,
  destroy_component: xw,
  init: Iw,
  mount_component: Rw,
  safe_not_equal: qw,
  transition_in: Lw,
  transition_out: Nw
} = window.__gradio__svelte__internal, { createEventDispatcher: Ow } = window.__gradio__svelte__internal, {
  SvelteComponent: zw,
  append_hydration: Pw,
  attr: Mw,
  check_outros: Uw,
  children: Hw,
  claim_component: Gw,
  claim_element: jw,
  claim_space: Zw,
  claim_text: Vw,
  create_component: Yw,
  destroy_component: Xw,
  detach: Ww,
  element: Kw,
  empty: Qw,
  group_outros: Jw,
  init: e$,
  insert_hydration: t$,
  mount_component: n$,
  safe_not_equal: i$,
  set_data: a$,
  space: l$,
  text: r$,
  toggle_class: o$,
  transition_in: s$,
  transition_out: u$
} = window.__gradio__svelte__internal, {
  SvelteComponent: c$,
  attr: _$,
  children: d$,
  claim_element: p$,
  create_slot: f$,
  detach: h$,
  element: m$,
  get_all_dirty_from_scope: g$,
  get_slot_changes: b$,
  init: v$,
  insert_hydration: D$,
  safe_not_equal: y$,
  toggle_class: w$,
  transition_in: $$,
  transition_out: F$,
  update_slot_base: E$
} = window.__gradio__svelte__internal, {
  SvelteComponent: k$,
  append_hydration: C$,
  attr: A$,
  check_outros: S$,
  children: T$,
  claim_component: B$,
  claim_element: x$,
  claim_space: I$,
  create_component: R$,
  destroy_component: q$,
  detach: L$,
  element: N$,
  empty: O$,
  group_outros: z$,
  init: P$,
  insert_hydration: M$,
  listen: U$,
  mount_component: H$,
  safe_not_equal: G$,
  space: j$,
  toggle_class: Z$,
  transition_in: V$,
  transition_out: Y$
} = window.__gradio__svelte__internal, {
  SvelteComponent: X$,
  attr: W$,
  children: K$,
  claim_element: Q$,
  create_slot: J$,
  detach: eF,
  element: tF,
  get_all_dirty_from_scope: nF,
  get_slot_changes: iF,
  init: aF,
  insert_hydration: lF,
  null_to_empty: rF,
  safe_not_equal: oF,
  transition_in: sF,
  transition_out: uF,
  update_slot_base: cF
} = window.__gradio__svelte__internal, {
  SvelteComponent: _F,
  check_outros: dF,
  claim_component: pF,
  create_component: fF,
  destroy_component: hF,
  detach: mF,
  empty: gF,
  group_outros: bF,
  init: vF,
  insert_hydration: DF,
  mount_component: yF,
  noop: wF,
  safe_not_equal: $F,
  transition_in: FF,
  transition_out: EF
} = window.__gradio__svelte__internal, { createEventDispatcher: kF } = window.__gradio__svelte__internal, {
  SvelteComponent: pr,
  append_hydration: he,
  attr: ae,
  binding_callbacks: On,
  check_outros: pt,
  children: le,
  claim_component: Wt,
  claim_element: re,
  claim_space: V,
  claim_text: z,
  create_component: Kt,
  create_slot: Ai,
  destroy_component: Qt,
  destroy_each: Si,
  detach: k,
  element: oe,
  empty: se,
  ensure_array_like: ft,
  get_all_dirty_from_scope: Ti,
  get_slot_changes: Bi,
  group_outros: ht,
  init: fr,
  insert_hydration: S,
  mount_component: Jt,
  noop: Ut,
  safe_not_equal: hr,
  set_data: ee,
  set_style: ke,
  space: Y,
  text: P,
  toggle_class: ie,
  transition_in: Z,
  transition_out: J,
  update_slot_base: xi
} = window.__gradio__svelte__internal, { tick: mr } = window.__gradio__svelte__internal, { onDestroy: gr } = window.__gradio__svelte__internal, { createEventDispatcher: br } = window.__gradio__svelte__internal, vr = (a) => ({}), zn = (a) => ({}), Dr = (a) => ({}), Pn = (a) => ({});
function Mn(a, e, t) {
  const n = a.slice();
  return n[43] = e[t], n[45] = t, n;
}
function Un(a, e, t) {
  const n = a.slice();
  return n[43] = e[t], n;
}
function Hn(a) {
  let e, t, n, i, r, l;
  return r = new ki({
    props: {
      Icon: Ci,
      label: (
        /*i18n*/
        a[2]("common.clear")
      ),
      disabled: !1,
      size: "x-small",
      background: "var(--background-fill-primary)",
      color: "var(--error-background-text)",
      border: "var(--border-color-primary)"
    }
  }), r.$on(
    "click",
    /*click_handler*/
    a[33]
  ), {
    c() {
      e = oe("div"), t = P(
        /*validation_error*/
        a[1]
      ), n = Y(), i = oe("button"), Kt(r.$$.fragment), this.h();
    },
    l(o) {
      e = re(o, "DIV", { class: !0 });
      var s = le(e);
      t = z(
        s,
        /*validation_error*/
        a[1]
      ), n = V(s), i = re(s, "BUTTON", {});
      var c = le(i);
      Wt(r.$$.fragment, c), c.forEach(k), s.forEach(k), this.h();
    },
    h() {
      ae(e, "class", "validation-error svelte-vusapu");
    },
    m(o, s) {
      S(o, e, s), he(e, t), he(e, n), he(e, i), Jt(r, i, null), l = !0;
    },
    p(o, s) {
      (!l || s[0] & /*validation_error*/
      2) && ee(
        t,
        /*validation_error*/
        o[1]
      );
      const c = {};
      s[0] & /*i18n*/
      4 && (c.label = /*i18n*/
      o[2]("common.clear")), r.$set(c);
    },
    i(o) {
      l || (Z(r.$$.fragment, o), l = !0);
    },
    o(o) {
      J(r.$$.fragment, o), l = !1;
    },
    d(o) {
      o && k(e), Qt(r);
    }
  };
}
function yr(a) {
  let e, t, n, i, r = (
    /*i18n*/
    a[2]("common.error") + ""
  ), l, o, s;
  t = new ki({
    props: {
      Icon: Ci,
      label: (
        /*i18n*/
        a[2]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler_1*/
    a[35]
  );
  const c = (
    /*#slots*/
    a[32].error
  ), u = Ai(
    c,
    a,
    /*$$scope*/
    a[31],
    zn
  );
  return {
    c() {
      e = oe("div"), Kt(t.$$.fragment), n = Y(), i = oe("span"), l = P(r), o = Y(), u && u.c(), this.h();
    },
    l(_) {
      e = re(_, "DIV", { class: !0 });
      var d = le(e);
      Wt(t.$$.fragment, d), d.forEach(k), n = V(_), i = re(_, "SPAN", { class: !0 });
      var m = le(i);
      l = z(m, r), m.forEach(k), o = V(_), u && u.l(_), this.h();
    },
    h() {
      ae(e, "class", "clear-status svelte-vusapu"), ae(i, "class", "error svelte-vusapu");
    },
    m(_, d) {
      S(_, e, d), Jt(t, e, null), S(_, n, d), S(_, i, d), he(i, l), S(_, o, d), u && u.m(_, d), s = !0;
    },
    p(_, d) {
      const m = {};
      d[0] & /*i18n*/
      4 && (m.label = /*i18n*/
      _[2]("common.clear")), t.$set(m), (!s || d[0] & /*i18n*/
      4) && r !== (r = /*i18n*/
      _[2]("common.error") + "") && ee(l, r), u && u.p && (!s || d[1] & /*$$scope*/
      1) && xi(
        u,
        c,
        _,
        /*$$scope*/
        _[31],
        s ? Bi(
          c,
          /*$$scope*/
          _[31],
          d,
          vr
        ) : Ti(
          /*$$scope*/
          _[31]
        ),
        zn
      );
    },
    i(_) {
      s || (Z(t.$$.fragment, _), Z(u, _), s = !0);
    },
    o(_) {
      J(t.$$.fragment, _), J(u, _), s = !1;
    },
    d(_) {
      _ && (k(e), k(n), k(i), k(o)), Qt(t), u && u.d(_);
    }
  };
}
function wr(a) {
  let e, t, n, i, r, l, o, s, c, u = (
    /*variant*/
    a[9] === "default" && /*show_eta_bar*/
    a[20] && /*show_progress*/
    a[7] === "full" && Gn(a)
  );
  function _(p, h) {
    if (
      /*progress*/
      p[8]
    ) return Er;
    if (
      /*queue_position*/
      p[3] !== null && /*queue_size*/
      p[4] !== void 0 && /*queue_position*/
      p[3] >= 0
    ) return Fr;
    if (
      /*queue_position*/
      p[3] === 0
    ) return $r;
  }
  let d = _(a), m = d && d(a), b = (
    /*timer*/
    a[6] && Vn(a)
  );
  const v = [Sr, Ar], y = [];
  function w(p, h) {
    return (
      /*last_progress_level*/
      p[17] != null ? 0 : (
        /*show_progress*/
        p[7] === "full" ? 1 : -1
      )
    );
  }
  ~(r = w(a)) && (l = y[r] = v[r](a));
  let f = !/*timer*/
  a[6] && ei(a);
  return {
    c() {
      u && u.c(), e = Y(), t = oe("div"), m && m.c(), n = Y(), b && b.c(), i = Y(), l && l.c(), o = Y(), f && f.c(), s = se(), this.h();
    },
    l(p) {
      u && u.l(p), e = V(p), t = re(p, "DIV", { class: !0 });
      var h = le(t);
      m && m.l(h), n = V(h), b && b.l(h), h.forEach(k), i = V(p), l && l.l(p), o = V(p), f && f.l(p), s = se(), this.h();
    },
    h() {
      ae(t, "class", "progress-text svelte-vusapu"), ie(
        t,
        "meta-text-center",
        /*variant*/
        a[9] === "center"
      ), ie(
        t,
        "meta-text",
        /*variant*/
        a[9] === "default"
      );
    },
    m(p, h) {
      u && u.m(p, h), S(p, e, h), S(p, t, h), m && m.m(t, null), he(t, n), b && b.m(t, null), S(p, i, h), ~r && y[r].m(p, h), S(p, o, h), f && f.m(p, h), S(p, s, h), c = !0;
    },
    p(p, h) {
      /*variant*/
      p[9] === "default" && /*show_eta_bar*/
      p[20] && /*show_progress*/
      p[7] === "full" ? u ? u.p(p, h) : (u = Gn(p), u.c(), u.m(e.parentNode, e)) : u && (u.d(1), u = null), d === (d = _(p)) && m ? m.p(p, h) : (m && m.d(1), m = d && d(p), m && (m.c(), m.m(t, n))), /*timer*/
      p[6] ? b ? b.p(p, h) : (b = Vn(p), b.c(), b.m(t, null)) : b && (b.d(1), b = null), (!c || h[0] & /*variant*/
      512) && ie(
        t,
        "meta-text-center",
        /*variant*/
        p[9] === "center"
      ), (!c || h[0] & /*variant*/
      512) && ie(
        t,
        "meta-text",
        /*variant*/
        p[9] === "default"
      );
      let g = r;
      r = w(p), r === g ? ~r && y[r].p(p, h) : (l && (ht(), J(y[g], 1, 1, () => {
        y[g] = null;
      }), pt()), ~r ? (l = y[r], l ? l.p(p, h) : (l = y[r] = v[r](p), l.c()), Z(l, 1), l.m(o.parentNode, o)) : l = null), /*timer*/
      p[6] ? f && (ht(), J(f, 1, 1, () => {
        f = null;
      }), pt()) : f ? (f.p(p, h), h[0] & /*timer*/
      64 && Z(f, 1)) : (f = ei(p), f.c(), Z(f, 1), f.m(s.parentNode, s));
    },
    i(p) {
      c || (Z(l), Z(f), c = !0);
    },
    o(p) {
      J(l), J(f), c = !1;
    },
    d(p) {
      p && (k(e), k(t), k(i), k(o), k(s)), u && u.d(p), m && m.d(), b && b.d(), ~r && y[r].d(p), f && f.d(p);
    }
  };
}
function Gn(a) {
  let e, t = `translateX(${/*eta_level*/
  (a[19] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = oe("div"), this.h();
    },
    l(n) {
      e = re(n, "DIV", { class: !0 }), le(e).forEach(k), this.h();
    },
    h() {
      ae(e, "class", "eta-bar svelte-vusapu"), ke(e, "transform", t);
    },
    m(n, i) {
      S(n, e, i);
    },
    p(n, i) {
      i[0] & /*eta_level*/
      524288 && t !== (t = `translateX(${/*eta_level*/
      (n[19] || 0) * 100 - 100}%)`) && ke(e, "transform", t);
    },
    d(n) {
      n && k(e);
    }
  };
}
function $r(a) {
  let e;
  return {
    c() {
      e = P("processing |");
    },
    l(t) {
      e = z(t, "processing |");
    },
    m(t, n) {
      S(t, e, n);
    },
    p: Ut,
    d(t) {
      t && k(e);
    }
  };
}
function Fr(a) {
  let e, t = (
    /*queue_position*/
    a[3] + 1 + ""
  ), n, i, r, l;
  return {
    c() {
      e = P("queue: "), n = P(t), i = P("/"), r = P(
        /*queue_size*/
        a[4]
      ), l = P(" |");
    },
    l(o) {
      e = z(o, "queue: "), n = z(o, t), i = z(o, "/"), r = z(
        o,
        /*queue_size*/
        a[4]
      ), l = z(o, " |");
    },
    m(o, s) {
      S(o, e, s), S(o, n, s), S(o, i, s), S(o, r, s), S(o, l, s);
    },
    p(o, s) {
      s[0] & /*queue_position*/
      8 && t !== (t = /*queue_position*/
      o[3] + 1 + "") && ee(n, t), s[0] & /*queue_size*/
      16 && ee(
        r,
        /*queue_size*/
        o[4]
      );
    },
    d(o) {
      o && (k(e), k(n), k(i), k(r), k(l));
    }
  };
}
function Er(a) {
  let e, t = ft(
    /*progress*/
    a[8]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = Zn(Un(a, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = se();
    },
    l(i) {
      for (let r = 0; r < n.length; r += 1)
        n[r].l(i);
      e = se();
    },
    m(i, r) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(i, r);
      S(i, e, r);
    },
    p(i, r) {
      if (r[0] & /*progress*/
      256) {
        t = ft(
          /*progress*/
          i[8]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = Un(i, t, l);
          n[l] ? n[l].p(o, r) : (n[l] = Zn(o), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && k(e), Si(n, i);
    }
  };
}
function jn(a) {
  let e, t = (
    /*p*/
    a[43].unit + ""
  ), n, i, r = " ", l;
  function o(u, _) {
    return (
      /*p*/
      u[43].length != null ? Cr : kr
    );
  }
  let s = o(a), c = s(a);
  return {
    c() {
      c.c(), e = Y(), n = P(t), i = P(" | "), l = P(r);
    },
    l(u) {
      c.l(u), e = V(u), n = z(u, t), i = z(u, " | "), l = z(u, r);
    },
    m(u, _) {
      c.m(u, _), S(u, e, _), S(u, n, _), S(u, i, _), S(u, l, _);
    },
    p(u, _) {
      s === (s = o(u)) && c ? c.p(u, _) : (c.d(1), c = s(u), c && (c.c(), c.m(e.parentNode, e))), _[0] & /*progress*/
      256 && t !== (t = /*p*/
      u[43].unit + "") && ee(n, t);
    },
    d(u) {
      u && (k(e), k(n), k(i), k(l)), c.d(u);
    }
  };
}
function kr(a) {
  let e = Le(
    /*p*/
    a[43].index || 0
  ) + "", t;
  return {
    c() {
      t = P(e);
    },
    l(n) {
      t = z(n, e);
    },
    m(n, i) {
      S(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      256 && e !== (e = Le(
        /*p*/
        n[43].index || 0
      ) + "") && ee(t, e);
    },
    d(n) {
      n && k(t);
    }
  };
}
function Cr(a) {
  let e = Le(
    /*p*/
    a[43].index || 0
  ) + "", t, n, i = Le(
    /*p*/
    a[43].length
  ) + "", r;
  return {
    c() {
      t = P(e), n = P("/"), r = P(i);
    },
    l(l) {
      t = z(l, e), n = z(l, "/"), r = z(l, i);
    },
    m(l, o) {
      S(l, t, o), S(l, n, o), S(l, r, o);
    },
    p(l, o) {
      o[0] & /*progress*/
      256 && e !== (e = Le(
        /*p*/
        l[43].index || 0
      ) + "") && ee(t, e), o[0] & /*progress*/
      256 && i !== (i = Le(
        /*p*/
        l[43].length
      ) + "") && ee(r, i);
    },
    d(l) {
      l && (k(t), k(n), k(r));
    }
  };
}
function Zn(a) {
  let e, t = (
    /*p*/
    a[43].index != null && jn(a)
  );
  return {
    c() {
      t && t.c(), e = se();
    },
    l(n) {
      t && t.l(n), e = se();
    },
    m(n, i) {
      t && t.m(n, i), S(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[43].index != null ? t ? t.p(n, i) : (t = jn(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && k(e), t && t.d(n);
    }
  };
}
function Vn(a) {
  let e, t = (
    /*eta*/
    a[0] ? `/${/*formatted_eta*/
    a[21]}` : ""
  ), n, i;
  return {
    c() {
      e = P(
        /*formatted_timer*/
        a[22]
      ), n = P(t), i = P("s");
    },
    l(r) {
      e = z(
        r,
        /*formatted_timer*/
        a[22]
      ), n = z(r, t), i = z(r, "s");
    },
    m(r, l) {
      S(r, e, l), S(r, n, l), S(r, i, l);
    },
    p(r, l) {
      l[0] & /*formatted_timer*/
      4194304 && ee(
        e,
        /*formatted_timer*/
        r[22]
      ), l[0] & /*eta, formatted_eta*/
      2097153 && t !== (t = /*eta*/
      r[0] ? `/${/*formatted_eta*/
      r[21]}` : "") && ee(n, t);
    },
    d(r) {
      r && (k(e), k(n), k(i));
    }
  };
}
function Ar(a) {
  let e, t;
  return e = new pa({
    props: { margin: (
      /*variant*/
      a[9] === "default"
    ) }
  }), {
    c() {
      Kt(e.$$.fragment);
    },
    l(n) {
      Wt(e.$$.fragment, n);
    },
    m(n, i) {
      Jt(e, n, i), t = !0;
    },
    p(n, i) {
      const r = {};
      i[0] & /*variant*/
      512 && (r.margin = /*variant*/
      n[9] === "default"), e.$set(r);
    },
    i(n) {
      t || (Z(e.$$.fragment, n), t = !0);
    },
    o(n) {
      J(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Qt(e, n);
    }
  };
}
function Sr(a) {
  let e, t, n, i, r, l = `${/*last_progress_level*/
  a[17] * 100}%`, o = (
    /*progress*/
    a[8] != null && Yn(a)
  );
  return {
    c() {
      e = oe("div"), t = oe("div"), o && o.c(), n = Y(), i = oe("div"), r = oe("div"), this.h();
    },
    l(s) {
      e = re(s, "DIV", { class: !0 });
      var c = le(e);
      t = re(c, "DIV", { class: !0 });
      var u = le(t);
      o && o.l(u), u.forEach(k), n = V(c), i = re(c, "DIV", { class: !0 });
      var _ = le(i);
      r = re(_, "DIV", { class: !0 }), le(r).forEach(k), _.forEach(k), c.forEach(k), this.h();
    },
    h() {
      ae(t, "class", "progress-level-inner svelte-vusapu"), ae(r, "class", "progress-bar svelte-vusapu"), ke(r, "width", l), ae(i, "class", "progress-bar-wrap svelte-vusapu"), ae(e, "class", "progress-level svelte-vusapu");
    },
    m(s, c) {
      S(s, e, c), he(e, t), o && o.m(t, null), he(e, n), he(e, i), he(i, r), a[34](r);
    },
    p(s, c) {
      /*progress*/
      s[8] != null ? o ? o.p(s, c) : (o = Yn(s), o.c(), o.m(t, null)) : o && (o.d(1), o = null), c[0] & /*last_progress_level*/
      131072 && l !== (l = `${/*last_progress_level*/
      s[17] * 100}%`) && ke(r, "width", l);
    },
    i: Ut,
    o: Ut,
    d(s) {
      s && k(e), o && o.d(), a[34](null);
    }
  };
}
function Yn(a) {
  let e, t = ft(
    /*progress*/
    a[8]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = Jn(Mn(a, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = se();
    },
    l(i) {
      for (let r = 0; r < n.length; r += 1)
        n[r].l(i);
      e = se();
    },
    m(i, r) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(i, r);
      S(i, e, r);
    },
    p(i, r) {
      if (r[0] & /*progress_level, progress*/
      65792) {
        t = ft(
          /*progress*/
          i[8]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = Mn(i, t, l);
          n[l] ? n[l].p(o, r) : (n[l] = Jn(o), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && k(e), Si(n, i);
    }
  };
}
function Xn(a) {
  let e, t, n, i, r = (
    /*i*/
    a[45] !== 0 && Tr()
  ), l = (
    /*p*/
    a[43].desc != null && Wn(a)
  ), o = (
    /*p*/
    a[43].desc != null && /*progress_level*/
    a[16] && /*progress_level*/
    a[16][
      /*i*/
      a[45]
    ] != null && Kn()
  ), s = (
    /*progress_level*/
    a[16] != null && Qn(a)
  );
  return {
    c() {
      r && r.c(), e = Y(), l && l.c(), t = Y(), o && o.c(), n = Y(), s && s.c(), i = se();
    },
    l(c) {
      r && r.l(c), e = V(c), l && l.l(c), t = V(c), o && o.l(c), n = V(c), s && s.l(c), i = se();
    },
    m(c, u) {
      r && r.m(c, u), S(c, e, u), l && l.m(c, u), S(c, t, u), o && o.m(c, u), S(c, n, u), s && s.m(c, u), S(c, i, u);
    },
    p(c, u) {
      /*p*/
      c[43].desc != null ? l ? l.p(c, u) : (l = Wn(c), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      c[43].desc != null && /*progress_level*/
      c[16] && /*progress_level*/
      c[16][
        /*i*/
        c[45]
      ] != null ? o || (o = Kn(), o.c(), o.m(n.parentNode, n)) : o && (o.d(1), o = null), /*progress_level*/
      c[16] != null ? s ? s.p(c, u) : (s = Qn(c), s.c(), s.m(i.parentNode, i)) : s && (s.d(1), s = null);
    },
    d(c) {
      c && (k(e), k(t), k(n), k(i)), r && r.d(c), l && l.d(c), o && o.d(c), s && s.d(c);
    }
  };
}
function Tr(a) {
  let e;
  return {
    c() {
      e = P(" /");
    },
    l(t) {
      e = z(t, " /");
    },
    m(t, n) {
      S(t, e, n);
    },
    d(t) {
      t && k(e);
    }
  };
}
function Wn(a) {
  let e = (
    /*p*/
    a[43].desc + ""
  ), t;
  return {
    c() {
      t = P(e);
    },
    l(n) {
      t = z(n, e);
    },
    m(n, i) {
      S(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      256 && e !== (e = /*p*/
      n[43].desc + "") && ee(t, e);
    },
    d(n) {
      n && k(t);
    }
  };
}
function Kn(a) {
  let e;
  return {
    c() {
      e = P("-");
    },
    l(t) {
      e = z(t, "-");
    },
    m(t, n) {
      S(t, e, n);
    },
    d(t) {
      t && k(e);
    }
  };
}
function Qn(a) {
  let e = (100 * /*progress_level*/
  (a[16][
    /*i*/
    a[45]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = P(e), n = P("%");
    },
    l(i) {
      t = z(i, e), n = z(i, "%");
    },
    m(i, r) {
      S(i, t, r), S(i, n, r);
    },
    p(i, r) {
      r[0] & /*progress_level*/
      65536 && e !== (e = (100 * /*progress_level*/
      (i[16][
        /*i*/
        i[45]
      ] || 0)).toFixed(1) + "") && ee(t, e);
    },
    d(i) {
      i && (k(t), k(n));
    }
  };
}
function Jn(a) {
  let e, t = (
    /*p*/
    (a[43].desc != null || /*progress_level*/
    a[16] && /*progress_level*/
    a[16][
      /*i*/
      a[45]
    ] != null) && Xn(a)
  );
  return {
    c() {
      t && t.c(), e = se();
    },
    l(n) {
      t && t.l(n), e = se();
    },
    m(n, i) {
      t && t.m(n, i), S(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[43].desc != null || /*progress_level*/
      n[16] && /*progress_level*/
      n[16][
        /*i*/
        n[45]
      ] != null ? t ? t.p(n, i) : (t = Xn(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && k(e), t && t.d(n);
    }
  };
}
function ei(a) {
  let e, t, n, i;
  const r = (
    /*#slots*/
    a[32]["additional-loading-text"]
  ), l = Ai(
    r,
    a,
    /*$$scope*/
    a[31],
    Pn
  );
  return {
    c() {
      e = oe("p"), t = P(
        /*loading_text*/
        a[10]
      ), n = Y(), l && l.c(), this.h();
    },
    l(o) {
      e = re(o, "P", { class: !0 });
      var s = le(e);
      t = z(
        s,
        /*loading_text*/
        a[10]
      ), s.forEach(k), n = V(o), l && l.l(o), this.h();
    },
    h() {
      ae(e, "class", "loading svelte-vusapu");
    },
    m(o, s) {
      S(o, e, s), he(e, t), S(o, n, s), l && l.m(o, s), i = !0;
    },
    p(o, s) {
      (!i || s[0] & /*loading_text*/
      1024) && ee(
        t,
        /*loading_text*/
        o[10]
      ), l && l.p && (!i || s[1] & /*$$scope*/
      1) && xi(
        l,
        r,
        o,
        /*$$scope*/
        o[31],
        i ? Bi(
          r,
          /*$$scope*/
          o[31],
          s,
          Dr
        ) : Ti(
          /*$$scope*/
          o[31]
        ),
        Pn
      );
    },
    i(o) {
      i || (Z(l, o), i = !0);
    },
    o(o) {
      J(l, o), i = !1;
    },
    d(o) {
      o && (k(e), k(n)), l && l.d(o);
    }
  };
}
function Br(a) {
  let e, t, n, i, r, l, o = (
    /*validation_error*/
    a[1] && /*show_validation_error*/
    a[14] && Hn(a)
  );
  const s = [wr, yr], c = [];
  function u(_, d) {
    return (
      /*status*/
      _[5] === "pending" ? 0 : (
        /*status*/
        _[5] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = u(a)) && (i = c[n] = s[n](a)), {
    c() {
      e = oe("div"), o && o.c(), t = Y(), i && i.c(), this.h();
    },
    l(_) {
      e = re(_, "DIV", { class: !0 });
      var d = le(e);
      o && o.l(d), t = V(d), i && i.l(d), d.forEach(k), this.h();
    },
    h() {
      ae(e, "class", r = "wrap " + /*variant*/
      a[9] + " " + /*show_progress*/
      a[7] + " svelte-vusapu"), ie(e, "hide", (!/*status*/
      a[5] || /*status*/
      a[5] === "complete" || /*show_progress*/
      a[7] === "hidden" || /*status*/
      a[5] == "streaming") && !/*validation_error*/
      a[1]), ie(
        e,
        "translucent",
        /*variant*/
        a[9] === "center" && /*status*/
        (a[5] === "pending" || /*status*/
        a[5] === "error") || /*translucent*/
        a[12] || /*show_progress*/
        a[7] === "minimal" || /*validation_error*/
        a[1]
      ), ie(
        e,
        "generating",
        /*status*/
        a[5] === "generating" && /*show_progress*/
        a[7] === "full"
      ), ie(
        e,
        "border",
        /*border*/
        a[13]
      ), ke(
        e,
        "position",
        /*absolute*/
        a[11] ? "absolute" : "static"
      ), ke(
        e,
        "padding",
        /*absolute*/
        a[11] ? "0" : "var(--size-8) 0"
      );
    },
    m(_, d) {
      S(_, e, d), o && o.m(e, null), he(e, t), ~n && c[n].m(e, null), a[36](e), l = !0;
    },
    p(_, d) {
      /*validation_error*/
      _[1] && /*show_validation_error*/
      _[14] ? o ? (o.p(_, d), d[0] & /*validation_error, show_validation_error*/
      16386 && Z(o, 1)) : (o = Hn(_), o.c(), Z(o, 1), o.m(e, t)) : o && (ht(), J(o, 1, 1, () => {
        o = null;
      }), pt());
      let m = n;
      n = u(_), n === m ? ~n && c[n].p(_, d) : (i && (ht(), J(c[m], 1, 1, () => {
        c[m] = null;
      }), pt()), ~n ? (i = c[n], i ? i.p(_, d) : (i = c[n] = s[n](_), i.c()), Z(i, 1), i.m(e, null)) : i = null), (!l || d[0] & /*variant, show_progress*/
      640 && r !== (r = "wrap " + /*variant*/
      _[9] + " " + /*show_progress*/
      _[7] + " svelte-vusapu")) && ae(e, "class", r), (!l || d[0] & /*variant, show_progress, status, show_progress, validation_error*/
      674) && ie(e, "hide", (!/*status*/
      _[5] || /*status*/
      _[5] === "complete" || /*show_progress*/
      _[7] === "hidden" || /*status*/
      _[5] == "streaming") && !/*validation_error*/
      _[1]), (!l || d[0] & /*variant, show_progress, variant, status, translucent, show_progress, validation_error*/
      4770) && ie(
        e,
        "translucent",
        /*variant*/
        _[9] === "center" && /*status*/
        (_[5] === "pending" || /*status*/
        _[5] === "error") || /*translucent*/
        _[12] || /*show_progress*/
        _[7] === "minimal" || /*validation_error*/
        _[1]
      ), (!l || d[0] & /*variant, show_progress, status, show_progress*/
      672) && ie(
        e,
        "generating",
        /*status*/
        _[5] === "generating" && /*show_progress*/
        _[7] === "full"
      ), (!l || d[0] & /*variant, show_progress, border*/
      8832) && ie(
        e,
        "border",
        /*border*/
        _[13]
      ), d[0] & /*absolute*/
      2048 && ke(
        e,
        "position",
        /*absolute*/
        _[11] ? "absolute" : "static"
      ), d[0] & /*absolute*/
      2048 && ke(
        e,
        "padding",
        /*absolute*/
        _[11] ? "0" : "var(--size-8) 0"
      );
    },
    i(_) {
      l || (Z(o), Z(i), l = !0);
    },
    o(_) {
      J(o), J(i), l = !1;
    },
    d(_) {
      _ && k(e), o && o.d(), ~n && c[n].d(), a[36](null);
    }
  };
}
var xr = function(a, e, t, n) {
  function i(r) {
    return r instanceof t ? r : new t(function(l) {
      l(r);
    });
  }
  return new (t || (t = Promise))(function(r, l) {
    function o(u) {
      try {
        c(n.next(u));
      } catch (_) {
        l(_);
      }
    }
    function s(u) {
      try {
        c(n.throw(u));
      } catch (_) {
        l(_);
      }
    }
    function c(u) {
      u.done ? r(u.value) : i(u.value).then(o, s);
    }
    c((n = n.apply(a, e || [])).next());
  });
};
let at = [], It = !1;
const Ir = typeof window < "u", Ii = Ir ? window.requestAnimationFrame : (a) => {
};
function Rr(a) {
  return xr(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (at.push(e), !It) It = !0;
      else return;
      yield mr(), Ii(() => {
        let n = [0, 0];
        for (let i = 0; i < at.length; i++) {
          const l = at[i].getBoundingClientRect();
          (i === 0 || l.top + window.scrollY <= n[0]) && (n[0] = l.top + window.scrollY, n[1] = i);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), It = !1, at = [];
      });
    }
  });
}
function qr(a, e, t) {
  let n, { $$slots: i = {}, $$scope: r } = e;
  const l = br();
  let { i18n: o } = e, { eta: s = null } = e, { queue_position: c } = e, { queue_size: u } = e, { status: _ } = e, { scroll_to_output: d = !1 } = e, { timer: m = !0 } = e, { show_progress: b = "full" } = e, { message: v = null } = e, { progress: y = null } = e, { variant: w = "default" } = e, { loading_text: f = "Loading..." } = e, { absolute: p = !0 } = e, { translucent: h = !1 } = e, { border: g = !1 } = e, { autoscroll: D } = e, { validation_error: $ = null } = e, { show_validation_error: A = !0 } = e, E, T = !1, B = 0, I = 0, ue = null, te = null, Ce = 0, X = null, ce, N = null, j = !0;
  const me = () => {
    t(0, s = t(29, ue = t(21, we = null))), t(27, B = performance.now()), t(28, I = 0), T = !0, F();
  };
  function F() {
    Ii(() => {
      t(28, I = (performance.now() - B) / 1e3), T && F();
    });
  }
  function U() {
    t(28, I = 0), t(0, s = t(29, ue = t(21, we = null))), T && (T = !1);
  }
  gr(() => {
    T && U();
  });
  let we = null;
  const W = () => t(1, $ = null);
  function ge(C) {
    On[C ? "unshift" : "push"](() => {
      N = C, t(18, N), t(8, y), t(16, X), t(17, ce);
    });
  }
  const Fe = () => {
    l("clear_status");
  };
  function xe(C) {
    On[C ? "unshift" : "push"](() => {
      E = C, t(15, E);
    });
  }
  return a.$$set = (C) => {
    "i18n" in C && t(2, o = C.i18n), "eta" in C && t(0, s = C.eta), "queue_position" in C && t(3, c = C.queue_position), "queue_size" in C && t(4, u = C.queue_size), "status" in C && t(5, _ = C.status), "scroll_to_output" in C && t(24, d = C.scroll_to_output), "timer" in C && t(6, m = C.timer), "show_progress" in C && t(7, b = C.show_progress), "message" in C && t(25, v = C.message), "progress" in C && t(8, y = C.progress), "variant" in C && t(9, w = C.variant), "loading_text" in C && t(10, f = C.loading_text), "absolute" in C && t(11, p = C.absolute), "translucent" in C && t(12, h = C.translucent), "border" in C && t(13, g = C.border), "autoscroll" in C && t(26, D = C.autoscroll), "validation_error" in C && t(1, $ = C.validation_error), "show_validation_error" in C && t(14, A = C.show_validation_error), "$$scope" in C && t(31, r = C.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    1744830465 && (s === null && t(0, s = ue), s != null && ue !== s && (t(30, te = (performance.now() - B) / 1e3 + s), t(21, we = te.toFixed(1)), t(29, ue = s))), a.$$.dirty[0] & /*eta_from_start, timer_diff*/
    1342177280 && t(19, Ce = te === null || te <= 0 || !I ? null : Math.min(I / te, 1)), a.$$.dirty[0] & /*progress*/
    256 && y != null && t(20, j = !1), a.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    459008 && (y != null ? t(16, X = y.map((C) => {
      if (C.index != null && C.length != null)
        return C.index / C.length;
      if (C.progress != null)
        return C.progress;
    })) : t(16, X = null), X ? (t(17, ce = X[X.length - 1]), N && (ce === 0 ? t(18, N.style.transition = "0", N) : t(18, N.style.transition = "150ms", N))) : t(17, ce = void 0)), a.$$.dirty[0] & /*status*/
    32 && (_ === "pending" ? me() : U()), a.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    83918880 && E && d && (_ === "pending" || _ === "complete") && Rr(E, D), a.$$.dirty[0] & /*status, message*/
    33554464, a.$$.dirty[0] & /*timer_diff*/
    268435456 && t(22, n = I.toFixed(1));
  }, [
    s,
    $,
    o,
    c,
    u,
    _,
    m,
    b,
    y,
    w,
    f,
    p,
    h,
    g,
    A,
    E,
    X,
    ce,
    N,
    Ce,
    j,
    we,
    n,
    l,
    d,
    v,
    D,
    B,
    I,
    ue,
    te,
    r,
    i,
    W,
    ge,
    Fe,
    xe
  ];
}
class Lr extends pr {
  constructor(e) {
    super(), fr(
      this,
      e,
      qr,
      Br,
      hr,
      {
        i18n: 2,
        eta: 0,
        queue_position: 3,
        queue_size: 4,
        status: 5,
        scroll_to_output: 24,
        timer: 6,
        show_progress: 7,
        message: 25,
        progress: 8,
        variant: 9,
        loading_text: 10,
        absolute: 11,
        translucent: 12,
        border: 13,
        autoscroll: 26,
        validation_error: 1,
        show_validation_error: 14
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: CF,
  SvelteComponent: AF,
  add_render_callback: SF,
  append_hydration: TF,
  attr: BF,
  bubble: xF,
  check_outros: IF,
  children: RF,
  claim_component: qF,
  claim_element: LF,
  claim_html_tag: NF,
  claim_space: OF,
  claim_text: zF,
  create_component: PF,
  create_in_transition: MF,
  create_out_transition: UF,
  destroy_component: HF,
  detach: GF,
  element: jF,
  get_svelte_dataset: ZF,
  group_outros: VF,
  init: YF,
  insert_hydration: XF,
  listen: WF,
  mount_component: KF,
  run_all: QF,
  safe_not_equal: JF,
  set_data: eE,
  space: tE,
  stop_propagation: nE,
  text: iE,
  toggle_class: aE,
  transition_in: lE,
  transition_out: rE
} = window.__gradio__svelte__internal, { createEventDispatcher: oE, onMount: sE } = window.__gradio__svelte__internal, {
  SvelteComponent: uE,
  append_hydration: cE,
  attr: _E,
  bubble: dE,
  check_outros: pE,
  children: fE,
  claim_component: hE,
  claim_element: mE,
  claim_space: gE,
  component_subscribe: bE,
  create_animation: vE,
  create_component: DE,
  destroy_component: yE,
  detach: wE,
  element: $E,
  ensure_array_like: FE,
  fix_and_outro_and_destroy_block: EE,
  fix_position: kE,
  group_outros: CE,
  init: AE,
  insert_hydration: SE,
  mount_component: TE,
  noop: BE,
  safe_not_equal: xE,
  set_style: IE,
  space: RE,
  transition_in: qE,
  transition_out: LE,
  update_keyed_each: NE
} = window.__gradio__svelte__internal, {
  SvelteComponent: OE,
  attr: zE,
  children: PE,
  claim_element: ME,
  detach: UE,
  element: HE,
  empty: GE,
  init: jE,
  insert_hydration: ZE,
  noop: VE,
  safe_not_equal: YE,
  set_style: XE
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nr,
  assign: Or,
  attr: zr,
  check_outros: Pr,
  children: Mr,
  claim_component: mt,
  claim_element: Ur,
  claim_space: ti,
  create_component: gt,
  destroy_component: bt,
  detach: lt,
  element: Hr,
  get_spread_object: Gr,
  get_spread_update: jr,
  group_outros: Zr,
  init: Vr,
  insert_hydration: Rt,
  mount_component: vt,
  safe_not_equal: Yr,
  set_style: rt,
  space: ni,
  toggle_class: ot,
  transition_in: Ae,
  transition_out: Ne
} = window.__gradio__svelte__internal;
function ii(a) {
  let e, t;
  return e = new Ll({
    props: {
      Icon: _r,
      show_label: (
        /*show_label*/
        a[7]
      ),
      label: (
        /*label*/
        a[0]
      ),
      float: !1
    }
  }), {
    c() {
      gt(e.$$.fragment);
    },
    l(n) {
      mt(e.$$.fragment, n);
    },
    m(n, i) {
      vt(e, n, i), t = !0;
    },
    p(n, i) {
      const r = {};
      i & /*show_label*/
      128 && (r.show_label = /*show_label*/
      n[7]), i & /*label*/
      1 && (r.label = /*label*/
      n[0]), e.$set(r);
    },
    i(n) {
      t || (Ae(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ne(e.$$.fragment, n), t = !1;
    },
    d(n) {
      bt(e, n);
    }
  };
}
function Xr(a) {
  let e, t, n, i, r, l, o = (
    /*show_label*/
    a[7] && ii(a)
  );
  const s = [
    { autoscroll: (
      /*gradio*/
      a[6].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      a[6].i18n
    ) },
    /*loading_status*/
    a[5],
    { variant: "center" }
  ];
  let c = {};
  for (let u = 0; u < s.length; u += 1)
    c = Or(c, s[u]);
  return t = new Lr({ props: c }), t.$on(
    "clear_status",
    /*clear_status_handler*/
    a[14]
  ), r = new ta({
    props: {
      value: (
        /*value*/
        a[4]
      ),
      elem_classes: (
        /*elem_classes*/
        a[2]
      ),
      visible: (
        /*visible*/
        a[3]
      ),
      autoscroll: (
        /*autoscroll*/
        a[12]
      ),
      selectable_elements: (
        /*selectable_elements*/
        a[13]
      )
    }
  }), r.$on(
    "change",
    /*change_handler*/
    a[15]
  ), r.$on(
    "click",
    /*click_handler*/
    a[16]
  ), r.$on(
    "select",
    /*select_handler*/
    a[17]
  ), {
    c() {
      o && o.c(), e = ni(), gt(t.$$.fragment), n = ni(), i = Hr("div"), gt(r.$$.fragment), this.h();
    },
    l(u) {
      o && o.l(u), e = ti(u), mt(t.$$.fragment, u), n = ti(u), i = Ur(u, "DIV", { class: !0 });
      var _ = Mr(i);
      mt(r.$$.fragment, _), _.forEach(lt), this.h();
    },
    h() {
      var u, _;
      zr(i, "class", "html-container svelte-1hkbylh"), ot(
        i,
        "padding",
        /*padding*/
        a[11]
      ), ot(
        i,
        "pending",
        /*loading_status*/
        ((u = a[5]) == null ? void 0 : u.status) === "pending"
      ), rt(
        i,
        "min-height",
        /*min_height*/
        a[8] && /*loading_status*/
        ((_ = a[5]) == null ? void 0 : _.status) !== "pending" ? it(
          /*min_height*/
          a[8]
        ) : void 0
      ), rt(
        i,
        "max-height",
        /*max_height*/
        a[9] ? it(
          /*max_height*/
          a[9]
        ) : void 0
      );
    },
    m(u, _) {
      o && o.m(u, _), Rt(u, e, _), vt(t, u, _), Rt(u, n, _), Rt(u, i, _), vt(r, i, null), l = !0;
    },
    p(u, _) {
      var b, v;
      /*show_label*/
      u[7] ? o ? (o.p(u, _), _ & /*show_label*/
      128 && Ae(o, 1)) : (o = ii(u), o.c(), Ae(o, 1), o.m(e.parentNode, e)) : o && (Zr(), Ne(o, 1, 1, () => {
        o = null;
      }), Pr());
      const d = _ & /*gradio, loading_status*/
      96 ? jr(s, [
        _ & /*gradio*/
        64 && { autoscroll: (
          /*gradio*/
          u[6].autoscroll
        ) },
        _ & /*gradio*/
        64 && { i18n: (
          /*gradio*/
          u[6].i18n
        ) },
        _ & /*loading_status*/
        32 && Gr(
          /*loading_status*/
          u[5]
        ),
        s[3]
      ]) : {};
      t.$set(d);
      const m = {};
      _ & /*value*/
      16 && (m.value = /*value*/
      u[4]), _ & /*elem_classes*/
      4 && (m.elem_classes = /*elem_classes*/
      u[2]), _ & /*visible*/
      8 && (m.visible = /*visible*/
      u[3]), _ & /*autoscroll*/
      4096 && (m.autoscroll = /*autoscroll*/
      u[12]), _ & /*selectable_elements*/
      8192 && (m.selectable_elements = /*selectable_elements*/
      u[13]), r.$set(m), (!l || _ & /*padding*/
      2048) && ot(
        i,
        "padding",
        /*padding*/
        u[11]
      ), (!l || _ & /*loading_status*/
      32) && ot(
        i,
        "pending",
        /*loading_status*/
        ((b = u[5]) == null ? void 0 : b.status) === "pending"
      ), _ & /*min_height, loading_status*/
      288 && rt(
        i,
        "min-height",
        /*min_height*/
        u[8] && /*loading_status*/
        ((v = u[5]) == null ? void 0 : v.status) !== "pending" ? it(
          /*min_height*/
          u[8]
        ) : void 0
      ), _ & /*max_height*/
      512 && rt(
        i,
        "max-height",
        /*max_height*/
        u[9] ? it(
          /*max_height*/
          u[9]
        ) : void 0
      );
    },
    i(u) {
      l || (Ae(o), Ae(t.$$.fragment, u), Ae(r.$$.fragment, u), l = !0);
    },
    o(u) {
      Ne(o), Ne(t.$$.fragment, u), Ne(r.$$.fragment, u), l = !1;
    },
    d(u) {
      u && (lt(e), lt(n), lt(i)), o && o.d(u), bt(t, u), bt(r);
    }
  };
}
function Wr(a) {
  let e, t;
  return e = new Sa({
    props: {
      visible: (
        /*visible*/
        a[3]
      ),
      elem_id: (
        /*elem_id*/
        a[1]
      ),
      elem_classes: (
        /*elem_classes*/
        a[2]
      ),
      container: (
        /*container*/
        a[10]
      ),
      padding: !1,
      $$slots: { default: [Xr] },
      $$scope: { ctx: a }
    }
  }), {
    c() {
      gt(e.$$.fragment);
    },
    l(n) {
      mt(e.$$.fragment, n);
    },
    m(n, i) {
      vt(e, n, i), t = !0;
    },
    p(n, [i]) {
      const r = {};
      i & /*visible*/
      8 && (r.visible = /*visible*/
      n[3]), i & /*elem_id*/
      2 && (r.elem_id = /*elem_id*/
      n[1]), i & /*elem_classes*/
      4 && (r.elem_classes = /*elem_classes*/
      n[2]), i & /*container*/
      1024 && (r.container = /*container*/
      n[10]), i & /*$$scope, padding, loading_status, min_height, max_height, value, elem_classes, visible, autoscroll, selectable_elements, gradio, show_label, label*/
      277501 && (r.$$scope = { dirty: i, ctx: n }), e.$set(r);
    },
    i(n) {
      t || (Ae(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ne(e.$$.fragment, n), t = !1;
    },
    d(n) {
      bt(e, n);
    }
  };
}
function Kr(a, e, t) {
  let { label: n = "HTML" } = e, { elem_id: i = "" } = e, { elem_classes: r = [] } = e, { visible: l = !0 } = e, { value: o = "" } = e, { loading_status: s } = e, { gradio: c } = e, { show_label: u = !1 } = e, { min_height: _ = void 0 } = e, { max_height: d = void 0 } = e, { container: m = !1 } = e, { padding: b = !0 } = e, { autoscroll: v = !1 } = e, { selectable_elements: y = null } = e;
  const w = () => c.dispatch("clear_status", s), f = () => c.dispatch("change"), p = () => c.dispatch("click"), h = (g) => c.dispatch("select", g.detail);
  return a.$$set = (g) => {
    "label" in g && t(0, n = g.label), "elem_id" in g && t(1, i = g.elem_id), "elem_classes" in g && t(2, r = g.elem_classes), "visible" in g && t(3, l = g.visible), "value" in g && t(4, o = g.value), "loading_status" in g && t(5, s = g.loading_status), "gradio" in g && t(6, c = g.gradio), "show_label" in g && t(7, u = g.show_label), "min_height" in g && t(8, _ = g.min_height), "max_height" in g && t(9, d = g.max_height), "container" in g && t(10, m = g.container), "padding" in g && t(11, b = g.padding), "autoscroll" in g && t(12, v = g.autoscroll), "selectable_elements" in g && t(13, y = g.selectable_elements);
  }, [
    n,
    i,
    r,
    l,
    o,
    s,
    c,
    u,
    _,
    d,
    m,
    b,
    v,
    y,
    w,
    f,
    p,
    h
  ];
}
class WE extends Nr {
  constructor(e) {
    super(), Vr(this, e, Kr, Wr, Yr, {
      label: 0,
      elem_id: 1,
      elem_classes: 2,
      visible: 3,
      value: 4,
      loading_status: 5,
      gradio: 6,
      show_label: 7,
      min_height: 8,
      max_height: 9,
      container: 10,
      padding: 11,
      autoscroll: 12,
      selectable_elements: 13
    });
  }
}
export {
  WE as default
};
