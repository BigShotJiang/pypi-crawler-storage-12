"""Onyx API exceptions."""
