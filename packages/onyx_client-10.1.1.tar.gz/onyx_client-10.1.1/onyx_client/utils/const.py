"""Constants for the Onyx Client."""

API_URL = "https://api.hella.link"
API_HEADERS = {
    "Content-Type": "application/json",
}
API_VERSION = "v3"
