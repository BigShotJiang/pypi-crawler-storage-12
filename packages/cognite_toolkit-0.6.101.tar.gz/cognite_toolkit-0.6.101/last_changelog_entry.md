## cdf 

### Added

- Added automatic dependency resolution for data model instances based
on container constraints when `data upload`
- Added a new topological sorting method
`topological_sort_container_constraints` to `ViewCRUD` based on
container constraints, in addition to the existing method that considers
`implements`

### Changed

- Renamed `topological_sort` in `ViewCRUD` to
`topological_sort_implements` to distinguish between the new method.

## templates

No changes.