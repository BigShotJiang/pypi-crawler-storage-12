- [Foodles](https://www.foodles.co)

  > - Pierre Verkest \<pierreverkest84@gmail.com\>

- Florian da Costa \<florian.dacosta@akretion.com\>
- [Tecnativa](https://www.tecnativa.com):

  - Christian Ramos
