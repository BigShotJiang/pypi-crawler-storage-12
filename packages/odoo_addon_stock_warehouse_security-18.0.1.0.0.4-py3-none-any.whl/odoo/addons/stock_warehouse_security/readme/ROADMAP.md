- test make sure default warehouse can still be set if user also sales
  goods but processus is not unit-tested
- Add unitest test to ensure transit goods between warehouses still
  working
