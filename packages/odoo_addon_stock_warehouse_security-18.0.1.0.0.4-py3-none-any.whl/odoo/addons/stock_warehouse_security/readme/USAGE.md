Each user administrators is able to defined allowed warehouse.

No warehouse define in such list means no restrictions.
