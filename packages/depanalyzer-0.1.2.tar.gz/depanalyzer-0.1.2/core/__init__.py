# Core orchestration layer - Main workflow coordination







