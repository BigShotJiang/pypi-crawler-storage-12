# Depanalyzer - 依赖关系分析工具

## 📁 项目架构

项目采用模块化分层架构，按功能组织代码：

```
depanalyzer/
├── main.py                 # 主入口点
├── app/                    # 应用层
│   └── run.py             # CLI接口和命令行参数处理
├── core/                   # 核心编排层
│   └── orchestrator.py    # 主要的工作流协调器
├── tasks/                  # 任务管理层
│   ├── task_system.py     # 任务调度和依赖管理
│   ├── enhanced_task_builder.py  # 增强任务构建器
│   └── parse_types.py     # 解析任务类型定义
├── dependencies/           # 依赖管理层
│   └── dependency_manager.py  # 第三方依赖管理
├── base/                   # 基础层
│   ├── base.py            # 抽象基类和通用功能
│   └── registry.py        # 解析器注册和发现
├── parsers/               # 解析器层
│   ├── cpp/               # C/C++ 解析器
│   │   ├── code_parser.py
│   │   └── config_parser.py
│   └── hvigor/            # HarmonyOS/TypeScript 解析器
│       ├── code_parser.py
│       └── config_parser.py
├── utils/                 # 工具层
│   ├── fs.py              # 文件系统工具
│   ├── graph.py           # 图数据结构管理
│   └── structure.py       # 结构化数据工具
└── pyproject.toml         # 项目配置
```

## 🏗️ 架构层次说明

### 1. **应用层** (`app/`)
- **职责**: 提供用户接口，处理命令行参数和程序入口
- **主要组件**: `run.py` - CLI接口实现

### 2. **核心编排层** (`core/`)
- **职责**: 协调整个分析流程，管理各个组件的交互
- **主要组件**: `orchestrator.py` - 主要工作流协调器

### 3. **任务管理层** (`tasks/`)
- **职责**: 实现复杂的任务调度，支持任务依赖关系和动态任务生成
- **主要组件**:
  - `task_system.py` - 任务调度器核心
  - `enhanced_task_builder.py` - 支持第三方依赖的任务构建器
  - `parse_types.py` - 解析任务类型定义

### 4. **依赖管理层** (`dependencies/`)
- **职责**: 处理第三方库的拉取、缓存和递归依赖解析
- **主要组件**: `dependency_manager.py` - 依赖管理器

### 5. **基础层** (`base/`)
- **职责**: 提供抽象基类、通用功能和解析器管理
- **主要组件**:
  - `base.py` - 抽象解析器基类
  - `registry.py` - 解析器注册和自动发现

### 6. **解析器层** (`parsers/`)
- **职责**: 特定语言的代码解析实现
- **支持语言**:
  - `cpp/` - C/C++ 语言解析器
  - `hvigor/` - HarmonyOS/TypeScript 解析器

### 7. **工具层** (`utils/`)
- **职责**: 提供通用工具函数和数据结构
- **主要组件**:
  - `fs.py` - 文件系统操作
  - `graph.py` - 图数据结构管理
  - `structure.py` - 结构化数据处理

## 🚀 使用方法

```bash
# 运行依赖分析
python main.py --repo /path/to/repo --out output.json --workers 8 --max-depth 3
```

### 参数说明:
- `--repo`: 要分析的仓库根目录
- `--out`: 输出图文件(.json 或 .gml格式)
- `--workers`: 最大并行工作线程数(默认:8)
- `--max-depth`: 第三方依赖递归深度(默认:3)

## 📊 核心特性

- **多语言支持**: 插件式解析器架构，易于扩展新语言
- **并发处理**: 多线程任务调度，充分利用系统资源
- **依赖管理**: 完整的第三方依赖解析链，支持缓存和递归
- **图形化输出**: 统一的图数据格式，支持JSON和GML导出
- **错误处理**: 全面的异常处理和降级策略

## 🔧 扩展新语言解析器

1. 在 `parsers/` 下创建新的语言文件夹
2. 实现 `code_parser.py` (必需) 和 `config_parser.py` (可选)
3. 继承 `BaseCodeParser` 和 `BaseConfigParser` 类
4. 重写解析方法，解析器会被自动发现和注册

## 📈 架构优势

- **清晰的职责分离**: 每个层次都有明确的职责边界
- **高度模块化**: 组件间耦合度低，易于维护和扩展
- **可扩展性**: 插件式架构支持快速添加新功能
- **并发安全**: 线程安全的设计支持高效并行处理






## 📦 安装与运行

### 1) 使用 pip 本地安装

```bash
pip install .
# 或开发模式安装
pip install -e .
```

安装完成后将自动生成 CLI：

```bash
# 依赖关系分析（基础）
depanalyzer --repo /path/to/repo --out output.json --workers 8 --max-depth 3

# 启用许可证检测与兼容性检查
depanalyzer \
  --repo /path/to/repo \
  --out output.json \
  --enable-license-check \
  --scancode-cmd scancode \
  --license-map-out license_map.json \
  --license-out compatible.json
```

环境与依赖说明：
- 需要 Python >=3.12, <=3.14
- 若启用 `--enable-license-check`，需系统可执行 `scancode`（建议安装 ScanCode 工具），并且会使用内置的 `liscopelens` 模块进行兼容性分析

### 2) 作为模块调用

```python
from core.orchestrator import Orchestrator

orch = Orchestrator("/path/to/repo", max_workers=8, max_dependency_depth=3)
graph = orch.run()
graph.save("output.json", save_format="json")
```

### 3) 常见问题
- 若 `depanalyzer` 命令不可用，请确认安装过程无报错，并确保 Python 的脚本目录在 `PATH` 中
- 许可证相关命令需要外部工具 `scancode` 可用


