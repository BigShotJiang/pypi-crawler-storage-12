# Base layer - Abstract classes and common functionality
