"""Utility helpers for file system, graphs and structure handling."""


