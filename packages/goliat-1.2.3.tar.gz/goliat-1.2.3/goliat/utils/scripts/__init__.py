"""Utility scripts for GOLIAT."""
