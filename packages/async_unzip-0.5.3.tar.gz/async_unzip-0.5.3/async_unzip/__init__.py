"""Version definition to track changes"""
__version__ = "0.5.3"
