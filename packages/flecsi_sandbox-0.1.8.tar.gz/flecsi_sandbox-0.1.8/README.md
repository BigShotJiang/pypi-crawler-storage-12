# FleCSI Sandbox Package (flecsi_sandbox)

The _flecsi_sandbox_ package provides the _skelf_ tool to create skeleton
FleCSI-based application projects, suitable for experimentation or as the
starting point for a real application.
