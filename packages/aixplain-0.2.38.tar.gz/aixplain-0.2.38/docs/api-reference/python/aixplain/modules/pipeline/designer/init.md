---
draft: true
sidebar_label: designer
title: aixplain.modules.pipeline.designer
---

