class AnamException(Exception):
    """Custom exception for Anam API errors."""

    pass
