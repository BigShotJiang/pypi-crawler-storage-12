class IncarnationNotFoundError(Exception):
    pass


class IncarnationAlreadyExistsError(Exception):
    pass
