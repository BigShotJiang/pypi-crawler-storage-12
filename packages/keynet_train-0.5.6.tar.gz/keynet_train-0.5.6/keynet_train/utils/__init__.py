"""Utility modules for keynet-train."""

from keynet_train.utils.paths import DatasetPath

__all__ = ["DatasetPath"]
