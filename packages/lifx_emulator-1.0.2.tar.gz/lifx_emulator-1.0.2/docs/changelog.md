# CHANGELOG

<!-- version list -->

## v1.0.2 (2025-11-10)

### Bug Fixes

- Extended_multizone added to products correctly by generator
  ([`b6c4f78`](https://github.com/Djelibeybi/lifx-emulator/commit/b6c4f78c7353313b961acdb4283023a595141151))


## v1.0.1 (2025-11-10)

### Bug Fixes

- Scenarios are now properly applied to initial devices
  ([`4808512`](https://github.com/Djelibeybi/lifx-emulator/commit/480851231dbfe6c01b215e3938fa8067c9864227))

### Documentation

- Replace lifx-async with lifx-emulator and update README.md
  ([`64ab6b6`](https://github.com/Djelibeybi/lifx-emulator/commit/64ab6b62dae6422774d8dc72f8f8020f0b6bb705))


## v1.0.0 (2025-11-06)

- Initial Release
