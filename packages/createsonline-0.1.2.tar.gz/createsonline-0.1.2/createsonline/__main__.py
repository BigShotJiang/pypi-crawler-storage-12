"""
CREATESONLINE Package Entry Point
Allows running: python -m createsonline
"""

from .cli.main import run_cli

if __name__ == "__main__":
    run_cli()
