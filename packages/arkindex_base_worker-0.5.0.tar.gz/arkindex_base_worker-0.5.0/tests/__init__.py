from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
FIXTURES_DIR = BASE_DIR / "data"
SAMPLES_DIR = BASE_DIR / "samples"

CORPUS_ID = "11111111-1111-1111-1111-111111111111"
PROCESS_ID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeffff"
