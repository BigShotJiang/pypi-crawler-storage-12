# API calls during worker configuration
BASE_API_CALLS = [
    (
        "GET",
        "http://testserver/api/v1/process/workers/56785678-5678-5678-5678-567856785678/",
    ),
]
