#!/usr/bin/env python3
# -*- coding:utf-8 -*-

HELP_PANEL_RETROSYNTHESIS_COMMANDS: str = "Retrosynthesis Operations"
"""Panel title shown in --help for the retrosynthesis commands."""
HELP_PANEL_BATCH_OPERATIONS: str = "Batch Operations"
"""Panel title shown in --help for the retrosynthesis commands."""
