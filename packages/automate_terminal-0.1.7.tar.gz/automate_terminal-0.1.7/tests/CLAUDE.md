Do not write tests that invoke subprocesses or assert that specific AppleScript was run. Test coverage of those things is an anti-goal.
