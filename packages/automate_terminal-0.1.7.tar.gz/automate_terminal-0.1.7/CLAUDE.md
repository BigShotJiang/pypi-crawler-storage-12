Avoid writing bold text in Markdown.

Avoid writing docstring comments if the purpose of the symbol is self-evident.
