#!/bin/bash
sphinx-apidoc -o source/ ../dfttoolkit
sphinx-apidoc -o source/ ../dfttoolkit/utils
