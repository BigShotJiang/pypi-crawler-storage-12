class TestBenchmarking: ...  # noqa: D101



# ruff: noqa: ANN001, S101, ERA001
