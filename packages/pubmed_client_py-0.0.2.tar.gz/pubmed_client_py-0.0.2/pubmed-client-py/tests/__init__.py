"""Test suite for pubmed-client Python bindings."""
