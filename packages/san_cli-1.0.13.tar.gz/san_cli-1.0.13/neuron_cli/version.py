"""Version information for Neuron CLI"""

__version__ = "1.0.13"  # SAN CLI (SPACE Agent Neuron CLI) - Secure Registry + Auto-Config
__author__ = "Kai Gartner (https://linkedin.com/in/kaigartner)"
__license__ = "Commercial - All Rights Reserved"
