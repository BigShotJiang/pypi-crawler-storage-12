"""ReAlign - Track and version AI agent chat sessions with git commits."""

__version__ = "0.4.0"
