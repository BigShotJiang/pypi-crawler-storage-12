.. _format:

**Version** |release| |today|

.. .. contents::

.. include:: _format_auto_docs/format_spec_main.inc
