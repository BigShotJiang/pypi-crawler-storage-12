*******
Credits
*******

Authors
=======

- Andrew Tritt
- Oliver Ruebel
- Ryan Ly
- Ben Dichter
- Matthew Avaylon

*****
Legal
*****

Copyright
=========

.. include:: ../../Legal.txt

License
=======

.. include:: ../../license.txt
