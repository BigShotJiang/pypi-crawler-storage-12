I want to further split and untangle this.

As I do mainly Java, I think in classes, might not always be applicable to python.

But for me what I wrote below should be the architecture.

Now this is to much to ask from you in one go - the would be a mess of misunderstandings probably.


So please.
1. read the architecture document
2. I will give you my existing PoC files (might take 2 prompts)
3. ask me questions if anything is unclear
4. make a plan to proceed in sane, safe steps to guide me.
5. Give me a clear structure (file/folder layout, python packages) for approval
6. Give me ONE new code file. ONE FILE AT A TIME! I review and aprove it.
7. Repeat 6. until I have all files
8. I run the programm and give you test-results
9. You help me fix errors/bugs. We repeat 8.
10. We document the programm.

Understood? Ready?
