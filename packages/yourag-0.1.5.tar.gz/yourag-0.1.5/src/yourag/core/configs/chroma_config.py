persistent_client_path: str = ".stores/chroma/"
