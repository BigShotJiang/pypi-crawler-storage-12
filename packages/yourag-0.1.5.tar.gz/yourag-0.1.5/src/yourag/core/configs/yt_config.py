YOUTUBE_SECRET_JSON_FILE = ".credentials/client_secret_2_148309037342-ruubm8naots2jnerblejpp6pa0itdr03.apps.googleusercontent.com.json"
CREDENTIALS_PICKLE_FILE = ".credentials/yourag_youtube_token.pickle"
OAUTH_ENABLED = True
