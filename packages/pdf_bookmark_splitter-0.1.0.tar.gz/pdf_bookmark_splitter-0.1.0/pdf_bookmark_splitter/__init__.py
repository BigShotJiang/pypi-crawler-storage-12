"""PDF Bookmark Splitter

A tool for splitting PDF files based on bookmarks.
"""

__version__ = "0.1.0"
