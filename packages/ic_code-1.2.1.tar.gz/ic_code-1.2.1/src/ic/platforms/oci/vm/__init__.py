#!/usr/bin/env python3
"""OCI VM (Instance) info commands"""
from .info import add_arguments, main 