#!/usr/bin/env python3
"""
GCP Google Kubernetes Engine (GKE) 모듈

이 모듈은 GCP GKE 클러스터 정보를 조회하고 관리하는 기능을 제공합니다.
"""

__version__ = "1.0.0"
__author__ = "IC CLI Team"