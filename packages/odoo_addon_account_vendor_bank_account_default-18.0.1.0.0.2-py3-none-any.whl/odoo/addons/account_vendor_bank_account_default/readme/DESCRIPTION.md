This module allows you to set a default bank account on partners for their vendor bills.
