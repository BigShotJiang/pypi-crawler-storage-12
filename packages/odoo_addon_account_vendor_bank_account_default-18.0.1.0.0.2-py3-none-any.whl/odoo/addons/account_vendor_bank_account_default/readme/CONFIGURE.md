To configure this module, you need to:

-  Go to a partner form view, and edit the Default Bank Account in the
   Sales and Purchase tab. The partner must be of type 'company', or an
   individual without a parent company. 

   **Note:** If you do not set this value, it will be equal to the first 
   bank account created in the contact. This is the standard behaviour of Odoo

-  You can disable the default bank account option at contact level, unmarking the 
   "Has Default Bank Account" check.
