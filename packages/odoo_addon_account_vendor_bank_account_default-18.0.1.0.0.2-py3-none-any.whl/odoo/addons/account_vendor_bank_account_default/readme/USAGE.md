To use this module, you need to:

1. Create a vendor bill and select a partner with a default bank account. Its recipient bank account will be the default one.
