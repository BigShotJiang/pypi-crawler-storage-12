"""Framework interfaces package.

This package contains user interface implementations for the Osprey Framework.
"""

