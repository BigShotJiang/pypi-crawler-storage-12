from .redvid import Downloader

__name__ = 'redvid.redvid.Downloader'
__author__ = 'Khaled H. El-Morshedy'
__url__ = 'https://github.com/elmoiv/redvid'
__description__ = 'Smart downloader for Reddit hosted videos'
__license__ = 'GPL-v3.0'
__version__ = '2.0.6'

