from redvid import Downloader

reddit = Downloader()
reddit.max = True
reddit.url = 'https://www.reddit.com/r/N_N_N/comments/hj4qxb/explosion_at_sina_athar_hospital_17_reported_dead/'
reddit.download()