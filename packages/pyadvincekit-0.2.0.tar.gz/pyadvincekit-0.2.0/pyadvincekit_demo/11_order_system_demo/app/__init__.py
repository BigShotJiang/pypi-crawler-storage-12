"""
PyAdvanceKit Admin Backend

基于PyAdvanceKit框架构建的管理系统后端API服务。
"""

__version__ = "1.0.0"
__author__ = "PyAdvanceKit Team"














