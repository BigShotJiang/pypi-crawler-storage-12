"""Deprecated OpenProtein APIs."""

from . import design, predict, train

__all__ = ["design", "predict", "train"]
