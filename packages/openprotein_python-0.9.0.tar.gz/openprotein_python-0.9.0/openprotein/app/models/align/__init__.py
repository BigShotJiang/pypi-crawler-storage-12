"""App-level models for align."""

from .base import AlignFuture
from .msa import MSAFuture
