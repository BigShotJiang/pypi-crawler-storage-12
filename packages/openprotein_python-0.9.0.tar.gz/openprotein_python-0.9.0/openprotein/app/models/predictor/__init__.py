"""OpenProtein app-level models for predictor."""

from .predict import PredictionResultFuture
from .predictor import PredictorModel
