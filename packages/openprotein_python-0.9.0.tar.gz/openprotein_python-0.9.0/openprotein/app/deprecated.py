"""
Deprecated OpenProtein interfaces.
"""

# old workflow apis
from .services.deprecated.design import DesignAPI
from .services.deprecated.predict import PredictAPI
from .services.deprecated.train import TrainingAPI
