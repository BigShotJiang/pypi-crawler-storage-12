from .flow_controller import FlowController

def main():
    flow = FlowController()
    flow.run()

if __name__ == "__main__":
    main()
