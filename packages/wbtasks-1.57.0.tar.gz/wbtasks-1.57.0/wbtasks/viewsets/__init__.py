from wbtasks.viewsets.buttons import TaskButtonConfig
from wbtasks.viewsets.display import TaskDisplayConfig
from wbtasks.viewsets.titles import TaskTitleConfig
