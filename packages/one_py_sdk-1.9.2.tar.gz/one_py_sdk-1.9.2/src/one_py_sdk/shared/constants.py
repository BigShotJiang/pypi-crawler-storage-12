Environment = {"feature": "https://api-feature-us.aquaticinformatics.net", "integration": "https://api-integration-us.aquaticinformatics.net",
               "stage": "https://api-stage-us.aquaticinformatics.net", "production": "https://api-us.aquaticinformatics.net/"}
