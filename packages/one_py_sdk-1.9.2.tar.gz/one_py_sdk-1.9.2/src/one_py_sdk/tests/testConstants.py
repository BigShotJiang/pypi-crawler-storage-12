writePlantId = "0c8ab848-cd62-44a9-9ac4-fe012e8ed592"
readPlantId = "0c8ab848-cd62-44a9-9ac4-fe012e8ed592"
plantId = "0c8ab848-cd62-44a9-9ac4-fe012e8ed592"
