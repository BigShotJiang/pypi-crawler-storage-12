import sys
from .auto_forge import main

def main_cli():
    main()

if __name__ == "__main__":
    main_cli()