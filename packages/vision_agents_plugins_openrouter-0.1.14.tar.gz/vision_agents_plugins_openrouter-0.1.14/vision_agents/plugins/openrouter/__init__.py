
from .openrouter_llm import OpenRouterLLM as LLM

__all__ = ["LLM"]

