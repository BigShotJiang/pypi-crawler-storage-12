# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Literal, Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["LinkCreateTanParams", "Config"]


class LinkCreateTanParams(TypedDict, total=False):
    account_type: Required[Literal["checking", "savings"]]

    customer_id: Required[str]
    """Unique identifier of the related customer object."""

    routing_number: Required[str]
    """Bank routing number."""

    tan: Required[str]
    """Tokenized account number."""

    config: Config

    external_id: Optional[str]
    """
    Unique identifier for the paykey in your database, used for cross-referencing
    between Straddle and your systems.
    """

    metadata: Optional[Dict[str, str]]
    """Up to 20 additional user-defined key-value pairs.

    Useful for storing additional information about the paykey in a structured
    format.
    """

    correlation_id: Annotated[str, PropertyInfo(alias="Correlation-Id")]

    idempotency_key: Annotated[str, PropertyInfo(alias="Idempotency-Key")]

    request_id: Annotated[str, PropertyInfo(alias="Request-Id")]

    straddle_account_id: Annotated[str, PropertyInfo(alias="Straddle-Account-Id")]


class Config(TypedDict, total=False):
    processing_method: Literal["inline", "background", "skip"]

    sandbox_outcome: Literal["standard", "active", "rejected", "review"]
