.. splineops/examples/02_resampling_using_1d_interpolation/GALLERY_HEADER.rst

Resampling using 1D Samples
===========================

Examples using the Resize module on 1D samples.
