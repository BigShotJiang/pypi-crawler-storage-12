# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

from __future__ import annotations

from logging import getLogger


LOGGER = getLogger(__name__.rsplit(".", maxsplit=1)[0])
