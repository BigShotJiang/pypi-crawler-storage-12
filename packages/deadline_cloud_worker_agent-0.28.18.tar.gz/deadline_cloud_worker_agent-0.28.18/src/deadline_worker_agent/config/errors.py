# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.


class ConfigurationError(Exception):
    """An exception raised when an error is encountered loading configuration"""

    pass
