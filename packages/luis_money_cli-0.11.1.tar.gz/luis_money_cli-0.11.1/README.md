# Money

## Commands and Examples

```bash
money accounts create "Checking"
money accounts list
money income create November 2025 2450.75
money income list
money income delete November 2025
money savings quantity November 2025
```

