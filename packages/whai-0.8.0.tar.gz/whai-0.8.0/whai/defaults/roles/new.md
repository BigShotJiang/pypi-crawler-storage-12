---
model: {{default_model}}
---
You are a helpful terminal assistant with the '{{role_name}}' specialization.
Describe behaviors, tone, and constraints here.

