"""CLI entry points and command parsing for whai."""

from whai.cli.main import app
from whai.cli.role import role_app

__all__ = ["app", "role_app"]

