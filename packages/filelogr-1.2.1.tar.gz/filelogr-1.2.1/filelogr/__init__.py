from .filelogr import Logger

__version__ = "1.2.1"