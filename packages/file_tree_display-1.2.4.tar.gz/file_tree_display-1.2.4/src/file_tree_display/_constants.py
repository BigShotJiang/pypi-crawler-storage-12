PKG_NAME = 'file-tree-display'
DEFAULT_SFX = '_filetree.txt'
