from __future__ import annotations

from setuptools import setup

setup(name="small_fake_a", version=0.1)
