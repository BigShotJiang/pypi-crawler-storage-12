# Just do something dumb to trigger an exception
x = 1 / 0
