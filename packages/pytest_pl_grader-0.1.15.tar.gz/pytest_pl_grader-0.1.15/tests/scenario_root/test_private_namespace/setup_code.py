a = 42
super_secret_value = 10


def weird_func(a):
    return a + 20


def f(a):
    return a + 1


numpy_array = __from_server_json(__data_params["target_numpy_array"])
