c = a
a = 10
b["c"] = 50
d = f(10)
numpy_array
