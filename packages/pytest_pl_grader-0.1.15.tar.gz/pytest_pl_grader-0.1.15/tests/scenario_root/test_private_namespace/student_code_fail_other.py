a = other_secret_value
