largest_fp = 2**7 * (1 - 2 ** (-4))
machine_epsilon = 2 ** (-3)
