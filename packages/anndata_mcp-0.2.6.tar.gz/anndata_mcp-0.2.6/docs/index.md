```{include} ../README.md

```

```{toctree}
:caption: API Documentation
:maxdepth: 2
:glob:

autoapi/anndata_mcp/index
```
