from mecha.cli import main

main()
