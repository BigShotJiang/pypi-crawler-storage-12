__all__ = [
    "MechaError",
]


class MechaError(Exception):
    """Base class for all mecha errors."""
