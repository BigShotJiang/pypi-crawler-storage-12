"""Python SDK code generator."""
