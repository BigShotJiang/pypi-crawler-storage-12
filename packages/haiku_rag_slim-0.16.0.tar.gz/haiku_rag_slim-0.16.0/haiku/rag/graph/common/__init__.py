"""Common utilities for graph implementations."""

from haiku.rag.graph.common.utils import get_model

__all__ = ["get_model"]
