- Angel Moya \<<angel.moya@domatix.com>\>

- Dave Lasley \<<dave@laslabs.com>\>

- Miquel Raïch \<<miquel.raich@eficent.com>\>

- Souheil Bejaoui \<<souheil.bejaoui@acsone.eu>\>

- Thomas Binsfeld \<<thomas.binsfeld@acsone.eu>\>

- Guillaume Vandamme \<<guillaume.vandamme@acsone.eu>\>

- Raphaël Reverdy \<<raphael.reverdy@akretion.com>\>

- [Tecnativa](https://www.tecnativa.com):

  > - Pedro M. Baeza
  > - Carlos Dauden
  > - Vicent Cubells
  > - Rafael Blasco
  > - Víctor Martínez

- Iván Antón \<<ozono@ozonomultimedia.com>\>

- [APSL](https://www.apsl.tech):

  > - Antoni Marroig \<<amarroig@apsl.net>\>
