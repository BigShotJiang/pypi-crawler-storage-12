This module enables contracts management with recurring invoicing
functions. Also you can print and send by email contract report.

It works for customer contract and supplier contracts.

Contracts are shown in portal.
