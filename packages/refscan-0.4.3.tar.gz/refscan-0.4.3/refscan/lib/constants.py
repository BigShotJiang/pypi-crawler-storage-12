from rich.console import Console

# Instantiate a Rich console for fancy console output.
# Reference: https://rich.readthedocs.io/en/stable/console.html
console = Console()

# Note: This is the only schema class name hard-coded into this script.
DATABASE_CLASS_NAME = "Database"
