import enum


class TimeSyncProtocol(enum.Enum):

    NTP = "NTP"
