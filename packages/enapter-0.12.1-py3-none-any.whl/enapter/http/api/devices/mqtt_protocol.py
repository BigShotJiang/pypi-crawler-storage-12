import enum


class MQTTProtocol(enum.Enum):

    MQTT = "MQTT"
    MQTTS = "MQTTS"
