render = 'JSON'
source = 'national'

# PG/M/1/055758
appnum_mask = 'PG/M/1/(\\d*)'
