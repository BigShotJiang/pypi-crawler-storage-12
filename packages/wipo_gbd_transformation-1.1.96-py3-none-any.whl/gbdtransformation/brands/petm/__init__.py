# instruction to render the output to JSON format
render = 'JSON'
source = 'national'

# 000929225-2021
appnum_mask = '[0]*([1-9]\\d*[A-Z]?[A-Z]?)\\-?(\\d{4})'
