# instruction to render the output to JSON format
render = 'JSON'
source = 'national'

# 05880/1977
appnum_mask = '(\\d*)/\\d{4}'
