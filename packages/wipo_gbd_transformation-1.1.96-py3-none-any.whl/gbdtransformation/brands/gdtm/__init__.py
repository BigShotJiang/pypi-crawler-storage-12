render = 'JSON'
source = 'national'

# AE/321890
appnum_mask = ['GD/T/(\\d{4})/(\\d*)', 'GD/T/(\\d*)/(\\d*)']
