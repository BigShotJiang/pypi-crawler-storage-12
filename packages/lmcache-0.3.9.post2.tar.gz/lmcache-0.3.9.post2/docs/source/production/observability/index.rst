.. _observability:

Observability
=============

.. toctree::
   :maxdepth: 2

   vllm_endpoint
   internal_api_server
