#include <string>

std::string get_gpu_pci_bus_id(int device);
