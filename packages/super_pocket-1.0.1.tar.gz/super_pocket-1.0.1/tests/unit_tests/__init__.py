"""
Unit tests for Pocket modules.
"""
