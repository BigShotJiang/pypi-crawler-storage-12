"""
Development cheat sheets.
"""
