# agent

Activate agent-architect (see .claude/agents/agent-architect.md) 