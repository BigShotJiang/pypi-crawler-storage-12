pocket.web
==========

.. automodule:: pocket.web

   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   favicon
   job_search
