pocket.templates\_and\_cheatsheets.templates
============================================

.. automodule:: pocket.templates_and_cheatsheets.templates

   