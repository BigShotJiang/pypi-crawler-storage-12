pocket.web.job\_search
======================

.. automodule:: pocket.web.job_search

   
   .. rubric:: Functions

   .. autosummary::
   
      get_jobs
      save_jobs_to_json
   