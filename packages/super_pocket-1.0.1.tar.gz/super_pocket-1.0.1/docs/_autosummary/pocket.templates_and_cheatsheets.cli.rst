pocket.templates\_and\_cheatsheets.cli
======================================

.. automodule:: pocket.templates_and_cheatsheets.cli

   
   .. rubric:: Functions

   .. autosummary::
   
      get_available_items
   