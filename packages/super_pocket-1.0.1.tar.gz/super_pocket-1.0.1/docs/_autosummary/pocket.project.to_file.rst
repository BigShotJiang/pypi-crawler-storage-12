pocket.project.to\_file
=======================

.. automodule:: pocket.project.to_file

   
   .. rubric:: Functions

   .. autosummary::
   
      create_codebase_markdown
      generate_tree
      get_language_identifier
      main
   