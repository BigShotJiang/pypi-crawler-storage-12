pocket.web.favicon
==================

.. automodule:: pocket.web.favicon

   
   .. rubric:: Functions

   .. autosummary::
   
      convert_to_favicon
      main
   