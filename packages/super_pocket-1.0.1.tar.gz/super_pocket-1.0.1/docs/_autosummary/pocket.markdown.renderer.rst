pocket.markdown.renderer
========================

.. automodule:: pocket.markdown.renderer

   
   .. rubric:: Functions

   .. autosummary::
   
      read_markdown_file
      render_markdown
   