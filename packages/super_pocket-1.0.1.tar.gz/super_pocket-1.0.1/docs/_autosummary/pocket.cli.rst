pocket.cli
==========

.. automodule:: pocket.cli

   
   .. rubric:: Functions

   .. autosummary::
   
      main
   