pocket.templates\_and\_cheatsheets.cheatsheets
==============================================

.. automodule:: pocket.templates_and_cheatsheets.cheatsheets

   