﻿pocket
======

.. automodule:: pocket

   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   cli
   markdown
   pdf
   project
   templates_and_cheatsheets
   web
