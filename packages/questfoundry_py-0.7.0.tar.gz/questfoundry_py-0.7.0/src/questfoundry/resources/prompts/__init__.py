"""Bundled prompts for QuestFoundry roles."""
