"""Integration tests for QuestFoundry providers."""
