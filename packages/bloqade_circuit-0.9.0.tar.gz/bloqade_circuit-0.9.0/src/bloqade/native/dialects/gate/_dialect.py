from kirin import ir

dialect = ir.Dialect("native.gate")
