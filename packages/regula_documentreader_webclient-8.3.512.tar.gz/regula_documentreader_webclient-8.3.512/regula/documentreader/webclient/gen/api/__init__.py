# flake8: noqa

# import apis into api package
from regula.documentreader.webclient.gen.api.healthcheck_api import HealthcheckApi
from regula.documentreader.webclient.gen.api.process_api import ProcessApi
from regula.documentreader.webclient.gen.api.transaction_api import TransactionApi

