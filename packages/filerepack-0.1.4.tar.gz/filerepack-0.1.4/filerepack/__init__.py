# -*- coding: utf-8 -*-
__version__ = '0.1.4'
__author__ = "Ivan Begtin (ivan@begtin.tech)"
__license__ = "BSD"


from .repack import FileRepacker
