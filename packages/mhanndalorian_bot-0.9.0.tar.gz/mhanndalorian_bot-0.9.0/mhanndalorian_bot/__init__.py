"""
Basic SWGOH Mhanndalorian Bot package initialization
"""

from .api import API
from .attrs import EndPoint
from .registry import Registry
