# coding=utf-8
"""
Object models for the MBot API library
"""

from __future__ import annotations


class Guild:
    pass
