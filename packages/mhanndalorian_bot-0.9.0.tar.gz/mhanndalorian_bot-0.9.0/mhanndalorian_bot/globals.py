# coding=utf-8
"""
Global settings and variable for the Mhanndalorian Bot API library
"""

from __future__ import annotations

SWGOH_GG_BASE_URL = "https://swgoh.gg"
SWGOH_GG_GUILD_PATH = 'g'

