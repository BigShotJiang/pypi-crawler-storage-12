### Example Code

----
The folders contained here provide access to example code files for use of the MHanndalorian Bot library

[API](API) contains examples of how to use the authenticated API endpoints<br/>
[Registry](Registry) contains example of how to use the global Player Registry service