"""Adapters subpackage.

This module marks 'rnapolis.adapters' as a regular Python package so it is
discovered by setuptools and included in distributions.
"""

__all__: list[str] = []
