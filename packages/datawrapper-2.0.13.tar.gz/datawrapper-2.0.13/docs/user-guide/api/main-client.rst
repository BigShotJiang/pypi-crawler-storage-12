.. _main-client:

Main Client
===========

The main Datawrapper client provides methods for interacting with the Datawrapper API.

.. currentmodule:: datawrapper

.. autoclass:: Datawrapper
   :members:
   :inherited-members:
   :show-inheritance:
