"""Environment variable adapters for ``lib_layered_config``."""

from . import default

__all__ = ["default"]
