# apk-info-xml

A small library that allows you to build an XML DOM tree.
