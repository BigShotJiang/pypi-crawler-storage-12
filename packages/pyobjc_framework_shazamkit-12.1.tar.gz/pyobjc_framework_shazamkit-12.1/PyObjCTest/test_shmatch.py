from PyObjCTools.TestSupport import TestCase
import ShazamKit


class TestSHMatch(TestCase):
    def test_classes(self):
        ShazamKit.SHMatch

    def test_methods(self):
        # XXX
        # unavailable: -init, +new
        pass
