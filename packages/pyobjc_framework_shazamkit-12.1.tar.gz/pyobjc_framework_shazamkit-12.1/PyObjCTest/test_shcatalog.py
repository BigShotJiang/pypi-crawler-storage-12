from PyObjCTools.TestSupport import TestCase
import ShazamKit


class TestSHCatalog(TestCase):
    def test_classes(self):
        ShazamKit.SHCatalog

    def test_methods(self):
        # XXX
        # unavailable: -init, +new
        pass
