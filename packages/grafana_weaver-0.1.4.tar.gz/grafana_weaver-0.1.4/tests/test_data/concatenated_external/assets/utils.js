// EXTERNAL:utils.js
const utils = {render: () => {}};
