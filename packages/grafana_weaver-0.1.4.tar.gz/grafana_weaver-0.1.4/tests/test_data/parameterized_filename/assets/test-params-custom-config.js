// EXTERNAL({panel_id: "custom", key: "config"}):test-params-custom-config.js
const config = {
  theme: 'dark'
};
