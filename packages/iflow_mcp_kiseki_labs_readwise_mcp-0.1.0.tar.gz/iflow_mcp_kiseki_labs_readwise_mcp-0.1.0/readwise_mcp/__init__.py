# This file makes the readwise_mcp directory a proper Python package.
