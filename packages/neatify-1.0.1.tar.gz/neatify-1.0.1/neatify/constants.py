from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "neatify"
DEFAULT_FILE_PATH = CONFIG_DIR / "extensions.json"
