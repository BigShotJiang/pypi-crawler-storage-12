"""Neatify - A CLI tool to organize files by their extensions."""

__version__ = "1.0.1"
