"""Contract address mappings."""

from .contract_addresses import get_contract_address

__all__ = ["get_contract_address"]
