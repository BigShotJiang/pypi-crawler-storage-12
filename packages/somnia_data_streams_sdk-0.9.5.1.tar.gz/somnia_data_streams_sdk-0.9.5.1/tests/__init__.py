"""Tests for Somnia Streams SDK."""
