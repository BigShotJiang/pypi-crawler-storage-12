"""Google utils."""

from owid.datautils.google.api import GoogleApi

__all__ = [
    "GoogleApi",
]
