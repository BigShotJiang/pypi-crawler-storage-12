"""Library to support the work of the Data Team at Our World in Data."""

__version__ = "0.5.3"
