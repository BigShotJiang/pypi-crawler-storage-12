.. owid-datautils documentation master file, created by
   sphinx-quickstart on Wed Jun  1 23:00:03 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

owid-datautils
==========================================

.. toctree::
   :maxdepth: 2

   owid.datautils <api/datautils>