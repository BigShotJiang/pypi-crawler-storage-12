def main():
    print("Hello from example-project!")


if __name__ == "__main__":
    main()
