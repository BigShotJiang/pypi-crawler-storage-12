"""Interface adapters for CLI, REST, and MCP."""
