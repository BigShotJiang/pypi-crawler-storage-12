# My Lab Code Exporter

This package contains all of my university lab code. Its primary function is to export all the code into a single Python file for easy access.

## Installation

```bash
pip install lab-code-exporter-your-unique-name