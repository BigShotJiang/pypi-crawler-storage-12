# Architecture

moneyflow's pluggable backend architecture.

[Documentation coming soon]
