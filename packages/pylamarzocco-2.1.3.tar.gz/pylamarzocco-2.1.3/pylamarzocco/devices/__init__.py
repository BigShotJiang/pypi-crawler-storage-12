"""Init the devices module.

Currently not in use
"""

from ._machine import LaMarzoccoMachine
from ._thing import LaMarzoccoThing

__all__ = [
    "LaMarzoccoMachine",
    "LaMarzoccoThing",
]
