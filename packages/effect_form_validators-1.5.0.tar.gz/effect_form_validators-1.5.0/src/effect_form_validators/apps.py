from django.apps import AppConfig as DjangoAppConfig


class AppConfig(DjangoAppConfig):
    name = "effect_form_validators"
    verbose_name = "Effect Form Validators"
