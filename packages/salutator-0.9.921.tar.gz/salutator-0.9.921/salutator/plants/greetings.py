class Greeter:
    def __init__(self, name: str):
        self.name = name

    def salute(self):
        print(f"The {self.name} rustles its leaves softly in greeting.")

