class GoodByer:
    def __init__(self, name: str):
        self.name = name

    def salute(self):
        print(f"The {self.name} fades quietly into the shadows, bidding farewell.")

