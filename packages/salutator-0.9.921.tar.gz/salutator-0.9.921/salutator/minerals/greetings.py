class Greeter:
    def __init__(self, name: str):
        self.name = name

    def salute(self):
        print(f"The {self.name} gleams brightly under the light as if to say hello.")

