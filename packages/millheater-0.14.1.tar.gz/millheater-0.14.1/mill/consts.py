"""Constants used by pymill"""

__version__ = "0.14.1"
