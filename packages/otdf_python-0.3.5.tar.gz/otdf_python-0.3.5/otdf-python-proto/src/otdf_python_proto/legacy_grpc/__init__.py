"""legacy_grpc protobuf definitions."""
