"""common protobuf definitions."""
