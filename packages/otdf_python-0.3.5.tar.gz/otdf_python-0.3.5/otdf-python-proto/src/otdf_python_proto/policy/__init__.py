"""policy protobuf definitions."""
