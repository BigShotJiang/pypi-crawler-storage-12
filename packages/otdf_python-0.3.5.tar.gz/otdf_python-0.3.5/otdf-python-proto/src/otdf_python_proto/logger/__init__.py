"""logger protobuf definitions."""
