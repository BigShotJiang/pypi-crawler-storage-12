# Credits

This project owes its existence to the incredible [`mkdocstrings`](https://mkdocstrings.github.io/) and its primary handler [`mkdocstrings-python`](https://mkdocstrings.github.io/python/). Special thanks to [@paramoy](https://fosstodon.org/@pawamoy) for his efforts.

Moreover, `mkdocstrings` itself extends [`mkdocs`](https://www.mkdocs.org/) and [`mkdocs-material`](https://squidfunk.github.io/mkdocs-material/), which form the foundation of the entire mkdoc* suite of documentation tools.
