---
hide:
- feedback
---

<!-- This page is named license-page such that it won't show in the GitHub UI -->

# License

```
--8<-- "LICENSE"
```
