import kawaiitb.handlers.defaults as defaults
import kawaiitb.handlers.extensions as extensions
import kawaiitb.handlers.vanilla as vanilla

__all__ = [
    *defaults.__all__,
    *extensions.__all__,
    *vanilla.__all__,
]
