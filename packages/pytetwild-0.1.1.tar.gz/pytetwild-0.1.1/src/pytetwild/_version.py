"""Contains the pytetwild version."""

from importlib import metadata

__version__ = metadata.version("pytetwild")
