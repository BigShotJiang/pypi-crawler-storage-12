#ifndef FLOATTETWILD_GET_MEM_H
#define FLOATTETWILD_GET_MEM_H

#include <stddef.h>

namespace floatTetWild {
    size_t get_mem();
    size_t get_peak_mem();
}


#endif //FLOATTETWILD_GET_MEM_H
