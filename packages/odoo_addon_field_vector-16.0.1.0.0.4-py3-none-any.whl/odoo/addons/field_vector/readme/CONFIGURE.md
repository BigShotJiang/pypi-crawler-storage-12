[ This file is not always required; it should explain **how to configure the module before using it**; it is aimed at users with administration privileges. 

Please be detailed on the path to configuration (eg: do you need to activate developer mode?), describe step by step configurations and the use of screenshots is strongly recommended.]


To configure this module, you need to:

- Go to *App* > Menu > Menu item
- Activate boolean… > save
- …
