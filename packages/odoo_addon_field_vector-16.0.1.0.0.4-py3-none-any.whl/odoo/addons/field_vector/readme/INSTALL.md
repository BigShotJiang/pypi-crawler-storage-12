To install this module, you need to ensure that the [**pgvector**](https://github.com/pgvector/pgvector) extension is installed and available in your PostgreSQL instance.
