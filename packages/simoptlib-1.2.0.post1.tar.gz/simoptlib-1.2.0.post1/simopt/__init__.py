"""Init file for the simopt package."""
