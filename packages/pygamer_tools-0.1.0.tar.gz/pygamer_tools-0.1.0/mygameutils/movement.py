def move(sprite, dx, dy):
  sprite.x += dx
  sprite.y += dy