"""Initialize the app"""

__version__ = "0.3.1"
__title__ = "AA Memberaudit Doctrine Checker"

__package_name__ = "aa-memberaudit-dc"
__app_name__ = "madc"
__app_name_useragent__ = "AA-Memberaudit-DC"
__github_url__ = f"https://github.com/Geuthur/{__package_name__}"
