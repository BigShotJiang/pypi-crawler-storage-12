from koil.composition import Composition

from unlok_next.rath import UnlokRath


class Unlok(Composition):
    rath: UnlokRath
