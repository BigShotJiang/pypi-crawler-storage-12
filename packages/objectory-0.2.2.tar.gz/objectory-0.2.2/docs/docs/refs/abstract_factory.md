::: objectory.abstract_factory
