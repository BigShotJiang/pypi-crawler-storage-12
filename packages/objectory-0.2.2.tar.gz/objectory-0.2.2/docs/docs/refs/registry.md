::: objectory.registry
