from .dump.doku_dumper import dump

def main():
    dump()