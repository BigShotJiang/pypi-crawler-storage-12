from dokuWikiDumper.version import get_version
UPLOADER_VERSION = get_version()