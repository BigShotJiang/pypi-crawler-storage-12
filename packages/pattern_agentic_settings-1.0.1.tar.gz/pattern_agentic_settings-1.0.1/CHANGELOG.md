
# 1.0.1
	
Fixes:
  - set settings logger level to INFO
