Why use snakebids?
==================

Snakebids makes it easy to use Snakemake to break down a neuroimaging workflow into its component steps, while still providing a the standard command line interface of a BIDS app.
