# Migrations

Snakebids has rapidly evolved over the last few versions, resulting in a number of breaking changes. Use the following guides if you're migrating codes from old snakemake versions.

```{toctree}
:maxdepth: 1

0.5_to_0.8
0.7_to_0.8
0.11_to_0.12
```
