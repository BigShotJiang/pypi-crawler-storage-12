Dataset Creation
=======================================

.. currentmodule:: snakebids

.. autofunction:: generate_inputs
