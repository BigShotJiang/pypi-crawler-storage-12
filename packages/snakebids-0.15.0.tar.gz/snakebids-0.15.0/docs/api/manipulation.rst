Dataset Manipulation
=======================================

.. currentmodule:: snakebids

.. automodule:: snakebids
    :members: filter_list, get_filtered_ziplist_index
