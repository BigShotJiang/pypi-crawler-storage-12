class UserProperty(property):
    """Simple wrapper around property for typing purposes."""
