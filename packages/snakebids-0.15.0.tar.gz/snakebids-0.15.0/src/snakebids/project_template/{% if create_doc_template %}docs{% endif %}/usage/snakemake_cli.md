# Snakemake Command line interface

```{argparse}
:module: snakebids.snakemake_compat
:func: get_argument_parser
:prog: snakemake
```
