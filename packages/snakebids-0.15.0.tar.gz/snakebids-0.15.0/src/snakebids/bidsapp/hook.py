import pluggy

hookimpl = pluggy.HookimplMarker("snakebids")
"""Marker to be imported and used in plugins (and for own implementations)"""
