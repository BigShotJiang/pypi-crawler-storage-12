from enum import Enum


# Todo: Change to string enum
class SessionFilterActionEnum(Enum):
    CLEAR = 'Clear'
    FILTER = 'Filter'