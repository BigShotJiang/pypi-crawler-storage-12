"""Pytest configuration for blart tests."""
