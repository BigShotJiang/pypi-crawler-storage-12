from mcp_server_w import main

main()
