"""Integration tests for pobapi components."""
