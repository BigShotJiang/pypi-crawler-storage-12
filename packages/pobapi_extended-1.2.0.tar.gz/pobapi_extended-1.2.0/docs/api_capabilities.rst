API Capabilities
================

This document provides a comprehensive overview of what data can be extracted from Path of Building import codes.

.. literalinclude:: API_CAPABILITIES.md
   :language: markdown
