##### Package <em>apb_extra_utils</em>

Modules used on different commonly cases founded in typical projects dealing with strings, mails, 
logging, sql, xml, excel, postgres, Github api and others.

To install:
```shell
pip install apb_extra_utils
```

Documentation here [apb_extra_utils](https://serveis.portdebarcelona.cat/generic_python_packages/apb_extra_utils.html)