# Screenshots

## Music player (June 2025)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/player5.png)

## Theater mode (September 2025)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/theater.png)

## Activity (October 2025)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/history4.png)

## Statistics (September 2025)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/stats3.png)

## Search (June 2024)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/search.png)

## Metadata editor (September 2025)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/metadata-editor2.png)

## Home (October 2025)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/home4.png)

## Browse artist (October 2025)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/browse-artist.png)

## Album cover meme mode (April 2023)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/meme.png)

## Account settings (November 2024)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/account2.png)
