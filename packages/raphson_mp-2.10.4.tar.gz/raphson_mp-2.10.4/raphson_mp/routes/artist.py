from sqlite3 import Connection

from aiohttp import web

from raphson_mp.common.image import ImageFormat, ImageQuality
from raphson_mp.server import auth, settings
from raphson_mp.server.artist import artist_image_thumbnail
from raphson_mp.server.decorators import route


@route("/{artist}/image")
async def image(request: web.Request, _conn: Connection, _user: auth.User):
    artist_name = request.match_info["artist"]
    format = ImageFormat(request.query.get("format", settings.default_image_format))
    quality = ImageQuality(request.query.get("quality", ImageQuality.HIGH))
    img = await artist_image_thumbnail(artist_name, format, quality)
    return web.Response(body=img, content_type=settings.default_image_format.content_type)
