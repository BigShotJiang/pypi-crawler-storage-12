import { eventBus, MusicEvent } from "./event.js";
import { music, Track, Album, Artist } from "../api.js";
import { AlbumBrowse, ArtistBrowse, browse, getTracksTable } from "./browse.js";
import { windows } from "./window.js";
import { throttle, vars } from "../util.js";

class Search {
    #searchResultParent = /** @type {HTMLDivElement} */ (document.getElementById('search-result-parent'));
    #searchResultTracks = /** @type {HTMLTableSectionElement} */ (document.getElementById('search-result-tracks'));
    #searchResultArtists = /** @type {HTMLDivElement} */ (document.getElementById('search-result-artists'));
    #searchResultAlbums = /** @type {HTMLDivElement} */ (document.getElementById('search-result-albums'));
    #queryInput = /** @type {HTMLInputElement} */ (document.getElementById('search-query'));
    #openButton = /** @type {HTMLButtonElement} */ (document.getElementById('open-window-search'));
    #abortController = /** @type {AbortController | null} */ (null);

    constructor() {
        eventBus.subscribe(MusicEvent.METADATA_CHANGE, () => {
            if (!windows.isOpen('window-search')) {
                console.debug('search: ignore METADATA_CHANGE, search window is not open');
                return;
            }
            console.debug('search: search again after receiving METADATA_CHANGE event');
            this.#performSearch();
        });

        this.#queryInput.addEventListener('input', throttle(100, true, () => this.#performSearch()));
        this.#openButton.addEventListener('click', () => this.openSearchWindow());
    }

    openSearchWindow() {
        const queryField =  /** @type {HTMLInputElement} */ (document.getElementById('search-query'));
        queryField.value = '';
        // @ts-ignore
        setTimeout(() => queryField.focus({ focusVisible: true }), 50); // high delay is necessary, I don't know why
        this.#searchResultParent.hidden = true;
    }

    /**
     * @param {string} name
     * @param {string} imageUrl
     * @param {() => void} onClick
     * @returns {HTMLDivElement}
     */
    #createImageBox(name, imageUrl, onClick) {
        const text = document.createElement('div');
        text.textContent = name;
        text.classList.add('box-header', 'line');

        const img = document.createElement('div');
        const imgUri = imageUrl;
        img.style.background = `black url("${imgUri}") no-repeat center / cover`;
        img.style.height = '12rem';

        const box = document.createElement('div');
        box.classList.add('box');
        box.style.width = '12rem';
        box.addEventListener('click', onClick);
        box.append(text, img);
        return box;
    }

    async #performSearch() {
        // abort an existing search query request
        if (this.#abortController) {
            this.#abortController.abort();
        }

        const query = this.#queryInput.value;

        if (query.length < 3) {
            this.#searchResultParent.hidden = true;
            return;
        }

        let result;
        try {
            this.#abortController = new AbortController();
            result = await music.search(query, this.#abortController.signal);
            this.#abortController = null;
            console.debug('search: result:', result);
        } catch (err) {
            if (err instanceof DOMException && err.name == "AbortError") {
                console.info("search: aborted");
                return;
            }
            throw err;
        }

        // TODO hide track/artist/album sections separately
        if (result.tracks.length == 0 && result.artists.length == 0 && result.albums.length == 0) {
            this.#searchResultParent.hidden = true;
            return;
        }

        this.#searchResultParent.hidden = false;

        // Tracks
        {
            this.#searchResultTracks.replaceChildren(getTracksTable(result.tracks));
        }

        // Artists
        {
            const newChildren = [];
            for (const artist of result.artists) {
                newChildren.push(this.#createImageBox(artist.name, artist.getImageURL(), () => browse.browse(new ArtistBrowse(artist.name))));
                if (newChildren.length > 10) {
                    break;
                }
            }

            this.#searchResultArtists.replaceChildren(...newChildren);
        }

        // Albums
        {
            const newChildren = [];
            for (const album of result.albums) {
                newChildren.push(this.#createImageBox(album.name, album.getCoverURL('low'), () => browse.browse(new AlbumBrowse(album))));
                if (newChildren.length > 10) {
                    break;
                }
            }

            this.#searchResultAlbums.replaceChildren(...newChildren);
        }
    }
}

export const search = new Search();
