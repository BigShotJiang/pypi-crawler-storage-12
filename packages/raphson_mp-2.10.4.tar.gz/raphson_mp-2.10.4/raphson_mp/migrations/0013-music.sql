-- Drop CSRF table

DROP TABLE csrf;
