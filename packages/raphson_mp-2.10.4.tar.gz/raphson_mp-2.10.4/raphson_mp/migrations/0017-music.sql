ALTER TABLE track RENAME COLUMN last_played TO last_chosen;
