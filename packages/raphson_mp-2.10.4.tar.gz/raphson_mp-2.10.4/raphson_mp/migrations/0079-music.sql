DROP INDEX idx_track_last_chosen;
