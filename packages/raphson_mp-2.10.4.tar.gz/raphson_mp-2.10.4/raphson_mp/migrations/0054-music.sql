CREATE INDEX idx_history_track_timestamp ON history(track, timestamp); -- mainly for charts
