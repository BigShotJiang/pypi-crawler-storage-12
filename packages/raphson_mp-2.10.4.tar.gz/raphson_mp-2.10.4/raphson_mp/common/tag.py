from enum import Enum


class TagMode(Enum):
    ALLOW = "allow"
    DENY = "deny"
