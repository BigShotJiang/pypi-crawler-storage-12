from phoenix.evals.legacy.models.bedrock import BedrockModel

__all__ = [
    "BedrockModel",
]
