from phoenix.evals.legacy.models.mistralai import MistralAIModel

__all__ = [
    "MistralAIModel",
]
