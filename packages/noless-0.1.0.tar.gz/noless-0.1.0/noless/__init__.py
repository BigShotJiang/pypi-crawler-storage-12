"""NoLess - AI Model Builder CLI"""

__version__ = "0.1.0"
__author__ = "NoLess Team"
