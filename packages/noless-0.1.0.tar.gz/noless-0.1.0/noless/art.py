r"""
    ███╗   ██╗ ██████╗     ██╗     ███████╗███████╗███████╗
    ████╗  ██║██╔═══██╗    ██║     ██╔════╝██╔════╝██╔════╝
    ██╔██╗ ██║██║   ██║    ██║     █████╗  ███████╗███████╗
    ██║╚██╗██║██║   ██║    ██║     ██╔══╝  ╚════██║╚════██║
    ██║ ╚████║╚██████╔╝    ███████╗███████╗███████║███████║
    ╚═╝  ╚═══╝ ╚═════╝     ╚══════╝╚══════╝╚══════╝╚══════╝

  🚀 Build AI Models Without Limits
  🤖 Multi-Agent AI Model Builder
  ⚡ Powered by Advanced LLM Technology
"""

ASCII_LOGO = r"""
    ███╗   ██╗ ██████╗     ██╗     ███████╗███████╗███████╗
    ████╗  ██║██╔═══██╗    ██║     ██╔════╝██╔════╝██╔════╝
    ██╔██╗ ██║██║   ██║    ██║     █████╗  ███████╗███████╗
    ██║╚██╗██║██║   ██║    ██║     ██╔══╝  ╚════██║╚════██║
    ██║ ╚████║╚██████╔╝    ███████╗███████╗███████║███████║
    ╚═╝  ╚═══╝ ╚═════╝     ╚══════╝╚══════╝╚══════╝╚══════╝
"""

ASCII_BANNER = r"""
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║  ███╗   ██╗ ██████╗     ██╗     ███████╗███████╗███████╗           ║
║  ████╗  ██║██╔═══██╗    ██║     ██╔════╝██╔════╝██╔════╝           ║
║  ██╔██╗ ██║██║   ██║    ██║     █████╗  ███████╗███████╗           ║
║  ██║╚██╗██║██║   ██║    ██║     ██╔══╝  ╚════██║╚════██║           ║
║  ██║ ╚████║╚██████╔╝    ███████╗███████╗███████║███████║           ║
║  ╚═╝  ╚═══╝ ╚═════╝     ╚══════╝╚══════╝╚══════╝╚══════╝           ║
║                                                                      ║
║  🤖 Multi-Agent AI Model Builder | ⚡ LLM-Powered Intelligence      ║
║  🚀 Build AI Models Without Limits | 🎯 6 Specialized Agents        ║
║  💻 Real-Time Code Generation | 📊 Smart Dataset Discovery          ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
"""

AGENT_ICONS = {
    "orchestrator": "🎯",
    "dataset_agent": "📊",
    "model_agent": "🤖",
    "code_agent": "💻",
    "training_agent": "🎓",
    "optimization_agent": "⚡",
    "validator": "✅",
    "analyzer": "🔍",
    "deployer": "🚢"
}

# Enhanced working animations
WORKING_ANIMATION = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
ROCKET_ANIMATION = ["🚀", "🚀 ", "🚀  ", "🚀   ", " 🚀  ", "  🚀 ", "   🚀"]
BRAIN_ANIMATION = ["🧠", "🧠💭", "🧠💭💡", "🧠💡", "🧠"]
SPARKLE_ANIMATION = ["✨", "⭐", "🌟", "💫", "✨"]
PROGRESS_ANIMATION = ["▱▱▱▱▱▱", "▰▱▱▱▱▱", "▰▰▱▱▱▱", "▰▰▰▱▱▱", "▰▰▰▰▱▱", "▰▰▰▰▰▱", "▰▰▰▰▰▰"]

# Success and completion banners
SUCCESS_BANNER = r"""
╔══════════════════════════════════════════════════════════════╗
║                    ✨ SUCCESS! ✨                            ║
║  🎉 Your AI Model Project Has Been Generated Successfully!  ║
╚══════════════════════════════════════════════════════════════╝
"""

ERROR_BANNER = r"""
╔══════════════════════════════════════════════════════════════╗
║                     ⚠️  ERROR  ⚠️                            ║
║  Something went wrong. Please check the details below.       ║
╚══════════════════════════════════════════════════════════════╝
"""

THINKING_BANNER = r"""
╔══════════════════════════════════════════════════════════════╗
║              🧠 AI Agent Thinking & Planning...              ║
╚══════════════════════════════════════════════════════════════╝
"""

AGENT_COLLABORATION = r"""
    ┌──────────────────────────────────────────────────┐
    │  🎯 Orchestrator → 📊 Dataset → 🤖 Model Agent  │
    │        ↓                ↓              ↓         │
    │  💻 Code Agent ← 🎓 Training ← ⚡ Optimizer     │
    └──────────────────────────────────────────────────┘
"""

# Status indicators
STATUS_ICONS = {
    "idle": "⚪",
    "thinking": "🧠",
    "working": "⚙️",
    "completed": "✅",
    "error": "❌",
    "warning": "⚠️",
    "info": "ℹ️",
    "searching": "🔍",
    "downloading": "⬇️",
    "generating": "🎨",
    "training": "🎓",
    "optimizing": "⚡",
    "validating": "✓"
}

# Progress bars
PROGRESS_BLOCKS = {
    "empty": "░",
    "partial": "▒",
    "full": "█"
}

# Decorative elements
SEPARATORS = {
    "light": "─" * 70,
    "heavy": "━" * 70,
    "double": "═" * 70,
    "dots": "·" * 70,
    "stars": "✦" * 35
}

# Feature highlights
FEATURES_ART = r"""
╔═══════════════════════════════════════════════════════════════╗
║                     🌟 KEY FEATURES 🌟                        ║
╠═══════════════════════════════════════════════════════════════╣
║  📊 Smart Dataset Search  │  4 sources (OpenML, HF, UCI)     ║
║  🤖 6 Specialized Agents   │  Collaborative AI workflow       ║
║  💻 Auto Code Generation   │  PyTorch, TensorFlow, sklearn   ║
║  🧠 LLM-Powered Planning   │  Intelligent task analysis       ║
║  ✅ AI Code Validation     │  Automatic review & improvement  ║
║  🔄 Interactive Feedback   │  Human-in-the-loop refinement    ║
║  🚀 One-Click Autopilot    │  End-to-end automation          ║
║  📝 Complete Projects      │  train.py, model.py, tests, docs║
╚═══════════════════════════════════════════════════════════════╝
"""

# Quick start guide
QUICK_START = r"""
╔═══════════════════════════════════════════════════════════════╗
║                    🚀 QUICK START GUIDE                       ║
╠═══════════════════════════════════════════════════════════════╣
║  1️⃣  noless autopilot -d "your ML task description"          ║
║      → Fully automated end-to-end generation                  ║
║                                                               ║
║  2️⃣  noless search -q "mnist images" --agents                ║
║      → AI-powered dataset discovery                           ║
║                                                               ║
║  3️⃣  noless create -t image-classification -f pytorch        ║
║      → Generate complete ML project                           ║
║                                                               ║
║  4️⃣  noless interactive                                       ║
║      → Guided step-by-step wizard                             ║
╚═══════════════════════════════════════════════════════════════╝
"""

# Agent showcase
AGENT_SHOWCASE = r"""
╔═══════════════════════════════════════════════════════════════╗
║                  🤖 MEET YOUR AI TEAM 🤖                      ║
╠═══════════════════════════════════════════════════════════════╣
║  🎯 Orchestrator    │  Master coordinator & planner           ║
║  📊 Dataset Agent   │  Data discovery & preparation           ║
║  🤖 Model Agent     │  Architecture design expert             ║
║  💻 Code Agent      │  Real-time code generation              ║
║  🎓 Training Agent  │  Pipeline & execution manager           ║
║  ⚡ Optimizer       │  Hyperparameter tuning specialist       ║
╚═══════════════════════════════════════════════════════════════╝
"""
