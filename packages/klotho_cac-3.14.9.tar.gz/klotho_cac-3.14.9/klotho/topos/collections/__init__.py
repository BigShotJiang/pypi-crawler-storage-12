from .sequences import *
from .sets import *
from .patterns import *

from . import sequences
from . import sets
from . import patterns