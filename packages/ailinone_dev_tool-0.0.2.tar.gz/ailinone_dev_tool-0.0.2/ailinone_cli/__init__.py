"""Public module metadata for the PyPI launcher."""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.0.2"

