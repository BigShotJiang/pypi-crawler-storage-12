<div align="center">

# ConsoleType
<hr>

[![Python](https://img.shields.io/badge/Python-3.8%20%E2%80%93%203.14-3776AB?style=flat&logo=python&logoColor=white)](https://python.org)
[![Github](https://img.shields.io/badge/-GitHub-181717?style=flat&logo=github)](https://github.com/Vaddlkk/ConsoleType)

<hr>
</div>

## Functions

### Prints
This function displays text and controls its movement across the field according to the 
specified parameters.

### Title
Simply outputs text as print.

### Login 
This feature enables account login using IDLogin technology. All data is stored and processed on your server.