NEURON install requires PATH modulation!

If you have a virtualenv in your home directory, use for example:
```
export PATH=~/venv/lib/python3.10/site-packages/neuron/.data/bin/:$PATH
```
