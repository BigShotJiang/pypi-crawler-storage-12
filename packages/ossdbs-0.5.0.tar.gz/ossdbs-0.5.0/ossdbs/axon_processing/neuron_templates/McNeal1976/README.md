Reilly, J.P. Survey of numerical electrostimulation models. Physics in Medicine and Biology 61:4346-4363, 2016. (see far bottom for errata) PMID 27223870
Developer: N.T. Carnevale, Neuroscience Department, Yale Medical School, New Haven, CT.

Modified by K. Butenko to input an externally computed electric potential distribution (`init_B5_extracellular.hoc` and `init_B10_extracellular.hoc`) 
