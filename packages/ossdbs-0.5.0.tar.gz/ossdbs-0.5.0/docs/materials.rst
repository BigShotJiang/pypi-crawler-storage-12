Dielectric properties
=====================

TODO

API reference
-------------

.. automodule:: ossdbs.dielectric_model.DielectricModel
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ossdbs.dielectric_model.ColeCole4Model
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ossdbs.dielectric_model.ColeCole3Model
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ossdbs.dielectric_model.ConstantModel
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: ossdbs.dielectric_model.ColeColeParameters

.. autoclass:: ossdbs.dielectric_model.ConstantParameters
