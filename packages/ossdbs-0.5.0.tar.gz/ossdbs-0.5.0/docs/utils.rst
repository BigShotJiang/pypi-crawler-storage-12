Utilities
=========


Type checking
-------------

TODO document
