"""Run the Talks Reducer GUI as a module."""

from __future__ import annotations

from . import hi_dpi
from .startup import main

if __name__ == "__main__":
    main()
