Authors
---------

pgcopy was written by Aryeh Leib Taurog `@altaurog <https://github.com/altaurog>`_
with contributions from

* Igor Mastak `@mastak <https://github.com/mastak>`_
* Marcin Gozdalik `@gozdal <https://github.com/gozdal>`_
* John A. Bachman `@johnbachman <https://github.com/johnbachman>`_
* Akshaye Shenoi `@akshayeshenoi <https://github.com/akshayeshenoi>`_
* Nathan Glover `@nathanglover <https://github.com/nathanglover>`_
* William Burklund `@wburklund <https://github.com/wburklund>`_
* Logan Wang `@loganwang007 <https://github.com/loganwang007>`_
