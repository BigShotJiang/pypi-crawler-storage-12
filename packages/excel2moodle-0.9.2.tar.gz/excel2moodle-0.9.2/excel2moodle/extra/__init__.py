"""This *extra* subpackage conains standalone scripts

The modules inside *extra* can be run standalone, but are planned to be available from the main Window as well

To run a script execute the following: ``python -m excel2moodle.extra.SCRIPT``
Note that there is no ``.py`` at the end!!
"""
