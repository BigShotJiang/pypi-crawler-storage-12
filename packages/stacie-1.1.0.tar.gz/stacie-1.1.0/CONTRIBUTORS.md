# Contributors

- [Toon Verstraelen](https://github.com/tovrstra):
  Associate professor at [Ghent University](https://www.ugent.be/),
  member of the [Center for Molecular Modeling](https://molmod.ugent.be/).
  ORCID: [0000-0001-9288-5608](https://orcid.org/0000-0001-9288-5608)
- [Gözdenur Toraman](https://github.com/gozdetoraman):
  PhD student at [Ghent University](https://www.ugent.be/),
  member of the Tribology Group at [Soete Laboratory](https://www.ugent.be/ea/emsme/en/research/soete).
  ORCID: [0000-0001-6785-333X](https://orcid.org/0000-0001-6785-333X)
