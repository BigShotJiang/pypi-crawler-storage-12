#!/usr/bin/env bash
sphinx-autobuild source build/html --watch source/ --watch ../src/stacie/
