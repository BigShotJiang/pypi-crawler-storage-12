#!/usr/bin/env bash
rm -rfv build
