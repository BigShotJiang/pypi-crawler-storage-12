# Code of Conduct

```{include} ../../CODE_OF_CONDUCT.md
:start-line: 2
```
