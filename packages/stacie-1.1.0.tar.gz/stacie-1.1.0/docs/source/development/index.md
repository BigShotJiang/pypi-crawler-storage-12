# Development

This section contains some technical details about the development of STACIE.

```{toctree}
:maxdepth: 1

contributing.md
setup.md
changelog.md
release.md
../apidocs/modules.rst
```
