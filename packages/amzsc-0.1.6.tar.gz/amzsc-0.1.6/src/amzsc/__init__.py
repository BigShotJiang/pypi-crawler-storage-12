from .scraper import AmazonScraper

__all__ = [
    "AmazonScraper",
]
