# mlalib

A lightweight library built by MLA for exploring and understanding machine learning.

## Installation

```bash
pip install mlalib

