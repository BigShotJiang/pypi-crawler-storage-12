"""DEPRECATED: Please import tabpfn.architectures.base.bar_distribution instead."""

from __future__ import annotations

from tabpfn.architectures.base.bar_distribution import *  # noqa: F403
