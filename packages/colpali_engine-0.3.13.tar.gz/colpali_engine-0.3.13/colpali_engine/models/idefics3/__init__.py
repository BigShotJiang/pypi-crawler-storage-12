from .biidefics3 import BiIdefics3, BiIdefics3Processor
from .colidefics3 import ColIdefics3, ColIdefics3Processor
