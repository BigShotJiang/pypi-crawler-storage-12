"""Test suite for DFM nowcasting module (DFM estimation, Kalman filter, news decomposition)."""

