# # SCI Results

import lfsir

YEAR = 1401

# ## Table 001

lfsir.load_knowledge("sci_results.T001", years=YEAR)
