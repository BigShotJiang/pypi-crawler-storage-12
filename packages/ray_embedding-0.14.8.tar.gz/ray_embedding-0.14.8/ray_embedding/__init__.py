from ray_embedding.deploy import build_app

