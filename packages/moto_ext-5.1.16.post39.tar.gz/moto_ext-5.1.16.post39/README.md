# moto-ext

Fork of [Moto](https://github.com/getmoto/moto) with patches and fixes for [LocalStack](https://github.com/localstack/localstack).
