//! Common traits for ALPM.

pub mod metadata_file;
pub mod schema;
