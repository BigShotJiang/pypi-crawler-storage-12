//! Helpers related to package handling.

pub mod input;
