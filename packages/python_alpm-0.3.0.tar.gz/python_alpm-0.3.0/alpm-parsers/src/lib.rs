#![doc = include_str!("../README.md")]

pub mod custom_ini;
pub mod macros;
