[ ] Add tests for the change.
[ ] Add any appropriate documentation.
[ ] Run `just check`.
[ ] Add a summary of changes to `CHANGELOG.rst`.
[ ] Add your name to `AUTHORS.rst`.

