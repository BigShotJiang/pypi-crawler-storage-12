from ..delta.five import SOME_VAR

a = SOME_VAR
