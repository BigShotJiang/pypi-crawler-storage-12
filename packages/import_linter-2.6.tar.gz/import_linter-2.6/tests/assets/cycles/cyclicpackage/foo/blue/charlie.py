from cyclicpackage.foo.blue import alpha

SOMETHING = alpha.a / 2
