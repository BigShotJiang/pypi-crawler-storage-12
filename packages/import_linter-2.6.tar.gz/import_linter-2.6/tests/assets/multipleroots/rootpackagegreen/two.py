from rootpackageblue.one import alpha

from . import one
