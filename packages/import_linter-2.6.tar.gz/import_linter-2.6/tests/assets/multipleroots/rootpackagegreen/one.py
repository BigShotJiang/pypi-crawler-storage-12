def foo(x):
    return x + 1
