"""Examples for the MAS framework."""
