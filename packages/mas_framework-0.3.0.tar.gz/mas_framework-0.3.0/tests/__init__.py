"""Test package for MAS Framework."""
