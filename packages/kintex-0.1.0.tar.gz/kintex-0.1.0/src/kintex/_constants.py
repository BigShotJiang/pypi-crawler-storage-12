HARD_SHORTCUTS = {
    ".p": ".people",
    ".n": ".notes",
    ".q": ".questions",
    ".i": ".ideas",
    ".d": ".disagree",
    ".a": ".agree",
    ".f": ".false",
    ".in": ".insights",
    ".mr": "..more research.",
    ".cr": "..check reference.",
    ".qt": ".quotes",
}

CLIPPING_TYPES = ["highlight", "note"]
