"""Version information for plex-generate-previews."""

__version__ = "2.3.0"
__version_tuple__ = (2, 3, 0)
