def add(x,y):
    print("bikram le banako package")

def sub(x,y):
    print("bikram le banako arrko package")
