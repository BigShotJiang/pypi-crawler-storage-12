:::{include} ../../LICENSE.md
:::

:::{index} License
:::
