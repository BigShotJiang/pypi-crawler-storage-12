"""Classes defining objectives that wrap external codes."""

from ._terpsichore import TERPSICHORE
