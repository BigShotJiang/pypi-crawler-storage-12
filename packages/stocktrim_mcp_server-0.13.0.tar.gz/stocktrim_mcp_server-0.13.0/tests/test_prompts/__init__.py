"""Tests for MCP prompts."""
