"""
QuerySUTRA - Structured-Unstructured-Text-Retrieval-Architecture
Creates multiple structured tables from ANY data with AI
"""

__version__ = "0.2.2"

from sutra.sutra import SUTRA, QueryResult, quick_start

__all__ = ["SUTRA", "QueryResult", "quick_start"]
