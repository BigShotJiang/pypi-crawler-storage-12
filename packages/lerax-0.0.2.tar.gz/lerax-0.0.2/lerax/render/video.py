from .base_renderer import AbstractRenderer


class VideoRenderer(AbstractRenderer):
    """Video recording renderer implementation"""
