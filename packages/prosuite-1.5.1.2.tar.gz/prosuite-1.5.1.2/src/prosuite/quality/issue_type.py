from enum import Enum


class IssueType(Enum):
    Warning = 0
    Error = 1
