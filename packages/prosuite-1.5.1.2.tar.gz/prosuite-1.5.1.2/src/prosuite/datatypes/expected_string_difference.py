class ExpectedStringDifference:
    ANY = 0
    CASE_SENSITIVE_DIFFERENCE = 1
    CASE_INSENITIVE_DIFFERENCE = 2
