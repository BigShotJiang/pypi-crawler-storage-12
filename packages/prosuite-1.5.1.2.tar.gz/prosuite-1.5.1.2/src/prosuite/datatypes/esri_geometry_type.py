class EsriGeometryType:
    Polyline = "Polyline"
    Polygon = "Polygon"
    Point = "Point"
    Multipoint = "Multipoint"
    Multipatch = "Multipatch"
