class ExpectedCase:
    ANY = 0
    ALLUPPER = 1
    ALLLOWER = 2
    MIXED = 3
    NOTALLUPPER = 4
    NOTALLLOWER = 5
