class UniqueStringsConstraint:
    NONE = 0
    UNIQUE_EXACT_CASE = 1
    UNIQUE_ANY_CASE = 2
