from abc import ABC, abstractmethod
from ..models.album import Album
from ..models.track import Track


class MusicSource(ABC):
    """Abstract base class for music sources (e.g., Subsonic)."""

    @abstractmethod
    def get_albums(self) -> list[Album]:
        """Get all albums from the music source."""
        pass

    @abstractmethod
    def get_tracks(self) -> list[Track]:
        """Get all tracks from the music source."""
        pass
