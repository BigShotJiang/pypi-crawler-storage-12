"""Subsonic music source implementation."""

from pushtunes.sources.base import MusicSource
from pushtunes.models.album import Album
from pushtunes.models.track import Track
from pushtunes.models.playlist import Playlist
from pushtunes.clients.subsonic import SubsonicClient
import os


from pushtunes.utils.artist_utils import parse_artist_string


class SubsonicSource(MusicSource):
    """Subsonic music source implementation."""

    def __init__(
        self, url=None, username=None, password=None, port=443, use_cache=True
    ):
        """Initialize Subsonic source.

        Args:
            url: Subsonic server URL (defaults to SUBSONIC_URL env var)
            username: Username (defaults to SUBSONIC_USER env var)
            password: Password (defaults to SUBSONIC_PASS env var)
            port: Server port (defaults to 443)
            use_cache: Whether to cache albums in memory during the session
        """
        self.url = url or os.getenv("SUBSONIC_URL")
        self.username = username or os.getenv("SUBSONIC_USER")
        self.password = password or os.getenv("SUBSONIC_PASS")

        if not self.url or not (self.username or self.password):
            raise ValueError(
                "Subsonic credentials not found. Please set "
                + "SUBSONIC_URL, SUBSONIC_USER, "
                + "SUBSONIC_PASS"
            )

        self.client = SubsonicClient(self.url, self.username, self.password, port)

    def get_albums(self, force_update: bool = False) -> list[Album]:
        """Get all albums from the Subsonic server.

        Args:
            force_update: Force update by fetching from server even if cached

        Returns:
            list of Album objects
        """
        raw_albums = self.client.get_albums()

        albums: list[Album] = []
        for raw_album in raw_albums:
            artist_string = raw_album.get("artist", "")
            artist_list = parse_artist_string(artist_string)
            
            year_str = str(raw_album.get("year", ""))
            year = int(year_str) if year_str.isdigit() else None

            album = Album(
                artists=artist_list, title=raw_album.get("title", ""), year=year
            )
            albums.append(album)

        print(f"Fetched {len(albums)} albums from Subsonic server")
        return albums

    def get_tracks(self) -> list[Track]:
        """Get all starred/favorite tracks from the Subsonic server.

        Returns:
            list of Track objects
        """
        raw_tracks = self.client.get_tracks()

        tracks: list[Track] = []
        for raw_track in raw_tracks:
            artist_string = raw_track.get("artist", "")
            artist_list = parse_artist_string(artist_string)

            year_str = str(raw_track.get("year", ""))
            year = int(year_str) if year_str.isdigit() else None

            track = Track(
                artists=artist_list,
                title=raw_track.get("title", ""),
                album=raw_track.get("album"),
                year=year
            )
            tracks.append(track)

        print(f"Fetched {len(tracks)} tracks from Subsonic server")
        return tracks

    def get_playlist(self, playlist_name: str) -> Playlist | None:
        """Get a specific playlist by name from the Subsonic server.

        Args:
            playlist_name: Name of the playlist to fetch

        Returns:
            Playlist object or None if not found
        """
        # First, get all playlists to find the ID
        raw_playlists = self.client.get_playlists()

        playlist_id = None
        for pl in raw_playlists:
            if pl["name"].lower() == playlist_name.lower():
                playlist_id = pl["id"]
                break

        if not playlist_id:
            print(f"Playlist '{playlist_name}' not found")
            return None

        # Now fetch the full playlist with tracks
        raw_playlist = self.client.get_playlist(playlist_id)
        if not raw_playlist:
            return None

        # Convert entries to Track objects
        tracks: list[Track] = []
        for entry in raw_playlist.get("entry", []):
            artist_string = entry.get("artist", "")
            artist_list = parse_artist_string(artist_string)

            year_str = str(entry.get("year", ""))
            year = int(year_str) if year_str.isdigit() else None

            track = Track(
                artists=artist_list,
                title=entry.get("title", ""),
                album=entry.get("album"),
                year=year
            )
            tracks.append(track)

        playlist = Playlist(
            name=raw_playlist.get("name", playlist_name),
            tracks=tracks
        )

        print(f"Fetched playlist '{playlist.name}' with {len(tracks)} tracks from Subsonic server")
        return playlist
