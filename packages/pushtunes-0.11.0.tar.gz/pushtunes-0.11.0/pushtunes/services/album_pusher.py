from pushtunes.models.album import Album
from pushtunes.models.push_status import PushStatus
from pushtunes.services.music_service import MusicService
from pushtunes.utils.filters import AlbumFilter
from pushtunes.utils.similarity import get_best_match
from pushtunes.utils.logging import get_logger
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class AlbumResult:
    album: Album
    status: PushStatus
    message: str = ""
    found_album: Album | None = None


@dataclass
class AlbumPusher:
    albums: list[Album]
    service: MusicService
    filter: AlbumFilter | None = None
    min_similarity: float = 0.8
    mappings: "MappingsManager | None" = None

    def push_albums(self) -> list[AlbumResult]:
        """Push albums from a music source to one or more services

        Args:
            source: The music source to sync from
            album_filter: Optional AlbumFilter to filter which albums to sync

        Returns:
            Dictionary with AlbumResults

        Raises:
            Exception: If authentication or cache loading fails
        """

        log = get_logger()
        log.info(f"Got {len(self.albums)} albums to push")

        album_results: list[AlbumResult] = []
        for album in self.albums:
            if self.filter and self.filter.matches(album):
                add_result(
                    album_results, AlbumResult(album=album, status=PushStatus.filtered)
                )
                continue

            # This uses the album cache to discard perfect matches before we even send a search query
            # If authentication fails, this will raise an exception and abort the entire operation
            try:
                is_in_library = self.service.is_album_in_library(album)
            except Exception as e:
                log.error(
                    f"Failed to check library for album {album.artist} - {album.title}: {e}"
                )
                log.error(
                    "Authentication or library access failed. Aborting album push operation."
                )
                raise

            if is_in_library:
                add_result(
                    album_results,
                    AlbumResult(album, status=PushStatus.already_in_library_cache),
                )
                continue

            # Check if there's a mapping for this album
            best_match = None
            if self.mappings:
                mapped_album = self.mappings.get_album_mapping(
                    album, self.service.service_name
                )
                if mapped_album:
                    # If the mapping has a service_id, use it directly
                    if mapped_album.service_id:
                        best_match = mapped_album
                        log.info(
                            f"Using mapping for {album.artist} - {album.title} -> ID {mapped_album.service_id}"
                        )
                    else:
                        # If the mapping has metadata, search for it
                        log.info(
                            f"Using mapping for {album.artist} - {album.title} -> {mapped_album.artist} - {mapped_album.title}"
                        )
                        search_results = self.service.search_albums(mapped_album)
                        if search_results:
                            best_match = get_best_match(
                                source=mapped_album,
                                candidates=search_results,
                                min_similarity=self.min_similarity,
                            )

            # If no mapping or mapping didn't find a match, do normal search
            if not best_match:
                search_results: list[Album] = self.service.search_albums(album)
                if not search_results:
                    add_result(
                        album_results, AlbumResult(album=album, status=PushStatus.not_found)
                    )
                    continue

                best_match = get_best_match(
                    source=album,
                    candidates=search_results,
                    min_similarity=self.min_similarity,
                )

            if best_match:
                # A suitable match was found on the target service.
                # The is_album_in_library check should have already caught this,
                # but we'll double-check here just in case.
                try:
                    is_best_match_in_library = self.service.is_album_in_library(
                        best_match
                    )
                except Exception as e:
                    log.error(
                        f"Failed to check library for best match {best_match.artist} - {best_match.title}: {e}"
                    )
                    log.error(
                        "Authentication or library access failed. Aborting album push operation."
                    )
                    raise

                if is_best_match_in_library:
                    add_result(
                        album_results,
                        AlbumResult(
                            album,
                            found_album=best_match,
                            status=PushStatus.already_in_library,
                        ),
                    )
                else:
                    # It's a good match and it's not in the library, so add it.
                    success = self.service.add_album(best_match)
                    if success:
                        add_result(
                            album_results,
                            AlbumResult(
                                album,
                                found_album=best_match,
                                status=PushStatus.added,
                            ),
                        )
                    else:
                        add_result(
                            album_results,
                            AlbumResult(
                                album,
                                found_album=best_match,
                                status=PushStatus.error,
                            ),
                        )
            else:  # No suitable match was found in the search results.
                add_result(
                    album_results,
                    AlbumResult(
                        album,
                        found_album=None,
                        status=PushStatus.similarity_too_low,
                    ),
                )
        return album_results


def pretty_print_result(result: AlbumResult):
    match result.status:
        case PushStatus.error:
            return f"Failed to add {result.album.artist} - {result.album.title}"
        case PushStatus.not_found:
            return f"Could not find a match for {result.album.artist} - {result.album.title}"
        case PushStatus.already_in_library:
            return f"Skipping {result.album.artist} - {result.album.title} (already in library)"
        case PushStatus.already_in_library_cache:
            return f"Skipping {result.album.artist} - {result.album.title} (already in library, cache hit)"
        case PushStatus.filtered:
            return f"Skipping {result.album.artist} - {result.album.title} (filtered)"
        case PushStatus.similarity_too_low:
            return f"Skipping {result.album.artist} - {result.album.title} (similarity too low)"
        case PushStatus.mapped:
            return f"Added {result.album.artist} - {result.album.title} -> Mapped to {result.found_album.artist} - {result.found_album.title}"
        case PushStatus.added:
            return f"Added {result.album.artist} - {result.album.title} -> Found {result.found_album.artist} - {result.found_album.title}"
        case _:
            return f"Something unknown happened while adding {result.album.artist} - {result.album.title}"


def add_result(results: list[AlbumResult], result: AlbumResult) -> None:
    """Add a result and send it to the logger at the same time"""
    log = get_logger(__name__)
    results.append(result)
    if result.status == PushStatus.error:
        log.error(pretty_print_result(result))
    else:
        log.info(pretty_print_result(result))
