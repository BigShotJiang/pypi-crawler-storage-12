from __future__ import annotations

import importlib.metadata

VERSION = importlib.metadata.version("cimi")
USER_AGENT = f"KimiCLI/{VERSION}"
