Moved to: [https://docs.netlas.io/changelog/](https://docs.netlas.io/changelog/)
