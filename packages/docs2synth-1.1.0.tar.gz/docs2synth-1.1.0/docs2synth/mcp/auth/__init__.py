from __future__ import annotations

# Authentication-related modules for MCP (OIDC and OAuth proxy)
