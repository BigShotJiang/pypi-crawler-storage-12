from .fast_dot import *

__doc__ = fast_dot.__doc__
if hasattr(fast_dot, "__all__"):
    __all__ = fast_dot.__all__