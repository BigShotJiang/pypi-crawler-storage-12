# Nothing to test here yet, the base class is quite simple.
