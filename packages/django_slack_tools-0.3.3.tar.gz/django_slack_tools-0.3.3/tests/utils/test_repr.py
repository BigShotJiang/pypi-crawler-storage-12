# NOTE: Won't test `make_repr`; it is used by other classes and will be tested indirectly.
