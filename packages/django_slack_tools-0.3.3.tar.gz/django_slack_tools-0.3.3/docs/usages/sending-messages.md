::: django_slack_tools.slack_messages.shortcuts
    options:
      show_root_heading: false
