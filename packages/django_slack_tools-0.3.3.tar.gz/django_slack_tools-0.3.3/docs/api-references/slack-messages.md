::: django_slack_tools.slack_messages.messenger
    options:
      show_root_heading: true

::: django_slack_tools.slack_messages.models
    options:
      show_root_heading: true

::: django_slack_tools.slack_messages.shortcuts
    options:
      show_root_heading: true

::: django_slack_tools.slack_messages.tasks
    options:
      show_root_heading: true
