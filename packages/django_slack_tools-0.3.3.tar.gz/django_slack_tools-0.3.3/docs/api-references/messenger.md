::: django_slack_tools.messenger.backends
    options:
      show_root_heading: true

::: django_slack_tools.messenger.message_templates
    options:
      show_root_heading: true

::: django_slack_tools.messenger.middlewares
    options:
      show_root_heading: true

::: django_slack_tools.messenger.template_loaders
    options:
      show_root_heading: true

::: django_slack_tools.messenger.messenger
    options:
      show_root_heading: true

::: django_slack_tools.messenger.request
    options:
      show_root_heading: true

::: django_slack_tools.messenger.response
    options:
      show_root_heading: true
