import "@testing-library/jest-dom/vitest";
import "@/testing/mocks/chatkit";
import { setupMockBackendFetch } from "@/testing/mocks/backend";

setupMockBackendFetch();
