export const DEFAULT_NODE_CODE = "return state";

export const LARGE_DATASET_THRESHOLD = 200;

export const YIELD_BATCH_SIZE = 50;

export const DECISION_NODE_TYPES = new Set(["IfElseNode"]);
