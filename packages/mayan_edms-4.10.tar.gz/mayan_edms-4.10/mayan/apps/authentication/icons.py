from mayan.apps.icons.icons import Icon

icon_impersonate_start = Icon(
    driver_name='fontawesome-dual', primary_symbol='user',
    secondary_symbol='user'
)
icon_login = Icon(driver_name='fontawesome', symbol='sign-in-alt')
icon_logout = Icon(driver_name='fontawesome', symbol='sign-out-alt')
icon_password_change = Icon(driver_name='fontawesome', symbol='key')
