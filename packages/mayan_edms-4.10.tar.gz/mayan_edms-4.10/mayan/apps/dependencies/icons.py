from mayan.apps.icons.icons import Icon

icon_check_version = Icon(driver_name='fontawesome', symbol='sync')

icon_dependency_group_list = Icon(driver_name='fontawesome', symbol='boxes')
icon_dependency_group_entry_list = Icon(
    driver_name='fontawesome', symbol='box'
)
icon_dependency_group_entry_detail = Icon(
    driver_name='fontawesome', symbol='box-open'
)
icon_dependency_licenses = Icon(
    driver_name='fontawesome', symbol='certificate'
)
