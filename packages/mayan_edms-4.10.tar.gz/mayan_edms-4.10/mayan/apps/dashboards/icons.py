from mayan.apps.icons.icons import Icon

icon_dashboard_detail = Icon(
    driver_name='fontawesome', symbol='tachometer-alt'
)
icon_dashboard_link_icon = Icon(
    driver_name='fontawesome', symbol='external-link-alt'
)
icon_dashboard_list = Icon(
    driver_name='fontawesome', symbol='tachometer-alt'
)
