from mayan.apps.dependencies.classes import JavaScriptDependency

JavaScriptDependency(
    module=__name__, name='jstree', version_string='=3.3.17'
)
