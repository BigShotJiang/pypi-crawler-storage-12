"""OrJSON provider for JSON serialization and deserialization."""

from anyenv.json_tools.orjson_provider.provider import OrJsonProvider

__all__ = ["OrJsonProvider"]
