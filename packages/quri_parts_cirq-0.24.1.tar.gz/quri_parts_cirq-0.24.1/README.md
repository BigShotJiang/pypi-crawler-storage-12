# QURI Parts Cirq

QURI Parts Cirq is a support library for using Cirq with QURI Parts.

## Documentation

[QURI Parts Documentation](https://quri-parts.qunasys.com)

## Installation

```
pip install quri-parts-cirq
```

## License

Apache License 2.0
