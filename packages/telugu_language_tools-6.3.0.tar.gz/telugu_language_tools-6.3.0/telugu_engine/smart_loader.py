"""
Smart loader that prefers PyTorch if available and falls back to ONNX.
Expected packaged model directories (inside package):
 - telugu_engine/model_data/tiny_gpt2/         (pytorch model files saved via model.save_pretrained)
 - telugu_engine/model_data/tiny_gpt2_onnx/    (model.onnx + tokenizer files)
Usage:
  from telugu_engine.smart_loader import init_model, backend_name, rerank
  ok = init_model()
  backend_name()  # 'torch'|'onnx'|'none'
  rerank(prompt, candidates)
Environment:
 - Does NOT install torch/onnxruntime for you. It will use whatever is available.
 - If both backends available, torch is preferred.
"""
import os
import importlib
import importlib.resources as pkg_res
import math
import numpy as np

PKG_NAME = "telugu_engine"
MODEL_PT_SUBPATH = "model_data/custom_gpt2_pt"
MODEL_ONNX_SUBPATH = "model_data/custom_gpt2_onnx"

_backend = None   # 'torch' | 'onnx' | None
_tokenizer = None
_model = None     # torch model or onnx session
_device = None

def _pkg_path(subpath: str) -> str:
    try:
        pkg = importlib.import_module(PKG_NAME)
        path = pkg_res.files(pkg).joinpath(subpath)
        return str(path)
    except Exception:
        return os.path.abspath(subpath)

def _pt_model_exists() -> bool:
    d = _pkg_path(MODEL_PT_SUBPATH)
    return os.path.isdir(d) and any(os.path.exists(os.path.join(d, f)) for f in ("pytorch_model.bin","pytorch_model.safetensors","config.json"))

def _onnx_model_exists() -> bool:
    d = _pkg_path(MODEL_ONNX_SUBPATH)
    return os.path.isdir(d) and os.path.isfile(os.path.join(d, "model.onnx"))

def backend_name() -> str:
    return _backend

# -----------------------------
# Initialize PT backend (lazy import)
# -----------------------------
def _init_pt() -> bool:
    global _backend, _tokenizer, _model, _device
    try:
        import torch
        from transformers import AutoTokenizer, AutoModelForCausalLM
        local_dir = _pkg_path(MODEL_PT_SUBPATH)
        # load tokenizer + model from local packaged files
        _tokenizer = AutoTokenizer.from_pretrained(local_dir, local_files_only=True)
        _model = AutoModelForCausalLM.from_pretrained(local_dir, local_files_only=True)
        device = "cuda" if torch.cuda.is_available() else "cpu"
        _device = device
        _model.to(device)
        _model.eval()
        _backend = "torch"
        return True
    except Exception:
        # do not raise — return False to allow fallback
        _backend = None
        _tokenizer = None
        _model = None
        _device = None
        return False

# -----------------------------
# Initialize ONNX backend (lazy import)
# -----------------------------
def _init_onnx() -> bool:
    global _backend, _tokenizer, _model, _device
    try:
        import onnxruntime as ort
        from transformers import AutoTokenizer
        local_dir = _pkg_path(MODEL_ONNX_SUBPATH)
        tokenizer = AutoTokenizer.from_pretrained(local_dir, local_files_only=True)
        onnx_path = os.path.join(local_dir, "model.onnx")
        sess = ort.InferenceSession(onnx_path, providers=["CPUExecutionProvider"])
        _tokenizer = tokenizer
        _model = sess
        _device = "cpu"
        _backend = "onnx"
        return True
    except Exception:
        _backend = None
        _tokenizer = None
        _model = None
        _device = None
        return False

# -----------------------------
# Public init function
# -----------------------------
def init_model() -> bool:
    """
    Try to initialize backends in order: torch (preferred) -> onnx.
    Returns True if some backend initialized, False otherwise.
    """
    global _backend
    # Prefer PT if both available locally and torch present
    pt_ok = _pt_model_exists()
    onnx_ok = _onnx_model_exists()

    # if torch import available and PT files exist -> init PT
    try:
        import importlib
        torch_spec = importlib.util.find_spec("torch")
        torch_available = torch_spec is not None
    except Exception:
        torch_available = False

    # If torch is installed and pt files exist, try PT first
    if torch_available and pt_ok:
        if _init_pt():
            return True
        # else fallthrough to ONNX

    # Else if ONNX is usable, try ONNX
    try:
        import importlib
        onnx_spec = importlib.util.find_spec("onnxruntime")
        onnx_available = onnx_spec is not None
    except Exception:
        onnx_available = False

    if onnx_available and onnx_ok:
        if _init_onnx():
            return True

    # If torch is available but PT files exist and we haven't tried PT (rare), try now
    if torch_available and pt_ok:
        if _init_pt():
            return True

    # nothing could be initialized
    _backend = None
    return False

# -----------------------------
# scoring implementations
# -----------------------------
def _score_with_pt(prompt: str, candidate: str) -> float:
    import torch
    text = f"{prompt} => {candidate}"
    enc = _tokenizer(text, return_tensors="pt").to(_device)
    with torch.no_grad():
        outputs = _model(**enc, labels=enc["input_ids"])
        # negative loss -> higher better
        return -float(outputs.loss.item())

def _score_with_onnx(prompt: str, candidate: str) -> float:
    # tokenizer returns numpy arrays if return_tensors="np"
    text = f"{prompt} => {candidate}"
    enc = _tokenizer(text, return_tensors="np")
    input_name = _model.get_inputs()[0].name
    inputs = {input_name: enc["input_ids"]}
    outputs = _model.run(None, inputs)
    logits = outputs[0]  # shape (batch, seq, vocab)
    ids = enc["input_ids"]
    seq_len = ids.shape[1]
    # compute average token log-prob (naive)
    total_logp = 0.0
    for t in range(seq_len):
        token_logits = logits[0, t]
        true_id = int(ids[0, t])
        amax = float(np.max(token_logits))
        lse = amax + np.log(np.sum(np.exp(token_logits - amax)))
        log_true = float(token_logits[true_id])
        total_logp += (log_true - lse)
    avg = total_logp / max(1, seq_len)
    return float(avg)

def score_candidate(prompt: str, candidate: str) -> float:
    """
    Score a single candidate with the active backend (must call init_model first).
    Returns higher = better.
    """
    if _backend == "torch":
        return _score_with_pt(prompt, candidate)
    elif _backend == "onnx":
        return _score_with_onnx(prompt, candidate)
    else:
        raise RuntimeError("No backend initialized. Call init_model() first or use local_reranker.")

def rerank(prompt: str, candidates, top_k: int = None):
    """
    Re-rank candidates best-first. Returns list of (candidate, score).
    """
    if _backend is None:
        raise RuntimeError("No backend initialized. Call init_model() first.")
    scored = []
    for c in candidates:
        try:
            s = score_candidate(prompt, c)
        except Exception:
            s = float("-inf")
        scored.append((c, s))
    scored.sort(key=lambda x: x[1], reverse=True)
    if top_k:
        return scored[:top_k]
    return scored