from .smart_loader import init_model, backend_name, rerank as _rerank_backend

_initialized = False

def ensure():
    global _initialized
    if not _initialized:
        ok = init_model()
        _initialized = True
        return ok
    return True

def rerank(prompt: str, candidates, top_k: int = None):
    if not _initialized:
        ensure()
    if backend_name() is None:
        raise RuntimeError("No HF backend initialized (torch/onnx). Call ensure() or install onnxruntime/torch.")
    return _rerank_backend(prompt, candidates, top_k)