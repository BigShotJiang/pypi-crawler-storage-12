"""
Telugu Library v6.3.0 - Modern Telugu Engine
===============================================

Complete v3.0 compliant Telugu processing library with complete tense system:
- transliterator: Modern transliteration (no archaic letters)
- grammar: Modern grammar with complete tense system (past/present/future/continuous)
- enhanced_tense: v5.5 enhanced tense with all tenses (present continuous, past, future)
- v3_validator: v3.0 compliance validation
- phonetic_matrix: Phonetic normalization
- combo_pipeline: Comprehensive pipeline for all transliteration workflows
- enhanced_telugu_mappings: Grammar-based phonetic classifications and sandhi rules
- merged_pipeline: Comprehensive merged pipeline with all enhanced features
- smart_loader: Intelligent backend selection with PyTorch/ONNX/fallback support
- rerank_utils: Shared utilities for candidate scoring and reranking

All modules use modern Vyāvahārika standards:
- Modern pronouns: నేను, వాళ్ళు (NOT ఏను, వాండ్రు)
- Modern verbs: చేసినాను (NOT చేసితిని)
- 4-case system: Nominative, Accusative, Dative, Locative
- SOV syntax
- No archaic letters: ఱ, ఌ, ౡ, ౘ, ౙ, ఀ, ౝ

v6.3.0 Features:
- Complete tense system: All 26 verbs with past/present/future/continuous support
- 182 new conjugations: All verbs now have 7 person forms in present/future tense
- Grammar engine completion: Production-ready with 100% accurate conjugations
- Gender distinctions: Proper masculine/feminine/neuter forms across all tenses
- Telugu conjugation patterns: Implemented 7 distinct patterns (-స్త, -ుత, -ంట, -త, etc.)
- వెళ్ళు rule mastery: Clear distinction between double ళ్ళ (past) and single ళ్త (present/future)
- Past participles complete: All 26 verbs have proper past participles
- Continuous tense pattern: Full uNi uNDu pattern support (కూర్చుని ఉన్నది)
- Comprehensive testing: 100% test pass rate with mapping verification
- Complete documentation: Guides for all grammar features with examples
- Context-aware anusvara resolution (from v6.2.0)
- Sandhi rule applications (Athva, Yadagama, etc.) (from v6.2.0)
- Grammar-based validation and scoring (from v6.2.0)
- Smart model loader with intelligent backend selection (from v6.2.2)
- Automatic dependency handling (from v6.2.2)
- Present continuous tense: "I am going" → నేను వెళ్తున్నాను (from v5.0.0+)
- All 16 v3.0 sections implemented (from v5.0.0+)
- Comprehensive test suites (from v5.0.0+)
- Streamlined architecture with focused modules (from v6.0.0+)
"""

# Main API - transliteration
from .transliterator import (
    eng_to_telugu,
)

def transliterate_word(word: str) -> str:
    """Transliterate a single word."""
    return eng_to_telugu(word)

def transliterate_sentence(sentence: str) -> str:
    """Transliterate a complete sentence."""
    words = sentence.split()
    return ' '.join(eng_to_telugu(word) for word in words)

def validate_v3_compliance(text: str) -> dict:
    """Validate v3 compliance using the v3_validator module."""
    from .v3_validator import validate_v3_compliance as validator
    return validator(text)

# Grammar module
from .grammar import (
    conjugate_verb,
    conjugate_continuous,
    apply_case,
    convert_svo_to_soV,
    build_telugu_sentence,
    apply_sandhi,
    check_vowel_harmony,
    apply_vowel_harmony,
    VERB_ROOT_MAP,
    PAST_PARTICIPLES,
    PERSON_MARKERS
)

# v3.0 validator
from .v3_validator import (
    validate_script,
    validate_pronouns,
    validate_verbs,
    validate_case_markers,
    validate_vowel_harmony,
    validate_v3_compliance,
    get_compliance_report,
    test_v3_compliance
)

# Enhanced tense engine (v5.0 - full v3.0 support)
from .enhanced_tense import (
    translate_sentence,
    conjugate_present_continuous,
    conjugate_past_tense,
    conjugate_verb_enhanced,
    detect_tense_enhanced,
    detect_person,
    validate_translation_output,
    run_comprehensive_test_suite
)

# Phonetic matrix (kept for compatibility)
from .phonetic_matrix import map_sound

# Suggestion module (required by combo_pipeline)
from .suggest import suggestions
from .suggest_sentence import sentence_variants, per_token_suggestions

# Combo pipeline - comprehensive workflow engine
from .combo_pipeline import (
    process_english_words_input,
    process_english_sentence_input,
    process_telugu_word_in_english_script,
    process_telugu_sentence_in_english_script
)

# Enhanced Telugu mappings - grammar-based features
from .enhanced_telugu_mappings import (
    is_valid_telugu_word,
    resolve_anusvara_context_aware,
    apply_athva_sandhi,
    apply_yadagama_sandhi,
    classify_word_by_ending,
    get_varga_for_consonant,
    get_consonant_nature,
    MATRAS_COMPLETE,
    VARGA_CLASSIFICATIONS
)

# Merged pipeline - comprehensive API with all enhanced features
from .merged_pipeline import (
    transliterate_word as merged_transliterate_word,
    transliterate_sentence as merged_transliterate_sentence,
    MergedPipeline
)

# Smart loader for model-based scoring and reranking
from .smart_loader import (
    init_model,
    score_candidate,
    rerank,
    backend_name
)

# Public API
__version__ = "6.3.0"
__author__ = "Telugu Library v3.0"
__email__ = "support@telugulibrary.org"

__all__ = [
    # Transliteration
    "eng_to_telugu",
    "transliterate_word",
    "transliterate_sentence",

    # Grammar
    "conjugate_verb",
    "conjugate_continuous",
    "apply_case",
    "convert_svo_to_soV",
    "build_telugu_sentence",
    "apply_sandhi",
    "check_vowel_harmony",
    "apply_vowel_harmony",
    "VERB_ROOT_MAP",
    "PAST_PARTICIPLES",
    "PERSON_MARKERS",

    # Enhanced Tense (v5.0 - Full v3.0 Support)
    "translate_sentence",
    "conjugate_present_continuous",
    "conjugate_past_tense",
    "conjugate_verb_enhanced",
    "detect_tense_enhanced",
    "validate_translation_output",
    "run_comprehensive_test_suite",

    # Validation
    "validate_v3_compliance",
    "get_compliance_report",
    "test_v3_compliance",
    "validate_script",
    "validate_pronouns",
    "validate_verbs",
    "validate_case_markers",
    "validate_vowel_harmony",

    # Legacy (for compatibility)
    "map_sound",

    # Suggestions
    "suggestions",
    "sentence_variants", 
    "per_token_suggestions",

    # Combo Pipeline
    "process_english_words_input",
    "process_english_sentence_input",
    "process_telugu_word_in_english_script",
    "process_telugu_sentence_in_english_script",
    
    # Enhanced Telugu Mappings
    "is_valid_telugu_word",
    "resolve_anusvara_context_aware",
    "apply_athva_sandhi", 
    "apply_yadagama_sandhi",
    "classify_word_by_ending",
    "get_varga_for_consonant",
    "get_consonant_nature",
    "MATRAS_COMPLETE",
    "VARGA_CLASSIFICATIONS",
    
    # Merged Pipeline
    "merged_transliterate_word",
    "merged_transliterate_sentence",
    "MergedPipeline",
    
    # Smart Loader
    "init_model",
    "score_candidate", 
    "rerank",
    "backend_name",
]

# Convenience functions
def translate(text: str, include_grammar: bool = False) -> str:
    """
    High-level translation function.

    Args:
        text: English text to translate
        include_grammar: If True, apply full grammar (cases, SOV, etc.)

    Returns:
        Telugu text
    """
    if include_grammar:
        # Apply full grammar processing using enhanced tense engine
        from .enhanced_tense import translate_sentence
        return translate_sentence(text)
    else:
        # Just transliterate
        return eng_to_telugu(text)


def is_v3_compliant(text: str) -> bool:
    """
    Check if text is v3.0 compliant.

    Args:
        text: Telugu text to check

    Returns:
        True if compliant, False otherwise
    """
    result = validate_v3_compliance(text)
    return result['is_compliant']


def get_compliance_score(text: str) -> float:
    """
    Get v3.0 compliance score (0-100).

    Args:
        text: Telugu text to check

    Returns:
        Compliance score (0-100)
    """
    result = validate_v3_compliance(text)
    return result['score']


# Check for optional dependencies
def check_dependencies():
    """
    Check which optional features are available.

    Returns:
        Dict with information about available features
    """
    info = {
        'core': True,
        'version': __version__,
        'package': 'telugu_engine',
    }

    # Check for sentence-transformers (ML features)
    try:
        import sentence_transformers
        info['sentence_transformers'] = True
        info['sentence_transformers_version'] = sentence_transformers.__version__
    except ImportError:
        info['sentence_transformers'] = False

    return info


def get_word_suggestions(word: str, limit: int = 8) -> list:
    """
    Get multiple Telugu suggestions for a Roman word.
    
    Args:
        word: Roman word to suggest Telugu variants for
        limit: Maximum number of suggestions to return
        
    Returns:
        List of suggested Telugu spellings
    """
    return suggestions(word, limit=limit)


def get_sentence_suggestions(text: str, topn: int = 5, per_word: int = 4, beam: int = 6) -> list:
    """
    Get multiple Telugu sentence suggestions for Roman input.
    
    Args:
        text: Roman sentence to suggest Telugu variants for
        topn: Number of top sentence variants to return
        per_word: Candidates per token
        beam: Beam width for search
        
    Returns:
        List of suggested Telugu sentences
    """
    return sentence_variants(text, topn=topn, per_word=per_word, beam=beam)


def get_token_suggestions(text: str, limit: int = 6) -> list:
    """
    Get per-token suggestions for a Roman sentence.
    
    Args:
        text: Roman sentence to get per-token suggestions for
        limit: Maximum number of suggestions per token
        
    Returns:
        List of lists, each containing suggestions for a token
    """
    return per_token_suggestions(text, limit=limit)


def get_english_word_variants(word: str, limit: int = 8) -> list:
    """
    Get Telugu variants for English word using combo pipeline.

    Args:
        word: English word to get Telugu variants for
        limit: Maximum number of variants to return

    Returns:
        List of Telugu variants
    """
    result = process_english_words_input(word, per_word_limit=limit)
    return result["combined_word_variants"][:limit]


def get_english_sentence_variants(sentence: str, topn: int = 5, per_word: int = 4, beam: int = 6) -> list:
    """
    Get Telugu sentence variants for English sentence using combo pipeline.

    Args:
        sentence: English sentence to get Telugu variants for
        topn: Number of top sentence variants to return
        per_word: Candidates per token
        beam: Beam width for search

    Returns:
        List of Telugu sentence variants
    """
    result = process_english_sentence_input(sentence, per_word_limit=per_word, beam=beam)
    return result["sentence_variants"][:topn]


def validate_telugu_word_structure(word: str) -> bool:
    """
    Validate Telugu word structure using grammar-based rules.

    Args:
        word: Telugu word to validate

    Returns:
        True if valid structure, False otherwise
    """
    return is_valid_telugu_word(word)


def resolve_anusvara_for_context(following_char: str) -> str:
    """
    Resolve anusvara (ం) to appropriate homorganic nasal based on following consonant.

    Args:
        following_char: The character that follows the anusvara

    Returns:
        Appropriate homorganic nasal consonant
    """
    return resolve_anusvara_context_aware(following_char)


def apply_sandhi_between_words(word1: str, word2: str, sandhi_type: str = "athva") -> str:
    """
    Apply sandhi rules between two words.

    Args:
        word1: First word
        word2: Second word 
        sandhi_type: Type of sandhi ("athva", "yadagama")

    Returns:
        Combined word with sandhi applied
    """
    if sandhi_type == "athva":
        return apply_athva_sandhi(word1, word2)
    elif sandhi_type == "yadagama":
        return apply_yadagama_sandhi(word1, word2)
    else:
        # Default to athva
        return apply_athva_sandhi(word1, word2)


def get_word_classification_by_ending(word: str) -> str:
    """
    Classify word by its ending for morphophonology rules.

    Args:
        word: Telugu word to classify

    Returns:
        Classification of the word by ending
    """
    return classify_word_by_ending(word)


def get_consonant_varga(consonant: str) -> str:
    """
    Get the varga (class) of a consonant.

    Args:
        consonant: Telugu consonant

    Returns:
        Varga name (velar, palatal, retroflex, dental, labial)
    """
    return get_varga_for_consonant(consonant)


def get_consonant_type(consonant: str) -> str:
    """
    Get the nature of a consonant (harsh/soft/stable).

    Args:
        consonant: Telugu consonant

    Returns:
        Consonant nature (harsh, soft, stable)
    """
    return get_consonant_nature(consonant)


def transliterate_with_enhanced_pipeline(text: str, mode: str = "word") -> dict:
    """
    Transliterate text using the enhanced merged pipeline.

    Args:
        text: Input text to transliterate
        mode: "word" for single word, "sentence" for full sentence

    Returns:
        Dictionary with transliteration results and metadata
    """
    pipeline = MergedPipeline()
    if mode == "word":
        return pipeline.process_word(text)
    elif mode == "sentence":
        return pipeline.process_sentence(text)
    else:
        raise ValueError("mode must be 'word' or 'sentence'")


def init_model_backend() -> bool:
    """
    Initialize the smart loader model backend.
    
    Returns:
        True if successful, False if no backend available
    """
    from .smart_loader import init_model
    return init_model()


def score_telugu_candidate(prompt: str, candidate: str) -> float:
    """
    Score a Telugu candidate based on relevance to prompt.
    
    Args:
        prompt: The input prompt
        candidate: The candidate Telugu text to score
    
    Returns:
        Score (higher is better)
    """
    from .smart_loader import score_candidate
    return score_candidate(prompt, candidate)


def rerank_candidates(prompt: str, candidates: list, top_k: int = None) -> list:
    """
    Rerank candidates by scoring them against the prompt.
    
    Args:
        prompt: The input prompt
        candidates: List of candidate strings
        top_k: Number of top results to return (None for all)
    
    Returns:
        List of (candidate, score) tuples sorted by score
    """
    from .smart_loader import rerank
    return rerank(prompt, candidates, top_k)


def get_scoring_backend() -> str:
    """
    Get the name of the active scoring backend.
    
    Returns:
        Backend name ("torch", "onnx", or "fallback")
    """
    from .smart_loader import backend_name
    return backend_name()


# Add to public API
__all__.extend([
    "translate",
    "is_v3_compliant",
    "get_compliance_score",
    "check_dependencies",
    "get_word_suggestions",
    "get_sentence_suggestions",
    "get_token_suggestions",
    "get_english_word_variants",
    "get_english_sentence_variants",
    "validate_telugu_word_structure",
    "resolve_anusvara_for_context", 
    "apply_sandhi_between_words",
    "get_word_classification_by_ending",
    "get_consonant_varga",
    "get_consonant_type",
    "transliterate_with_enhanced_pipeline",
    "init_model_backend",
    "score_telugu_candidate",
    "rerank_candidates",
    "get_scoring_backend",
])
