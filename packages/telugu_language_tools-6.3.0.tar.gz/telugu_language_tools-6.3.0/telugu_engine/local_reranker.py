# local_reranker.py
"""
Local reranker using shared utilities for consistent scoring.
"""
from typing import List, Tuple
from . import rerank_utils


def score_candidate(roman_prompt: str, candidate: str) -> float:
    """
    Score a candidate using shared utilities.
    """
    # Use the shared rerank function to get scores for just this one candidate
    all_scores = rerank_utils.rerank_candidates(roman_prompt, [candidate])
    return all_scores[0][1] if all_scores else 0.0


def rerank(roman_prompt: str, candidates: List[str]) -> List[Tuple[str,float]]:
    """
    Rerank candidates using shared utilities.
    """
    return rerank_utils.rerank_candidates(roman_prompt, candidates)


def pick_best(roman_prompt: str, candidates: List[str]) -> str:
    """
    Pick best candidate using shared utilities.
    """
    return rerank_utils.pick_best_candidate(roman_prompt, candidates)
