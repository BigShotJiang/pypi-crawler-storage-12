"""
Adaptive Learning System for Telugu Language Tools
===================================================

This module implements online learning that improves suggestions based on user feedback.
Instead of full retraining (slow), it uses:
1. Feedback collection - Track which suggestions users pick
2. Preference learning - Adjust scores based on user choices
3. Incremental updates - Small, fast model updates
4. Background training - Optional periodic retraining

Usage:
    from telugu_engine.adaptive_learner import AdaptiveLearner

    learner = AdaptiveLearner()

    # Get suggestions with learning
    suggestions = learner.get_suggestions("hello")

    # User picks one
    learner.record_feedback("hello", "హలో", picked=True)

    # Next time, "హలో" will rank higher for "hello"
"""

import os
import json
import time
from typing import List, Dict, Tuple, Optional
from collections import defaultdict
import threading
import pickle


class AdaptiveLearner:
    """
    Learns from user feedback to improve transliteration suggestions.
    """

    def __init__(self, data_dir: Optional[str] = None):
        """
        Initialize adaptive learner.

        Args:
            data_dir: Directory to store learning data (default: ~/.telugu_learning)
        """
        if data_dir is None:
            home = os.path.expanduser("~")
            data_dir = os.path.join(home, ".telugu_learning")

        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)

        # Feedback storage
        self.feedback_file = os.path.join(data_dir, "feedback.jsonl")
        self.preferences_file = os.path.join(data_dir, "preferences.pkl")

        # Preference scores: {input: {output: score}}
        self.preferences = defaultdict(lambda: defaultdict(float))

        # Load existing preferences
        self._load_preferences()

        # Statistics
        self.stats = {
            'total_feedback': 0,
            'unique_inputs': 0,
            'last_updated': None
        }
        self._load_stats()

        # Training flag
        self._training_lock = threading.Lock()
        self._training_in_progress = False

    def _load_preferences(self):
        """Load learned preferences from disk."""
        if os.path.exists(self.preferences_file):
            try:
                with open(self.preferences_file, 'rb') as f:
                    loaded = pickle.load(f)
                    self.preferences = defaultdict(lambda: defaultdict(float), loaded)
            except Exception as e:
                print(f"Warning: Could not load preferences: {e}")

    def _save_preferences(self):
        """Save learned preferences to disk."""
        try:
            with open(self.preferences_file, 'wb') as f:
                pickle.dump(dict(self.preferences), f)
        except Exception as e:
            print(f"Warning: Could not save preferences: {e}")

    def _load_stats(self):
        """Load statistics."""
        stats_file = os.path.join(self.data_dir, "stats.json")
        if os.path.exists(stats_file):
            try:
                with open(stats_file, 'r', encoding='utf-8') as f:
                    self.stats = json.load(f)
            except Exception:
                pass

    def _save_stats(self):
        """Save statistics."""
        stats_file = os.path.join(self.data_dir, "stats.json")
        try:
            with open(stats_file, 'w', encoding='utf-8') as f:
                json.dump(self.stats, f, indent=2)
        except Exception:
            pass

    def record_feedback(self, input_text: str, output_text: str,
                       picked: bool = True, score: float = 1.0):
        """
        Record user feedback for a suggestion.

        Args:
            input_text: The input (e.g., English text)
            output_text: The suggested output (e.g., Telugu text)
            picked: Whether user selected this suggestion (True) or rejected it (False)
            score: Optional score (default 1.0 for picked, -0.5 for not picked)
        """
        # Normalize inputs
        input_text = input_text.strip().lower()
        output_text = output_text.strip()

        if not picked:
            score = -0.5

        # Update preferences (exponential moving average)
        alpha = 0.3  # Learning rate
        current_score = self.preferences[input_text][output_text]
        new_score = current_score + alpha * (score - current_score)
        self.preferences[input_text][output_text] = new_score

        # Log feedback to file
        feedback_entry = {
            'timestamp': time.time(),
            'input': input_text,
            'output': output_text,
            'picked': picked,
            'score': score
        }

        try:
            with open(self.feedback_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(feedback_entry, ensure_ascii=False) + '\n')
        except Exception as e:
            print(f"Warning: Could not log feedback: {e}")

        # Update stats
        self.stats['total_feedback'] += 1
        self.stats['unique_inputs'] = len(self.preferences)
        self.stats['last_updated'] = time.time()

        # Save periodically (every 10 feedbacks)
        if self.stats['total_feedback'] % 10 == 0:
            self._save_preferences()
            self._save_stats()

    def get_preference_score(self, input_text: str, output_text: str) -> float:
        """
        Get learned preference score for an input-output pair.

        Returns:
            Score between -1.0 and 1.0 (higher = more preferred)
        """
        input_text = input_text.strip().lower()
        output_text = output_text.strip()
        return self.preferences[input_text].get(output_text, 0.0)

    def rerank_suggestions(self, input_text: str, suggestions: List[str],
                          base_scores: Optional[List[float]] = None) -> List[Tuple[str, float]]:
        """
        Re-rank suggestions using learned preferences.

        Args:
            input_text: The input text
            suggestions: List of suggested outputs
            base_scores: Optional base scores from other rankers

        Returns:
            List of (suggestion, combined_score) tuples, sorted best first
        """
        input_text = input_text.strip().lower()

        if base_scores is None:
            base_scores = [0.0] * len(suggestions)

        ranked = []
        for suggestion, base_score in zip(suggestions, base_scores):
            # Get learned preference
            pref_score = self.get_preference_score(input_text, suggestion)

            # Combine base score + preference (weighted)
            combined_score = base_score + (2.0 * pref_score)

            ranked.append((suggestion, combined_score))

        # Sort by combined score (descending)
        ranked.sort(key=lambda x: x[1], reverse=True)

        return ranked

    def get_top_suggestions(self, input_text: str, limit: int = 5) -> List[str]:
        """
        Get top learned suggestions for an input (from historical feedback).

        Args:
            input_text: The input text
            limit: Maximum number of suggestions

        Returns:
            List of top suggestions based on learned preferences
        """
        input_text = input_text.strip().lower()

        if input_text not in self.preferences:
            return []

        # Get all outputs for this input, sorted by score
        outputs = self.preferences[input_text]
        sorted_outputs = sorted(outputs.items(), key=lambda x: x[1], reverse=True)

        return [output for output, score in sorted_outputs[:limit]]

    def get_statistics(self) -> Dict:
        """Get learning statistics."""
        return {
            **self.stats,
            'unique_mappings': sum(len(v) for v in self.preferences.values()),
            'data_dir': self.data_dir
        }

    def clear_learning_data(self):
        """Clear all learned preferences (use with caution!)."""
        self.preferences = defaultdict(lambda: defaultdict(float))
        self._save_preferences()
        self.stats = {
            'total_feedback': 0,
            'unique_inputs': 0,
            'last_updated': None
        }
        self._save_stats()

    def export_training_data(self, output_file: str):
        """
        Export collected feedback as training data for model retraining.

        Args:
            output_file: Path to output file (JSON format)
        """
        training_data = []

        # Read all feedback
        if os.path.exists(self.feedback_file):
            with open(self.feedback_file, 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        entry = json.loads(line)
                        if entry.get('picked', False):
                            training_data.append({
                                'input': entry['input'],
                                'output': entry['output'],
                                'score': entry.get('score', 1.0)
                            })
                    except Exception:
                        continue

        # Write training data
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(training_data, f, ensure_ascii=False, indent=2)

        return len(training_data)

    def train_from_feedback(self, min_samples: int = 100) -> bool:
        """
        Trigger background training if enough feedback collected.

        Args:
            min_samples: Minimum number of feedback samples needed

        Returns:
            True if training started, False otherwise
        """
        if self._training_in_progress:
            return False

        if self.stats['total_feedback'] < min_samples:
            return False

        # Start training in background thread
        def _train():
            with self._training_lock:
                self._training_in_progress = True
                try:
                    # Export training data
                    train_file = os.path.join(self.data_dir, "training_data.json")
                    n_samples = self.export_training_data(train_file)

                    print(f"Exported {n_samples} training samples to {train_file}")
                    print("Note: Actual model retraining requires separate script.")
                    print("For now, using preference-based ranking.")

                    # TODO: Implement actual model fine-tuning here
                    # This would require:
                    # 1. Loading the base model
                    # 2. Fine-tuning on collected data
                    # 3. Saving updated model

                finally:
                    self._training_in_progress = False

        thread = threading.Thread(target=_train, daemon=True)
        thread.start()
        return True


# Global instance for convenience
_global_learner = None

def get_learner() -> AdaptiveLearner:
    """Get global adaptive learner instance."""
    global _global_learner
    if _global_learner is None:
        _global_learner = AdaptiveLearner()
    return _global_learner


# Convenience functions
def record_choice(input_text: str, chosen_output: str):
    """Record that user chose this output for this input."""
    learner = get_learner()
    learner.record_feedback(input_text, chosen_output, picked=True)


def get_learned_suggestions(input_text: str, limit: int = 5) -> List[str]:
    """Get suggestions based on learned preferences."""
    learner = get_learner()
    return learner.get_top_suggestions(input_text, limit)


def rerank_with_learning(input_text: str, suggestions: List[str],
                        base_scores: Optional[List[float]] = None) -> List[Tuple[str, float]]:
    """Rerank suggestions using learned preferences."""
    learner = get_learner()
    return learner.rerank_suggestions(input_text, suggestions, base_scores)


__all__ = [
    'AdaptiveLearner',
    'get_learner',
    'record_choice',
    'get_learned_suggestions',
    'rerank_with_learning',
]


# Example usage
if __name__ == "__main__":
    print("="*70)
    print("  ADAPTIVE LEARNING SYSTEM DEMO")
    print("="*70 + "\n")

    learner = AdaptiveLearner()

    # Simulate user feedback
    print("1. Recording user feedback:")
    learner.record_feedback("hello", "హలో", picked=True)
    learner.record_feedback("hello", "హెల్లో", picked=False)
    learner.record_feedback("hello", "హలో", picked=True)  # User consistently picks this

    learner.record_feedback("goodbye", "వీడ్కోలు", picked=True)

    print(f"   Recorded feedback for 'hello' and 'goodbye'\n")

    # Test reranking
    print("2. Re-ranking suggestions with learned preferences:")
    suggestions = ["హలో", "హెల్లో", "హల", "హేలో"]
    base_scores = [0.5, 0.6, 0.3, 0.4]  # Suppose these are ML scores

    ranked = learner.rerank_suggestions("hello", suggestions, base_scores)

    print("   Input: 'hello'")
    print("   Suggestions (re-ranked):")
    for suggestion, score in ranked:
        pref = learner.get_preference_score("hello", suggestion)
        print(f"      {suggestion} - Score: {score:.2f} (base + preference {pref:.2f})")

    print("\n3. Statistics:")
    stats = learner.get_statistics()
    for key, value in stats.items():
        print(f"   {key}: {value}")

    print("\n" + "="*70)
