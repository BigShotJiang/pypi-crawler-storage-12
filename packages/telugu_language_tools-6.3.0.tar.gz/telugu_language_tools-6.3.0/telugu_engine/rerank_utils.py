"""
telugu_engine/rerank_utils.py
Shared utility functions for candidate reranking and scoring
"""
from typing import List, Tuple, Optional
import re

def is_valid_telugu_text(text: str) -> bool:
    """
    Check if text contains valid Telugu characters.
    """
    try:
        from .enhanced_telugu_mappings import is_valid_telugu_word
        # Check each word in the text
        words = text.split()
        return all(is_valid_telugu_word(word) for word in words if word.strip())
    except Exception:
        # Fallback: check if it contains Telugu characters
        return any('ఀ' <= ch <= '౿' for ch in text)

def calculate_edit_distance_similarity(text1: str, text2: str) -> float:
    """
    Calculate normalized edit distance similarity between two texts.
    Returns similarity score (higher is more similar, 0.0 to 1.0)
    """
    def lev(a: str, b: str) -> int:
        la, lb = len(a), len(b)
        dp = list(range(lb + 1))
        for i, ca in enumerate(a, 1):
            prev = i
            for j, cb in enumerate(b, 1):
                cur = dp[j]
                dp[j] = prev if ca == cb else 1 + min(prev, dp[j - 1], dp[j])
                prev = cur
        return dp[lb]
    
    if not text1 and not text2:
        return 1.0
    if not text1 or not text2:
        return 0.0
    
    max_len = max(len(text1), len(text2))
    edit_distance = lev(text1, text2)
    return 1.0 - (edit_distance / max_len)

def calculate_weirdness_penalty(text: str) -> float:
    """
    Calculate penalty for text that looks 'weird' or invalid.
    Higher penalty means less desirable.
    """
    penalty = 0.0
    
    # Penalty for Roman characters
    roman_chars = sum(1 for ch in text if ('a' <= ch <= 'z') or ('A' <= ch <= 'Z'))
    penalty += roman_chars * 2.0
    
    # Penalty for excessive viramas
    virama_count = text.count('్')
    penalty += virama_count * 0.5
    
    # Penalty for mixed scripts (if text has both Telugu and Roman)
    has_telugu = any('ఀ' <= ch <= '౿' for ch in text)
    has_roman = any(('a' <= ch <= 'z') or ('A' <= ch <= 'Z') for ch in text)
    if has_telugu and has_roman:
        penalty += 3.0
    
    return penalty

def score_by_validity(text: str) -> float:
    """
    Score based on validity (1.0 if valid, 0.0 if not)
    """
    if is_valid_telugu_text(text):
        return 1.0
    return 0.0

def score_by_pattern_matching(text: str, expected_pattern: Optional[str] = None) -> float:
    """
    Score based on expected patterns (if provided)
    """
    if expected_pattern is None:
        return 0.0
    # This would implement pattern matching logic if needed
    return 0.0

def rerank_candidates(prompt: str, candidates: List[str], 
                     score_validity: bool = True,
                     score_similarity: bool = True,
                     score_penalty: bool = True) -> List[Tuple[str, float]]:
    """
    Generic reranking function that can use multiple scoring strategies.
    """
    scored = []
    for candidate in candidates:
        total_score = 0.0
        
        # Validity scoring
        if score_validity:
            total_score += score_by_validity(candidate) * 2.0  # Weight validity more
            
        # Similarity to prompt scoring (if available)
        if score_similarity and prompt:
            # We need a base transliteration for comparison
            try:
                from .transliterator import eng_to_telugu
                base_translit = eng_to_telugu(prompt)
                similarity = calculate_edit_distance_similarity(candidate, base_translit)
                total_score += similarity * 1.5  # Weight similarity
            except Exception:
                pass  # Fallback if transliterator unavailable
                
        # Penalty scoring
        if score_penalty:
            penalty = calculate_weirdness_penalty(candidate)
            total_score -= penalty
        
        scored.append((candidate, total_score))
    
    # Sort by score in descending order
    scored.sort(key=lambda x: x[1], reverse=True)
    return scored

def pick_best_candidate(prompt: str, candidates: List[str]) -> str:
    """
    Pick the best candidate from a list using the reranking logic.
    """
    if not candidates:
        return ""
    
    ranked = rerank_candidates(prompt, candidates)
    return ranked[0][0] if ranked else candidates[0]