
import enum


class ResposneStatus(enum.Enum):
    ok = "ok"
    error = "error"
