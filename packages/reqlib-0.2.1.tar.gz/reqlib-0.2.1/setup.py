from setuptools import setup, find_packages

setup(
    name="reqlib",  # اسم المكتبة على PyPI
    version="0.2.1",
    description="Simple HTTP client like requests",
    author="Mohhamed Yahea",
    author_email="asiacellfree@gmail.com",
    url="https://github.com/username/req",  # اختياري
    packages=find_packages(),
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires=">=3.6",
)