
major = 1
minor = 0
micro = 3
__version__ = f"{major}.{minor}.{micro}"
