from classiq.interface.enum_utils import StrEnum


class EncodingType(StrEnum):
    BINARY = "BINARY"
    ONE_HOT = "ONE_HOT"
