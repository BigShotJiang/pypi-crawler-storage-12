# Calico - Django-based Static Site Generator

Calico is a powerful static site generator built on top of Django, combining the flexibility of Django's templating system with the simplicity and performance of static websites.

## Features

- **Django-powered**: Leverage Django's robust templating engine and ecosystem
- **Plugin System**: Extensible architecture using pluggy (via djp)
- **Widget-based Components**: Modular, reusable UI components
- **Multiple Themes**: Built-in PicoCSS theme with support for custom themes
- **Blog System**: Full-featured blog plugin with categories, tags, and RSS
- **Collections**: Organize and display grouped content
- **Development Server**: Live-reload development environment
- **Search Support**: Built-in search functionality with lunr.js

## Installation

```bash
pip install calico-ssg
```

Or install from source:

```bash
git clone https://codeberg.org/emmaDelescolle/calico.git
cd calico
pip install -e .
```

## Quick Start

1. **Initialize a new site**:
```bash
calico init
```

2. **Start the development server**:
```bash
calico run
```

3. **Build your static site**:
```bash
calico build
```

## Creating Content

Content in Calico is written in Markdown with YAML frontmatter:

```markdown
---
title: My First Post
date: 2024-01-15
tags: [introduction, calico]
---

# Welcome to My Site

This is my first post using Calico!
```

## Plugin Development

Create custom plugins to extend Calico's functionality:

```bash
calico start_plugin my_plugin
```

Plugins can hook into various aspects of the build process:
- Add template tags and filters
- Register themes and templates
- Include CSS and JavaScript
- Define custom content collections
- Add context processors

## Project Structure

```
my-site/
   content/          # Markdown content files
   static/           # Static assets (images, css, js)
   templates/        # Custom templates
   plugins/          # Local plugins
   config.yml        # Site configuration
```

## Documentation

For detailed documentation, visit [https://calico-ssg.com/docs/index.html](https://calico-ssg.com/docs/index.html).

## Contributing

Contributions are welcome! Please feel free to submit issues and pull requests to the [Calico repository](https://codeberg.org/emmaDelescolle/calico).

## License

Calico is distributed under the MIT License.

## Links

- **Documentation**: [https://calico-ssg.com/docs/index.html](https://calico-ssg.com/docs/index.html)
- **Source Code**: [https://codeberg.org/emmaDelescolle/calico](https://codeberg.org/emmaDelescolle/calico)
- **Issue Tracker**: [https://codeberg.org/emmaDelescolle/calico/issues](https://codeberg.org/emmaDelescolle/calico/issues)