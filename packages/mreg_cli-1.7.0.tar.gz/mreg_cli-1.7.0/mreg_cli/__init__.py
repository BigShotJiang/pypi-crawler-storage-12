"""The mreg_cli package."""

from __future__ import annotations

from mreg_cli.__about__ import __version__  # noqa: F401 # allows mreg_cli.__version__
