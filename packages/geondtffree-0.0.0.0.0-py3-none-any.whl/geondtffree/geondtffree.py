print("Thank you for your interest, however, this library has not been released yet, this is a placeholder.")
quit()
