"""Context Lens - Give your LLM glasses to understand meaning, not just read words."""

__version__ = "0.1.3"
__author__ = "Context Lens"
__description__ = "Semantic search for AI assistants via MCP"
