"""
Stuff which went wrong.
"""


class InvalidTransaction(Exception):
    """
    A transaction is invalid.
    """
