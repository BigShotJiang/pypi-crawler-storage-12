//! general pipelines are used during analysis in multiple kinds of tests.

mod identity;
pub mod into;
pub mod maybe_into;
