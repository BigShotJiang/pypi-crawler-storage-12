We recommend to install another addon (one for each country) in order to
relate NUTS with states defined by each localization addon, for example:

- l10n_es_location_nuts : Spanish Provinces (NUTS level 4) related to
  Partner State
- l10n_de_location_nuts : German states (NUTS level 2) related to
  Partner State
- l10n_nl_location_nuts : Dutch provinces (NUTS level 3 and 4) related
  to Partner State
