Only Administrator can manage NUTS list (it is not neccesary because it
is an European convention) but any registered user can read them, in
order to allow to assign them to partner object.
