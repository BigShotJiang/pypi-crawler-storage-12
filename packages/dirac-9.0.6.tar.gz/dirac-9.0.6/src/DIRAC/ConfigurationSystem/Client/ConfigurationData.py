from DIRAC.ConfigurationSystem.private.ConfigurationData import ConfigurationData

gConfigurationData = ConfigurationData()
