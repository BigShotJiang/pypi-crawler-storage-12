"""
   DIRAC.ConfigurationSystem.Client.Helpers package
"""
from DIRAC.ConfigurationSystem.Client.Helpers.Path import *
from DIRAC.ConfigurationSystem.Client.Helpers.CSGlobals import getCSExtensions, getVO
