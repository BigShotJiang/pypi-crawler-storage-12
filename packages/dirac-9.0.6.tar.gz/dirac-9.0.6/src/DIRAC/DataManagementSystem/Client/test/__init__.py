"""
   DIRAC.DataManagementSystem.Client test package
"""
