

class SponsrDumperError(Exception):
    """Base exception."""
