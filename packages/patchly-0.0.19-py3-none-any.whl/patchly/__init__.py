__version__ = "0.0.19"

from patchly.sampler import GridSampler, SamplingMode
from patchly.aggregator import Aggregator
from patchly.slicer import slicer