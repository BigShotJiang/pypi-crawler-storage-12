from perf_sentinel.ci.cli import main

__all__ = ['main']
