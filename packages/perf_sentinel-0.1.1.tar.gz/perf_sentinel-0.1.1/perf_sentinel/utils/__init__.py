from perf_sentinel.utils.json_logger import log_performance

__all__ = ['log_performance']
