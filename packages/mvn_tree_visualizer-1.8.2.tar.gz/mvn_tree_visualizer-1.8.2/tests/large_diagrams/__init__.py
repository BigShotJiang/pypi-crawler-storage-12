"""Large diagram tests package."""
