def test_all_nodes():
    assert True
