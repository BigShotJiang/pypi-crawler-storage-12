# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._intent_resolution import IntentResolutionEvaluator

__all__ = ["IntentResolutionEvaluator"]
