"""Tests for pydagu package"""
