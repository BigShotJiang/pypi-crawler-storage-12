```{toctree}
---
caption: Contents
maxdepth: 1
hidden:
---
    Introduction <self>
    Examples <examples/index>
    Migration Guide from spglib <migration>
```

```{include} ../README.md
:relative-docs: docs/
```
