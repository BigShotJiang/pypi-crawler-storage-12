# pythonbible-dr

The Douay-Rheims (DR) version of the Bible in Python. For use with the `pythonbible` library.
