.. _alembic.runtime.exceptions.toplevel:

=======================
Exception Objects
=======================


.. automodule:: alembic.util.exc
    :members:
