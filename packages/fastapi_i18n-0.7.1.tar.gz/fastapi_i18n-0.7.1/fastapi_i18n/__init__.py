from fastapi_i18n.main import _, get_locale, i18n

__all__ = ("_", "get_locale", "i18n")
