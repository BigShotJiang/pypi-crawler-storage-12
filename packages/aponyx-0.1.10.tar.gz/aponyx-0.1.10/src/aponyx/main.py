def main() -> None:
    """Main entry point."""
    print("Hello from aponyx!")


if __name__ == "__main__":
    main()
