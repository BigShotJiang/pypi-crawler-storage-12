from enum import Enum


class Enum__Comprehend__Detect_Sentiment__Sentiment(str, Enum):
    POSITIVE = "Positive"
    NEUTRAL  = "Neutral"
    MIXED    = "Mixed"
    NEGATIVE = "Negative"