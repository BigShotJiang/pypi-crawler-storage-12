from osbot_aws.aws.bedrock.models.claude.Anthropic__Claude_Instant_V1 import Anthropic__Claude_Instant_V1


class Anthropic__Claude_V2_1(Anthropic__Claude_Instant_V1):

    model_id = 'anthropic.claude-v2:1'