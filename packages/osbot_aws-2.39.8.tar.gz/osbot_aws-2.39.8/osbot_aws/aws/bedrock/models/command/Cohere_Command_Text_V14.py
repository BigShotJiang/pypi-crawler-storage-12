from osbot_aws.aws.bedrock.models.command.Cohere_Command import Cohere_Command


class Cohere_Command_Text_V14(Cohere_Command):
    model_id : str = "cohere.command-text-v14"