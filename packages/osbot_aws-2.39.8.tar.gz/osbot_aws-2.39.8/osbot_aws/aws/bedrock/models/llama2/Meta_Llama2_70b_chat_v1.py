from osbot_aws.aws.bedrock.models.llama2.Meta_Llama2 import Meta_Llama2


class Meta_Llama2_70B_Chat_V1(Meta_Llama2):

    model_id: str = "meta.llama2-70b-chat-v1"