from .faithfulnessTest import faithfulness

# Currently existing tests
testMapping = {
    "cot_faithfulness" : faithfulness,
}
