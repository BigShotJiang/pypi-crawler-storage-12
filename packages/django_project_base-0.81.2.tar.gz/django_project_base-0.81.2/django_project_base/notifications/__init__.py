from django_project_base.notifications.constants import NOTIFICATIONS_APP_ID

default_app_config = "%s.apps.DjangoProjectBaseNotifyConfig" % NOTIFICATIONS_APP_ID
