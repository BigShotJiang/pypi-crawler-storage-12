import solidipes as sp  # noqa: F401
from solidipes.plugins.management import get_installed_plugins_info, install_plugin, remove_plugin  # noqa: F401

# Example usage:
# sp.load_file("path/to/file")
# sp.close_cached_metadata()
# sp.plugins.discovery.loader_list
