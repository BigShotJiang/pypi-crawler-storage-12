# TavilyApp MCP Server

An MCP Server for the TavilyApp API.

## 🛠️ Tool List

This is automatically generated from OpenAPI schema for the TavilyApp API.


| Tool | Description |
|------|-------------|
| `search_and_summarize` | Queries the Tavily API to perform a web search. It returns a direct AI-generated answer if available; otherwise, it provides a formatted summary of the top three search results, including their titles and snippets. |
