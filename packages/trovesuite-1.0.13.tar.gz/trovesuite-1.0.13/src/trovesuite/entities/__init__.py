"""
TroveSuite Entities Module

Shared entities and response models for TroveSuite services.
"""

from .sh_response import Respons

__all__ = [
    "Respons"
]
