"""Test package for gopher-mcp."""
