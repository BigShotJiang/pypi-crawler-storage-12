from __future__ import annotations

from .__main__ import *

__version__ = "0.1.4"
__name__ = "MinecraftDockerCLI"
