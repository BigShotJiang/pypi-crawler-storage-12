"""Test package for PyPI version cleaner workflow."""

__version__ = "0.1.3"

def hello():
    """Simple test function."""
    return "Hello from terminator-test-cleaner!"
