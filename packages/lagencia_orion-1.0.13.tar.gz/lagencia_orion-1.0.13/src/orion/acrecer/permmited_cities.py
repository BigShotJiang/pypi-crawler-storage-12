CIUDADES = [
    "EL RETIRO",
    "ENVIGADO",
    "ITAGUI",
    "Itaguí",
    "LA CEJA",
    "LA ESTRELLA",
    "MEDELLÍN",
    "RETIRO",
    "RIONEGRO",
    "SABANETA",
    "San Antonio De Pereira",
    "San Antonio De Prado",
]
