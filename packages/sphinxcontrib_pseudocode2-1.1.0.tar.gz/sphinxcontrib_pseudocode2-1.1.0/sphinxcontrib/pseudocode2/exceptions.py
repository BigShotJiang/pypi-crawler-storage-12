from sphinx.errors import SphinxError


class Pseudocode2Error(SphinxError):
    category = "PseudoCode2 Error"
