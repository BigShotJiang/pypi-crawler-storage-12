def main():
    print("Hello from depquery!")


if __name__ == "__main__":
    main()
