Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/logging_simpletest.py
    :caption: examples/logging_simpletest.py
    :linenos:
