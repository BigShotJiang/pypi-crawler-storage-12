"""Translate Bot - A translation bot using LXMFy and Argos Translate.
"""

__version__ = "1.2.2"
