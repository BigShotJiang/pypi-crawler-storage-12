"""veriq.__main__ module."""

from ._cli.main import main

main()
