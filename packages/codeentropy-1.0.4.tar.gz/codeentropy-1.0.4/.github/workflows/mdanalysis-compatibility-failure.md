---
title: CI Failure: MDAnalysis v{{ env.MDA_VERSION }} / Python {{ env.PYTHON_VERSION }}
labels: CI Failure, MDAnalysis Compatibility
---

### Automated MDAnalysis Compatibility Test Failure

**MDAnalysis version**: `{{ env.MDA_VERSION }}`  
**Python version**: `{{ env.PYTHON_VERSION }}`  
**Workflow Run**: [Run #{{ env.RUN_NUMBER }}]({{ env.RUN_URL }})
