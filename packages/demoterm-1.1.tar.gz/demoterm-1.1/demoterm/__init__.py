"""demoterm makes your CLI demos more visual by displaying what you type."""

__version__ = "1.1"
