## cdf 

### Added

- [alpha] Support for Infield Location Config in the `cdf build/deploy`
methods.

## templates

No changes.