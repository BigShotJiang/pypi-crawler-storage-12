"""
SSM Stack Library Module
"""
