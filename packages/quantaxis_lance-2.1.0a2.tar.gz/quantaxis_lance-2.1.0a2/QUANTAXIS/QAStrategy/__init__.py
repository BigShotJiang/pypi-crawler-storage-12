##

from QUANTAXIS.QAStrategy.util import QA_data_futuremin_resample
from QUANTAXIS.QAStrategy.qactabase import QAStrategyCtaBase


"""
QAStrategy 提供了一个示例流程
包括且不限于

QACtabase :  单标的研究基类

QAMultiBase: 多标的多市场的研究基类

QAHedgeBase: 双标的对冲/套利的研究基类

QAFactorBase: 因子工厂模式的研究基类
"""

