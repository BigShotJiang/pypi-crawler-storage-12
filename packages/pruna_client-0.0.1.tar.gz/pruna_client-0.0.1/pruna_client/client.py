"""Pruna API client for synchronous and asynchronous image generation and editing."""
import base64
import os
import time
from io import BytesIO
from typing import Any, Optional, Union

import requests
from PIL import Image

from .models import PrunaResponse


class PrunaClient:
    """Client for making synchronous and asynchronous requests to Pruna API."""
    
    DEFAULT_BASE_URL = "https://api.pruna.ai/v1"
    
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        """
        Initialize Pruna API client.
        
        Args:
            api_key: Your Pruna API key. If not provided, will use PRUNA_API_KEY env var.
            base_url: Base URL for the API. Defaults to https://api.pruna.ai/v1
        """
        self.api_key = api_key or os.getenv("PRUNA_API_KEY")
        if not self.api_key:
            raise ValueError("API key must be provided or set as PRUNA_API_KEY environment variable")
        
        self.base_url = base_url or self.DEFAULT_BASE_URL
        self.base_headers = {
            "apikey": self.api_key,
            "Content-Type": "application/json"
        }
    
    def generate_text_to_image(
        self, model: str, prompt: str, sync: bool = True, **kwargs: Any
    ) -> PrunaResponse:
        """
        Generate an image from a text prompt.
        
        Args:
            model: Model name (e.g., "p-image")
            prompt: Text description of the image to generate
            sync: If True, use synchronous mode (waits for completion). If False, use async mode (returns immediately).
            **kwargs: Additional parameters to pass to the API
        
        Returns:
            PrunaResponse with status, generation_url, and image (if successful)
        
        Raises:
            requests.exceptions.RequestException: For network or HTTP errors
        """
        input_data = {
            "prompt": prompt,
            **kwargs
        }
        
        response = self.generate(model=model, input=input_data, sync=sync)
        
        if response.status == "succeeded" and response.generation_url:
            image = self._download_image(response.generation_url)
            response.image = image
        
        return response
    
    def generate_image_edit(
        self,
        model: str,
        prompt: str,
        images: list[Union[str, Image.Image]],
        sync: bool = True,
        **kwargs: Any
    ) -> PrunaResponse:
        """
        Edit images using p-image-edit model.
        
        This method handles file uploads and then makes the editing request.
        
        Args:
            model: Model name (e.g., "p-image-edit")
            prompt: Text description of the desired edit
            images: List of images to upload and edit (1-5 images). Each can be:
                - str: File path or data URI (e.g., "data:image/png;base64,...")
                - Image.Image: PIL Image object
            sync: If True, use synchronous mode (waits for completion). If False, use async mode (returns immediately).
            **kwargs: Additional parameters to pass to the API
        
        Returns:
            PrunaResponse with status, generation_url, and image (if successful)
        
        Raises:
            requests.exceptions.RequestException: For network or HTTP errors
            IOError: For file reading errors
        """

        # Upload files and get their URLs
        uploaded_urls = []
        for image_input in images:
            file_url = self.upload_image(image_input)
            if not file_url:
                raise ValueError("Failed to upload image(s). Check API key permissions and file format.")
            uploaded_urls.append(file_url)
        
        # Prepare input data for editing
        input_data = {
            "prompt": prompt,
            "images": uploaded_urls,
            **kwargs
        }
        
        response = self.generate(model=model, input=input_data, sync=sync)
        
        if response.status == "succeeded" and response.generation_url:
            image = self._download_image(response.generation_url)
            response.image = image
        
        return response
    
    def generate(
        self,
        model: str,
        input: dict[str, Any],
        sync: bool = True,
        **kwargs: Any
    ) -> PrunaResponse:
        """
        General method to generate content with any model.
        
        Args:
            model: Model name (e.g., "p-image", "p-image-edit")
            input: Input parameters for the model
            sync: If True, use synchronous mode (waits for completion). If False, use async mode (returns immediately).
            **kwargs: Additional parameters to merge into input
        
        Returns:
            PrunaResponse with status and generation_url (sync) or prediction_id and get_url (async)
        
        Raises:
            requests.exceptions.RequestException: For network or HTTP errors
        """
        headers = self.base_headers.copy()
        headers["Model"] = model
        
        if sync:
            headers["Try-Sync"] = "true"
        
        payload = {
            "input": {**input, **kwargs}
        }
        
        response = requests.post(
            f"{self.base_url}/predictions",
            headers=headers,
            json=payload,
            timeout=60
        )
        response.raise_for_status()
        
        data = response.json()
        
        # Synchronous mode - response contains status and generation_url directly
        if sync:
            generation_url = data.get("generation_url")
            response = PrunaResponse(
                status=data.get("status", "unknown"),
                generation_url=generation_url,
                message=data.get("message"),
                error=data.get("error")
            )
            # Download and attach image if generation_url is available and status is succeeded
            if response.status == "succeeded" and generation_url:
                image = self._download_image(generation_url)
                response.image = image
            return response
        
        # Asynchronous mode - response contains prediction ID and get_url
        prediction_id = data.get("id")
        get_url = data.get("get_url")
        
        if not prediction_id or not get_url:
            raise ValueError("Missing prediction ID or get_url in async response")
        
        # Return immediately with prediction info for user to poll
        return PrunaResponse(
            status="starting",
            prediction_id=prediction_id,
            get_url=get_url,
            message="Use poll_status() to check completion"
        )
    
    def _normalize_image(self, image_input: Union[str, Image.Image]) -> Optional[BytesIO]:
        """
        Normalize image input to BytesIO for upload.
        
        Args:
            image_input: Can be:
                - str: File path or data URI (e.g., "data:image/png;base64,...")
                - Image.Image: PIL Image object
        
        Returns:
            BytesIO object with image data, or None if error
        """
        try:
            # Handle PIL Image
            if isinstance(image_input, Image.Image):
                buffer = BytesIO()
                image_input.save(buffer, format="PNG")
                buffer.seek(0)
                return buffer
            
            # Handle data URI
            if isinstance(image_input, str) and image_input.startswith("data:image"):
                # Extract base64 data from data URI
                # Format: data:image/png;base64,<base64_string>
                header, encoded = image_input.split(",", 1)
                image_bytes = base64.b64decode(encoded)
                return BytesIO(image_bytes)
            
            # Handle file path
            if isinstance(image_input, str):
                # Assume it's a file path
                with open(image_input, "rb") as f:
                    return BytesIO(f.read())
            
            return None
            
        except Exception as e:
            print(f"Error normalizing image: {e}")
            return None
    
    def _upload_image(self, image_input: Union[str, Image.Image]) -> Optional[str]:
        """
        Upload an image to Pruna API.
        
        According to the API documentation, files are uploaded via multipart/form-data
        with the 'content' field. The response includes URLs to access the uploaded file.
        
        Args:
            image_input: Can be:
                - str: File path or data URI (e.g., "data:image/png;base64,...")
                - Image.Image: PIL Image object
        
        Returns:
            File URL if successful, None otherwise
        """
        headers = {"apikey": self.api_key}
        
        try:
            image_buffer = self._normalize_image(image_input)
            if not image_buffer:
                return None
            
            # Upload file using multipart/form-data with 'content' field
            # See: https://ac25aba50212.eu.kongportals.com/apis/pruna-gateway-api-0/versions/c394b033-d156-4cb7-a176-18ab26390e00/operations/uploadFile
            files = {"content": image_buffer}
            response = requests.post(
                f"{self.base_url}/files",
                headers=headers,
                files=files,
                timeout=60
            )
            response.raise_for_status()
            
            data = response.json()
            # API response includes a 'urls' object with file access URLs
            # See API docs: https://ac25aba50212.eu.kongportals.com/apis/pruna-gateway-api-0/versions/c394b033-d156-4cb7-a176-18ab26390e00/operations/uploadFile
            urls = data.get("urls", {})
            if urls and isinstance(urls, dict):
                # Try common URL field names
                for key in ["url", "download", "access"]:
                    if key in urls:
                        return urls[key]
                # If no standard key found, use first value
                if urls:
                    return list(urls.values())[0]
            
            # Fallback: construct URL from file ID
            file_id = data.get("id")
            if file_id:
                return f"{self.base_url}/files/{file_id}"
            
            return None
            
        except (requests.exceptions.RequestException, IOError, Exception) as e:
            print(f"Error uploading image: {e}")
            return None
    
    def upload_file(self, file_path: str) -> Optional[str]:
        """
        Upload a file to Pruna API.
        
        Args:
            file_path: Path to the file to upload
        
        Returns:
            File URL if successful, None otherwise
        """
        return self.upload_image(file_path)
    
    def poll_status(
        self,
        status_url: Optional[str] = None,
        response: Optional[PrunaResponse] = None,
        poll_interval: float = 2.0,
        max_wait: int = 300
    ) -> PrunaResponse:
        """
        Poll the status endpoint until the prediction is complete.
        
        Args:
            status_url: URL to poll for status (can be provided directly or via response)
            response: PrunaResponse from async generate() call (contains get_url)
            poll_interval: Seconds to wait between polls
            max_wait: Maximum seconds to wait before giving up
        
        Returns:
            PrunaResponse with final status, generation_url, and image (if successful)
        
        Raises:
            requests.exceptions.RequestException: For network or HTTP errors
            ValueError: If neither status_url nor response with get_url is provided
        """
        # Get status URL from response if provided
        if response and response.get_url:
            status_url = response.get_url
        elif not status_url:
            raise ValueError("Either status_url or response with get_url must be provided")
        
        headers = {"apikey": self.api_key}
        start_time = time.time()
        
        while True:
            http_response = requests.get(status_url, headers=headers, timeout=60)
            http_response.raise_for_status()
            
            data = http_response.json()
            status = data.get("status", "unknown")
            
            # Check if completed or failed
            if status == "succeeded":
                generation_url = data.get("generation_url")
                response = PrunaResponse(
                    status=status,
                    generation_url=generation_url,
                    message=data.get("message")
                )
                # Download and attach image if generation_url is available
                if generation_url:
                    image = self._download_image(generation_url)
                    response.image = image
                return response
            elif status == "failed":
                return PrunaResponse(
                    status=status,
                    message=data.get("message"),
                    error=data.get("error", "Prediction failed")
                )
            
            # Check timeout
            if time.time() - start_time > max_wait:
                return PrunaResponse(
                    status="failed",
                    error=f"Timeout after {max_wait} seconds"
                )
            
            # Wait before next poll
            time.sleep(poll_interval)
    
    def _download_image(self, url: str) -> Image.Image:
        """
        Download an image from a URL and convert to PIL Image.
        
        Args:
            url: URL of the image to download
        
        Returns:
            PIL Image
        
        Raises:
            requests.exceptions.RequestException: For network or HTTP errors
        """
        headers = {"apikey": self.api_key}
        response = requests.get(url, headers=headers, timeout=60)
        response.raise_for_status()
        image_data = BytesIO(response.content)
        return Image.open(image_data)

