"""Integration tests for text-to-image generation."""
from PIL import Image

from pruna_client import PrunaResponse


class TestSynchronousTextToImageFlow:
    """Integration tests for synchronous text-to-image generation flow."""
    
    def test_complete_sync_generation_flow(self, client):
        """Test complete synchronous image generation flow from start to finish."""
        # Execute the full flow with real API
        response = client.generate_text_to_image(
            model="p-image",
            prompt="A beautiful sunset over a calm ocean with vibrant colors",
            sync=True
        )
        
        # Verify the result
        assert response is not None
        if isinstance(response.image, Image.Image):
            assert response.image.size[0] > 0
            assert response.image.size[1] > 0    
            assert response.image.mode in ["RGB", "RGBA"]
        elif isinstance(response, PrunaResponse):
            assert response.status in ["succeeded", "processing"]
    
    def test_sync_generation_with_parameters(self, client):
        """Test synchronous generation with additional parameters."""
        response = client.generate_text_to_image(
            model="p-image",
            prompt="A serene mountain landscape at dawn",
            sync=True,
            aspect_ratio="custom",
            width=512,
            height=512
        )
        
        assert response is not None
        if isinstance(response.image, Image.Image):
            assert response.image.size == (512, 512)
    
    def test_sync_generation_error_handling(self, client):
        """Test error handling with invalid input."""
        response = client.generate_text_to_image(
            model="p-image",
            prompt="",  # Empty prompt might cause error
            sync=True
        )
        
        # Should return either an image or an error response
        assert response is not None
        if isinstance(response, PrunaResponse):
            assert response.status in ["succeeded"]


class TestAsynchronousTextToImageFlow:
    """Integration tests for asynchronous text-to-image generation flow with polling."""
    
    def test_complete_async_generation_flow(self, client):
        """Test complete async generation flow: start -> poll -> download."""
        # Start async generation
        response = client.generate_text_to_image(
            model="p-image",
            prompt="An abstract painting with vibrant colors and geometric shapes",
            sync=False
        )
        
        # Verify initial response
        assert isinstance(response, PrunaResponse)
        assert response.status == "starting"
        assert response.prediction_id is not None
        assert response.get_url is not None
        
        # Poll until completion
        final_response = client.poll_status(
            response=response,
            poll_interval=2.0,
            max_wait=120  # 2 minutes max wait
        )
        
        # Verify final status
        assert final_response.status in ["succeeded"]
        
        if final_response.status == "succeeded":
            assert final_response.generation_url is not None
            # Download and verify image
            image = client._download_image(final_response.generation_url)
            assert image is not None
            assert isinstance(image, Image.Image)
    
    def test_async_generation_polling_with_url(self, client):
        """Test async generation polling using status URL directly."""
        # Start async generation
        response = client.generate_text_to_image(
            model="p-image",
            prompt="A futuristic cityscape at night",
            sync=False
        )
        
        assert response.get_url is not None
        
        # Poll using URL directly
        final_response = client.poll_status(
            status_url=response.get_url,
            poll_interval=2.0,
            max_wait=120
        )
        
        assert final_response.status in ["succeeded"]
        if final_response.status == "succeeded":
            assert final_response.generation_url is not None
            # Download and verify image
            image = client._download_image(final_response.generation_url)
            assert image is not None
            assert isinstance(image, Image.Image)
            assert image.size[0] > 0
            assert image.size[1] > 0


class TestEndToEndTextToImageWorkflows:
    """Integration tests for complete end-to-end text-to-image workflows."""
    
    def test_workflow_async_generate_and_download(self, client):
        """Test workflow: async generate -> poll -> download."""
        # Start async generation
        response = client.generate_text_to_image(
            model="p-image",
            prompt="A minimalist geometric design",
            sync=False
        )
        
        assert isinstance(response, PrunaResponse)
        assert response.get_url is not None
        
        # Poll for completion
        final_response = client.poll_status(
            response=response,
            poll_interval=2.0,
            max_wait=120
        )
        
        if final_response.status == "succeeded":
            # Download the image
            image = client._download_image(final_response.generation_url)
            assert image is not None
            assert isinstance(image, Image.Image)
            assert image.size[0] > 0
            assert image.size[1] > 0

