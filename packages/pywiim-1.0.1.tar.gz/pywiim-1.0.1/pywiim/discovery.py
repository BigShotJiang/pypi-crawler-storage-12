"""Device discovery for WiiM and LinkPlay devices.

This module provides SSDP/UPnP discovery and network scanning to find
WiiM and LinkPlay devices on the local network.
"""

from __future__ import annotations

import asyncio
import ipaddress
import logging
import socket
from dataclasses import dataclass
from typing import Any

try:
    from async_upnp_client.search import async_search
except ImportError:
    async_search = None  # type: ignore[assignment]

from .client import WiiMClient
from .exceptions import WiiMError

_LOGGER = logging.getLogger(__name__)

__all__ = [
    "DiscoveredDevice",
    "discover_devices",
    "discover_via_ssdp",
    "scan_network",
    "validate_device",
]


@dataclass
class DiscoveredDevice:
    """Represents a discovered WiiM/LinkPlay device."""

    ip: str
    name: str | None = None
    model: str | None = None
    firmware: str | None = None
    mac: str | None = None
    uuid: str | None = None
    port: int = 80
    protocol: str = "http"  # "http" or "https"
    vendor: str | None = None  # "wiim", "arylic", "audio_pro", etc.
    discovery_method: str = "unknown"  # "ssdp", "network_scan", "manual"
    validated: bool = False  # Whether device was validated via API

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "ip": self.ip,
            "name": self.name,
            "model": self.model,
            "firmware": self.firmware,
            "mac": self.mac,
            "uuid": self.uuid,
            "port": self.port,
            "protocol": self.protocol,
            "vendor": self.vendor,
            "discovery_method": self.discovery_method,
            "validated": self.validated,
        }

    def __str__(self) -> str:
        """String representation."""
        name = self.name or "Unknown"
        model = f" ({self.model})" if self.model else ""
        return f"{name}{model} @ {self.ip}"


async def discover_via_ssdp(
    timeout: int = 5,
    target: str | None = None,
) -> list[DiscoveredDevice]:
    """Discover devices via SSDP/UPnP.

    Args:
        timeout: Discovery timeout in seconds
        target: Optional SSDP search target (default: "upnp:rootdevice")

    Returns:
        List of discovered devices
    """
    if async_search is None:
        _LOGGER.warning(
            "async-upnp-client not available, SSDP discovery disabled. "
            "Install with: pip install async-upnp-client"
        )
        return []

    devices: list[DiscoveredDevice] = []
    seen_ips: set[str] = set()

    try:
        _LOGGER.info("Starting SSDP discovery (timeout=%ds)...", timeout)
        search_target = target or "upnp:rootdevice"

        # New API requires async_callback instead of async generator
        async def process_response(response: dict[str, Any]) -> None:
            """Process a single SSDP response."""
            try:
                # Extract location URL
                location = response.get("location", "")
                if not location:
                    return

                # Parse IP from location URL
                ip = _extract_ip_from_url(location)
                if not ip or ip in seen_ips:
                    return

                seen_ips.add(ip)

                # Extract port and protocol
                port, protocol = _extract_port_and_protocol(location)

                # Try to get device info from description
                name = response.get("usn", "").split("::")[0] if "usn" in response else None
                if name and name.startswith("uuid:"):
                    name = None

                device = DiscoveredDevice(
                    ip=ip,
                    name=name,
                    port=port,
                    protocol=protocol,
                    discovery_method="ssdp",
                )

                devices.append(device)
                _LOGGER.debug("SSDP discovered: %s", device)

            except Exception as e:
                _LOGGER.debug("Error processing SSDP response: %s", e)

        # Use new callback-based API
        await async_search(
            async_callback=process_response,
            timeout=timeout,
            search_target=search_target,
        )

    except Exception as e:
        _LOGGER.warning("SSDP discovery failed: %s", e)

    _LOGGER.info("SSDP discovery found %d device(s)", len(devices))
    return devices


async def scan_network(
    network: str = "192.168.1.0/24",
    timeout: float = 1.0,
    ports: list[int] | None = None,
    scan_timeout: float | None = None,
) -> list[DiscoveredDevice]:
    """Scan network for WiiM/LinkPlay devices.

    Args:
        network: Network CIDR to scan (e.g., "192.168.1.0/24")
        timeout: Timeout per device in seconds
        ports: List of ports to try (default: [80, 443, 4443])
        scan_timeout: Maximum time for entire scan in seconds (default: 60s)

    Returns:
        List of discovered devices
    """
    if ports is None:
        ports = [80, 443, 4443]
    
    if scan_timeout is None:
        # Default: 60 seconds or 2 seconds per IP (whichever is larger)
        network_obj = ipaddress.ip_network(network, strict=False)
        num_hosts = sum(1 for _ in network_obj.hosts())
        scan_timeout = max(60.0, num_hosts * len(ports) * timeout / 10)

    devices: list[DiscoveredDevice] = []
    network_obj = ipaddress.ip_network(network, strict=False)

    _LOGGER.info("Scanning network %s for devices...", network)

    # Create coroutines for all IPs
    coros = []
    for ip in network_obj.hosts():
        ip_str = str(ip)
        for port in ports:
            coros.append(_probe_device(ip_str, port, timeout))

    # Execute probes in parallel (with limit to avoid overwhelming network)
    semaphore = asyncio.Semaphore(50)  # Max 50 concurrent probes

    async def limited_probe(coro):
        async with semaphore:
            return await coro

    async def run_scan():
        # Create tasks from coroutines so we can cancel them if needed
        scan_tasks = [asyncio.create_task(limited_probe(coro)) for coro in coros]
        try:
            results = await asyncio.gather(*scan_tasks, return_exceptions=True)
            
            # Collect valid devices
            for result in results:
                if isinstance(result, Exception):
                    # Log cancellation errors but don't fail
                    if isinstance(result, asyncio.CancelledError):
                        _LOGGER.debug("Task cancelled during scan")
                    continue
                if result:
                    devices.append(result)
            
            return devices
        finally:
            # Cancel any remaining tasks
            for task in scan_tasks:
                if not task.done():
                    task.cancel()
            # Wait for cancellations to complete
            if scan_tasks:
                await asyncio.gather(*scan_tasks, return_exceptions=True)

    try:
        devices = await asyncio.wait_for(run_scan(), timeout=scan_timeout)
    except asyncio.TimeoutError:
        _LOGGER.warning("Network scan timed out after %ds", scan_timeout)
    except Exception as e:
        _LOGGER.error("Network scan failed: %s", e)

    _LOGGER.info("Network scan found %d device(s)", len(devices))
    return devices


async def _probe_device(ip: str, port: int, timeout: float) -> DiscoveredDevice | None:
    """Probe a single device to see if it's a WiiM/LinkPlay device.

    Args:
        ip: IP address to probe
        port: Port to probe
        timeout: Timeout in seconds

    Returns:
        DiscoveredDevice if device responds, None otherwise
    """
    client: WiiMClient | None = None
    try:
        # Quick connection test
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((ip, port))
        sock.close()

        if result != 0:
            return None  # Port not open

        # Try to validate as WiiM device
        protocol = "https" if port in [443, 4443] else "http"
        client = WiiMClient(ip, port=port, timeout=timeout)

        try:
            # Quick validation - try to get device info
            device_info = await client.get_device_info_model()
            await client.close()
            client = None  # Mark as closed

            return DiscoveredDevice(
                ip=ip,
                name=device_info.name,
                model=device_info.model,
                firmware=device_info.firmware,
                mac=device_info.mac,
                uuid=device_info.uuid,
                port=port,
                protocol=protocol,
                discovery_method="network_scan",
                validated=True,
            )

        except Exception:
            if client:
                try:
                    await client.close()
                except Exception:
                    pass
            return None

    except asyncio.CancelledError:
        # Ensure cleanup on cancellation
        if client:
            try:
                await client.close()
            except Exception:
                pass
        raise
    except Exception:
        if client:
            try:
                await client.close()
            except Exception:
                pass
        return None


async def validate_device(device: DiscoveredDevice) -> DiscoveredDevice:
    """Validate a discovered device by querying its API.

    Args:
        device: Device to validate

    Returns:
        Updated device with full information
    """
    if device.validated:
        return device

    try:
        client = WiiMClient(
            device.ip,
            port=device.port,
            timeout=5.0,
        )

        try:
            # Get device info
            device_info = await client.get_device_info_model()
            status = await client.get_player_status()

            # Update device with full info
            device.name = device_info.name or device.name
            device.model = device_info.model or device.model
            device.firmware = device_info.firmware or device.firmware
            device.mac = device_info.mac or device.mac
            device.uuid = device_info.uuid or device.uuid

            # Detect vendor from capabilities (normalized)
            if client.capabilities:
                from .normalize import normalize_vendor
                
                vendor = client.capabilities.get("vendor")
                if vendor:
                    device.vendor = normalize_vendor(vendor)

            device.validated = True

            await client.close()

        except Exception as e:
            await client.close()
            _LOGGER.debug("Validation failed for %s: %s", device.ip, e)

    except Exception as e:
        _LOGGER.debug("Could not validate device %s: %s", device.ip, e)

    return device


async def discover_devices(
    methods: list[str] | None = None,
    validate: bool = True,
    network: str = "192.168.1.0/24",
    ssdp_timeout: int = 5,
) -> list[DiscoveredDevice]:
    """Discover all WiiM/LinkPlay devices using multiple methods.

    Args:
        methods: Discovery methods to use (default: ["ssdp", "network_scan"])
            Options: "ssdp", "network_scan"
        validate: Whether to validate discovered devices via API
        network: Network CIDR for network scanning
        ssdp_timeout: SSDP discovery timeout in seconds

    Returns:
        List of discovered and validated devices
    """
    if methods is None:
        methods = ["ssdp", "network_scan"]

    all_devices: list[DiscoveredDevice] = []
    seen_ips: set[str] = set()

    # SSDP discovery
    if "ssdp" in methods:
        _LOGGER.info("Discovering devices via SSDP...")
        ssdp_devices = await discover_via_ssdp(timeout=ssdp_timeout)
        for device in ssdp_devices:
            if device.ip not in seen_ips:
                all_devices.append(device)
                seen_ips.add(device.ip)

    # Network scanning
    if "network_scan" in methods:
        _LOGGER.info("Discovering devices via network scan...")
        scan_devices = await scan_network(network=network)
        for device in scan_devices:
            if device.ip not in seen_ips:
                all_devices.append(device)
                seen_ips.add(device.ip)

    # Validate devices if requested
    if validate:
        _LOGGER.info("Validating %d discovered device(s)...", len(all_devices))
        validation_tasks = [validate_device(device) for device in all_devices]
        all_devices = await asyncio.gather(*validation_tasks)

    # Remove duplicates (by IP)
    unique_devices: list[DiscoveredDevice] = []
    seen_ips_again: set[str] = set()
    for device in all_devices:
        if device.ip not in seen_ips_again:
            unique_devices.append(device)
            seen_ips_again.add(device.ip)

    _LOGGER.info("Discovery complete: found %d unique device(s)", len(unique_devices))
    return unique_devices


def _extract_ip_from_url(url: str) -> str | None:
    """Extract IP address from URL."""
    try:
        # Remove protocol
        if "://" in url:
            url = url.split("://", 1)[1]

        # Remove path
        if "/" in url:
            url = url.split("/", 1)[0]

        # Remove port
        if ":" in url:
            url = url.split(":")[0]

        # Validate IP
        ipaddress.ip_address(url)
        return url
    except Exception:
        return None


def _extract_port_and_protocol(url: str) -> tuple[int, str]:
    """Extract port and protocol from URL."""
    protocol = "https" if url.startswith("https://") else "http"
    default_port = 443 if protocol == "https" else 80

    try:
        # Remove protocol
        if "://" in url:
            url = url.split("://", 1)[1]

        # Extract port
        if ":" in url:
            port_str = url.split(":")[1].split("/")[0]
            port = int(port_str)
            return port, protocol
    except Exception:
        pass

    return default_port, protocol

