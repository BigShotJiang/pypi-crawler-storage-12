# pywiim

Python library for WiiM/LinkPlay device communication (HTTP API + UPnP).

## Overview

`pywiim` is a Python library that provides a clean interface for communicating with WimM and LinkPlay-based audio devices.

## Features

- HTTP API client for device control and status
- UPnP event subscriptions for real-time updates
- Async/await support throughout
- Type hints for better IDE support
- Comprehensive error handling
- **Built-in diagnostic tool** for troubleshooting and support

## Installation

```bash
pip install pywiim
```

## Quick Start

```python
import asyncio
from pywiim import WiiMClient

async def main():
    # Create client
    client = WiiMClient("192.168.1.100")
    
    # Get device info
    device_info = await client.get_device_info_model()
    print(f"Device: {device_info.name} ({device_info.model})")
    
    # Get player status
    status = await client.get_player_status()
    print(f"Playing: {status.get('play_state')}")
    
    # Control playback
    await client.set_volume(0.5)
    await client.play()
    
    # Clean up
    await client.close()

asyncio.run(main())
```

## Tools

### Device Discovery

Discover all WiiM/LinkPlay devices on your network:

```bash
# Discover all devices
wiim-discover

# Discover via SSDP only (faster)
wiim-discover --methods ssdp

# Output as JSON
wiim-discover --output json
```

The discovery tool uses SSDP/UPnP and network scanning to find devices automatically.

See [Discovery Documentation](docs/DISCOVERY.md) for more information.

### Diagnostic Tool

The library includes a comprehensive diagnostic tool for troubleshooting:

```bash
# Run diagnostics on your device
wiim-diagnostics 192.168.1.100

# Save report to file (for sharing with support)
wiim-diagnostics 192.168.1.100 --output report.json
```

The diagnostic tool will:
- Gather device information (model, firmware, capabilities)
- Test all API endpoints
- Test feature support
- Generate a detailed report

See [DIAGNOSTICS.md](DIAGNOSTICS.md) for more information.

### Real-time Monitor

Monitor your device in real-time with adaptive polling and UPnP event support:

```bash
# Monitor a device
wiim-monitor 192.168.1.100

# Specify callback host for UPnP
wiim-monitor 192.168.1.100 --callback-host 192.168.1.254
```

The monitor displays:
- Play state, volume, and mute status
- Current track information
- Playback position
- Device role (solo/master/slave)
- Real-time updates via HTTP polling and UPnP events

## Development Setup

See [SETUP.md](SETUP.md) for detailed development setup instructions.

Quick start:
```bash
# Create virtual environment
python3 -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest tests/unit/ -v

# Run code quality checks
make lint typecheck
```

## Project Status

✅ **Core Features Complete:**
- HTTP API client with all mixins
- UPnP client and event handling
- Capability detection system
- State synchronization
- Diagnostic tool
- Comprehensive test suite

✅ **Code Quality:**
- Major refactoring completed (24% reduction in largest file)
- Improved error handling and logging
- Enhanced type hints across codebase
- All large files properly documented

🚧 **Package Finalization:**
- Package metadata ready
- Build testing pending (requires build tools)

## License

MIT License
