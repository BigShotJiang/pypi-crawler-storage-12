from abc import ABC



class ClassApi(ABC):
    def __init__(self):
        super().__init__()