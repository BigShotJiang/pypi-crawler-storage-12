import morepath


class app(morepath.App):
    pass


1 / 0
