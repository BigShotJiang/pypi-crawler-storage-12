class RootRoot:
    pass


class GenericRoot:
    pass


class GenericModel:
    def __init__(self, id, name):
        self.id = id
        self.name = name


class DocumentRoot:
    pass


class DocumentModel:
    def __init__(self, id):
        self.id = id
