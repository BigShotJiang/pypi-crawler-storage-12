import morepath


class App(morepath.App):
    pass
