Contributor Guide
=================

If you want to contribute to the project, this part of the
documentation is for you.

.. toctree::
   :maxdepth: 2

   developing
   design
   implementation
