``morepath.settings`` -- Settings
=================================

.. automodule:: morepath.settings

.. autoclass:: morepath.settings.SettingSection
  :members:
