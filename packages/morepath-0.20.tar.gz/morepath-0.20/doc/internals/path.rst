``morepath.path`` -- Path registry
==================================

.. automodule:: morepath.path

.. autoclass:: PathInfo
  :members:

.. autoclass:: Path
  :members:
  :special-members:
  :exclude-members: __weakref__

.. autofunction:: get_arguments

.. autofunction:: filter_arguments

.. autofunction:: fixed_urlencode
