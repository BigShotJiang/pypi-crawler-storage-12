``morepath.app`` -- App class
=============================

.. automodule:: morepath.app

