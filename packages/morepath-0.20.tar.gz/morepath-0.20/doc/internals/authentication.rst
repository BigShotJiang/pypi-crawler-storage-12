``morepath.authentication`` -- Authentication
=============================================

.. automodule:: morepath.authentication

.. autoclass:: NoIdentity
