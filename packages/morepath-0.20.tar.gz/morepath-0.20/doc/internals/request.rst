``morepath.request`` -- Request and Response
============================================

.. automodule:: morepath.request
