``morepath.predicate`` -- Predicate registry
============================================

.. automodule:: morepath.predicate

.. autoclass:: morepath.predicate.PredicateInfo
  :members:
