``morepath.view`` -- View registry
==================================

.. automodule:: morepath.view

.. autoclass:: morepath.view.View
  :members:
  :special-members:
  :exclude-members: __weakref__

.. autofunction:: morepath.view.render_view

