``morepath.core`` -- Default Morepath Configuration
===================================================

.. automodule:: morepath.core
  :members:
