``morepath.template`` -- Template Engines
=========================================

.. automodule:: morepath.template

.. autoclass:: morepath.template.TemplateDirectoryInfo
  :members:
