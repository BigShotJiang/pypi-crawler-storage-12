``morepath.autosetup`` -- Configuration Automation
==================================================

.. automodule:: morepath.autosetup

.. autofunction:: morepath.autosetup.import_package

.. autofunction:: morepath.autosetup.import_package

.. autoclass:: morepath.autosetup.DependencyMap
  :members:

.. autofunction:: morepath.autosetup.get_module_name

.. autofunction:: morepath.autosetup.caller_module

.. autofunction:: morepath.autosetup.caller_package
