``morepath.converter`` -- Convert URL variables
===============================================

.. automodule:: morepath.converter

.. autoclass:: ListConverter
  :members:

.. autodata:: IDENTITY_CONVERTER
