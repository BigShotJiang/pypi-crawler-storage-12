Community
=========

Github
------

Morepath is maintained as a Github project:

https://github.com/morepath/morepath

Feel free to fork it and make pull requests!

We use the Github issue tracker for discussion about bugs and new
features:

https://github.com/morepath/morepath/issues

So please report issues there. Feel free to add new issues!

Chat
----

Want to chat with us? `Join us`_! This uses Discord_, with web-based,
desktop and mobile clients available.

.. _`join us`: https://discord.gg/0xRQrJnOPiRsEANa

.. _`Discord`: https://discordapp.com

Mailing list/forum
------------------

There's a mailing list/web forum for discussing Morepath. Discussion
about use and development of Morepath are both welcome:

https://groups.google.com/forum/#!forum/morepath

Feel free to speak up. Questions are very welcome!
