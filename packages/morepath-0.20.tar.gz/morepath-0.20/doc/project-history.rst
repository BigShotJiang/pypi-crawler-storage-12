History
=======

The change log and how to use it.

.. toctree::
   :maxdepth: 2

   history
   changes
   upgrading
