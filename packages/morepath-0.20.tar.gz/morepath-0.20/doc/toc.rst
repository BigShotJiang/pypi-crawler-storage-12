Documentation
=============

.. toctree::
   :maxdepth: 2

   getting-started
   user-guide
   advanced-topics
   api-reference
   contributor-guide
   project-history


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
