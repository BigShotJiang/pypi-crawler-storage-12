def test_import_AquaSEBS():
    import AquaSEBS
