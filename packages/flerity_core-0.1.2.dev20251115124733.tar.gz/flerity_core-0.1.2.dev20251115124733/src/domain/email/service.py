"""Email service for sending emails via AWS SES."""


from flerity_core.utils.logging import get_logger

from .schemas import EmailType

logger = get_logger(__name__)


class EmailService:
    """Service for sending emails via AWS SES."""

    def __init__(self, aws_region: str = "us-east-1"):
        self.aws_region = aws_region
        self._templates = {
            EmailType.EMAIL_VERIFICATION: {
                "subject_key": "email.verification.subject",
                "template_name": "EmailVerification"
            },
            EmailType.PASSWORD_RESET: {
                "subject_key": "email.password_reset.subject",
                "template_name": "PasswordReset"
            }
        }

