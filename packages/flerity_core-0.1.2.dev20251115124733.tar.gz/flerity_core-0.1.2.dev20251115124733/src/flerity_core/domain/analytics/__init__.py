"""Analytics domain - Data collection and metrics."""
