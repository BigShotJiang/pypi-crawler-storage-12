from . import app


def main() -> None:
    app.main()


if __name__ == '__main__':
    main()
