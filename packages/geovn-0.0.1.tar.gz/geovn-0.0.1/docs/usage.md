# Usage

To use geovn in a project:

```
import geovn
```
