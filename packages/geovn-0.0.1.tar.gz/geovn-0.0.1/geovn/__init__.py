"""Top-level package for geovn."""

__author__ = """Le Nguyen"""
__email__ = "thanhle.ng@gmail.com"
__version__ = "0.0.1"
