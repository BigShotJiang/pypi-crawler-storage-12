from cg.exc import CgError


class NoDeliveryFilesError(CgError):
    """Raised when no delivery files are found."""

    pass
