"""AFL Overseer - Advanced AFL/AFL++ monitoring and visualization."""

__version__ = "0.1.0"
__author__ = "kirit1193"
__license__ = "MIT"
