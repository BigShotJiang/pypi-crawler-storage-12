This is the Belgian localization for the Cooperators module.

Features:

- Add Belgian legal form of companies on partner and on Subscription Request
- Set default value for communication on invoices for Capital Release Request
- Create a fiscal declaration year and print a tax shelter declaration for each
  cooperator.

The legal requirements for tax shelter are detailed `here for start-ups <https://finances.belgium.be/fr/entreprises/tax-shelter-petites-entreprises/debutantes-start-up>`_ and `here for scale-ups <https://finances.belgium.be/fr/entreprises/tax-shelter-petites-entreprises/en-croissance-scale-up>`_.
