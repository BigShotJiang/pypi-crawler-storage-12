**Tax shelter :**

According to
`this <https://eservices.minfin.fgov.be/myminfin-web/pages/public/fisconet/document/7049b083-3ae7-4250-bb35-c00b9130fb02#_VI._Documents_justificatifs>`__
administration FAQ on tax shelter for scaleups (translated to english):

   31. A royal decree (to be issued) will determine the manner in which
       evidence is to be provided and that the proof that the company in
       growth fulfills the criterion of growth of turnover or full-time
       equivalents.

In the attestation template from the administration, there is currently
some information on annual sales and number of employee for the past two
years before the fiscal year. It’s a lot of information to add to the
declaration. Since the legal situation seems still uncertain, we might
wait before adding this information in the report.
