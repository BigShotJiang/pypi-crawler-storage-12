# SPDX-FileCopyrightText: 2017 Open Architects Consulting SPRL
# SPDX-FileCopyrightText: 2018 Coop IT Easy SC
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from . import res_partner
from . import subscription_request
from . import tax_shelter_certificate
from . import tax_shelter_certificate_line
from . import tax_shelter_declaration
