## v0.4.1 (2025-11-13)

### 🐞 Bug Fixes

- **modelfit:** fix dask detection logic ([a5b74d1](https://github.com/kmnhan/xarray-lmfit/commit/a5b74d1344491d592a7e233421cbf297fb57f705))

[main 3653f00] bump: version 0.4.0 → 0.4.1
 3 files changed, 8 insertions(+), 2 deletions(-)

