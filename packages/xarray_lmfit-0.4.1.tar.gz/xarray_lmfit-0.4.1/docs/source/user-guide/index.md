# User Guide

```{toctree}
:caption: Basics
:maxdepth: 2

installing
lmfit
```

```{toctree}
:caption: Using xarray-lmfit
:maxdepth: 2

modelfit
broadcasting
multidim
io
```
