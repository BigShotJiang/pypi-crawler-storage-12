# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .item_update_params import ItemUpdateParams as ItemUpdateParams
