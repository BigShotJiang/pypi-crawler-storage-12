# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .invoke_invoke_ad_hoc_params import InvokeInvokeAdHocParams as InvokeInvokeAdHocParams
from .invoke_invoke_by_template_params import InvokeInvokeByTemplateParams as InvokeInvokeByTemplateParams
