"""
# DHX PyTincture WASM Based Widgetset
"""

__widgetset__ = "dhxpyt"
__version__ = "0.9.4"
__version_tuple__ = tuple(map(int, __version__.split('.')))
__description__ = "Python wrapper for DHTMLX widgets"
