"""Line Integral Convolution, implemented in Rust."""

__all__ = ["convolve"]

from rlic._lib import convolve
