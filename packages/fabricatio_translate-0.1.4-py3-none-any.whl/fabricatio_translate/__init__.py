"""An extension of fabricatio, which provide capabilities to translate text.."""
