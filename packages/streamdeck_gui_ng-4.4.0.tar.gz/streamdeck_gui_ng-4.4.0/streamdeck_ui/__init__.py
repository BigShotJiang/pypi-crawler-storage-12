"""**streamdeck_ui**

A Linux compatible UI for the Elgato Stream Deck.
"""

__version__ = "1.0.2"
