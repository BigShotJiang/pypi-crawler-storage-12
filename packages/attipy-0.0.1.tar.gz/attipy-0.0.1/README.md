# AttiPy
Attitude and motion sensing toolkit
