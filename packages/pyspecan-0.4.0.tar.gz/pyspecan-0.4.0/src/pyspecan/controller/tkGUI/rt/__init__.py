from .pst import PST

plots = {
    "PST": PST
}
