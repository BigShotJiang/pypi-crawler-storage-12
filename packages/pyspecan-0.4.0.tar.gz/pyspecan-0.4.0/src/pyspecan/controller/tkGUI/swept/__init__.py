from .psd import PSD
from .spg import SPG

plots = {
    "PSD": PSD,
    "SPG": SPG
}
