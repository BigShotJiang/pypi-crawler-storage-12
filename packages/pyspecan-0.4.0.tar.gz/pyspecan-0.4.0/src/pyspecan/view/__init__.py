"""Contains view implementations"""
