"""Create a tkGUI view"""

from ..config import Mode
from .tkGUI.base import View

def GetView(mode):
    return View
