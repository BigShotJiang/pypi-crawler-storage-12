"""Create a CUI view"""

from .CUI.base import View

def GetView(mode):
    return View
