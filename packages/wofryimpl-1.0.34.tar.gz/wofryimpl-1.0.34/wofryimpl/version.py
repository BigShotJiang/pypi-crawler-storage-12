
# THIS FILE IS GENERATED FROM wofry SETUP.PY
short_version = '1.0.33'
version = '1.0.33'
full_version = '1.0.33'
git_revision = ''
release = True

if not release:
    version = full_version
    short_version += ".dev"
