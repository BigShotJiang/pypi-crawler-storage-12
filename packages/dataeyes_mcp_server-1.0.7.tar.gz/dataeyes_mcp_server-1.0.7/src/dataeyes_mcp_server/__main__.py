from dataeyes_mcp_server.dataeyes import main

main()