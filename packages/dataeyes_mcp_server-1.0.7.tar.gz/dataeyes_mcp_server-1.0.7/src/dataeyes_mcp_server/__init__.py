from dataeyes_mcp_server.dataeyes import main

if __name__ == "__main__":
    main()