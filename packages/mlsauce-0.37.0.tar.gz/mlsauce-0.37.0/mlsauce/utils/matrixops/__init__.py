from .matrixops import safe_sparse_dot

__all__ = ["safe_sparse_dot"]
