from .correncoder import RankTargetEncoder

__all__ = ["RankTargetEncoder"]
