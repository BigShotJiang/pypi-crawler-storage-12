'''
Date: 2025-04-23 11:30:33
LastEditors: Xinxiang Sun sunxinxiang24@mails.ucas.ac.cn
LastEditTime: 2025-04-27 08:50:16
FilePath: /research/autohea/autohea/missions/__init__.py
'''
from .fermi.gbm import GBMObservation

__all__ = ['GBMObservation']