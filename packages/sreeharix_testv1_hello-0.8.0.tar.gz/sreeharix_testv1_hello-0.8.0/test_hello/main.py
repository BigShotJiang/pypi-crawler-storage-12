def hello():
    print("Hello, buddy!")