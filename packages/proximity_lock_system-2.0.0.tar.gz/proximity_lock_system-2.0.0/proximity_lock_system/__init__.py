# proximity_lock_system/__init__.py
__version__ = "2.0.0"
