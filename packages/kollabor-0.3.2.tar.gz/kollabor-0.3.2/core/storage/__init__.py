"""Storage subsystem for Kollabor CLI."""

from .state_manager import StateManager

__all__ = ['StateManager']