import numpy as np 

# normalization functions 

# batch normalization 

