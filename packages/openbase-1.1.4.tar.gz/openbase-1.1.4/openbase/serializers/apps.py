from django.apps import AppConfig


class SerializersConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "openbase.serializers"