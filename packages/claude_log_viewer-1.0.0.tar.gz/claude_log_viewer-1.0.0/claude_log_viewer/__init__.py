"""Claude Code Log Viewer - An interactive web-based viewer for Claude Code JSONL transcript files"""

__version__ = "1.0.0"
