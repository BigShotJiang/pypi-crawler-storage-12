import os
import sys

if __name__ = "__main__":
    from flecsi_sandbox._internal.main import main as _main

    sys.exit(_main)
