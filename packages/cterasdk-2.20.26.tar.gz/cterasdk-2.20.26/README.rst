====================
CTERA SDK for Python
====================

.. image:: https://github.com/ctera/ctera-python-sdk/workflows/CI/badge.svg
   :target: https://github.com/ctera/ctera-python-sdk/actions?query=workflow%3ACI
.. image:: https://readthedocs.org/projects/ctera-python-sdk/badge/?version=latest
   :target: https://ctera-python-sdk.readthedocs.io/en/latest
   :alt: [Latest Release Documentation]
.. image:: https://snyk.io/test/github/ctera/ctera-python-sdk/badge.svg
   :target: https://snyk.io/test/github/ctera/ctera-python-sdk
.. image:: https://img.shields.io/pypi/v/cterasdk
   :target: https://pypi.org/pypi/cterasdk
   :alt: [Latest Release Version]
.. image:: https://img.shields.io/pypi/wheel/cterasdk
   :target: https://pypi.org/pypi/cterasdk
   :alt: PyPI - Wheel
.. image:: https://img.shields.io/pypi/l/cterasdk
   :target: https://opensource.org/licenses/Apache-2.0
   :alt: [Latest Release License]
.. image:: https://img.shields.io/pypi/pyversions/cterasdk
   :target: https://pypi.org/pypi/cterasdk
   :alt: [Latest Release Supported Python Versions]
.. image:: https://img.shields.io/pypi/status/cterasdk
   :target: https://pypi.org/pypi/cterasdk
   :alt: [Latest Release Development Stage]

The CTERA SDK for Python provides developers with powerful tools to automate the deployment and configuration 
of the CTERA Global File System, streamline data management tasks, 
and seamlessly integrate CTERA's global namespace with their applications.

Documentation
=============

User documentation is available on `Read the Docs <http://ctera-python-sdk.readthedocs.org/>`_.

Installation
============

Installing via `pip <https://pip.pypa.io/>`_:

.. code-block:: console

   $ pip install cterasdk

Install from source:

.. code-block:: console

   $ git clone https://github.com/ctera/ctera-python-sdk.git
   $ cd ctera-python-sdk
   $ python -m build

Importing the Library
======================

To get started, open a Python console:

.. code-block:: python
   
   from cterasdk import *

Building Documentation
======================

Documentation can be compiled by running ``make html`` from the ``docs``
folder. After compilation, open ``docs/build/html/index.html``.

Testing
=======

We use the `tox <https://tox.readthedocs.org/>`_ package to run tests in Python
3. To install, use :code:`pip install tox`. Once installed, run `tox` from the
root directory.

.. code-block:: console

   $ tox

Compatibility Notice
====================

Future versions of the CTERA Python SDK may introduce breaking changes.
A breaking change is any modification insupported functionality between released versions that may require
users to update existing integrations or configurations to upgrade successfully.
While efforts are made to minimize disruption, such changes are sometimes necessary to maintain and improve the software.

Notice of breaking changes will be detailed in the CTERA Python SDK changelog.
Users are responsible for reviewing the changelog for each new version and thoroughly
testing the software before deploying it in production.

By using the CTERA Python SDK, users acknowledge and agree that the SDK and its
contributors are not liable for any damages, losses, or issues arising from the use or upgrade of the software,
including those resulting from breaking changes.
