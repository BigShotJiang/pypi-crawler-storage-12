EREMOTEIO = 121


class BaseIOError(IOError):
    """Base CTERA IO Error"""
