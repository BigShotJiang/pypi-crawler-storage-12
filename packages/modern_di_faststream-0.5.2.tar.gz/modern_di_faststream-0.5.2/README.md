"Modern-DI-FastStream"
==

Integration of [Modern-DI](https://github.com/modern-python/modern-di) to FastStream

📚 [Documentation](https://modern-di.readthedocs.io)
