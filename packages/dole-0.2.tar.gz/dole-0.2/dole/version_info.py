# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2025, 2ps all rights reserved.


_version = '0.2'
