from .dataprof import *

__doc__ = dataprof.__doc__
if hasattr(dataprof, "__all__"):
    __all__ = dataprof.__all__