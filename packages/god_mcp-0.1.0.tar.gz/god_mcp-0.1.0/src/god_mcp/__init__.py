"""
godMCP - A meta-MCP server for creating, managing, and debugging other MCP servers.
"""

__version__ = "0.1.0"
