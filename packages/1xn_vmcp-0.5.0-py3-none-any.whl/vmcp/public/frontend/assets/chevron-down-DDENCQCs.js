import{c as o}from"./index-Cp0jSp7c.js";const n=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],e=o("chevron-down",n);export{e as C};
//# sourceMappingURL=chevron-down-DDENCQCs.js.map
