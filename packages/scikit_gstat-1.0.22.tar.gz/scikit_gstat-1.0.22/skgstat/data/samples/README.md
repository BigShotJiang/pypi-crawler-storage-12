# Meuse dataset

Please note that the `./meuse.txt` is distributed under a GPL 3.0 license.
It is originally from https://cran.r-project.org/package=sp and if you
reuse the data, cite:

Pebesma EJ, Bivand RS (2005). “Classes and methods for spatial
    data in R.” R News, 5(2), 9–13. https://CRAN.R-project.org/doc/Rnews/.

Bivand RS, Pebesma E, Gomez-Rubio V (2013). Applied spatial data
    analysis with R, Second edition. Springer, NY. https://asdar-book.org/.
