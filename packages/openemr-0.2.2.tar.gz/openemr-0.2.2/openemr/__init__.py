name = "openemr"
__version__ = "0.3.0"
from openemr.client import Client
from openemr.patient import Patient