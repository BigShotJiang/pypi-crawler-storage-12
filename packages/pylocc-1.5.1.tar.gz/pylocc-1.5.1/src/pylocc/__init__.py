from pylocc.cli import pylocc


def main():
    pylocc()
