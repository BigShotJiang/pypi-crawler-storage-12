roman_snpit_snappl Documentation
--------------------------------


This is the documentation for roman_snpit_snappl.

**Version**: |version|


This package contains the Python software suite developed for use with the Roman Telescope project, as part of the Roman Supernova Project Implementation Team (PIT) project. 


If you have questions or concerns regarding the software, please create an issue in
the github package repository at https://github.com/Roman-Supernova-PIT/roman_snpit_snappl

--------------------------------

.. toctree::
   :maxdepth: 1
   :caption: Getting Started

   installation.rst
   usage.rst
   changes.rst
   api.rst
   database_schema.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
