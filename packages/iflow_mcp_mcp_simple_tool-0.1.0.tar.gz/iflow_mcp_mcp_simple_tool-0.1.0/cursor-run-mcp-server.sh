#!/bin/bash

# Change to the directory where this script is located
cd "$(dirname "$0")"

# Run the server
exec uv run mcp-simple-tool