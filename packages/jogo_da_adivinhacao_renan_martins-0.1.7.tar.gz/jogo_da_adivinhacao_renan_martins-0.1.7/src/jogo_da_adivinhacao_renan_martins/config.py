"""Configurações e constantes do jogo"""
VERSION = "0.1.7"
LARGURA_TELA = 63
TEMPO_ESPERA_FINAL = 3