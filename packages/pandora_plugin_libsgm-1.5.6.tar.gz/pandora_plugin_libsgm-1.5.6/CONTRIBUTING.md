# **PANDORA plugin libSGM** **Contributing guide**.

Let's refer to [Pandora Contributing guide](https://github.com/CNES/Pandora/blob/master/CONTRIBUTING.md)