"""
Device discovery and synchronization utilities.
"""
from govee.discovery.sync import DeviceSync

__all__ = ["DeviceSync"]
