"""Running data visualization module for KaiserLift.

This module provides plotting and HTML generation functionality for
running/cardio data visualization.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import re
from io import BytesIO

from .running_processers import (
    estimate_pace_at_distance,
    highest_pace_per_distance,
    df_next_running_targets,
    seconds_to_pace_string,
)


def plot_running_df(df, df_pareto=None, df_targets=None, Exercise: str = None):
    """Plot running performance: Distance vs Speed.

    Similar to plot_df for lifting but with running metrics:
    - X-axis: Distance (miles)
    - Y-axis: Speed (mph, higher is better)
    - Red line: Pareto front of best speeds
    - Green X: Target speeds to achieve

    Parameters
    ----------
    df : pd.DataFrame
        Full running data
    df_pareto : pd.DataFrame, optional
        Pareto front records
    df_targets : pd.DataFrame, optional
        Target running goals
    Exercise : str, optional
        Specific exercise to plot. If None, plots all exercises normalized.

    Returns
    -------
    matplotlib.figure.Figure
        The generated figure
    """

    df = df[df["Distance"] > 0].copy()

    # Add Speed column if not present (Speed = 3600 / Pace)
    if "Speed" not in df.columns and "Pace" in df.columns:
        df["Speed"] = df["Pace"].apply(
            lambda p: 3600 / p if pd.notna(p) and p > 0 else np.nan
        )

    if Exercise is None:
        # Plot all exercises normalized
        exercises = df["Exercise"].unique()
        fig, ax = plt.subplots()
        for exercise in exercises:
            ex_df = df[df["Exercise"] == exercise]
            ax.scatter(
                ex_df["Distance"] / max(ex_df["Distance"]),
                ex_df["Speed"] / max(ex_df["Speed"]),
                label=exercise,
                alpha=0.6,
            )
        ax.set_title("Speed vs. Distance for All Running Exercises")
        ax.set_xlabel("Distance (normalized)")
        ax.set_ylabel("Speed (normalized, higher=faster)")
        ax.legend()
        return fig

    # Filter to specific exercise
    df = df[df["Exercise"] == Exercise]
    if df.empty:
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, f"No data for {Exercise}", ha="center")
        return fig

    # Add Speed to pareto and targets if needed
    if df_pareto is not None:
        df_pareto = df_pareto[df_pareto["Exercise"] == Exercise].copy()
        if "Speed" not in df_pareto.columns and "Pace" in df_pareto.columns:
            df_pareto["Speed"] = df_pareto["Pace"].apply(
                lambda p: 3600 / p if pd.notna(p) and p > 0 else np.nan
            )

    if df_targets is not None:
        df_targets = df_targets[df_targets["Exercise"] == Exercise].copy()
        if "Speed" not in df_targets.columns and "Pace" in df_targets.columns:
            df_targets["Speed"] = df_targets["Pace"].apply(
                lambda p: 3600 / p if pd.notna(p) and p > 0 else np.nan
            )

    # Calculate axis limits
    distance_series = [df["Distance"]]
    if df_pareto is not None and not df_pareto.empty:
        distance_series.append(df_pareto["Distance"])
    if df_targets is not None and not df_targets.empty:
        distance_series.append(df_targets["Distance"])

    min_dist = min(s.min() for s in distance_series)
    max_dist = max(s.max() for s in distance_series)
    plot_max_dist = max_dist + 1

    fig, ax = plt.subplots()

    # Plot Pareto front (red line)
    if df_pareto is not None and not df_pareto.empty:
        pareto_points = list(zip(df_pareto["Distance"], df_pareto["Speed"]))
        pareto_dists, pareto_speeds = zip(*sorted(pareto_points, key=lambda x: x[0]))

        # Compute best speed overall (maximum)
        max_speed = max(pareto_speeds)

        # Get the pace corresponding to max_speed for curve estimation
        max_speed_idx = pareto_speeds.index(max_speed)
        best_pace = 3600 / max_speed if max_speed > 0 else np.nan
        best_distance = pareto_dists[max_speed_idx]

        # Generate speed curve (convert pace estimates to speed)
        if not np.isnan(best_pace):
            x_vals = np.linspace(min_dist, plot_max_dist, 100)
            y_vals = []
            for d in x_vals:
                pace_est = estimate_pace_at_distance(best_pace, best_distance, d)
                if pace_est > 0 and not np.isnan(pace_est):
                    y_vals.append(3600 / pace_est)
                else:
                    y_vals.append(np.nan)
            ax.plot(x_vals, y_vals, "k--", label="Best Speed Curve", alpha=0.7)

        # Plot step line and markers
        ax.step(
            pareto_dists,
            pareto_speeds,
            color="red",
            label="Pareto Front (Best Speeds)",
        )
        ax.scatter(
            pareto_dists,
            pareto_speeds,
            color="red",
            marker="o",
            label="_nolegend_",
        )

    # Plot targets (green X)
    if df_targets is not None and not df_targets.empty:
        target_points = list(zip(df_targets["Distance"], df_targets["Speed"]))
        target_dists, target_speeds = zip(*sorted(target_points, key=lambda x: x[0]))

        # Get max speed from targets
        max_target_speed = max(target_speeds)
        max_target_idx = target_speeds.index(max_target_speed)
        target_pace = 3600 / max_target_speed if max_target_speed > 0 else np.nan
        target_distance = target_dists[max_target_idx]

        # Generate dotted target speed curve
        if not np.isnan(target_pace):
            x_vals = np.linspace(min_dist, plot_max_dist, 100)
            y_vals = []
            for d in x_vals:
                pace_est = estimate_pace_at_distance(target_pace, target_distance, d)
                if pace_est > 0 and not np.isnan(pace_est):
                    y_vals.append(3600 / pace_est)
                else:
                    y_vals.append(np.nan)
            ax.plot(x_vals, y_vals, "g-.", label="Max Target Speed", alpha=0.7)

        ax.scatter(
            target_dists,
            target_speeds,
            color="green",
            marker="x",
            s=100,
            label="Next Targets",
        )

    # Plot raw data (blue dots)
    ax.scatter(df["Distance"], df["Speed"], label="All Runs", alpha=0.6)

    ax.set_title(f"Speed vs. Distance for {Exercise}")
    ax.set_xlabel("Distance (miles)")
    ax.set_ylabel("Speed (mph, higher=faster)")
    ax.set_xlim(left=0, right=plot_max_dist)
    ax.legend()

    return fig


def render_running_table_fragment(df) -> str:
    """Render HTML fragment with running data visualization.

    Parameters
    ----------
    df : pd.DataFrame
        Running data

    Returns
    -------
    str
        HTML fragment with dropdown, table, and figures
    """

    df_records = highest_pace_per_distance(df)
    df_targets = df_next_running_targets(df_records)

    # Format pace columns for display
    if not df_targets.empty:
        df_targets_display = df_targets.copy()
        df_targets_display["Pace"] = df_targets_display["Pace"].apply(
            seconds_to_pace_string
        )
        df_targets_display["Speed"] = df_targets_display["Speed"].round(2)
    else:
        df_targets_display = df_targets

    figures_html: dict[str, str] = {}

    def slugify(name: str) -> str:
        slug = re.sub(r"[^\w]+", "_", name)
        slug = re.sub(r"_+", "_", slug).strip("_")
        return slug.lower()

    exercise_slug = {ex: slugify(ex) for ex in df["Exercise"].unique()}

    # Generate plots for each exercise
    for exercise, slug in exercise_slug.items():
        try:
            fig = plot_running_df(df, df_records, df_targets, Exercise=exercise)
            buf = BytesIO()
            # Use SVG format instead of PNG for smaller file size and scalability
            fig.savefig(buf, format="svg", bbox_inches="tight")
            buf.seek(0)
            svg_data = buf.read().decode("utf-8")
            # Embed SVG directly (smaller than base64-encoded PNG)
            img_html = (
                f'<div id="fig-{slug}" class="running-figure" '
                f'style="display:block; max-width:100%; height:auto;">'
                f"{svg_data}"
                f"</div>"
            )
            figures_html[exercise] = img_html
            plt.close(fig)
        except Exception:
            # If plot generation fails, skip this exercise and continue
            plt.close("all")  # Clean up any partial figures

    all_figures_html = "\n".join(figures_html.values())

    # Convert targets to table
    table_html = df_targets_display.to_html(
        classes="display compact cell-border", table_id="runningTable", index=False
    )

    return table_html + all_figures_html


def gen_running_html_viewer(df, *, embed_assets: bool = True) -> str:
    """Generate full HTML viewer for running data.

    Parameters
    ----------
    df : pd.DataFrame
        Running data
    embed_assets : bool
        If True (default), return standalone HTML. If False, return fragment only.

    Returns
    -------
    str
        Complete HTML page or fragment
    """

    fragment = render_running_table_fragment(df)

    if not embed_assets:
        return fragment

    # Include same CSS/JS as lifting viewer
    js_and_css = """
    <!-- Preconnect to CDNs for faster loading -->
    <link rel="preconnect" href="https://code.jquery.com">
    <link rel="preconnect" href="https://cdn.datatables.net">
    <link rel="preconnect" href="https://cdn.jsdelivr.net">

    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css"/>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" defer></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" defer></script>

    <!-- Custom Styling for Mobile -->
    <style>
    :root {
        --bg: #fafafa;
        --fg: #1a1a1a;
        --bg-alt: #ffffff;
        --border: #e5e7eb;
        --primary: #3b82f6;
        --primary-hover: #2563eb;
        --success: #10b981;
        --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
    }
    @media (prefers-color-scheme: dark) {
        :root {
            --bg: #0f0f0f;
            --fg: #e5e5e5;
            --bg-alt: #1a1a1a;
            --border: #2a2a2a;
            --primary: #60a5fa;
            --primary-hover: #3b82f6;
            --success: #34d399;
            --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.3);
        }
    }
    [data-theme="dark"] {
        --bg: #0f0f0f;
        --fg: #e5e5e5;
        --bg-alt: #1a1a1a;
        --border: #2a2a2a;
        --primary: #60a5fa;
        --primary-hover: #3b82f6;
        --success: #34d399;
        --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.3);
    }
    [data-theme="light"] {
        --bg: #fafafa;
        --fg: #1a1a1a;
        --bg-alt: #ffffff;
        --border: #e5e7eb;
        --primary: #3b82f6;
        --primary-hover: #2563eb;
        --success: #10b981;
        --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
    }

    * {
        transition: background-color 0.2s ease, border-color 0.2s ease, color 0.2s ease;
    }

    body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        font-size: 34px;
        padding: 28px;
        background-color: var(--bg);
        color: var(--fg);
        line-height: 1.5;
    }

    h1 {
        font-weight: 700;
        margin-bottom: 24px;
    }

    table.dataTable {
        font-size: 32px;
        width: 100% !important;
        word-wrap: break-word;
        background-color: var(--bg-alt);
        color: var(--fg);
        border: 1px solid var(--border);
        border-radius: 8px;
        overflow: hidden;
        box-shadow: var(--shadow);
    }

    table.dataTable thead th {
        background-color: var(--bg);
        font-weight: 600;
        padding: 12px;
        border-bottom: 2px solid var(--border);
    }

    table.dataTable tbody td {
        padding: 10px 12px;
    }

    table.dataTable tbody tr {
        border-bottom: 1px solid var(--border);
    }

    table.dataTable tbody tr:hover {
        background-color: var(--bg);
    }

    label {
        font-size: 34px;
        color: var(--fg);
        font-weight: 500;
        margin-bottom: 8px;
        display: inline-block;
    }

    select {
        font-size: 34px;
        color: var(--fg);
        background-color: var(--bg-alt);
        border: 2px solid var(--border);
        border-radius: 6px;
        padding: 8px 12px;
    }

    select:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }

    /* Dark mode overrides for DataTables and Select2 */
    @media (prefers-color-scheme: dark) {
        .dataTables_wrapper .dataTables_filter input,
        .dataTables_wrapper .dataTables_length select {
            background-color: var(--bg);
            color: var(--fg);
            border: 1px solid var(--border);
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button {
            background-color: var(--bg);
            color: var(--fg) !important;
            border: 1px solid var(--border);
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button.current,
        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background-color: var(--bg-alt) !important;
            color: var(--fg) !important;
        }
    }
    html[data-theme="dark"] .dataTables_wrapper .dataTables_filter input,
    html[data-theme="dark"] .dataTables_wrapper .dataTables_length select {
        background-color: var(--bg);
        color: var(--fg);
        border: 1px solid var(--border);
    }
    html[data-theme="dark"] .dataTables_wrapper .dataTables_paginate .paginate_button {
        background-color: var(--bg);
        color: var(--fg) !important;
        border: 1px solid var(--border);
    }
    html[data-theme="dark"] .dataTables_wrapper .dataTables_paginate .paginate_button.current,
    html[data-theme="dark"] .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
        background-color: var(--bg-alt) !important;
        color: var(--fg) !important;
    }

    .upload-controls {
        display: flex;
        gap: 12px;
        align-items: center;
        margin-bottom: 16px;
    }

    #uploadButton {
        padding: 10px 20px;
        border: none;
        border-radius: 8px;
        background-color: var(--primary);
        color: #ffffff;
        cursor: pointer;
        font-weight: 600;
        font-size: 28px;
        box-shadow: var(--shadow);
        transition: all 0.2s ease;
    }

    #uploadButton:hover {
        background-color: var(--primary-hover);
        transform: translateY(-1px);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15);
    }

    #uploadButton:active {
        transform: translateY(0);
    }

    #csvFile {
        padding: 10px;
        border: 2px solid var(--border);
        border-radius: 6px;
        background-color: var(--bg-alt);
        color: var(--fg);
        font-size: 28px;
    }

    #csvFile:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }

    #uploadProgress {
        flex: 1;
    }

    .theme-toggle {
        position: fixed;
        top: 16px;
        right: 16px;
        padding: 10px 14px;
        font-size: 24px;
        cursor: pointer;
        background-color: var(--bg-alt);
        color: var(--fg);
        border: 2px solid var(--border);
        border-radius: 8px;
        box-shadow: var(--shadow);
        transition: all 0.2s ease;
        z-index: 1000;
    }

    .theme-toggle:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15);
    }

    .running-figure {
        border-radius: 8px;
        box-shadow: var(--shadow);
        margin: 20px 0;
        opacity: 0;
        animation: fadeIn 0.3s ease-in forwards;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .running-figure svg {
        max-width: 100%;
        height: auto;
        display: block;
    }

    @media only screen and (max-width: 600px) {
        body {
            padding: 16px;
        }

        h1 {
            font-size: 2em;
        }

        table.dataTable {
            font-size: 28px;
        }

        label {
            font-size: 30px;
        }

        select {
            font-size: 30px;
        }

        #uploadButton {
            font-size: 26px;
            padding: 12px 20px;
        }

        #csvFile {
            font-size: 26px;
        }

        .upload-controls {
            flex-direction: column;
            align-items: stretch;
        }
    }
    </style>
    """

    upload_html = """
    <button class="theme-toggle" id="themeToggle">🌙</button>
    <h1>KaiserLift - Running Data</h1>
    <div class="upload-controls">
        <input type="file" id="csvFile" accept=".csv">
        <button id="uploadButton">Upload Running Data</button>
        <progress id="uploadProgress" value="0" max="100" style="display:none;"></progress>
    </div>
    """

    scripts = """
    <script src="https://cdn.jsdelivr.net/pyodide/v0.24.1/full/pyodide.js"></script>
    <script>
    $(document).ready(function() {
        // Initialize DataTable
        $('#runningTable').DataTable({
            pageLength: 25,
            order: [[0, 'asc']]
        });

        // Theme toggle
        const themeToggle = document.getElementById('themeToggle');
        const currentTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', currentTheme);
        themeToggle.textContent = currentTheme === 'dark' ? '☀️' : '🌙';

        themeToggle.addEventListener('click', function() {
            const theme = document.documentElement.getAttribute('data-theme');
            const newTheme = theme === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            themeToggle.textContent = newTheme === 'dark' ? '☀️' : '🌙';
        });
    });
    </script>
    """

    meta = """
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <meta name="description" content="KaiserLift running analysis - Data-driven pace optimization with Pareto front">
    """
    body_html = upload_html + f'<div id="result">{fragment}</div>'
    return (
        f"<html><head>{meta}{js_and_css}</head><body>{body_html}{scripts}</body></html>"
    )
