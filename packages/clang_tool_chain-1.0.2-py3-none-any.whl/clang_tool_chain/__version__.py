"""Version information for clang-tool-chain."""

__version__ = "1.0.2"
__llvm_version__ = "21.1.5"
