
def main() -> None:
    print("Hello from veriskgo!")
