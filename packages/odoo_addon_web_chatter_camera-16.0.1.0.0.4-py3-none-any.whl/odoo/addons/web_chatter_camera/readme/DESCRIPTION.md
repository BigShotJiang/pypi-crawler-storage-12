This module adds an extra button in the chatter views that allows to make a photo.
The button is only displayed in mobile.
