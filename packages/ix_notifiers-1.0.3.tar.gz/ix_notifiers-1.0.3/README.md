# ix-notifiers

A python library for sending notifications. Used in the [egos-tech](https://gitlab.com/egos-tech) projects such as:

- [/egos-tech/alertmanager-notifier](https://gitlab.com/egos-tech/alertmanager-notifier)
- [/egos-tech/cioban](https://gitlab.com/egos-tech/cioban)

## Usage

See [notifiers.py](https://gitlab.com/egos-tech/alertmanager-notifier/-/blob/main/alertmanager-notifier/lib/notifiers.py) for an usage example.
