# django-vises

## Change log

### 1.0.0

- first public release
