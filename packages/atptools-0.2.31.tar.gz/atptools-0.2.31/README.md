# pkgpy-atp-tools

Simple tools for data manipulation.

## URLs

- [GitHub](https://github.com/atp-things/pkgpy-atp-tools)
- [PyPI](https://pypi.org/project/atptools/)

## Installation

### From PyPI

```bash
pip install atptools
```

```bash
pipenv install atptools
```

## Content

### File io (async)

### Records

### DictDefault

### Csv
