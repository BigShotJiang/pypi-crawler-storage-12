from .process_func import remove_consecutive_duplicates

__all__: list[str] = ["remove_consecutive_duplicates"]
