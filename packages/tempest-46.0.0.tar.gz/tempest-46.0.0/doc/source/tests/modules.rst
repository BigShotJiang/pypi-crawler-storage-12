Description of Tests
====================

OpenStack Services Integration Tests
------------------------------------
.. toctree::
   :maxdepth: 2

   scenario/modules

OpenStack Services API Tests
----------------------------
.. toctree::
   :maxdepth: 2

   compute/modules
   identity/modules
   image/modules
   network/modules
   object_storage/modules
   volume/modules

Serial Tests
------------
.. toctree::
   :maxdepth: 2

   serial_tests/modules
