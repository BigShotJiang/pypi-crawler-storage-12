.. _auth:

Authentication Framework Usage
==============================

---------------
The auth module
---------------

.. automodule:: tempest.lib.auth
   :members:
