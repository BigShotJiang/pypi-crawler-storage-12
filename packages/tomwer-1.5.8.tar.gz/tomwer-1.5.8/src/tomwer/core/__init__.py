"""This package contains all the core functions / classes of tomwer"""
