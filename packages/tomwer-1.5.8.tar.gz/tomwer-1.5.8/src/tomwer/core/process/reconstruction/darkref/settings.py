REFHST_PREFIX = "refHST"

DARKHST_PREFIX = "dark.edf"
"""Warning: here define the extension to in order to make difference
between darkendXXXX.edf and dark.edf. dark only is not enough"""
