"""This package contains all the applications that can be launched from 'tomwer'"""
