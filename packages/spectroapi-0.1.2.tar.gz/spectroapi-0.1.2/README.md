> This is spectros api for IOS / mobile status
> You must have status presence online(green)