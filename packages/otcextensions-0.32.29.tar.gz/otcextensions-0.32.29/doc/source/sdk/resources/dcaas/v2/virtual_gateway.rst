otcextensions.sdk.dcaas.v2.virtual_gateway
==========================================

.. automodule:: otcextensions.sdk.dcaas.v2.virtual_gateway

The Virtual Gateway Class
-------------------------

The ``VirtualGateway`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dcaas.v2.virtual_gateway.VirtualGateway
   :members:
