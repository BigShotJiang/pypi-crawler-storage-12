otcextensions.sdk.function_graph.v2.function_invocation
=======================================================

.. automodule:: otcextensions.sdk.function_graph.v2.function_invocation

The FunctionInvocation Class
----------------------------

The ``FunctionInvocation`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.function_invocation.FunctionInvocation
   :members:
