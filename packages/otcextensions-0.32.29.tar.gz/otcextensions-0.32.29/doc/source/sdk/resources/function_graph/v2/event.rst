otcextensions.sdk.function_graph.v2.event
=========================================

.. automodule:: otcextensions.sdk.function_graph.v2.event

The Event Class
---------------

The ``Event`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.event.Event
   :members:
