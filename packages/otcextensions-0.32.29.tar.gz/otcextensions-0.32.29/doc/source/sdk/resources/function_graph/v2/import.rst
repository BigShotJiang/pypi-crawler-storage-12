otcextensions.sdk.function_graph.v2.import_function
===================================================

.. automodule:: otcextensions.sdk.function_graph.v2.import_function

The Import Class
----------------

The ``Import`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.import_function.Import
   :members:
