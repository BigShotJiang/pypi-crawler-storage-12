otcextensions.sdk.dcs.v1.group
==============================

.. automodule:: otcextensions.sdk.dms.v1.group

The DMS Group Class
-------------------

The ``Group`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dms.v1.group.Group
   :members:
