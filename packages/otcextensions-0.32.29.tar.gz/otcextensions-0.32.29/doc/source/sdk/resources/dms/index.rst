DMS Resources
=============

.. toctree::
   :maxdepth: 1

   v1/group
   v1/message
   v1/queue
   v1/instance
   v1/topic
   v1/misc
