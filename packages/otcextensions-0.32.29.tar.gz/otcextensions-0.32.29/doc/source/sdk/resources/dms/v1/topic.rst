otcextensions.sdk.dcs.v1.topic
==============================

.. automodule:: otcextensions.sdk.dms.v1.topic

The DMS Instance topic Class
----------------------------

The ``Topic`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dms.v1.topic.Topic
   :members:
