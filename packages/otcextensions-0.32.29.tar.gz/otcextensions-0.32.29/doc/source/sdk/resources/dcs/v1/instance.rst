otcextensions.sdk.dcs.v1.instance
=================================

.. automodule:: otcextensions.sdk.dcs.v1.instance

The DCS Instance Class
----------------------

The ``Instance`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dcs.v1.instance.Instance
   :members:
