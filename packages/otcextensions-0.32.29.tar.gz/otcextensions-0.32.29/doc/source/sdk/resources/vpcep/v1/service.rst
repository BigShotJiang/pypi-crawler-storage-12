otcextensions.sdk.vpecp.v1.service
==================================

.. automodule:: otcextensions.sdk.vpcep.v1.service

The VPCEP Service Class
-----------------------

The ``Service`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vpcep.v1.service.Service
   :members:
