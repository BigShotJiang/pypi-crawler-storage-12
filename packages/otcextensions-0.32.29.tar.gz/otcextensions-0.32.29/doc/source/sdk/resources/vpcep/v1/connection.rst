otcextensions.sdk.vpecp.v1.connection
=====================================

.. automodule:: otcextensions.sdk.vpcep.v1.connection

The VPCEP Connection Class
--------------------------

The ``Connection`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vpcep.v1.connection.Connection
   :members:
