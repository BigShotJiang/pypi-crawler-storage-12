otcextensions.sdk.ctsv3.v3.tracker
==================================

.. automodule:: otcextensions.sdk.ctsv3.v3.tracker

The CTS Tracker Class
-----------------------

The ``Tracker`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.ctsv3.v3.tracker.Tracker
   :members:
