otcextensions.sdk.identity.v3.agency
====================================

.. automodule:: otcextensions.sdk.identity.v3.agency

The Agency Class
----------------

The ``Agency`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: otcextensions.sdk.identity.v3.agency.Agency
   :members:
