otcextensions.sdk.identity.v3.credential
========================================

.. automodule:: otcextensions.sdk.identity.v3.credential

The Credential Class
--------------------

The ``Credential`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: otcextensions.sdk.identity.v3.credential.Credential
   :members:
