otcextensions.sdk.dws.v1.flavor
===============================

.. automodule:: otcextensions.sdk.dws.v1.flavor

The DWS Flavor Class
--------------------

The ``Flavor`` class inherits from
:class:`~openstack.sdk.resource.Resource`.

.. autoclass:: otcextensions.sdk.dws.v1.flavor.Flavor
   :members:
