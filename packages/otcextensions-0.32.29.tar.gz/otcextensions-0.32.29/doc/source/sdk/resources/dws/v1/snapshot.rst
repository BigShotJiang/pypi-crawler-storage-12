otcextensions.sdk.dws.v1.snapshot
=================================

.. automodule:: otcextensions.sdk.dws.v1.snapshot

The DWS Snapshot Class
----------------------

The ``Snapshot`` class inherits from
:class:`~openstack.sdk.resource.Resource`.

.. autoclass:: otcextensions.sdk.dws.v1.snapshot.Snapshot
   :members:
