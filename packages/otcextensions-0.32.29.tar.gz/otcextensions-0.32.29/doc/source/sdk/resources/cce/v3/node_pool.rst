otcextensions.sdk.cce.v3.node_pool
==================================

.. automodule:: otcextensions.sdk.cce.v3.node_pool

The CCE Node Pool Class
-----------------------

The ``NodePool`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.cce.v3.node_pool.NodePool
   :members:
