otcextensions.sdk.sdrs.v1.replication_pair.ReplicationPair
==========================================================

.. automodule:: otcextensions.sdk.sdrs.v1.replication_pair

The SDRS Replication Pair Class
-------------------------------

The ``ReplicationPair`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.sdrs.v1.replication_pair.ReplicationPair
   :members:

.. autoclass:: otcextensions.sdk.sdrs.v1.replication_pair.Attachment
   :members:

.. autoclass:: otcextensions.sdk.sdrs.v1.replication_pair.Metadata
   :members:
