TMS Resources
=============

.. toctree::
   :maxdepth: 1

   v1/predefined_tag
   v1/resource_tag
