otcextensions.sdk.modelartsv2.v2.dataset_sample
===============================================

.. automodule:: otcextensions.sdk.modelartsv2.v2.dataset_sample

The ModelArts DatasetSample Class
---------------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.modelartsv2.v2.dataset_sample.DatasetSample
   :members:
