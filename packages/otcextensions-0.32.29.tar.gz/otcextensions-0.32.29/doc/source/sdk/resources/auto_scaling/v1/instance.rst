otcextensions.sdk.auto_scaling.v1.instance
==========================================

.. automodule:: otcextensions.sdk.auto_scaling.v1.instance

The AS Instance Class
---------------------

The ``Instance`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.auto_scaling.v1.instance.Instance
   :members:
