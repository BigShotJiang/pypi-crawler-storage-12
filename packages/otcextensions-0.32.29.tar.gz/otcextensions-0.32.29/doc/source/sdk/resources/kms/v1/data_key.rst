otcextensions.sdk.kms.v1.data_key
=================================

.. automodule:: otcextensions.sdk.kms.v1.data_key

The KMS DEK Class
-----------------

The ``DataKey`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.kms.v1.data_key.DataKey
   :members:
