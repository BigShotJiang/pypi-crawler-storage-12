otcextensions.sdk.apig.v2.backend_server_group
==============================================

.. automodule:: otcextensions.sdk.apig.v2.backend_server_group

The BackendServerGroup Class
----------------------------

The ``BackendServerGroup`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.backend_server_group.BackendServerGroup
   :members:

The MicroserviceLabelSpec Class
-------------------------------

The ``MicroserviceLabelSpec`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.backend_server_group.MicroserviceLabelSpec
   :members:
