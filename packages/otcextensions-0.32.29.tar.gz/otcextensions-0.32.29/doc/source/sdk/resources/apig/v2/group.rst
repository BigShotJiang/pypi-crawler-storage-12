otcextensions.sdk.apig.v2.apigroup
==================================

.. automodule:: otcextensions.sdk.apig.v2.apigroup

The ApiGroup Class
------------------

The ``ApiGroup`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.apigroup.ApiGroup
   :members:
