otcextensions.sdk.apig.v2.throttling_policy_binding
===================================================

.. automodule:: otcextensions.sdk.apig.v2.throttling_policy_binding

The ThrottlingPolicyBind Class
------------------------------

The ``ThrottlingPolicyBind`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.throttling_policy_binding.ThrottlingPolicyBind
   :members:

The NotBoundApi Class
---------------------

The ``NotBoundApi`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.throttling_policy_binding.NotBoundApi
   :members:

The BoundApi Class
------------------

The ``BoundThrottles`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.throttling_policy_binding.BoundThrottles
   :members:
