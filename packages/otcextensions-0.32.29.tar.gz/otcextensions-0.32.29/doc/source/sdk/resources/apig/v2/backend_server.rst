otcextensions.sdk.apig.v2.backend_server
========================================

.. automodule:: otcextensions.sdk.apig.v2.backend_server

The BackendServer Class
------------------------------

The ``BackendServer`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.backend_server.BackendServer
   :members:
