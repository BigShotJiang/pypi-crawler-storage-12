otcextensions.sdk.apig.v2.throttling_excluded
=============================================

.. automodule:: otcextensions.sdk.apig.v2.throttling_excluded

The ThrottlingExcludedPolicy Class
----------------------------------

The ``ThrottlingExcludedPolicy`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.throttling_excluded.ThrottlingExcludedPolicy
   :members:
