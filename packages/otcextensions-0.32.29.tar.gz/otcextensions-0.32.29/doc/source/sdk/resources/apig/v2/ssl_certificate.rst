otcextensions.sdk.apig.v2.ssl_certificate
=========================================

.. automodule:: otcextensions.sdk.apig.v2.ssl_certificate

The SslCertificate Class
------------------------
The ``SslCertificate`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.ssl_certificate.SslCertificate
   :members:
