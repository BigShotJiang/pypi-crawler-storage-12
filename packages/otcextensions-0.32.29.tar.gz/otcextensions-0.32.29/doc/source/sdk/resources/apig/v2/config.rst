otcextensions.sdk.apig.v2.config
================================

.. automodule:: otcextensions.sdk.apig.v2.config

The Config Class
----------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.config.Config
   :members:
