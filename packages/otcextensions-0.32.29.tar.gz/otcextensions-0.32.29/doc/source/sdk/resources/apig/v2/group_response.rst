otcextensions.sdk.apig.v2.group_response
========================================

.. automodule:: otcextensions.sdk.apig.v2.group_response

The GroupResponse Class
-----------------------

The ``GroupResponse`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.group_response.GroupResponse
   :members:
