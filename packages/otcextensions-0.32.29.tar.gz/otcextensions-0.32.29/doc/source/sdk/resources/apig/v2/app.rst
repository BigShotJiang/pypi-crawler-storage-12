otcextensions.sdk.apig.v2.app
=============================

.. automodule:: otcextensions.sdk.apig.v2.app

The App Class
-------------

The ``App`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.app.App
   :members:

The AppCode Class
-----------------

The ``AppCode`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.appcode.AppCode
   :members:

The Quota Class
---------------

The ``Quota`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.app.Quota
   :members:
