otcextensions.sdk.apig.v2.api_auth
==================================

.. automodule:: otcextensions.sdk.apig.v2.api_auth

The ApiAuthResult Class
-----------------------

The ``ApiAuthResult`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.api_auth.ApiAuthResult
   :members:

The ApiAuthInfo Class
---------------------

The ``ApiAuthInfo`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.api_auth.ApiAuthInfo
   :members:

The ApiAuth Class
-----------------

The ``ApiAuth`` class inherits from
:class:`~otcextensions.sdk.apig.v2.api_auth.ApiAuthInfo`.

.. autoclass:: otcextensions.sdk.apig.v2.api_auth.ApiAuth
   :members:
