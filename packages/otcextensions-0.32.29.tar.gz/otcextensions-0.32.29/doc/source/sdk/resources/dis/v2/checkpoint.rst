otcextensions.sdk.dis.v2.checkpoint
===================================

.. automodule:: otcextensions.sdk.dis.v2.checkpoint

The DIS Checkpoint Class
------------------------

The ``Checkpoint`` class inherits from
:class:`~openstack.sdk.resource.Resource`.

.. autoclass:: otcextensions.sdk.dis.v2.checkpoint.Checkpoint
   :members:
