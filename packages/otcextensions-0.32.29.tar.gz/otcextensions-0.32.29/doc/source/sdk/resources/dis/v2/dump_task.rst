otcextensions.sdk.dis.v2.dump_task
==================================

.. automodule:: otcextensions.sdk.dis.v2.dump_task

The DIS DumpTask Class
----------------------

The ``DumpTask`` class inherits from
:class:`~openstack.sdk.resource.Resource`.

.. autoclass:: otcextensions.sdk.dis.v2.dump_task.DumpTask
   :members:
