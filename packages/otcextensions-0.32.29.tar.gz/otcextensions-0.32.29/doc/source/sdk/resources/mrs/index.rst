MapReduce Service Resources
===========================

.. toctree::
   :maxdepth: 1

   v1/cluster
   v1/datasource
   v1/job
   v1/jobbinary
