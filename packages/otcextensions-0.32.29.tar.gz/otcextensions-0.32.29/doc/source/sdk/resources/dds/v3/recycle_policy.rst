otcextensions.sdk.dds.v3.recycle_policy
==========================================

.. automodule:: otcextensions.sdk.dds.v3.recycle_policy

The RecyclePolicy Class
----------------------------

The ``RecyclePolicy`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dds.v3.recycle_policy.RecyclePolicy
   :members:
