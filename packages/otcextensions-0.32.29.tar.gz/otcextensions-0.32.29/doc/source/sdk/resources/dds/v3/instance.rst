otcextensions.sdk.dds.v3.instance
===================================

.. automodule:: otcextensions.sdk.dds.v3.instance

The Instance Class
-------------------

The ``Instance`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dds.v3.instance.Instance
   :members:
