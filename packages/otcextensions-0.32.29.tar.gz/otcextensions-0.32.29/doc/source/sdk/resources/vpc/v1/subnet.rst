otcextensions.sdk.vpc.v1.subnet
================================

.. automodule:: otcextensions.sdk.vpc.v1.subnet

The VPC Subnet Class
--------------------

The ``Subnet`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vpc.v1.subnet.Subnet
   :members:
