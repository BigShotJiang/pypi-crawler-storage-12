otcextensions.sdk.vpc.v1.vpc
================================

.. automodule:: otcextensions.sdk.vpc.v1.vpc

The VPC Class
-------------------

The ``Vpc`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vpc.v1.vpc.Vpc
   :members:
