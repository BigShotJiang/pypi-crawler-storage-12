otcextensions.sdk.vlb.v3.l7_policy
==================================

.. automodule:: otcextensions.sdk.vlb.v3.l7_policy

The L7Policy Class
------------------

The ``L7Policy`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vlb.v3.l7_policy.L7Policy
   :members:
