otcextensions.sdk.vlb.v3.quota
==============================

.. automodule:: otcextensions.sdk.vlb.v3.quota

The Quota Class
---------------

The ``Quota`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vlb.v3.quota.Quota
   :members:
