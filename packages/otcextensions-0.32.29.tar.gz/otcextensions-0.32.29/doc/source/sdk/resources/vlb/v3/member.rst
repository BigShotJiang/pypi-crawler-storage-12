otcextensions.sdk.vlb.v3.member
=================================

.. automodule:: otcextensions.sdk.vlb.v3.member

The Member Class
------------------

The ``Member`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vlb.v3.member.Member
   :members:
