otcextensions.sdk.vlb.v3.ip_address_group
=========================================

.. automodule:: otcextensions.sdk.vlb.v3.ip_address_group

The IpAddressGroup Class
------------------------

The ``IpAddressGroup`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vlb.v3.ip_address_group.IpAddressGroup
   :members:
