otcextensions.sdk.vlb.v3.load_balancer_status
=============================================

.. automodule:: otcextensions.sdk.vlb.v3.load_balancer_status

The LoadBalancer Class
----------------------

The ``LoadBalancerStatus`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vlb.v3.load_balancer_status.LoadBalancerStatus
   :members:
