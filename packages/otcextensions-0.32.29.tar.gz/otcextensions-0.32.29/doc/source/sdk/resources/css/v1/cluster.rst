otcextensions.sdk.css.v1.cluster
================================

.. automodule:: otcextensions.sdk.css.v1.cluster

The CSS Cluster Class
---------------------

The ``Cluster`` class inherits from
:class:`~openstack.sdk.resource.Resource`.

.. autoclass:: otcextensions.sdk.css.v1.cluster.Cluster
   :members:
