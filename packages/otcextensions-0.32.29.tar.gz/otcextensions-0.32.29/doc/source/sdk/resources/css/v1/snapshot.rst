otcextensions.sdk.css.v1.snapshot
=================================

.. automodule:: otcextensions.sdk.css.v1.snapshot

The CSS Snapshot Class
----------------------

The ``Snapshot`` class inherits from
:class:`~openstack.sdk.resource.Resource`.

.. autoclass:: otcextensions.sdk.css.v1.snapshot.Snapshot
   :members:
