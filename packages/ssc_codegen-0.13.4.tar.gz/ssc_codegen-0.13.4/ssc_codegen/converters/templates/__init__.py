"""Collections of jinja2 templates for simplify code in several cases, where need too many concatenate or formatting
string operations
"""