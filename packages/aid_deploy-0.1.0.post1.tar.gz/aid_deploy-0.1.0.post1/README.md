# aid-deploy module

## Installation
From pypi:
```
pip install aid-deploy
```

From source:
```
pip install .
```

## Usage
Installed script:
```
aid-deploy --help
```

Source package:
```
python -m aid_deploy.cli --help
```
