"""PyThra CLI - Command line interface for the PyThra Framework"""

from .main import app

__all__ = ['app']