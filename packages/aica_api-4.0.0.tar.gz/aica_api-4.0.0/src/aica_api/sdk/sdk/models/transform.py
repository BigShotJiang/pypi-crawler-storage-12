from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.quaternion import Quaternion
    from ..models.vector_3 import Vector3


T = TypeVar("T", bound="Transform")


@_attrs_define
class Transform:
    """
    Attributes:
        position (Vector3):
        orientation (Quaternion):
    """

    position: "Vector3"
    orientation: "Quaternion"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        position = self.position.to_dict()

        orientation = self.orientation.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "position": position,
                "orientation": orientation,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.quaternion import Quaternion
        from ..models.vector_3 import Vector3

        d = dict(src_dict)
        position = Vector3.from_dict(d.pop("position"))

        orientation = Quaternion.from_dict(d.pop("orientation"))

        transform = cls(
            position=position,
            orientation=orientation,
        )

        transform.additional_properties = d
        return transform

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
