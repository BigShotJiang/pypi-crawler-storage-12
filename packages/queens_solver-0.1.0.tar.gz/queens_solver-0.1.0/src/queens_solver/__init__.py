def main() -> None:
    print("Hello from queens-solver!")
