# Wesphyr Messenger

A retro-style command-line messaging application that connects to global messaging servers.

## 🚀 Quick Install

```bash
pip install wesphyr
```

## 🎯 Usage

### Option 1: Use Wesphyr's official server (Default)
```bash
# No setup needed - connects to Wesphyr's server automatically
wesphyr
```

### Option 2: Connect to custom server
```bash
# Connect to any Wesphyr-compatible server
export API_URL="https://your-custom-server.com"
wesphyr
```

## ✨ Features

- 🔐 User registration and login
- 👥 Friend system with requests
- 💬 Private messaging between friends
- 📱 Cross-platform (Windows, Mac, Linux)
- 🌍 Global server support
- 🗂️ Message history
- ✅ Read receipts

## 📋 Requirements

- Python 3.8+
- Internet connection
- Server URL (Wesphyr server: https://www.fly.dev - automatically used if not specified)

## 🎮 How to Use

1. **Register**: Create account with username/password
2. **Get your ID**: You'll receive a 6-digit user ID
3. **Find friends**: Share your ID with friends
4. **Send requests**: Send friend requests using their IDs
5. **Start chatting**: Message your accepted friends!

## 🌐 Server Setup

To run your own server:

```bash
pip install wesphyr-server
wesphyr-server
```

## 📄 License

MIT License - see LICENSE file for details.

## 🤝 Contributing

Contributions welcome! Please feel free to submit pull requests.

## 📞 Support

If you encounter issues, please check:
1. Server is running and accessible
2. API_URL environment variable is set correctly
3. You have an internet connection

## 🌟 About Wesphyr

Wesphyr is a global messaging platform that brings retro CLI chat to the modern world. Connect with friends worldwide through secure, private messaging.