# blueye.protocol

This package contains the generated python interface for the protobuf messages used in the Blueye drones.
