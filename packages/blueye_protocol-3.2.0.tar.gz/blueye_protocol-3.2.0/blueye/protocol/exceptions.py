class ResponseTimeout(Exception):
    """Raised when the socket timed out waiting for response to a message"""
