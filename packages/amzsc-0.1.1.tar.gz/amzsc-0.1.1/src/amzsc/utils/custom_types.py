from selenium.webdriver import Chrome, Remote


class CustomTypes:
    DRIVER_TYPE = Chrome | Remote
