#ifndef TEST_BITFIELDS_H
#define TEST_BITFIELDS_H

void test_motohawk_bit_fields_example_message(void);
void test_floating_point_bit_fields_message1(void);
void test_floating_point_bit_fields_message2(void);
void test_signed_bit_fields_message64(void);
void test_signed_bit_fields_message33(void);
void test_signed_bit_fields_message32(void);
void test_signed_bit_fields_message64big(void);
void test_signed_bit_fields_message33big(void);
void test_signed_bit_fields_message32big(void);
void test_signed_bit_fields_message378910(void);
void test_is_in_range_bit_fields(void);

#endif // TEST_BITFIELDS_H