#ifndef TEST_INITIAL_VALUES_H
#define TEST_INITIAL_VALUES_H

void valid_initial_value(void);
void absence_of_initial_value(void);
void nullptr_ptr_initial_value(void);

#endif // TEST_INITIAL_VALUES_H