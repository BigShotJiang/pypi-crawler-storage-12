# App module for vector merging
