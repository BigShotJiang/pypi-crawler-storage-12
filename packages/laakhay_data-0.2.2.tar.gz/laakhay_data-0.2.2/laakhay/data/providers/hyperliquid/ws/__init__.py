"""Hyperliquid WebSocket provider package."""
