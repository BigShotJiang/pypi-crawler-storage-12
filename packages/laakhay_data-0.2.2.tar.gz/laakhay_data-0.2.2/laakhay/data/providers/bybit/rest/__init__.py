"""Bybit REST provider implementation."""
