# lean4check

A minimal MCP for Lean 4 development.

## Setup

For Claude Code:
```
claude mcp add lean4check -- uvx lean4check
```
