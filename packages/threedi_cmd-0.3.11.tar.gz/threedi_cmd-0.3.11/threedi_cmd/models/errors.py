class ApiModelError(BaseException):
    pass
