mkdir linktest
ln -rs ../src/ratisbona_shellutils/file_organisation/fileorga_cli.py
