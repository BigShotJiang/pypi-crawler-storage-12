"""
Resources for LaTeX
"""