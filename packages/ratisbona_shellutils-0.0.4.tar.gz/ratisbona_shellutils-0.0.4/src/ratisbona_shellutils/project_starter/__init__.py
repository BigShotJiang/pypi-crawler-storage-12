"""
    Replacement for the withdrawn project starter script.
    This script simply outputs the shellcommand to check out the new project template from git.
"""
