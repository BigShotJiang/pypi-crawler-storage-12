from ratisbona_shellutils.project_starter._project_starter import project_starter_cli


def main():
    project_starter_cli()


if __name__ == "__main__":
    main()
