from ._pipy_research_cli import pypi_research_cli

def main():
    pypi_research_cli()

if __name__ == "__main__":
    main()