"""
    This module contains a mouse wiggler to keep your computer hard from going into standby.
"""


from ._twister import wiggle_wiggle