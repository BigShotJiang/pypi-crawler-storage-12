from ratisbona_shellutils.twister._twister import wiggle_wiggle
from ratisbona_shellutils.twister._twister_cli import twist_and_shout_cli


def main():
    twist_and_shout_cli()



if __name__ == "__main__":
    main()
