"""
    A collection of utilities to be used as a filter in your posix pipes.
    
    Currently there is just a utility to transliterate unicode characters to ascii.
"""
