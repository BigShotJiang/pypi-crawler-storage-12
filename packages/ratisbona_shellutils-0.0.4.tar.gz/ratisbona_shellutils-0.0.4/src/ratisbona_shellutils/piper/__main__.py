from ratisbona_shellutils.piper.piper_cli import piper_cli


def main():
    piper_cli()

if __name__ == "__main__":
    main()
