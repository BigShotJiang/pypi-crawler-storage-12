from ratisbona_shellutils.length_encode._length_encode_cli import length_encode_cli


def main():
    length_encode_cli()

if __name__ == "__main__":
    main()
