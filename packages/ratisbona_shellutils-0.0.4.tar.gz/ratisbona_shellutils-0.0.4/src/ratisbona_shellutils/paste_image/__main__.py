from ratisbona_shellutils.paste_image.paste_image import paste_image_main


def main():
    paste_image_main()


if __name__ == "__main__":
    main()
