"""
    Resources package for ratisbona_shellutils.
"""