from ._emojifind_cli import emojifind_cli

def main():
    emojifind_cli()


if __name__ == "__main__":
    main()