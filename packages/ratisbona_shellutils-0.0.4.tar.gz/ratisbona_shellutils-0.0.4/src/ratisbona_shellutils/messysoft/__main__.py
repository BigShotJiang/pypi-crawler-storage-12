from ._messysoft_cli import messysoft_cli

def main():
    messysoft_cli()

if __name__ == "__main__":
    main()
