from ratisbona_shellutils.dialogator.dialogator_cli import dialogator_cli


def main():
    dialogator_cli()

if __name__ == "__main__":
    main()