"""
    A package comprising several utilities for the shell.
"""
