from ratisbona_shellutils.file_organisation._fileorga_cli import fileorga_cli


def main():
    fileorga_cli()

if __name__ == "__main__":
    main()