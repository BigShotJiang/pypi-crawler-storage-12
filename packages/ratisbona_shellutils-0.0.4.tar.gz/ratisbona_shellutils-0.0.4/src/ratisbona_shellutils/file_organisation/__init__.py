"""
    A Module with helpers to keep your files organized.
    It can apply a set of cleaners to your filenames to make them more readable.
    Files are not changed directly but a script is output that can be reviewed and used to rename the files.
"""