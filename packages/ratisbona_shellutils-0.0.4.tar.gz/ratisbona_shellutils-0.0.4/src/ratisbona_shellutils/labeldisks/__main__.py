from ratisbona_shellutils.labeldisks.labeldisks_cli import label_disks_cli


def main():
    label_disks_cli()

if __name__ == "__main__":
    main()