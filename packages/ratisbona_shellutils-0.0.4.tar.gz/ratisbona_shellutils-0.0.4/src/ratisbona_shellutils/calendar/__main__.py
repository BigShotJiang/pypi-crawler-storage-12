from ratisbona_shellutils.calendar.google_calender_cli import google_calendar_cli


def main():
    google_calendar_cli()


if __name__ == "__main__":
    main()
