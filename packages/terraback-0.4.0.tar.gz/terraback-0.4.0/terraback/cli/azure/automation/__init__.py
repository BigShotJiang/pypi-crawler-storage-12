"""Azure Automation service scanning module."""

from terraback.cli.azure.automation.automation_accounts import app as automation_accounts_app

__all__ = ["automation_accounts_app"]