#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2025 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class BlibliIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "blibli"

    @property
    def original_file_name(self) -> "str":
        return "blibli.svg"

    @property
    def title(self) -> "str":
        return "Blibli"

    @property
    def primary_color(self) -> "str":
        return "#0072FF"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Blibli</title>
     <path d="M5.8018 5.9457c2.4792.2543 4.3228.3814
 6.1663.3814l-.89-2.9243a1.0171 1.0171 0 0
 0-1.2714-.6357l-3.6235.9536c-.5721.1271-.89.7629-.6357
 1.2714l.1907.89zm12.5234
 0V3.9114c.0636-.6357-.6357-1.0807-1.2714-.6993l-3.6871
 2.4157c-.2543.1272-.445.3814-.5086.6357 1.5257 0 3.1785-.1271
 5.467-.3178zm-4.3228-2.0343a1.9707 1.9707 0 1 0-.9536-3.8142 1.9707
 1.9707 0 1 0 .9536 3.8142Zm5.1492
 2.6067v.0633h-.1266c-3.0514.3178-5.0857.4445-6.9928.4445-2.0343
 0-4.0057-.1267-7.1207-.4445h-.0633c-.6357 0-1.0171.3812-.9536 1.0169
 1.0172 6.0392 1.0167 9.7901-.509 15.1936C3.1949 23.364 3.7034 24
 4.339 24H19.724c.5721 0 1.081-.5726.8902-1.1448a30.1325 30.1325 0 0
 1-.509-15.257c.1271-.572-.3179-1.0801-.9536-1.0801Zm-10.298
 3.623c.445 0 .7624.3178.7624.6357v.0633c0
 .3814-.3173.7003-.7623.7003a.6357.6357 0 0 1-.6357-.7003.6357.6357 0
 0 1 .6357-.699zm6.2292 0c.3815 0 .7636.3176.7636.699 0
 .3814-.3821.7003-.7636.7003a.6357.6357 0 0 1-.6357-.7636.6357.6357 0
 0 1 .6357-.6357Zm-6.6116 2.6061c.3179 0 .5091.2548.5091.5091a2.9243
 2.9243 0 0 0 2.9873 2.924c2.2886 0 3.052-1.9704 3.052-2.924
 0-.2543.1901-.509.4444-.509s.509.2547.509.509c0 1.2714-.954
 3.8142-4.0054 3.8142-2.9878 0-3.9409-2.5428-3.9409-3.8142
 0-.2543.1903-.509.4445-.509z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return ''''''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
