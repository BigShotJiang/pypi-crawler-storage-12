#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2025 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class AlistIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "alist"

    @property
    def original_file_name(self) -> "str":
        return "alist.svg"

    @property
    def title(self) -> "str":
        return "AList"

    @property
    def primary_color(self) -> "str":
        return "#70C6BE"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>AList</title>
     <path d="M12.083 11.45c.38-.06.782.03
 1.097.251.239.184.405.46.452.76.033.226.01.462-.073.677-.064.186-.156.36-.259.528L8.908
 21.05c-.187.308-.358.628-.574.917a1.68 1.68 0 0
 1-.58.466c-.478.255-1.102.1-1.466-.283a1.079 1.079 0 0
 1-.306-.7c-.021-.269.038-.54.16-.78a6.9 6.9 0 0 1
 .366-.677c.643-1.083 1.281-2.169 1.923-3.252.878-1.49 1.77-2.972
 2.654-4.458.094-.17.21-.325.342-.466.178-.18.403-.326.656-.366zm.128-10.007c.253-.03.517.028.728.172.319.206.544.52.735.841.864
 1.449 1.734 2.894 2.598 4.343 1.15 1.938 2.3 3.875 3.448 5.814.793
 1.342 1.59 2.682 2.388 4.02.526.895 1.07 1.78 1.572
 2.687.217.38.336.818.318
 1.257-.012.339-.074.687-.252.98-.25.415-.668.708-1.122.86a2.25 2.25 0
 0 1-.755.147h-8.451a2.133 2.133 0 0 1-.716-.121 1.467 1.467 0 0
 1-.46-.286c-.223-.22-.367-.532-.328-.848.02-.221.074-.44.165-.642.089-.208.213-.398.32-.596.472-.84.966-1.668
 1.479-2.484.164-.256.307-.533.535-.742.241-.221.545-.395.877-.417.267-.011.53.08.753.224.251.148.449.393.515.679.096.362-.007.743-.16
 1.074-.173.375-.418.716-.55 1.11-.024.09-.057.203.01.282a.548.548 0 0
 0
 .25.111c.256.057.52.043.78.044h2.874c.19-.003.38.006.57-.005.136-.015.286-.038.392-.133.07-.063.08-.168.053-.253a2.572
 2.572 0 0
 0-.259-.53c-2.554-4.363-5.095-8.734-7.677-13.081-.084-.14-.156-.292-.277-.405a.242.242
 0 0
 0-.23-.066c-.069.025-.115.086-.161.14-.114.145-.216.3-.31.458-.444.723-.87
 1.458-1.306 2.186l-7.53
 12.675c-.156.286-.322.567-.503.84-.158.233-.35.451-.599.592-.292.169-.653.236-.98.139a1.441
 1.441 0 0 1-.642-.38C.086 21.915-.01 21.6 0
 21.3c.011-.316.117-.625.276-.896a1510.95 1510.95 0 0 1
 4.598-7.753c.792-1.337 1.58-2.676 2.377-4.01.806-1.352 1.613-2.703
 2.415-4.057.448-.763.899-1.524 1.369-2.273a2.12 2.12 0 0 1
 .557-.614c.185-.126.392-.234.618-.254z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return ''''''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
