#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2025 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class AdaIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "ada"

    @property
    def original_file_name(self) -> "str":
        return "ada.svg"

    @property
    def title(self) -> "str":
        return "Ada"

    @property
    def primary_color(self) -> "str":
        return "#000000"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Ada</title>
     <path d="M18.869 13.45c0-.428.45-.585 1.18-.663.606-.068
 1.09-.169 1.404-.371v.539c0 .644-.542.957-1.265 1.028a47.006 47 0 0
 0-.925-.077c-.25-.095-.394-.256-.394-.457m-13.99.19h3.113l.256.755a33.004
 33 0 0 0-3.96.97zM6.43 9.056l1.09 3.202H5.34zm6.921 1.606c.82 0
 1.483.742 1.483 1.663 0 .651-.348 1.212-.852 1.473a47.006 47 0 0
 0-1.152.053c-.562-.227-.961-.812-.961-1.526 0-.944.663-1.663
 1.483-1.663m9.484 3.657v-3.072c0-.461-.18-1.978-2.529-1.978-1.516
 0-2.572.82-2.718 1.921h1.483c.134-.494.741-.73 1.27-.73.662 0
 1.055.247 1.055.55 0 .472-.685.585-1.651.675-1.28.112-2.37.449-2.37
 1.752q0 .194.035.367a51.006 51 0 0
 0-1.092-.028V6.844h-1.484v3.123a2.43 2.43 0 0 0-1.707-.674c-1.505
 0-2.752 1.303-2.752 3.022a3.2 3.2 0 0 0 .474 1.702 38.005 38 0 0
 0-1.12.14L7.376 7.406H5.498l-2.992 8.587A22.003 22 0 0 0 0
 17.156c3.835-1.673 13.295-3.938
 24-2.55-.051-.057-.466-.166-1.164-.286" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = '''https://blog.adacore.com/our-contribution-to-'''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return '''https://ada-lang-io.github.io/ada-logo-editor'''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
