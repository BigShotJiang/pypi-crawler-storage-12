#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2025 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class AnimedotjsIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "animedotjs"

    @property
    def original_file_name(self) -> "str":
        return "animedotjs.svg"

    @property
    def title(self) -> "str":
        return "Anime.js"

    @property
    def primary_color(self) -> "str":
        return "#000000"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Anime.js</title>
     <path d="M12 .0012c2.8931 0 5.547 1.0238 7.6193 2.7288H24c-.2493
 1.6968-.4997 3.3933-.748 5.0903C23.7357 9.1218 24 10.53 24 12c0
 6.6274-5.3726 12-12 12S0 18.6274 0 12 5.3726 0 12 0Zm.7271
 5.2c-1.9911 0-3.5191.1-4.584.2987-1.0648.1991-1.844.5497-2.3374
 1.0518-.4935.5021-.8095 1.2467-.948
 2.2336l-.052.3896h4.3235l.014-.078c.052-.2944.1602-.5238.3247-.6883.3758-.3758
 1.3594-.4805 2.74-.4805.6975 0 1.3993-.016
 2.0907.091.355.061.619.1862.7922.3766.1731.1905.2597.4935.2597.909-.042.6074-.1174
 1.2126-.1818
 1.8181h-.078c-.3117-.4156-.8138-.7143-1.5064-.8961-.9452-.2481-2.0153-.2727-3.4023-.2727-1.5756
 0-2.7876.1039-3.636.3117-.8484.2078-1.4718.5627-1.87
 1.0648-.3982.5021-.6666 1.238-.8051 2.2076-.074.5178-.1517
 1.0343-.1558 1.5583 0 .7445.1731 1.3332.5194
 1.7661.3463.4329.9047.7445 1.6752.935.7705.1904 1.8223.2857
 3.1555.2857.9631 0 1.9304 0 2.8829-.1559.5714-.1038 1.0302-.2683
 1.3765-.4934.3463-.2251.7012-.5454 1.0648-.961h.052l-.2338
 1.4025h4.4931l.935-6.5968c.1212-.9177.1818-1.6016.1818-2.0518
 0-.598-.053-.9743-.1354-1.3516l-2.6242.0009c.1123-.7649.2252-1.5297.3381-2.2946-.07-.02-.1415-.038-.2146-.056-1.2124-.2886-2.6154-.3246-4.4542-.3246Zm-.8051
 7.298c.8311 0 1.4588.026
 1.883.078.4242.052.7142.1428.87.2727.1558.1298.2338.316.2338.5584 0
 .055-.037.9918-.4156
 1.3895-.1731.1818-.4848.3116-.935.3895-.5642.098-1.3136.1169-2.3374.1169-.7792
 0-1.3808-.026-1.805-.078-.4243-.052-.7316-.1515-.922-.2987-.1905-.1472-.2857-.3506-.2857-.6103.053-.6238.1306-1.0137.3895-1.2856.1732-.1818.4892-.316.948-.4026.5853-.1104
 1.3454-.1299 2.3764-.1299zm11.1111-8.928h-4.4973l-.5111
 3.4752h4.4973z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return '''https://github.com/simple-icons/simple-icons/'''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
