#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2025 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class ApacheAvroIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "apacheavro"

    @property
    def original_file_name(self) -> "str":
        return "apacheavro.svg"

    @property
    def title(self) -> "str":
        return "Apache Avro"

    @property
    def primary_color(self) -> "str":
        return "#30638E"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Apache Avro</title>
     <path d="M11.704
 3.324s-.464.428.024.982c.363.412.904.16.904.16s.5-.274.12-.85c-.492-.75-1.048-.292-1.048-.292ZM23.927
 22 5.456 13.966S-.58 10.32.046 8.88c.608-1.393 5.988 1.415 6.557
 1.544.569.13.886-.221.896-.466.017-.354-.799-1.366-.376-1.798.422-.431
 1.8.408 1.8.408l1.12.757L23.926 22ZM24 21.924 11.81 8.74S9.615 6.306
 9.706 5.61c.091-.698 3.007 1.527 3.007
 1.527s.324.305.632.252c.307-.05-.022-.55-.022-.55s-.504-1.142-.167-1.347c.338-.203
 1.191.657
 1.191.657s.213.215.437.157c.224-.06.104-.539.104-.539s-1.542-3.471-.87-3.73c1.026-.396
 2.487 2.476 2.977 3.37C17.118 5.654 24 21.924 24 21.924ZM4.978
 5.611s-.626.404.07 1.181c.639.716 1.208.345
 1.208.345s.59-.352.024-1.017c-.748-.877-1.302-.51-1.302-.51ZM21.288
 21.215l-13.87-3.867-.885-2.551 14.755 6.418Z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return ''''''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
