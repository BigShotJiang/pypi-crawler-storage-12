# This only exists for compatibility with old log configs
from .logging import ColorFormatter
