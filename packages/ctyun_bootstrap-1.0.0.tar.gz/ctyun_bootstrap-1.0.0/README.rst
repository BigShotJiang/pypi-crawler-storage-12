
Installation
------------


aliyun-bootstrap
-----------------------

::

    aliyun-bootstrap [-a |--action=][install|requirements]
