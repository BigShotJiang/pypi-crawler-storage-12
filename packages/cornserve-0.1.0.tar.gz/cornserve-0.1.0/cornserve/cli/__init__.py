"""CLI for Cornserve."""
