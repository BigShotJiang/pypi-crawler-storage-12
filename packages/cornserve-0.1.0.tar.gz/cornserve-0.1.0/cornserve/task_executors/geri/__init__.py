"""Geri generates multimodal content, like images, videos, and audios."""
