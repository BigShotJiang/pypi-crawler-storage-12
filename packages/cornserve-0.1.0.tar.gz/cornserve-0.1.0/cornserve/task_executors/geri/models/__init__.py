"""Model implementations for Geri."""
