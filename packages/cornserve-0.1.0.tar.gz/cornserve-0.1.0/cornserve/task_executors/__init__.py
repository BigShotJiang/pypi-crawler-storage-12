"""Built-in task executors in Cornserve.

- Eric: A server that embeds modality data so that they can be fed into LLMs.
"""
