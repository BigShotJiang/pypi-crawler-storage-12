"""The engine runs in a separate process and handles model inference."""
