"""The router receives embedding requests and invokes the engine."""
