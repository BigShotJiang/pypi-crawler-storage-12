"""Utility functions and classes for Eric."""
