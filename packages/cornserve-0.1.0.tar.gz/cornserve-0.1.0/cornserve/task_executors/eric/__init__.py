"""Eric embeds modality data so that they can be fed into LLMs."""
