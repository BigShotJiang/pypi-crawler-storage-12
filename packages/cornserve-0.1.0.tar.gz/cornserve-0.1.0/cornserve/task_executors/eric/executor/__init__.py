"""The executor manages workers that execute inference."""
