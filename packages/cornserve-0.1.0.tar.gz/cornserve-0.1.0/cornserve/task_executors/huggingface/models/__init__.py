"""HuggingFace model wrappers."""
