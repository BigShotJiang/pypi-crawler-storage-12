"""HuggingFace task executor (deprecated)."""
