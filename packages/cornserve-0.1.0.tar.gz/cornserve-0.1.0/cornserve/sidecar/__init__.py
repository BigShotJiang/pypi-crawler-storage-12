"""Sidecar APIs for Task Executors."""
