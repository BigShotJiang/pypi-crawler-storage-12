"""Easy, fast, and scalable multimodal agentic AI."""

__version__ = "0.1.0"
