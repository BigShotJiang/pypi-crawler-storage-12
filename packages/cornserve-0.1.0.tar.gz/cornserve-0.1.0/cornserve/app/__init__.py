"""Cornserve application package."""
