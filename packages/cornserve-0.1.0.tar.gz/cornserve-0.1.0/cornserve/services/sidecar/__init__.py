"""Sidecar servers that forward data between peers."""
