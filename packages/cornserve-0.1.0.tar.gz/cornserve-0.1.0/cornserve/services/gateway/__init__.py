"""The gateway service is the main entry point for Cornserve.

System admins can use the gateway service to register and unregister applications.
Successfully registered applications will be deployed to the cluster and made available
for invocation from users.
"""
