"""CLI module for AWS Baseline Snapshot tool."""

from .main import app, cli_main

__all__ = ["app", "cli_main"]
