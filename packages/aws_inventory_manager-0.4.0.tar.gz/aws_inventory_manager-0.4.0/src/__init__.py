"""AWS Baseline Snapshot & Delta Tracking tool."""

__version__ = "1.0.0"
