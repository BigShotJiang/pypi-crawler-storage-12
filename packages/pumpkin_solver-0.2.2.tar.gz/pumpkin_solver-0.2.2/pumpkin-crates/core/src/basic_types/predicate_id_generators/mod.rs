mod deletable_predicate_id_generator;
mod predicate_id_generator;

pub(crate) use deletable_predicate_id_generator::DeletablePredicateIdGenerator;
pub(crate) use predicate_id_generator::PredicateId;
pub(crate) use predicate_id_generator::PredicateIdGenerator;
