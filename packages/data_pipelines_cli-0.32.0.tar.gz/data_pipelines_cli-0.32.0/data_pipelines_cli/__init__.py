"""
data-pipelines-cli (dp) is a CLI tool designed for data platform.

dp helps data analysts to create, maintain and make full use of their data
pipelines.
"""

version = "0.32.0"
