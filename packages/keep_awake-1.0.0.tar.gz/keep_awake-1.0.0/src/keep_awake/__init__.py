from ._native_api import prevent_sleep, allow_sleep

__all__ = ["prevent_sleep", "allow_sleep"]
