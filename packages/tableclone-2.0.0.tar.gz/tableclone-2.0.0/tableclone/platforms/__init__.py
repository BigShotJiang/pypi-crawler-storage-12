from .abstracts import Platform, Table
