"""
MCP Observer Server - A file system monitoring server using Model Context Protocol
"""

__version__ = "0.1.0"
