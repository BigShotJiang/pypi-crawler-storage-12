from ccflow_emails import *  # noqa


def test_all():
    assert True
