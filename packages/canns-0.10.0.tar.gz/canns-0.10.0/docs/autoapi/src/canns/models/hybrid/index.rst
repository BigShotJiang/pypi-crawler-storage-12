src.canns.models.hybrid
=======================

.. py:module:: src.canns.models.hybrid


