src.canns
=========

.. py:module:: src.canns


Submodules
----------

.. toctree::
   :maxdepth: 1

   /autoapi/src/canns/analyzer/index
   /autoapi/src/canns/data/index
   /autoapi/src/canns/models/index
   /autoapi/src/canns/pipeline/index
   /autoapi/src/canns/task/index
   /autoapi/src/canns/trainer/index
   /autoapi/src/canns/typing/index
   /autoapi/src/canns/utils/index


Attributes
----------

.. autoapisummary::

   src.canns.__version__


Package Contents
----------------

.. py:data:: __version__
   :value: 'unknown'


