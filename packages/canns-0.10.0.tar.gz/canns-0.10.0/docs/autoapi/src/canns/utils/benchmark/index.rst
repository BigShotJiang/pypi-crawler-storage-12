src.canns.utils.benchmark
=========================

.. py:module:: src.canns.utils.benchmark


Functions
---------

.. autoapisummary::

   src.canns.utils.benchmark.benchmark


Module Contents
---------------

.. py:function:: benchmark(runs=10)

