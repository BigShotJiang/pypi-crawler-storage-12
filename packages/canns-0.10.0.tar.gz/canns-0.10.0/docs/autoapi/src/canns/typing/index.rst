src.canns.typing
================

.. py:module:: src.canns.typing


Attributes
----------

.. autoapisummary::

   src.canns.typing.Iext_pair_type
   src.canns.typing.Iext_type
   src.canns.typing.time_type


Package Contents
----------------

.. py:data:: Iext_pair_type

.. py:data:: Iext_type

.. py:data:: time_type

