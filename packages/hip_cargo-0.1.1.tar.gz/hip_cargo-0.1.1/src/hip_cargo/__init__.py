"""hip-cargo: Tools for generating Stimela cab definitions."""

from hip_cargo.utils.decorators import stimela_cab, stimela_output

__version__ = "0.1.1"
__all__ = ["stimela_cab", "stimela_output"]
