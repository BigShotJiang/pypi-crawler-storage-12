from mcp_maya_small_tools import server

if __name__ == '__main__':
    server.main()
