from mcp_maya_small_tools import server
server.main()