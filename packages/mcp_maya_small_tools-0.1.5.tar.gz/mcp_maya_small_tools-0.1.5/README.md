这是一个mcp服务器，提供的tools有
 - list_maya_references 列出指定目录下所有ma文件，其referenc列表