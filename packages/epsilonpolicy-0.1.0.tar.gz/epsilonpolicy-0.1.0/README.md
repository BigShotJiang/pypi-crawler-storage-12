# epsilonpolicy

A minimal epsilon-greedy action selection function.

## Install
```bash
pip install epsilonpolicy
