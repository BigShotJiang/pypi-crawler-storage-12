# kachaka-api

## Overview
kachaka-apiは[スマートファニチャー・プラットフォーム「カチャカ」](https://kachaka.life/) のAPIを利用するためのPythonライブラリです。
ドキュメントは[kachaka-api manual](https://github.com/pf-robotics/kachaka-api/blob/main/README.md)をご覧ください。

## License
Copyright 2023 Preferred Robotics, Inc.
Licensed under [the Apache License, Version 2.0](LICENSE).
