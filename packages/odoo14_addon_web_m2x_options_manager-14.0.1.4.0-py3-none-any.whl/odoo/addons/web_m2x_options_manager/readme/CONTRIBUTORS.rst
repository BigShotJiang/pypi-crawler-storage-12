* `Camptocamp <https://www.camptocamp.com>`__:

  * Silvio Gregorini
