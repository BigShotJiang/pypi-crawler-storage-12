Allows managing the "Create..." and "Create and Edit..." options for `Many2one`
and `Many2many` fields directly from the `ir.model` form view.
