API Reference
=============

General functions
-----------------

.. autofunction:: guitarpro.parse

.. autofunction:: guitarpro.write


Models
------

.. automodule:: guitarpro.models
   :members:

.. vim: tw=120 cc=121
