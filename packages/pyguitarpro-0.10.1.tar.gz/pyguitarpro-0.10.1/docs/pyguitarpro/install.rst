Installation
============

Install the package with:

.. code-block:: sh

    pip install pyguitarpro

For the latest development version:

.. code-block:: sh

    git clone https://github.com/Perlence/PyGuitarPro
    cd pyguitarpro
    pip install -e .

.. vim: tw=120 cc=121
