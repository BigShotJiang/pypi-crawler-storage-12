"""app 包初始化。"""

from .main import main
from .mcp_service import run_mcp_server

__all__ = ["main", "run_mcp_server"]

