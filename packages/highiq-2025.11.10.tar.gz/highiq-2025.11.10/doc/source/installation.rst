Installing HighIQ
=================

The best way to install HighIQ is to install it using either pip or anaconda. In order to do this, simply do::

   $ pip install highiq

Or, if you have Anaconda::

   $ conda install -c conda-forge highiq

If you are going to make contributions to HighIQ, it is recommended that you create your own fork of the GitHub repository of HighIQ and create your own branch.From here, you would install it from source like this::

   $ git clone https://github.com/username/HighIQ
   $ cd HighIQ
   $ pip install .
