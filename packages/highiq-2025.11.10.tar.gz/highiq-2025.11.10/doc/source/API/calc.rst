.. automodule:: highiq.calc
    :members:
    :undoc-members:
    :show-inheritance:
