from simple_lama_inpainting.models.model import SimpleLama

__all__ = ['SimpleLama',]
