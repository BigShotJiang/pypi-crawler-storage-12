"""Treat widgets directory as a package for installed distributions."""
