"""
Selvage 패키지의 메인 진입점입니다.
"""

from selvage.cli import main

if __name__ == "__main__":
    main()
