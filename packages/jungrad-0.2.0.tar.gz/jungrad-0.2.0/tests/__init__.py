"""Tests for jungrad."""
