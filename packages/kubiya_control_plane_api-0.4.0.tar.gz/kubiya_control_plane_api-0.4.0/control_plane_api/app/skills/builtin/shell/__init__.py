"""Shell Skill - Provides shell command execution capabilities."""
from .skill import ShellSkill

__all__ = ["ShellSkill"]
