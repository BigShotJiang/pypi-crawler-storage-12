## basic type
All of class in this package, must be a ABC class.