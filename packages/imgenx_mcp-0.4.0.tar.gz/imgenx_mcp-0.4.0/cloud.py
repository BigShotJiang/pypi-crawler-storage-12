from imgenx.server import mcp

mcp.remove_tool('download')
