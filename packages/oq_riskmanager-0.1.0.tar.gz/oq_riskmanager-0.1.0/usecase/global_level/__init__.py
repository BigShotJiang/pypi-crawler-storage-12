"""
global_level 子包：全局（Global）级别风控用例。
"""


