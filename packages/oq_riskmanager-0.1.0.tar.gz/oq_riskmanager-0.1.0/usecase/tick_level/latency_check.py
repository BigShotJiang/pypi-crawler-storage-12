from typing import List, Dict, Any
import time
from utils.loader import get_config_loader

# 获取配置加载器
_config = get_config_loader()

def bbo_latency_check(bbo: List[Dict[str, Any]]) -> bool:
    """
    检查相同 symbol 的行情延迟是否异常
    """
    if not bbo or len(bbo) != 2 or not bbo[0] or not bbo[1]:
        return False
    
    taker_bbo = bbo[0]
    maker_bbo = bbo[1]
    
    taker_timestamp = taker_bbo.get('timestamp', 0)
    maker_timestamp = maker_bbo.get('timestamp', 0)

    current_timestamp = int(time.time() * 1000)
    threshold = _config.get_tick_config()['abnormal_bbo_latency_threshold']

    if abs(taker_timestamp - current_timestamp) > threshold or abs(maker_timestamp - current_timestamp) > threshold:
        return False

    return True
