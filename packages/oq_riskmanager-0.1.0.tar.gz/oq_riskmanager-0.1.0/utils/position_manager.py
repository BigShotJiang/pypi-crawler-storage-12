import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from typing import Tuple

class Position:
    def __init__(self):
        self.amount = 10
        self.avg_price = 0
        self.side = ''
        self.hedge_index = 0
        self.update_time = 0

    def __repr__(self):
        return f"Position(amount={self.amount}, avg_price={self.avg_price}, side={self.side}, hedge_index={self.hedge_index})"

class HedgePositionManager:
    def __init__(self):
        print(f"Mock HedgePositionManager class 初始化")

        self.symbols = ''
        self.base_index = 2
        self.positions = [{symbol: Position() for symbol in ['BTC_USDT']} for _ in range(self.base_index)]

    def get_hedge_positions(self, symbol: str) -> Tuple[Position, Position]:
        return Position(), Position()

