
class Trader:
    def __init__(self):
        print(f"Mock Trader class 初始化")

