# TerraformGen

A CLI tool to generate Terraform module structures quickly.

## Install

pip install simpleterraform

## Use

simpleterraform
