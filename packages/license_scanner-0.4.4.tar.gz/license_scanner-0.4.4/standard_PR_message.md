With [PEP 639](https://peps.python.org/pep-0639/), the standard for license is [SPDX](https://spdx.org/licenses/).
So I think this refers to []()

This makes it easier for tools to figure out what license is used.
