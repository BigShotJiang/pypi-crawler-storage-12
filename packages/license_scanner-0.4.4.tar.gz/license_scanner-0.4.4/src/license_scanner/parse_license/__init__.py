from .main import parse_license
