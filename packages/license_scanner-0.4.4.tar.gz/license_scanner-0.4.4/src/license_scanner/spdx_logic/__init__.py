from .main import spdx_logic
