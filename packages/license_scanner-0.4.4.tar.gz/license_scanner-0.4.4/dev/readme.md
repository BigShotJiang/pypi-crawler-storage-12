# Dev Scripts

These scripts are tools to find licenses in an automated way.
They are not part of the package itself.