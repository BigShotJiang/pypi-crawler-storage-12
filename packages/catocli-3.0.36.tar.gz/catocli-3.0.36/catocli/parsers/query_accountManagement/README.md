
## CATO-CLI - query.accountManagement:
[Click here](https://api.catonetworks.com/documentation/#query-query.accountManagement) for documentation on this operation.

### Usage for query.accountManagement:

```bash
catocli query accountManagement -h

catocli query accountManagement <json>

catocli query accountManagement "$(cat < query.accountManagement.json)"

#### Operation Arguments for query.accountManagement ####

`accountId` [ID] - (required) N/A    
