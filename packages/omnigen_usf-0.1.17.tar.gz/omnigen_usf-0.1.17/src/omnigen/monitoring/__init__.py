"""MongoDB monitoring package."""

from omnigen.monitoring.mongodb_monitor import MongoDBMonitor

__all__ = ['MongoDBMonitor']