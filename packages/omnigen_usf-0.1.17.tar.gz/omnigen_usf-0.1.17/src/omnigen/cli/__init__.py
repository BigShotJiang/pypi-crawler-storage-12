"""CLI tools for OmniGen."""

from omnigen.cli.main import app

__all__ = ["app"]