"""Base classes and utilities for GUI components."""

from .callback_manager import CallbackManager

__all__ = ['CallbackManager']