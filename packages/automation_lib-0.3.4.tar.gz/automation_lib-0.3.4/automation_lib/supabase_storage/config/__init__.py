"""
Supabase Storage Configuration Module
"""
