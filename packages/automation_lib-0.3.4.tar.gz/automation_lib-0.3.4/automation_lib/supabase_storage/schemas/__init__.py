"""
Supabase Storage Schemas Module
"""
