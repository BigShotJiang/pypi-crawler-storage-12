"""
Gmail Config - Konfiguration und Parameter

Dieses Modul definiert die Konfigurationsstrukturen für das Gmail-Modul.
"""

from .gmail_config import GmailConfig

__all__ = ["GmailConfig"]
