"""
Gmail CLI - Kommandozeilen-Schnittstelle

Dieses Modul stellt die CLI-Einstiegspunkte für das Gmail-Modul bereit.
"""
