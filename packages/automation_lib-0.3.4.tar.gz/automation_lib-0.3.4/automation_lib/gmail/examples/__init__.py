"""
Gmail Examples - Anwendungsbeispiele

Dieses Modul enthält Beispiele für die Nutzung des Gmail-Moduls.
"""
