This is a simple Python package for creating bar graph.


