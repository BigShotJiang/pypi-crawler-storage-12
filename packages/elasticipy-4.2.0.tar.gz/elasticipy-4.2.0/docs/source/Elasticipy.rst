Elasticipy package
==================

Submodules
----------

.. toctree::
   :maxdepth: 4

   Elasticipy.tensors.fourth_order
   Elasticipy.tensors.elasticity
   Elasticipy.tensors.second_order
   Elasticipy.tensors.stress_strain
   Elasticipy.spherical_function
   Elasticipy.plasticity
   Elasticipy.interfaces.PRISMS
   Elasticipy.interfaces.FEPX

Module contents
---------------

.. automodule:: Elasticipy
   :members:
   :undoc-members:
   :show-inheritance:
