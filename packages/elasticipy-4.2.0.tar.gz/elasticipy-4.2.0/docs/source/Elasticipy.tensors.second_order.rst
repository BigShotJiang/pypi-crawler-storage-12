Elasticipy.tensors.second_order module
======================================

.. automodule:: Elasticipy.tensors.second_order
   :members:
   :undoc-members:
   :show-inheritance:
