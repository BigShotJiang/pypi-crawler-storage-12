Elasticipy.plasticity module
============================

.. automodule:: Elasticipy.plasticity
   :members:
   :undoc-members:
   :show-inheritance: