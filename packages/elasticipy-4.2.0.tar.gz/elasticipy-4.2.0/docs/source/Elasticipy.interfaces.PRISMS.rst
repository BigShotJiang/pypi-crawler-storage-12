Elasticipy.interfaces.PRISMS module
====================================

.. automodule:: Elasticipy.interfaces.PRISMS
   :members:
   :undoc-members:
   :show-inheritance: