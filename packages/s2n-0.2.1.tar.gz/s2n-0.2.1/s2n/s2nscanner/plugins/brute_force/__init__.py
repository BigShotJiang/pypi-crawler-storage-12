from .brute_force_main import main as Plugin

__all__ = ["Plugin"]