def main():
    print("running taulu")
