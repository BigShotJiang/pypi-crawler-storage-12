_version_ = "0.0.2"
from setuptools import setup

setup()