import{l as o,e as r}from"../chunks/x9dhbL3g.js";export{o as load_css,r as start};
