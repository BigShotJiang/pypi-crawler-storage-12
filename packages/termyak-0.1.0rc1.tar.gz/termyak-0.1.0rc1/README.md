<div align="center">

# termyak

Yet Another Kit: Python utilities packaged as an installable terminal application

[![GitHub](https://img.shields.io/badge/github-code-blue?label=GitHub)](https://github.com/oyghen/termyak)
[![PyPI](https://img.shields.io/pypi/v/termyak?label=PyPI)](https://pypi.org/project/termyak)
[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://github.com/oyghen/termyak/blob/main/LICENSE)
[![CI](https://github.com/oyghen/termyak/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/oyghen/termyak/actions/workflows/ci.yml)

</div>

```shell
pip install termyak
```
