import importlib.metadata as metadata

__version__ = metadata.version("python-ecd")
