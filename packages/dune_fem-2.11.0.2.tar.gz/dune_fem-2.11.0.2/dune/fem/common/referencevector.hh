#ifndef DUNE_FEM_COMMON_REFERENCEVECTOR_HH
#define DUNE_FEM_COMMON_REFERENCEVECTOR_HH

#warning("WARNING: please include dune/fem/storage/referencevector.hh instead of dune/fem/common/referencevector.hh.")

#include <dune/fem/storage/referencevector.hh>

#endif //#ifndef DUNE_FEM_COMMON_REFERENCEVECTOR_HH
