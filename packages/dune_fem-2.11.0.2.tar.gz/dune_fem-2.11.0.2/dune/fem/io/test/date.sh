#!/bin/bash
echo "Calculating the date!" >&2
sleep 1
date +%y.%m.%d_%H:%M:%S
