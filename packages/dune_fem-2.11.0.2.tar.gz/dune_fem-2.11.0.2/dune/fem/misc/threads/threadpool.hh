#ifndef DUNE_FEM_MISC_THREADS_THREADPOOL_HH
#define DUNE_FEM_MISC_THREADS_THREADPOOL_HH
#include <dune/fem/misc/mpimanager.hh>
#warning "Deprecated header, use #include <dune/fem/misc/mpimanager.hh> instead!"
#endif
