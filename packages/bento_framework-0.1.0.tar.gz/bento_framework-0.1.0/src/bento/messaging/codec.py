import json

encode = json.dumps
decode = json.loads
