"""
Property class for well log data with filtering support.
"""
from pathlib import Path
from typing import Optional, TYPE_CHECKING, Union

import numpy as np
import pandas as pd
from scipy.interpolate import interp1d

from .exceptions import PropertyError, PropertyNotFoundError, PropertyTypeError, DepthAlignmentError
from .statistics import compute_intervals, weighted_mean, weighted_sum, weighted_std, weighted_percentile, arithmetic_mean, arithmetic_sum, arithmetic_std

if TYPE_CHECKING:
    from .well import Well
    from .las_file import LasFile


class Property:
    """
    Single log property with depth-value pairs and filtering operations.

    A Property can contain secondary properties (filters) that are aligned
    on the same depth grid. This enables chained filtering operations.

    Parameters
    ----------
    name : str
        Property name (sanitized for Python attribute access)
    depth : np.ndarray
        Depth values
    values : np.ndarray
        Log values
    parent_well : Well, optional
        Parent well for property lookup during filtering
    unit : str, default ''
        Unit string
    prop_type : str, default 'continuous'
        Either 'continuous' or 'discrete'
    description : str, default ''
        Property description
    null_value : float, default -999.25
        Value to treat as null/missing
    labels : dict[int, str], optional
        Label mapping for discrete properties (e.g., {0: 'NonNet', 1: 'Net'})
    original_name : str, optional
        Original property name with special characters (from LAS file)

    Attributes
    ----------
    name : str
        Property name (sanitized for Python attribute access)
    original_name : str
        Original property name with special characters (from LAS file)
    depth : np.ndarray
        Depth values
    values : np.ndarray
        Log values (nulls converted to np.nan)
    unit : str
        Unit string
    type : str
        'continuous' or 'discrete'
    description : str
        Description
    parent_well : Well | None
        Parent well reference
    labels : dict[int, str] | None
        Label mapping for discrete values
    source_las : LasFile | None
        Source LAS file this property came from
    source : str | None
        Source LAS file path (read-only property)
    secondary_properties : list[Property]
        List of aligned filter properties

    Examples
    --------
    >>> phie = well.get_property('PHIE')
    >>> filtered = phie.filter('Zone').filter('NTG_Flag')
    >>> stats = filtered.sums_avg()
    """
    
    def __init__(
        self,
        name: str,
        depth: Optional[np.ndarray] = None,
        values: Optional[np.ndarray] = None,
        parent_well: Optional['Well'] = None,
        unit: str = '',
        prop_type: str = 'continuous',
        description: str = '',
        null_value: float = -999.25,
        labels: Optional[dict[int, str]] = None,
        source_las: Optional['LasFile'] = None,
        source_name: Optional[str] = None,
        original_name: Optional[str] = None,
        lazy: bool = False
    ):
        self.name = name  # Sanitized name for Python attribute access
        self.original_name = original_name or name  # Original name with special characters
        self.parent_well = parent_well
        self.unit = unit
        self._type = prop_type  # Internal storage for type
        self.description = description
        self._labels = labels  # Internal storage for labels
        self.source_las = source_las  # Source LAS file this property came from
        self.source_name = source_name  # Source name (file path or external_df)
        self._null_value = null_value

        # Secondary properties (filters) aligned on same depth grid
        self.secondary_properties: list[Property] = []

        # Lazy loading support
        self._lazy = lazy
        self._depth_cache: Optional[np.ndarray] = None
        self._values_cache: Optional[np.ndarray] = None

        # Filtered copy tracking
        self._is_filtered = False  # True if this is a filtered copy with modified depth grid
        self._boundary_samples_inserted = 0  # Number of boundary samples added during filtering
        self._original_sample_count = 0  # Original sample count before filtering

        # For derived properties (not lazy), store data directly
        if not lazy:
            if depth is not None and values is not None:
                self._depth_cache = np.asarray(depth, dtype=np.float64)
                self._values_cache = np.asarray(values, dtype=np.float64)

                # Replace null values with np.nan
                self._values_cache = np.where(
                    np.abs(self._values_cache - null_value) < 1e-6,
                    np.nan,
                    self._values_cache
                )

    @property
    def source(self) -> Optional[str]:
        """
        Get the source this property came from.

        Returns
        -------
        Optional[str]
            Source name - either a LAS file path or external DataFrame name
            (e.g., 'path/to/original.las' or 'external_df')

        Examples
        --------
        >>> prop = well.get_property('PHIE')
        >>> print(prop.source)  # 'path/to/original.las' or 'external_df'
        """
        if self.source_name:
            return self.source_name
        return str(self.source_las.filepath) if self.source_las else None

    @property
    def type(self) -> str:
        """
        Get the property type ('continuous' or 'discrete').

        Returns
        -------
        str
            Property type
        """
        return self._type

    @type.setter
    def type(self, value: str) -> None:
        """
        Set the property type and mark source as modified.

        Parameters
        ----------
        value : str
            Property type ('continuous' or 'discrete')
        """
        if value not in ('continuous', 'discrete'):
            raise ValueError(f"type must be 'continuous' or 'discrete', got '{value}'")
        if value != self._type:
            self._type = value
            self._mark_source_modified()

    @property
    def labels(self) -> Optional[dict[int, str]]:
        """
        Get the label mapping for discrete property values.

        Returns
        -------
        Optional[dict[int, str]]
            Mapping of numeric values to label strings, or None if not discrete
        """
        return self._labels

    @labels.setter
    def labels(self, value: Optional[dict[int, str]]) -> None:
        """
        Set the label mapping and mark source as modified.

        Parameters
        ----------
        value : Optional[dict[int, str]]
            Mapping of numeric values to label strings
        """
        if value != self._labels:
            self._labels = value
            self._mark_source_modified()

    def _mark_source_modified(self) -> None:
        """Mark the parent well's source as modified so it gets re-exported on save."""
        if self.parent_well is not None and self.source_name is not None:
            try:
                self.parent_well.mark_source_modified(self.source_name)
            except (KeyError, AttributeError):
                # Source may not exist in well (e.g., filtered copy) - ignore
                pass

    @property
    def depth(self) -> np.ndarray:
        """
        Get depth array with lazy loading support.

        For lazy properties, data is loaded from source_las on first access.
        For derived properties, data is stored directly.

        Returns
        -------
        np.ndarray
            Depth values
        """
        # Check if we have cached data
        if self._depth_cache is not None:
            return self._depth_cache

        # If lazy and not cached, load from source LAS
        if self._lazy and self.source_las is not None:
            # Load data from LAS file
            las_data = self.source_las.data

            # Get depth column
            depth_col = self.source_las.depth_column
            if depth_col not in las_data.columns:
                raise PropertyError(
                    f"Depth column '{depth_col}' not found in LAS data. "
                    f"Available columns: {', '.join(las_data.columns)}"
                )

            self._depth_cache = las_data[depth_col].values.astype(np.float64)
            return self._depth_cache

        # No data available
        raise PropertyError(
            f"Property '{self.name}' has no depth data. "
            "Either provide depth during initialization or set source_las for lazy loading."
        )

    @property
    def values(self) -> np.ndarray:
        """
        Get values array with lazy loading support.

        For lazy properties, data is loaded from source_las on first access.
        For derived properties, data is stored directly.

        Returns
        -------
        np.ndarray
            Property values (nulls converted to np.nan)
        """
        # Check if we have cached data
        if self._values_cache is not None:
            return self._values_cache

        # If lazy and not cached, load from source LAS
        if self._lazy and self.source_las is not None:
            # Load data from LAS file
            las_data = self.source_las.data

            # Get property column using original name
            if self.original_name not in las_data.columns:
                raise PropertyError(
                    f"Property '{self.original_name}' not found in LAS data. "
                    f"Available columns: {', '.join(las_data.columns)}"
                )

            values = las_data[self.original_name].values.astype(np.float64)

            # Replace null values with np.nan
            values = np.where(
                np.abs(values - self._null_value) < 1e-6,
                np.nan,
                values
            )

            self._values_cache = values
            return self._values_cache

        # No data available
        raise PropertyError(
            f"Property '{self.name}' has no values data. "
            "Either provide values during initialization or set source_las for lazy loading."
        )

    @property
    def is_filtered(self) -> bool:
        """
        Check if this property is a filtered copy with modified depth grid.

        Returns
        -------
        bool
            True if this is a filtered copy, False if original
        """
        return self._is_filtered

    def filter_info(self) -> dict:
        """
        Get information about filtering applied to this property.

        Returns
        -------
        dict
            Dictionary with filtering metadata:
            - is_filtered: bool - whether this is a filtered copy
            - filters: list[str] - names of applied filters
            - original_sample_count: int - samples before filtering
            - current_sample_count: int - samples after filtering
            - boundary_samples_inserted: int - synthetic samples added at boundaries
        """
        return {
            'is_filtered': self._is_filtered,
            'filters': [sp.name for sp in self.secondary_properties],
            'original_sample_count': self._original_sample_count if self._is_filtered else len(self.depth),
            'current_sample_count': len(self.depth),
            'boundary_samples_inserted': self._boundary_samples_inserted,
        }

    def filter(self, property_name: str) -> 'Property':
        """
        Add a discrete property from parent well as a filter dimension.

        Returns new Property with the discrete property values interpolated
        to the current depth grid. The depth grid remains unchanged - only
        the discrete values are added as a secondary property.

        Parameters
        ----------
        property_name : str
            Name of discrete property in parent well

        Returns
        -------
        Property
            New property instance with secondary property added (same depth grid)

        Raises
        ------
        PropertyNotFoundError
            If parent_well is None or property doesn't exist
        PropertyTypeError
            If property is not discrete type

        Examples
        --------
        >>> filtered = well.phie.filter("Zone").filter("NTG_Flag")
        >>> stats = filtered.sums_avg()
        >>> # Shape remains the same - only discrete values are added
        >>> original.shape  # (29, 2)
        >>> filtered.data().shape  # (29, 3) - added Zone column
        """
        if self.parent_well is None:
            raise PropertyNotFoundError(
                f"Cannot filter property '{self.name}': no parent well reference. "
                "Property must be created from a Well to enable filtering."
            )

        # Lookup in parent well
        try:
            discrete_prop = self.parent_well.get_property(property_name)
        except KeyError:
            available = ', '.join(self.parent_well.properties)
            raise PropertyNotFoundError(
                f"Property '{property_name}' not found in well '{self.parent_well.name}'. "
                f"Available properties: {available}"
            )

        # Validate it's discrete
        if discrete_prop.type != 'discrete':
            raise PropertyTypeError(
                f"Property '{property_name}' must be discrete type, "
                f"got '{discrete_prop.type}'. Set type with: "
                f"well.get_property('{property_name}').type = 'discrete'"
            )

        # Insert synthetic samples at discrete property boundaries
        # This ensures accurate interval weighting when zone boundaries don't align with samples
        new_depth, new_values, new_secondaries = self._insert_boundary_samples(discrete_prop)

        # Interpolate discrete property to the NEW depth grid (with boundary samples)
        # Use 'previous' (forward fill) for discrete: value at MD applies from that depth downward
        interpolated_discrete = self._resample_to_grid(
            discrete_prop.depth,
            discrete_prop.values,
            new_depth,  # Use expanded depth grid with boundary samples
            method='previous'  # Forward fill: value applies from depth downward until next marker
        )

        # Mask out discrete values where main property is undefined (NaN)
        # This prevents filtering at depths where the main log doesn't have valid data
        interpolated_discrete = np.where(np.isnan(new_values), np.nan, interpolated_discrete)

        # Add new secondary property (already on same grid as other secondaries)
        new_secondaries.append(Property(
            name=discrete_prop.name,
            depth=new_depth.copy(),  # Same depth grid with boundaries
            values=interpolated_discrete,
            parent_well=self.parent_well,
            unit=discrete_prop.unit,
            prop_type=discrete_prop.type,
            description=discrete_prop.description,
            null_value=-999.25,
            labels=discrete_prop.labels,
            source_las=discrete_prop.source_las,
            source_name=discrete_prop.source_name,
            original_name=discrete_prop.original_name
        ))

        # Create new Property instance with all secondaries
        new_prop = Property(
            name=self.name,
            depth=new_depth,  # Expanded depth grid with boundary samples
            values=new_values,  # Interpolated values at new depths
            parent_well=self.parent_well,
            unit=self.unit,
            prop_type=self.type,
            description=self.description,
            null_value=-999.25,  # Already cleaned
            labels=self.labels,
            source_las=self.source_las,
            source_name=self.source_name,
            original_name=self.original_name
        )
        new_prop.secondary_properties = new_secondaries

        # Track that this is a filtered copy with modified depth grid
        new_prop._is_filtered = True
        new_prop._original_sample_count = len(self.depth)
        new_prop._boundary_samples_inserted = len(new_depth) - len(self.depth)

        return new_prop

    def _insert_boundary_samples(
        self,
        discrete_prop: 'Property'
    ) -> tuple[np.ndarray, np.ndarray, list['Property']]:
        """
        Insert synthetic samples at discrete property boundaries.

        When a discrete property (e.g., zone top) changes value at a depth that
        doesn't align with the log sample grid, this creates synthetic samples
        at those boundary depths to properly partition the intervals.

        Only inserts boundaries within the valid data range of the main property
        (where values are not NaN).

        Parameters
        ----------
        discrete_prop : Property
            Discrete property with boundary depths (e.g., zone tops)

        Returns
        -------
        tuple
            (new_depth, new_values, new_secondaries) with boundary samples inserted
        """
        # Get unique boundary depths from discrete property (handle duplicates)
        # When duplicate depths exist, keep only unique ones for boundary insertion
        valid_discrete_mask = ~np.isnan(discrete_prop.values)
        boundary_depths = np.unique(discrete_prop.depth[valid_discrete_mask])

        # Determine valid depth range of main property (where data exists)
        valid_mask = ~np.isnan(self.values)
        if not np.any(valid_mask):
            # No valid data, return copies
            return (
                self.depth.copy(),
                self.values.copy(),
                [sp for sp in self.secondary_properties]
            )

        valid_depths = self.depth[valid_mask]
        min_valid_depth = valid_depths.min()
        max_valid_depth = valid_depths.max()

        # Find boundaries that fall within the valid data range
        boundaries_to_insert = []
        for bd in boundary_depths:
            # Check if boundary falls strictly within valid data range
            if min_valid_depth < bd < max_valid_depth:
                # Check it's not already a sample point (within 1mm tolerance)
                # Use rtol=0 to only use absolute tolerance (avoid relative tolerance scaling with depth)
                # Note: 1mm tolerance to avoid duplicate samples, but still capture boundary changes
                if not np.any(np.isclose(self.depth, bd, atol=0.001, rtol=0)):
                    boundaries_to_insert.append(bd)

        if not boundaries_to_insert:
            # No boundaries to insert, return copies
            return (
                self.depth.copy(),
                self.values.copy(),
                [sp for sp in self.secondary_properties]
            )

        boundaries_to_insert = np.array(sorted(boundaries_to_insert))

        # Create new depth grid with boundary samples
        new_depth = np.sort(np.concatenate([self.depth, boundaries_to_insert]))

        # Interpolate main property values at new depths
        new_values = self._resample_to_grid(
            self.depth,
            self.values,
            new_depth,
            method='linear' if self.type == 'continuous' else 'previous'
        )

        # Interpolate all existing secondary properties
        new_secondaries = []
        for sp in self.secondary_properties:
            new_sp_values = self._resample_to_grid(
                sp.depth,
                sp.values,
                new_depth,
                method='previous'  # Secondary properties are discrete
            )
            new_secondaries.append(Property(
                name=sp.name,
                depth=new_depth.copy(),
                values=new_sp_values,
                parent_well=sp.parent_well,
                unit=sp.unit,
                prop_type=sp.type,
                description=sp.description,
                null_value=-999.25,
                labels=sp.labels,
                source_las=sp.source_las,
                source_name=sp.source_name,
                original_name=sp.original_name
            ))

        return new_depth, new_values, new_secondaries

    def _align_depths(self, other: 'Property') -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Align this property with another on a common depth grid.
        
        Returns
        -------
        tuple[np.ndarray, np.ndarray, np.ndarray]
            (common_depth, self_values_resampled, other_values_resampled)
        """
        # Find common depth range (intersection)
        min_depth = max(self.depth.min(), other.depth.min())
        max_depth = min(self.depth.max(), other.depth.max())
        
        if min_depth >= max_depth:
            raise DepthAlignmentError(
                f"No overlapping depth range between '{self.name}' "
                f"[{self.depth.min():.2f}, {self.depth.max():.2f}] and "
                f"'{other.name}' [{other.depth.min():.2f}, {other.depth.max():.2f}]"
            )
        
        # Use finer grid of the two
        step_self = np.median(np.diff(self.depth)) if len(self.depth) > 1 else 0.1
        step_other = np.median(np.diff(other.depth)) if len(other.depth) > 1 else 0.1
        common_step = min(step_self, step_other)
        
        # Create common depth grid
        common_depth = np.arange(min_depth, max_depth + common_step/2, common_step)
        
        # Resample both properties
        resampled_self = self._resample_to_grid(
            self.depth,
            self.values,
            common_depth,
            method='linear' if self.type == 'continuous' else 'previous'
        )

        resampled_other = self._resample_to_grid(
            other.depth,
            other.values,
            common_depth,
            method='linear' if other.type == 'continuous' else 'previous'
        )
        
        return common_depth, resampled_self, resampled_other
    
    @staticmethod
    def _resample_to_grid(
        old_depth: np.ndarray,
        old_values: np.ndarray,
        new_depth: np.ndarray,
        method: str = 'linear'
    ) -> np.ndarray:
        """
        Resample values from old depth grid to new depth grid.

        Parameters
        ----------
        old_depth : np.ndarray
            Original depth values
        old_values : np.ndarray
            Original property values
        new_depth : np.ndarray
            Target depth grid
        method : str, default 'linear'
            Interpolation method:
            - 'linear': Linear interpolation (default for continuous)
            - 'previous': Forward fill - value applies from depth downward (use for discrete/tops)
            - 'nearest': Nearest neighbor
            - 'cubic': Cubic spline interpolation

        Returns
        -------
        np.ndarray
            Resampled values on new grid
        """
        # Remove NaN values for interpolation
        mask = ~np.isnan(old_values)
        valid_depth = old_depth[mask]
        valid_values = old_values[mask]

        if len(valid_depth) == 0:
            # All NaN, return NaN array
            return np.full_like(new_depth, np.nan, dtype=np.float64)

        # Handle duplicate depths: keep the LAST value for each depth
        # This is important when tops data has multiple entries at same depth
        if len(valid_depth) > 1:
            unique_depths, unique_indices = np.unique(valid_depth, return_index=True)
            if len(unique_depths) < len(valid_depth):
                # Duplicates exist - for each unique depth, find the last occurrence
                last_indices = []
                for ud in unique_depths:
                    # Find all indices where depth equals this unique depth
                    matches = np.where(valid_depth == ud)[0]
                    # Take the last one
                    last_indices.append(matches[-1])
                valid_depth = valid_depth[last_indices]
                valid_values = valid_values[last_indices]

        if len(valid_depth) == 1:
            # Single point, use nearest neighbor
            method = 'nearest'
        
        # Interpolate
        try:
            # Special handling for 'previous' to forward-fill beyond last point
            if method == 'previous':
                # Use 'previous' for interpolation but forward-fill beyond range
                f = interp1d(
                    valid_depth,
                    valid_values,
                    kind=method,
                    bounds_error=False,
                    fill_value=(np.nan, valid_values[-1])  # NaN before, last value after
                )
            else:
                f = interp1d(
                    valid_depth,
                    valid_values,
                    kind=method,
                    bounds_error=False,
                    fill_value=np.nan
                )
            return f(new_depth)
        except Exception as e:
            raise DepthAlignmentError(
                f"Failed to resample data: {e}"
            )
    
    def sums_avg(self, weighted: bool = True, arithmetic: bool = False) -> dict:
        """
        Compute hierarchical statistics grouped by all secondary properties.

        Parameters
        ----------
        weighted : bool, default True
            Include depth-weighted statistics
        arithmetic : bool, default False
            Include arithmetic (unweighted) statistics

        Returns
        -------
        dict
            Nested dictionary with statistics for each group combination.
            Structure includes:
            - mean: weighted and/or arithmetic mean
            - sum: weighted and/or arithmetic sum
            - std_dev: weighted and/or arithmetic standard deviation
            - percentile: {p10, p50, p90} values
            - range: {min, max} value range
            - samples: number of valid samples
            - thickness: depth interval for this group
            - gross_thickness: total depth interval (all groups)
            - thickness_fraction: thickness / gross_thickness
            - calculation: 'weighted', 'arithmetic', or 'both'

        Examples
        --------
        >>> # Simple statistics (no filters)
        >>> phie = well.get_property('PHIE')
        >>> stats = phie.sums_avg()
        >>> # {'mean': 0.18, 'sum': 45.2, 'samples': 251, ...}

        >>> # With arithmetic stats
        >>> stats = phie.sums_avg(arithmetic=True)
        >>> # {'mean': {'weighted': 0.18, 'arithmetic': 0.17}, ...}

        >>> # Grouped statistics
        >>> filtered = phie.filter('Zone').filter('NTG_Flag')
        >>> stats = filtered.sums_avg()
        >>> # {'Zone_1': {'NTG_Flag_0': {...}, 'NTG_Flag_1': {...}}, ...}
        """
        # Calculate gross thickness for fraction calculation
        full_intervals = compute_intervals(self.depth)
        valid_mask = ~np.isnan(self.values)
        gross_thickness = float(np.sum(full_intervals[valid_mask]))

        if not self.secondary_properties:
            # No filters, simple statistics
            return self._compute_stats(
                np.ones(len(self.depth), dtype=bool),
                weighted=weighted,
                arithmetic=arithmetic,
                gross_thickness=gross_thickness
            )

        # Build hierarchical grouping
        return self._recursive_group(
            0,
            np.ones(len(self.depth), dtype=bool),
            weighted=weighted,
            arithmetic=arithmetic,
            gross_thickness=gross_thickness
        )

    def _recursive_group(
        self,
        filter_idx: int,
        mask: np.ndarray,
        weighted: bool,
        arithmetic: bool,
        gross_thickness: float
    ) -> dict:
        """
        Recursively group by secondary properties.

        Parameters
        ----------
        filter_idx : int
            Index of current secondary property
        mask : np.ndarray
            Boolean mask for current group
        weighted : bool
            Include weighted statistics
        arithmetic : bool
            Include arithmetic statistics
        gross_thickness : float
            Total gross thickness for fraction calculation

        Returns
        -------
        dict
            Statistics dict or nested dict of statistics
        """
        if filter_idx >= len(self.secondary_properties):
            # Base case: compute statistics for this group
            return self._compute_stats(mask, weighted, arithmetic, gross_thickness)

        # Get unique values for current filter
        current_filter = self.secondary_properties[filter_idx]
        filter_values = current_filter.values[mask]
        unique_vals = np.unique(filter_values[~np.isnan(filter_values)])

        if len(unique_vals) == 0:
            # No valid values, return stats for current mask
            return self._compute_stats(mask, weighted, arithmetic, gross_thickness)

        # Group by each unique value
        result = {}
        for val in unique_vals:
            sub_mask = mask & (current_filter.values == val)

            # Create readable key with label if available
            if current_filter.labels is not None and val == int(val) and int(val) in current_filter.labels:
                # Use label from mapping
                key = current_filter.labels[int(val)]
            elif val == int(val):  # Integer value without label
                key = f"{current_filter.name}_{int(val)}"
            else:  # Float value
                key = f"{current_filter.name}_{val:.2f}"

            result[key] = self._recursive_group(
                filter_idx + 1, sub_mask, weighted, arithmetic, gross_thickness
            )

        return result

    def _compute_stats(
        self,
        mask: np.ndarray,
        weighted: bool = True,
        arithmetic: bool = False,
        gross_thickness: float = 0.0
    ) -> dict:
        """
        Compute statistics for values selected by mask.

        Uses depth-weighted statistics by default, which properly accounts for
        varying sample spacing. Also includes arithmetic (unweighted) statistics
        for comparison.

        Parameters
        ----------
        mask : np.ndarray
            Boolean mask selecting subset of data
        weighted : bool
            Include weighted statistics
        arithmetic : bool
            Include arithmetic statistics
        gross_thickness : float
            Total gross thickness for fraction calculation

        Returns
        -------
        dict
            Statistics dictionary with organized structure:
            - mean, sum, std: single value or {weighted, arithmetic} dict
            - percentile: {p10, p50, p90} with single or nested values
            - samples, thickness, fraction, min, max
            - calculation: method indicator
        """
        values = self.values[mask]
        valid = values[~np.isnan(values)]

        # Compute depth intervals on FULL depth array first, then mask
        # This is critical! Intervals must be computed on full grid so that
        # zone boundary samples get correct weights based on their neighbors
        # in the full sequence, not just within their zone.
        full_intervals = compute_intervals(self.depth)
        intervals = full_intervals[mask]
        valid_mask_local = ~np.isnan(values)
        valid_intervals = intervals[valid_mask_local]

        # Total depth thickness (sum of intervals, not just first to last)
        thickness = float(np.sum(valid_intervals)) if len(valid_intervals) > 0 else 0.0

        # Fraction of gross thickness
        fraction = thickness / gross_thickness if gross_thickness > 0 else 0.0

        # Determine calculation method for output
        if weighted and arithmetic:
            calc_method = 'both'
        elif weighted:
            calc_method = 'weighted'
        else:
            calc_method = 'arithmetic'

        # Helper to format single or dual values
        def format_value(w_val, a_val):
            if weighted and arithmetic:
                return {'weighted': w_val, 'arithmetic': a_val}
            elif weighted:
                return w_val
            else:
                return a_val

        # Compute weighted stats
        w_mean = weighted_mean(values, intervals)
        w_sum = weighted_sum(values, intervals)
        w_std = weighted_std(values, intervals)
        w_p10 = weighted_percentile(values, intervals, 10)
        w_p50 = weighted_percentile(values, intervals, 50)
        w_p90 = weighted_percentile(values, intervals, 90)

        # Compute arithmetic stats
        a_mean = arithmetic_mean(values)
        a_sum = arithmetic_sum(values)
        a_std = arithmetic_std(values)
        # Arithmetic percentiles using numpy
        if len(valid) > 0:
            a_p10 = float(np.percentile(valid, 10))
            a_p50 = float(np.percentile(valid, 50))
            a_p90 = float(np.percentile(valid, 90))
        else:
            a_p10 = a_p50 = a_p90 = np.nan

        # Build percentile dict
        percentile_dict = {
            'p10': format_value(w_p10, a_p10),
            'p50': format_value(w_p50, a_p50),
            'p90': format_value(w_p90, a_p90),
        }

        # Build range dict
        range_dict = {
            'min': float(np.min(valid)) if len(valid) > 0 else np.nan,
            'max': float(np.max(valid)) if len(valid) > 0 else np.nan,
        }

        return {
            'mean': format_value(w_mean, a_mean),
            'sum': format_value(w_sum, a_sum),
            'std_dev': format_value(w_std, a_std),
            'percentile': percentile_dict,
            'range': range_dict,
            'samples': int(len(valid)),
            'thickness': thickness,
            'gross_thickness': gross_thickness,
            'thickness_fraction': fraction,
            'calculation': calc_method,
        }
    
    def _apply_labels(self, values: np.ndarray) -> np.ndarray:
        """
        Apply label mapping to numeric values.

        Parameters
        ----------
        values : np.ndarray
            Numeric values to map

        Returns
        -------
        np.ndarray
            Array with labels applied (object dtype), preserving NaN values
        """
        if self.labels is None:
            return values

        # Create result array as object type to hold strings
        result = np.empty(len(values), dtype=object)

        for i, val in enumerate(values):
            if np.isnan(val):
                result[i] = np.nan
            else:
                int_val = int(val)
                result[i] = self.labels.get(int_val, int_val)  # Use label or fall back to numeric

        return result

    def data(
        self,
        discrete_labels: bool = True,
        clip_edges: bool = True,
        clip_to_property: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Export property and secondary properties as DataFrame.

        Parameters
        ----------
        discrete_labels : bool, default True
            If True, apply label mappings to discrete properties
        clip_edges : bool, default True
            If True, remove rows at the start and end where all data columns
            (excluding DEPT) contain NaN values. This trims the DataFrame to the
            range where actual data exists.
        clip_to_property : str, optional
            Clip output to the defined range of this specific property. If specified,
            overrides clip_edges behavior.

        Returns
        -------
        pd.DataFrame
            DataFrame with DEPT, main property, and secondary properties

        Examples
        --------
        >>> filtered = well.phie.filter('Zone').filter('NTG_Flag')
        >>> df = filtered.data()
        >>> print(df.head())
        >>> df = filtered.data(clip_to_property='Zone')
        """
        data = {
            'DEPT': self.depth,
            self.name: self._apply_labels(self.values) if discrete_labels and self.labels else self.values
        }

        for sec_prop in self.secondary_properties:
            if discrete_labels and sec_prop.labels:
                data[sec_prop.name] = sec_prop._apply_labels(sec_prop.values)
            else:
                data[sec_prop.name] = sec_prop.values

        df = pd.DataFrame(data)

        # Clip to specific property's defined range
        if clip_to_property and clip_to_property in df.columns:
            not_nan = df[clip_to_property].notna()
            if not_nan.any():
                first_valid = not_nan.idxmax()
                last_valid = not_nan[::-1].idxmax()
                df = df.loc[first_valid:last_valid].reset_index(drop=True)
        elif clip_edges and len(df) > 0:
            # Clip edges to remove leading/trailing NaN rows
            # Get data columns (exclude DEPT)
            data_cols = [col for col in df.columns if col != 'DEPT']
            if data_cols:
                # Find first row where at least one data column is not NaN
                not_all_nan = df[data_cols].notna().any(axis=1)
                if not_all_nan.any():
                    first_valid = not_all_nan.idxmax()
                    last_valid = not_all_nan[::-1].idxmax()
                    df = df.loc[first_valid:last_valid].reset_index(drop=True)

        return df

    def head(self, n: int = 5) -> pd.DataFrame:
        """
        Return first n rows of property data.

        Convenience method equivalent to `property.data().head(n)`.

        Parameters
        ----------
        n : int, default 5
            Number of rows to return

        Returns
        -------
        pd.DataFrame
            First n rows of property data

        Examples
        --------
        >>> well.PHIE.head()
        >>> well.PHIE.filter('Zone').head(10)
        """
        return self.data().head(n)

    def export_to_las(
        self,
        filepath: Union[str, Path],
        well_name: Optional[str] = None,
        store_labels: bool = True,
        null_value: float = -999.25
    ) -> None:
        """
        Export property to LAS 2.0 format file.

        Parameters
        ----------
        filepath : Union[str, Path]
            Output LAS file path
        well_name : str, optional
            Well name for the LAS file. If not provided and parent_well exists,
            uses parent well's name. Otherwise uses 'UNKNOWN'.
        store_labels : bool, default True
            If True, store discrete property label mappings in the ~Parameter section.
            The actual data values remain numeric (standard LAS format).
        null_value : float, default -999.25
            Value to use for missing data in LAS file

        Examples
        --------
        >>> prop = well.get_property('PHIE')
        >>> prop.export_to_las('phie_only.las')

        >>> # Export with secondary properties (filters) and labels
        >>> filtered = well.phie.filter('Zone').filter('NTG_Flag')
        >>> filtered.export_to_las('filtered_phie.las', well_name='12/3-2 B')
        """
        # Import here to avoid circular import
        from .las_file import LasFile

        # Determine well name
        if well_name is None:
            if self.parent_well is not None:
                well_name = self.parent_well.name
            else:
                well_name = 'UNKNOWN'

        # Get DataFrame with property and secondary properties (numeric values)
        df = self.data(discrete_labels=False, clip_edges=False)

        # Build column name mapping: sanitized -> original
        column_rename_map = {self.name: self.original_name}
        for sec_prop in self.secondary_properties:
            column_rename_map[sec_prop.name] = sec_prop.original_name

        # Rename DataFrame columns to use original names for LAS export
        df = df.rename(columns=column_rename_map)

        # Build unit mappings (use original names)
        unit_mappings = {
            'DEPT': 'm',  # Default depth unit
            self.original_name: self.unit
        }

        # Add secondary property units
        for sec_prop in self.secondary_properties:
            unit_mappings[sec_prop.original_name] = sec_prop.unit

        # Collect discrete labels if store_labels is True (use original names)
        label_mappings = None
        if store_labels:
            label_mappings = {}
            # Check main property
            if self.labels:
                label_mappings[self.original_name] = self.labels
            # Check secondary properties
            for sec_prop in self.secondary_properties:
                if sec_prop.labels:
                    label_mappings[sec_prop.original_name] = sec_prop.labels

        # Export using LasFile static method
        LasFile.export_las(
            filepath=filepath,
            well_name=well_name,
            df=df,
            unit_mappings=unit_mappings,
            null_value=null_value,
            discrete_labels=label_mappings if label_mappings else None
        )

    def __repr__(self) -> str:
        """String representation."""
        filters = f", filters={len(self.secondary_properties)}" if self.secondary_properties else ""
        filtered_info = ""
        if self._is_filtered:
            filtered_info = f", filtered=True, boundary_samples={self._boundary_samples_inserted}"
        return (
            f"Property('{self.name}', "
            f"samples={len(self.depth)}, "
            f"type='{self.type}'"
            f"{filters}"
            f"{filtered_info})"
        )