# src/ipsumheroes/resources/__init__.py
