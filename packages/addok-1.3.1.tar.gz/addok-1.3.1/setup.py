"""
Minimal setup.py for backwards compatibility.
All package metadata is now in pyproject.toml (PEP 621).
"""
from setuptools import setup

setup()
