"""
An example of integration tests.
I recommend them because they are independent of the application
    architecture and allow you to fairly test your application.
"""
