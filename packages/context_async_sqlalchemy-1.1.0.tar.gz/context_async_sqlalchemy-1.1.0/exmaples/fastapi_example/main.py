"""Application entry point"""

from .setup_app import setup_app


app = setup_app()
