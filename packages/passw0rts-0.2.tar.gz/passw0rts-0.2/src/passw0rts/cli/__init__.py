"""
CLI interface for passw0rts
"""

from .main import main

__all__ = ["main"]
