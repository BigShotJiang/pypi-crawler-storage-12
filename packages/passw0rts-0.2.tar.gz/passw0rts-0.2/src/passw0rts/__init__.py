"""
Passw0rts - A secure cross-platform password manager
"""

__version__ = "0.1.0"
__author__ = "RiseofRice"
