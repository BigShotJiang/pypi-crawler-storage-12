

MACHINECONFIG_VERSION = "machineconfig>=7.93"
DEFAULT_PICKLE_SUBDIR = "tmp_results/tmp_scripts/ssh"

