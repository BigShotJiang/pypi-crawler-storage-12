This module extends the functionality of delivery_cbl and sale_stock_picking_note to allow you to send the customer_note field of the picking to CBL with their observations fields.
