To configure this module, you need to:

1. Go to Inventory / Configuration / Shipping Methods
2. Select your CBL Carrier
3. Set the "CBL Observations Size" with your desired value