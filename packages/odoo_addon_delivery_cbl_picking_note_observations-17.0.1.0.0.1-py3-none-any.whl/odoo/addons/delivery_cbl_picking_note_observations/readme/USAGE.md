To use this module, you need to:

1. Create a picking with a CBL shipping method. See delivery_cbl's readme.
2. Fill the "customer_note" field of the picking, it is located in the "Comments" tab. You can also set a default value in the customer.
3. Confirm the picking to send it so CBL
4. In the chatter, download the CBL tag report. The observations will be filled with your picking's customer_note
