"""
API modules for Certbox.
"""

from .routes import router

__all__ = ["router"]