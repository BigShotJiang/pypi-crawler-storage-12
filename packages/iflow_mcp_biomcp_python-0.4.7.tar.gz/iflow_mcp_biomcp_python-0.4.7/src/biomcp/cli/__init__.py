"""BioMCP Command Line Interface."""

from .main import app

__all__ = ["app"]
