# CHANGELOG

## v0.1.1 (2025-11-12)

### Chore

* chore: formatting ([`a013f6b`](https://github.com/chanind/extract-openreview-comments/commit/a013f6bd7d2c9bcf943fb43246512f9b8ed77acc))

* chore: update README ([`1ff59b5`](https://github.com/chanind/extract-openreview-comments/commit/1ff59b5bef2d90b8ca042d41b826be3395cc27cb))

### Fix

* fix: properly decode html encoded entities ([`7101e94`](https://github.com/chanind/extract-openreview-comments/commit/7101e94e18fa09d1e598edb8fc74d473db62b4c5))

## v0.1.0 (2025-11-12)

### Feature

* feat: autodeploy to pypi ([`4361210`](https://github.com/chanind/extract-openreview-comments/commit/4361210c105859ae00164993aa5503a317470741))

### Unknown

* fixing formatting ([`562cf3d`](https://github.com/chanind/extract-openreview-comments/commit/562cf3d003dbd3d8699236da6f845f2e6cc464f7))

* Update README.md ([`2f52e3a`](https://github.com/chanind/extract-openreview-comments/commit/2f52e3a0d1b409e0f3f7b9d168140e84f146a077))

* initial commit ([`2144c76`](https://github.com/chanind/extract-openreview-comments/commit/2144c768542be0af1bd2cec7baf3b78412c9685c))

* Initial commit ([`705577a`](https://github.com/chanind/extract-openreview-comments/commit/705577ad0bfa4d62e04f432b76be7c1ec62196fb))
