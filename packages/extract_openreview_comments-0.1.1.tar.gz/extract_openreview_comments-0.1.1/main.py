"""Main entry point for the extract-openreview-comments package."""

from extract_openreview_comments.cli import main

if __name__ == "__main__":
    main()
