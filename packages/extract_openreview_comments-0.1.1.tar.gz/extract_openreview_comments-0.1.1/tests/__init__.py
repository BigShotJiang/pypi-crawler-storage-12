"""Tests for openreview-comment-extractor."""
