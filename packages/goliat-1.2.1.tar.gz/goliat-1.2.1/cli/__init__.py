"""GOLIAT CLI entry points."""
