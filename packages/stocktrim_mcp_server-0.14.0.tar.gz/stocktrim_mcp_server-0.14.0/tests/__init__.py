"""Test package for StockTrim MCP Server."""
