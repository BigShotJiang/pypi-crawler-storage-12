# Forecast Update Status

**Status**: Triggered

Forecast calculation started in the background.

## Next Steps

- Use this tool again with wait_for_completion=true to monitor progress
- Check back in a few minutes for updated forecasts
