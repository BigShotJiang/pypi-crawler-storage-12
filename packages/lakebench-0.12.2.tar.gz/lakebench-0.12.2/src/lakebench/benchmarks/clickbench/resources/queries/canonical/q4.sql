SELECT
    AVG(UserID)
FROM
    hits;