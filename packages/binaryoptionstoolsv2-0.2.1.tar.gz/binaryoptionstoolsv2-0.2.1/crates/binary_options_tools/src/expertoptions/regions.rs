use binary_options_tools_macros::RegionImpl;

#[derive(RegionImpl)]
#[region(path = "expert_options_regions.json")]
pub struct Regions;
