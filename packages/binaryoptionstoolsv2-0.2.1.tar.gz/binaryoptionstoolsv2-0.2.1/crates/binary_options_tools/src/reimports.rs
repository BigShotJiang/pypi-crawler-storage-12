pub use binary_options_tools_macros::Config;
