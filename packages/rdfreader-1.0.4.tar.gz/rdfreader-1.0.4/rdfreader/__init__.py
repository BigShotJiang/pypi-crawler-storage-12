from rdfreader.rdf import RDFParser  # noqa F401
