![JSON Logo](json_logo.svg)

# JSON Model

# A compact and intuitive JSON syntax to describe JSON data structures

[Getting Started](README.md)
