package CHECK_PACKAGE_NAME;
use Exporter 'import';
our @ISA = qw( Exporter );
our @EXPORT = qw(
    CHECK_FUNCTION_NAME_init
    CHECK_FUNCTION_NAME_map
    CHECK_FUNCTION_NAME
    CHECK_FUNCTION_NAME_free
);
