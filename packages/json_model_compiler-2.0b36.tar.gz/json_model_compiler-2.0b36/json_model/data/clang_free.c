void CHECK_FUNCTION_NAME_free(void)
{
    if (initialized)
    {
        initialized = false;

        // cleanup code
CODE_BLOCK
    }
}
