// differed module cleanup
export function CHECK_FUNCTION_NAME_free()
{
    if (initialized)
    {
        initialized = false;
CODE_BLOCK
    }
}
