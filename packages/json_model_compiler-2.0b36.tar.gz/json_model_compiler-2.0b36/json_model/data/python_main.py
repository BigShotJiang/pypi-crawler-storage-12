
if __name__ == "__main__":
    CHECK_FUNCTION_NAME_init()
    main(CHECK_FUNCTION_NAME_fun, CHECK_FUNCTION_NAME_map, __version__)
    CHECK_FUNCTION_NAME_free()
