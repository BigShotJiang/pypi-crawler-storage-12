sub CHECK_FUNCTION_NAME_free()
{
    if ($initialized)
    {
        $initialized = 0;
CODE_BLOCK
    }
}
