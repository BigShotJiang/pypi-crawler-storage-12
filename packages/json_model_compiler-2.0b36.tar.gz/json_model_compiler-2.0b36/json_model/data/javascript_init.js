var initialized = false

// differed module initializations
export function CHECK_FUNCTION_NAME_init()
{
    if (! initialized)
    {
        initialized = true;
CODE_BLOCK
    }
}
