public void free()
{
    if (initialized)
    {
        super.free();
CODE_BLOCK
    }
}
