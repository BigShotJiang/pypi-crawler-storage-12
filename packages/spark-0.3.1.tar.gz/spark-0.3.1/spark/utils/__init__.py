"""Utility functions for the Spark framework."""

from spark.utils.common import (
    arun,
)

__all__ = [
    "arun",
]
