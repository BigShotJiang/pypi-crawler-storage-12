"""Spark framework for building agentic workflows."""
