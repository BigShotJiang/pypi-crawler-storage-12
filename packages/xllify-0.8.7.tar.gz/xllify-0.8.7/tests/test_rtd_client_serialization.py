"""Tests for RTD client value serialization (_serialize_value)"""

import pytest
import sys
from unittest.mock import patch


# Test basic scalar types (no dependencies)
def test_serialize_int():
    """Test serializing integer values"""
    from xllify.rtd_client import _serialize_value

    assert _serialize_value(42) == "i:42"
    assert _serialize_value(0) == "i:0"
    assert _serialize_value(-100) == "i:-100"


def test_serialize_float():
    """Test serializing float values"""
    from xllify.rtd_client import _serialize_value

    assert _serialize_value(42.5) == "d:42.5"
    assert _serialize_value(0.0) == "d:0.0"
    assert _serialize_value(-3.14) == "d:-3.14"


def test_serialize_bool():
    """Test serializing boolean values (must check before int!)"""
    from xllify.rtd_client import _serialize_value

    assert _serialize_value(True) == "b:true"
    assert _serialize_value(False) == "b:false"


def test_serialize_string():
    """Test serializing string values"""
    from xllify.rtd_client import _serialize_value

    assert _serialize_value("hello") == "s:hello"
    assert _serialize_value("") == "s:"
    assert _serialize_value("with spaces") == "s:with spaces"


def test_serialize_none():
    """Test serializing None as null type"""
    from xllify.rtd_client import _serialize_value

    assert _serialize_value(None) == "n:"


def test_serialize_nan():
    """Test serializing NaN as null type (without numpy)"""
    from xllify.rtd_client import _serialize_value

    nan = float("nan")
    assert _serialize_value(nan) == "n:"


def test_serialize_exception():
    """Test serializing exceptions as error type"""
    from xllify.rtd_client import _serialize_value

    exc = ValueError("something went wrong")
    result = _serialize_value(exc)
    assert result.startswith("e:")
    assert "something went wrong" in result


def test_serialize_error_string():
    """Test serializing Excel error strings

    Note: Currently ANY string starting with '#' is treated as an error.
    This catches all Excel errors (#VALUE!, #N/A, etc.) but also catches
    non-error strings like '#hashtag'. This is a conservative approach.
    """
    from xllify.rtd_client import _serialize_value

    assert _serialize_value("#ERROR: invalid") == "e:#ERROR: invalid"
    assert _serialize_value("#VALUE!") == "e:#VALUE!"
    assert _serialize_value("#N/A") == "e:#N/A"
    assert _serialize_value("#DIV/0!") == "e:#DIV/0!"
    # Currently all # strings are treated as errors (conservative approach)
    assert _serialize_value("#hashtag") == "e:#hashtag"


def test_serialize_matrix():
    """Test serializing 2D matrix (list of lists)"""
    from xllify.rtd_client import _serialize_value

    matrix = [[1, 2], [3, 4]]
    result = _serialize_value(matrix)
    assert result.startswith("m:2,2\n")
    assert "i:1" in result
    assert "i:2" in result
    assert "i:3" in result
    assert "i:4" in result


def test_serialize_matrix_mixed_types():
    """Test serializing matrix with mixed types"""
    from xllify.rtd_client import _serialize_value

    matrix = [[1, 2.5, True], ["hello", False, None]]
    result = _serialize_value(matrix)

    lines = result.split("\n")
    assert lines[0] == "m:2,3"  # dimensions
    assert lines[1] == "i:1"
    assert lines[2] == "d:2.5"
    assert lines[3] == "b:true"
    assert lines[4] == "s:hello"
    assert lines[5] == "b:false"
    assert lines[6] == "n:"


def test_serialize_matrix_irregular():
    """Test serializing irregular matrix (different row lengths)"""
    from xllify.rtd_client import _serialize_value

    matrix = [[1, 2, 3], [4, 5]]  # Second row shorter
    result = _serialize_value(matrix)

    lines = result.split("\n")
    assert lines[0] == "m:2,3"  # Max columns is 3
    # First row
    assert lines[1] == "i:1"
    assert lines[2] == "i:2"
    assert lines[3] == "i:3"
    # Second row (padded with null)
    assert lines[4] == "i:4"
    assert lines[5] == "i:5"
    assert lines[6] == "n:"  # Padding for missing column


def test_serialize_empty_matrix():
    """Test serializing empty matrices"""
    from xllify.rtd_client import _serialize_value

    # Empty matrix
    matrix = [[]]
    result = _serialize_value(matrix)
    assert result == "m:1,0"


# Tests with numpy available
@pytest.mark.skipif(
    not hasattr(sys.modules.get("xllify.rtd_client", object()), "HAS_NUMPY")
    or not sys.modules.get("xllify.rtd_client", object()).HAS_NUMPY,
    reason="numpy not available",
)
def test_serialize_numpy_types():
    """Test serializing numpy types when numpy is available"""
    import numpy as np
    from xllify.rtd_client import _serialize_value

    # Numpy scalar types
    assert _serialize_value(np.int32(42)) == "i:42"
    assert _serialize_value(np.int64(100)) == "i:100"
    assert _serialize_value(np.float32(3.14)) == "d:3.140000104904175"  # float32 precision
    assert _serialize_value(np.float64(2.5)) == "d:2.5"
    assert _serialize_value(np.bool_(True)) == "b:true"
    assert _serialize_value(np.bool_(False)) == "b:false"


@pytest.mark.skipif(
    not hasattr(sys.modules.get("xllify.rtd_client", object()), "HAS_NUMPY")
    or not sys.modules.get("xllify.rtd_client", object()).HAS_NUMPY,
    reason="numpy not available",
)
def test_serialize_numpy_nan():
    """Test serializing numpy NaN values"""
    import numpy as np
    from xllify.rtd_client import _serialize_value

    assert _serialize_value(np.nan) == "n:"
    assert _serialize_value(np.float32("nan")) == "n:"
    assert _serialize_value(np.float64("nan")) == "n:"


@pytest.mark.skipif(
    not hasattr(sys.modules.get("xllify.rtd_client", object()), "HAS_NUMPY")
    or not sys.modules.get("xllify.rtd_client", object()).HAS_NUMPY,
    reason="numpy not available",
)
def test_serialize_matrix_with_numpy_types():
    """Test serializing matrix containing numpy types"""
    import numpy as np
    from xllify.rtd_client import _serialize_value

    matrix = [[np.int32(1), np.float64(2.5)], [np.bool_(True), np.nan]]
    result = _serialize_value(matrix)

    lines = result.split("\n")
    assert lines[0] == "m:2,2"
    assert lines[1] == "i:1"
    assert lines[2] == "d:2.5"
    assert lines[3] == "b:true"
    assert lines[4] == "n:"  # numpy nan


# Tests with pandas available
@pytest.mark.skipif(
    not hasattr(sys.modules.get("xllify.rtd_client", object()), "HAS_PANDAS")
    or not sys.modules.get("xllify.rtd_client", object()).HAS_PANDAS,
    reason="pandas not available",
)
def test_serialize_dataframe():
    """Test serializing pandas DataFrame"""
    import pandas as pd
    from xllify.rtd_client import _serialize_value

    df = pd.DataFrame({"A": [1, 2, 3], "B": [4.5, 5.5, 6.5], "C": ["x", "y", "z"]})

    result = _serialize_value(df)
    lines = result.split("\n")

    # Should be matrix with headers
    assert lines[0] == "m:4,3"  # 3 data rows + 1 header row, 3 columns
    # Headers
    assert lines[1] == "s:A"
    assert lines[2] == "s:B"
    assert lines[3] == "s:C"
    # First data row
    assert lines[4] == "d:1.0"  # pandas converts ints to float in some contexts
    assert lines[5] == "d:4.5"
    assert lines[6] == "s:x"


@pytest.mark.skipif(
    not hasattr(sys.modules.get("xllify.rtd_client", object()), "HAS_PANDAS")
    or not sys.modules.get("xllify.rtd_client", object()).HAS_PANDAS,
    reason="pandas not available",
)
def test_serialize_dataframe_with_nan():
    """Test serializing DataFrame with NaN values"""
    import pandas as pd
    import numpy as np
    from xllify.rtd_client import _serialize_value

    df = pd.DataFrame({"A": [1, None, 3], "B": [4.5, float("nan"), 6.5]})

    result = _serialize_value(df)
    lines = result.split("\n")

    # Check that NaN/None are serialized as empty strings (per _dataframe_to_matrix docstring)
    # Headers: A, B
    assert lines[1] == "s:A"
    assert lines[2] == "s:B"
    # Row 1: 1, 4.5
    assert "d:1.0" in result or "d:1" in result
    assert "d:4.5" in result
    # Row 2: None/NaN should be empty strings ""
    assert "s:" in result  # Empty strings for NaN


@pytest.mark.skipif(
    not hasattr(sys.modules.get("xllify.rtd_client", object()), "HAS_PANDAS")
    or not sys.modules.get("xllify.rtd_client", object()).HAS_PANDAS,
    reason="pandas not available",
)
def test_serialize_dataframe_with_bools():
    """Test serializing DataFrame with boolean values"""
    import pandas as pd
    from xllify.rtd_client import _serialize_value

    df = pd.DataFrame({"flag": [True, False, True], "value": [1, 2, 3]})

    result = _serialize_value(df)
    lines = result.split("\n")

    # Check bool handling (bools must be checked before numerics!)
    assert "b:true" in result
    assert "b:false" in result


@pytest.mark.skipif(
    not hasattr(sys.modules.get("xllify.rtd_client", object()), "HAS_PANDAS")
    or not sys.modules.get("xllify.rtd_client", object()).HAS_PANDAS,
    reason="pandas not available",
)
def test_serialize_dataframe_with_numpy_types():
    """Test serializing DataFrame with various numpy dtypes"""
    import pandas as pd
    import numpy as np
    from xllify.rtd_client import _serialize_value

    # Create DataFrame with specific numpy dtypes
    df = pd.DataFrame(
        {
            "int32_col": np.array([1, 2, 3], dtype=np.int32),
            "int64_col": np.array([10, 20, 30], dtype=np.int64),
            "float32_col": np.array([1.5, 2.5, 3.5], dtype=np.float32),
            "float64_col": np.array([10.5, 20.5, 30.5], dtype=np.float64),
            "bool_col": np.array([True, False, True], dtype=np.bool_),
        }
    )

    result = _serialize_value(df)
    lines = result.split("\n")

    # Should be 6 rows (1 header + 3 data), 5 columns
    assert lines[0] == "m:4,5"

    # Headers
    assert lines[1] == "s:int32_col"
    assert lines[2] == "s:int64_col"
    assert lines[3] == "s:float32_col"
    assert lines[4] == "s:float64_col"
    assert lines[5] == "s:bool_col"

    # Check that numpy types are properly converted
    # First data row
    assert lines[6].startswith("d:")  # int32 -> float
    assert lines[7].startswith("d:")  # int64 -> float
    assert lines[8].startswith("d:")  # float32 -> float
    assert lines[9].startswith("d:")  # float64 -> float
    assert lines[10] == "b:true"  # bool preserved


@pytest.mark.skipif(
    not hasattr(sys.modules.get("xllify.rtd_client", object()), "HAS_PANDAS")
    or not sys.modules.get("xllify.rtd_client", object()).HAS_PANDAS,
    reason="pandas not available",
)
def test_serialize_dataframe_mixed_types():
    """Test serializing DataFrame with mixed types including strings and objects"""
    import pandas as pd
    from xllify.rtd_client import _serialize_value

    df = pd.DataFrame(
        {
            "numbers": [1, 2, 3],
            "floats": [1.1, 2.2, 3.3],
            "strings": ["a", "b", "c"],
            "bools": [True, False, True],
            "mixed": [1, "text", 3.14],  # Object dtype
        }
    )

    result = _serialize_value(df)
    lines = result.split("\n")

    # Check headers
    assert "s:numbers" in result
    assert "s:floats" in result
    assert "s:strings" in result
    assert "s:bools" in result
    assert "s:mixed" in result

    # Check data types are preserved correctly
    assert "s:a" in result
    assert "s:b" in result
    assert "s:c" in result
    assert "b:true" in result
    assert "b:false" in result
    # Mixed column should stringify non-numeric values
    assert "s:text" in result


# Tests simulating missing dependencies
def test_serialize_without_numpy():
    """Test that serialization works when numpy is not available"""
    # This test simulates numpy not being available
    with patch("xllify.rtd_client.HAS_NUMPY", False):
        from xllify.rtd_client import _serialize_value

        # Should still work with basic Python types
        assert _serialize_value(42) == "i:42"
        assert _serialize_value(3.14) == "d:3.14"
        assert _serialize_value(True) == "b:true"
        assert _serialize_value("hello") == "s:hello"
        assert _serialize_value(None) == "n:"

        # Matrix should work without numpy
        matrix = [[1, 2], [3, 4]]
        result = _serialize_value(matrix)
        assert result.startswith("m:2,2")


def test_serialize_without_pandas():
    """Test that serialization works when pandas is not available"""
    # This test simulates pandas not being available
    with patch("xllify.rtd_client.HAS_PANDAS", False):
        from xllify.rtd_client import _serialize_value

        # Basic types should work
        assert _serialize_value(42) == "i:42"
        assert _serialize_value([1, 2, 3]) == "s:[1, 2, 3]"  # List becomes string

        # Matrix should still work
        matrix = [[1, 2], [3, 4]]
        result = _serialize_value(matrix)
        assert result.startswith("m:2,2")


def test_serialize_without_any_optional_deps():
    """Test serialization with neither numpy nor pandas"""
    with patch("xllify.rtd_client.HAS_NUMPY", False), patch("xllify.rtd_client.HAS_PANDAS", False):
        from xllify.rtd_client import _serialize_value

        # All basic Python types should work
        assert _serialize_value(42) == "i:42"
        assert _serialize_value(3.14) == "d:3.14"
        assert _serialize_value(True) == "b:true"
        assert _serialize_value(False) == "b:false"
        assert _serialize_value("test") == "s:test"
        assert _serialize_value(None) == "n:"
        assert _serialize_value(float("nan")) == "n:"

        # Matrix with basic types
        matrix = [[1, 2.5, True], ["hello", False, None]]
        result = _serialize_value(matrix)
        lines = result.split("\n")
        assert lines[0] == "m:2,3"
        assert "i:1" in result
        assert "d:2.5" in result
        assert "b:true" in result
        assert "s:hello" in result
        assert "b:false" in result
        assert "n:" in result
