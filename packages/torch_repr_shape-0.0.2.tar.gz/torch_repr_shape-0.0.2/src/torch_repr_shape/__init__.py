from .patch import enable_torch_repr_shape

__all__ = ["enable_torch_repr_shape"]
