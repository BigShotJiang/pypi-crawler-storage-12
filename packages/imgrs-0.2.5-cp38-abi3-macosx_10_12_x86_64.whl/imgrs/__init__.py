"""
Imgrs - A high-performance, memory-safe image processing library

Provides the high-level API while addressing
performance and memory-safety issues through a Rust backend.
"""

from .enums import (
    BlendMode,
    ColorFormat,
    ImageFormat,
    ImageMode,
    MaskType,
    Resampling,
    Transpose,
)
from .image import Image
from .mixins.color_mixin import ColorMixin
from .operations import (
    blur,
    brightness,
    contrast,
    convert,
    crop,
    edge_detect,
    emboss,
    fromarray,
    new,
    open,
    paste,
    resize,
    rotate,
    save,
    sharpen,
    split,
)

__version__ = "0.2.4"
__author__ = "Grandpa EJ"

__all__ = [
    "BlendMode",
    "ColorFormat",
    "ColorMixin",
    "Image",
    "ImageMode",
    "ImageFormat",
    "MaskType",
    "Resampling",
    "Transpose",
    "open",
    "new",
    "save",
    "resize",
    "crop",
    "rotate",
    "convert",
    "fromarray",
    "split",
    "paste",
    # Filters
    "blur",
    "sharpen",
    "edge_detect",
    "emboss",
    "brightness",
    "contrast",
]
