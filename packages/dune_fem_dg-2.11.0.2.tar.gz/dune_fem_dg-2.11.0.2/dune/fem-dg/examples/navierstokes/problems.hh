#ifndef FEMDG_NAVIERSTOKES_PROBLEMS_HH
#define FEMDG_NAVIERSTOKES_PROBLEMS_HH

#include "problems/nswaves.hh"
//#include "problems/nsmooth.hh"

#endif
