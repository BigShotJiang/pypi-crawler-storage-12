"""Deprecated case template rule value models have been removed."""

__all__: list[str] = []
