## [2.0.18] - 2025-11-17

### Added
- Add default profile for Akeyless

