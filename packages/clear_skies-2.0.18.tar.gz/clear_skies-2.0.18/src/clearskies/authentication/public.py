from .authentication import Authentication


class Public(Authentication):
    pass
