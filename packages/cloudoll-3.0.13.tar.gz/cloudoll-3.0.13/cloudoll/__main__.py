from cloudoll.cli import cli

if __name__ == "__main__":
    cli()
