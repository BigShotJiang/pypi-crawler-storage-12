#!/bin/bash

pip install --upgrade --upgrade-strategy eager -r requirements.txt
