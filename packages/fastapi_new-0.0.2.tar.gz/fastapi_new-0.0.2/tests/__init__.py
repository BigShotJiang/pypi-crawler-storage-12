# Tests for fastapi-new
