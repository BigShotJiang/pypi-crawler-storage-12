.. _basic_api:

####################
methods descriptions
####################

..
    to document functions, add them to __all__ in ../cdsodatacli/__init__.py

.. automodule:: cdsodatacli
    :members:


.. automodule:: cdsodatacli.query
    :members: fetch_data

.. automodule:: cdsodatacli.download
    :members: download_list_product_sequential, download_list_product
