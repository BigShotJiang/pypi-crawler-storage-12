"""Command-line interface for the RAG system."""

from .main import main

__all__ = ["main"]
