"""
AIGroup Econometrics MCP Package
专业计量经济学MCP工具包
"""

__version__ = "2.0.7"
__author__ = "AIGroup"
__email__ = "jackdark425@gmail.com"

__all__ = ["__version__", "__author__", "__email__"]