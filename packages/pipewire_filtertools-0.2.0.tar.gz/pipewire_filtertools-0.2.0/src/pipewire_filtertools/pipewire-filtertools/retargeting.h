/* SPDX-License-Identifier: MIT */

#pragma once

int setup_retargeting(struct pfts_data *data, struct pw_core *core);
