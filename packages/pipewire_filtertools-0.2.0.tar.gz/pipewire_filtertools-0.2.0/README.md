# pipewire-filtertools - Insert a Process into PipeWire as a Filter

A library that provides an audio processing callback so an application can act as a filter.
