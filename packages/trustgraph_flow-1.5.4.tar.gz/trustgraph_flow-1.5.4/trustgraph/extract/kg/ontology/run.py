#!/usr/bin/env python3

"""
OntoRAG extraction service launcher.
"""

from . extract import run

if __name__ == "__main__":
    run()