from .lib import Adapter
from .utils import transform_value
# from .resource import (
#     Code, Coding, CodeableConcept, ContactPoint, Reference, Address, Attachment, Period, Profile, Identifier, HumanName,
#     Practitioner,
# )
