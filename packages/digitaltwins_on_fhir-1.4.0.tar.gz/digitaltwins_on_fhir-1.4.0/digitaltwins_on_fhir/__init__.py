from .core import Adapter

__title__ = "digitaltwins-on-fhir"
__version__ = "1.4.0"
__author__ = "Linkun Gao"
__license__ = "Apache-2.0"
__copyright__ = "Copyright 2024 ABI"

# Version synonym
VERSION = __version__