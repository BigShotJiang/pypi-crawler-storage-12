from .core import YorubaG2P

__all__ = ["YorubaG2P"]
