# Page to test feature

See: <https://github.com/Guts/mkdocs-rss-plugin/pull/43/>
