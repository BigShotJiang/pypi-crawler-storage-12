---
title: Page with meta date in dot key
authors:
    - Guts
    - Tim Vink
    - liang2kl
date:
    created: 2023-10-07 10:20
update: 2023-10-08 10:20
description: First test page of mkdocs-rss-plugin test suite
image: "https://svgsilh.com/png-512/97849.png"
tags:
    - test
---

# Test page with meta

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
