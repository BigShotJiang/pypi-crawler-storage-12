from poke_env.emulators.pokemon_red_emulator import PokemonRedEmulator

