"""Main entry point for WeCom Bot MCP Server."""

# Import local modules
from wecom_bot_mcp_server.server import main

if __name__ == "__main__":
    main()
