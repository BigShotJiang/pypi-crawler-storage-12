from .config import DEFAULTCONFIG, DEFAULTCONFIG_EN, ConfigData
from .slider import SLIDERCONFIG, SLIDERCONFIG_EN, SliderConfigData

