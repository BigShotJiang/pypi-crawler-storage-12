from a2p import *  # noqa


def test_all():
    assert True
