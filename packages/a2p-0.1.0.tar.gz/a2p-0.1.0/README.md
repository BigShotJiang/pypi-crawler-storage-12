# a2p

Alias for p2a

[![Build Status](https://github.com/tkp-aliases/a2p/actions/workflows/build.yaml/badge.svg?branch=main&event=push)](https://github.com/tkp-aliases/a2p/actions/workflows/build.yaml)
[![codecov](https://codecov.io/gh/tkp-aliases/a2p/branch/main/graph/badge.svg)](https://codecov.io/gh/tkp-aliases/a2p)
[![License](https://img.shields.io/github/license/tkp-aliases/a2p)](https://github.com/tkp-aliases/a2p)
[![PyPI](https://img.shields.io/pypi/v/a2p.svg)](https://pypi.python.org/pypi/a2p)

## Overview

> [!NOTE]
> This library was generated using [copier](https://copier.readthedocs.io/en/stable/) from the [Base Python Project Template repository](https://github.com/python-project-templates/base).
