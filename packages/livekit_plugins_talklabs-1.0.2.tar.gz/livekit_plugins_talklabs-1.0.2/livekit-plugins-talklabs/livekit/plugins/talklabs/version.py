"""Version information for livekit-plugins-talklabs"""

__version__ = "1.0.2"