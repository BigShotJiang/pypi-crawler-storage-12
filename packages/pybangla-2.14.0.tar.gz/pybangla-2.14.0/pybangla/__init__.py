__version__ = "1.0.0"

from pybangla.module.main import Normalizer