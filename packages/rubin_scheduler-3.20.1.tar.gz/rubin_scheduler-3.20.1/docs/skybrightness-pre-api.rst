.. py:currentmodule:: rubin_scheduler.skybrightness_pre

.. _skybrightness-pre-api:

=====================
Skybrightness Pre API
=====================

.. automodule:: rubin_scheduler.skybrightness_pre
    :imported-members:
    :members:
    :show-inheritance:
