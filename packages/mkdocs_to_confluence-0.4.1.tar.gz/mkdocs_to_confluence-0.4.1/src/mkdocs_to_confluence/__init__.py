"""MkDocs plugin for publishing documentation to Confluence."""
