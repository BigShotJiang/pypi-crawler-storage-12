"""Test fixtures for mkdocs-with-confluence."""
