# Parallax-AI

## Installation

```bash
pip install parallax-ai
```