FRONTEND_EXT = ['.js', '.jsx', '.ts', '.tsx', '.vue', '.html', '.css', '.scss', '.less']
