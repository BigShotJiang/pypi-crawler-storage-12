class TaskCancellationException(Exception):
    pass
