"""
PredictionData Python Client

A Python library for streaming historical market data from PredictionData API.
"""

from predictiondata.client import PredictionDataClient
from predictiondata.channel import Channel, DataType

__version__ = "0.1.0"
__all__ = ["PredictionDataClient", "Channel", "DataType"]

