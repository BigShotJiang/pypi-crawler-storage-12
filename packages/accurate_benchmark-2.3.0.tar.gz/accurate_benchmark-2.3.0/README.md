# Accurate Benchmark

This is a python package for accurate benchmarking and speed comparisons
