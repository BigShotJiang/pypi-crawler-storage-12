# Copyright (c) 2025 Airbyte, Inc., all rights reserved.
"""Guidance module for Connector Builder MCP.

This module provides prompts, topic mappings, and checklists for connector development.
"""
