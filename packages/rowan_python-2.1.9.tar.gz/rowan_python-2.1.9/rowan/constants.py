import os

API_URL = os.getenv("ROWAN_API_URL", default="https://api.rowansci.com")
