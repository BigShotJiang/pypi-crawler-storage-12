# TMS Provider API sdk
The TMS provider api SDK provides Python APIs to create and manage accounts, devices, subsriptions, etc. 

## System Requirements
 * requests
 
 On Debian-based systems, run:
 
 `apt-get install python3-requests`
 

## Installation
Install using pip:

`pip3 install tmsproviderapisdk`

## Usage:

See examples folder.