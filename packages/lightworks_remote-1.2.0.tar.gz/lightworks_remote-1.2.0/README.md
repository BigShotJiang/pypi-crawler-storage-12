# lightworks_remote
Extension to lightworks which enables submission of jobs to remote hardware.

Install with:

```bash
pip install git+https://github.com/Aegiq/lightworks_remote
```

Alternatively, if you're working directly with the source code via cloning the repo, then you'll need to use the following command to generate the version data file.

```bash
pip install -e .
```