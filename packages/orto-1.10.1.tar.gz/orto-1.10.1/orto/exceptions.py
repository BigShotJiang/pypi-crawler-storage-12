from extto import DataNotFoundError as exttoDNF
from extto import DataFormattingError as exttoDFE

DataNotFoundError = exttoDNF
DataFormattingError = exttoDFE
