# My Open Source Package
这是一个简单的开源Python工具包。目前处于测试阶段，仅实现了对pandas的极个别指令的简化处理，和一键搭建Flask简易服务器的功能。

## 安装
```bash
pip install mzy_py