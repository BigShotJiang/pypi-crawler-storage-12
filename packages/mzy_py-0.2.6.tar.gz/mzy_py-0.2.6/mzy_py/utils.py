def print_info() -> str:
    """打印包信息"""
    print("自此版本起始将此函数作为指示更新内容的函数，从1.0.0版本起将由Print_Version_Update_info()替换原print_info()函数")
    print("0.2.6之前的版本过于简陋，不再做任何更新和维护。自0.2.6版本起，将持续更新和维护，使用此命令将会打印当前版本更新内容。\n")
    print("0.2.6 更新内容：\n" + 
          "1. 修改了print_info()函数，用于打印更新内容。\n" + 
          "2. 优化了二维码生成功能.生成的二维码将会默认生成在与执行入口脚本所在相同目录。通过QRcodegen_txt()函数调用。\n" + 
          "3. 优化了图片压缩功能.通过compress_img()函数调用。\n" + 
    "")

def print_Version_Update_info() -> str:
    """打印版本更新信息"""
    print("0.2.6 更新内容：\n" + 
          "0.2.6之前的版本过于简陋，不再做任何更新和维护。自0.2.6版本起，将持续更新和维护，使用此命令将会打印当前版本更新内容。\n" +
          "1. 修改了print_info()函数，用于打印更新内容。\n" + 
          "2. 优化了二维码生成功能.生成的二维码将会默认生成在与执行入口脚本所在相同目录。通过QRcodegen_txt()函数调用。\n" + 
          "3. 优化了图片压缩功能.通过compress_img()函数调用。\n" + 
    "")

def print_my_name_mzy() -> str:
    """Return personal intro."""
    print("My name is Mzy, I am a student in BPU.")

def liujinglun() -> str:
    """Return liujinglun's intro."""
    print("He is a bitch enjoy suck everybody's dick. ")

def FuJunYi() -> str:
    """Return mzy's name."""
    print("FuJunYi is a good boy.")

def LiuziHao() -> str:
    """Return mzy's name."""
    print("LiuziHao is one of my best friend.")

def mzy() -> str:
    """Return a confession string."""
    return "I LOVE WeiJinHe"

def PengHongYu() -> str:
    print("PengHongYu is one of my best friend.")

def JiangJingChen() -> str:
    print("JiangJingChen is one of my best friend.")

def LiYanBo() -> str:
    print("LiYanBo is one of my best friend.")


