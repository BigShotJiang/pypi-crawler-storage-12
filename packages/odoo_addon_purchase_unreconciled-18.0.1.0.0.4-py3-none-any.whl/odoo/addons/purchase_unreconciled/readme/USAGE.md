Accountants will be able to find a filters in Purchase Orders that shows
outstanding balances in interim accounts. Also there is a link in the PO
to those outstanding journal items.

Locking the PO will automatically reconcile the outstanding balance for
the stock iterim accounts.
