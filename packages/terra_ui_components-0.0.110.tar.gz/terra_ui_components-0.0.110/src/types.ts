export enum TimeInterval {
    HalfHourly = 'half-hourly',
    Hourly = 'hourly',
    ThreeHourly = '3-hourly',
    Daily = 'daily',
    Weekly = 'weekly',
}
