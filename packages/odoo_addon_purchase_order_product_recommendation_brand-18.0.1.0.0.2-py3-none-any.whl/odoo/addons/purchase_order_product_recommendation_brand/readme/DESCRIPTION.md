This module allows to filter product recommendations by brand.
