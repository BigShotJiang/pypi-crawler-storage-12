INSTALL_TYPE = "full" # lite or full
