"""ipyrf package: a tiny iperf3-like tool with JSON output."""

__all__ = [
    "main",
]
