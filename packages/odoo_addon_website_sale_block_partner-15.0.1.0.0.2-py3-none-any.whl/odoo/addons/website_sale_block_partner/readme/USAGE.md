1. Go to Contacts > select a contact > check the Blacklist field.
2. Log in with this partner.

You can check the functionality in these three cases:
- Go to Sales > create a new sale order > when this contact is selected, a message will be displayed.
- Go to Invoicing > Customers > Invoices > create a new invoice > when this contact is selected, a message will be displayed.
- Go to Website > Shop > click on a product > a message will appear on the page and you won't be able to add the product to the cart.
