This module help to blacklist customers. If the customer is blacklisted, a notification will be shown in sale order and invoice. Also the customer can't buy products from website
