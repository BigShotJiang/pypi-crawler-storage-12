info.png is from Google's material icons
