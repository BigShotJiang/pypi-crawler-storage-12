# pythonbible-diaglot

The Diaglot NT - 1865 (Diaglot) version of the Bible in Python. For use with the `pythonbible` library.
