# endpoints
::: horde_sdk.ratings_api.endpoints
