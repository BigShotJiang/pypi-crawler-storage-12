# metadata
::: horde_sdk.ratings_api.metadata
