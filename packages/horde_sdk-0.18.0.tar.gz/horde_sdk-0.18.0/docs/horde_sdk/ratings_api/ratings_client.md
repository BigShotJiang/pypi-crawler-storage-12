# ratings_client
::: horde_sdk.ratings_api.ratings_client
