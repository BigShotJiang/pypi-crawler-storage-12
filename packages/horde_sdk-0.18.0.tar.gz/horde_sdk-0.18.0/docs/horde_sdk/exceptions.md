# exceptions
::: horde_sdk.exceptions
