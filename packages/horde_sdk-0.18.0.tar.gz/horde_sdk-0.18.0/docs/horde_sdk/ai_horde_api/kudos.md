# kudos
::: horde_sdk.ai_horde_api.kudos
