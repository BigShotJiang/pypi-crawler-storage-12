# exceptions
::: horde_sdk.ai_horde_api.exceptions
