# _find_user
::: horde_sdk.ai_horde_api.apimodels._find_user
