# _status
::: horde_sdk.ai_horde_api.apimodels.alchemy._status
