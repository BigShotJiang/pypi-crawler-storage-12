# _check
::: horde_sdk.ai_horde_api.apimodels.generate._check
