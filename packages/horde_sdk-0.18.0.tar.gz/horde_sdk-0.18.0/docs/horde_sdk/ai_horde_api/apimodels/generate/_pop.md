# _pop
::: horde_sdk.ai_horde_api.apimodels.generate._pop
