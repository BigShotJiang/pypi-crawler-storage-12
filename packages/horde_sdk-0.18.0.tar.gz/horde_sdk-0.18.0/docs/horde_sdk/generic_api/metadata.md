# metadata
::: horde_sdk.generic_api.metadata
