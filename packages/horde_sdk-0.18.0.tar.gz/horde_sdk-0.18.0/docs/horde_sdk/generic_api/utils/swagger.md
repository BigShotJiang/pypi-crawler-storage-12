# swagger
::: horde_sdk.generic_api.utils.swagger
