# bridge_data
::: horde_sdk.ai_horde_worker.bridge_data
