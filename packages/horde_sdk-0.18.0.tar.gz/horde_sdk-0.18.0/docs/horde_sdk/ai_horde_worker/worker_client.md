# worker_client
::: horde_sdk.ai_horde_worker.worker_client
