# bridge_data_fields
::: horde_sdk.ai_horde_worker.locale_info.bridge_data_fields
