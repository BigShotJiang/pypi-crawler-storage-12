# model_meta
::: horde_sdk.ai_horde_worker.model_meta
