"""The api client tailored for horde workers."""
