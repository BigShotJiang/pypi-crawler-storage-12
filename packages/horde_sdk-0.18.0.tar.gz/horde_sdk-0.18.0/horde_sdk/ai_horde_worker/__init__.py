"""Helper methods for creating a worker for the AI Horde."""
