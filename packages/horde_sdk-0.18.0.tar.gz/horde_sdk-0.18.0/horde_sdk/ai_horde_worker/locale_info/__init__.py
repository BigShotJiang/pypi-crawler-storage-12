"""The AI Horde worker locale info package."""
