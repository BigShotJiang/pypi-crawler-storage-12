"""Definitions for the ratings API."""
