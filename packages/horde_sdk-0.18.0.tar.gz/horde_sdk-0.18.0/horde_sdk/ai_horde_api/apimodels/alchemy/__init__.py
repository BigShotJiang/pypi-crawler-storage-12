"""The API models for alchemy (endpoint on v2 referred to as `interrogation`)."""
