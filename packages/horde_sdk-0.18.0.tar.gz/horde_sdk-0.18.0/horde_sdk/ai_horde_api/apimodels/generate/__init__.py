"""The api models for the generate endpoints."""
