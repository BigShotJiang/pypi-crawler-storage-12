"""The API models for the workers endpoints."""
