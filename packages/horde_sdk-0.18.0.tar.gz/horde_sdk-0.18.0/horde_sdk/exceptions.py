class HordeException(Exception):
    """Base exception for all Horde SDK exceptions."""
