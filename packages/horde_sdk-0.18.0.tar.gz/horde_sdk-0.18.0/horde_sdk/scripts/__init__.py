"""Helper scripts for Horde SDK."""
