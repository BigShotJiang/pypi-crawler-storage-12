"""Definitions for working with the horde model reference system."""
