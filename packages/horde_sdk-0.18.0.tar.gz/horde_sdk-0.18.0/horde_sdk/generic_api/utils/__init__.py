"""Utility functions for any horde API."""
