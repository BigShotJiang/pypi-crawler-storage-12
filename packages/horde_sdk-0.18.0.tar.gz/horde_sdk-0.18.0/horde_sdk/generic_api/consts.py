"""Constants shared by or for any horde API."""

ANON_API_KEY = "0000000000"
