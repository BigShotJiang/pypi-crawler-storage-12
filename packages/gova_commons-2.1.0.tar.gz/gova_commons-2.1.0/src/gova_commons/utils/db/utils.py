from datetime import UTC, datetime


def get_datetime():
    return datetime.now(UTC)
