from imod.formats.gen.gen import read, read_ascii, read_binary, write
