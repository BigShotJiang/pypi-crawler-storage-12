//! Converts glyphs.app sources into IR for font compilation.

pub mod source;
mod toir;
