# ufo2fontir

This crate is a frontend for compilation of .designspace sources. It converts from .designspace to the fontc
internal representation.

It should be referenced only by fontc.
