# fontbe

[![MIT/Apache 2.0](https://img.shields.io/badge/license-MIT%2FApache-blue.svg)](#license)

fontbe: Font BackEnd.

This crate is the backend of font compilation. It provides the tasks to convert from IR to a binary font.

Only fontc should reference this crate.
