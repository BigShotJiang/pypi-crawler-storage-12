# fontir

[![MIT/Apache 2.0](https://img.shields.io/badge/license-MIT%2FApache-blue.svg)](#license)

fontir: Font Intermediate Representation

This crate defines the intermediate representation (IR) of a font used by fontc and common operations
on that IR.

It should be referenced by fontc and any frontend (_format_2fontir) crates.
