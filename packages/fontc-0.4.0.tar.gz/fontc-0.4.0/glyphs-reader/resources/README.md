# Dat files

*.dat content generated from glyphsLib 6.10.2 by update.py
