#!/bin/sh

sudo bash -c "$(curl -fsSL https://download.simplyprint.io/bambu/install-linux.sh)"
