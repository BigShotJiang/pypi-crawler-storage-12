WACZ_VERSION = "1.1.1"

# https://specs.webrecorder.net/wacz/1.1.1/#archive
ARCHIVE_DIR = "archive/"

# https://specs.webrecorder.net/wacz/1.1.1/#indexes
INDEXES_DIR = "indexes/"
