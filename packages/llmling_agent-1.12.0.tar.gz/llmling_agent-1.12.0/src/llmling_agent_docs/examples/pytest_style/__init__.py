"""Pytest-style Example."""

TITLE = "PyTest-Style Functions"
ICON = "octicon:code-16"
