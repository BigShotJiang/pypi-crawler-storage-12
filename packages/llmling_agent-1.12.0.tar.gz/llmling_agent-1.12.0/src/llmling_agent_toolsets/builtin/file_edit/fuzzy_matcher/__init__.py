"""Streaming fuzzy matcher."""

from .streaming_fuzzy_matcher import StreamingFuzzyMatcher, Range

__all__ = ["Range", "StreamingFuzzyMatcher"]
