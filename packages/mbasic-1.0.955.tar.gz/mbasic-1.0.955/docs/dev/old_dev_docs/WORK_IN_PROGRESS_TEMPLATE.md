# Work in Progress

**This is a TEMPLATE. Copy to WORK_IN_PROGRESS.md when starting work.**

## Task
Brief description of what's being implemented

## Status
- ⏸️ Not started yet
- ⏸️ Step 2 pending
- ⏸️ Step 3 pending

## Files Modified
- (none yet)

## Next Steps
1. First step to take
2. Second step
3. Third step

## Context/Notes
Any important details needed to resume work after crash/shutdown
