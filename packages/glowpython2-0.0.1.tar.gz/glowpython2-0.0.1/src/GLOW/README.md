# GLOW
The GLobal airglOW Model

This directory contains:
 - Fortran-90 source code files,
 - Subdirectory data/ contains input data files,
