"""Package for plugins."""

from .abstracts import PluginAbstract

__all__: list[str] = [
    "PluginAbstract",
]
