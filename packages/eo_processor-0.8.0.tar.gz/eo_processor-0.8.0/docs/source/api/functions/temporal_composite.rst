temporal_composite
==================

.. autofunction:: eo_processor.temporal_composite
   :noindex:
