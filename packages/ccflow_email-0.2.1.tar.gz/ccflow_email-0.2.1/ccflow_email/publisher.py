from ccflow import BasePublisher

__all__ = ("EmailPublisher",)


class EmailPublisher(BasePublisher): ...
