# ccflow-email

ccflow models for email

[![Build Status](https://github.com/1kbgz/ccflow-email/actions/workflows/build.yaml/badge.svg?branch=main&event=push)](https://github.com/1kbgz/ccflow-email/actions/workflows/build.yaml)
[![codecov](https://codecov.io/gh/1kbgz/ccflow-email/branch/main/graph/badge.svg)](https://codecov.io/gh/1kbgz/ccflow-email)
[![License](https://img.shields.io/github/license/1kbgz/ccflow-email)](https://github.com/1kbgz/ccflow-email)
[![PyPI](https://img.shields.io/pypi/v/ccflow-email.svg)](https://pypi.python.org/pypi/ccflow-email)

## Overview

> [!NOTE]
> This library was generated using [copier](https://copier.readthedocs.io/en/stable/) from the [Base Python Project Template repository](https://github.com/python-project-templates/base).
