from __future__ import annotations

from wexample_helpers.const.types import StringKeysDict

REGISTRY_KERNEL_ADDON: str = "addon"

RegistryResolverData = StringKeysDict
