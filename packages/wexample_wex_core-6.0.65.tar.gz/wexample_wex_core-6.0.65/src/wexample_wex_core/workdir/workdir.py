from __future__ import annotations

from wexample_filestate.utils.file_state_manager import FileStateManager


class Workdir(FileStateManager):
    pass
