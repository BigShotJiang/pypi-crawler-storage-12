# Composite model COMBINE archive (OMEX)

Example of a composite model distributed as COMBINE archive.
