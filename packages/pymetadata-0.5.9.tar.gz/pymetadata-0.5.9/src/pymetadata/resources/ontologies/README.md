# Ontologies

Ontologies have been downloaded from bioportal and other resources as OWL files.
See `ontologies/ontology.py` for information on the download links.
