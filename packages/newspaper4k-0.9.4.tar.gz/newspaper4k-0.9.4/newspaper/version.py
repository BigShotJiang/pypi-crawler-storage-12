"""To change the version of entire package, just edit this one location."""

__version__ = "0.9.4"
VERSION = __version__
