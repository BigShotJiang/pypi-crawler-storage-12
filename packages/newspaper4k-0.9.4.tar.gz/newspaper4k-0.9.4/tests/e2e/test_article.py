# pytest file for testing the article class
