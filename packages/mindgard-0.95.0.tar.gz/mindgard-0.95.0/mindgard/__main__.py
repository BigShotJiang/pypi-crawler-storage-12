# Project imports
from mindgard.cli import main

if __name__ == "__main__":
    # do NOT put logic here, it does not get executed under normal operation.
    main()
