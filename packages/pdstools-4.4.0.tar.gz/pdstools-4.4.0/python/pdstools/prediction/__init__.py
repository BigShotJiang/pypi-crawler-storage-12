from .Prediction import Prediction

__all__ = ["Prediction"]
