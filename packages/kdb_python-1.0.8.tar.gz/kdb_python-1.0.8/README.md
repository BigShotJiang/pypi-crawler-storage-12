# KDB framework
KDB automation testing framework for web (desktop &amp; mobile) and mobile app (android &amp; iOS)
