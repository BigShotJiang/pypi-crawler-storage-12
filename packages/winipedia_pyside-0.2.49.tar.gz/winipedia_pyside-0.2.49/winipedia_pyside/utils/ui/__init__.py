"""__init__ module for winipedia_pyside6.ui."""
