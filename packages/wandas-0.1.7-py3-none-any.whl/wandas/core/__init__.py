from .base_frame import BaseFrame

__all__ = [
    "BaseFrame",
]
