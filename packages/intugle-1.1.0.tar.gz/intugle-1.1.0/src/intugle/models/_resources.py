
from intugle.common.resources.base import BaseResource


class Fewshot(BaseResource): ...


class AnalyticsCatalogue(BaseResource): ...

