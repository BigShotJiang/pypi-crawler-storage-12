from .proxy import get_proxy

__all__ = [
    "get_proxy",
]
