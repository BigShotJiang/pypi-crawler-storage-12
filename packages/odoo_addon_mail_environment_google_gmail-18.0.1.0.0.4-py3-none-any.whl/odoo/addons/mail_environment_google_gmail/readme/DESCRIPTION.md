This module allows to configure Gmail outgoing servers with server-env.
