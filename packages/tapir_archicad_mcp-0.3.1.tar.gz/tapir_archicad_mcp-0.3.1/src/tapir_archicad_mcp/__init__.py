def main() -> None:
    print("Hello from tapir-archicad-mcp!")
