# noqa: D104
# SPDX-FileCopyrightText: 2025 László Vaskó <opensource@vlaci.email.com>
#
# SPDX-License-Identifier: EUPL-1.2

from .globlin import Flag as Flag
from .globlin import fnmatch as fnmatch
