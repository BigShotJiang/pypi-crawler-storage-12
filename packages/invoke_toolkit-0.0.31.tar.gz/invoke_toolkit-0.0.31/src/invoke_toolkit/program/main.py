"""Entrypoint for project.scripts"""

from .program import ToolkitProgram

program = ToolkitProgram(name="invoke-toolkit")
