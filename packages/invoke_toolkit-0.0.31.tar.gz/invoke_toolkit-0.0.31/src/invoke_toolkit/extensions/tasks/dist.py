"""
Generate self contained distributable scripts
"""
