"""Config class"""

from .config import ToolkitConfig  # noqa: F401
