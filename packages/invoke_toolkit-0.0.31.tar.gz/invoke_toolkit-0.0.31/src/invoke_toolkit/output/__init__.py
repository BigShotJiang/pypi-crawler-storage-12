"""rich Console handling"""

from .console import get_console, SecretRedactorConsole  # noqa: F401
from .utils import rich_exit  # noqa: F401
