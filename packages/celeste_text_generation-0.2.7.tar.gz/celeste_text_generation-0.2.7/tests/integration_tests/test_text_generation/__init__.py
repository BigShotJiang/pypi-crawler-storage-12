"""Integration tests for text generation capability."""
