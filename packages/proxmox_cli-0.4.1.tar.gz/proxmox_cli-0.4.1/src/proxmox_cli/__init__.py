"""Proxmox CLI - Command-line interface for Proxmox Virtual Environment."""

__version__ = "0.4.1"
__author__ = "Ralph Brynard"
__email__ = "ralph.brynard@gmail.com"
