"""Tests for proxmox-cli."""
