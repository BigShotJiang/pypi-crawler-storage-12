# Youtube Autonomous Time Interval Module

The way to handle time intervals, very useful when handling videos.