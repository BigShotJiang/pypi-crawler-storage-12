:::: {.cell execution_count="3"}
``` {.python .cell-code}
import pandas as pd
df = pd.DataFrame({'a': [1, 2, 3]})
print("Created dataframe")
df
```

::: {.cell-output .cell-output-stdout}
    Created dataframe
:::

::: {.cell-output .cell-output-display}
<div>
<table>
  <tr><td>a</td></tr>
  <tr><td>1</td></tr>
  <tr><td>2</td></tr>
  <tr><td>3</td></tr>
</table>
</div>
:::
::::
