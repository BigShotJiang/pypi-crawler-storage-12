Some text before the cell.

:::: {.cell execution_count="4"}
``` {.python .cell-code}
print("First output")
import warnings
warnings.warn("A warning")
print("Second output")
```

::: {.cell-output .cell-output-stdout}
    First output
:::

::: {.cell-output .cell-output-stderr}
    UserWarning: A warning
:::

::: {.cell-output .cell-output-stdout}
    Second output
:::
::::

Some text after the cell.
