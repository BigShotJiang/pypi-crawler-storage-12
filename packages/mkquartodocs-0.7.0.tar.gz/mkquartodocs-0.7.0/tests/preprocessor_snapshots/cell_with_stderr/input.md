:::: {.cell execution_count="2"}
``` {.python .cell-code}
import warnings
warnings.warn("This is a warning message")
```

::: {.cell-output .cell-output-stderr}
    UserWarning: This is a warning message
      warnings.warn("This is a warning message")
:::
::::
