# API Documentation

This page documents the main API.

::: pathlib.Path

Some text between API references.

::: os.path.join

More documentation here.

::: collections.defaultdict
