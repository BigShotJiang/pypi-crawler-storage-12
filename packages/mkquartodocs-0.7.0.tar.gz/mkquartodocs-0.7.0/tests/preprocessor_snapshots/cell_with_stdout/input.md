:::: {.cell execution_count="1"}
``` {.python .cell-code}
print("Hello, world!")
print("This is a test")
```

::: {.cell-output .cell-output-stdout}
    Hello, world!
    This is a test
:::
::::
