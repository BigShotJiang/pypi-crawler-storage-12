# Test for Issue #69

This is a regular markdown file with mkdocstrings syntax.

::: math.sqrt

The above line uses mkdocstrings syntax to document the math.sqrt function.
