# include "common.h"

float SolveIsotoneScale(
    const float *first_largest_arr,
    const float *second_largest_arr,
    const int64 length, const int quant_max);
