#ifndef DUNE_POLYGONGRID_DECLARATION_HH
#define DUNE_POLYGONGRID_DECLARATION_HH

namespace Dune
{

  // External Forward Declarations
  // -----------------------------

  template< class ct >
  class PolygonGrid;

} // namespace Dune

#endif // #ifndef DUNE_POLYGONGRID_DECLARATION_HH
