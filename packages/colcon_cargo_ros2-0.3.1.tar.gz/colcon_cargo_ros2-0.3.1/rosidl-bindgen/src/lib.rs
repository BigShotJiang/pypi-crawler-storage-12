//! cargo-ros2-bindgen library
//!
//! This library provides modules for discovering and generating ROS 2 bindings.

pub mod ament;
pub mod generator;
