# Licensed under the Apache License, Version 2.0

from setuptools import setup

setup()
