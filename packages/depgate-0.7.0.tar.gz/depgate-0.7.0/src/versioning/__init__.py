"""Versioning package for package resolution and token parsing."""
