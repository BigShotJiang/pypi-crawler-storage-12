"""Common utilities shared across registry and repository."""
