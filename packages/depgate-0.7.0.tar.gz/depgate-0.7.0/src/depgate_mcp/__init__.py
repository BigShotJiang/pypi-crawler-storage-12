"""DepGate MCP internals.

This package contains schemas and validation helpers used by the DepGate MCP server.
Renamed from the generic 'mcp' to avoid import conflicts with the third-party MCP SDK.
"""
