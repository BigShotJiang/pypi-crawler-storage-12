BASE_URL = "https://api.blocket.se"
SITE_URL = "https://www.blocket.se"
BYTBIL_URL = "https://api.bytbil.com"
QASA_URL = "https://api.qasa.se/graphql"

BLOCKET_SENDBIRD_APP_ID = "162ABE1D-86E9-4C2A-866A-EF1034525DAF"
SENDBIRD_URL = f"https://api-{BLOCKET_SENDBIRD_APP_ID}.sendbird.com"
