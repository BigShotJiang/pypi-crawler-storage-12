This module allows to add multiple tags to purchase orders
