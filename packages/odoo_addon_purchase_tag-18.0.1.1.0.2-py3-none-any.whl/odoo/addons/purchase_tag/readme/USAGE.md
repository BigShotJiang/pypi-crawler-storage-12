To use this module, you need to go to Purchase Orders and select tags.
