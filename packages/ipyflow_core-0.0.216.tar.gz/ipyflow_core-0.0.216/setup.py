#!/usr/bin/env python
# -*- coding: utf-8 -*-
import setuptools


if __name__ == "__main__":
    setuptools.setup()
