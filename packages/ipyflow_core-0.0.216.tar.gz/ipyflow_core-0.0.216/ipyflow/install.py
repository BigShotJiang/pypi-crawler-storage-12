# -*- coding: utf-8 -*-
import sys

from ipyflow.kernel.install import main

# this is just a pointer to ipyflow.kernel.install
if __name__ == "__main__":
    sys.exit(main())
