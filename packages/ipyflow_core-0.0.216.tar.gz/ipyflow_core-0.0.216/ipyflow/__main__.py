# -*- coding: utf-8 -*-
from ipyflow import main as start_ipyflow

start_ipyflow()
