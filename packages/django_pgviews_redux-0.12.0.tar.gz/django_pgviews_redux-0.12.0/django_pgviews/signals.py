from django.dispatch import Signal

view_synced = Signal()
all_views_synced = Signal()
