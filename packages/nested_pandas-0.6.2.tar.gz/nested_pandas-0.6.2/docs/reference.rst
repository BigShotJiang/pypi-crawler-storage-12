API Reference
========================================================================================

.. toctree::
    :maxdepth: 2

    NestedFrame <reference/nestedframe>
    NestedSeries <reference/nestedseries>
    .nest Accessor <reference/accessor>
    Utility Functions <reference/utils>
    NestedDtype <reference/nesteddtype>
    Nested Extension Array <reference/ext_array>
    Packer Functions <reference/packer>
