=========
NestedDtype
=========
.. currentmodule:: nested_pandas

Constructor
~~~~~~~~~~~
.. autosummary::
   :toctree: api/

   series.ext_array.NestedExtensionArray

Functions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.. autosummary::
    :toctree: api/

    series.ext_array.NestedExtensionArray.dtype
    series.ext_array.NestedExtensionArray.nbytes
    series.ext_array.NestedExtensionArray.list_array
    series.ext_array.NestedExtensionArray.struct_array
    series.ext_array.NestedExtensionArray.pa_table
    series.ext_array.NestedExtensionArray.list_offsets
    series.ext_array.NestedExtensionArray.field_names
    series.ext_array.NestedExtensionArray.list_lengths
    series.ext_array.NestedExtensionArray.flat_length
    series.ext_array.NestedExtensionArray.num_chunks
    series.ext_array.NestedExtensionArray.to_numpy
    series.ext_array.NestedExtensionArray.isna
    series.ext_array.NestedExtensionArray.take
    series.ext_array.NestedExtensionArray.copy
    series.ext_array.NestedExtensionArray.equals
    series.ext_array.NestedExtensionArray.dropna
    series.ext_array.NestedExtensionArray.from_sequence
    series.ext_array.NestedExtensionArray.to_arrow_ext_array
    series.ext_array.NestedExtensionArray.to_pyarrow_scalar
    series.ext_array.NestedExtensionArray.get_list_index
    series.ext_array.NestedExtensionArray.iter_field_lists
    series.ext_array.NestedExtensionArray.view_fields
    series.ext_array.NestedExtensionArray.set_flat_field
    series.ext_array.NestedExtensionArray.set_list_field
    series.ext_array.NestedExtensionArray.fill_field_lists
    series.ext_array.NestedExtensionArray.pop_fields
