Biblioteca com uso de SQLmodel e FastAPI para usos didaticos.

Depois de instala a biblioteca é preciso usar o comando "uvicorn HeroTeams1103.main:app --reload" para rodar o código principal