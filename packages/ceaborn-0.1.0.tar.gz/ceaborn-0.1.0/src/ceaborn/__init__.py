#1A

import pandas as pd
import numpy as np

# 1. Read the data
df = pd.read_csv('iris.csv')

# 2. Display the first and last 5 rows
print("--- First 5 rows ---")
print(df.head())

print("\n--- Last 5 rows ---")
print(df.tail())

# 3. Display the number of rows and columns
print("\n--- Number of Rows and Columns (Shape) ---")
print(f"Rows: {df.shape[0]}, Columns: {df.shape[1]}")

# 4. Display the number of categorical and numerical columns
numerical_cols = df.select_dtypes(include=np.number).columns.tolist()
categorical_cols = df.select_dtypes(include='object').columns.tolist()
print("\n--- Column Type Counts ---")
print(f"Numerical Columns: {len(numerical_cols)}")
print(f"Categorical Columns: {len(categorical_cols)}")

# 5. For numerical columns, display the min, max and mode
numerical_stats = df[numerical_cols].agg(['min', 'max', lambda x: x.mode()[0] if not x.mode().empty else 'N/A'])
numerical_stats.index = ['min', 'max', 'mode']
print("\n--- Min, Max, and Mode for Numerical Columns ---")
print(numerical_stats)

# 6. Display the columns with null values
null_counts = df.isnull().sum()
null_columns = null_counts[null_counts > 0]
print("\n--- Columns with Null Values ---")
if null_columns.empty:
    print("No null values found in any column.")
else:
    print(null_columns)


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore

# Read the data
df = pd.read_csv('iris.csv')
numerical_cols = df.select_dtypes(include=np.number).columns.tolist()

# 7. Calculate the 5 number summary
print("\n--- 5 Number Summary (Quartiles, Min, Max, Mean, Std Dev) ---")
five_number_summary = df[numerical_cols].describe().T[['min', '25%', '50%', '75%', 'max']]
print(five_number_summary)

# Box Plot (Correlate with 5 number summary)
plt.figure(figsize=(12, 8))
df[numerical_cols].boxplot()
plt.title('Box Plot of Iris Numerical Features')
plt.ylabel('Value (cm)')
plt.grid(False)
# In Colab, the plot will display automatically here.


# 8. Display the outlier values using Z-score
z_scores = df[numerical_cols].apply(zscore)
outliers = df[(np.abs(z_scores) > 3).any(axis=1)]
print("\n--- Outlier Values (Z-score > 3 or < -3) ---")
if outliers.empty:
    print("No outliers found based on a Z-score threshold of 3.")
else:
    print(outliers)

# 9. Correlation Analysis
correlation_matrix = df[numerical_cols].corr()
print("\n--- Correlation Matrix ---")
print(correlation_matrix)

# Analyze correlation (High positive, high negative, no correlation)
correlations = correlation_matrix.unstack().sort_values(ascending=False)
correlations = correlations[(correlations.index.get_level_values(0) != correlations.index.get_level_values(1))]
high_positive_corr = correlations[correlations > 0.7].drop_duplicates()
high_negative_corr = correlations[correlations < -0.7].drop_duplicates()
no_corr = correlations[(correlations >= -0.1) & (correlations <= 0.1)].drop_duplicates()

print("\n--- High Positive Correlation (r > 0.7) ---")
if high_positive_corr.empty:
    print("No pairs with high positive correlation found.")
else:
    print(high_positive_corr)

print("\n--- High Negative Correlation (r < -0.7) ---")
if high_negative_corr.empty:
    print("No pairs with high negative correlation found.")
else:
    print(high_negative_corr)

print("\n--- No Correlation (-0.1 <= r <= 0.1) ---")
if no_corr.empty:
    print("No pairs with close to zero correlation found.")
else:
    print(no_corr)


# 10. Skewness and Distribution Plot
skewness = df[numerical_cols].skew()
print("\n--- Skewness of Features ---")
print(skewness)

# Analyze skewness
right_skew_features = skewness[skewness > 0.5].index.tolist()
left_skew_features = skewness[skewness < -0.5].index.tolist()
no_skew_features = skewness[(skewness >= -0.5) & (skewness <= 0.5)].index.tolist()

print("\nFeatures with Right Skew (Skew > 0.5):", right_skew_features)
print("Features with Left Skew (Skew < -0.5):", left_skew_features)
print("Features with No Skew (-0.5 <= Skew <= 0.5):", no_skew_features)

# Plot distribution graph
plt.figure(figsize=(15, 10))
for i, col in enumerate(numerical_cols):
    plt.subplot(2, 2, i + 1)
    sns.histplot(df[col], kde=True)
    plt.title(f'Distribution of {col}')
plt.tight_layout()
# In Colab, the plot will display automatically here.

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Read the data
df = pd.read_csv('iris.csv')
categorical_col = 'species'
continuous_col_1 = 'sepal_length'
continuous_col_2 = 'sepal_width'
continuous_col_3 = 'petal_length'

# Set Seaborn style for better plots
sns.set_theme(style="whitegrid")

# 11. Univariate analysis for categorical variables using bar plot
plt.figure(figsize=(7, 5))
df[categorical_col].value_counts().plot(kind='bar', color=sns.color_palette("viridis"))
plt.title(f'Bar Plot of {categorical_col}')
plt.xlabel(categorical_col)
plt.ylabel('Count')
plt.xticks(rotation=0)
# In Colab, the plot will display automatically here.


# 12. Univariate/Bivariate analysis for continuous variables using swarm plot and violin plot
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
sns.swarmplot(x=categorical_col, y=continuous_col_1, data=df, palette="muted")
plt.title(f'Swarm Plot: {continuous_col_1} by {categorical_col}')
plt.xlabel(categorical_col)
plt.ylabel(continuous_col_1)
plt.subplot(1, 2, 2)
sns.violinplot(x=categorical_col, y=continuous_col_1, data=df, palette="pastel")
plt.title(f'Violin Plot: {continuous_col_1} by {categorical_col}')
plt.xlabel(categorical_col)
plt.ylabel(continuous_col_1)
plt.tight_layout()
# In Colab, the plot will display automatically here.


# 13. Scatter plat to show the relationship between two continuous variables
plt.figure(figsize=(8, 6))
sns.scatterplot(x=continuous_col_1, y=continuous_col_2, hue=categorical_col, data=df, palette="deep", s=80)
plt.title(f'Scatter Plot: {continuous_col_1} vs {continuous_col_2}')
plt.xlabel(continuous_col_1)
plt.ylabel(continuous_col_2)
plt.legend(title=categorical_col)
# In Colab, the plot will display automatically here.


# 14. Perform a bivariate analysis between continuous variable and categorical variable using categorical plot (Box Plot used here)
plt.figure(figsize=(8, 6))
sns.boxplot(x=categorical_col, y=continuous_col_3, data=df, palette="Set3")
plt.title(f'Box Plot: {continuous_col_3} by {categorical_col}')
plt.xlabel(categorical_col)
plt.ylabel(continuous_col_3)
# In Colab, the plot will display automatically here.


# 15. Display the counts of observations for categorical variable using count plot
plt.figure(figsize=(7, 5))
sns.countplot(x=categorical_col, data=df, palette="viridis", order=df[categorical_col].value_counts().index)
plt.title(f'Count Plot of {categorical_col}')
plt.xlabel(categorical_col)
plt.ylabel('Count')
# In Colab, the plot will display automatically here.


# 16. Perform a multivariate analysis between features using pair plot
sns.pairplot(df, hue=categorical_col, palette="tab10")
# In Colab, the plot will display automatically here.


#1B



import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import zscore
from sklearn.preprocessing import MinMaxScaler, StandardScaler, LabelEncoder

# 1. Read the data
df = pd.read_csv('iris.csv')
print("--- 1. Data Read and Initial Shape ---")
print(f"Initial Shape: {df.shape}")

# --- Data Simulation for Preprocessing Steps (Since Iris is clean) ---
temp_df = df.copy()

# Inject Missing Values (< 10%): sepal_length (for mean), petal_length (for interpolation), species (for mode)
np.random.seed(42)
for col in ['sepal_length', 'petal_length']:
    missing_indices = np.random.choice(temp_df.index, size=int(0.05 * len(temp_df)), replace=False)
    temp_df.loc[missing_indices, col] = np.nan

missing_indices_cat = np.random.choice(temp_df.index, size=int(0.05 * len(temp_df)), replace=False)
temp_df.loc[missing_indices_cat, 'species'] = np.nan

# Inject Missing Values (> 10%): high_missing_col (for dropping)
missing_indices_high = np.random.choice(temp_df.index, size=int(0.15 * len(temp_df)), replace=False)
temp_df['high_missing_col'] = temp_df['sepal_width']
temp_df.loc[missing_indices_high, 'high_missing_col'] = np.nan

# Inject Duplicate Rows (5 duplicate rows)
temp_df = pd.concat([temp_df, temp_df.iloc[[0, 1, 1, 2, 2]]], ignore_index=True)
print(f"Simulated Data Shape (after adding NA and Duplicates): {temp_df.shape}")
print("-" * 40)

# 2. Calculate the % of missing values in the columns
print("--- 2. % of Missing Values (Simulated Data) ---")
missing_percent = temp_df.isnull().sum() / len(temp_df) * 100
print(missing_percent)
print("-" * 40)

# Column names used for imputation based on simulation
num_col_mean = 'sepal_length'
num_col_interp = 'petal_length'
cat_col_mode = 'species'
col_to_drop = 'high_missing_col'

# 3. Replace missing value with mean for the numerical column (sepal_length)
if missing_percent[num_col_mean] < 10 and missing_percent[num_col_mean] > 0:
    temp_df[num_col_mean].fillna(temp_df[num_col_mean].mean(), inplace=True)
    print(f"--- 3. Mean Imputation for '{num_col_mean}' Done ---")
else:
    print(f"--- 3. Mean Imputation Skipped for '{num_col_mean}' (Missing %: {missing_percent[num_col_mean]:.2f}) ---")
print("-" * 40)

# 4. Perform the interpolation using nearest method for the numerical column (petal_length)
if missing_percent[num_col_interp] < 10 and missing_percent[num_col_interp] > 0:
    temp_df[num_col_interp] = temp_df[num_col_interp].interpolate(method='nearest')
    print(f"--- 4. Nearest Interpolation for '{num_col_interp}' Done ---")
else:
    print(f"--- 4. Nearest Interpolation Skipped for '{num_col_interp}' (Missing %: {missing_percent[num_col_interp]:.2f}) ---")
print("-" * 40)

# 5. Perform the mode imputation for a categorical data (species)
if missing_percent[cat_col_mode] < 10 and missing_percent[cat_col_mode] > 0:
    temp_df[cat_col_mode].fillna(temp_df[cat_col_mode].mode()[0], inplace=True)
    print(f"--- 5. Mode Imputation for '{cat_col_mode}' Done ---")
else:
    print(f"--- 5. Mode Imputation Skipped for '{cat_col_mode}' (Missing %: {missing_percent[cat_col_mode]:.2f}) ---")
print("-" * 40)

# 6. Drop the columns with more than 10% missing values
if missing_percent[col_to_drop] >= 10:
    temp_df.drop(columns=[col_to_drop], inplace=True)
    print(f"--- 6. Dropped column '{col_to_drop}' (Missing %: {missing_percent[col_to_drop]:.2f}) ---")
    print(f"New Shape after dropping column: {temp_df.shape}")
else:
    print(f"--- 6. Column dropping skipped for '{col_to_drop}' (Missing %: {missing_percent[col_to_drop]:.2f}) ---")
print("-" * 40)

# 7. Drop the rows with outlier Z-score value > 3 for 'sepal_width' (Replacement for 'Guarantee_Period')
outlier_col = 'sepal_width'
initial_rows = temp_df.shape[0]
temp_df['z_score'] = zscore(temp_df[outlier_col])
temp_df.drop(temp_df[temp_df['z_score'].abs() > 3].index, inplace=True)
temp_df.drop(columns=['z_score'], inplace=True)
final_rows = temp_df.shape[0]

print(f"--- 7. Dropped Outlier Rows for '{outlier_col}' ---")
print(f"Rows dropped: {initial_rows - final_rows}")
print(f"New size after dropping outliers: {temp_df.shape}")
print("-" * 40)

# 8. Find the % of duplicate rows with all columns having same value.
total_rows = temp_df.shape[0]
total_duplicates_all = temp_df.duplicated().sum()
percent_duplicates_all = (total_duplicates_all / total_rows) * 100

print(f"--- 8. % of fully duplicate rows (all columns) ---")
print(f"Total Rows: {total_rows}")
print(f"Fully Duplicate Rows: {total_duplicates_all}")
print(f"% Fully Duplicate: {percent_duplicates_all:.2f}%")
print("-" * 40)

# 9. Find the % of duplicate rows based on specific columns and drop them.
dup_cols = ['sepal_length', 'sepal_width', 'petal_length'] # Replacement for ['Price','Age','Mfg_Month','Fuel_Type']
total_duplicates_subset = temp_df.duplicated(subset=dup_cols).sum()
percent_duplicates_subset = (total_duplicates_subset / total_rows) * 100
initial_rows_9 = temp_df.shape[0]

# Drop duplicates based on subset
temp_df.drop_duplicates(subset=dup_cols, keep='first', inplace=True)
final_rows_9 = temp_df.shape[0]

print(f"--- 9. % of duplicate rows based on {dup_cols} and Drop ---")
print(f"Duplicate Rows (Subset): {total_duplicates_subset}")
print(f"% Subset Duplicate: {percent_duplicates_subset:.2f}%")
print(f"New size after dropping subset duplicates: {temp_df.shape}")
print("-" * 40)

# 10. Perform the min-max normalization for 'sepal_length' (Replacement for 'Quarterly_Tax')
norm_col = 'sepal_length'
scaler_minmax = MinMaxScaler()
temp_df[f'{norm_col}_MinMax'] = scaler_minmax.fit_transform(temp_df[[norm_col]])

# Analyze values in scatter plot (Min-Max)
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.scatter(temp_df.index, temp_df[norm_col], c='blue', s=10)
plt.title(f'Original {norm_col} Values')
plt.xlabel('Index')
plt.ylabel('Original Value')

plt.subplot(1, 2, 2)
plt.scatter(temp_df.index, temp_df[f'{norm_col}_MinMax'], c='red', s=10)
plt.title(f'Min-Max Normalized {norm_col} Values')
plt.xlabel('Index')
plt.ylabel('Normalized Value (0 to 1)')
plt.tight_layout()
plt.show() # Show plot in Colab

print(f"--- 10. Min-Max Normalization for '{norm_col}' Done (See Plot Above) ---")
print("-" * 40)

# 11. Perform the Z-score normalization for 'sepal_length' (Replacement for 'Quarterly_Tax')
scaler_zscore = StandardScaler()
temp_df[f'{norm_col}_ZScore'] = scaler_zscore.fit_transform(temp_df[[norm_col]])

# Analyze values in scatter plot (Z-score)
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.scatter(temp_df.index, temp_df[norm_col], c='blue', s=10)
plt.title(f'Original {norm_col} Values')
plt.xlabel('Index')
plt.ylabel('Original Value')

plt.subplot(1, 2, 2)
plt.scatter(temp_df.index, temp_df[f'{norm_col}_ZScore'], c='green', s=10)
plt.title(f'Z-score Normalized {norm_col} Values')
plt.xlabel('Index')
plt.ylabel('Normalized Value (Mean 0, Std Dev 1)')
plt.tight_layout()
plt.show() # Show plot in Colab

print(f"--- 11. Z-score Normalization for '{norm_col}' Done (See Plot Above) ---")
print("-" * 40)

# 12. Perform the label encoding for a categorical feature 'species' (Replacement for 'Fuel_Type')
le = LabelEncoder()
temp_df[f'{cat_col_mode}_LabelEncoded'] = le.fit_transform(temp_df[cat_col_mode])

print(f"--- 12. Label Encoding for '{cat_col_mode}' ---")
print(temp_df[[cat_col_mode, f'{cat_col_mode}_LabelEncoded']].head())
print(f"Unique encoded values: {temp_df[f'{cat_col_mode}_LabelEncoded'].unique()}")
print("-" * 40)

# 13. Perform the one-hot encoding for a categorical feature 'species' (Replacement for 'Fuel_Type')
df_one_hot = pd.get_dummies(temp_df[cat_col_mode], prefix=cat_col_mode)

print(f"--- 13. One-Hot Encoding for '{cat_col_mode}' ---")
print(df_one_hot.head())
print("-" * 40)



#2


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import VarianceThreshold, SelectKBest, SelectPercentile, f_regression
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

# 1. Read and analyze the data
df = pd.read_csv('Toyato - Toyato.csv')
print("--- 1. Data Read and Initial Analysis ---")
print("First 5 rows:")
print(df.head())
print("\nData Info:")
print(df.info())
print("-" * 50)

# 5. Calculate the % of missing values in the columns
print("--- 5. % of Missing Values ---")
missing_percent = df.isnull().sum() / len(df) * 100
print(missing_percent[missing_percent > 0].sort_values(ascending=False))
print("-" * 50)

# Identify numerical columns for preprocessing
numerical_cols = df.select_dtypes(include=np.number).columns.tolist()

# Drop 'Price' as it will be the target variable (Y)
if 'Price' in numerical_cols:
    numerical_cols.remove('Price')

# --- Preprocessing Pipeline Setup ---
temp_df = df.copy()

# 6. Remove features with missing values (>20%)
cols_to_drop_na = missing_percent[missing_percent > 20].index.tolist()
if cols_to_drop_na:
    temp_df.drop(columns=cols_to_drop_na, inplace=True)
    numerical_cols = [col for col in numerical_cols if col not in cols_to_drop_na]
    print(f"--- 6. Dropped columns (>20% NA): {cols_to_drop_na} ---")
else:
    print("--- 6. No columns dropped (Missing % < 20%) ---")
print(f"Current shape: {temp_df.shape}")
print("-" * 50)

# 7. If the missing values is <20%, do data imputation (mean/median)
impute_cols = missing_percent[(missing_percent > 0) & (missing_percent <= 20)].index.tolist()

for col in impute_cols:
    if col in numerical_cols:
        # Use mean imputation for numerical columns (Doors was imputed with mean)
        temp_df[col].fillna(temp_df[col].mean(), inplace=True)
    elif temp_df[col].dtype == 'object':
        # Use mode imputation for categorical columns
        temp_df[col].fillna(temp_df[col].mode()[0], inplace=True)

if impute_cols:
    print(f"--- 7. Imputed columns (<20% NA): {impute_cols} ---")
    print(f"Missing values remaining: {temp_df.isnull().sum().sum()}")
else:
    print("--- 7. No imputation required (No columns with 0% < NA% < 20%) ---")
print("-" * 50)

# --- Feature Preparation for Numerical Steps ---
X_num = temp_df[numerical_cols].copy()
Y = temp_df['Price']

# 8. Remove the outliers (using Z-score > 3)
z_scores = X_num.apply(zscore)
outlier_rows = (z_scores.abs() > 3).any(axis=1)

X_clean = X_num[~outlier_rows]
Y_clean = Y[~outlier_rows]

print(f"--- 8. Outlier Removal (Z-score > 3) ---")
print(f"Original rows: {len(X_num)}, Rows after removal: {len(X_clean)}")
print(f"Rows removed: {len(X_num) - len(X_clean)}")
print("-" * 50)

# 2. Split the dataset into train and test sets & 3. check shape
X_train, X_test, Y_train, Y_test = train_test_split(X_clean, Y_clean, test_size=0.3, random_state=42)

print("--- 2 & 3. Train/Test Split and Shape Check ---")
print(f"X_train shape: {X_train.shape}")
print(f"X_test shape: {X_test.shape}")
print("-" * 50)

# 4. Perform scaling in the data using Standard Scaler
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
X_scaled_df = pd.DataFrame(X_train_scaled, columns=X_train.columns)

print("--- 4. Standard Scaling Performed on Training Data ---")
print(f"X_train_scaled (first 5 rows):\n{X_scaled_df.head()}")
print("-" * 50)

# 9. Use sklearn variance threshold to find the constant features and 10. Remove features with low variance
# A constant feature has a variance of 0.
sel_constant = VarianceThreshold(threshold=0)
sel_constant.fit(X_train)
constant_zero_var = X_train.columns[~sel_constant.get_support()].tolist()

# Remove features with low variance (threshold < 0.01 on scaled data)
sel_low_var = VarianceThreshold(threshold=0.01)
sel_low_var.fit(X_train_scaled)

features_to_keep = X_train.columns[sel_low_var.get_support()]
constant_features = X_train.columns[~sel_low_var.get_support()].tolist()
X_train_var = X_train_scaled[:, sel_low_var.get_support()]

print("--- 9. Constant Features (Variance = 0) ---")
print(constant_zero_var)

print("--- 10. Features with Low Variance (Threshold < 0.01) Removed ---")
print(f"Features removed: {constant_features}")
print(f"New X_train shape: {X_train_var.shape}")
print("-" * 50)

# Update feature set for next steps
X_train_df = pd.DataFrame(X_train_var, columns=features_to_keep)

# 13. Apply Pearson Correlation Coefficient/Spearman’s rank coefficient and find Correlation-Matrix with Heatmap
corr_matrix = X_train_df.corr(method='pearson')

plt.figure(figsize=(14, 12))
sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap='coolwarm', cbar=True)
plt.title('Pearson Correlation Matrix of Features')
plt.show() # Display plot in Colab

print("--- 13. Correlation Matrix (Pearson) and Heatmap Generated (See Plot Above) ---")
print("-" * 50)

# 11. Remove highly correlated features (e.g., correlation > 0.9)
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
cols_to_drop_corr = [column for column in upper.columns if any(upper[column].abs() > 0.9)]

X_train_corr = X_train_df.drop(columns=cols_to_drop_corr)

print(f"--- 11. Highly Correlated Features (r > 0.9) Removed ---")
print(f"Features removed: {cols_to_drop_corr}")
print(f"New X_train shape: {X_train_corr.shape}")
print("-" * 50)

# 12. Perform Univariate feature selection (SelectKBest, SelectPercentile)
X_train_final = X_train_corr.values
Y_train_final = Y_train.values

# SelectKBest (selecting 5 best features)
selector_kbest = SelectKBest(score_func=f_regression, k=5)
selector_kbest.fit(X_train_final, Y_train_final)
kbest_features = X_train_corr.columns[selector_kbest.get_support()].tolist()

# SelectPercentile (selecting top 50% features)
selector_percentile = SelectPercentile(score_func=f_regression, percentile=50)
selector_percentile.fit(X_train_final, Y_train_final)
percentile_features = X_train_corr.columns[selector_percentile.get_support()].tolist()

print("--- 12. Univariate Feature Selection (f_regression score) ---")
print(f"SelectKBest (k=5) Features: {kbest_features}")
print(f"SelectPercentile (50%) Features: {percentile_features}")
print("-" * 50)

# 14. Apply Principal Component Analysis (PCA) for matrix factorization
pca = PCA(n_components=5) # Example: retaining 5 principal components
X_train_pca = pca.fit_transform(X_train_final)
explained_variance_ratio = pca.explained_variance_ratio_

print("--- 14. Principal Component Analysis (PCA) ---")
print(f"Original feature count: {X_train_final.shape[1]}")
print(f"New PCA feature count (n=5): {X_train_pca.shape[1]}")
print("Explained Variance Ratio by components:")
print(explained_variance_ratio.round(4))
print(f"Total variance explained by 5 components: {explained_variance_ratio.sum():.4f}")
print("-" * 50)

# 15. Apply Linear Discriminant Analysis (LDA) to perform feature extraction
# LDA requires a categorical target. We create a 3-class target from 'Price'.
Y_class = pd.qcut(Y_clean, q=3, labels=[0, 1, 2]).values
X_train_lda, X_test_lda, Y_train_lda, Y_test_lda = train_test_split(X_clean, Y_class, test_size=0.3, random_state=42)

# Scale the features (using the same feature subset as the final X_train_corr)
X_train_lda_scaled = scaler.fit_transform(X_train_lda[X_train_corr.columns])

# The number of components in LDA is min(n_classes - 1, n_features)
n_components_lda = min(len(np.unique(Y_train_lda)) - 1, X_train_lda_scaled.shape[1])

lda = LinearDiscriminantAnalysis(n_components=n_components_lda)
X_train_lda_features = lda.fit_transform(X_train_lda_scaled, Y_train_lda)

print("--- 15. Linear Discriminant Analysis (LDA) ---")
print(f"Original feature count: {X_train_lda_scaled.shape[1]}")
print(f"LDA components (n_classes-1): {n_components_lda}")
print(f"New LDA feature count: {X_train_lda_features.shape[1]}")
print("LDA Explained Variance (Discriminability):")
print(lda.explained_variance_ratio_.round(4))
print("-" * 50)


#3


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

# 1. Read CSV data into pandas dataframe object
df = pd.read_csv('Toyato - Toyato.csv')

# --- Necessary Preprocessing (Based on previous analysis) ---
# Impute 'Doors' (12% missing) with mean and drop 'Mfr_Guarantee' (46% missing).
df['Doors'].fillna(df['Doors'].mean(), inplace=True)
df.drop(columns=['Mfr_Guarantee'], inplace=True)

# Select only the clean numerical features for both regression tasks
numerical_features = ['Age', 'KM', 'HP', 'Quarterly_Tax', 'Weight', 'Guarantee_Period']
target_variable = 'Price'

# Create the clean numerical subset for modeling
df_model = df[numerical_features + [target_variable]]

# Remove outliers using a simple Z-score filter on the target (Price) for cleaner models
z_scores_price = np.abs(zscore(df_model[target_variable]))
df_model = df_model[z_scores_price < 3]

print("--- Preprocessing Done: Cleaned Numerical Dataset Ready ---")

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from scipy.stats import zscore

# 1. Read CSV data into pandas dataframe object
df = pd.read_csv('Toyato - Toyato.csv')

# 2. Do necessary preprocessing
# Impute 'Doors' (12% missing) with mean and drop 'Mfr_Guarantee' (46% missing).
df['Doors'].fillna(df['Doors'].mean(), inplace=True)
df.drop(columns=['Mfr_Guarantee'], inplace=True)

# Select clean numerical features
numerical_features = ['Age', 'KM', 'HP', 'Quarterly_Tax', 'Weight', 'Guarantee_Period']
target_variable = 'Price'

# Create the clean numerical subset for modeling
df_model = df[numerical_features + [target_variable]].copy()

# Remove outliers (Z-score < 3 on Price)
z_scores_price = np.abs(zscore(df_model[target_variable]))
df_model = df_model[z_scores_price < 3].copy()

print("--- Preprocessing Done: Cleaned Numerical Dataset Ready ---")

# --- SIMPLE LINEAR REGRESSION (SLR) ---

# 3. Choose independent variable (X) and dependent variable (Y)
X_slr = df_model[['Age']] # Independent: Age
Y_slr = df_model['Price'] # Dependent: Price

# Split the dataset
X_train_slr, X_test_slr, Y_train_slr, Y_test_slr = train_test_split(
    X_slr, Y_slr, test_size=0.3, random_state=42
)

# Perform scaling
scaler_slr = StandardScaler()
X_train_slr_scaled = scaler_slr.fit_transform(X_train_slr)
X_test_slr_scaled = scaler_slr.transform(X_test_slr)

# Train the model
slr_model = LinearRegression()
slr_model.fit(X_train_slr_scaled, Y_train_slr)

# 4. Find the b0 and b1 values
b0_slr = slr_model.intercept_
b1_slr = slr_model.coef_[0]

print("\n--- SIMPLE LINEAR REGRESSION (Age vs Price) ---")
print(f"Y-intercept (b0): {b0_slr:.2f}")
print(f"Coefficient (b1): {b1_slr:.2f}")
print(f"Y_predicted = {b0_slr:.2f} + {b1_slr:.2f} * X (Scaled Age)")

# 5. Find the Ypredicted
Y_pred_slr = slr_model.predict(X_test_slr_scaled)

# 5. Calculate the SSE (Sum of Squared Error)
sse_slr = np.sum((Y_test_slr - Y_pred_slr) ** 2)
print(f"5. Sum of Squared Error (SSE): {sse_slr:.2f}")

# 6. Calculate the RMSE (Root Mean Square Error) value (CORRECTED)
mse_slr = mean_squared_error(Y_test_slr, Y_pred_slr)
rmse_slr = np.sqrt(mse_slr)
print(f"6. Root Mean Square Error (RMSE): {rmse_slr:.2f}")

# 7. Calculate the coefficient of determination (r2) r-square
r2_slr = r2_score(Y_test_slr, Y_pred_slr)
print(f"7. Coefficient of Determination (R^2): {r2_slr:.4f}")

# 8. Plot regression line along with the given data points
plt.figure(figsize=(10, 6))
plt.scatter(X_test_slr, Y_test_slr, color='blue', label='Actual Data Points')
plt.plot(X_test_slr, Y_pred_slr, color='red', linewidth=2, label='Regression Line')
plt.title('SLR: Price vs Age')
plt.xlabel('Age')
plt.ylabel('Price')
plt.legend()
plt.show()

# 9. Predict the output for a given input value
new_age = 50 # Example input: Age = 50 months
new_age_scaled = scaler_slr.transform([[new_age]])
predicted_price = slr_model.predict(new_age_scaled)[0]

print(f"9. Predicted Price for Age={new_age} months: {predicted_price:.2f}")

# --- MULTIPLE LINEAR REGRESSION (MLR) ---

# 3. Choose independent variables (X) and dependent variable (Y)
X_mlr = df_model[['Age', 'KM', 'HP', 'Weight', 'Quarterly_Tax']]
Y_mlr = df_model['Price']

# Split the dataset
X_train_mlr, X_test_mlr, Y_train_mlr, Y_test_mlr = train_test_split(
    X_mlr, Y_mlr, test_size=0.3, random_state=42
)

# Perform scaling (Standard Scaler)
scaler_mlr = StandardScaler()
X_train_mlr_scaled = scaler_mlr.fit_transform(X_train_mlr)
X_test_mlr_scaled = scaler_mlr.transform(X_test_mlr)

# Train the model
mlr_model = LinearRegression()
mlr_model.fit(X_train_mlr_scaled, Y_train_mlr)

# 4. Print values of y-intercept and independent variable coefficients
print("\n--- MULTIPLE LINEAR REGRESSION ---")
print(f"Y-intercept: {mlr_model.intercept_:.2f}")
print("Coefficients for Independent Variables:")
for feature, coef in zip(X_mlr.columns, mlr_model.coef_):
    print(f"  {feature}: {coef:.2f}")

# 5. Find the Ypred
Y_pred_mlr = mlr_model.predict(X_test_mlr_scaled)

# 6. Calculate the SSE and RMSE value
sse_mlr = np.sum((Y_test_mlr - Y_pred_mlr) ** 2)
print(f"\n6. Sum of Squared Error (SSE): {sse_mlr:.2f}")

# 6. Calculate RMSE (CORRECTED)
mse_mlr = mean_squared_error(Y_test_mlr, Y_pred_mlr)
rmse_mlr = np.sqrt(mse_mlr)
print(f"6. Root Mean Square Error (RMSE): {rmse_mlr:.2f}")

# 7. Calculate the coefficient of determination (r2) r-square
r2_mlr = r2_score(Y_test_mlr, Y_pred_mlr)
print(f"7. Coefficient of Determination (R^2): {r2_mlr:.4f}")

# 8. Plot the scatter graph of Yactual and Ypredicted
plt.figure(figsize=(8, 6))
plt.scatter(Y_test_mlr, Y_pred_mlr, color='purple')
plt.plot([Y_test_mlr.min(), Y_test_mlr.max()], [Y_test_mlr.min(), Y_test_mlr.max()], 'r--', lw=2)
plt.title('MLR: Actual Price vs Predicted Price')
plt.xlabel('Actual Price')
plt.ylabel('Predicted Price')
plt.grid(True)
plt.show()

# 9. Predict the output for a given input values
# New values (must be in the same order and scaled):
new_data = pd.DataFrame([[45, 60000, 100, 1150, 150]],
                        columns=X_mlr.columns)
new_data_scaled = scaler_mlr.transform(new_data)
predicted_price_mlr = mlr_model.predict(new_data_scaled)[0]

print("\n9. Predicted Output for New Input:")
print(f"Input: Age=45, KM=60000, HP=100, Weight=1150, Quarterly_Tax=150")
print(f"Predicted Price: {predicted_price_mlr:.2f}")


#4

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Perceptron
from sklearn.metrics import accuracy_score

# Configuration
RANDOM_STATE = 42
MAX_EPOCHS = 100
LEARNING_RATE = 0.1

# Define column names for haberman.csv
column_names = ['Age', 'Operation_Year', 'Axil_Nodes', 'Survival_Status']

# 1. Read the dataset and do necessary preprocessing
df = pd.read_csv('haberman.csv', header=None, names=column_names)

# 1a. Encoding Categorical to Numerical (Target)
df['Survival_Status'] = df['Survival_Status'].map({1: 1, 2: 0})
Y = df['Survival_Status'].values
X = df[['Age', 'Operation_Year', 'Axil_Nodes']].values

# Split data
X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.3, random_state=RANDOM_STATE
)

# Scale features (essential for Perceptron convergence)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)

# Initialize Perceptron model for monitoring convergence
ppn = Perceptron(
    eta0=LEARNING_RATE,
    random_state=RANDOM_STATE,
    shuffle=True,
    max_iter=1,
    warm_start=True,
    tol=None
)

# Variables to store convergence data
error_history = []
min_error = float('inf')
best_epoch = 0
best_weights = None

# 2. Determine the number of epochs which have minimum error
for epoch in range(1, MAX_EPOCHS + 1):
    ppn.fit(X_train_scaled, Y_train)

    # Calculate misclassification error on the training set
    Y_train_pred = ppn.predict(X_train_scaled)
    accuracy = accuracy_score(Y_train, Y_train_pred)
    misclassification_error = 1.0 - accuracy
    error_history.append(misclassification_error)

    # Check for minimum error
    if misclassification_error < min_error:
        min_error = misclassification_error
        best_epoch = epoch
        best_weights = (ppn.coef_.flatten().tolist(), ppn.intercept_.tolist())

    # Stop if minimum error is 0.0
    if min_error <= 0.0:
        break

# 3. Display final weight of each attribute which have minimum error.
final_weights = best_weights[0]
final_bias = best_weights[1][0]
feature_names = ['Age', 'Operation_Year', 'Axil_Nodes']

print("\n--- 3. Final Weights (at Minimum Error) ---")
for name, weight in zip(feature_names, final_weights):
    print(f"Weight for {name}: {weight:.4f}")
print(f"Bias/Intercept: {final_bias:.4f}")

# 4. Plot the convergence of error for each iteration
plt.figure(figsize=(10, 6))
plt.plot(range(1, len(error_history) + 1), error_history, marker='o', linestyle='-', color='blue')
plt.axvline(x=best_epoch, color='red', linestyle='--', label=f'Min Error Epoch ({best_epoch})')
plt.title('Perceptron Error Convergence per Epoch (Haberman Data)')
plt.xlabel('Epoch')
plt.ylabel('Misclassification Error (1 - Accuracy)')
plt.grid(True)
plt.legend()
plt.show()


#5

import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from tqdm import tqdm
import matplotlib.pyplot as plt

# Configuration
RANDOM_STATE = 42
NUM_EPOCHS = 100
LEARNING_RATE = 0.001
TARGET_COLUMN = 'Thal' # Target for multi-class classification

# --- 1. Load the dataset and handle missing values ---
df = pd.read_csv('Heart.csv')

# A. Handle Missing Values (Imputation)
for col in df.columns:
    if df[col].dtype in ['int64', 'float64']:
        # Fill numerical with mean
        df[col].fillna(df[col].mean(), inplace=True)
    else:
        # Fill categorical with mode
        df[col].fillna(df[col].mode()[0], inplace=True)

# Identify Features
numerical_features = ['RestBP', 'Chol', 'MaxHR', 'Oldpeak']
categorical_features = ['Fbs', 'RestECG', 'ExAng', 'Slope', 'Ca']
all_features = numerical_features + categorical_features

# B. Normalize numerical features using Min-Max Scaling
scaler = MinMaxScaler()
df[numerical_features] = scaler.fit_transform(df[numerical_features])

# C. Encode categorical features using Label Encoding
le_features = LabelEncoder()
for col in categorical_features:
    # Convert to string just in case, then encode
    df[col] = le_features.fit_transform(df[col].astype(str))

# Encode target variable
le_target = LabelEncoder()
df[TARGET_COLUMN] = le_target.fit_transform(df[TARGET_COLUMN].astype(str))
NUM_CLASSES = len(le_target.classes_)
INPUT_SIZE = len(all_features)

# D. Prepare X and Y
X = df[all_features].values
Y = df[TARGET_COLUMN].values

# E. Split the dataset into 75% training and 25% testing
X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.25, random_state=RANDOM_STATE
)

# Convert to PyTorch tensors
X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
Y_train_tensor = torch.tensor(Y_train, dtype=torch.long)
Y_test_tensor = torch.tensor(Y_test, dtype=torch.long)


# --- Design Multi-Layer Perceptron (MLP) using torch.nn.Module ---
class MLPClassifier(nn.Module):
    def __init__(self, input_size, num_classes):
        super(MLPClassifier, self).__init__()

        # Input layer -> 1st Hidden layer (64 nodes)
        self.fc1 = nn.Linear(input_size, 64)

        # 1st Hidden layer -> 2nd Hidden layer (32 nodes)
        self.fc2 = nn.Linear(64, 32)

        # 2nd Hidden layer -> Output layer (num_classes)
        self.fc3 = nn.Linear(32, num_classes)

        # ReLU activation for hidden layers
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x) # Activation for H1
        x = self.fc2(x)
        x = self.relu(x) # Activation for H2
        x = self.fc3(x)
        return x # Outputting logits

model = MLPClassifier(INPUT_SIZE, NUM_CLASSES)

# Use CrossEntropyLoss as the loss function (implicitly includes Softmax)
criterion = nn.CrossEntropyLoss()

# Optimize using Adam optimizer
optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

# --- Train the model for 100 epochs ---
loss_history = []

print("--- Model Training Started (100 Epochs) ---")
for epoch in tqdm(range(NUM_EPOCHS)):
    # Forward pass
    outputs = model(X_train_tensor)
    loss = criterion(outputs, Y_train_tensor)

    # Backward and optimize
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    loss_history.append(loss.item())

# --- Evaluation and Visualization ---

# Plot training loss vs. number of iterations
plt.figure(figsize=(10, 6))
plt.plot(loss_history, label='Training Loss')
plt.title('Training Loss vs. Iterations')
plt.xlabel('Iteration (Epoch)')
plt.ylabel('Loss (CrossEntropyLoss)')
plt.grid(True)
plt.show()

# Compute predictions on the test set
model.eval() # Set model to evaluation mode
with torch.no_grad():
    Y_test_outputs = model(X_test_tensor)
    # Get the index (class) with the highest probability
    _, Y_pred_tensor = torch.max(Y_test_outputs, 1)

    Y_pred = Y_pred_tensor.numpy()
    Y_true = Y_test_tensor.numpy()

# Calculate performance metrics
cm = confusion_matrix(Y_true, Y_pred)
accuracy = accuracy_score(Y_true, Y_pred)
# Use 'weighted' average for multi-class metrics
precision = precision_score(Y_true, Y_pred, average='weighted', zero_division=0)
recall = recall_score(Y_true, Y_pred, average='weighted', zero_division=0)
f1 = f1_score(Y_true, Y_pred, average='weighted', zero_division=0)


print("\n--- Model Performance Evaluation ---")
print(f"Target Classes (Encoded): {le_target.classes_}")

print("\nConfusion Matrix:")
print(cm)

print("\nPerformance Metrics:")
print(f"Accuracy: {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f"F1-Score: {f1:.4f}")

# Interpretation of performance metrics
print("\nInterpretation of Performance Metrics:")
print(f"Accuracy ({accuracy:.4f}): The proportion of total samples that were correctly classified.")
print(f"Precision ({precision:.4f}): Measures the correctness of positive predictions.")
print(f"Recall ({recall:.4f}): Measures the ability of the model to find all positive samples.")
print(f"F1-Score ({f1:.4f}): Provides a single score that balances both Precision and Recall.")


#6


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score, davies_bouldin_score

# 1. Load the given dataset
df = pd.read_csv('Solar.csv')

# Clean up column names based on dataset structure
df.columns = ['Latitude', 'Longitude', 'Altitude', 'min_Temp', 'Max_Temp', 'Sunshine_Hour', 'Solar_Radiation']
print("--- 1. Data Loaded ---")

# 2. Conduct the pre-processing steps
# No missing values found in the data, but the imputation structure is kept for robustness.

# 3. Remove the target variable
TARGET_COL = 'Solar_Radiation'
X = df.drop(columns=[TARGET_COL])
print(f"--- 3. Target Variable '{TARGET_COL}' Removed ---")

# Normalization (Min-Max Scaling)
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)
X_scaled_df = pd.DataFrame(X_scaled, columns=X.columns)
print("Data normalized using Min-Max Scaling.")

# --- Visualization Setup (PCA for 2D Plotting) ---
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)
pca_df = pd.DataFrame(X_pca, columns=['PC1', 'PC2'])

# 4. Plot the data points using scatter plots (using PCA components)
plt.figure(figsize=(8, 6))
plt.scatter(pca_df['PC1'], pca_df['PC2'], s=30)
plt.title('4. Data Points (Reduced to 2D via PCA)')
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.grid(True)
plt.show()
print("--- 4. Data Scatter Plot Displayed ---")


# 6. Determine the optimal number of clusters using a dendrogram.
print("--- 6. Dendrogram for Optimal Cluster Determination ---")
# Use 'single' method as requested
linked = linkage(X_scaled, method='single')

plt.figure(figsize=(15, 7))
dendrogram(linked,
           orientation='top',
           distance_sort='descending',
           show_leaf_counts=True)
plt.title('6. Hierarchical Clustering Dendrogram (Single Linkage)')
plt.xlabel('Sample Index')
plt.ylabel('Distance')
plt.show()
print("Dendrogram Displayed.")

# Define range for cluster counting
n_clusters_range = [2, 3, 4, 5]
print(f"Testing cluster counts: {n_clusters_range}")

# Variables to store performance results
results = {'N_Clusters': [], 'Silhouette_Score': [], 'Davies_Bouldin_Index': []}
all_cluster_labels = {}

# 5, 8, 9, 10. Apply Clustering, Repeat, Measure Performance, and Plot Centroids
print("--- 5, 8, 9, 10. Clustering, Metrics, and Centroids ---")

plt.figure(figsize=(15, 12))
for i, n_clusters in enumerate(n_clusters_range):
    # 5 & 8. Apply Hierarchical Agglomerative Clustering
    agg_clustering = AgglomerativeClustering(n_clusters=n_clusters, linkage='single')
    cluster_labels = agg_clustering.fit_predict(X_scaled)

    # Store labels
    all_cluster_labels[f'Cluster_N_{n_clusters}'] = cluster_labels

    # 9. Measure clustering performance
    sil_score = silhouette_score(X_scaled, cluster_labels)
    db_index = davies_bouldin_score(X_scaled, cluster_labels)

    results['N_Clusters'].append(n_clusters)
    results['Silhouette_Score'].append(sil_score)
    results['Davies_Bouldin_Index'].append(db_index)

    # Calculate Centroids (mean of scaled features for each cluster)
    centroids_scaled = pd.DataFrame(X_scaled).groupby(cluster_labels).mean().values

    # Transform centroids back to PCA space for plotting
    centroids_pca = pca.transform(centroids_scaled)

    # 10. Plot the clustering output and cluster centroids (using PCA)
    ax = plt.subplot(2, 2, i + 1)
    ax.scatter(pca_df['PC1'], pca_df['PC2'], c=cluster_labels, cmap='viridis', s=50, alpha=0.6)
    ax.scatter(centroids_pca[:, 0], centroids_pca[:, 1], marker='X', s=200, c='red', label='Centroids')
    ax.set_title(f'N={n_clusters} Clusters (Single Linkage)\nSil: {sil_score:.3f}, DB: {db_index:.3f}')
    ax.set_xlabel('PC1')
    ax.set_ylabel('PC2')
    ax.legend()

plt.tight_layout()
plt.show()
print("Clustering Comparison Plots Displayed.")

# 7. Print Centroids and Labels (for N=3)
results_df = pd.DataFrame(results).set_index('N_Clusters')
print("\nClustering Performance Metrics:")
print(results_df)

centroids_n3 = pd.DataFrame(X_scaled).groupby(all_cluster_labels['Cluster_N_3']).mean()
centroids_n3.columns = X.columns
print("\nCluster Centroids (N=3, Scaled Features):")
print(centroids_n3)

print("\nCluster Labels (N=3, First 10):")
print(all_cluster_labels['Cluster_N_3'][:10])


#8

# Install the Self-Organizing Map library (REQUIRED)
!pip install minisom


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score
from minisom import MiniSom
from tqdm import tqdm

# Configuration
RANDOM_STATE = 42
TARGET_COLUMN = 'Thal'

# --- 1 & 2. Data Preprocessing and Loading ---
df = pd.read_csv('Heart.csv')

print("--- 1 & 2. Data Preprocessing and Loading ---")

# A. Handle Missing Values (Imputation)
for col in df.columns:
    if df[col].dtype in ['int64', 'float64']:
        # Fill numerical with mean (using .loc for robust assignment)
        df.loc[:, col] = df[col].fillna(df[col].mean())
    else:
        # Fill categorical with mode
        df.loc[:, col] = df[col].fillna(df[col].mode()[0])

# B. Encode categorical features
categorical_features = ['Fbs', 'RestECG', 'ExAng', 'Slope', 'Ca', 'Thal']
le = LabelEncoder()
for col in categorical_features:
    df.loc[:, col] = le.fit_transform(df[col].astype(str))

# C. Normalization (Min-Max Scaling)
numerical_features = ['RestBP', 'Chol', 'MaxHR', 'Oldpeak']
features_to_scale = numerical_features + [f for f in categorical_features if f != TARGET_COLUMN]

scaler = MinMaxScaler()
df_scaled = df[features_to_scale].copy()
X_scaled = scaler.fit_transform(df_scaled)
X = X_scaled
INPUT_LEN = X.shape[1]

# 3. Remove the target variable
print(f"3. Target variable '{TARGET_COLUMN}' removed. Features scaled.")
print("-" * 50)

# --- 4. Plot the datapoints using scatter plots (using PCA) ---
pca = PCA(n_components=2, random_state=RANDOM_STATE)
X_pca = pca.fit_transform(X)

plt.figure(figsize=(8, 6))
plt.scatter(X_pca[:, 0], X_pca[:, 1], s=30, cmap='viridis')
plt.title('4. Data Points (Reduced to 2D via PCA)')
plt.xlabel(f'Principal Component 1 ({pca.explained_variance_ratio_[0]*100:.1f}%)')
plt.ylabel(f'Principal Component 2 ({pca.explained_variance_ratio_[1]*100:.1f}%)')
plt.grid(True)
plt.show()
print("4. Data points scatter plot displayed.")
print("-" * 50)

# --- 5. Training Self-Organizing Map (Hybrid SOM-K-Means) ---
SOM_GRID_SIZE = 10
SOM_EPOCHS = 1000
SIGMA = 1.0
LEARNING_RATE = 0.5

print(f"--- 5. Training Self-Organizing Map ({SOM_GRID_SIZE}x{SOM_GRID_SIZE} Grid) ---")

som = MiniSom(
    x=SOM_GRID_SIZE,
    y=SOM_GRID_SIZE,
    input_len=INPUT_LEN,
    sigma=SIGMA,
    learning_rate=LEARNING_RATE,
    random_seed=RANDOM_STATE
)
som.random_weights_init(X)

# Training loop (CORRECTED to use som.winner and som.update correctly)
print(f"Training SOM for {SOM_EPOCHS} epochs...")
for i in tqdm(range(SOM_EPOCHS)):
    rand_i = np.random.randint(len(X))
    sample = X[rand_i] # Select the 1D sample
    bmu_coords = som.winner(sample) # Get the winner's (x, y) coordinates
    som.update(sample, bmu_coords, i, SOM_EPOCHS) # Correct update call

som_weights = som.get_weights().reshape(-1, INPUT_LEN)
print("SOM training complete. Weights extracted.")
print("-" * 50)


# --- 6, 7, 8, 9. Repeat K-Means on SOM Weights and Measure Performance ---
n_clusters_range = [2, 3, 4, 5]
optimal_score = -1
optimal_k = 0
results = {'N_Clusters': [], 'Silhouette_Score': [], 'DB_Index': []}
cluster_outputs = {}

plt.figure(figsize=(15, 12))
print("--- 6, 7, 8, 9. K-Means Clustering on SOM Weights and Evaluation ---")

for i, n_clusters in enumerate(n_clusters_range):
    # Apply K-Means to the SOM weights (to get final cluster centers)
    kmeans = KMeans(n_clusters=n_clusters, random_state=RANDOM_STATE, n_init='auto')
    kmeans.fit(som_weights)

    # Assign data points to the cluster of their BMU's cluster
    neuron_cluster_labels = kmeans.labels_
    data_cluster_labels = np.array([neuron_cluster_labels[som.winner(x)[0] * SOM_GRID_SIZE + som.winner(x)[1]] for x in X])

    # Measure clustering performance on the data points
    sil_score = silhouette_score(X, data_cluster_labels)
    db_index = davies_bouldin_score(X, data_cluster_labels)

    results['N_Clusters'].append(n_clusters)
    results['Silhouette_Score'].append(sil_score)
    results['DB_Index'].append(db_index)

    # Store output for optimal determination
    cluster_outputs[n_clusters] = {'labels': data_cluster_labels, 'centroids': kmeans.cluster_centers_}

    # Determine Optimal N (Max Silhouette Score)
    if sil_score > optimal_score:
        optimal_score = sil_score
        optimal_k = n_clusters

    # --- 7 & 10. Plot the cluster labels (for all N) ---
    ax = plt.subplot(2, 2, i + 1)

    # Plot data points coloured by the final cluster label
    scatter = ax.scatter(X_pca[:, 0], X_pca[:, 1], c=data_cluster_labels, cmap='viridis', s=30, alpha=0.7)

    # Transform K-Means centroids to PCA space for plotting
    centroids_pca = pca.transform(kmeans.cluster_centers_)
    ax.scatter(centroids_pca[:, 0], centroids_pca[:, 1], marker='X', s=200, c='red', edgecolor='black', label='Centroids')

    ax.set_title(f'N={n_clusters} Clusters (SOM-KMeans)\nSil: {sil_score:.3f}, DB: {db_index:.3f}')
    ax.set_xlabel('PC1')
    ax.set_ylabel('PC2')
    ax.legend()

plt.tight_layout()
plt.show()

print("--- 7 & 10. Clustering Comparison Plots Displayed ---")
print(f"\nOptimal Number of Clusters (Max Silhouette Score): N={optimal_k}")

# Print performance table
metrics_df = pd.DataFrame(results).set_index('N_Clusters')
print("\nClustering Performance Metrics:")
print(metrics_df)

# Print Centroids and Labels for Optimal N
centroids_opt_df = pd.DataFrame(cluster_outputs[optimal_k]['centroids'], columns=df_scaled.columns)
print(f"\nCluster Centroids (N={optimal_k}, Scaled Features):")
print(centroids_opt_df)

labels_opt = cluster_outputs[optimal_k]['labels']
print(f"\nCluster Labels (N={optimal_k}, First 10):")
print(labels_opt[:10])


#9


!pip install mlxtend


import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules
import numpy as np

# 1. Load the dataset
df = pd.read_csv('Shop1.csv')

# --- Data Preprocessing: Convert CSV to One-Hot Encoded Format ---
transactions = []

# Process the 'Item' column where items are comma-separated
for index, row in df.iterrows():
    item_string = row.get('Item')

    # Handle NaN values
    if pd.isna(item_string):
        continue

    # Split the string and clean up whitespace
    items = [item.strip() for item in str(item_string).split(',')]

    # Filter out empty strings if the split results in them (e.g., if there were double commas)
    items = [item for item in items if item]

    if items:
        transactions.append(items)

# Convert the list of transactions into a one-hot encoded DataFrame
te = TransactionEncoder()
te_ary = te.fit(transactions).transform(transactions)
df_oht = pd.DataFrame(te_ary, columns=te.columns_)
print("URK23CS7029")
print("--- 1. Data Loading and Preprocessing Complete ---")
print(f"Total Transactions: {len(transactions)}")
print(f"Total Unique Items: {len(df_oht.columns)}")
print("-" * 70)

# 2. Identify frequent itemsets (Support threshold = 8% / 0.08)
min_support = 0.08
frequent_itemsets = apriori(df_oht, min_support=min_support, use_colnames=True)

print("--- 2. Frequent Itemsets (Support >= 8%) ---")
print(f"Number of Frequent Itemsets found: {len(frequent_itemsets)}")
print(frequent_itemsets.sort_values(by='support', ascending=False).head())
print("-" * 70)

# 3. Generate association rules (Confidence threshold = 50% / 0.5)
min_confidence = 0.50
rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=min_confidence)

# 4. Extract rules with higher confidence values (Sort by confidence)
rules_sorted = rules.sort_values(by='confidence', ascending=False)

print(f"--- 3 & 4. Association Rules (Confidence >= 50%) ---")
print(f"Number of Association Rules generated: {len(rules_sorted)}")

# Display the top rules, including support, confidence, and lift
print("\nTop 10 Rules by Confidence:")
print(rules_sorted[['antecedents', 'consequents', 'support', 'confidence', 'lift']].head(10))
print("URK23CS7050")

#10

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
)

# Configuration
RANDOM_STATE = 42

# 1. Read the dataset and do necessary preprocessing
df = pd.read_csv('income (1).csv')

print("--- 1. Data Preprocessing & Setup ---")

# --- Identify features and check for non-numeric/missing data ---
# Based on the snippet, columns are: age, fnlwgt, education_num, capital_gain, capital_loss, hours_per_week, income_level
# Assuming the data is entirely numerical, but check for any non-finite values (NaN/Inf)
print("Missing values per column (initial check):")
print(df.isnull().sum())

# Data Imputation: Fill missing values with the mean for numerical columns
for col in df.columns:
    if df[col].dtype in ['int64', 'float64']:
        # If any missing data exists, fill with mean
        if df[col].isnull().any():
            df[col].fillna(df[col].mean(), inplace=True)
            print(f"Imputed missing values in {col} with mean.")

# Since the column names suggest they are all numerical, no categorical encoding is performed.

# 2. Choose independent variable (X) and dependent variable (Y)
X = df.drop(columns=['income_level'])
Y = df['income_level']

# Split the data
X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.3, random_state=RANDOM_STATE
)

# Scale the data (Good practice for most ensemble methods, especially if features have different scales)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
print(f"\nTraining set size: {X_train.shape[0]}, Test set size: {X_test.shape[0]}")
print("-" * 50)


# --- Helper Function for Training and Evaluation ---
def train_and_evaluate_model(model_class, parameters_list, X_train, X_test, Y_train, Y_test, algorithm_name):
    """Trains multiple models, finds the best one, and evaluates performance."""

    results = []
    best_score = -1
    best_model = None

    print(f"\n--- {algorithm_name} Training & Evaluation ---")

    for params in parameters_list:
        # Create and train the model
        model = model_class(**params, random_state=RANDOM_STATE)
        model.fit(X_train, Y_train)

        # Predict
        Y_pred = model.predict(X_test)

        # Calculate metrics
        accuracy = accuracy_score(Y_test, Y_pred)
        precision = precision_score(Y_test, Y_pred, average='binary', zero_division=0)
        recall = recall_score(Y_test, Y_pred, average='binary', zero_division=0)
        f1 = f1_score(Y_test, Y_pred, average='binary', zero_division=0)
        cm = confusion_matrix(Y_test, Y_pred)

        # Store results
        results.append({
            'params': params,
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'confusion_matrix': cm
        })

        # Track the best model based on accuracy
        if accuracy > best_score:
            best_score = accuracy
            best_model = model
            best_params = params
            best_y_pred = Y_pred
            best_cm = cm

    # Display results for all parameters (Step 5)
    print("5. Performance for Different Parameter Sets:")
    for res in results:
        print(f"\n- Parameters: {res['params']}")
        print(f"  Accuracy: {res['accuracy']:.4f}, Precision: {res['precision']:.4f}, Recall: {res['recall']:.4f}, F1-Score: {res['f1_score']:.4f}")

    # Display best model results (Step 4 & 5)
    print("\n--- Best Model Summary ---")
    print(f"4. Best Parameters: {best_params}")
    print(f"   Best Model Accuracy: {best_score:.4f}")
    print("\n5. Confusion Matrix for Best Model:")
    print(best_cm)
    print("-" * 50)

    return best_y_pred

# --- RANDOM FOREST CLASSIFIER ---
# 3. Create different model of Random Forest using different parameters (Minimum of 4)
rf_parameters = [
    {'n_estimators': 50, 'max_depth': 5, 'min_samples_split': 10},
    {'n_estimators': 100, 'max_depth': 10, 'min_samples_split': 5},
    {'n_estimators': 150, 'max_depth': None, 'min_samples_split': 2},
    {'n_estimators': 200, 'max_depth': 8, 'min_samples_split': 10}
]

Y_pred_rf = train_and_evaluate_model(
    RandomForestClassifier,
    rf_parameters,
    X_train_scaled,
    X_test_scaled,
    Y_train,
    Y_test,
    "Random Forest"
)


# --- ADABOOST CLASSIFIER ---
# 3. Create different model of AdaBoost using different parameters (Minimum of 4)
ada_parameters = [
    {'n_estimators': 50, 'learning_rate': 0.1},
    {'n_estimators': 100, 'learning_rate': 0.5},
    {'n_estimators': 200, 'learning_rate': 1.0},
    {'n_estimators': 500, 'learning_rate': 0.05}
]

Y_pred_ada = train_and_evaluate_model(
    AdaBoostClassifier,
    ada_parameters,
    X_train_scaled,
    X_test_scaled,
    Y_train,
    Y_test,
    "AdaBoost"
)


