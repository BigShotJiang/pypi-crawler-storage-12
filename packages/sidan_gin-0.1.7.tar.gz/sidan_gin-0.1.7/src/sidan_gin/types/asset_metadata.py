from typing import Any, Dict

AssetMetadata = Dict[str, Any]
