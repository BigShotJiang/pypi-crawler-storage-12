# flake8: noqa

from .wallet import Wallet
