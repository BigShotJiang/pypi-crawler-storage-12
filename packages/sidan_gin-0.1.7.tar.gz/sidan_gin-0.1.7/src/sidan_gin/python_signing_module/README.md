# python-signing-module
Python signing module, implementation in Rust, ported over to C++, then to Python.
