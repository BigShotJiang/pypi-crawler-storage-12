# NieMarkov
Niema's Python implementation of Markov chains
