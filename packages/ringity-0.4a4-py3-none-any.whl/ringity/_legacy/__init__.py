"""
Legacy subpackage. This folder contains legacy code that will be removed in
future versions of ringity. A module starts with ``legacy_[MODULNAME].py`` containing functions
that used to be in a module with the name [MODULNAME].py
"""
