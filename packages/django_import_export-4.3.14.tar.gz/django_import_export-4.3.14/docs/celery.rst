.. _celery:

===========
Using celery
===========

You can use one of the third-party applications to process long imports and exports in Celery:

* `django-import-export-celery <https://github.com/auto-mat/django-import-export-celery>`_ (`PyPI <https://pypi.org/project/django-import-export-celery>`_)
* `django-import-export-extensions <https://github.com/saritasa-nest/django-import-export-extensions>`_ (`PyPI <https://pypi.org/project/django-import-export-extensions>`_)
