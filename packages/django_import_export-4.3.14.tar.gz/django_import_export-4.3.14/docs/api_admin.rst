=====
Admin
=====

For instructions on how to use the models and mixins in this module, please
refer to :ref:`admin-integration`.

.. automodule:: import_export.admin
   :members:
