=======
Results
=======

.. currentmodule:: import_export.results

Result
------

.. autoclass:: import_export.results.Result
   :members:

RowResult
---------

.. autoclass:: import_export.results.RowResult
   :members:

InvalidRow
---------

.. autoclass:: import_export.results.InvalidRow
   :members:
