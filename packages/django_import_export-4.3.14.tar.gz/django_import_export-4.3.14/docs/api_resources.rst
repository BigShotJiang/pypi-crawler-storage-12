=========
Resources
=========

Resource
--------

.. autoclass:: import_export.resources.Resource
   :members:

ModelResource
-------------

.. autoclass:: import_export.resources.ModelResource
   :members:


ResourceOptions (Meta)
----------------------

.. autoclass:: import_export.options.ResourceOptions
   :members:

modelresource_factory
---------------------

.. automethod:: import_export.resources.modelresource_factory
