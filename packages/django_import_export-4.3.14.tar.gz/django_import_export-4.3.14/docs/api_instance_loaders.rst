================
Instance loaders
================

.. module:: import_export.instance_loaders

.. autoclass:: BaseInstanceLoader

.. autoclass:: ModelInstanceLoader

.. autoclass:: CachedInstanceLoader
