==========
Exceptions
==========

.. currentmodule:: import_export.exceptions

ImportExportError
-----------------

.. autoclass:: import_export.exceptions.ImportExportError
   :members:

FieldError
----------

.. autoclass:: import_export.exceptions.FieldError
   :members:

ImportError
-----------

.. autoclass:: import_export.exceptions.ImportError
   :members:
