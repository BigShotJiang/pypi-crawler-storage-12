---
name: Question
about: Do you have a general question?
title: ''
labels: question
assignees: ''

---

<!--- Welcome to django-import-export  -->
<!--- Your issue may already be reported!
Please search on the [issue tracker](../) before creating one. -->
<!--- Additionally, you can either search or ask you question on [Stack Overflow tagged with `django-import-export`](https://stackoverflow.com/questions/tagged/django-import-export) -->
<!--- If you would still like to create a question on github, please do so and remember that the more details you give, the more likely your question will be answered. -->
