# Global project configuration for dvt-core
# This defines the name of the global/internal project namespace

PROJECT_NAME = "dbt"  # Keep as "dbt" for compatibility with adapter ecosystem
