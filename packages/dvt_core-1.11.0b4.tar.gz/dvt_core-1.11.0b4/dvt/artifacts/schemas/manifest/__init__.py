# alias to latest
from dvt.artifacts.schemas.manifest.v12.manifest import *  # noqa
