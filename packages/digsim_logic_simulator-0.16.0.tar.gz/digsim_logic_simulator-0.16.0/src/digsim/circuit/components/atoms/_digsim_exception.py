# Copyright (c) Fredrik Andersson, 2023-2025
# All rights reserved

"""The digsim exception base"""


class DigsimException(Exception):
    """The digsim exception base class"""
