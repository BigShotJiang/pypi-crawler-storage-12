# Copyright (c) Fredrik Andersson, 2023-2025
# All rights reserved

"""All classes within digsim.app.model namespace"""

from ._model import AppModel  # noqa: F401
