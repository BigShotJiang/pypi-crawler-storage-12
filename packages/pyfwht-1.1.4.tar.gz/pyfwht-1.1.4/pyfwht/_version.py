"""Version information for pyfwht package."""

__version__ = "1.1.4"
