#ifndef COUNTERDEF_H
#define COUNTERDEF_H

namespace gambatte {

enum { disabled_time = 0xfffffffful };

}

#endif
