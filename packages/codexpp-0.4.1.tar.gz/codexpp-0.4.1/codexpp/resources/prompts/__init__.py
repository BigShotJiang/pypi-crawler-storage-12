"""Prompt templates shipped with Codexpp."""

