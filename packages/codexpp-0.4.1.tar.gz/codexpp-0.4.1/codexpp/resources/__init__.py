"""Resource package containing default command and persona bundles."""

