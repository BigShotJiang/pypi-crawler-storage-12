print("Thank you for your interest, however, geondptinf is a licensed library available at https://geond.tech, this is a placegolder. You can use the freely available geondptfree instead, if you want to try out its funcionality.")
quit()
