#!/usr/bin/env python3
"""
Docuvert CLI entry point for python -m docuvert usage.
"""

from .cli import main

if __name__ == "__main__":
    main()
