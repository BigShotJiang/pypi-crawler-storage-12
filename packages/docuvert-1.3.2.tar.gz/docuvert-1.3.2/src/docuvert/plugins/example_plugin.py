
# This is an example of how a user could register a custom converter.
# The plugin would need to be installed in the same environment as Docuvert.

# TODO: Implement a proper plugin system, perhaps using entry_points.

def register_converters():
    """
    Registers custom converters.
    """
    # Example of registering a custom converter
    # from docuvert.core.converter_registry import register
    # from .my_custom_converter import MyCustomConverter
    #
    # register("custom_format", "another_format", MyCustomConverter)
    pass
