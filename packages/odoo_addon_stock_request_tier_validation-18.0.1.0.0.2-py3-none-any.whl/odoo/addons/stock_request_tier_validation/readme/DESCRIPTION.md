This module extends the functionality of Stock Requests and Stock
Request Orders to support a tier validation process.
