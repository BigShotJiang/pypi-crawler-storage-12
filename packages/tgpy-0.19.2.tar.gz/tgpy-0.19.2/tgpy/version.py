__version__ = '0.19.2'
IS_DEV_BUILD = False
COMMIT_HASH = None
