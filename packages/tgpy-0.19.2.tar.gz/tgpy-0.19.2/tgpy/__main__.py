from tgpy.main import main

main()
