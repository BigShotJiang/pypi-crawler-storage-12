"""Domain layer for BitAds Miner Scoring."""


