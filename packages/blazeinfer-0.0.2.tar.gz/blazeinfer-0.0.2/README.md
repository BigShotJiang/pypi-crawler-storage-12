<div align="center">

![# BlazeInfer](assets/logo.png)
A high-performance, light-weight llm inference framework.

</div>

<div align="center">

[![PyPI version](https://img.shields.io/pypi/v/blazeinfer.svg)](https://pypi.org/project/blazeinfer/)

</div>

--------------------------------------------------------------------------------

## About

## Features
- Optimized Attention Kernels

## Getting Started

## Acknowledgement
- [lite_llama](https://github.com/harleyszhang/lite_llama/tree/main)