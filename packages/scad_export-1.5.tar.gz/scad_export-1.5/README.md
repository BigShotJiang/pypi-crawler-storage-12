# SCAD Export

SCAD Export allows for automated and parallel export of OpenSCAD projects to separate files and folders. For usage and API documentation see the [SCAD Export Wiki](https://github.com/CharlesLenk/scad-export/wiki).
