from .dao_base_update import DAOBaseUpdate

class DAOBasePartialUpdate(DAOBaseUpdate):

    pass
