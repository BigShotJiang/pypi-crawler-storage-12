"""Models based on Torch library."""

__all__ = ["linear_model", "nn_models"]
