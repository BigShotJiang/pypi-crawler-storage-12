__version__ = "2025.11.16"
__prog__ = "webscout"
