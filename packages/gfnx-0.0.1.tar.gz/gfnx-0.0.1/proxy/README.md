# Proxy Network Training and Storage Instructions

## Usage

To train the proxy network using the specified configuration, run the following command:

```bash
python proxy/train_proxy.py --config-name amp
```
