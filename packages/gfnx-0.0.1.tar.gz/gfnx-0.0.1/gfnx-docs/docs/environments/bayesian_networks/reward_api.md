# Reward API Reference

## Priors

::: gfnx.reward.dag_prior

## Likelihoods

::: gfnx.reward.dag_likelihood

## Final reward for enviornment

::: gfnx.reward.dag