# Reward API Reference
 
::: gfnx.reward.ising