# Environment API Reference

## General sequence enviornmnet

::: gfnx.environment.sequence

## Bit Sequence environment

::: gfnx.environment.bitseq

## TFBind-8 environment

::: gfnx.environment.tfbind

## QM9 Small environment

::: gfnx.environment.qm9_small

## AMP environment

::: gfnx.environment.amp

## GFP environment

::: gfnx.environment.gfp