# Reward API Reference

# Bit Sequence reward

::: gfnx.reward.bitseq

# TFBind-8 reward

::: gfnx.reward.tfbind

# QM9 Small reward

::: gfnx.reward.qm9_small

# AMP reward

::: gfnx.reward.amp

# GFP reward

::: gfnx.reward.gfp
