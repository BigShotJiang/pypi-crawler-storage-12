# Reward API Reference

::: gfnx.reward.hypergrid