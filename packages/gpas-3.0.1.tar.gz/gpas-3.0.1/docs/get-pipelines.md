__help__

The `get-pipelines` command fetches the valid pipelines and their versions from the server.

### Usage

```bash
gpas get-pipelines
```
