__help__

Credits are required to upload samples and initiate the analysis process. Users can check their credit balance in the
header of the GPAS Portal or by using the `gpas balance` command when logged in.

### Usage

```bash balance usage
gpas balance
15:56:56 INFO: GPAS client version 2.0.0
15:56:56 INFO: Getting credit balance for portal.gpas.global
15:56:57 INFO: Your remaining account balance is 1000 credits
```
