__help__

The `get-amplicon-schemes` command fetches the valid amplicon schemes from the server.

### Usage

```bash
gpas get-amplicon-schemes
```
