# This repository has been archived

You can find all client-python code in the `client-python` directory of [OpenCTI repository](https://github.com/OpenCTI-Platform/opencti)

## About

OpenCTI is a product designed and developed by the company [Filigran](https://filigran.io).

<a href="https://filigran.io" alt="Filigran"><img src="https://github.com/OpenCTI-Platform/opencti/raw/master/.github/img/logo_filigran.png" width="300" /></a>