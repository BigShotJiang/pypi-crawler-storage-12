"""
Video processing commands for mcli.
"""
