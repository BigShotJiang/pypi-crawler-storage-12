"""
Self-management module for mcli.
"""
