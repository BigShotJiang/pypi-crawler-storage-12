"""Multi-cloud sync module for mcli workflow system."""

from .sync_cmd import sync

__all__ = ["sync"]
