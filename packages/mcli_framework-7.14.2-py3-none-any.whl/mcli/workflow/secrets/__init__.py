"""Secrets workflow - migrated from lib.secrets."""

from .secrets_cmd import secrets

__all__ = ["secrets"]
