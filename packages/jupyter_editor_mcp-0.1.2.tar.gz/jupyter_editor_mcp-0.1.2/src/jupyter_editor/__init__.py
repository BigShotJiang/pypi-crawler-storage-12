"""Jupyter Notebook Editor MCP Server.

A Model Context Protocol server for editing Jupyter notebooks programmatically.
"""

__version__ = "0.1.0"
