# SPDX-FileCopyrightText: 2024 Tomodachi94 and contributors
#
# SPDX-License-Identifier: MIT

import pokemon_images.__init__ as pokemon_images

def main():
    print(pokemon_images.get_random_url())

if __name__ == "__main__":
    main()
