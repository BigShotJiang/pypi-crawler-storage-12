The development of this module has been financially supported by:

- Odoo Italia Network
- APS Odoo Italia
