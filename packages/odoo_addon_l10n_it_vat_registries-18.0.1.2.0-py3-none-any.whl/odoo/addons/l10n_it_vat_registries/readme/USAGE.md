**Italiano**

Dal menu Contabilità -\> Rendicontazione -\> Imposte -\> Registri IVA è
possibile lanciare la procedura di stampa, nella quale è necessario
impostare un intervallo di date. Qui è possibile utilizzare un periodo
fiscale nel campo 'Intervallo Date'.

Nel campo 'Registro IVA' è possibile selezionare un registro
preconfigurato, oppure è possibile andare direttamente a impostare i
registri e la struttura nei campi sottostanti.

**English**

Using the menu Accounting -\> Reports -\> Taxes -\> VAT registries it is
possible to launch the print wizard, where you have to set a date range.
You can use a fiscal period in the field 'date range'.

In the 'VAT registry' field you can select a preconfigured registry, or
you can directly journals and layout in the fields below.
