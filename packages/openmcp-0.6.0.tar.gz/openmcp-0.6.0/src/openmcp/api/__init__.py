"""API endpoints for openmcp."""

from .routes import create_api_router

__all__ = ["create_api_router"]
