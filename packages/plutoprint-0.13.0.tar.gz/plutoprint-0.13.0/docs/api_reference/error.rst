Error
=====

.. currentmodule:: plutoprint

.. autoclass:: Error
    :show-inheritance:
