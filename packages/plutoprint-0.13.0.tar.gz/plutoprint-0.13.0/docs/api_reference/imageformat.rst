ImageFormat
===========

.. currentmodule:: plutoprint

.. autoclass:: ImageFormat

.. autodata:: IMAGE_FORMAT_INVALID

.. autodata:: IMAGE_FORMAT_ARGB32

.. autodata:: IMAGE_FORMAT_RGB24

.. autodata:: IMAGE_FORMAT_A8

.. autodata:: IMAGE_FORMAT_A1
