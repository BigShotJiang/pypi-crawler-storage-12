ImageCanvas
===========

.. currentmodule:: plutoprint

.. autoclass:: ImageCanvas
    :show-inheritance:
    :members:

    .. automethod:: __init__
