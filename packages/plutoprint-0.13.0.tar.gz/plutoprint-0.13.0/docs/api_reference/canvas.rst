Canvas
======

.. currentmodule:: plutoprint

.. autoclass:: Canvas
    :members:

    .. automethod:: __enter__
    .. automethod:: __exit__

.. autoclass:: AnyCanvas
