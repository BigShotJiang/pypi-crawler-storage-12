PageSize
========

.. currentmodule:: plutoprint

.. autoclass:: PageSize
    :members:

    .. automethod:: __init__
    .. automethod:: __getitem__

.. autodata:: PAGE_SIZE_NONE

.. autodata:: PAGE_SIZE_LETTER

.. autodata:: PAGE_SIZE_LEGAL

.. autodata:: PAGE_SIZE_LEDGER

.. autodata:: PAGE_SIZE_A3

.. autodata:: PAGE_SIZE_A4

.. autodata:: PAGE_SIZE_A5

.. autodata:: PAGE_SIZE_B4

.. autodata:: PAGE_SIZE_B5
