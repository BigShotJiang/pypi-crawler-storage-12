"""Types for use in accessing the NI Metadata Store."""
