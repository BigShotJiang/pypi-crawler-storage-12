"""Public API for accessing the NI Data/Metadata Stores."""
