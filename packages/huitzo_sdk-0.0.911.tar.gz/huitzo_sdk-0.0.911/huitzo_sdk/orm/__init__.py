"""ORM interfaces for plugin model definitions."""

from .base import Base, get_base, register_base

__all__ = ["Base", "get_base", "register_base"]
