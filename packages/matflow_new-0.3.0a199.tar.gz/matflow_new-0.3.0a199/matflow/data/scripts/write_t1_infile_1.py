def write_t1_infile_1(*args, **kwargs):
    pass
