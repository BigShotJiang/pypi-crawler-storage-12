# Django kanboard

This django app aims to create some Kanboard projects from a generic project.
