"""
Views for the :mod:`django_kanboard` application.

:creationdate: 29/06/2021 16:48
:moduleauthor: François GUÉRIN <fguerin@ville-tourcoing.fr>
:modulename: django_kanboard.views
"""
