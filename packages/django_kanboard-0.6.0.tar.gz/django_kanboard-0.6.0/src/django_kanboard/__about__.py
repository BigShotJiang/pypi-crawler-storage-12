"""About the :mod:`django-kanboard` package."""

__version__ = "0.6.0"
