"""W3C Actions module for performing gestures using W3C Actions API.

0==K9 <>4C;L ?@54>AB02;O5B @50;870F8N 65AB>2 G5@57 W3C Actions API,
:>B>@K9 O2;O5BAO AB0=40@B>< WebDriver 4;O 2K?>;=5=8O A;>6=KE 2708<>459AB289
A M;5<5=B0<8.
"""
