import json
import os
import unittest

from src.torrent_name_parser import TorrentNameParser
from dataclasses import asdict

class ParseTest(unittest.TestCase):
    def test_parser(self):
        json_input = os.path.join(os.path.dirname(__file__), 'files/input.json')
        with open(json_input) as input_file:
            torrents = json.load(input_file)

        json_output = os.path.join(os.path.dirname(__file__), 'files/output.json')
        with open(json_output) as output_file:
            expected_results = json.load(output_file)

        self.assertEqual(len(torrents), len(expected_results))
        parser = TorrentNameParser()
        
        for torrent, expected_result in zip(torrents, expected_results):
            print("Test: " + torrent)
            result = asdict(parser.parse(torrent))
            for key in expected_result:
                self.assertIn(key, result)
                result1 = result[key]
                self.assertEqual(result1, expected_result[key])

 
if __name__ == '__main__':
    unittest.main()
