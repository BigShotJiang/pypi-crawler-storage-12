![PyPI - Python Version](https://img.shields.io/badge/python-3.9%20|%203.10%20|%203.11%20|%203.12%20|%203.13-blue)

# torrent-name-parser

> Extract media information from torrent-like filenames

This fork modernizes the original [Python port](https://github.com/divijbindlish/parse-torrent-name) by Divij Bindlish of [Jānis’ JavaScript library](https://github.com/jzjzjzj/parse-torrent-name).

---

## Usage

> TBA

---

## Attribution

* Original JavaScript implementation: [Jānis](https://github.com/jzjzjzj)  
* Python port: [Divij Bindlish](https://github.com/divijbindlish/parse-torrent-name)  
* This fork (Python 3.x updates, ongoing maintenance): [Dragos Pancescu](https://github.com/DragosPancescu)

---

## License

MIT © [Divij Bindlish](http://divijbindlish.in) (original work)  
MIT © [Dragos Pancescu](https://github.com/DragosPancescu) (this fork)
