To configure this module, you need to:

1.  Go to a *Inventory \> Configuration \> Operation Types*.
2.  Set 'auto create lot' option for this operation type.
3.  Go to a *Inventory \> Master Data \> Products*.
4.  Set 'auto create lot' option for the products you need.
