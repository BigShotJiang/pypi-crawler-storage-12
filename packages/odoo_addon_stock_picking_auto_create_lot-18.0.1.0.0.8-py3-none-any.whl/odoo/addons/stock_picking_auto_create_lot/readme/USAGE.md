To use this module you need to:

1.  Go to a *Product \> General Information tab*.
2.  Set a tracking option for this product.
3.  Set auto create lot.
4.  Go to *Inventory \> Incoming* and create one.
5.  Validate picking without lot.
