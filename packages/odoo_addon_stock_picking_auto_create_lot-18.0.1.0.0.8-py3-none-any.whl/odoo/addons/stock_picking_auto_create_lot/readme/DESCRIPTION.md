This module extends the functionality of stock module to allow auto
create lots for incoming pickings.
