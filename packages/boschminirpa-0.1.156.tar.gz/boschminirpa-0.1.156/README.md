# BoschMiniRpa

This package is used for building low code or no code RPA solutions within Bosch.