from .core import Cached

__all__ = [
    "Cached",
]
