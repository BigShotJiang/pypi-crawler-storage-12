"""Unit tests for MemAgent components."""
