#!/usr/bin/env python
# * coding: utf8 *
"""
test_swapper.py
A module that contains tests for the swapper package
"""


def test_sanity():
    assert True
