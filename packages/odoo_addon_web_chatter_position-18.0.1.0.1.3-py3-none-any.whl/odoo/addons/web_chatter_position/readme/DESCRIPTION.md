Configurable chatter position from the user preferences.

Supports Both Community & Enterprise Edition.

Extends the functionality of the web client to get full width in the form view sheet.