Developer and scientific team:

* Pablo Iturrieta - Deutsches GeoForschungsZentrum (GFZ), Germany - pciturri@gfz-potsdam.de
* William Savran - University of Nevada, USA
* Asim Khawaja - GFZ, Germany
* Toño Bayona - University of Bristol, United Kingdom
* Danijel Schorlemmer -  GFZ, Germany
* Fabio Silva - Southern California Earthquake Center (SCEC), USA
* Phil Maechling - SCEC, USA
* Max Werner - University of Bristol, United Kingdom