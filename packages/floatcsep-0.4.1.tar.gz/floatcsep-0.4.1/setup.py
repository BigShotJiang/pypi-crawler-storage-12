from setuptools import setup

if __name__ == "__main__":
    setup(
        name="floatcsep",
        use_scm_version=True,
        setup_requires=["setuptools-scm"],
    )
