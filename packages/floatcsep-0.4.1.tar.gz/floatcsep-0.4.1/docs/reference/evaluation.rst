Evaluation Class
================

.. autoclass:: floatcsep.evaluation.Evaluation
   :members:
   :undoc-members:
   :show-inheritance:
