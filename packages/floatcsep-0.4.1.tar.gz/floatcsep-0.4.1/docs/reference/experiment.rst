Experiment Handler
==================

.. autoclass:: floatcsep.experiment.Experiment
   :members:
   :undoc-members:
   :show-inheritance:
