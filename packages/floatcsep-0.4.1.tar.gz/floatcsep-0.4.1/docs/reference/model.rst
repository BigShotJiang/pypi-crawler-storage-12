Model Classes
=============

.. autoclass:: floatcsep.model.Model
   :members:
   :undoc-members:
   :show-inheritance:


.. autoclass:: floatcsep.model.TimeIndependentModel
   :members:
   :undoc-members:
   :show-inheritance:


.. autoclass:: floatcsep.model.TimeDependentModel
   :members:
   :undoc-members:
   :show-inheritance:
