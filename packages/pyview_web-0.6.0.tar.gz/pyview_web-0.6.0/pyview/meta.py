from dataclasses import dataclass


@dataclass
class PyViewMeta:
    pass
