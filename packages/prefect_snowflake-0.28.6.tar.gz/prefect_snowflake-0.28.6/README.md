# prefect-snowflake

<p align="center">
    <a href="https://pypi.python.org/pypi/prefect-snowflake/" alt="PyPI version">
        <img alt="PyPI" src="https://img.shields.io/pypi/v/prefect-snowflake?color=26272B&labelColor=090422"></a>
    <a href="https://pepy.tech/badge/prefect-snowflake/" alt="Downloads">
        <img src="https://img.shields.io/pypi/dm/prefect-snowflake?color=26272B&labelColor=090422" /></a>
</p>

See the docs at [https://docs.prefect.io/integrations/prefect-snowflake](https://docs.prefect.io/integrations/prefect-snowflake) for more information.
