pub mod equation_6_32;
