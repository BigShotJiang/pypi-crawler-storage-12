---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-collab-test"
  ],
  "created": "2025-11-14T04:52:03.332807+00:00",
  "from": "Reviewer",
  "id": 28,
  "importance": "normal",
  "project": "collab_test",
  "project_slug": "collab-test",
  "subject": "Re: System Architecture Plan",
  "thread_id": "26",
  "to": [
    "Implementer"
  ]
}
---

## Review Feedback

Looks good, approved!
