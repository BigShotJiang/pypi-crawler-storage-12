---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-collab-test"
  ],
  "created": "2025-11-14T04:52:03.060756+00:00",
  "from": "Planner",
  "id": 26,
  "importance": "normal",
  "project": "collab_test",
  "project_slug": "collab-test",
  "subject": "System Architecture Plan",
  "thread_id": null,
  "to": [
    "Implementer",
    "Reviewer"
  ]
}
---

## Architecture

Proposed system design...
