---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-test-manual-01db3777"
  ],
  "created": "2025-11-14T09:37:01.525450+00:00",
  "from": "Bobfbd3ff",
  "id": 190,
  "importance": "normal",
  "project": "test_manual_01db3777",
  "project_slug": "test-manual-01db3777",
  "subject": "Bob testing message 1",
  "thread_id": null,
  "to": [
    "Alice4feef7"
  ]
}
---

Testing content from Bob 1
