---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-test-manual-01db3777"
  ],
  "created": "2025-11-14T09:37:01.423615+00:00",
  "from": "Alice4feef7",
  "id": 189,
  "importance": "normal",
  "project": "test_manual_01db3777",
  "project_slug": "test-manual-01db3777",
  "subject": "Alice testing message 3",
  "thread_id": null,
  "to": [
    "Bobfbd3ff"
  ]
}
---

Testing content from Alice 3
