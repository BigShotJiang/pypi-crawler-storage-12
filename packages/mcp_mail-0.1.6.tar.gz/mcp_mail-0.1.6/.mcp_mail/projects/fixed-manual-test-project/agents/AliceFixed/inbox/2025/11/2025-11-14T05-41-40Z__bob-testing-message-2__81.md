---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-fixed-manual-test-project"
  ],
  "created": "2025-11-14T05:41:40.277817+00:00",
  "from": "BobFixed",
  "id": 81,
  "importance": "normal",
  "project": "fixed_manual_test_project",
  "project_slug": "fixed-manual-test-project",
  "subject": "Bob testing message 2",
  "thread_id": null,
  "to": [
    "AliceFixed"
  ]
}
---

Testing content from Bob 2
