---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-fixed-manual-test-project"
  ],
  "created": "2025-11-14T05:41:18.995578+00:00",
  "from": "AliceFixed",
  "id": 59,
  "importance": "normal",
  "project": "fixed_manual_test_project",
  "project_slug": "fixed-manual-test-project",
  "subject": "Alice testing message 3",
  "thread_id": null,
  "to": [
    "BobFixed"
  ]
}
---

Testing content from Alice 3
