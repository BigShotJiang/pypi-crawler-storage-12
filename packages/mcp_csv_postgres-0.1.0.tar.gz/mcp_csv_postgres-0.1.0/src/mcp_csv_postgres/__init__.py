"""CSV to PostgreSQL loader MCP server."""

__version__ = "0.1.0"
