"""GlanceWatch - Lightweight monitoring adapter for Glances + Uptime Kuma."""

__version__ = "1.0.10"
