# White API Python Client

Python клиент для работы с API White (api.wscode.ru)

## Установка

```bash
pip install white-api