class LogSentinelError(Exception):
    pass

class ConfigurationError(LogSentinelError):
    pass
