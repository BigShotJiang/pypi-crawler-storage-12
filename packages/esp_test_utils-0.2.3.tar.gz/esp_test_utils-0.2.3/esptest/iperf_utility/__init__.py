"""
Iperf Test Utility Methods

- Initialized from: https://github.com/espressif/esp-idf/tree/v5.2.1/tools/ci/python_packages/idf_iperf_test_util
- pyecharts is an optional package, need to install it manually

Usage Example:


"""
