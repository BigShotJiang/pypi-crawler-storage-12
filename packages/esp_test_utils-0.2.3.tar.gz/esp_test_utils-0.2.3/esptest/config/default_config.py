class DefConfig:
    DEF_PEXPECT_TIMEOUT = 30
