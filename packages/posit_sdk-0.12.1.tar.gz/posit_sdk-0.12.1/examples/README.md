### Posit SDK Examples

For more in-depth SDK examples, covering a variety of use cases, check out the
[Posit Connect Cookbook](https://docs.posit.co/connect/cookbook/getting-started/).

> [!NOTE]
> The databricks and snowflake examples will be removed from this repo is a future SDK release.
> Please see the updated examples in the [OAuth Integrations](https://docs.posit.co/connect/cookbook/oauth-integrations/)
> section of the Connect Cookbook.

