# This file fixes the mypy errors "duplicate module named app.py"
