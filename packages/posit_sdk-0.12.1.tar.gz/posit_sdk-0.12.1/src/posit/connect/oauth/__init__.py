"""OAuth resources."""

from .oauth import Credentials as Credentials
from .oauth import OAuth as OAuth
