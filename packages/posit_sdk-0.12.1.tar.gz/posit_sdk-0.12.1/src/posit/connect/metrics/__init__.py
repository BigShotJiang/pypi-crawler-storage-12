"""Metric resources."""

from .metrics import Metrics as Metrics
