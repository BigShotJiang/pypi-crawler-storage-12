"""External integrations.

Notes
-----
The APIs in this module are provided as a convenience and are subject to breaking changes.
"""
