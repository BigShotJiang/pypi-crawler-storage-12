


async def inclusao_pedidos_ipiranga():
    pass