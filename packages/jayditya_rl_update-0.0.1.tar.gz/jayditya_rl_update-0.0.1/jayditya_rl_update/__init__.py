
"""Public API for jayditya-rl-update"""

from .qlearning import q_learning_update

__all__ = ["q_learning_update"]
