replacement for struct standard library.
struct3.py
