class Visualization:
    """
    Visualization instruction helpers.
    """

    def __init__(self):
        pass
