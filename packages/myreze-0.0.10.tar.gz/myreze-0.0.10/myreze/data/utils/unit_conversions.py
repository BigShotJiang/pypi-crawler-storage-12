def kelvin_to_celsius(kelvin):
    celsius = kelvin - 273.15
    return celsius
