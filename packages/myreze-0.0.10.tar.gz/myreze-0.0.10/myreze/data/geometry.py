class Geometry:
    """
    GeoJSON-compatible geometry helpers.
    """

    def __init__(self):
        pass
