# PySaveUtils

`PySaveUtils` — это простая библиотека с утилитами для генерации случайных данных и проверки пользовательского ввода.

## 🚀 Установка

```bash
pip install PySaveUtils
