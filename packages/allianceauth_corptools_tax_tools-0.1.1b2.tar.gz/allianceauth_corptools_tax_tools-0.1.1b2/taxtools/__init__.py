"""
Corp Tools - Tax Tools
"""

__version__ = "0.1.1b2"
__title__ = "Corp Tools - Tax Tools"
