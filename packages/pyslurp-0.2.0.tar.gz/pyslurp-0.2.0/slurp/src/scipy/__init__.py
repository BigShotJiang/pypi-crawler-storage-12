


from slurp.src.scipy._l import l
from slurp.src.scipy._cc import cc
from slurp.src.scipy._f import f
from slurp.src.scipy._bs import s

from slurp.src.scipy._gnam import GnAM