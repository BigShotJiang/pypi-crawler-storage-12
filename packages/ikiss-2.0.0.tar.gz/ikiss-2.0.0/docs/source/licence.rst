GNU V3
=========

Licensed under  `GNU GENERAL PUBLIC LICENSE V3 <https://forge.ird.fr/diade/iKISS/-/blob/master/LICENCE?ref_type=heads>`_.

Intellectual property belongs to `IRD <https://www.ird.fr>`_ and authors.
