iKISS modules
--------------

.. toctree::
   :maxdepth: 2

   kmer_gwas.rst
   pcadapt.rst
   lfmm.rst
   snmf.rst

Go away with outliers
----------------------

.. toctree::
   :maxdepth: 2

   mapping.rst
   kmer_assembly.rst
   intersect.rst


