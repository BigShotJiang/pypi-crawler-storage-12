"""Company search domain services."""

from birre.domain.company_search.service import register_company_search_tool

__all__ = ["register_company_search_tool"]
