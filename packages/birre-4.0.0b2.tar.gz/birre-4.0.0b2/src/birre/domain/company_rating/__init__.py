"""Company rating domain services."""

from birre.domain.company_rating.service import register_company_rating_tool

__all__ = ["register_company_rating_tool"]
