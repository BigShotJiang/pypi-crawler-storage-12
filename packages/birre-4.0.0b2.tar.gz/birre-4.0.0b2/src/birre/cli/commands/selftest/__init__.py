"""Self-test command package."""

from __future__ import annotations

from birre.cli.commands.selftest.command import register

__all__ = ["register"]
