"""Command-line interface for BiRRe."""

from birre.cli.app import app
from birre.cli.main import main

__all__ = ["app", "main"]
