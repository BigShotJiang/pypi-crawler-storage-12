"""Tags system for traceability and linking."""

__all__ = []
