# moai-domain-ml - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **PyTorch**: 2.5.0
- **TensorFlow**: 2.18.0
- **MLflow**: 2.19.0

---

_For detailed usage, see SKILL.md_
