# moai-domain-web-api - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **OpenAPI**: 3.1.0
- **Postman**: 11.21.0
- **Swagger UI**: 5.18.2

---

_For detailed usage, see SKILL.md_
