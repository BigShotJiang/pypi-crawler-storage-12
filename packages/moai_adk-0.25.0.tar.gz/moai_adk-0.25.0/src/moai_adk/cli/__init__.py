"""CLI module: Click-based command-line interface"""
