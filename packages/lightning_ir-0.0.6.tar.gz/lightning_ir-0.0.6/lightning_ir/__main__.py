from lightning_ir.main import main

if __name__ == "__main__":
    main()
