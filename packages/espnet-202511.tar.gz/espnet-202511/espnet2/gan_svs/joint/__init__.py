from espnet2.gan_svs.joint.joint_score2wav import JointScore2Wav  # NOQA
