layer = {
    "s4": "espnet2.asr.state_spaces.s4.S4",
    "ff": "espnet2.asr.state_spaces.ff.FF",
    "mha": "espnet2.asr.state_spaces.attention.MultiHeadedAttention",
}
