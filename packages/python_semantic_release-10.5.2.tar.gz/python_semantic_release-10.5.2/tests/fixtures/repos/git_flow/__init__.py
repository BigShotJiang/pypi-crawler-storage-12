from tests.fixtures.repos.git_flow.repo_w_1_release_channel import *
from tests.fixtures.repos.git_flow.repo_w_2_release_channels import *
from tests.fixtures.repos.git_flow.repo_w_3_release_channels import *
from tests.fixtures.repos.git_flow.repo_w_4_release_channels import *
