"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.sq.examples import sentences
>>> docs = nlp.pipe(sentences)
"""

sentences = [
    "Apple po shqyrton blerjen e nje shoqërie të U.K. për 1 miliard dollarë",
    "Makinat autonome ndryshojnë përgjegjësinë e sigurimit ndaj prodhuesve",
    "San Francisko konsideron ndalimin e robotëve të shpërndarjes",
    "Londra është një qytet i madh në Mbretërinë e Bashkuar.",
]
