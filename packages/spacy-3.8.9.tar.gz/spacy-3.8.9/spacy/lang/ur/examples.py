"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.da.examples import sentences
>>> docs = nlp.pipe(sentences)
"""

sentences = [
    "اردو ہے جس کا نام ہم جانتے ہیں داغ",
    "سارے جہاں میں دھوم ہماری زباں کی ہے",
]
