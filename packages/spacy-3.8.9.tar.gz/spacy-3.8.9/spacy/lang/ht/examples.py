"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.ht.examples import sentences
>>> docs = nlp.pipe(sentences)
"""

sentences = [
    "Apple ap panse achte yon demaraj nan Wayòm Ini pou $1 milya dola",
    "Machin otonòm fè responsablite asirans lan ale sou men fabrikan yo",
    "San Francisco ap konsidere entèdi robo ki livre sou twotwa yo",
    "Lond se yon gwo vil nan Wayòm Ini",
    "Kote ou ye?",
    "Kilès ki prezidan Lafrans?",
    "Ki kapital Etazini?",
    "Kile Barack Obama te fèt?",
]
