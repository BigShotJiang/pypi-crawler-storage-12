from weasel.cli.clone import *
