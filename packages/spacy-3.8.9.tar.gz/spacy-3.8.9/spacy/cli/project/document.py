from weasel.cli.document import *
