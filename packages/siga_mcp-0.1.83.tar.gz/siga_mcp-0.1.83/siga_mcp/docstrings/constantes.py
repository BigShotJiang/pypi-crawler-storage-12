def docs() -> str:
    return """
        Retorna todas as constantes de referência do sistema SIGA organizadas em seções Markdown.

        Esta função fornece dados estáticos essenciais para operações no SIGA, incluindo 
        listas de projetos, sistemas, equipes, tipos de atendimento e configurações do sistema.
        Utilizada principalmente pela IA para consultas sem necessidade de chamadas API específicas.

        Funcionalidade:
        - Retorna constantes organizadas em seções com formato ## título
        - Inclui IDs e nomes no padrão **Nome:** ID  
        - Dados atualizados automaticamente conforme configuração do sistema
        - Abrange todos os tipos: sistemas, projetos, equipes, status, origens
        - Formato otimizado para parsing e consulta pela IA

        Formato de apresentação ao usuário:
        - IMPORTANTE: Remova asteriscos (**) e hashtags (##) do Markdown ao apresentar
        - Extraia apenas os dados limpos: nome e ID
        - Use tabelas HTML ou listas simples para apresentação final
        - Nunca mostre a formatação Markdown bruta para o usuário
        - Para consultas específicas, extraia APENAS a seção solicitada (ex: "## projetos")

        Exemplos de uso:
        - Usuário: "Liste os projetos" → Extrair seção "## projetos" → Apresentar como tabela limpa
        - Usuário: "Mostre os sistemas" → Extrair seção "## sistemas" → Apresentar como lista organizada  
        - Usuário: "Quais equipes existem" → Extrair seção "## equipe geral" → Apresentar como lista limpa

        Conversão de formato:
        - Raw: "**Adequações para ONA 2022:** 107"
        - Apresentar como: "Adequações para ONA 2022 (ID: 107)"
        - Ou em tabela com colunas separadas: Nome | ID

        Notes: 
            - FONTE DINÂMICA: Gerado automaticamente a partir das constantes configuradas no sistema
            - FORMATO PADRÃO: Markdown com seções ## e itens **Nome:** ID para fácil parsing
            - ATUALIZAÇÃO AUTOMÁTICA: Novas constantes adicionadas ao sistema aparecem automaticamente
            - USO PRINCIPAL: Consultas da IA para listar opções disponíveis (projetos, sistemas, equipes)
            - PERFORMANCE: Dados estáticos, sem necessidade de chamadas à API para consultas básicas
            - COMPATIBILIDADE: Funciona com todas as operações de criação/edição que precisam de constantes
            - MANUTENÇÃO: Zero manutenção - adicionar constante no sistema atualiza automaticamente
            - EXTRAÇÃO: Use a seção específica solicitada, não retorne todo o conteúdo
            - APRESENTAÇÃO: Formate como apresentação limpa sem caracteres Markdown visíveis
            
        """
