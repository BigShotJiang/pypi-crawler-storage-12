<div align="center">
<img alt="" src="https://forge.steffo.eu/steffo/royalspells/raw/branch/main/.media/icon-512.png" height="128" style="border-radius: 100%;">
<hgroup>
<h1>Royal Spells</h1>
<p>Genera proceduralmente magie con statistiche insignificanti</p>
</hgroup>
</div>

</div>

## Perchè?

Per fare divertire un po' la [RYG](https://www.ryg.one/).

Da usare in RYG Bot, in qualche modo.

## Link

### Tools

<a href="https://www.python.org/">
    <img alt="Scritto in Python" title="Scritto in Python" src="https://img.shields.io/badge/language-python-3775a9" height="30px">
</a>

### Packaging

<a href="https://pypi.org/project/royalspells">
    <img alt="Disponibile su PyPI" title="Available on PyPI" src="https://img.shields.io/pypi/v/royalspells?label=pypi&color=ffd242" height="30px">
</a>
&hairsp;
<a href="https://forge.steffo.eu/steffo/-/packages/pypi/royalspells">
    <img alt="Disponibile su Forgejo Packages" title="Available on Forgejo Packages" src="https://img.shields.io/badge/forgejo%20packages-latest-ff6600" height="30px">
</a>

### Sviluppo

<a href="https://forge.steffo.eu/steffo/royalspells">
    <img alt="Repository di codice" title="Repository di codice" src="https://img.shields.io/gitea/last-commit/steffo/royalspells?gitea_url=https%3A%2F%2Fforge.steffo.eu&color=374351" height="30px">
</a>
&hairsp;
<a href="https://forge.steffo.eu/steffo/royalspells/releases">
    <img alt="Release" title="Release" src="https://img.shields.io/gitea/v/release/steffo/royalspells?gitea_url=https%3A%2F%2Fforge.steffo.eu&label=last+release&color=374351" height="30px">
</a>
