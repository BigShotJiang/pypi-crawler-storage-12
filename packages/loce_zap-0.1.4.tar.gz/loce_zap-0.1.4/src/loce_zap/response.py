from __future__ import annotations

from typing import Any


class APIResponse(dict):
    """Dict que permite acesso por atributos (ex: resp.qrCode)."""

    def __getattr__(self, item: str) -> Any:
        try:
            return self[item]
        except KeyError as exc:
            raise AttributeError(item) from exc

    def __dir__(self) -> Any:
        return sorted(set(super().__dir__()) | set(self.keys()))


def wrap_response_payload(value: Any) -> Any:
    if isinstance(value, dict):
        return APIResponse({k: wrap_response_payload(v) for k, v in value.items()})
    if isinstance(value, list):
        return [wrap_response_payload(v) for v in value]
    if isinstance(value, tuple):
        return tuple(wrap_response_payload(v) for v in value)
    return value
