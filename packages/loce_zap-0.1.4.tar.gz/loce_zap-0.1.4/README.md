# Loce Zap Python SDK

Official Python SDK for the Loce Zap multi-session WhatsApp API. The public interface mirrors the JavaScript snippet you provided: instantiate `LoceZap(api_key)` and call camelCase helpers such as `connect`, `sendMessageText`, `listSessions`, and `deleteMessage`.

> **Recipients:** Numbers must be in E.164 format **without** the `+` (DDI + number, 6–15 digits). To target a group, send the group JID (e.g. `1234567890-123@g.us`).

## Installation

```bash
pip install loce-zap
```

For local edits inside this repo:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -e .
```

## Quick start (sync)

```python
import LoceZap

zap = LoceZap("your_api_key")

# 1) Connect a session and display the QR code
qr_info = zap.connect("Support Session", "https://example.com/webhook", webhook_messages=True)
print(qr_info.status, qr_info.qrCode)

# 2) Send a few message types
zap.sendMessageText("support-session", "5564999999999", "Hello from Python 👋")
zap.sendMessageImage("support-session", "5564999999999", "https://files.loce.io/promo.png", caption="New feature!")
zap.sendMessageDocument("support-session", "5564999999999", "https://files.loce.io/contract.pdf", file_name="Contract.pdf")
zap.sendMessageLocation("support-session", "5564999999999", latitude=-16.7033, longitude=-49.263)

# 3) Edit & delete a message
resp = zap.sendMessageText("support-session", "5564999999999", "Temporary message")
msg_id = resp.messageId
if msg_id:
    zap.editMessage("support-session", msg_id, "5564999999999", "Updated message")
    zap.deleteMessage("support-session", msg_id, "5564999999999")

# 4) List sessions
sessions = zap.listSessions()
for session in sessions.sessions:
    print(session.get("name"), session.get("status"))
```

## Quick start (async)

```python
import asyncio
import LoceZap

async def demo():
    zap = LoceZap.AsyncLoceZap("your_api_key")
    await zap.connect("Store Session", "https://example.com/webhook")
    await zap.sendMessageText("store-session", "5564999999999", "Order received!")
    await zap.close()

asyncio.run(demo())
```

## Client configuration

Sync and async constructors share the same signature:

```python
LoceZap(
    api_key="lz_xxx",
    base_url="https://api.locezap.com",
    timeout=30,
    max_retries=2,
    backoff_factor=0.5,
    default_headers={"X-App": "demo"},
)
```

- `api_key` (**required**): found in the Loce Zap dashboard.
- `base_url`: override only if you’re targeting a staging/self-hosted environment.
- `timeout`, `max_retries`, `backoff_factor`: tweak HTTPX resilience settings.
- `default_headers`: extra headers included in every request.

## Session management

```python
qr = zap.connect(
    "WhatsApp Support",
    "https://example.com/webhook",
    webhook_messages=True,
    sync_full_history=False,
    days_history=7,
)
print(qr.status)

zap.disconnect("support-session")
current = zap.listSessions()
```

The `connect` response includes the `qrCode`, `status`, and `expiresAt`. Use `qrcode_terminal` to show the QR in your terminal.

## Messaging helpers

```python
zap.sendMessageText(session_id, to, text, *, external_id=None, quote_id=None)
zap.sendMessageImage(session_id, to, image_url, *, caption=None, external_id=None, quote_id=None)
zap.sendMessageAudio(session_id, to, audio_url, *, external_id=None, quote_id=None)
zap.sendMessageDocument(session_id, to, file_url, *, file_name=None, caption=None, mimetype=None, external_id=None, quote_id=None)
zap.sendMessageLocation(session_id, to, *, latitude, longitude, external_id=None, quote_id=None)
zap.sendMessageVideo(session_id, to, video_url, *, caption=None, mimetype=None, gif_playback=None, external_id=None, quote_id=None)
zap.sendMessageSticker(session_id, to, sticker_url, *, external_id=None, quote_id=None)
zap.deleteMessage(session_id, message_id, to)
zap.editMessage(session_id, message_id, to, text)
```

Each helper returns an `APIResponse`, which behaves like a dict but also supports attribute access (`resp.messageId`). Required fields are validated locally: missing `text`, `imageUrl`, etc. raise `ValueError` before the HTTP request is issued.

### External IDs & quotes

- `external_id`: echoed back in delivery/read webhooks, useful for reconciling events in your system.
- `quote_id`: replies to a specific message id (quoted messages).

## Webhook verification

Loce Zap signs every webhook with HMAC SHA-256. Use the provided verifier:

```python
from LoceZap import WebhookVerifier, WebhookSignatureError

signature = request.headers.get("x-locezap-signature")
try:
    WebhookVerifier.verify_signature(signature_header=signature, body=request.data, secret="your_api_key")
except WebhookSignatureError:
    abort(400, "Invalid signature")
```

The same helper works in async contexts because it’s a plain static method.

## Error handling

| Exception | Meaning |
| --- | --- |
| `AuthenticationError` | API key missing or invalid. |
| `AuthorizationError` | User doesn’t have access to that resource. |
| `ValidationError` | Payload rejected (400). |
| `RateLimitError` | Daily quota or rate limit exceeded. |
| `NotFoundError` | Session/message not found. |
| `ServerError` | 5xx from Loce Zap. |
| `TransportError` | Network/timeout/JSON decoding issue. |
| `WebhookSignatureError` | Incoming webhook signature is invalid. |

```python
from LoceZap import LoceZap, ValidationError

try:
    zap.sendMessageText("demo", "invalid", "test")
except ValidationError as exc:
    print("Payload rejected", exc)
```

## Logging & troubleshooting

1. **Network issues** – `TransportError` means the SDK retried but still couldn’t reach the API. Check `base_url`, firewall rules, or proxy settings.
2. **Rate limiting** – catch `RateLimitError` and implement exponential backoff or queueing.
3. **Inspecting HTTP traffic** – set `HTTPX_LOG_LEVEL=debug` to log all requests/responses for diagnostics.

## Build & publish

To ship a new SDK release:

```bash
python3 -m pip install --upgrade build twine wheel
rm -rf dist
python3 -m build
python3 -m twine upload dist/*      # use --repository testpypi for dry runs
```

Remember to bump `project.version` inside `pyproject.toml` before uploading.

## License

MIT.
