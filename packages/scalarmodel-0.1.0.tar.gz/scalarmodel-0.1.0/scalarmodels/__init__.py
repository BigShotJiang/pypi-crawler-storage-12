from ann import ann
from chi import ks, chi
from cnn import cnn
from comparison import comp
from gru import gru
from paralle import parallel
