"""Tests for fsspec-utils utils module."""

# Test package for utils module
