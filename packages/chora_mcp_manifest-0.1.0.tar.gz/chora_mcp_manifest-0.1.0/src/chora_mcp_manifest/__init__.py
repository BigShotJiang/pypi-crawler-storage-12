"""Chora MCP Manifest - MCP server for managing and discovering Chora ecosystem manifests, SAPs, and capabilities"""

__version__ = "0.1.0"
__author__ = "liminalcommons"