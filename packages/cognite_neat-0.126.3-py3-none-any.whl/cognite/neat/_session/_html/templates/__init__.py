from pathlib import Path

issues = Path(__file__).parent / "issues.html"
deployment = Path(__file__).parent / "deployment.html"
