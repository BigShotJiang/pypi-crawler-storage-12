# Unified NCP Module
# Consolidated from ncp/ and ncp_module/ directories