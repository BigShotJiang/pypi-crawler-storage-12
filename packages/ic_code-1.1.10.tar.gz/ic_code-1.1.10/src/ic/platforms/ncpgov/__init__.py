# Unified NCPGOV Module
# Consolidated from ncpgov/ and ncpgov_module/ directories