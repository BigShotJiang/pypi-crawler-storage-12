#!/usr/bin/env python3
"""OCI Volume info commands"""
from .info import add_arguments, main 