#!/usr/bin/env python3
"""OCI NSG info commands"""
from .info import add_arguments, main 