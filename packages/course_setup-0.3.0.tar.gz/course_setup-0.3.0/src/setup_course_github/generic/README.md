# Notes, programs, and files

This repo contains the notebook + files from my training class.  It'll remain open, so you can review the material later on.

Enjoy!

If you liked this training, you might also like:

- My YouTube channel: https://YouTube.com/reuvenlerner
- Better developers, new, free articles about Python every week: https://BetterDevelopersWeekly.com/
- "Bamboo Weekly," where I analyze data related to current events using Pandas: https://www.BambooWeekly.com/
- My Bluesky feed: https://bsky.app/profile/lernerpython.com
- My first book, "Python Workout": https://PythonWorkout.com/
- My second book, "Pandas Workout": https://PandasWorkout.com/
- LinkedIn, where I also post: https://linkedin.com/in/reuven

Want to get access to all of my courses? Check out my classes at https://LernerPython.com/

And of course, you can always e-mail me at reuven@LernerPython.com .
