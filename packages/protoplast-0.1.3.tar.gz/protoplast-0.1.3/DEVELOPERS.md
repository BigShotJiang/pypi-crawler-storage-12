# Notes for developers of PROTOplast


## How to bump version?

```bash
make bump-version version=x.x.x
```

Please make sure `x.x.x` is not an existing tag.
