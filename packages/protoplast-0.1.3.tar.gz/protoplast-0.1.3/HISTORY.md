# History

## 0.1.0 (2025-08-05)

* First release on PyPI.
