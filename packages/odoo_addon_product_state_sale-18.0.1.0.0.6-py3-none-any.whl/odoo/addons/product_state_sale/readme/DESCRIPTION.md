This module add the use of product_state module in sale
