To create a new state:

1.  Go to *Sales \> Configuration \> Products \> Product States*.
2.  You can set its name and a description.
