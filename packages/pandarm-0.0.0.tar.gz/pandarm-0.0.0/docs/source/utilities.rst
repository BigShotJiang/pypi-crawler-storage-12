Utilities
=========

.. autofunction:: pandarm.utils.reindex
