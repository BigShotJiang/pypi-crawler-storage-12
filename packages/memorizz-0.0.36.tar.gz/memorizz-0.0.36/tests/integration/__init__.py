"""Integration tests for MemAgent components."""
