EXCLUDED_CONFIG_FILE_PARAMS = {
    "urls",
    "config_path",
    "read_urls_as_txt",
    "no_config_file",
    "version",
    "help",
}
X_NOT_IN_PATH = '{} was not found in PATH at "{}"'
