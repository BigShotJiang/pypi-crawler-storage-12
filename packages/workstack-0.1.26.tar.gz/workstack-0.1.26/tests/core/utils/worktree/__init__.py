"""Tests for worktree utility functions."""
