# Kit Documentation Registry

<!-- AUTO-GENERATED: This file is managed by dot-agent kit commands -->
<!-- DO NOT EDIT: Changes will be overwritten. Use 'dot-agent kit sync' -->

<!-- REGISTRY_VERSION: 1 -->
<!-- GENERATED_AT: 2025-11-14T14:52:36 -->

<!-- BEGIN_ENTRIES -->

<!-- ENTRY_START kit_id="devrun" version="0.1.0" source="bundled" -->

@.agent/kits/devrun/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="dignified-python-313" version="0.1.0" source="bundled" -->

@.agent/kits/dignified-python-313/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="fix-merge-conflicts" version="0.1.0" source="bundled" -->

@.agent/kits/fix-merge-conflicts/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="gt" version="0.1.0" source="bundled" -->

@.agent/kits/gt/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="workstack" version="0.1.0" source="bundled" -->

@.agent/kits/workstack/registry-entry.md

<!-- ENTRY_END -->

<!-- END_ENTRIES -->
