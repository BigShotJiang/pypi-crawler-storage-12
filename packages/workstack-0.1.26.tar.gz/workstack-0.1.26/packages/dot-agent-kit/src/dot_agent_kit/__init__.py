"""dot-agent-kit: Kit management for Claude Code."""

from dot_agent_kit.version import __version__

__all__ = ["__version__"]
