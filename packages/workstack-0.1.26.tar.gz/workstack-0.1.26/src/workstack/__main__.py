"""Allow workstack to be run as a module: python -m workstack."""

from workstack import main

if __name__ == "__main__":
    main()
