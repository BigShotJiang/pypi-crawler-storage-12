"""Status renderers."""

from workstack.status.renderers.simple import SimpleRenderer

__all__ = ["SimpleRenderer"]
