# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "retell"
__version__ = "4.57.0"  # x-release-please-version
