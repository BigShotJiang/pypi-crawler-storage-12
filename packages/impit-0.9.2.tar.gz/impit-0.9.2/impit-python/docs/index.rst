impit for Python
===================

.. toctree::
   :maxdepth: 2
   :glob:

   api/*

README
===================

.. include:: ../README.md
   :parser: myst_parser.sphinx_
