Response
===================

.. .. toctree::

.. autoclass:: impit.Response
    :members:


