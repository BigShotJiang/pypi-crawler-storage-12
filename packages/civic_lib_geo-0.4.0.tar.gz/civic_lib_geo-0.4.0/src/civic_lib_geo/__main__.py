"""Entry point for Civic Lib Geo CLI.

File: civic_lib_geo.__main__
"""

from civic_lib_geo.cli.cli import app

if __name__ == "__main__":
    app()
