# CLI Reference

## Quick help

```bash
# Show top-level help
civic-geo --help

# Show help for a subcommand
civic-geo <subcommand> --help
```
