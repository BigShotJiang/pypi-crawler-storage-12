# pkgs/intreg_stats/src/intreg_stats/__init__.py
from .estimator import HIREG, MARINER
__all__ = ["HIREG","MARINER"]