"""Tests for the ``jupyter`` module."""

import calkit


def test_get_servers():
    calkit.jupyter.get_servers()
