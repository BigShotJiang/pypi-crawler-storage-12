from .ifc_model_object_pb2 import *
from .ifc_file_model_object_pb2 import *
