1.  Your Company record must have the Legal ID specified.
2.  Your Bank must have the Routing Number specified.
