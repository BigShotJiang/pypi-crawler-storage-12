from enum import Enum

class ApertureType(Enum):
    EntrancePupilDiameter = "Entrance pupil diameter"
    ObjectSpaceNA = "Object space NA"
