from .wavelength import Wavelength
from .optical_wavelength import OpticalWavelength
__all__ = ["Wavelength", "OpticalWavelength"]