#exonware/xwsystem/tests/core/core/__init__.py
"""
Core Core Tests Package

Tests for XSystem core functionality including base classes and contracts.
"""
