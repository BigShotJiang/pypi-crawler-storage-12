"""Unit tests for io.stream sub-package."""

