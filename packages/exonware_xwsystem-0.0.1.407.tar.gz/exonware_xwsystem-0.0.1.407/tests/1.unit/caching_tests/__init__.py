"""
Unit tests for caching module.
"""

