"""
#exonware/xwsystem/tests/1.unit/operations_tests/__init__.py

Unit tests for operations module.
"""

