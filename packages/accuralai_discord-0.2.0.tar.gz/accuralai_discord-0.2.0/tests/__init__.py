"""Tests for accuralai-discord package."""

