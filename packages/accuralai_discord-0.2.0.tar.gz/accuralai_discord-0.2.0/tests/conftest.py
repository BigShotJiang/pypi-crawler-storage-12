"""Pytest configuration and fixtures."""

from __future__ import annotations

import pytest

