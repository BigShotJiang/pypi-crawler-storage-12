<p align="center">
  <!-- @subst[`printf '<a href="https://github.com/curvcpu/curv-python/releases/tag/curv-v%s"><img src="https://img.shields.io/badge/v%s-blue?label=curv" alt="curv version %s"></a>\n' '0.1.9' '0.1.9' '0.1.9'`] -->
  <!-- @endsubst -->
  <!-- @subst[`printf '<a href="https://github.com/curvcpu/curv-python/releases/tag/curvtools-v%s"><img src="https://img.shields.io/badge/v%s-blue?label=curvtools" alt="curvtools version %s"></a>\n' '0.0.9' '0.0.9' '0.0.9'`] -->
  <!-- @endsubst -->
  <!-- @subst[`printf '<a href="https://github.com/curvcpu/curv-python/releases/tag/curvpyutils-v%s"><img src="https://img.shields.io/badge/v%s-blue?label=curvpyutils" alt="curvpyutils version %s"></a>\n' '0.0.29' '0.0.29' '0.0.29'`] -->
  <!-- @endsubst -->
</p>
