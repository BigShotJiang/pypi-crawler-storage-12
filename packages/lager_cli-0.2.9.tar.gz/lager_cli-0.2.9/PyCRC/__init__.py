# -*- coding: utf-8 -*-

__author__ = 'Cristian Năvălici'
__email__ = 'cristian.navalici@runbox.com'
__version__ = '1.0'
