"""
    lager.hello.commands

    Say hello to gateway
"""
import click
from ..dut_storage import resolve_and_validate_dut_with_name

@click.command()
@click.pass_context
@click.option("--box", required=False, help="Lagerbox name or IP")
@click.option('--dut', required=False, hidden=True, help="Lagerbox name or IP")
def hello(ctx, box, dut):
    """Test gateway connectivity"""
    # Use box or dut (box takes precedence)
    dut = box or dut

    # Resolve and validate the DUT, keeping track of the original name
    resolved_dut, dut_name = resolve_and_validate_dut_with_name(ctx, dut)

    # Get session for gateway - uses DirectHTTPSession for direct connections
    session = ctx.obj.get_session_for_gateway(resolved_dut, dut_name=dut_name)

    try:
        # Call the HTTP /hello endpoint on port 5000
        resp = session.gateway_hello(resolved_dut)

        if resp.status_code == 200:
            # Try to parse as JSON first, fall back to plain text
            try:
                data = resp.json()
                message = data.get('message', 'Hello from gateway!')
            except Exception:
                # Plain text response (from controller)
                message = resp.text.strip()

            # Display success message with DUT info
            click.secho(message, fg='green')
            if dut_name:
                click.secho(f'Gateway: {dut_name} ({resolved_dut})', fg='green')
            else:
                click.secho(f'Gateway: {resolved_dut}', fg='green')
        else:
            click.secho(f'Gateway returned status code {resp.status_code}', fg='red', err=True)
            ctx.exit(1)
    except Exception as e:
        click.secho(f'Failed to connect to gateway: {str(e)}', fg='red', err=True)
        click.secho(f'Ensure gateway at {resolved_dut} is online and reachable', fg='yellow', err=True)
        ctx.exit(1)

# """
#     lager.hello.commands

#     Say hello to gateway or DUT
# """
# import click
# from ..context import get_impl_path, get_default_gateway
# from ..python.commands import run_python_internal
# from ..dut_storage import get_dut_ip

# @click.command()
# @click.pass_context
# @click.option("--box", required=False, help="Lagerbox name or IP")
# @click.option('--dut', required=False, hidden=True, help='ID of DUT or saved DUT name')
# def hello(ctx, dut):
#     """
#         Say hello to gateway or DUT
#     """
#     dut_name = dut  # Save the original DUT name
#     dut_ip = None
#
#     # If dut is provided, check if it's a saved DUT name
#     if dut:
#         saved_ip = get_dut_ip(dut)
#         if saved_ip:
#             # Use the saved IP address for direct connection
#             dut_ip = saved_ip
#             dut = saved_ip
#     else:
#         # Get default gateway
#         dut = get_default_gateway(ctx)
#         # Check if the default gateway is a saved DUT name
#         if dut:
#             saved_ip = get_dut_ip(dut)
#             if saved_ip:
#                 dut_name = dut
#                 dut_ip = saved_ip
#                 dut = saved_ip
#
#     # For direct IP connections, try ping to verify connectivity
#     if dut_ip:
#         try:
#             import subprocess
#             # Try to ping the device to verify connectivity
#             result = subprocess.run([
#                 'ping', '-c', '3', '-W', '2000', dut_ip
#             ], capture_output=True, text=True, timeout=10)
#
#             if result.returncode == 0:
#                 if dut_name:
#                     click.echo(f'Hello from DUT {dut_name} ({dut_ip})! Your gateway is reachable via Tailscale.')
#                 else:
#                     click.echo(f'Hello from DUT {dut_ip}! Your gateway is reachable via Tailscale.')
#             else:
#                 click.secho(f'Failed to reach DUT {dut_ip}', fg='red', err=True)
#                 if result.stderr:
#                     click.echo(result.stderr.strip())
#         except subprocess.TimeoutExpired:
#             click.secho(f'Ping t o DUT {dut_ip} timed out', fg='red', err=True)
#         except Exception as e:
#             click.secho(f'Error connecting to DUT {dut_ip}: {str(e)}', fg='red', err=True)
#     else:
#         # Use the original Python script for regular gateway connection
#         # Pass DUT name and IP as arguments
#         args = []
#         if dut_name:
#             args.append(dut_name)
#         if dut:
#             args.append(dut)
#
#         run_python_internal(
#             ctx,
#             get_impl_path('hello.py'),
#             dut,
#             image='',
#             env=(),
#             passenv=(),
#             kill=False,
#             download=(),
#             allow_overwrite=False,
#             signum='SIGTERM',
#             timeout=0,
#             detach=False,
#             port=(),
#             org=None,
#             args=tuple(args),
#         )
