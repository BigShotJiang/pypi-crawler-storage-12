## 0.1.1 (2025-11-16)

### Feat

- fastapi inject decorator
