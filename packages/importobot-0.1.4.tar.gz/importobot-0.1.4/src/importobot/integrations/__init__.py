"""Integration adapters for external systems."""

from . import clients

__all__ = ["clients"]
