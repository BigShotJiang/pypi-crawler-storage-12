from .extension import PermissionExtension

__all__ = [
    "PermissionExtension",
]
