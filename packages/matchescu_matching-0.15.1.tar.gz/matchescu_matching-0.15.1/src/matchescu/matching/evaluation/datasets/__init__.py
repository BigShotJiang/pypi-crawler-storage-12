from matchescu.matching.evaluation.datasets._magellan import (
    MagellanDataset,
    MagellanTraits,
)


__all__ = ["MagellanDataset", "MagellanTraits"]
