# matching
Common types and algorithms used for matching two information

The library uses `git@github.com:usc-isi-i2/ppjoin.git@0.2.0` for its `ppjoin`
matcher. It needs to be installed separately.