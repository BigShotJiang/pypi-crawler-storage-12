# Stor4Build Modeling Tool Documentation

The main documentation of the tool is available in the top-level README.md file. Additional documentation is stored here.
