

###### (Automatically generated documentation)

# Add CSV Output

## Description
Enable CSV outputs.

## Modeler Description
Enable CSV outputs.

## Measure Type
ModelMeasure

## Taxonomy


## Arguments




This measure does not have any user arguments



