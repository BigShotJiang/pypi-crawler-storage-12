# Add DX Coil Outputs

## Description
Add the output variables needed to compare to the DX coil TES system.

## Modeler Description
Add the output variables needed to compare to the DX coil TES system.

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Report at hourly frequency.

**Name:** hourly,
**Type:** Boolean,
**Units:** ,
**Required:** false,
**Model Dependent:** false
