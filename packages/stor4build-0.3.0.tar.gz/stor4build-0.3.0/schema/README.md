# Stor4Build Modeling Tool API Input Schema

The input schema for the flask API is stored here. It can be regenerated using the `print-schema.py` script in the `scripts` directory.
