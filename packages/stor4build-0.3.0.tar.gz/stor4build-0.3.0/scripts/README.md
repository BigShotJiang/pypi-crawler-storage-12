# Stor4Build Modeling Tool Stand-Alone Scripts

Scripts used for testing and setup are stored here. Check the individual script file for a description of what the script does.
