export FLASK_TIMESCALE_HOST="localhost"
export FLASK_TIMESCALE_DB="tessbed"
export FLASK_TIMESCALE_USERNAME="postgres"
export FLASK_TIMESCALE_PASSWORD="postgres"
