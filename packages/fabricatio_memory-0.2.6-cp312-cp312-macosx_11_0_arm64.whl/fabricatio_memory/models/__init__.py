"""Models defined in fabricatio-memory."""
