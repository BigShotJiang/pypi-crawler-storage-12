QUERYSET = 'queryset'  # QuerySet
