MULTIPLE_OBJECTS_ERROR = 'Expected one, but returned multiple objects.'
NOT_FOUND_ERROR = 'Not found.'
