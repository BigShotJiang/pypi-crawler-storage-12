from .base import BaseOperationResult, StoreOperationResultInMeta, ReturnAsOperationResult

__all__ = (
    "BaseOperationResult",
    "StoreOperationResultInMeta",
    "ReturnAsOperationResult",
)
