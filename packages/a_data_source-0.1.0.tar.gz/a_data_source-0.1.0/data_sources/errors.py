class NotSingleEntityError(Exception):
    pass
