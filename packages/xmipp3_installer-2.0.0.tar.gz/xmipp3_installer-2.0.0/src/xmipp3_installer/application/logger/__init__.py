"""
### Logger Module.

This module provides logging functionalities for the Xmipp installer.
"""
