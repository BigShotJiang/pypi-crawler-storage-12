"""### System's entry point."""

from xmipp3_installer.application.cli.cli import main

if __name__ == "__main__":
  main()
