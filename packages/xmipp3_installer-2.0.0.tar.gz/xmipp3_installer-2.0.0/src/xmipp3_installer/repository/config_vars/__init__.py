"""
### Configuration Variables Module.

This module contains configuration variables used throughout the application.
"""
