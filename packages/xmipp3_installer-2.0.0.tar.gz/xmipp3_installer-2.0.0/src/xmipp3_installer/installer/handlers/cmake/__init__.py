"""### Contains CMake handler & different related constants."""
