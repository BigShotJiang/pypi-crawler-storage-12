from .core import TextInsight

__version__ = "1.0.0"
__all__ = ["TextInsight"]
