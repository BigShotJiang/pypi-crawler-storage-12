
# amberNPS-api


amperNPS-api is a convenient python API to make lethal blood concentrations (LBC) of new psychoactive substances (NPS). 

[amberNPS](https://ambernps.streamlit.app/) is a streamlit application developed by Tarcisio Nascimento Correa. 

For further details please the publication at [A QSAR-based application for the prediction of lethal blood concentration of new psychoactive substances](https://www.sciencedirect.com/science/article/pii/S2667118224000151)

## Installation

Install amberNPS with pip:

```shell
pip install amberNPS
```

## More docs to come
