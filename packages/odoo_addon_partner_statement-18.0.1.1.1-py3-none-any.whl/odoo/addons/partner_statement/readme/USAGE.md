To use this module, you need to:

1.  Go to a list of Partners, Contacts, Customer or Vendors and select
    one or more.
2.  Press 'Action \> Partner Activity Statement' or 'Action \> Partner
    Outstanding Statement' respectively.
3.  Indicate if you want to display receivables or payables, and if you
    want to display aging buckets and the aging type.
4.  Optionally complete advanced options such as filtering non due or
    negative balance partners.
