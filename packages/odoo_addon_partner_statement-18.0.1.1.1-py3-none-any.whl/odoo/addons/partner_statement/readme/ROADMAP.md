- Email template.
- Expose reports (using defaults) to billing users while restricting the
  wizard to managers option.
- Concept of statement run - to start an async job to send out all
  statements.
