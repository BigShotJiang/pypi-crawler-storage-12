---
description: Translation prompt
source_lang: Source language
target_lang: Target language
text: Text to translate
style: Translation style (formal/casual)
---
Translate the following text from {source_lang} to {target_lang}.

Translation style: {style}

Text to translate:
{text}

Provide only the translation without explanations.
