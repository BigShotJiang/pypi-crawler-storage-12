---
description: Friendly chat user message
message: User message
---
{message} 😊