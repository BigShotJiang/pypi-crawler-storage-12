---
description: Professional chat user message
message: User message
---
{message}