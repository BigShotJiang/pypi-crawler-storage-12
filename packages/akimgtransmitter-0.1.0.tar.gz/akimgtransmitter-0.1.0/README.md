# akimgtransmitter

Tiny image-frame transmitter that writes the latest frame as `frame.png` into a folder.

## Install (local test)
From the project root (the folder containing `setup.py`):

```bash
pip install .
# or editable mode for development
pip install -e .
