# akimgtransmitter/__init__.py
from .core import transmit_image

__all__ = ["transmit_image"]
