from mewo_ovhcloud import cmd as cmd



from mewo_ovhcloud.lib import *
