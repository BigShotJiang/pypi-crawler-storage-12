"""Top-level package for thanos_cli."""

__author__ = """Soldatov Serhii"""
__email__ = "soldatov.own@gmail.com"
