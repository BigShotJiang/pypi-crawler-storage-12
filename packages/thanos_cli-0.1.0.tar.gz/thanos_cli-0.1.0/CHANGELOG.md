# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2025-XX-XX

### Added
- Initial release
- Random file elimination (50% of files)
- Dry run mode
- Recursive directory support
- Interactive confirmation
- Beautiful CLI with Typer

[0.1.0]: https://github.com/soldatov-ss/thanos/releases/tag/v0.1.0
