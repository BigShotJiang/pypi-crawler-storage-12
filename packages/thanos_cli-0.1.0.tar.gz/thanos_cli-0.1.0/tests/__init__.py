"""Unit test package for thanos_cli."""
