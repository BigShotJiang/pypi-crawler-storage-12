# Welcome to thanos's documentation!

## Contents

- [Readme](../readme.md)
- [Installation](installation.md)
- [Usage](usage.md)

