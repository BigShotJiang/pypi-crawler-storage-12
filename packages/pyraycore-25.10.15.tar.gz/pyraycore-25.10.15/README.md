# pyraycore

**pyraycore** — это Python-биндинги для [Xray-core](https://github.com/XTLS/Xray-core) через gRPC.  
Позволяет вызывать методы Xray прямо из Python-кода, без боли и шаманства с протобафами вручную.

---

## 🚀 Установка

```bash
pip install pyraycore
