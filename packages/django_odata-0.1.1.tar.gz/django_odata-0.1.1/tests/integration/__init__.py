"""
Integration tests for django-odata.

These tests verify that multiple components work together correctly
and test end-to-end functionality with database interactions.
"""
