"""
Support files for django-odata integration tests.

This package contains Django configuration and models
specifically for integration testing.
"""
