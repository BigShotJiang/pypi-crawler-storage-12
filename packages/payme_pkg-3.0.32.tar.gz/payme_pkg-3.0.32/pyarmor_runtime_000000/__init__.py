# Pyarmor 9.2.0 (trial), 000000, 2025-11-16T12:37:49.709239
from .pyarmor_runtime import __pyarmor__
