class Translation:
    
    # 获取翻译语言
    def get_language(self):
        return {
            "name": "",
            "value": ""
        }


    def translate(self):
        return {
            "text": "",
            "translate_text": ""
        }