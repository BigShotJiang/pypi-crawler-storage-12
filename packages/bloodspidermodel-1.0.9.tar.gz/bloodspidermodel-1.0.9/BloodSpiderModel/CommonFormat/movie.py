class MovieForm:
    
    # 卡片展示信息
    def show_card_info(self):
        return {
            "movie_name": "",
            "movie_info_url": "",
            "movie_cover_url": "",
        }