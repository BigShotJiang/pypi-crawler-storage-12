Source code for `gsrap`.
