"""Device class implementations for VeSync devices."""
