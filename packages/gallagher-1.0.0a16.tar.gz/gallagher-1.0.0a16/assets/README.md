# Gallagher Python Toolkit Assets

This directory contains assets for the Gallagher Python Toolkit project. There are two types of files found in here:

- Screenshots from the Command Centre application
- Branding assets for the project

The screenshots are used for documentation purposes and are copyright of Gallagher Group Limited.

The branding assets are used for the project's logo and are copyright of the project's maintainers.

> [!WARNING]
> Please seek appropriate permission before referencing or reusing any of the assets in this directory.
