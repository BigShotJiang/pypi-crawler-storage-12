# SQL and SQLAlchemy

## Shillelagh

### Querying

### Filtering

### Using ORDER, LIMIT, OFFSET

## SQLAlchemy dialect

### Virtual Tables
