"""


"""

from textual.containers import (
    Container,
)


class Dashboard(Container):
    pass
