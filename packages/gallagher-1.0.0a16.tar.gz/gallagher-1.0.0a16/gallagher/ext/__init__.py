""" Extensions package for building upon other frameworks

This package provides extensions around framewokrs like shillelagh
that allow us to extend functionality like a SQL interface to
the package.


It's recommdend that we list the package that ext provides for 
developers to understand what is possible and in what context.

- [shillelagh](https://youtu.be/85ztwhfyQ-k?feature=shared&t=14) 
  how to pronounce

"""
