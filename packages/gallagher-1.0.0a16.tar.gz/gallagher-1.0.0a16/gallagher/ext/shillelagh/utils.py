""" Utilities to help Shillelagh CLI commands
"""