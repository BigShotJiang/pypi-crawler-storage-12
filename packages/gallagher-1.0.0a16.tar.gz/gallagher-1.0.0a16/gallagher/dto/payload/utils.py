""" Payload builder helpers





"""

from pydantic import BaseModel, URL

class BaseRequestPayloadBuilder(BaseModel):
    pass