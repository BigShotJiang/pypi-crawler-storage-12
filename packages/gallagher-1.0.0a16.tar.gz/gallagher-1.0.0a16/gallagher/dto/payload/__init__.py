""" Data Payloads for mutating the API

"""

from .alarms import (
    AlarmCommentPayload,
)
