""" Summary models for Cards and annex information
"""

from typing import Optional

from ..utils import (
    AppBaseModel,
    IdentityMixin,
)
