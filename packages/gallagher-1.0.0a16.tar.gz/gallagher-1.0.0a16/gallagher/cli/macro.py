""" Marco


"""

from .utils import AsyncTyper


app = AsyncTyper(help="Macro search, summary")
