""" Receptions

"""

from .utils import AsyncTyper


app = AsyncTyper(help="Receptions")
