""" Interlock group

"""

from .utils import AsyncTyper


app = AsyncTyper(help="Interlock")
