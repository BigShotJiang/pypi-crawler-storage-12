""" Personal Data Definitions


"""

from .utils import AsyncTyper


app = AsyncTyper(help="Query personal data definitions")
