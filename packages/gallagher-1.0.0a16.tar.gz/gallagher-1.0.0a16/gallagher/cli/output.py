""" Output

"""

from .utils import AsyncTyper


app = AsyncTyper(help="Output")
