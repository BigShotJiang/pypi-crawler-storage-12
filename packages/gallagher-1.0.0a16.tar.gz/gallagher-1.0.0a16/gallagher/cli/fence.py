""" Fence Zone


"""

from .utils import AsyncTyper

app = AsyncTyper(help="Query fence zone")
