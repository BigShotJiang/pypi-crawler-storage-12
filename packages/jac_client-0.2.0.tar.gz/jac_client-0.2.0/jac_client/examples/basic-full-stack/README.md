# basic-full-stack

make sure node modules are installed:
```bash
npm install
```


## Running Jac Code


To run your Jac code, use the Jac CLI:

```bash
jac serve app.jac
```

Happy coding with Jac!
