from datetime import timedelta

REDIRECTION_LOG_RETENTION_TIMEDELTA: timedelta = timedelta(days=30)
