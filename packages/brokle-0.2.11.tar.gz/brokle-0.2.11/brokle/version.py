"""Brokle OpenTelemetry SDK version."""

__version__ = "0.2.11"
__version_info__ = tuple(int(x) for x in __version__.split("-")[0].split("."))
