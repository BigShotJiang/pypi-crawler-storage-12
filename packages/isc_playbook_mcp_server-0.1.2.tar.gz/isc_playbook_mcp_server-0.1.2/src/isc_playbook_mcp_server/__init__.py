"""
IBM ISC Playbook MCP Server
Provides hybrid search (semantic + keyword) for IBM ISC Playbook documentation.
"""

__version__ = "0.1.0"
