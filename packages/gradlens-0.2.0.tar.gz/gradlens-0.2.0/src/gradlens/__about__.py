# SPDX-FileCopyrightText: 2025-present im-mahdi-74 <mahdi.mosavi.nsa@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.2.0"
