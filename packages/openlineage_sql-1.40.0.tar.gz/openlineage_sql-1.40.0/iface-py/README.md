# Python interface for the OpenLineage SQL Parser

Refer to the [GitHub for details](https://github.com/OpenLineage/OpenLineage). This package is not meant to be used alone by end-user.

