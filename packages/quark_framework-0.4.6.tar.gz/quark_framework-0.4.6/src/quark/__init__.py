from quark.__main__ import start


def entrypoint():
    start()
