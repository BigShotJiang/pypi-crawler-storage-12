from .__main__ import main


def run():
    main("ffdl")
