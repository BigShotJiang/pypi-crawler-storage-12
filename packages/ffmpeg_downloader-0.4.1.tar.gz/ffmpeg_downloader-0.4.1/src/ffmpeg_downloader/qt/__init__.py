from .wizard import InstallFFmpegWizard

__all__ = ["InstallFFmpegWizard"]
