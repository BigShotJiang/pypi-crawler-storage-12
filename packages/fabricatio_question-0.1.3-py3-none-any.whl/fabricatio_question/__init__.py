"""An extension of fabricatio, which provide the capability to question user to make better planning and etc.."""
