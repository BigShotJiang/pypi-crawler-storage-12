"""Capabilities defined in fabricatio-question."""
