> Данная библиотека НЕ является официальной, и не пытается ей казаться. Данная библиотека разрабатывается исключительно в личных интересах, и использует только общедоступные endpoint'ы.

## Возможности
- Асинхронная архитектура (`asyncio`, `aiohttp`)
- Поддержка пикового измерения скорости (реальные пиковые Mbps, как в браузере)
- Умное использование проб (probes) с серверов Яндекса
- Полная типизация (через `pydantic`)
- Поддержка измерений **Download**, **Upload**, **Latency**
- Совместимость с Python 3.11+
- Возможность интеграции в любые системы мониторинга или DevOps пайплайны

## Пример использования
```python
import asyncio
from yaspeedtest.client import YaSpeedTest

async def main():
    ya = await YaSpeedTest.create()
    result = await ya.run()

    print(f"Ping: {result.ping_ms:.2f} ms")
    print(f"Download: {result.download_mbps:.2f} Mbps")
    print(f"Upload: {result.upload_mbps:.2f} Mbps")

asyncio.run(main())

# Ping: 1.84 ms
# Download: 939.17 Mbps
# Upload: 870.29 Mbps
```

## Как это работает
1. Клиент делает запрос к Яндекс
1. Сервер возвращает набор доступных probe-серверов (latency, download, upload)
1. Для каждого типа выполняются асинхронные измерения:
   - Latency — последовательные пинги к малым ресурсам (latency probes)
   - Download — скачивание файлов
   - Upload — отправка данных
1. Результаты агрегируются в объект SpeedResult, содержащий:
   - Минимальный пинг
   - Пиковую скорость загрузки
   - Пиковую скорость отдачи

### 🧩 Более подробная документация доступна по посылке GitHub [ErilovNikita/yaspeedtest](https://github.com/ErilovNikita/yaspeedtest)