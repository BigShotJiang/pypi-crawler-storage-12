
# PV_Live-API
A Python implementation of the PV_Live web API. See https://www.solar.sheffield.ac.uk/pvlive/

**Latest Version: 1.5.2**

## About this repository

* This Python library provides a convenient interface for the PV_Live web API to facilitate accessing PV_Live results in Python code.
* Developed and tested with Python 3.12, should work with Python 3.10+.

## About PV_Live

PV_Live is a service providing generation estimates for solar photovoltaic (PV) systems connected to the GB electricity network. The service, and the methodology behind it, were developed as a collaboration between the Sheffield Solar research project at The University of Sheffield and the National Energy System Operator (NESO). The service continues to be funded by NESO to ensure the data PV_Live provides can remain open and free to access.

There are two PV_Live models for GB: National and Regional, both of which estimate PV generation at a half-hourly temporal resolution. The national model provides an estimate of the total generation from solar PV systems across the GB electricity network which do not participate in the Balancing Mechanism. The regional model is more geographically-resolved and provides PV generation estimates aggregated by Grid Supply Point (GSP) or DNO License Area (a.k.a PES region).

The Balancing mechanism (BM) is NESO’s primary tool to balance supply and demand on GB’s electricity network. In the Electricity National Control Centre (ENCC), NESO use the BM to buy and procure the right amount of electricity required to balance the system. Participants to the BM are referred to as Balancing Mechanism Units (BMUs) - BMUs are dispatchable and also supplied operational metering directly to NESO. As such, Solar PV BMUs are excluded from the PV_Live outturn estimates, to avoid double counting. Generation data for solar BMUs can be accessed via Elexon (see "settlement metering").

In the regional PV_Live data, GSPs are given arbitrary integer IDs called `gsp_id`. The corresponding name(s) for the GSPs are supplied by the `/gsp_list` API endpoint (see Code Examples below). An equivalent system is used for the PV outturns by DNO License Area - the DNO License Area outturns are identified by `pes_id`, with the string names for the DNO License Areas being supplied by the `/pes_list` API endpoint. For a full list of GSPs and PES regions, and the geographical regions they supply, refer to the GIS datasets hosted on NESO's data portal:

- [GIS Boundaries for GB Grid Supply Points](https://www.neso.energy/data-portal/gis-boundaries-gb-grid-supply-points)
- [GIS Boundaries for GB DNO License Areas](https://www.neso.energy/data-portal/gis-boundaries-gb-dno-license-areas).

## How do I get set up?

* Run either:
    * `pip install pvlive-api`
    * `pip install git+https://github.com/SheffieldSolar/PV_Live-API`
	    * (you'll need to have Git installed for this to work - see https://git-scm.com/downloads)







## Usage

As of 2025-07-07, the production PV_Live API is hosted on Google Cloud Platform (GCP) at https://api.pvlive.uk. There is also a non-prod test/fix-on-fail environment hosted on TUOS IT: https://api.solar.sheffield.ac.uk. To support switching between the two, the `pvlive-api` package exposes a parameter `domain_url`, which can be set to one of `["api.pvlive.uk", "api.solar.sheffield.ac.uk"]` but defaults to `api.pvlive.uk`.

You can interact with the PV_Live API by importing the PVLive class and instantiating as follows:

```Python
from pvlive_api import PVLive

pvl = PVLive(
    retries=3, # Optionally set the number of retries when intermittent issues are encountered
    proxies=None, # Optionally pass a dict of proxies to use when making requests
    ssl_verify=True, # Optionally disable SSL certificate verification (not advised!)
    domain_url="api.pvlive.uk", # Optionally switch between the prod and FOF APIs
)
```

The `PVLive` class exposes three methods for extracting raw data from the PV_Live API:

|Method|Description|Docs Link|
|------|-----------|---------|
|`PVLive.latest(entity_type="pes", entity_id=0, extra_fields="", period=30, dataframe=False)`|Get the latest PV_Live generation result from the API.|[&#128279;](https://sheffieldsolar.github.io/PV_Live-API/build/html/modules.html#pvlive_api.pvlive.PVLive.latest)|
|`PVLive.at_time(dt, entity_type="pes", entity_id=0, extra_fields="", period=30, dataframe=False)`|Get the PV_Live generation result for a given time from the API.|[&#128279;](https://sheffieldsolar.github.io/PV_Live-API/build/html/modules.html#pvlive_api.pvlive.PVLive.at_time)|
|`PVLive.between(start, end, entity_type="pes", entity_id=0, extra_fields="", period=30, dataframe=False)`|Get the PV_Live generation result for a given time interval from the API.|[&#128279;](https://sheffieldsolar.github.io/PV_Live-API/build/html/modules.html#pvlive_api.pvlive.PVLive.between)|

There are also two methods for extracting derived statistics:

|Method|Description|Docs Link|
|------|-----------|---------|
|`PVLive.day_peak(d, entity_type="pes", entity_id=0, extra_fields="", period=30, dataframe=False)`|Get the peak PV_Live generation result for a given day from the API.|[&#128279;](https://sheffieldsolar.github.io/PV_Live-API/build/html/modules.html#pvlive_api.pvlive.PVLive.day_peak)|
|`PVLive.day_energy(d, entity_type="pes", entity_id=0)`|Get the cumulative PV generation for a given day from the API.|[&#128279;](https://sheffieldsolar.github.io/PV_Live-API/build/html/modules.html#pvlive_api.pvlive.PVLive.day_energy)|

These methods include the following optional parameters:

|Parameter|Usage|
|---------|-----|
|`entity_type`|Choose between `"pes"` or `"gsp"`. If querying for national data, this parameter can be set to either value (or left to it's default value) since setting `entity_id` to `0` will always return national data.|
|`entity_id`|Set `entity_id=0` (the default value) to return nationally aggregated data. If `entity_type="pes"`, specify a _pes_id_ to retrieve data for, else if `entity_id="gsp"`, specify a _gsp_id_.|
|`extra_fields`|Use this to extract additional fields from the API such as _installedcapacity_mwp_. For a full list of available fields, see the [PV_Live API Docs](https://api.pvlive.uk/pvlive/docs).|
|`dataframe`|Set `dataframe=True` and the results will be returned as a Pandas DataFrame object which is generally much easier to work with. The columns of the DataFrame will be _pes_id_ or _gsp_id_, _datetime_gmt_, _generation_mw_, plus any extra fields specified.|

There is also a method for extracting PV deployment (a.k.a capacity) data:
|Method|Description|Docs Link|
|------|-----------|---------|
|`PVLive.deployment(region="gsp", include_history=False, by_system_size=False, release=0)`|Download PV deployment datasets from the API.|[&#128279;](https://sheffieldsolar.github.io/PV_Live-API/build/html/modules.html#pvlive_api.pvlive.PVLive.deployment)|


## Code Examples

See [pvlive_api_demo.py](https://github.com/SheffieldSolar/PV_Live-API/blob/master/pvlive_api_demo.py) for more example usage.

|Example|Code|Example Output|
|-------|----|------|
|Get the latest nationally aggregated GB PV outturn|`pvl.latest()`|`(0, '2021-01-20T11:00:00Z', 203.0)`|
|Get the latest aggregated outturn for **PES** region **23** (Yorkshire)|`pvl.latest(entity_id=23)`|`(23, '2021-01-20T14:00:00Z', 5.8833031)`
|Get the latest aggregated outturn for **GSP** ID **152** (INDQ1 or "Indian Queens")|`pvl.latest(entity_type="gsp", entity_id=152)`|`(152, '2021-01-20T14:00:00Z', 1, 3.05604)`
|Get the nationally aggregated GB PV outturn for all of 2020 as a DataFrame|`pvl.between(start=datetime(2020, 1, 1, 0, 30, tzinfo=pytz.utc), end=datetime(2021, 1, 1, tzinfo=pytz.utc), dataframe=True)`|![Screenshot of output](https://raw.githubusercontent.com/SheffieldSolar/PV_Live-API/master/misc/code_example_output.png)|
|Get a list of GSP IDs|`pvl.gsp_ids`|`array([  0,   1,   2,   3,   ..., 315, 316, 317])`|
|Get a list of PES IDs|`pvl.pes_ids`|`array([  0,  10,  11,  12,   ...,  21,  22,  23])`|

To download data for all GSPs, use something like:

```python
def download_pvlive_by_gsp(start, end, include_national=True, extra_fields=""):
    data = None
    pvl = PVLive()
    min_gsp_id = 0 if include_national else 1
    for gsp_id in pvl.gsp_ids:
        if gsp_id < min_gsp_id:
            continue
        data_ = pvl.between(
            start=start,
            end=end,
            entity_type="gsp",
            entity_id=gsp_id,
            dataframe=True,
            extra_fields=extra_fields
        )
        if data is None:
            data = data_
        else:
            data = pd.concat((data, data_), ignore_index=True)
    return data
```

## Command Line Utilities

### pv_live

This utility can be used to download data to a CSV file:

```
>> pv_live -h
usage: pv_live [-h] [-s "<yyyy-mm-dd HH:MM:SS>"] [-e "<yyyy-mm-dd HH:MM:SS>"]
               [--entity_type <entity_type>] [--entity_id <entity_id>]
               [--extra_fields <field1[,field2, ...]>] [--period <5|30>] [-q]
               [-o </path/to/output/file>] [-http <http_proxy>] [-https <https_proxy>]

This is a command line interface (CLI) for the PV_Live API module

options:
  -h, --help            show this help message and exit
  -s "<yyyy-mm-dd HH:MM:SS>", --start "<yyyy-mm-dd HH:MM:SS>"
                        Specify a UTC start date in 'yyyy-mm-dd HH:MM:SS' format
                        (inclusive), default behaviour is to retrieve the latest outturn.
  -e "<yyyy-mm-dd HH:MM:SS>", --end "<yyyy-mm-dd HH:MM:SS>"
                        Specify a UTC end date in 'yyyy-mm-dd HH:MM:SS' format (inclusive),
                        default behaviour is to retrieve the latest outturn.
  --entity_type <entity_type>
                        Specify an entity type, either 'gsp' or 'pes'. Default is 'gsp'.
  --entity_id <entity_id>
                        Specify an entity ID, default is 0 (i.e. national).
  --extra_fields <field1[,field2, ...]>
                        Specify an extra_fields (as a comma-separated list to include when
                        requesting data from the API, defaults to 'installedcapacity_mwp'.
  --period <5|30>       Desired temporal resolution (in minutes) for PV outturn estimates.
                        Default is 30.
  -q, --quiet           Specify to not print anything to stdout.
  -o </path/to/output/file>, --outfile </path/to/output/file>
                        Specify a CSV file to write results to.
  -http <http_proxy>, --http-proxy <http_proxy>
                        HTTP Proxy address
  -https <https_proxy>, --https-proxy <https_proxy>
                        HTTPS Proxy address

Jamie Taylor & Ethan Jones, 2018-06-04
```

## Using the Docker Image

There is also a Docker Image hosted on Docker Hub which can be used to download data from the PV_Live API with minimal setup:

```
>> docker run -it --rm sheffieldsolar/pv_live-api:<release> pv_live -h
```

## Documentation

API reference documentation for this Python package is available here: [https://sheffieldsolar.github.io/PV_Live-API/](https://sheffieldsolar.github.io/PV_Live-API/)

Documentation for the PV_Live REST API is available here: [https://api.pvlive.uk/pvlive/docs](https://api.pvlive.uk/pvlive/docs)

## How do I upgrade?

Sheffield Solar will endeavour to update this library in sync with the [PV_Live API](https://www.solar.sheffield.ac.uk/api/ "PV_Live API webpage") and ensure the latest version of this library always supports the latest version of the PV_Live API, but cannot guarantee this. To make sure you are forewarned of upcoming changes to the API, you should email [solar@sheffield.ac.uk](mailto:solar@sheffield.ac.uk?subject=PV_Live%20API%20email%20updates "Email Sheffield Solar") and request to be added to the PV_Live user mailing list.

To upgrade the code:
* Run `pip install --upgrade pvlive-api`

## Notes on PV_Live GB national update cycle

Users should be aware that Sheffield Solar computes continuous retrospective updates to PV_Live outturn estimates i.e. we regularly re-calculate outturn estimates retrospectively and these updated estimates are reflected immediately in the data delivered via the API.

As of 2023-05-02, the first estimate of the PV outturn for a given settlement period is computed ~5 minutes after the end of the half hour in question and is typically available via the API within 6 minutes

e.g. the initial estimate of the GB PV outturn for the period 14:30 - 15:00 UTC on 2023-05-02 (i.e. 15:30 - 16:00 BST) would become available at ~16:06 BST on 2023-05-02 and will be labelled using the timestamp at the end of the interval (in UTC): '2023-05-02 15:00:00'

This outturn estimate is not final though - Sheffield Solar will continue to make retrospective revisions as

- more PV sample data becomes available
- better PV deployment data becomes available
- the PV_Live methodology is refined

Since the PV_Live model produces outturn estimates, they will never strictly speaking be final, as there will always be things we can do to refine the model and improve accuracy. That said, there are some notable/routine retrospective revisions to be aware of:

- Outturns are re-computed in near-real-time every 5 minutes after the end of the half-hour for 3 hours, to allow for late arriving sample data
    - If all data ingestion pipelines are running smoothly, this does not result in any retrospective revisions
    - If some near-real-time sample data is late arriving, the outturn estimate will be revised at the next update
- Outturns are re-computed on day+1 (typically between 10:30 and 10:35 and again between 22:30 and 22:35) to make use of sample data which only becomes available on day+1
- Historical outturns may be re-computed periodically whenever our PV deployment dataset is updated retrospectively (usually every 3 - 6 months)

In order to maintain a local copy of the PV_Live GB national outturn estimates that is as in sync with our own latest/best estimates as possible, we recommend the following polling cycle:

- Every 5 minutes, pull the last 3 hours of outturns from the API
- Every day, around 11am, re-download the previous 3 days of outturns
- Every month, re-download all historical outturns

To make it easier to re-ingest historical data without duplication, PV_Live API users can request the `updated_gmt` field in the API response (by setting the `extra_fields`  parameter). The `updated_gmt` field can be used to determine if an outturn estimate has changed since the API was last polled. For example, one could treat `("gsp_id", "datetime_gmt", "updated_gmt")` as the primary key in one's own copy of the PV_Live outturns data and thereby avoid the need to re-ingest identical data. For more help designing an optimal ingestion design for PV_Live data, feel free to [contact Sheffield Solar](https://www.solar.sheffield.ac.uk/contact-us/).

## Who do I talk to?

[Contact Sheffield Solar](https://www.solar.sheffield.ac.uk/contact-us/)

The PV_Live-API package is developed and maintained by several members of the [SheffieldSolar](https://github.com/SheffieldSolar) team:
* [Jamie Taylor](https://github.com/JamieTaylor-TUOS)
* [Herald Olakkengil](https://github.com/Herald-TUOS)
* [Andrew Richards](https://github.com/AndrewCRichards)

### Original Authors

* [Jamie Taylor](https://github.com/JamieTaylor-TUOS)
* [Ethan Jones](https://github.com/ejones18)

## How do I contribute?

You can contribute to this repo in two ways:
- Submit an Issue [here](https://github.com/SheffieldSolar/PV_Live-API/issues) and one of the team will respond as soon as they can
- Submit a PR [here](https://github.com/SheffieldSolar/PV_Live-API/pulls) and one of the team will review it as soon as they can

## License

The PV_Live-API Python package uses the [GNU GENERAL PUBLIC LICENSE Version 3](https://choosealicense.com/licenses/gpl-3.0/).
