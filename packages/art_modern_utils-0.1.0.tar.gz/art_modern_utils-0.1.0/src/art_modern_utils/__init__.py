__version__ = "0.1.0"

QUAL_MAX = 71
