from .darn_it import *

__doc__ = darn_it.__doc__
if hasattr(darn_it, "__all__"):
    __all__ = darn_it.__all__