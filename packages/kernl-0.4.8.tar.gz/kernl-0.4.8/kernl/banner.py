from art import text2art

def display_banner():
    print(text2art("Kernl", font="isometric1"))