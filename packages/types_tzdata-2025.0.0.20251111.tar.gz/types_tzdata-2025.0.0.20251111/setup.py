
from setuptools import setup

setup(package_data={'tzdata-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
