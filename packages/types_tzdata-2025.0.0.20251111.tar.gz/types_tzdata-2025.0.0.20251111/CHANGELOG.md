## 2025.0.0.20251111 (2025-11-11)

[tzdata] Add package stubs ([#14997](https://github.com/python/typeshed/pull/14997))

