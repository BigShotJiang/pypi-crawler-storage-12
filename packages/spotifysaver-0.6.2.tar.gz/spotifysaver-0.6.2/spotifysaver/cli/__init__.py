"""SpotifySaver CLI package initialization."""

from spotifysaver.cli.cli import cli

__all__ = ["cli"]
