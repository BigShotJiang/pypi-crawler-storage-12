"""SpotifySaver CLI Download Command."""

from spotifysaver.cli.commands.download.download import download

__all__ = ["download"]
