"""SpotifySaver CLI Log Command"""

from spotifysaver.cli.commands.log.log import show_log

__all__ = ["show_log"]
