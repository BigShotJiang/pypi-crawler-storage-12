"""SpotifySaver configuration module."""

from spotifysaver.config.setting_environment import Config
