<div align="center">

# pushikoo-interface

Pushikoo plugin interface definition

[![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/Pushikoo/pushikoo-interface/package.yml)](https://github.com/Pushikoo/pushikoo-interface/actions)
[![Python](https://img.shields.io/pypi/pyversions/pushikoo-interface)](https://pypi.org/project/pushikoo-interface)
[![PyPI version](https://badge.fury.io/py/pushikoo-interface.svg)](https://pypi.org/project/pushikoo-interface)
[![License](https://img.shields.io/github/license/Pushikoo/pushikoo-interface.svg)](https://pypi.org/project/pushikoo-interface/)

</div>
