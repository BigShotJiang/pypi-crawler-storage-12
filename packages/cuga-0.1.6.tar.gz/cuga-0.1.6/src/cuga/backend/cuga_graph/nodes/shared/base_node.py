class BaseNode:
    def __init__(self):
        pass
