"""Operations: functional programming utilities and helpers."""
