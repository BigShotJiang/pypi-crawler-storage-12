
# Funcy Bear

[![pypi version](https://img.shields.io/pypi/v/funcy-bear.svg)](https://pypi.org/project/funcy-bear/)

A FP Based Repo

## Installation

```bash
pip install funcy-bear
```

With [`uv`](https://docs.astral.sh/uv/):

```bash
uv tool install funcy-bear
```