# Translation

::: sieves.tasks.predictive.translation
::: sieves.tasks.predictive.translation.bridges