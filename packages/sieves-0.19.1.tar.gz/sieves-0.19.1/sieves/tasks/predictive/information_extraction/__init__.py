"""Information extraction task."""

from .core import FewshotExample, InformationExtraction

__all__ = ["InformationExtraction", "FewshotExample"]
