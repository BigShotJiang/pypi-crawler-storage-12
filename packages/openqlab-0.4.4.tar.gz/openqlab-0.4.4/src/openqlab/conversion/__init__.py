from openqlab.conversion.wavelength import Wavelength
