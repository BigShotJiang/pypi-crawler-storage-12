# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2023 Scipp contributors (https://github.com/scipp)

BUTTON_LAYOUT = {"layout": {"width": "37px", "padding": "0px 0px 0px 0px"}}
