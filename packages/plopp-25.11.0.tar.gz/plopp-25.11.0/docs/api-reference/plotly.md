# Plotly backend

```{eval-rst}
.. currentmodule:: plopp

.. autosummary::
   :toctree: ../generated

   backends.plotly.canvas.Canvas
   backends.plotly.figure.Figure
   backends.plotly.line.Line
```
