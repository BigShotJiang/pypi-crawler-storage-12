# Matplotlib backend

```{eval-rst}
.. currentmodule:: plopp

.. autosummary::
   :toctree: ../generated

   backends.matplotlib.canvas.Canvas
   backends.matplotlib.figure.Figure
   backends.matplotlib.image.Image
   backends.matplotlib.line.Line
   backends.matplotlib.scatter.Scatter
   backends.matplotlib.tiled.Tiled
```
