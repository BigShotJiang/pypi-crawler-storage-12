import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,

  // Enable experimental features if needed
  // Add experimental features here
};

export default nextConfig;
