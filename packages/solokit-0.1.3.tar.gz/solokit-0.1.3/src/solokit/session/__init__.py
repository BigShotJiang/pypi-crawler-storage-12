"""Session management for Solokit workflow."""
