"""VNStock MCP Server - Vietnamese Stock Market Data for Claude Desktop."""

__version__ = "0.1.0"
__author__ = "gahoccode"

from .server import main

__all__ = ["main"]
