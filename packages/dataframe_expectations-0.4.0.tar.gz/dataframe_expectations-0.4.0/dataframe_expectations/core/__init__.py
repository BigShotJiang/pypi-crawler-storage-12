"""Core base classes and interfaces for DataFrame expectations."""

__all__ = []
