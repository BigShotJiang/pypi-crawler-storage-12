"""Column expectations."""

__all__ = []
