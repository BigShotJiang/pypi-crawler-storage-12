orichain.embeddings
===========================

.. automodule:: orichain.embeddings
   :members:
   :undoc-members: 
   :special-members: __init__, __call__
   :exclude-members: model_handler, supported_models
   :show-inheritance:
