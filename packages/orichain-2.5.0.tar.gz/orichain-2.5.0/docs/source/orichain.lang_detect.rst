orichain.lang\_detect
=============================

.. automodule:: orichain.lang_detect
   :members:
   :undoc-members:
   :special-members: __init__, __call__
   :show-inheritance:
