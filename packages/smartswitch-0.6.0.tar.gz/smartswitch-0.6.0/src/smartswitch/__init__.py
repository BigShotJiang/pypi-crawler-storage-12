from .core import Switcher
from .plugin import BasePlugin

__all__ = ["Switcher", "BasePlugin"]
__version__ = "0.6.0"
