"""Transpose view plugin for Pulka."""

from .plugin import TransposeSheet, register

__all__ = ["TransposeSheet", "register"]
