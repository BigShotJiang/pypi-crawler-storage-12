"""
FastAPI Auth Starter Package
A reusable FastAPI starter template with authentication
"""

__version__ = "0.1.1"

