# File: /wefact-python/wefact-python/src/wefact/config.py

DEFAULT_API_URL = "https://api.mijnwefact.nl/v2/"