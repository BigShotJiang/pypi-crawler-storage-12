""" Utility functions and classes shared by many applicaitons that uses apps.core. """
