"""
Custom cradmin stuff for Devilry.

This app **MUST** be added to ``INSTALLED_APPS`` before ``cradmin_legacy``
to ensure our custom cradmin templates are overridden.
"""
