from .runsims import main


def runsims_command(args, logger):
    return main(args, logger)
    