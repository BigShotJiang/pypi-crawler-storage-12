from __future__ import annotations

import json
from unittest.mock import Mock, patch
from django.test import TestCase, RequestFactory
from django.http import HttpResponseForbidden, HttpResponseServerError, HttpResponse

from django_sns_signals.views import sns_webhook
from django_sns_signals.signals import (
    sns_subscription_confirmation,
    sns_unsubscribe_confirmation,
    sns_notification,
)


class SNSWebhookViewTestCase(TestCase):
    def setUp(self):
        self.factory = RequestFactory()

    def test_invalid_json(self):
        request = self.factory.post('/sns/', data='invalid json', content_type='application/json')
        response = sns_webhook(request)

        self.assertIsInstance(response, HttpResponseForbidden)

    def test_signature_validation_failure(self):
        message = {
            'Type': 'Notification',
            'MessageId': '12345',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Message': 'Hello',
        }

        request = self.factory.post(
            '/sns/',
            data=json.dumps(message),
            content_type='application/json'
        )

        with patch('django_sns_signals.views.validator.validate_message') as mock_validate:
            mock_validate.side_effect = ValueError('Invalid signature')
            response = sns_webhook(request)

        self.assertIsInstance(response, HttpResponseForbidden)

    def test_subscription_confirmation_success(self):
        message = {
            'Type': 'SubscriptionConfirmation',
            'MessageId': '12345',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Message': 'You have chosen to subscribe',
            'Timestamp': '2023-01-01T00:00:00.000Z',
            'Token': 'token123',
            'SubscribeURL': 'https://sns.amazonaws.com/subscribe',
        }

        request = self.factory.post(
            '/sns/',
            data=json.dumps(message),
            content_type='application/json'
        )

        with patch('django_sns_signals.views.validator.validate_message'):
            with patch('django_sns_signals.views.urlopen') as mock_urlopen:
                mock_response = Mock()
                mock_response.status = 200
                mock_response.__enter__ = Mock(return_value=mock_response)
                mock_response.__exit__ = Mock(return_value=False)
                mock_urlopen.return_value = mock_response

                response = sns_webhook(request)

        self.assertEqual(response.status_code, 200)

    def test_subscription_confirmation_failure(self):
        message = {
            'Type': 'SubscriptionConfirmation',
            'MessageId': '12345',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Message': 'You have chosen to subscribe',
            'Timestamp': '2023-01-01T00:00:00.000Z',
            'Token': 'token123',
            'SubscribeURL': 'https://sns.amazonaws.com/subscribe',
        }

        request = self.factory.post(
            '/sns/',
            data=json.dumps(message),
            content_type='application/json'
        )

        with patch('django_sns_signals.views.validator.validate_message'):
            with patch('django_sns_signals.views.urlopen') as mock_urlopen:
                mock_response = Mock()
                mock_response.status = 500
                mock_response.__enter__ = Mock(return_value=mock_response)
                mock_response.__exit__ = Mock(return_value=False)
                mock_urlopen.return_value = mock_response

                response = sns_webhook(request)

        self.assertIsInstance(response, HttpResponseServerError)

    def test_unsubscribe_confirmation_success(self):
        message = {
            'Type': 'UnsubscribeConfirmation',
            'MessageId': '12345',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Message': 'You have chosen to unsubscribe',
            'Timestamp': '2023-01-01T00:00:00.000Z',
            'Token': 'token123',
            'SubscribeURL': 'https://sns.amazonaws.com/unsubscribe',
        }

        request = self.factory.post(
            '/sns/',
            data=json.dumps(message),
            content_type='application/json'
        )

        with patch('django_sns_signals.views.validator.validate_message'):
            with patch('django_sns_signals.views.urlopen') as mock_urlopen:
                mock_response = Mock()
                mock_response.status = 200
                mock_response.__enter__ = Mock(return_value=mock_response)
                mock_response.__exit__ = Mock(return_value=False)
                mock_urlopen.return_value = mock_response

                response = sns_webhook(request)

        self.assertEqual(response.status_code, 200)

    def test_notification_success(self):
        message = {
            'Type': 'Notification',
            'MessageId': '12345',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Message': 'Hello World',
            'Timestamp': '2023-01-01T00:00:00.000Z',
            'UnsubscribeURL': 'https://sns.amazonaws.com/unsubscribe',
        }

        request = self.factory.post(
            '/sns/',
            data=json.dumps(message),
            content_type='application/json'
        )

        with patch('django_sns_signals.views.validator.validate_message'):
            response = sns_webhook(request)

        self.assertEqual(response.status_code, 200)

    def test_unknown_message_type(self):
        message = {
            'Type': 'UnknownType',
            'MessageId': '12345',
        }

        request = self.factory.post(
            '/sns/',
            data=json.dumps(message),
            content_type='application/json'
        )

        with patch('django_sns_signals.views.validator.validate_message'):
            response = sns_webhook(request)

        self.assertEqual(response.status_code, 200)

    def test_exception_handling(self):
        message = {
            'Type': 'Notification',
            'MessageId': '12345',
        }

        request = self.factory.post(
            '/sns/',
            data=json.dumps(message),
            content_type='application/json'
        )

        with patch('django_sns_signals.views.validator.validate_message'):
            with patch('django_sns_signals.views.sns_notification.send') as mock_send:
                with patch('django_sns_signals.views.logger.error'):
                    mock_send.side_effect = Exception('Unexpected error')
                    response = sns_webhook(request)

        self.assertIsInstance(response, HttpResponseServerError)
