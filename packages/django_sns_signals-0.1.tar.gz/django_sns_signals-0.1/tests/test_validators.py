from __future__ import annotations

import base64
from unittest.mock import Mock, patch
from django.test import TestCase
from django.core.cache import cache
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.backends import default_backend
import datetime

from django_sns_signals.validators import SNSSignatureValidator


class SNSSignatureValidatorTestCase(TestCase):
    def setUp(self):
        self.validator = SNSSignatureValidator()
        cache.clear()

        self.private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
            backend=default_backend()
        )

        subject = issuer = x509.Name([
            x509.NameAttribute(x509.oid.NameOID.COUNTRY_NAME, "US"),
            x509.NameAttribute(x509.oid.NameOID.STATE_OR_PROVINCE_NAME, "WA"),
            x509.NameAttribute(x509.oid.NameOID.ORGANIZATION_NAME, "Amazon"),
        ])

        self.cert = x509.CertificateBuilder().subject_name(
            subject
        ).issuer_name(
            issuer
        ).public_key(
            self.private_key.public_key()
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            datetime.datetime.utcnow()
        ).not_valid_after(
            datetime.datetime.utcnow() + datetime.timedelta(days=365)
        ).sign(self.private_key, hashes.SHA256(), default_backend())

        self.cert_pem = self.cert.public_bytes(serialization.Encoding.PEM)

    def _create_signed_message(self, message_dict):
        """Helper to create a properly signed SNS message"""
        msg_type = message_dict['Type']

        if msg_type == 'Notification':
            fields = ['Message', 'MessageId']
            if 'Subject' in message_dict:
                fields.append('Subject')
            fields.extend(['Timestamp', 'TopicArn', 'Type'])
        else:
            fields = ['Message', 'MessageId', 'SubscribeURL', 'Timestamp', 'Token', 'TopicArn', 'Type']

        parts = []
        for field in fields:
            if field in message_dict:
                parts.append(f"{field}\n{message_dict[field]}\n")

        string_to_sign = ''.join(parts)

        signature = self.private_key.sign(
            string_to_sign.encode('utf-8'),
            padding.PKCS1v15(),
            hashes.SHA1()
        )

        message_dict['Signature'] = base64.b64encode(signature).decode('utf-8')
        message_dict['SigningCertURL'] = 'https://sns.us-east-1.amazonaws.com/cert.pem'

        return message_dict

    def test_validate_notification_message_success(self):
        message = self._create_signed_message({
            'Type': 'Notification',
            'MessageId': '12345',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Message': 'Hello World',
            'Timestamp': '2023-01-01T00:00:00.000Z',
        })

        with patch('django_sns_signals.validators.urlopen') as mock_urlopen:
            mock_response = Mock()
            mock_response.read.return_value = self.cert_pem
            mock_response.__enter__ = Mock(return_value=mock_response)
            mock_response.__exit__ = Mock(return_value=False)
            mock_urlopen.return_value = mock_response

            self.validator.validate_message(message)

    def test_validate_subscription_confirmation_success(self):
        message = self._create_signed_message({
            'Type': 'SubscriptionConfirmation',
            'MessageId': '12345',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Message': 'You have chosen to subscribe',
            'Timestamp': '2023-01-01T00:00:00.000Z',
            'Token': 'token123',
            'SubscribeURL': 'https://sns.amazonaws.com/subscribe',
        })

        with patch('django_sns_signals.validators.urlopen') as mock_urlopen:
            mock_response = Mock()
            mock_response.read.return_value = self.cert_pem
            mock_response.__enter__ = Mock(return_value=mock_response)
            mock_response.__exit__ = Mock(return_value=False)
            mock_urlopen.return_value = mock_response

            self.validator.validate_message(message)

    def test_missing_signing_cert_url(self):
        message = {'Type': 'Notification', 'MessageId': '12345'}

        with self.assertRaises(ValueError) as context:
            self.validator.validate_message(message)

        self.assertIn('Missing SigningCertURL', str(context.exception))

    def test_invalid_cert_url_domain(self):
        message = {
            'Type': 'Notification',
            'MessageId': '12345',
            'SigningCertURL': 'https://evil.com/cert.pem',
        }

        with self.assertRaises(ValueError) as context:
            self.validator.validate_message(message)

        self.assertIn('Invalid certificate URL', str(context.exception))

    def test_invalid_signature(self):
        message = {
            'Type': 'Notification',
            'MessageId': '12345',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Message': 'Hello World',
            'Timestamp': '2023-01-01T00:00:00.000Z',
            'Signature': base64.b64encode(b'invalid_signature').decode('utf-8'),
            'SigningCertURL': 'https://sns.us-east-1.amazonaws.com/cert.pem',
        }

        with patch('django_sns_signals.validators.urlopen') as mock_urlopen:
            mock_response = Mock()
            mock_response.read.return_value = self.cert_pem
            mock_response.__enter__ = Mock(return_value=mock_response)
            mock_response.__exit__ = Mock(return_value=False)
            mock_urlopen.return_value = mock_response

            with self.assertRaises(ValueError) as context:
                self.validator.validate_message(message)

            self.assertIn('Signature verification failed', str(context.exception))

    def test_certificate_caching(self):
        message = self._create_signed_message({
            'Type': 'Notification',
            'MessageId': '12345',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Message': 'Hello World',
            'Timestamp': '2023-01-01T00:00:00.000Z',
        })

        with patch('django_sns_signals.validators.urlopen') as mock_urlopen:
            mock_response = Mock()
            mock_response.read.return_value = self.cert_pem
            mock_response.__enter__ = Mock(return_value=mock_response)
            mock_response.__exit__ = Mock(return_value=False)
            mock_urlopen.return_value = mock_response

            self.validator.validate_message(message)
            self.assertEqual(mock_urlopen.call_count, 1)

            self.validator.validate_message(message)
            self.assertEqual(mock_urlopen.call_count, 1)

    def test_unknown_message_type(self):
        message = {
            'Type': 'UnknownType',
            'MessageId': '12345',
            'SigningCertURL': 'https://sns.us-east-1.amazonaws.com/cert.pem',
        }

        with patch('django_sns_signals.validators.urlopen') as mock_urlopen:
            mock_response = Mock()
            mock_response.read.return_value = self.cert_pem
            mock_response.__enter__ = Mock(return_value=mock_response)
            mock_response.__exit__ = Mock(return_value=False)
            mock_urlopen.return_value = mock_response

            with self.assertRaises(ValueError) as context:
                self.validator.validate_message(message)

            self.assertIn('Unknown message type', str(context.exception))
