from __future__ import annotations

import json
from unittest.mock import Mock, patch
from django.test import TestCase, RequestFactory

from django_sns_signals.views import sns_webhook
from django_sns_signals.signals import (
    sns_subscription_confirmation,
    sns_unsubscribe_confirmation,
    sns_notification,
)


class SNSSignalsTestCase(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.received_signals = []

    def tearDown(self):
        sns_subscription_confirmation.disconnect(self.signal_handler)
        sns_unsubscribe_confirmation.disconnect(self.signal_handler)
        sns_notification.disconnect(self.signal_handler)

    def signal_handler(self, sender, **kwargs):
        self.received_signals.append(kwargs)

    def test_subscription_confirmation_signal_fired(self):
        sns_subscription_confirmation.connect(self.signal_handler)

        message = {
            'Type': 'SubscriptionConfirmation',
            'MessageId': 'msg-12345',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Subject': 'Test Subject',
            'Message': 'You have chosen to subscribe',
            'Timestamp': '2023-01-01T00:00:00.000Z',
            'Token': 'token123',
            'SubscribeURL': 'https://sns.amazonaws.com/subscribe',
        }

        request = self.factory.post(
            '/sns/',
            data=json.dumps(message),
            content_type='application/json'
        )

        with patch('django_sns_signals.views.validator.validate_message'):
            with patch('django_sns_signals.views.urlopen') as mock_urlopen:
                mock_response = Mock()
                mock_response.status = 200
                mock_response.__enter__ = Mock(return_value=mock_response)
                mock_response.__exit__ = Mock(return_value=False)
                mock_urlopen.return_value = mock_response

                sns_webhook(request)

        self.assertEqual(len(self.received_signals), 1)
        signal_data = self.received_signals[0]

        self.assertEqual(signal_data['message_id'], 'msg-12345')
        self.assertEqual(signal_data['topic_arn'], 'arn:aws:sns:us-east-1:123456789012:MyTopic')
        self.assertEqual(signal_data['subject'], 'Test Subject')
        self.assertEqual(signal_data['timestamp'], '2023-01-01T00:00:00.000Z')
        self.assertEqual(signal_data['subscribe_url'], 'https://sns.amazonaws.com/subscribe')
        self.assertEqual(signal_data['token'], 'token123')
        self.assertIn('message', signal_data)
        self.assertIn('raw_message', signal_data)

    def test_unsubscribe_confirmation_signal_fired(self):
        sns_unsubscribe_confirmation.connect(self.signal_handler)

        message = {
            'Type': 'UnsubscribeConfirmation',
            'MessageId': 'msg-67890',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Message': 'You have chosen to unsubscribe',
            'Timestamp': '2023-01-02T00:00:00.000Z',
            'Token': 'token456',
            'SubscribeURL': 'https://sns.amazonaws.com/unsubscribe',
        }

        request = self.factory.post(
            '/sns/',
            data=json.dumps(message),
            content_type='application/json'
        )

        with patch('django_sns_signals.views.validator.validate_message'):
            with patch('django_sns_signals.views.urlopen') as mock_urlopen:
                mock_response = Mock()
                mock_response.status = 200
                mock_response.__enter__ = Mock(return_value=mock_response)
                mock_response.__exit__ = Mock(return_value=False)
                mock_urlopen.return_value = mock_response

                sns_webhook(request)

        self.assertEqual(len(self.received_signals), 1)
        signal_data = self.received_signals[0]

        self.assertEqual(signal_data['message_id'], 'msg-67890')
        self.assertEqual(signal_data['topic_arn'], 'arn:aws:sns:us-east-1:123456789012:MyTopic')
        self.assertEqual(signal_data['timestamp'], '2023-01-02T00:00:00.000Z')
        self.assertEqual(signal_data['subscribe_url'], 'https://sns.amazonaws.com/unsubscribe')
        self.assertEqual(signal_data['token'], 'token456')

    def test_notification_signal_fired(self):
        sns_notification.connect(self.signal_handler)

        message = {
            'Type': 'Notification',
            'MessageId': 'notif-12345',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Subject': 'Important Notification',
            'Message': 'Hello World',
            'Timestamp': '2023-01-03T00:00:00.000Z',
            'UnsubscribeURL': 'https://sns.amazonaws.com/unsubscribe',
        }

        request = self.factory.post(
            '/sns/',
            data=json.dumps(message),
            content_type='application/json'
        )

        with patch('django_sns_signals.views.validator.validate_message'):
            sns_webhook(request)

        self.assertEqual(len(self.received_signals), 1)
        signal_data = self.received_signals[0]

        self.assertEqual(signal_data['message_id'], 'notif-12345')
        self.assertEqual(signal_data['topic_arn'], 'arn:aws:sns:us-east-1:123456789012:MyTopic')
        self.assertEqual(signal_data['subject'], 'Important Notification')
        self.assertEqual(signal_data['timestamp'], '2023-01-03T00:00:00.000Z')
        self.assertEqual(signal_data['notification_message'], 'Hello World')
        self.assertEqual(signal_data['unsubscribe_url'], 'https://sns.amazonaws.com/unsubscribe')
        self.assertIn('message', signal_data)
        self.assertIn('raw_message', signal_data)

    def test_notification_signal_without_subject(self):
        sns_notification.connect(self.signal_handler)

        message = {
            'Type': 'Notification',
            'MessageId': 'notif-99999',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Message': 'No subject message',
            'Timestamp': '2023-01-04T00:00:00.000Z',
            'UnsubscribeURL': 'https://sns.amazonaws.com/unsubscribe',
        }

        request = self.factory.post(
            '/sns/',
            data=json.dumps(message),
            content_type='application/json'
        )

        with patch('django_sns_signals.views.validator.validate_message'):
            sns_webhook(request)

        self.assertEqual(len(self.received_signals), 1)
        signal_data = self.received_signals[0]

        self.assertIsNone(signal_data['subject'])
        self.assertEqual(signal_data['notification_message'], 'No subject message')

    def test_subscription_confirmation_not_fired_on_failure(self):
        sns_subscription_confirmation.connect(self.signal_handler)

        message = {
            'Type': 'SubscriptionConfirmation',
            'MessageId': 'msg-fail',
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:MyTopic',
            'Message': 'You have chosen to subscribe',
            'Timestamp': '2023-01-01T00:00:00.000Z',
            'Token': 'token123',
            'SubscribeURL': 'https://sns.amazonaws.com/subscribe',
        }

        request = self.factory.post(
            '/sns/',
            data=json.dumps(message),
            content_type='application/json'
        )

        with patch('django_sns_signals.views.validator.validate_message'):
            with patch('django_sns_signals.views.urlopen') as mock_urlopen:
                mock_response = Mock()
                mock_response.status = 500
                mock_response.__enter__ = Mock(return_value=mock_response)
                mock_response.__exit__ = Mock(return_value=False)
                mock_urlopen.return_value = mock_response

                sns_webhook(request)

        self.assertEqual(len(self.received_signals), 0)
