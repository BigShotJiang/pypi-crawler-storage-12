from __future__ import annotations

import base64
from urllib.request import urlopen
from urllib.parse import urlparse
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend
from django.core.cache import cache
from django.conf import settings


class SNSSignatureValidator:
    """Validate AWS SNS message signatures"""

    def validate_message(self, message):
        """
        Validate an SNS message signature.
        Raises ValueError if invalid.
        """
        cert_url = message.get('SigningCertURL')
        if not cert_url:
            raise ValueError("Missing SigningCertURL")

        parsed_url = urlparse(cert_url)
        if not parsed_url.hostname or not parsed_url.hostname.endswith('.amazonaws.com'):
            raise ValueError(f"Invalid certificate URL: {cert_url}")

        cert = self._get_certificate(cert_url)
        string_to_sign = self._build_string_to_sign(message)
        signature = base64.b64decode(message['Signature'])
        public_key = cert.public_key()

        try:
            public_key.verify(
                signature,
                string_to_sign.encode('utf-8'),
                padding.PKCS1v15(),
                hashes.SHA1()
            )
        except Exception as e:
            raise ValueError(f"Signature verification failed: {e}")

    def _get_certificate(self, cert_url):
        """Get and cache the signing certificate"""
        cache_timeout = getattr(settings, 'SNS_SIGNING_CERT_CACHE_TIMEOUT', 86400)
        cache_key = f'sns_cert_{cert_url}'
        cert_pem = cache.get(cache_key)

        if not cert_pem:
            with urlopen(cert_url, timeout=5) as response:
                cert_pem = response.read()
            cache.set(cache_key, cert_pem, cache_timeout)

        return x509.load_pem_x509_certificate(cert_pem, default_backend())

    def _build_string_to_sign(self, message):
        """Build the canonical string that was signed"""
        msg_type = message['Type']

        if msg_type == 'Notification':
            fields = ['Message', 'MessageId']
            if 'Subject' in message:
                fields.append('Subject')
            fields.extend(['Timestamp', 'TopicArn', 'Type'])
        elif msg_type in ['SubscriptionConfirmation', 'UnsubscribeConfirmation']:
            fields = ['Message', 'MessageId', 'SubscribeURL', 'Timestamp', 'Token', 'TopicArn', 'Type']
        else:
            raise ValueError(f"Unknown message type: {msg_type}")

        parts = []
        for field in fields:
            if field in message:
                parts.append(f"{field}\n{message[field]}\n")

        return ''.join(parts)
