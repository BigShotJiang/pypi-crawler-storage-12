from __future__ import annotations

import django.dispatch

# Signal sent when SNS SubscriptionConfirmation is received
sns_subscription_confirmation = django.dispatch.Signal()

# Signal sent when SNS UnsubscribeConfirmation is received
sns_unsubscribe_confirmation = django.dispatch.Signal()

# Signal sent when SNS Notification is received
sns_notification = django.dispatch.Signal()
