from __future__ import annotations

import json
import logging
from urllib.request import urlopen
from urllib.error import HTTPError, URLError
from django.http import HttpResponse, HttpResponseForbidden, HttpResponseServerError
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from django_sns_signals.validators import SNSSignatureValidator
from django_sns_signals.signals import (
    sns_subscription_confirmation,
    sns_unsubscribe_confirmation,
    sns_notification,
)

logger = logging.getLogger(__name__)

validator = SNSSignatureValidator()

@csrf_exempt
@require_http_methods(["POST"])
def sns_webhook(request):
    try:
        message = json.loads(request.body)

        try:
            validator.validate_message(message)
        except ValueError as e:
            return HttpResponseForbidden(f'Invalid message: {e}')

        message_type = message.get('Type')

        if message_type == 'SubscriptionConfirmation':
            subscribe_url = message['SubscribeURL']
            try:
                with urlopen(subscribe_url, timeout=10) as response:
                    if response.status == 200:
                        sns_subscription_confirmation.send(
                            sender=None,
                            message=message,
                            raw_message=request.body,
                            message_id=message.get('MessageId'),
                            topic_arn=message.get('TopicArn'),
                            subject=message.get('Subject'),
                            timestamp=message.get('Timestamp'),
                            subscribe_url=subscribe_url,
                            token=message.get('Token'),
                        )
                        return HttpResponse(status=200)
            except (HTTPError, URLError):
                pass
            return HttpResponseServerError()

        elif message_type == 'UnsubscribeConfirmation':
            unsubscribe_url = message['SubscribeURL']
            try:
                with urlopen(unsubscribe_url, timeout=10) as response:
                    if response.status == 200:
                        sns_unsubscribe_confirmation.send(
                            sender=None,
                            message=message,
                            raw_message=request.body,
                            message_id=message.get('MessageId'),
                            topic_arn=message.get('TopicArn'),
                            subject=message.get('Subject'),
                            timestamp=message.get('Timestamp'),
                            subscribe_url=unsubscribe_url,
                            token=message.get('Token'),
                        )
                        return HttpResponse(status=200)
            except (HTTPError, URLError):
                pass
            return HttpResponseServerError()

        elif message_type == 'Notification':
            sns_notification.send(
                sender=None,
                message=message,
                raw_message=request.body,
                message_id=message.get('MessageId'),
                topic_arn=message.get('TopicArn'),
                subject=message.get('Subject'),
                timestamp=message.get('Timestamp'),
                notification_message=message.get('Message'),
                unsubscribe_url=message.get('UnsubscribeURL'),
            )
            return HttpResponse(status=200)

        return HttpResponse(status=200)

    except json.JSONDecodeError:
        return HttpResponseForbidden('Invalid JSON')
    except Exception as e:
        logger.error("Error processing SNS message: %s", e, exc_info=True)
        return HttpResponseServerError()
