everyone = [
    "admin.view_logentry",
    "auth.view_group",
    "auth.view_permission",
    "auth.view_user",
    "edc_auth.view_userprofile",
    "sites.view_site",
]
