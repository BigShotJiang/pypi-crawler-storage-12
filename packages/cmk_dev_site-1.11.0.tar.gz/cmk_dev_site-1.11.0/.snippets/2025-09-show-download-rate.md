## show download rate
<!--
type: feature
scope: all
affected: all
-->

The shown rate is for the overall download, so it stabilizes over time.
