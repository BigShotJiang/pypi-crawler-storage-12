## Prefer downloads.checkmk.com server over tsbuild where possible
<!--
type: feature
scope: internal
affected: all
-->

Prefer downloading packages from the public downloads.checkmk.com server, instead of the internal tsbuilds server.
We only use tstbuilds-artifacts.lan.tribe29.com for the cloud edition.
