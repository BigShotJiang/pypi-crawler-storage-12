"""
This module contains an example usage of :mod:`cfig`.
"""