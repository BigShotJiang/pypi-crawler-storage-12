from enum import Enum

class PortFigureArrangement(Enum):
    OnePlotPerDim = 0
    OnePlotPerPort = 1