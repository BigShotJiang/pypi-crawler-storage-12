def run():
    print("Evaluation - demo")
