def run():
    print("Data Preparation - demo")
