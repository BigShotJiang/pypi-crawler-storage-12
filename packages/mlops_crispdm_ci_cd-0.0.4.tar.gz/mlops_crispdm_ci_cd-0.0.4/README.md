# Proyecto de MLOps siguiendo la metodología CRISP-DM
