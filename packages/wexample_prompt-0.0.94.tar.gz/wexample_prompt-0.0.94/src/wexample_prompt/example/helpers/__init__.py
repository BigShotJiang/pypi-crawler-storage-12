"""Helper utilities for examples."""

from __future__ import annotations
