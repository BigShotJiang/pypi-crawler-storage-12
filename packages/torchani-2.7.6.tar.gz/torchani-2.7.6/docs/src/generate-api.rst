:orphan:

.. Only job of this file is to generate the stubs

.. autosummary::
   :recursive:
   :toctree: api_autogen
   :template: custom-module.rst
   :nosignatures:

   torchani
