"""Common Types for the MADSci Framework."""
