"""Common code for the MADSci project."""
