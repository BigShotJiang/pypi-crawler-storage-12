snagrecover --version
Write-Host ""
Write-Host "The following commands are available in this shell:"
Write-Host ""
Write-Host "snagrecover, snagflash, snagfactory"
Write-Host ""
