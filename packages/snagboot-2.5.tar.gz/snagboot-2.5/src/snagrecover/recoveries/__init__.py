"""
recoveries subpackage:
Handles connecting and disconnecting from serial ports, calling the firmware CLI
and performing soc-specific configurations and checks.
"""
