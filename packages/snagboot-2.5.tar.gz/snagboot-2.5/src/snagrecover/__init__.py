"""
Package containing the board recovery tool.
DO NOT IMPORT ANYTHING HERE!
this would cause an import loop
"""

# Global version string for Snagboot
__version__ = "2.5"
