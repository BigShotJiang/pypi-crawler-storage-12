"""
firmware subpackage:
Handles loading, parsing, installing and running firmware binaries.
"""
