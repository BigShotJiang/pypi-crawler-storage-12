"""
protocols subpackage:
Handles sending protocol-specific commands to the board.
Standard commands like memory reads, memory writes and jumps should be called
through a MemoryOps object whenever possible.
"""
