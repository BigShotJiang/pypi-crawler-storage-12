"""
Package containing the factory flashing tool.
"""

import os

os.environ["KIVY_LOG_MODE"] = "PYTHON"
