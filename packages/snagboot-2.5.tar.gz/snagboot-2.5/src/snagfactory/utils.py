class SnagFactoryConfigError(Exception):
	pass
