"""
Package containing the flashing tool.
"""
