"""Workflows defined in fabricatio-diff."""
