import time
from random import random


def xx(x):
    return x**2


def sleep_random():
    time.sleep(random() * 10)
