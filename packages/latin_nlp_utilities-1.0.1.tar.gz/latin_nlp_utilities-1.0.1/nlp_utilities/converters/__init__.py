"""Interface for converters."""
