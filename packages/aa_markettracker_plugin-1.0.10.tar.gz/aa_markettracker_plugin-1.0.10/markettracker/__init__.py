"""Initialize the app"""

__version__ = "1.0.10"
__title__ = "Markettracker"
