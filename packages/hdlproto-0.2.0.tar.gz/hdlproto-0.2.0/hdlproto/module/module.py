from functools import wraps
from hdlproto.event import Event, EventType, EventSource
from hdlproto.state import Edge


def _create_always_decorator(type_str: str, source_type: EventSource):
    """
    alwaysデコレータを生成するためのファクトリ関数。
    """
    def decorator(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            event_handler = getattr(wrapper, 'handler', None)
            module_path = getattr(wrapper, '_hdlproto_module_path', None)
            if module_path is None:
                module_path = getattr(self, "module_path", None)
            func_name = getattr(wrapper, '_hdlproto_func_name', func.__name__)

            if event_handler:
                start_event = Event(
                    event_type=EventType.FUNCTION_START,
                    source_type=source_type,
                    info={
                        "module": self,
                        "module_path": module_path,
                        "function_name": func_name,
                    }
                )
                event_handler(start_event)

            try:
                result = func(self, *args, **kwargs)
            finally:
                if event_handler:
                    end_event = Event(
                        event_type=EventType.FUNCTION_END,
                        source_type=source_type,
                        info={
                            "module": self,
                            "module_path": module_path,
                            "function_name": func_name,
                        }
                    )
                    event_handler(end_event)

            return result

        wrapper.type = type_str
        wrapper.handler = None
        wrapper._hdlproto_func_name = func.__name__
        return wrapper
    return decorator

always_comb = _create_always_decorator('always_comb', EventSource.ALWAYS_COMB)


def always_ff(*trigger_specs):
    """always_ff デコレータ。必ず (Edge, signal) タプルを渡す。"""

    if not trigger_specs:
        raise TypeError("@always_ff requires at least one (Edge, signal) trigger tuple.")

    normalized = []
    for spec in trigger_specs:
        if not isinstance(spec, tuple) or len(spec) != 2:
            raise TypeError("always_ff triggers must be tuples of (Edge, signal_name).")
        edge_value, signal_name = spec
        if not isinstance(edge_value, Edge):
            raise TypeError("always_ff triggers must use Edge.POS or Edge.NEG.")
        if not isinstance(signal_name, str):
            raise TypeError("always_ff trigger signal must be provided as an attribute name (str).")
        normalized.append({"edge": edge_value, "signal_name": signal_name})

    primary_edge = normalized[0]["edge"]
    source_type = EventSource.ALWAYS_FF_POS if primary_edge == Edge.POS else EventSource.ALWAYS_FF_NEG

    def decorator(func):
        wrapper = _create_always_decorator('always_ff', source_type)(func)
        wrapper._triggers = tuple(normalized)
        return wrapper

    return decorator


class Module:
    def __init__(self):
        self.id = id(self)
        self.parent = None
        self.children = []
        self.class_name = self.__class__.__name__
        self.instance_name = None
        self.module_path = None
        self.make_module_tree()

    @property
    def is_testbench(self):
        return False

    def make_module_tree(self):
        for name, mod in self.__dict__.items():
            if isinstance(mod, Module):
                mod.parent = self
                mod.instance_name = name
                self.children.append(mod)

    def items(self, instance_type):
        if isinstance(instance_type, (tuple, list)):
            instance_type_list = instance_type
        else:
            instance_type_list = [instance_type]
        for name, obj in self.__dict__.items():
            if isinstance(obj, instance_type_list):
                yield name, obj

    def dir(self):
        for name in dir(self):
            yield name

    def log_clock_start(self, cycle):
        pass

    def log_clock_end(self, cycle):
        pass
