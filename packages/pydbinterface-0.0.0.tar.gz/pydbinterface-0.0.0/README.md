# pydbinterface


Interfaz sencilla para conectar y manipular bases de datos en Python.

## Instalación


```bash
pip install pydbinterface
```

## Uso


```python
from db_interface import DBInterface
```

## Licencia

MIT
