"""Version information for pact-langchain."""

__version__ = "0.1.0"
