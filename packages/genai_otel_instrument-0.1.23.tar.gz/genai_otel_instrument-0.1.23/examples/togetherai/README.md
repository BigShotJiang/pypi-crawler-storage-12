# Together AI Example
```bash
pip install genai-otel-instrument[together]
cp .env.example .env
python example.py
```
