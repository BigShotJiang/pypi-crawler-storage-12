# Groq Example
Fast LPU inference with auto-instrumentation.
```bash
pip install genai-otel-instrument[groq]
cp .env.example .env
python example.py
```
