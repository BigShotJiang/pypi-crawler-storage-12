"""Common utilities for simplerpyc."""
