"""
Merobox - A Python CLI tool for managing Calimero nodes in Docker containers.
"""

__version__ = "0.2.4"
__author__ = "Calimero Ltd."
__email__ = "engineering@calimero.network"
