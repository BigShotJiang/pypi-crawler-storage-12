### Parameters (defaults shown)

```python
@persist_cache(
  cache_dir=".dfcached_cache",
  version=None,
  refresh=False,
  exclude_from_key=None,
  canonicalize_kwargs=True,
  write_checksums=True,
  verify_checksums=True,
  strict_integrity=True,
)

