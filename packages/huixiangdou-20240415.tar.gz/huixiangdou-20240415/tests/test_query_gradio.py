from loguru import logger

if __name__ == '__main__':
    logger.warning('This file moved to `huixiangdou.gradio_ui`')
