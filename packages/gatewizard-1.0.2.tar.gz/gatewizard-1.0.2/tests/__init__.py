"""
GateWizard Test Suite

This package contains all tests for GateWizard functionality.
"""

# Test version
__version__ = "1.0.0"

# Common test utilities can be added here
