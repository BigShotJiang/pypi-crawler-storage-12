from w.test_utils.testcases.view_testcase import ViewTestCase  # noqa
