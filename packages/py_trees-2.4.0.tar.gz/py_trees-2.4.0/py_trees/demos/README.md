# Guidelines

Each module here is a self-contained code sample for one of the demo scripts.
That means there is a fair bit of copy and paste happening, but that is an
intentional decision to ensure each demo script is self-contained and easy
for beginners to follow and/or copy-paste from.

Keep this in mind when adding additional programs.