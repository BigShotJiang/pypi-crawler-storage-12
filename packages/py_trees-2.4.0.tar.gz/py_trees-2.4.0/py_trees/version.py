#
# License: BSD
#   https://raw.githubusercontent.com/splintered-reality/py_trees/devel/LICENSE
#
##############################################################################
# Documentation
##############################################################################

"""Package version number."""

##############################################################################
# Version
##############################################################################

# When changing, Also update setup.py and package.xml
# TODO: use pkg_resources to fetch the version from setup.py
__version__ = "2.4.0"
