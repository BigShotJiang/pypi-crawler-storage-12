# Changes

2025.11.16
:    Adapted to upstream changes in muuntuu.

2025.7.19
:    Initial release on pypi.
