from .random_generator import RandomOperationsGenerator


class RandomParametrizeGenerator(RandomOperationsGenerator):
    pass
