# TickerDataFetcher

A simple Python package for fetching and updating historical stock data from Alpha Vantage.

## Installation
```bash
pip install GoekenDataScience