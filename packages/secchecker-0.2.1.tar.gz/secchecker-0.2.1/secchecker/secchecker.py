# This file is kept for backward compatibility
# The main functionality has been moved to cli.py
from .cli import main

if __name__ == "__main__":
    main()
