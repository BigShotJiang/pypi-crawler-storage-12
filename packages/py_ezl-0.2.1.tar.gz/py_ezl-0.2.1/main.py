def main():
    print("Hello from ezl!")


if __name__ == "__main__":
    main()
