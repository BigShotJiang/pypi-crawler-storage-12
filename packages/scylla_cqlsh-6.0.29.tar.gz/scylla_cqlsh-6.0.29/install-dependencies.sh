#!/bin/bash
#
# Copyright (C) 2022 ScyllaDB
#

# SPDX-License-Identifier: Apache-2.0


# TODO: move cqlsh dependencies from scylla main repo
