from pruna_pro.algorithms.zipar.zipar import ZipAR

__all__ = ["ZipAR"]
