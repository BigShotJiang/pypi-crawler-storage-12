from pruna_pro.algorithms.fp8.fp8 import Fp8

__all__ = ["Fp8"]
