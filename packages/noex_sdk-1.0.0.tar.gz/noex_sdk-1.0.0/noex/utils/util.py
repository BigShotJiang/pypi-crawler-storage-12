def p2c(co) -> str:
    return f"{co}/USDT"