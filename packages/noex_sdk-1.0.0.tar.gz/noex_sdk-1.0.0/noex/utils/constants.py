MAINNET_API_URL = "https://api.noex.io"
TESTNET_API_URL = "https://testnet-api.noex.io"
LOCAL_API_URL = "http://localhost:8000"
DEFAULT_TIMEOUT = 30
WEBSOCKET_PING_INTERVAL = 50
