# Concept
## JSON file

The python plugin for Material for #MkDocs creates a `graph.json` file, which will be used by [[ECharts]] javascript. 

You can find the #JSON file for this example site here: [graph.json](../assets/javascripts/graph.json)
