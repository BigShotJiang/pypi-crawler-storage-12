# ECharts
## Graph Javascript by Apache ECharts

A `interactive_graph.js` example can be downloaded from [here](https://raw.githubusercontent.com/daxcore/mkdocs-obsidian-interactive-graph-plugin/main/docs/ObsidianVault/assets/javascripts/interactive_graph.js){:target="\_blank"} and must be located into the docs directory under `docs/ObsidianVault/assets/javascripts/interactive_graph.js`.

## Live Editor

There is a web-based live editor for the #EChart javascript file: [Live Editor](https://echarts.apache.org/examples/en/editor.html?c=graph){:target="\_blank"}
