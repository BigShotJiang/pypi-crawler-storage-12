# Installation

Available on [PyPI](https://pypi.org/project/mkdocs-obsidian-interactive-graph-plugin/){:target="\_blank"}.
Install via `pip install mkdocs-obsidian-interactive-graph-plugin` or add it to your `requirements.txt`.
