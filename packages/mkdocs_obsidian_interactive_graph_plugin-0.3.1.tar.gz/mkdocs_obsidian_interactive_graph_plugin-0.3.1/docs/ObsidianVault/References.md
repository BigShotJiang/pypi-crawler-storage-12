# References

* [https://www.mkdocs.org/](https://www.mkdocs.org/){:target="\_blank"}
* [https://squidfunk.github.io/mkdocs-material/](https://squidfunk.github.io/mkdocs-material/){:target="\_blank"}
* [https://github.com/ndy2/mkdocs-obsidian-support-plugin/tree/main](https://github.com/ndy2/mkdocs-obsidian-support-plugin/tree/main){:target="\_blank"}
* [https://github.com/GooRoo/mkdocs-obsidian-bridge](https://github.com/GooRoo/mkdocs-obsidian-bridge){:target="\_blank"}
* [https://github.com/blueswen/mkdocs-glightbox](https://github.com/blueswen/mkdocs-glightbox){:target="\_blank"}
* [https://echarts.apache.org](https://echarts.apache.org){:target="\_blank"}
