from ..base_loader import BaseMarkitdownLoader

class PlainTextLoader(BaseMarkitdownLoader):
    pass