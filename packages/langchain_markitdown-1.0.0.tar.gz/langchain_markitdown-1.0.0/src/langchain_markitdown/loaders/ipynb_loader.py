from ..base_loader import BaseMarkitdownLoader

class IpynbLoader(BaseMarkitdownLoader):
    pass