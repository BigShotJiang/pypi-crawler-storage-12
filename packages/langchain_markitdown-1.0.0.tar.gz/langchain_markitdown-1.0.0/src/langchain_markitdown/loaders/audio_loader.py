from ..base_loader import BaseMarkitdownLoader

class AudioLoader(BaseMarkitdownLoader):
    """Loader for audio files."""

    pass
