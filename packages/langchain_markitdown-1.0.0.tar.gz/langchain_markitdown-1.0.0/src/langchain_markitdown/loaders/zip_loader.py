from ..base_loader import BaseMarkitdownLoader

class ZipLoader(BaseMarkitdownLoader):
    pass