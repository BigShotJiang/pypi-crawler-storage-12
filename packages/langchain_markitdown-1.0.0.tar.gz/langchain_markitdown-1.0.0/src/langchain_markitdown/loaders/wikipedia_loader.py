from ..base_loader import BaseMarkitdownLoader

class WikipediaLoader(BaseMarkitdownLoader):
    pass