from ..base_loader import BaseMarkitdownLoader

class BingSerpLoader(BaseMarkitdownLoader):
    pass