from ..base_loader import BaseMarkitdownLoader

class RssLoader(BaseMarkitdownLoader):
    pass