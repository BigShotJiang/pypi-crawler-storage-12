from ..base_loader import BaseMarkitdownLoader

class HtmlLoader(BaseMarkitdownLoader):
    pass