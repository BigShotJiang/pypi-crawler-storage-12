from ..base_loader import BaseMarkitdownLoader

class DocIntelLoader(BaseMarkitdownLoader):
    pass