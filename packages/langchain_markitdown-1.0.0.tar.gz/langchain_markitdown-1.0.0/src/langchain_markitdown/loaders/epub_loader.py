from ..base_loader import BaseMarkitdownLoader

class EpubLoader(BaseMarkitdownLoader):
    pass