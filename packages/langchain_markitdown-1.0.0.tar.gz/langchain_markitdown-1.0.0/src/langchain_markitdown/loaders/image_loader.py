from ..base_loader import BaseMarkitdownLoader

class ImageLoader(BaseMarkitdownLoader):
    pass