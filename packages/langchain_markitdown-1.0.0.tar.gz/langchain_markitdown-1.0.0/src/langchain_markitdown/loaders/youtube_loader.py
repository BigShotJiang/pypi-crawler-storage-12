from ..base_loader import BaseMarkitdownLoader

class YoutubeLoader(BaseMarkitdownLoader):
    pass