from ..base_loader import BaseMarkitdownLoader

class OutlookMsgLoader(BaseMarkitdownLoader):
    pass