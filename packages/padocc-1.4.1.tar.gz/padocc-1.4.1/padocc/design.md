# Developer Notes

## Arguments

### Initialisation Arguments (all stages)
 - proj_code
 - workdir
 - groupID
 - first_time
 - ft_kwargs
 - logger
 - bypass
 - label, fh, logid, verbose
 - forceful, dryrun, thorough

### Run Arguments
 - mode
 - *forceful
 - *thorough
 - *dryrun