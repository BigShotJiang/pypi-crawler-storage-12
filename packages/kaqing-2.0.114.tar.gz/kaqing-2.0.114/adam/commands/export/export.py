from adam.commands.export.utils_export import export_tables, export_all
from adam.commands.command import Command
from adam.commands.cql.cql_utils import cassandra_table_names
from adam.repl_state import ReplState, RequiredState
from adam.sql.sql_completer import SqlCompleter
from adam.utils_k8s.statefulsets import StatefulSets

class ExportTable(Command):
    COMMAND = 'export'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ExportTable, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ExportTable.COMMAND

    def required(self):
        return RequiredState.CLUSTER_OR_POD

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        state, args = self.apply_state(args, state)
        if not self.validate_state(state):
            return state

        if not state.pod:
            state.push()
            state.pod = StatefulSets.pod_names(state.sts, state.namespace)[0]
        try:
            if not args:
                export_all(state)
            else:
                export_tables(args, state)
        finally:
            state.pop()

        return state

    def completion(self, state: ReplState):
        def sc():
            return SqlCompleter(
                lambda: cassandra_table_names(state),
                dml='export',
                columns = lambda table: ['id', '*'],
                variant='cql'
            )

        if state.sts:
            return {ExportTable.COMMAND: sc()} | \
                {f'@{p}': {ExportTable.COMMAND: sc()} for p in StatefulSets.pod_names(state.sts, state.namespace)}

        return {}

    def help(self, _: ReplState):
        return f'{ExportTable.COMMAND} TABLE\t export table'