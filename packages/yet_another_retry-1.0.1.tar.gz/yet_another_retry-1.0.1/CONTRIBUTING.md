# About yet-another-retry
This package was made to push the idea what a retry decorator could do.  
The package is presented as is.

# Contributing
If you have a suggestion for the package please create an issue.  
External pull requests of any kind will not be accepted.  

# Code standards
This package is formatted with the Black Formatter from Microsoft and isort with Black formatting setting.  
The package was designed with the idea to use `uv` as default build and testing tool, nothing outside of this will be put into the pyproject.toml file.  
