# version: v2
def main_script_test_direct_in_direct_out(p1):
    # process
    p2 = p1 + 200

    # return outputs
    return {"p2": p2}
