# Our families rely on the log probabilities. Instead of these, we use a c-log, where the second term is weighed by c.

import torch.distributions as D
