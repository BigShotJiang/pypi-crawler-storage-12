"""Types for the Typesense Python Client."""
