"""Device specific classes for device from Highfinesse."""
from .wsx import WSx

__all__ = ["WSx"]
