# Engineering Box SDK

A Python SDK for Engineering Box Quantum Computing.

## Installation

```bash
# Install in development mode
pip install -e .

# Or install from PyPI (once published)
# pip install engineering_box_sdk
```
