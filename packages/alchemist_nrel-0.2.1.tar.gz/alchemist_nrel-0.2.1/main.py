from ui.ui import ALchemistApp

def main():
    app = ALchemistApp()
    app.mainloop()

if __name__ == '__main__':
    main()