"""Kurt - Document intelligence CLI tool."""

from importlib.metadata import version

__version__ = version("kurt-core")
