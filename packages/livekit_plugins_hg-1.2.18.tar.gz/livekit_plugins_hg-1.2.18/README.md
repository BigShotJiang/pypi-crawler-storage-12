# HeyGen virtual avatar plugin for LiveKit Agents

Support for the [Heygen LiveAvatar](https://www.liveavatar.com/) virtual avatar.

See [https://docs.livekit.io/agents/integrations/avatar/heygen/](https://docs.livekit.io/agents/integrations/avatar/heygen/) for more information.

