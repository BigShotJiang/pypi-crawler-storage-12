from usdm4.builder.base_manager import BaseManager


class OtherCTVersionManager(BaseManager):
    pass
