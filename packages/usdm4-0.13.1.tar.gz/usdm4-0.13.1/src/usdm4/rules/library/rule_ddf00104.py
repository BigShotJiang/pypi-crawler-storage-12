from usdm3.rules.library.rule_ddf00104 import RuleDDF00104 as V3Rule


class RuleDDF00104(V3Rule):
    pass
