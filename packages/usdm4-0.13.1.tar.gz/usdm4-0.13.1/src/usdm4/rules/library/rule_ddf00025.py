from usdm3.rules.library.rule_ddf00025 import RuleDDF00025 as V3Rule


class RuleDDF00025(V3Rule):
    pass
