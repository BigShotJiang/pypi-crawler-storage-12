from usdm3.rules.library.rule_ddf00149 import RuleDDF00149 as V3Rule


class RuleDDF00149(V3Rule):
    pass
