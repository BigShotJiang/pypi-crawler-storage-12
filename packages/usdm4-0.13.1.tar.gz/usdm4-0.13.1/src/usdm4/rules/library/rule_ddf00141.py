from usdm3.rules.library.rule_ddf00141 import RuleDDF00141 as V3Rule


class RuleDDF00141(V3Rule):
    pass
