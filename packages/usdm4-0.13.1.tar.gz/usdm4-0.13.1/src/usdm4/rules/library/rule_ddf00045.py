from usdm3.rules.library.rule_ddf00045 import RuleDDF00045 as V3Rule


class RuleDDF00045(V3Rule):
    pass
