from usdm3.rules.library.rule_ddf00108 import RuleDDF00108 as V3Rule


class RuleDDF00108(V3Rule):
    pass
