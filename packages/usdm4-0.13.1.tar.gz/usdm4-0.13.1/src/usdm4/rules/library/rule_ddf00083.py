from usdm3.rules.library.rule_ddf00083 import RuleDDF00083 as V3Rule


class RuleDDF00083(V3Rule):
    pass
