from usdm3.rules.library.rule_ddf00031 import RuleDDF00031 as V3Rule


class RuleDDF00031(V3Rule):
    pass
