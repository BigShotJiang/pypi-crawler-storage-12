from usdm3.rules.library.rule_ddf00142 import RuleDDF00142 as V3Rule


class RuleDDF00142(V3Rule):
    pass
