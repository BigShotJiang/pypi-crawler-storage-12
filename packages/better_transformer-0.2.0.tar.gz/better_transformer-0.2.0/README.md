Extraced from Optimum Package: https://github.com/huggingface/optimum

