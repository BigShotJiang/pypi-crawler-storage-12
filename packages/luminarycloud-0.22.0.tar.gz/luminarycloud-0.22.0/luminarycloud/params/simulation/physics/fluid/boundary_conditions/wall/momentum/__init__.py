from .no_slip_ import NoSlip
from .slip_ import Slip
from .wall_model_ import WallModel
