"""Activities package."""
