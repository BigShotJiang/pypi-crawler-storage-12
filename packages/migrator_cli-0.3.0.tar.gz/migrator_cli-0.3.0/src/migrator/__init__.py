"""Migrator - Universal migration CLI for Python apps"""

__version__ = "0.3.0"
