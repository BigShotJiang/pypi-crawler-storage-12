from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from migrator.core.alembic_backend import AlembicBackend
from migrator.core.config import MigratorConfig
from migrator.core.detector import ModelDetector
from migrator.core.logger import error, info, success
from migrator.utils.validators import sanitize_message, validate_database_url

app = typer.Typer(help="🧩 Migrator - Universal Migration CLI")
console = Console()


@app.command()
def init(
    directory: Path = typer.Option(Path("migrations"), "--dir", "-d", help="Migration directory"),
    base_path: str = typer.Option(None, "--base", "-b", help="Base class path (e.g. app.core.database:Base)"),
    config_path: Path = typer.Option(None, "--config", "-c", help="Config file path"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed detection process"),
):
    """Initialize migration environment"""
    try:
        if verbose:
            info("Verbose mode enabled")
        
        info("Detecting project configuration...")
        
        if verbose:
            from migrator.utils.config_loader import ConfigLoader
            env_file = ConfigLoader._find_env_file()
            if env_file:
                info(f"Found .env at: {env_file}")
            else:
                info("No .env file found")
        
        config = MigratorConfig.load(migrations_dir=directory, config_path=config_path)
        
        if verbose:
            info(f"Database URL: {config.database_url[:30]}...")

        info("Finding SQLAlchemy Base...")
        base = ModelDetector.find_base(explicit_path=base_path)
        
        if not base:
            error("Could not find SQLAlchemy Base class")
            
            searched = ModelDetector.get_searched_paths()
            if searched:
                info(f"Searched in: {', '.join(searched[:5])}")
                if len(searched) > 5:
                    info(f"... and {len(searched) - 5} more locations")
            
            console.print("\n💡 Hints:")
            console.print("  1. Use --base flag: migrator init --base app.core.database:Base")
            console.print("  2. Ensure Base = declarative_base() exists in your code")
            console.print("  3. Check that your models are importable")
            
            raise typer.Exit(1)
        
        if verbose:
            info(f"Found Base in: {base.__module__}")

        # Get the module where Base was actually defined (not sqlalchemy)
        import inspect

        base_module = inspect.getmodule(base)
        if base_module and not base_module.__name__.startswith("sqlalchemy"):
            config.base_import_path = f"{base_module.__name__}.Base"
        else:
            # Fallback: scan for the file that has Base
            for py_file in Path.cwd().rglob("*.py"):
                if "venv" in str(py_file) or "site-packages" in str(py_file):
                    continue
                try:
                    content = py_file.read_text()
                    if (
                        "Base = declarative_base()" in content
                        or "Base=declarative_base()" in content
                    ):
                        module_name = py_file.stem
                        config.base_import_path = f"{module_name}.Base"
                        break
                except Exception:
                    continue

        info(f"Initializing migrations in {directory}...")
        backend = AlembicBackend(config)
        backend.init(directory)

        success(f"Migration environment created at {directory}")
        console.print("\n📁 Structure:")
        console.print(f"  {directory}/")
        console.print("  ├── versions/")
        console.print("  ├── env.py")
        console.print("  ├── script.py.mako")
        console.print("  └── alembic.ini")

    except Exception as e:
        error(f"Initialization failed: {e}")
        raise typer.Exit(1)


@app.command()
def makemigrations(
    message: str = typer.Argument(..., help="Migration description"),
    autogenerate: bool = typer.Option(True, "--auto/--manual", help="Auto-generate migration"),
    base_path: str = typer.Option(None, "--base", "-b", help="Base class path"),
):
    """Create new migration"""
    try:
        config = MigratorConfig.load()
        
        if autogenerate and not config.base_import_path:
            base = ModelDetector.find_base(explicit_path=base_path)
            if not base:
                error("Could not find SQLAlchemy Base class")
                info("Hint: Use --base flag or run 'migrator init' first")
                raise typer.Exit(1)

        if not validate_database_url(config.database_url):
            error("Invalid database URL format")
            raise typer.Exit(1)

        message = sanitize_message(message)
        if not message:
            error("Migration message cannot be empty")
            raise typer.Exit(1)

        backend = AlembicBackend(config)

        info(f"Creating migration: {message}")
        migration_path = backend.create_migration(message, autogenerate)

        success(f"Migration created: {migration_path}")

    except Exception as e:
        error(f"Migration creation failed: {e}")
        raise typer.Exit(1)


@app.command()
def migrate(
    revision: str = typer.Option("head", "--revision", "-r", help="Target revision"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show SQL without executing"),
):
    """Apply migrations"""
    try:
        config = MigratorConfig.load()
        backend = AlembicBackend(config)

        # Check for existing tables (excluding migration tracking table)
        existing_tables = backend.check_existing_tables()
        # Filter out alembic_version table
        user_tables = [t for t in existing_tables if t != "alembic_version"]
        current = backend.current()

        if user_tables and not current:
            console.print(f"\n⚠️  Found {len(user_tables)} existing tables in database")
            console.print("\nOptions:")
            console.print("  1. Mark database as migrated (stamp) - Recommended")
            console.print("  2. Continue anyway (may cause conflicts)")
            console.print("  3. Cancel")

            choice = typer.prompt("\nChoice", type=int, default=3)

            if choice == 1:
                backend.stamp(revision)
                success(f"Database marked as migrated to {revision}")
                return
            elif choice == 3:
                info("Migration cancelled")
                return

        if dry_run:
            info("Dry-run mode: showing SQL only")
            info("Note: Alembic doesn't support native dry-run. Use --sql flag instead.")
            return

        info(f"Current revision: {current or 'None'}")
        info(f"Upgrading to: {revision}")

        backend.apply_migrations(revision)

        success("Database up-to-date")

    except Exception as e:
        error(f"Migration failed: {e}")
        if "foreign key constraint" in str(e).lower():
            console.print("\n💡 Tip: Use 'migrator stamp head' to mark existing database as migrated")
        raise typer.Exit(1)


@app.command()
def downgrade(revision: str = typer.Option("-1", "--revision", "-r", help="Target revision")):
    """Rollback migrations"""
    try:
        config = MigratorConfig.load()
        backend = AlembicBackend(config)

        current = backend.current()
        info(f"Current revision: {current}")
        info(f"Downgrading to: {revision}")

        backend.downgrade(revision)

        success("Rollback complete")

    except Exception as e:
        error(f"Downgrade failed: {e}")
        raise typer.Exit(1)


@app.command()
def history():
    """Show migration history"""
    try:
        config = MigratorConfig.load()
        backend = AlembicBackend(config)

        migrations = backend.history()
        current = backend.current()

        if not migrations:
            info("No migrations found")
            return

        table = Table(title="Migration History")
        table.add_column("Revision", style="cyan")
        table.add_column("Message", style="white")
        table.add_column("Status", style="green")

        for migration in migrations:
            status = "✅ applied" if migration["revision"] == current else "⏳ pending"
            table.add_row(migration["revision"][:12], migration["message"], status)

        console.print(table)

    except Exception as e:
        error(f"Failed to get history: {e}")
        raise typer.Exit(1)


@app.command()
def current():
    """Show current revision"""
    try:
        config = MigratorConfig.load()
        backend = AlembicBackend(config)

        revision = backend.current()
        if revision:
            success(f"Current revision: {revision}")
        else:
            info("No migrations applied yet")

    except Exception as e:
        error(f"Failed to get current revision: {e}")
        raise typer.Exit(1)


@app.command()
def stamp(revision: str = typer.Argument("head", help="Target revision to stamp")):
    """Mark database as migrated without running migrations"""
    try:
        config = MigratorConfig.load()
        backend = AlembicBackend(config)

        info(f"Stamping database to revision: {revision}")
        backend.stamp(revision)

        success(f"Database marked as {revision}")

    except Exception as e:
        error(f"Stamp failed: {e}")
        raise typer.Exit(1)


@app.command()
def status():
    """Show migration status and pending migrations"""
    try:
        config = MigratorConfig.load()
        backend = AlembicBackend(config)

        current = backend.current()
        pending = backend.get_pending_migrations()
        existing_tables = backend.check_existing_tables()

        console.print("\n📊 Migration Status\n")
        console.print(f"Current revision: {current or 'None'}")
        console.print(f"Existing tables: {len(existing_tables)}")
        console.print(f"Pending migrations: {len(pending)}")

        if pending:
            console.print("\n⏳ Pending Migrations:")
            for mig in pending:
                console.print(f"  • {mig['revision'][:12]} - {mig['message']}")
        else:
            console.print("\n✅ All migrations applied")

    except Exception as e:
        error(f"Failed to get status: {e}")
        raise typer.Exit(1)
