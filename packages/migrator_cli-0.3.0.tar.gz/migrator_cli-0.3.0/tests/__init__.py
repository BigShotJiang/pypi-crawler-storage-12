"""Tests for migrator"""
