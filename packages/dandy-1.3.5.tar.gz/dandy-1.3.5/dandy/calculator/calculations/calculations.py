def bits_to_bytes(
        bits: int
) -> int | float:
    return bits / 8