# -*- coding: utf-8 -*-
# @Time    : 2020/7/27 17:07
# @Author  : CC
# @Desc    : MiddlewareEum.py


class MiddlewareEum(object):
    MEMORY = 'memory'
    REDIS = 'redis'
    KAFKA = 'kafka'
    SQLITE = 'sqlite'
