# -*- coding: utf-8 -*-
"""
此文件leek_config.py是自动生成的leek框架的数据库配置文件。
"""
# redis连接配置
redis_host = '127.0.0.1'
redis_password = ''
redis_port = 6379
redis_db = 0
redis_ssl = False

# kafka配置连接信息
kafka_port = 9092
kafka_host = '127.0.0.1'
kafka_username = ''
kafka_password = ''
