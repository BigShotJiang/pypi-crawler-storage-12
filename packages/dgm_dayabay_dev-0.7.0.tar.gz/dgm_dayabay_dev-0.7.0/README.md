# dgm-dayabay-dev

[![python](https://img.shields.io/badge/python-3.11-purple.svg)](https://www.python.org/)
[![pipeline](https://git.jinr.ru/dagflow-team/dgm-dayabay-dev/badges/main/pipeline.svg)](https://git.jinr.ru/dagflow-team/dgm-dayabay-dev/commits/main)
[![coverage report](https://git.jinr.ru/dagflow-team/dgm-dayabay-dev/badges/main/coverage.svg)](https://git.jinr.ru/dagflow-team/dgm-dayabay-dev/-/commits/main)

<!--- Uncomment here after adding docs!
[![pages](https://img.shields.io/badge/pages-link-white.svg)](http://dagflow-team.pages.jinr.ru/dgm-dayabay-dev)
-->

Implementation of the Daya Bay model for `dag-modelling` framework. Development version.

## Repositories

- Main repo:
  - Development/CI: https://git.jinr.ru/dagflow-team/dgm-dayabay-dev
  - Contact/pypi/mirror: https://github.com/dagflow-team/dgm-dayabay-dev
  - PYPI: https://pypi.org/project/dgm-dayabay-dev
