def hello() -> str:
    return "Hello from good-common!"
