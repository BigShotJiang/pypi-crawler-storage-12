************************
Near-IR, multi-slit arcs
************************

.. figure:: NIR_MOS_arc.svg
   :alt: DR flowchart for MOS wavelength calibration.
   :height: 1200
   :width: 600
   :scale: 50 %

   Reduction of arc exposures using previously-determined flat traces.
   Steps in grey are optional or alternative processing steps.
