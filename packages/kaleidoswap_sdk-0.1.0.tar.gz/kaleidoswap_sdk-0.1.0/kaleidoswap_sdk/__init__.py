# This file is intentionally left blank.
# It marks the 'kaleidoswap_sdk' directory as a Python package.

# You can later expose parts of your SDK here, e.g.:
# from .client import KaleidoSDK
# from .exceptions import KaleidoSDKError
