"""Tests for shortcake CLI."""
