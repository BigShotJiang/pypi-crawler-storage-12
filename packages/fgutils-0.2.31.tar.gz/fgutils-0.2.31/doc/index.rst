.. FGUtils documentation master file, created by
   sphinx-quickstart on Tue Aug 20 09:10:34 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to FGUtils's documentation!
===================================

.. toctree::
   :maxdepth: 1

   getting_started
   functional_groups
   graph_syntax
   proxy_collection
   references
