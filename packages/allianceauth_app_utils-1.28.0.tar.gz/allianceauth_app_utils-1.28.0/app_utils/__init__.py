"""Commonly used utilities and helpers for rapid development of Alliance Auth apps."""

__title__ = "Allianceauth App Utils"
__version__ = "1.28.0"
