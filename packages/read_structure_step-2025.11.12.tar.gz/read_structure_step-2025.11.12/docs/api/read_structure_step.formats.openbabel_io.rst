read\_structure\_step.formats.openbabel\_io package
===================================================

Submodules
----------

read\_structure\_step.formats.openbabel\_io.checkers module
-----------------------------------------------------------

.. automodule:: read_structure_step.formats.openbabel_io.checkers
   :members:
   :undoc-members:
   :show-inheritance:

read\_structure\_step.formats.openbabel\_io.obabel module
---------------------------------------------------------

.. automodule:: read_structure_step.formats.openbabel_io.obabel
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: read_structure_step.formats.openbabel_io
   :members:
   :undoc-members:
   :show-inheritance:
