# -*- coding: utf-8 -*-
"""兼容入口，转发到 kd_search_mcp.main."""

from kd_search_mcp.main import main


if __name__ == "__main__":
    main()