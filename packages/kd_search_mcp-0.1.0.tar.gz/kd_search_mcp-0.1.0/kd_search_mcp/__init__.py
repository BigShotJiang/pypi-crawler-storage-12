"""kd-search-mcp 包初始化。"""

from .main import main, search_developer

__all__ = ["main", "search_developer"]

