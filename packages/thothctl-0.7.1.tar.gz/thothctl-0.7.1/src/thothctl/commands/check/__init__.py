# commands/init/__init__.py
from .cli import cli


__all__ = ["cli"]
