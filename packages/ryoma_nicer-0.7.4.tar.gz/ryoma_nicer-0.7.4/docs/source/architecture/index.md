(ryoma-architecture)=

# Architecture 

Ryoma architecture diagram documentation.

```{toctree}
:maxdepth: 2

architecture
```
