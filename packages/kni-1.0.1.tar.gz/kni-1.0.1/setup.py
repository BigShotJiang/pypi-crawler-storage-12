from setuptools import setup
setup(name="kni",author="Niranjan Kumar K",version="1.0.1",py_module=["kni"],python_requires=">=3.8")
