from typing_extensions import TypeAlias

__all__ = ["ModelID"]

ModelID: TypeAlias = str
