# DDD Physical Units

![Tests](https://github.com/shmakovpn/ddd-physical-units/actions/workflows/python-package.yml/badge.svg)
[![codecov](https://codecov.io/github/shmakovpn/ddd-physical-units/graph/badge.svg)](https://codecov.io/github/shmakovpn/ddd-physical-units)
[![pypi](https://img.shields.io/pypi/v/ddd-physical-units.svg)](https://pypi.python.org/pypi/ddd-physical-units)
[![downloads](https://static.pepy.tech/badge/ddd-physical-units/month)](https://pepy.tech/project/ddd-physical-units)
[![versions](https://img.shields.io/pypi/pyversions/ddd-physical-units.svg)](https://github.com/shmakovpn/ddd-physical-units)



Поддержка единиц измерения в предметно-ориентированном проектировании на языке Python.


