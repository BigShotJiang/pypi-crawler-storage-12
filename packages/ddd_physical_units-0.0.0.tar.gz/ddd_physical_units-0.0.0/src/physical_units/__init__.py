from importlib.metadata import version

from .meter import *  # noqa: F403
from .second import *  # noqa: F403

# __version__ = version("physical_units")