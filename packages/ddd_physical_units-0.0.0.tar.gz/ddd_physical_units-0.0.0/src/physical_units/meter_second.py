import dataclasses

from .base_physical_unit import BasePhysicalUnit

from .meter import Meter
from .second import Second



class MeterPerSend:
    pass 