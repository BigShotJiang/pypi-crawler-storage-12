# -*- coding: utf-8 -*-
__author__ = "lundberg"


class AttestationVerificationError(Exception):
    pass


class MetadataValidationError(Exception):
    pass
