"""Version information for Doctra."""
__version__ = '0.9.2'
