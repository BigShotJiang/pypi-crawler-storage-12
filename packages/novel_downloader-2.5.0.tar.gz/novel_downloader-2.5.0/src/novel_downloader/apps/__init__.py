#!/usr/bin/env python3
"""
novel_downloader.apps
---------------------

Adapters / UI layer. Provides CLI and Web interfaces.
"""
