#!/usr/bin/env python3
"""
novel_downloader.apps.web.components
------------------------------------

Reusable web UI components.
"""

__all__ = ["navbar"]

from .navigation import navbar
