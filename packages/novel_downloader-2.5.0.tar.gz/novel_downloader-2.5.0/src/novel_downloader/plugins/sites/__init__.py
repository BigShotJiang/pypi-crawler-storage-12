#!/usr/bin/env python3
"""
novel_downloader.plugins.sites
------------------------------

Site-specific plugin implementations. Each subpackage represents one site.
"""
