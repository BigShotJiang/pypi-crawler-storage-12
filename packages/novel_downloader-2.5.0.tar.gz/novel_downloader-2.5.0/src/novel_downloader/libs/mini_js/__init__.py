#!/usr/bin/env python3
"""
novel_downloader.libs.mini_js
-----------------------------

Public API surface for mini-js.
"""

__all__ = ["MiniJS"]

from .runtime import MiniJS
