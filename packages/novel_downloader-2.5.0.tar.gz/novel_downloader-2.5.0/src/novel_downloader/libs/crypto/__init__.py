#!/usr/bin/env python3
"""
novel_downloader.libs.crypto
----------------------------

Cryptographic algorithms such as AES and RC4.
"""
