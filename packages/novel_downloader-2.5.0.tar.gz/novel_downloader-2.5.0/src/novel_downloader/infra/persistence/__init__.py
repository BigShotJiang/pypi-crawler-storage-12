#!/usr/bin/env python3
"""
novel_downloader.infra.persistence
----------------------------------

Persistence layer for storing chapters and maintaining state.
"""
