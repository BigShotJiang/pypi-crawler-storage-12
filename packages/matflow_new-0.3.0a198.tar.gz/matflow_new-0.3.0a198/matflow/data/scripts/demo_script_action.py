def demo_script_action():
    pass
