"""
Instance database to easily query the instances from a zip or a folder.
"""

# flake8: noqa F401
from .instance_database import InstanceDatabase

__all__ = ["InstanceDatabase"]
