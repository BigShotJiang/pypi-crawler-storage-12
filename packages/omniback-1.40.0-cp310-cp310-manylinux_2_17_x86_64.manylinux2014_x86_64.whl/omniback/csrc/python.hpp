#ifndef __OMNI_PYTHON_INCLUDE__
#define __OMNI_PYTHON_INCLUDE__

#include <omniback/csrc/py_register.hpp>
#include <omniback/csrc/register.hpp>
#endif
