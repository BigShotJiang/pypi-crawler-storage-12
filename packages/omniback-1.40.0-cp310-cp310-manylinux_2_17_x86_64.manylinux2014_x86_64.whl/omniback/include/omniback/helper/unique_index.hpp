#include <cstddef> // for size_t
#include "omniback/helper/omniback_export.h"
namespace omniback {
OMNI_EXPORT size_t get_unique_index();
}