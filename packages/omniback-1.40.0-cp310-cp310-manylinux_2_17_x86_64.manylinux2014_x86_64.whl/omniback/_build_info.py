# This file is auto-generated during build

USE_CXX11_ABI = 0
PYBIND11_VERSION = '3.0.1'
CMAKE_BUILD_TYPE = 'Release'
PYTHON_VERSION = '3.10'
