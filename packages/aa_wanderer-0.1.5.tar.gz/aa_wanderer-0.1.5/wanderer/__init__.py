"""AA wanderer"""

# pylint: disable = invalid-name

__version__ = "0.1.5"
