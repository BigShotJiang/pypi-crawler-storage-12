from openhands.sdk.context.prompts.prompt import render_template


__all__ = [
    "render_template",
]
