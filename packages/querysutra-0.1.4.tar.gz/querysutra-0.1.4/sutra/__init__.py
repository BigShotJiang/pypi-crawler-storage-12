"""
QuerySUTRA: Structured-Unstructured-Text-Retrieval-Architecture

A comprehensive natural language to SQL query system with visualization and cloud export.

Installation:
    pip install QuerySUTRA

Usage:
    from sutra import SUTRA
    
    sutra = SUTRA(api_key="your-openai-key")
    sutra.upload("data.pdf")  # PDF, DOCX, TXT, CSV, Excel, JSON
    result = sutra.ask("Show me insights", viz=True)

Author: Aditya Batta
Version: 0.1.3
"""

__version__ = "0.1.4"
__author__ = "Aditya Batta"
__title__ = "QuerySUTRA: Structured-Unstructured-Text-Retrieval-Architecture"

from .sutra import SUTRA, QueryResult, quick_start

__all__ = ["SUTRA", "QueryResult", "quick_start"]
