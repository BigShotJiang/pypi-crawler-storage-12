"""Module contains test cases for the Bakalari API."""

import re
import tempfile
from unittest.mock import patch

import aiohttp
from aiohttp import hdrs
from aioresponses import aioresponses
from async_bakalari_api.api_client import ApiClient
from async_bakalari_api.bakalari import Bakalari, Credentials, Schools
from async_bakalari_api.const import EndPoint, Errors
from async_bakalari_api.exceptions import Ex
from async_bakalari_api.logger_api import api_logger
import orjson
import pytest

fs = "http://fake_server"


# @pytest.mark.asyncio
# async def test_bakalari_del_closes_session(monkeypatch):
#     bakalari = Bakalari("http://fake_server", auto_cache_credentials=False)

#     # patch session.close to detect the call
#     closed = False

#     async def close_patch(*a, **k):
#         nonlocal closed
#         closed = True

#     bakalari._session.close = close_patch

#     # 'delete' and force garbage collect
#     del bakalari
#     gc.collect()

#     assert True


# async def test_bakalari_del_outside_loop(monkeypatch):
#     bakalari = Bakalari("http://fake_server", auto_cache_credentials=False)

#     # patch event loop tak, že get_event_loop vyhodí výjimku
#     monkeypatch.setattr(
#         "asyncio.get_event_loop", lambda: (_ for _ in ()).throw(RuntimeError())
#     )
#     loop_ran = False

#     def fake_run_until_complete(coro):
#         nonlocal loop_ran
#         loop_ran = True

#     class FakeLoop:
#         def is_running(self):
#             return False

#         def run_until_complete(self, coro):
#             return fake_run_until_complete(coro)

#     monkeypatch.setattr("asyncio.new_event_loop", lambda: FakeLoop())
#     monkeypatch.setattr("asyncio.set_event_loop", lambda l: None)

#     # patch session.close as sync for test simplicity
#     bakalari._session.close = lambda: None

#     del bakalari
#     gc.collect()
#     assert True


async def test_unauth_request():
    """Test the unauthenticated request function."""
    bakalari = Bakalari("http://fake_server")

    with aioresponses() as m:
        m.get(
            "http://fake_server" + EndPoint.KOMENS_UNREAD_COUNT.get("endpoint"),
            payload="we have data!",
            headers={},
            status=200,
        )
        # we tries to `GET` response on `POST` method
        m.post(
            "http://fake_server" + EndPoint.KOMENS_UNREAD_COUNT.get("endpoint"),
            payload="we should have no data!",
            headers={},
            status=200,
        )

        result = await bakalari.send_unauth_request(EndPoint.KOMENS_UNREAD_COUNT)
        assert result == "we have data!"

        with pytest.raises(Ex.BadRequestException) as ex:
            result = await bakalari.send_unauth_request(EndPoint.KOMENS_UNREAD_COUNT)

        assert "Connection error:" in str(ex.value)
    await bakalari.__aexit__()

    # Bad server URL
    bakalari = Bakalari()
    with pytest.raises(Ex.BadEndpointUrl):
        await bakalari.send_unauth_request(EndPoint.KOMENS_UNREAD_COUNT)
    await bakalari.__aexit__()


async def test_get_request_url():
    """Test case for the get_request_url method of the Bakalari class."""
    bakalari = Bakalari()

    with pytest.raises(Ex.BadEndpointUrl) as ex:
        final_url = bakalari.get_request_url(EndPoint.LOGIN)

    assert "Bad endpoint url" in str(ex.value)

    bakalari._server = "http://fake_server"
    final_url = bakalari.get_request_url(EndPoint.LOGIN)
    assert final_url == "http://fake_server/api/login"


async def test_schools_list_not_recursive():
    """Test the schools_list method withou recrusive parameter of the Bakalari class."""
    bakalari = Bakalari()
    pattern = re.compile(r"^https://sluzby\.bakalari\.cz/.*$")
    api_logger("Bakalari API", loglevel=10).get()

    with aioresponses() as m:
        # town is provided, recursive is False
        m.get(
            pattern,
            headers={"Accept": "application/json"},
            body="""
            [
                {
                    "name": "town name.a",
                    "schoolCount": 1
                },
                {
                    "name": "name town.b",
                    "schoolCount": 1
                },
                {
                    "name":"no town.c"}
            ]
            """,
            status=200,
        )
        m.get(
            pattern,
            headers={"Accept": "application/json"},
            body="""{"name": "name town.b", "schools": [{"name": "school_name_town.b","schoolUrl": "endpoint_url_town.b"}]}""",
        )

        m.get(
            pattern,
            headers={"Accept": "application/json"},
            body="""{"name": "town name.a", "schools": [{"name": "school_name_town.a","schoolUrl": "endpoint_url_town.a"}]}""",
        )

        s: Schools = await bakalari.schools_list(town="name", recursive=False)  # pyright: ignore[]
    assert isinstance(s, Schools)
    assert not s.get_url("school_name_town.a")
    assert s.get_url("school_name_town.b") == "endpoint_url_town.b"
    await bakalari.__aexit__()


async def test_school_list():
    """Test the schools_list method of the Bakalari class."""
    bakalari = Bakalari()
    pattern = re.compile(r"^https://sluzby\.bakalari\.cz/.*$")
    api_logger("Bakalari API", loglevel=10).get()

    with aioresponses() as m:
        m.get(
            pattern,
            headers={"Accept": "application/json"},
            body="""[{"name": "town_name.a","schoolCount": 1},{"name":""}]""",
            status=200,
        )

        m.get(
            pattern,
            headers={"Accept": "application/json"},
            body="""{"name": "town_name", "schools": [{"name": "school_name","schoolUrl": "endpoint_url"}]}""",
        )

        result = await bakalari.schools_list()
        assert isinstance(result, Schools)
        assert result.get_url("school_name") == "endpoint_url"
        assert result.get_school_name_by_api_point("endpoint_url") == "school_name"
        assert isinstance(result.get_schools_by_town("town_name"), list)

        m.post(
            pattern,
            headers={"Accept": "application/json"},
            body="""{"name": "town_name", "schools": [{"name": "school_name","schoolUrl": "endpoint_url"}]}""",
        )
        result = await bakalari.schools_list()
        assert not result

        # town is provided
        m.get(
            pattern,
            headers={"Accept": "application/json"},
            body="""
            [
                {
                    "name": "town name.a",
                    "schoolCount": 1
                },
                {
                    "name": "name town.b",
                    "schoolCount": 1
                },
                {
                    "name":"no town.c"}
            ]
            """,
            status=200,
        )

        m.get(
            pattern,
            headers={"Accept": "application/json"},
            body="""{"name": "town name.a", "schools": [{"name": "school_name_town.a","schoolUrl": "endpoint_url_town.a"}]}""",
        )

        m.get(
            pattern,
            headers={"Accept": "application/json"},
            body="""{"name": "name town.b", "schools": [{"name": "school_name_town.b","schoolUrl": "endpoint_url_town.b"}]}""",
        )

        m.get(
            pattern,
            headers={"Accept": "application/json"},
            body="""{"name": "no town.c", "schools": [{"name": "school_name_no_town.c","schoolUrl": "endpoint_url_town.c"}]}""",
        )
        result = await bakalari.schools_list(town="name")
        assert isinstance(result, Schools)
        assert result.get_url("school_name_town.a") == "endpoint_url_town.a"
        assert result.get_url("school_name_town.b") == "endpoint_url_town.b"
        assert not result.get_url("school_name_no_town.c")
    await bakalari.__aexit__()


async def test__send_request_aioex():
    """Test the _send_request function with aiohttp.ClientConnectionError and TimeoutError exceptions."""

    bakalari = Bakalari("fake_server")

    with patch("asyncio.timeout", side_effect=TimeoutError):
        try:
            await bakalari._send_request("fake_server", hdrs.METH_GET, {})
        except Ex.TimeoutException:
            pytest.raises(Ex.TimeoutException)
        except aiohttp.ClientConnectionError:
            pytest.fail("ClientConnectionError should not be raised")
        except Exception as ex:
            pytest.fail(f"Unexpected exception: {ex}")
        finally:
            await bakalari.__aexit__()

    with patch(
        "aiohttp.ClientSession.request", side_effect=aiohttp.ClientConnectionError
    ):
        try:
            await bakalari._send_request("fake_server", hdrs.METH_GET, {})
        except Ex.BadRequestException:
            pytest.raises(Ex.BadRequestException)
        finally:
            await bakalari.__aexit__()


async def test_send_auth_request():
    """Test the send_auth_request method of the Bakalari class."""

    cache_file = f"{tempfile.TemporaryDirectory()}/cache_file"

    bakalari = Bakalari(
        "http://fake_server", auto_cache_credentials=True, cache_filename=cache_file
    )

    with pytest.raises(Ex.TokenMissing):
        result = await bakalari.send_auth_request(EndPoint.KOMENS_UNREAD)

    # seed initial credentials immutably
    object.__setattr__(
        bakalari,
        "_credentials",
        Credentials(
            username=None,
            access_token="access_token",
            refresh_token="refresh_token",
            user_id=None,
        ),
    )

    # we have expired access token and valid refresh token, we are trying refreshing with token
    with aioresponses() as m:
        m.post(
            fs + EndPoint.KOMENS_UNREAD.endpoint,
            headers={"WWW-Authenticate": Errors.ACCESS_TOKEN_EXPIRED},
            status=401,
        )
        m.post(
            fs + EndPoint.LOGIN.endpoint,
            payload={
                "bak:UserId": "fake_user_id",
                "access_token": "fake_access_token",
                "refresh_token": "fake_refresh_token",
            },
            status=200,
        )

        m.post(
            fs + EndPoint.KOMENS_UNREAD.endpoint,
            headers={},
            payload="we should have some data",
            status=200,
        )

        result = await bakalari.send_auth_request(EndPoint.KOMENS_UNREAD)
        assert result == "we should have some data"
        assert bakalari.credentials.access_token == "fake_access_token"
        assert bakalari.credentials.refresh_token == "fake_refresh_token"
        assert bakalari.credentials.user_id == "fake_user_id"

    # we have expired refresh token and access token
    result = None
    with aioresponses() as m:
        m.post(
            fs + EndPoint.KOMENS_UNREAD.endpoint,
            headers={"WWW-Authenticate": Errors.ACCESS_TOKEN_EXPIRED},
            status=401,
        )

        m.post(
            fs + EndPoint.LOGIN.endpoint,
            headers={"WWW-Authenticate": Errors.REFRESH_TOKEN_EXPIRED},
            payload={
                "bak:UserId": "fake_user_id_expired",
                "access_token": "fake_access_token_expired",
                "refresh_token": "fake_refresh_token_expired",
                "username": "fake_username_expired",
            },
            status=401,
        )
        with pytest.raises(Ex.RefreshTokenExpired):
            result = await bakalari.send_auth_request(EndPoint.KOMENS_UNREAD)

        assert not result
        assert bakalari.credentials.username != "fake_username_expired"
        assert bakalari.credentials.access_token != "fake_access_token_expired"
        assert bakalari.credentials.refresh_token != "fake_refresh_token_expired"
        assert bakalari.credentials.user_id != "fake_user_id_expired"

    # we have valid access token
    result = None
    with aioresponses() as m:
        m.post(
            fs + EndPoint.KOMENS_UNREAD.endpoint,
            headers={},
            payload="we have valid access token",
            status=200,
        )

        result = await bakalari.send_auth_request(EndPoint.KOMENS_UNREAD)

        assert result == "we have valid access token"

    # another exception is raised while using access token
    result = None
    with aioresponses() as m:
        m.post(
            fs + EndPoint.KOMENS_UNREAD.endpoint,
            headers={},
            payload="we should have no data",
            status=200,
            exception=TimeoutError,
        )
        with pytest.raises(Ex.TimeoutException):
            result = await bakalari.send_auth_request(EndPoint.KOMENS_UNREAD)
        assert result != "we should have no data"

    # another exception is raised while using refresh token
    result = None
    with aioresponses() as m:
        m.post(
            fs + EndPoint.KOMENS_UNREAD.endpoint,
            headers={"WWW-Authenticate": Errors.ACCESS_TOKEN_EXPIRED},
            payload="we should have no data",
            status=401,
        )
        m.post(
            fs + EndPoint.LOGIN.endpoint,
            headers={},
            payload="we should have no data",
            status=401,
            exception=TimeoutError,
        )

        with pytest.raises(Ex.TimeoutException):
            result = await bakalari.send_auth_request(EndPoint.KOMENS_UNREAD)
        assert result != "we should have no data"

    # we have an invalid refresh token
    result = None
    with aioresponses() as m:
        m.post(
            fs + EndPoint.KOMENS_UNREAD.endpoint,
            headers={"WWW-Authenticate": Errors.INVALID_TOKEN},
            payload="we should have no data",
            status=401,
        )
        m.post(
            fs + EndPoint.LOGIN.endpoint,
            headers={"WWW-Authenticate": Errors.REFRESH_TOKEN_EXPIRED},
            payload="we should have no data",
            status=401,
        )
        with pytest.raises(Ex.RefreshTokenExpired):
            result = await bakalari.send_auth_request(EndPoint.KOMENS_UNREAD)
    await bakalari.__aexit__()


async def test__send_request():
    """Test the _send_request method of the Bakalari class."""

    bakalari = Bakalari("fake_server")

    with aioresponses() as m:
        # 1 - ACCESS TOKEN EXPIRED
        m.get(
            "fake_server",
            payload={},
            headers={"WWW-Authenticate": Errors.ACCESS_TOKEN_EXPIRED},
            status=401,
        )

        # 2 - REFRESH TOKEN EXPIRED
        m.post(
            "fake_server",
            payload={},
            headers={"WWW-Authenticate": Errors.REFRESH_TOKEN_EXPIRED},
            status=401,
        )

        # 3 - BadRequest in Authentication
        m.get(
            "fake_server",
            payload={},
            headers={"WWW-Authenticate": ""},
            status=401,
        )

        # 4 - INVALID METHOD
        m.get(
            "fake_server",
            payload={"error_uri": Errors.INVALID_METHOD},
            headers={},
            status=400,
        )

        # 5 - INVALID METHOD
        m.get(
            "fake_server",
            payload={"error_uri": Errors.INVALID_LOGIN},
            headers={},
            status=400,
        )

        # 6 - REFRESH TOKEN REDEEMD
        m.get(
            "fake_server",
            payload={"error_uri": Errors.REFRESH_TOKEN_REDEEMD},
            headers={},
            status=400,
        )

        # 7 - INVALID REFRESH TOKEN
        m.get(
            "fake_server",
            payload={"error_uri": Errors.INVALID_REFRESH_TOKEN},
            headers={},
            status=400,
        )

        # 8 - BadRequestExeption in 400
        m.get(
            "fake_server",
            payload={
                "other_exception": "another bad thing happened",
                "error_uri": "err",
            },
            headers={"WWW-Authenticate": "error_uri"},
            status=400,
        )

        # 9 - Pass valid data
        m.get(
            "fake_server",
            payload={"yupiee": "we have a data!"},
            headers={},
            status=200,
        )

        # 10 - Some weird things happening
        m.get(
            "fake_server",
            payload={"Oh god.": "We have some kind of 500 error."},
            headers={},
            status=500,
        )

        # 11 - Some weird things happening
        m.get(
            "fake_server",
            payload={"Oh god.": "We have some kind of 404 error."},
            headers={},
            status=404,
        )

        # TESTS
        # 1
        with pytest.raises(Ex.AccessTokenExpired) as exc:
            response = await bakalari._send_request(
                "fake_server", hdrs.METH_GET, headers={}
            )
        # 2
        with pytest.raises(Ex.RefreshTokenExpired) as exc:
            response = await bakalari._send_request(
                "fake_server", hdrs.METH_POST, headers={}
            )
        # 3
        with pytest.raises(Ex.BadRequestException) as exc:
            response = await bakalari._send_request(
                "fake_server", hdrs.METH_GET, headers={}
            )

        # 4
        with pytest.raises(Ex.InvalidHTTPMethod) as exc:
            response = await bakalari._send_request(
                "fake_server", hdrs.METH_GET, headers={}
            )
        # 5
        with pytest.raises(Ex.InvalidLogin) as exc:
            response = await bakalari._send_request(
                "fake_server", hdrs.METH_GET, headers={}
            )
        # 6
        with pytest.raises(Ex.RefreshTokenRedeemd) as exc:
            response = await bakalari._send_request(
                "fake_server", hdrs.METH_GET, headers={}
            )
        # 7
        with pytest.raises(Ex.InvalidRefreshToken) as exc:
            response = await bakalari._send_request(
                "fake_server", hdrs.METH_GET, headers={}
            )

        # 8
        with pytest.raises(Ex.BadRequestException) as exc:
            response = await bakalari._send_request(
                "fake_server", hdrs.METH_GET, headers={}
            )
        assert "another bad thing happened" in str(exc.value)

        # 9
        response = await bakalari._send_request(
            "fake_server", hdrs.METH_GET, headers={}
        )
        assert response == {"yupiee": "we have a data!"}

        # 10
        with pytest.raises(Ex.BadRequestException) as exc:
            response = await bakalari._send_request(
                "fake_server", hdrs.METH_GET, headers={}
            )
        assert "We have some kind of 500 error." in str(exc.value)

        # 11
        with pytest.raises(Ex.BadRequestException) as exc:
            response = await bakalari._send_request(
                "fake_server", hdrs.METH_GET, headers={}
            )
        assert "Not found! (fake_server)" in str(exc.value)
    await bakalari.__aexit__()


def raise_OSError(*args, **kwargs):
    """OsError exception."""
    raise OSError


@pytest.fixture
def mocker_file(mocker):
    """Mock file for testing."""

    data = b'{"username": "test_name", "access_token": "test_access","refresh_token": "test_refresh", "user_id": "test_user_id"}'
    mocked_file = mocker.mock_open(read_data=data)
    mocker.patch("builtins.open", mocked_file)


async def test_load_credentials_OSError():
    """Test the load_credentials method of the Bakalari class with OSError exception."""

    bakalari = Bakalari()

    # cannot open file
    with patch("builtins.open", raise_OSError):
        false_data = bakalari.load_credentials("fake_file")
        assert not false_data


async def test_load_credentials_success(mocker_file):
    """Test the load_credentials method of the Bakalari class with success."""

    bakalari = Bakalari()

    success = bakalari.load_credentials("fake_file")
    assert success

    assert bakalari.credentials.access_token == "test_access"
    assert bakalari.credentials.refresh_token == "test_refresh"


async def test_save_file_success():
    """Test the save_credentials method of the Bakalari class."""

    bakalari = Bakalari()
    object.__setattr__(
        bakalari,
        "_credentials",
        Credentials.create_from_json(
            {
                "access_token": "test_access",
                "refresh_token": "test_refresh",
                "user_id": "test_user_id",
                "username": "test_username",
            }
        ),
    )

    with tempfile.TemporaryDirectory() as temp_dir:
        filename = temp_dir + "test_data"
        bakalari.save_credentials(filename=filename)

        with open(filename, "+rb") as file:
            data = orjson.loads(file.read())
            file.close()

        assert data.get("access_token") == bakalari.credentials.access_token
        assert data.get("refresh_token") == bakalari.credentials.refresh_token
        assert data.get("user_id") == bakalari.credentials.user_id

    with tempfile.TemporaryDirectory() as temp_dir:
        filename = temp_dir

        with patch("builtins.open", raise_OSError):
            false = bakalari.save_credentials(filename=filename)
            assert not false


async def test_save_file_cache_file():
    """Test the save_credentials method of the Bakalari class with cache file."""

    # we have auto_cache, but no filename provided.
    with pytest.raises(Ex.CacheError) as ex:
        bakalari = Bakalari("", auto_cache_credentials=True, cache_filename=None)
    assert "Auto-cache is enabled, but no filename is provided!" in str(ex.value)

    bakalari = Bakalari("", auto_cache_credentials=True, cache_filename="fake_file")
    object.__setattr__(
        bakalari,
        "_credentials",
        Credentials.create_from_json(
            {
                "access_token": "test_access",
                "refresh_token": "test_refresh",
                "user_id": "test_user_id",
                "username": "test_username",
            }
        ),
    )

    with tempfile.TemporaryDirectory() as temp_dir:
        filename = temp_dir + "test_data"
        bakalari._cache_filename = filename
        bakalari.save_credentials()

        with open(filename, "+rb") as file:
            data = orjson.loads(file.read())
            file.close()

        assert data.get("access_token") == bakalari.credentials.access_token
        assert data.get("refresh_token") == bakalari.credentials.refresh_token
        assert data.get("user_id") == bakalari.credentials.user_id


async def test_first_login():
    """Test the first_login method of the Bakalari class."""

    filename = f"{tempfile.TemporaryDirectory()}/cache_file"
    bakalari = Bakalari(fs, auto_cache_credentials=True, cache_filename=filename)

    # we have valid username and password
    with aioresponses() as m:
        m.post(
            url=fs + EndPoint.LOGIN.endpoint,
            headers={},
            payload={
                "bak:UserId": "fake_user_id",
                "access_token": "fake_access_token",
                "token_type": "Bearer",
                "expires_in": 0,
                "scope": "offline_access bakalari_api",
                "refresh_token": "fake_refresh_token",
            },
            status=200,
        )

        result = await bakalari.first_login("username", "password")
        assert isinstance(result, Credentials)
        assert bakalari.credentials.access_token == "fake_access_token"
        assert bakalari.credentials.refresh_token == "fake_refresh_token"

    # we don't have valid username / password provided
    # we have valid username and password
    with aioresponses() as m:
        m.post(
            url=fs + EndPoint.LOGIN.endpoint,
            headers={},
            payload={"error_uri": Errors.INVALID_LOGIN},
            status=400,
        )
        with pytest.raises(Ex.InvalidLogin) as ex:
            result = await bakalari.first_login("username", "password")

        assert "Invalid login!" in str(ex.value)
    await bakalari.__aexit__()


async def test_refresh_access_token_no_token():
    """refresh_access_token raises when no refresh token is available."""
    bakalari = Bakalari(fs)
    # Seed credentials without refresh token
    object.__setattr__(
        bakalari,
        "_credentials",
        Credentials(username=None, access_token="at", refresh_token=None, user_id=None),
    )
    with pytest.raises(Ex.RefreshTokenExpired):
        await bakalari.refresh_access_token()
    await bakalari.__aexit__()


async def test_schools_list_error_branches(monkeypatch):
    """Cover error branches in schools_list for various invalid town responses."""
    bak = Bakalari()

    # Initial list of towns (valid response from SCHOOL_LIST)
    towns = [
        {"name": "T1"},
        {"name": "T2"},
        {"name": "T3"},
        {"name": "T4"},
        {"name": "T5"},
    ]

    async def fake_send_unauth(self, endpoint, *a, **k):
        if endpoint is EndPoint.SCHOOL_LIST:
            return towns
        raise AssertionError("Unexpected unauth call")

    async def fake_client_request(self, url, method, headers=None, retry=0, **kwargs):
        # T1 -> raises exception (covered: isinstance(response_town, Exception))
        if "T1" in url:
            raise RuntimeError("boom")
        # T2 -> returns non-dict (covered: not isinstance(response_town, dict))
        if "T2" in url:
            return "not a dict"
        # T3 -> dict but schools is not a list (covered: not isinstance(schools, list))
        if "T3" in url:
            return {"name": "T3", "schools": "not a list"}
        # T4 -> dict with schools list containing non-dict entries (covered: inner skip)
        if "T4" in url:
            return {"name": "T4", "schools": [123, {"bad": "entry"}]}
        # T5 -> valid payload, should be appended
        if "T5" in url:
            return {
                "name": "T5",
                "schools": [{"name": "Good", "schoolUrl": "endpoint"}],
            }
        return {}

    monkeypatch.setattr(Bakalari, "send_unauth_request", fake_send_unauth)
    monkeypatch.setattr(ApiClient, "request", fake_client_request)

    result = await bak.schools_list()
    assert result.get_url("Good") == "endpoint"
    await bak.__aexit__()


async def test_get_request_url_absolute_endpoint():
    """Absolute endpoint should be returned as-is, even without server set."""
    bak = Bakalari()
    # EndPoint.SCHOOL_LIST is absolute (https://...)
    url = bak.get_request_url(EndPoint.SCHOOL_LIST)
    assert url == EndPoint.SCHOOL_LIST.endpoint

    # Even if server is set, absolute endpoints remain unchanged
    bak2 = Bakalari("http://irrelevant")
    url2 = bak2.get_request_url(EndPoint.SCHOOL_LIST)
    assert url2 == EndPoint.SCHOOL_LIST.endpoint
    await bak.__aexit__()
    await bak2.__aexit__()


async def test_bakalari_property_getters():
    """Cover simple property getters for coverage."""
    bak = Bakalari("http://srv")
    assert bak.server == "http://srv"
    assert bak.auto_cache_credentials is False
    assert bak.cache_filename is None

    bak2 = Bakalari(
        "http://srv2", auto_cache_credentials=True, cache_filename="cf.json"
    )
    assert bak2.server == "http://srv2"
    assert bak2.auto_cache_credentials is True
    assert bak2.cache_filename == "cf.json"
    await bak.__aexit__()
    await bak2.__aexit__()


async def test_send_auth_request_get_with_extend():
    """Cover GET method selection and `extend` path handling in send_auth_request."""
    bak = Bakalari(fs)
    # Seed valid tokens
    object.__setattr__(
        bak,
        "_credentials",
        Credentials(username=None, access_token="AT", refresh_token="RT", user_id=None),
    )
    with aioresponses() as m:
        # MARKS is GET endpoint; ensure extend gets appended
        m.get(
            fs + EndPoint.MARKS.endpoint + "/extra",
            headers={},
            payload={"ok": True},
            status=200,
        )
        res = await bak.send_auth_request(EndPoint.MARKS, extend="/extra")
        assert res == {"ok": True}
    await bak.__aexit__()


async def test_save_credentials_missing_filename_returns_false():
    """Cover branch where save_credentials is called without filename and no cache filename is set."""
    bak = Bakalari(fs)  # no cache filename set
    # Seed credentials so serialization would succeed, filename branch is what we test
    object.__setattr__(
        bak,
        "_credentials",
        Credentials(username="u", access_token="at", refresh_token="rt", user_id="id"),
    )
    assert bak.save_credentials() is False


async def test_schools_list_invalid_towns_response(monkeypatch):
    """Return None when towns_json is not a list."""
    bak = Bakalari()

    async def fake_send_unauth(self, endpoint, *a, **k):
        if endpoint is EndPoint.SCHOOL_LIST:
            return {"unexpected": "dict"}  # invalid type
        raise AssertionError("Unexpected endpoint")

    monkeypatch.setattr(Bakalari, "send_unauth_request", fake_send_unauth)

    result = await bak.schools_list()
    assert result is None
    await bak.__aexit__()


async def test_send_auth_request_refresh_then_second_call_refresh_expired():
    """Cover branch where second request after refresh raises RefreshTokenExpired (lines 146-148)."""
    bak = Bakalari(fs)
    # Seed valid tokens
    object.__setattr__(
        bak,
        "_credentials",
        Credentials(username=None, access_token="AT", refresh_token="RT", user_id=None),
    )

    with aioresponses() as m:
        # First attempt: access token expired -> triggers refresh flow
        m.post(
            fs + EndPoint.KOMENS_UNREAD.endpoint,
            headers={"WWW-Authenticate": Errors.ACCESS_TOKEN_EXPIRED},
            status=401,
        )
        # Refresh succeeds and sets new tokens
        m.post(
            fs + EndPoint.LOGIN.endpoint,
            headers={},
            payload={
                "bak:UserId": "uid",
                "access_token": "newAT",
                "refresh_token": "newRT",
            },
            status=200,
        )
        # Second attempt after refresh: simulate refresh token expired header on endpoint
        # to raise Ex.RefreshTokenExpired inside the inner try/except
        m.post(
            fs + EndPoint.KOMENS_UNREAD.endpoint,
            headers={"WWW-Authenticate": Errors.REFRESH_TOKEN_EXPIRED},
            status=401,
        )

        with pytest.raises(Ex.RefreshTokenExpired):
            await bak.send_auth_request(EndPoint.KOMENS_UNREAD)

    await bak.__aexit__()
