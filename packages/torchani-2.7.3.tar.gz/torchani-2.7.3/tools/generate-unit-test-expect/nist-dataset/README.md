# Commands

## Download all 3d structures from NIST

```
scrapy runspider get_nist.py -o result.json
```
