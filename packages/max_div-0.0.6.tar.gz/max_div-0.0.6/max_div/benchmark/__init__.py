from .sample_int import benchmark_sample_int
