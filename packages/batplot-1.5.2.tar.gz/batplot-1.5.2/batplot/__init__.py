"""batplot: Interactive plotting for battery data visualization."""

__version__ = "1.5.2"

__all__ = ["__version__"]
