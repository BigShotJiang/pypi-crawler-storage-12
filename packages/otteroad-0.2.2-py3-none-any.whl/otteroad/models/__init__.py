"""All models for IDU services are defined here."""

from .indicator_events import *
from .scenario_events import *
from .urban_events import *
