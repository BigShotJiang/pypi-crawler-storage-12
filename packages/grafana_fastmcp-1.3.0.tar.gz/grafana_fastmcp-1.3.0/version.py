"""Version information for grafana-fastmcp."""

__version__ = "1.3.0"
