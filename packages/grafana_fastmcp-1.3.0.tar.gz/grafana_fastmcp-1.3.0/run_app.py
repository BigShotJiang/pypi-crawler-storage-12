"""Standalone entrypoint for packaging the Grafana FastMCP server."""

from app.main import main

if __name__ == "__main__":
    main()
