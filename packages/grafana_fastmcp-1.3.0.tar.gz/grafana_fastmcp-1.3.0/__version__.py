# This file is used as the single source of truth for the package version.
# Keep the value here and configure the build backend (hatchling) to read it.

__version__ = "1.2.3"
