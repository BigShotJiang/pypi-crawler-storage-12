from .errors import BrowserImportError

__all__ = ("BrowserImportError",)
