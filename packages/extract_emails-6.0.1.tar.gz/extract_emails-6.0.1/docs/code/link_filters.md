# Link Filters

::: extract_emails.link_filters.link_filter_base
::: extract_emails.link_filters.default_link_filter
::: extract_emails.link_filters.contact_link_filter
