# Browsers

::: extract_emails.browsers.page_source_getter

::: extract_emails.browsers.chromium_browser

::: extract_emails.browsers.httpx_browser
