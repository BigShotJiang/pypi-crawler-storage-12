# coding=utf-8
from .._impl import (
    storage_series_api_NominalDataType as NominalDataType,
)

__all__ = [
    'NominalDataType',
]

