You should configure first the module `web_view_leaflet_map` to enable
the feature.
