- go to 'Contact'.
- a new map icon is available.

![](../static/description/res_partner_button.png)

- by clicking on it, the partners are displayed on the map, if the
  latitude and longitude are defined. (see `base_geolocalize` module)

![](../static/description/view_res_partner_map.png)
