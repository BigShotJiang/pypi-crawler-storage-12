This module extends the `web_view_leaflet_map` odoo module, to add a map
view on the res.partner model.
