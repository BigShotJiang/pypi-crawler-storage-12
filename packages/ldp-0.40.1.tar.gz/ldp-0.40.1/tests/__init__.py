import pathlib

TESTS_DIR = pathlib.Path(__file__).parent
CASSETTES_DIR = TESTS_DIR / "cassettes"
