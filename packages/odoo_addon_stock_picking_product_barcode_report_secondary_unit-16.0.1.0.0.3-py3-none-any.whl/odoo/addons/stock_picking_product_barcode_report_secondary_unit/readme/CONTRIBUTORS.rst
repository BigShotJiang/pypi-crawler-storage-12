* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Roca
  * Sergio Teruel

* `Heliconia Solutions Pvt. Ltd. <https://www.heliconia.io>`_
