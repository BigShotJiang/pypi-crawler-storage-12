This module extends the functionality of stock_picking_product_barcode_report to set by
default the maximum qty on labels depending of the secondary unit.
