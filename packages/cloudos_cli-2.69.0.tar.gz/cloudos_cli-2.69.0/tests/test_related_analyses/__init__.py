"""Tests for related analyses module"""
