"""Data models for LinkedIn Spider."""

from linkedin_spider.models.profile import Profile, ProfileCollection

__all__ = ["Profile", "ProfileCollection"]
