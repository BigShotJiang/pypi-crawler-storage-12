"""Allow LinkedIn Spider to be run as: python -m linkedin_spider"""

from linkedin_spider.cli.main import app

if __name__ == "__main__":
    app()
