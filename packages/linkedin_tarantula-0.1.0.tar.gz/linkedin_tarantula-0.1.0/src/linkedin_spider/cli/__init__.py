"""CLI interface for LinkedIn Spider."""

from linkedin_spider.cli.main import app

__all__ = ["app"]
