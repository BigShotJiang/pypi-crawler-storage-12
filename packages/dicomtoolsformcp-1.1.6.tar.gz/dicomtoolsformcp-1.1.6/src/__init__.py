"""
Src package initialization.
"""
