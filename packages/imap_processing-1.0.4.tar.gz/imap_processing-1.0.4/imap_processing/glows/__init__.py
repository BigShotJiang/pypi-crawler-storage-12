__version__ = "v001"

# Quality flag list length. Used in L1B and L2.
FLAG_LENGTH = 17
