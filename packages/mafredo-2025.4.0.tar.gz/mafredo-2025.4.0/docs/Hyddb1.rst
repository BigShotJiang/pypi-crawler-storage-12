Hydrodynamic database
======================


.. autoclass:: mafredo.Hyddb1
