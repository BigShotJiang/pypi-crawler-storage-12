from mafredo import Rao, Hyddb1


def test_rao():
    _r = Rao()


def test_hyddb1():
    _h = Hyddb1()
