# Changelog

## Version 2025.2.0

- Removed NetCDF4 in favour of hypy5, this solves fatal crashes that occured when reading a db twice.

## Version 2025.1.0

- Converted setup.cfg to pyproject.toml
- Fixed all unit tests

## Version 0.1

- Made creation methods static and renamed from `load` to `create`
