from importlib.metadata import version as get_version

__version__: str = get_version("linkup-sdk")
