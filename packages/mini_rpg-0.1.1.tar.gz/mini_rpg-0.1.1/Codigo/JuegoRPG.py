import random

# Función que crea un personaje usando un diccionario
def crear_personaje(nombre, salud, ataque, defensa, min_ataque, max_ataque):
    return {
        "nombre": nombre,
        "salud": salud,
        "ataque": ataque,
        "defensa": defensa,
        "min_ataque": min_ataque,
        "max_ataque": max_ataque,
        "daño_total": 0,
        "golpes_acertados": 0
    }

# Función para realizar el ataque entre dos personajes
def atacar(atacante, defensor, defensor_defendiéndose=False):
    # Calcula daño aleatorio según el rango definido
    daño = random.randint(atacante["min_ataque"], atacante["max_ataque"])
    # Si el defensor se defiende, su defensa se duplica
    defensa_real = defensor["defensa"] * 2 if defensor_defendiéndose else defensor["defensa"]
    daño_real = max(0, daño - defensa_real)
    defensor["salud"] -= daño_real
    atacante["daño_total"] += daño_real
    if daño_real > 0:
        atacante["golpes_acertados"] += 1
    return daño_real

# Tipos de acciones que el usuario puede hacer en cada turno
def obtener_accion():
    while True:
        try:
            accion = int(input("Elige acción: 1) Atacar  2) Defenderse → "))
            if accion not in [1, 2]:
                raise ValueError("Debes elegir 1 o 2")
            return accion
        except ValueError as e:
            print(f"Error: {e}. Intenta de nuevo.")

# Metodo para elegir la dificultad (Menu con 3 tipos de dificultades)
def elegir_dificultad():
    while True:
        try:
            nivel = int(input("Elige dificultad: 1) Fácil  2) Normal  3) Difícil → "))
            if nivel == 1:
                return crear_personaje("Slime", 20, 0, 2, 1, 5)
            elif nivel == 2:
                return crear_personaje("Esqueleto", 25, 0, 3, 1, 5)
            elif nivel == 3:
                return crear_personaje("Dragón", 40, 0, 5, 1, 5)
            else:
                print("Número inválido")
        except ValueError:
            print("Debes escribir 1, 2 o 3.")

# Texto entre turnos junto a las estadísticas
def combate(jugador, enemigo):
    turno = 1
    print(f"\n¡Comienza el combate entre {jugador['nombre']} y {enemigo['nombre']}!\n")

    while jugador["salud"] > 0 and enemigo["salud"] > 0:
        print(f"--- Turno {turno} ---")
        print(f"Salud {jugador['nombre']}: {jugador['salud']}")
        print(f"Salud {enemigo['nombre']}: {enemigo['salud']}")

        accion = obtener_accion()

        # Turno del jugador
        if accion == 1:   # Atacar
            daño = atacar(jugador, enemigo)
            print(f"Has hecho {daño} de daño a {enemigo['nombre']}!")
        else:
            print("Te defiendes y reduces el daño del enemigo este turno.")

        if enemigo["salud"] <= 0:
            break

        # Turno enemigo
        if accion == 2:
            # jugador se defiende → la defensa se duplica
            daño_enemigo = atacar(enemigo, jugador, defensor_defendiéndose=True)
        else:
            daño_enemigo = atacar(enemigo, jugador)

        print(f"{enemigo['nombre']} te hace {daño_enemigo} de daño.\n")

        turno += 1

    # Resultado del combate
    print("\n--- FIN DEL COMBATE ---")
    if jugador["salud"] > 0:
        print(f"¡Ganaste! {jugador['nombre']} derrotó a {enemigo['nombre']}.")
    else:
        print(f"Perdiste... {enemigo['nombre']} ganó el combate.")

    # Estadísticas
    print("\n--- ESTADÍSTICAS ---")
    print(f"Daño total realizado: {jugador['daño_total']}")
    print(f"Golpes acertados: {jugador['golpes_acertados']}")

# Funcion principal
def main():
    print("------ EMPIEZA LA AVENTURA ------")
    jugador = crear_personaje("Héroe", 30, 0, 4, 1, 10)
    enemigo = elegir_dificultad()
    combate(jugador, enemigo)


if __name__ == "__main__":
    main()