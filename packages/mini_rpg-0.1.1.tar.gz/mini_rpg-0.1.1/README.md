# Mini RPG de Combate

Proyecto que consiste en un Mini RPG de combate por consola, hecho en Python.  
La idea es crear un juego donde el usuario, como jugador, lucha contra un enemigo eligiendo segun los 3 niveles de dificultad y acciones por turnos.

---

# Como jugar

- Se te pedirá que elijas la dificultad del enemigo:
    - Fácil → Slime
    - Normal → Esqueleto
    - Difícil → Dragón

- Por turnos puedes elegir:
    - Atacar → haces daño al enemigo.
    - Defenderte → reduces el daño que el enemigo te hace este turno.

- El combate termina cuando uno de los dos personajes se queda sin salud.
- Al final se muestran tus estadísticas: daño total realizado y golpes acertados.

# Ejecuta el programa:
```bash
python -m mini_rpg