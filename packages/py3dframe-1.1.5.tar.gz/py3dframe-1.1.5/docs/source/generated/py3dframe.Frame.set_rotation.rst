set\_rotation
=============

.. currentmodule:: py3dframe

.. automethod:: Frame.set_rotation