set\_rotation\_matrix
=====================

.. currentmodule:: py3dframe

.. automethod:: Frame.set_rotation_matrix