get\_active\_output\_frame
==========================

.. currentmodule:: py3dframe

.. automethod:: FrameTransform.get_active_output_frame