global\_quaternion
==================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.global_quaternion