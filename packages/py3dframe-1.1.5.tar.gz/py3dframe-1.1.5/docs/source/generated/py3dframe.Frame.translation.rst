translation
===========

.. currentmodule:: py3dframe

.. autoproperty:: Frame.translation