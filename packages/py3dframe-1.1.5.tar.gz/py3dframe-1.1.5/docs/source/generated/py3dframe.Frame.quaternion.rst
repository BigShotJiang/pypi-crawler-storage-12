quaternion
==========

.. currentmodule:: py3dframe

.. autoproperty:: Frame.quaternion