deepcopy
========

.. currentmodule:: py3dframe

.. automethod:: Frame.deepcopy