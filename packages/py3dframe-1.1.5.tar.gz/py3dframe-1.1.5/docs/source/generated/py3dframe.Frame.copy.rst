copy
====

.. currentmodule:: py3dframe

.. automethod:: Frame.copy