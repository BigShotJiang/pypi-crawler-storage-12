set\_global\_rotation\_vector
=============================

.. currentmodule:: py3dframe

.. automethod:: Frame.set_global_rotation_vector