dynamic
=======

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.dynamic