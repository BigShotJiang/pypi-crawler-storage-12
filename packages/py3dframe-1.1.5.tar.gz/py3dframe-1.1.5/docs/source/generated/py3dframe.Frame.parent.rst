parent
======

.. currentmodule:: py3dframe

.. autoproperty:: Frame.parent