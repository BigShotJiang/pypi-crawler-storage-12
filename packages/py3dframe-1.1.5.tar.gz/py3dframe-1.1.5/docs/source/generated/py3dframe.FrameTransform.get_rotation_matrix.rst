get\_rotation\_matrix
=====================

.. currentmodule:: py3dframe

.. automethod:: FrameTransform.get_rotation_matrix