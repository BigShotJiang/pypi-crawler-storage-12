from\_quaternion
================

.. currentmodule:: py3dframe

.. automethod:: Frame.from_quaternion