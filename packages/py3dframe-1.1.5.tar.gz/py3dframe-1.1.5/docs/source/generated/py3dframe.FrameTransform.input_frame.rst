input\_frame
============

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.input_frame