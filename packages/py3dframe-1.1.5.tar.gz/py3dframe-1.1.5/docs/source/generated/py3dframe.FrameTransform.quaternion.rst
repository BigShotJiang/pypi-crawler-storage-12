quaternion
==========

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.quaternion