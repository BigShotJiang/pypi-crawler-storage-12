rotation\_vector
================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.rotation_vector