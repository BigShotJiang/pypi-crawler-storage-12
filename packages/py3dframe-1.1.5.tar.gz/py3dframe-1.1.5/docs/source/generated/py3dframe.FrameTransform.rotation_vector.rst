rotation\_vector
================

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.rotation_vector