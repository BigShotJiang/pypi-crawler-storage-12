from setuptools import setup, find_packages

setup(
    name="onflow-wms-shared-auth",
    version="0.1.6",
    packages=find_packages(),
)
