"""
Example of using the Synqed client to interact with an agent.

Make sure you have an agent running (e.g., from basic_agent.py) before running this.
"""

import asyncio
from synqed import SynqedClient


async def main():
    # Connect to an agent
    agent_url = "http://localhost:8000"
    
    print(f"Connecting to agent at {agent_url}...")
    
    async with SynqedClient(agent_url) as client:
        print(f"Connected: {client}\n")
        
        # Send a simple message and stream the response
        print("Sending message: 'Hello, agent!'")
        print("Response:")
        async for chunk in client.send("Hello, agent!"):
            print(chunk, end="", flush=True)
        print("\n")
        
        # Send another message and wait for complete response
        print("Sending message: 'What can you help me with?'")
        response = await client.send_and_wait("What can you help me with?")
        print(f"Complete response: {response}\n")
        
        # Send a third message
        print("Sending message: 'Thank you!'")
        response = await client.send_and_wait("Thank you!")
        print(f"Response: {response}\n")


if __name__ == "__main__":
    asyncio.run(main())

