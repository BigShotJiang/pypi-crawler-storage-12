"""
Basic example of creating and running an agent with Synqed.
"""

import asyncio
import synqed

async def my_agent_logic(context):
    """
    Custom agent logic - this is where you implement your agent's behavior.
    
    Args:
        context: RequestContext with information about the request
        
    Returns:
        A string response or Message object
    """
    # Get the user's message
    user_message = context.get_request_message_text()
    
    # Your custom logic here
    response = f"You said: '{user_message}'. I'm here to help!"
    
    return response


async def main():
    # Create an agent with simple configuration
    agent = Agent(
        name="My First Agent",
        description="A helpful assistant that echoes messages",
        skills=["echo", "conversation"],
        executor=my_agent_logic,
        version="1.0.0",
    )
    
    print(f"Created agent: {agent}")
    print(f"Agent card: {agent.card.model_dump_json(indent=2)}")
    
    # Create a server for the agent
    server = AgentServer(agent, host="0.0.0.0", port=8000)
    
    print(f"\nStarting server at {server.url}")
    print("Press Ctrl+C to stop")
    
    # Start the server (this will run until interrupted)
    try:
        await server.start()
    except KeyboardInterrupt:
        print("\nShutting down...")


if __name__ == "__main__":
    asyncio.run(main())

