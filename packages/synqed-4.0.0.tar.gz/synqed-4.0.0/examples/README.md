# Synqed Examples

This directory contains example scripts demonstrating how to use Synqed for building multi-agent systems.

## Prerequisites

Make sure you have Synqed installed:

```bash
pip install synqed
# Or if installing from source:
cd Synq && pip install -e .
```

You'll also need uvicorn to run the servers:

```bash
pip install uvicorn
```

## Examples

### 1. Basic Agent (`basic_agent.py`)

Creates a simple agent with custom logic and starts a server.

```bash
python examples/basic_agent.py
```

This will start an agent server on `http://localhost:8000`. The agent will:
- Accept messages
- Process them with custom logic
- Return responses

### 2. Client Example (`client_example.py`)

Shows how to connect to an agent and send messages using the Synqed client.

**Prerequisites:** Make sure you have an agent running (e.g., from `basic_agent.py`)

```bash
# In one terminal, start the agent:
python examples/basic_agent.py

# In another terminal, run the client:
python examples/client_example.py
```

The client demonstrates:
- Connecting to an agent
- Streaming responses
- Waiting for complete responses
- Using async context managers

### 3. Multi-Agent Delegation (`multi_agent_delegation.py`)

Demonstrates the power of the TaskDelegator for coordinating multiple specialized agents.

```bash
python examples/multi_agent_delegation.py
```

This example:
- Creates 3 specialized agents (Recipe, Shopping, Weather)
- Starts servers for each agent
- Uses TaskDelegator to automatically route tasks to the right agent
- Shows various delegation strategies:
  - Automatic agent selection
  - Skill-based routing
  - Preferred agent selection
  - Broadcasting to multiple agents

## Architecture

```
┌─────────────────┐
│   TaskDelegator │  ← Orchestrates multiple agents
└────────┬────────┘
         │
         ├──────────┬──────────┬──────────┐
         │          │          │          │
    ┌────▼───┐ ┌───▼────┐ ┌───▼────┐ ┌───▼────┐
    │ Agent  │ │ Agent  │ │ Agent  │ │ Agent  │
    │   1    │ │   2    │ │   3    │ │   N    │
    └────┬───┘ └───┬────┘ └───┬────┘ └───┬────┘
         │         │          │          │
    ┌────▼─────────▼──────────▼──────────▼────┐
    │          A2A Protocol Layer             │
    └─────────────────────────────────────────┘
```

## Creating Your Own Agent

Here's a minimal example:

```python
import asyncio
from synqed import Agent, AgentServer

async def my_logic(context):
    message = context.get_request_message_text()
    return f"Processed: {message}"

agent = Agent(
    name="My Agent",
    description="Does something useful",
    skills=["skill1", "skill2"],
    executor=my_logic
)

server = AgentServer(agent, port=8000)
await server.start()
```

## Tips

1. **Development Mode**: Use `host="127.0.0.1"` for local development
2. **Production Mode**: Use `host="0.0.0.0"` and configure proper security
3. **Multiple Agents**: Use different ports for each agent
4. **Background Tasks**: Use `server.start_background()` to run servers without blocking
5. **Error Handling**: Always wrap agent logic in try-except blocks
6. **Logging**: Enable logging to debug issues:
   ```python
   import logging
   logging.basicConfig(level=logging.INFO)
   ```

## Next Steps

- Check out the [main documentation](../README.md)
- Explore the A2A protocol: https://a2a-protocol.org
- Build your own multi-agent system!

