# Publishing Synqed to PyPI

This guide covers how to publish the Synqed package to PyPI.

## Prerequisites

1. **PyPI Account**: Create accounts on:
   - Test PyPI: https://test.pypi.org/account/register/
   - Production PyPI: https://pypi.org/account/register/

2. **API Tokens**: Generate API tokens for both:
   - Test PyPI: https://test.pypi.org/manage/account/token/
   - Production PyPI: https://pypi.org/manage/account/token/

3. **Set Up Environment Variables**:
```bash
# Copy the example file
cp .env.example .env

# Edit .env and add your tokens
# TWINE_PASSWORD=your-production-token
# TWINE_TEST_PASSWORD=your-test-token
```

4. **Install Build Tools**:
```bash
pip install --upgrade build twine
```

## Pre-Publishing Checklist

- [ ] Version number updated in `pyproject.toml`
- [ ] CHANGELOG updated with latest changes
- [ ] All tests passing
- [ ] Documentation up to date
- [ ] LICENSE file present
- [ ] README.md is comprehensive

## Build the Package

### 1. Clean Previous Builds
```bash
rm -rf dist/ build/ *.egg-info
```

### 2. Build Distribution Files
```bash

python -m build
```

This creates:
- `dist/synqed-X.Y.Z-py3-none-any.whl` (wheel)
- `dist/synqed-X.Y.Z.tar.gz` (source distribution)

### 3. Check the Build
```bash

twine check dist/*
```

## Test on Test PyPI (Recommended)

### 1. Upload to Test PyPI

**Using environment variables (recommended):**
```bash
# Token is loaded from .env file
./scripts/publish.sh --test
```

**Or manually with twine:**
```bash
# Using .env file
source .env
twine upload --repository testpypi dist/* --username __token__ --password $TWINE_TEST_PASSWORD

# Or specify directly
twine upload --repository testpypi dist/* --username __token__ --password <your-test-pypi-token>
```

### 2. Test Installation
```bash
# In a fresh virtual environment
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple synqed
```

### 3. Verify Installation
```python
import synqed
print(synqed.__version__)
```

## Publish to Production PyPI

### 1. Upload to PyPI

**Using environment variables (recommended):**
```bash
# Token is loaded from .env file
./scripts/publish.sh --prod
```

**Or manually with twine:**
```bash
# Using .env file

source .env
twine upload dist/* --username __token__ --password $TWINE_PASSWORD

# Or specify directly
twine upload dist/* --username __token__ --password <your-pypi-token>
```

### 2. Verify Publication
Visit: https://pypi.org/project/synqed/

### 3. Test Installation
```bash
pip install synqed
```

## Using .pypirc (Optional)

Create `~/.pypirc` to store credentials:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = <your-production-token>

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = <your-test-token>
```

Then upload with:
```bash
twine upload --repository testpypi dist/*
twine upload --repository pypi dist/*
```

## Automated Publishing Script

For convenience, use the included script:

```bash
# Test PyPI
./scripts/publish.sh --test

# Production PyPI
./scripts/publish.sh --prod
```

## Version Management

Update version in `pyproject.toml`:

```toml
[project]
name = "synqed"
version = "1.0.0"  # Update this
```

Follow [Semantic Versioning](https://semver.org/):
- `MAJOR.MINOR.PATCH`
- `1.0.0` - Initial release
- `1.0.1` - Patch (bug fixes)
- `1.1.0` - Minor (new features, backwards compatible)
- `2.0.0` - Major (breaking changes)

## Troubleshooting

### Error: File already exists
- You cannot re-upload the same version
- Increment the version number in `pyproject.toml`
- Rebuild and upload again

### Error: Invalid credentials
- Verify your API token is correct
- Ensure you're using `__token__` as username
- Check token has not expired

### Error: Missing dependencies
- Ensure all dependencies in `pyproject.toml` exist on PyPI
- Check dependency version constraints are valid

## Post-Publishing

1. **Tag the Release**:
```bash
git tag -a v1.0.0 -m "Release version 1.0.0"
git push origin v1.0.0
```

2. **Create GitHub Release**:
- Go to: https://github.com/your-org/synqed-python/releases
- Click "Create a new release"
- Select the tag
- Add release notes

3. **Announce**:
- Update documentation
- Notify users
- Update any dependent projects

## Security Notes

- **Never commit** API tokens to version control
- Use environment variables or `.pypirc` (add to `.gitignore`)
- Rotate tokens periodically
- Use separate tokens for test and production

## Resources

- [PyPI Publishing Guide](https://packaging.python.org/tutorials/packaging-projects/)
- [Twine Documentation](https://twine.readthedocs.io/)
- [Python Packaging User Guide](https://packaging.python.org/)

