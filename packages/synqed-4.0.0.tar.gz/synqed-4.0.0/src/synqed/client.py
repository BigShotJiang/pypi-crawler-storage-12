"""
Client wrapper for simplified agent interaction.
"""

import logging
import uuid
from typing import Any, AsyncIterator

import httpx
from a2a.client import Client, ClientConfig, ClientFactory
from a2a.types import AgentCard, Message, Part, Role, Task, TextPart

logger = logging.getLogger(__name__)


class SynqedClient:
    """
    Simplified client for interacting with A2A agents.
    
    This class provides an easy-to-use interface for sending messages to agents
    and receiving responses, without needing to understand A2A protocol details.
    
    Example:
        ```python
        client = SynqedClient("http://localhost:8000/a2a/v1")
        
        # Send a simple text message
        async for response in client.send("Hello, agent!"):
            print(response)
        
        # Or get the final result
        result = await client.send_and_wait("Tell me a joke")
        print(result)
        ```
    """
    
    def __init__(
        self,
        agent_url: str | None = None,
        agent_card: AgentCard | None = None,
        streaming: bool = True,
        timeout: float = 30.0,
    ):
        """
        Initialize the client.
        
        Args:
            agent_url: URL of the agent (or URL to fetch the agent card from)
            agent_card: Pre-loaded agent card (optional)
            streaming: Whether to use streaming responses (default: True)
            timeout: Request timeout in seconds (default: 30.0)
        """
        if agent_url is None and agent_card is None:
            raise ValueError("Either agent_url or agent_card must be provided")
        
        self.agent_url = agent_url
        self._agent_card = agent_card
        self.streaming = streaming
        self.timeout = timeout
        
        # HTTP client for requests
        self._http_client = httpx.AsyncClient(timeout=timeout)
        
        # A2A client (created lazily)
        self._a2a_client: Client | None = None
        self._client_config = ClientConfig(
            streaming=streaming,
            httpx_client=self._http_client,
        )
    
    async def _get_client(self) -> Client:
        """Get or create the A2A client."""
        if self._a2a_client is None:
            # Get the agent card if not already loaded
            if self._agent_card is None:
                self._agent_card = await self._fetch_card()
            
            # Create the A2A client factory and then the client
            factory = ClientFactory(config=self._client_config)
            self._a2a_client = factory.create(card=self._agent_card)
        
        return self._a2a_client
    
    async def _fetch_card(self) -> AgentCard:
        """Fetch the agent card from the server."""
        if self.agent_url is None:
            raise ValueError("Cannot fetch card without agent_url")
        
        logger.info(f"Fetching agent card from {self.agent_url}")
        
        # Agents should serve their card at /.well-known/agent.json
        card_url = self.agent_url.rstrip("/")
        if not card_url.endswith("/.well-known/agent.json"):
            # Try common card locations
            base_url = card_url
            card_url = f"{base_url}/.well-known/agent.json"
        
        try:
            response = await self._http_client.get(card_url)
            response.raise_for_status()
            card_data = response.json()
            return AgentCard(**card_data)
        except Exception as e:
            logger.error(f"Failed to fetch agent card: {e}")
            raise ValueError(f"Could not fetch agent card from {card_url}: {e}") from e
    
    async def send(
        self,
        message: str | Message,
        task_id: str | None = None,
    ) -> AsyncIterator[str]:
        """
        Send a message to the agent and stream responses.
        
        Args:
            message: Text message or Message object to send
            task_id: Optional task ID to continue an existing conversation
            
        Yields:
            Response text chunks from the agent
        """
        client = await self._get_client()
        
        # Create message object if needed
        if isinstance(message, str):
            msg = Message(
                role=Role.user,
                parts=[Part(root=TextPart(text=message))],
                message_id=str(uuid.uuid4()),
                task_id=task_id,
            )
        else:
            msg = message
        
        # Send the message
        async for event in client.send_message(msg):
            # Handle different event types
            if isinstance(event, tuple):
                # (Task, Update) pair - ClientEvent
                task, update = event
                # Extract text from the latest message in task history
                if task and task.history:
                    # Get the latest message from the agent
                    for msg in reversed(task.history):
                        if msg.role == Role.agent:
                            text = self._extract_text(msg)
                            if text:
                                yield text
                            break
            elif isinstance(event, Message):
                # Direct message response
                text = self._extract_text(event)
                if text:
                    yield text
    
    async def send_and_wait(
        self,
        message: str | Message,
        task_id: str | None = None,
    ) -> str:
        """
        Send a message and wait for the complete response.
        
        Args:
            message: Text message or Message object to send
            task_id: Optional task ID to continue an existing conversation
            
        Returns:
            Complete response text from the agent
        """
        response_parts = []
        async for chunk in self.send(message, task_id):
            response_parts.append(chunk)
        
        return "".join(response_parts)
    
    async def get_task(self, task_id: str) -> Task:
        """
        Get the current state of a task.
        
        Args:
            task_id: ID of the task to retrieve
            
        Returns:
            Task object with current state and history
        """
        client = await self._get_client()
        from a2a.types import TaskQueryParams
        
        return await client.get_task(TaskQueryParams(id=task_id))
    
    async def cancel_task(self, task_id: str) -> Task:
        """
        Cancel a running task.
        
        Args:
            task_id: ID of the task to cancel
            
        Returns:
            Task object with final state
        """
        client = await self._get_client()
        from a2a.types import TaskIdParams
        
        return await client.cancel_task(TaskIdParams(id=task_id))
    
    def _extract_text(self, message: Message) -> str:
        """Extract text content from a message."""
        text_parts = []
        for part in message.parts:
            # Part has a root attribute that can be TextPart
            if hasattr(part, "root") and isinstance(part.root, TextPart):
                text_parts.append(part.root.text)
        return "".join(text_parts)
    
    async def close(self) -> None:
        """Close the client and cleanup resources."""
        await self._http_client.aclose()
        logger.info("Client closed")
    
    async def __aenter__(self) -> "SynqedClient":
        """Async context manager entry."""
        return self
    
    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
        await self.close()
    
    def __repr__(self) -> str:
        """String representation of the client."""
        return f"SynqedClient(agent_url='{self.agent_url}', streaming={self.streaming})"

