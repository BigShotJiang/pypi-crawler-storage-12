# Text logger module
