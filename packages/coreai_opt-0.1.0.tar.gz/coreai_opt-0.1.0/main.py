def main():
    print("Hello from coreai-opt!")


if __name__ == "__main__":
    main()
