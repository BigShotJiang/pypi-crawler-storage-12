from .test_results_parser import *

__doc__ = test_results_parser.__doc__
if hasattr(test_results_parser, "__all__"):
    __all__ = test_results_parser.__all__