# Changelog

## [1.0.1] - 2025-11-02
- Initial public release
- Added ranking guard and demo projects
- Published to PyPI and automated CI/CD

## [1.0.0] - 2025-10-23
- Internal sandbox and testing framework foundation
