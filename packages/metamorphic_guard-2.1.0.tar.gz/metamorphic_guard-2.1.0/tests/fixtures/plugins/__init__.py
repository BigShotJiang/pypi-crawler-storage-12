"""Test fixtures for plugin system."""

