"""Véhicule package exposing the vehicle entity used in the simulation."""

from .vehicule import Vehicule

__all__ = ["Vehicule"]
