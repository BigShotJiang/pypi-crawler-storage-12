"""Réseau routier package exposing the core network entity."""

from .reseau import ReseauRoutier

__all__ = ["ReseauRoutier"]
