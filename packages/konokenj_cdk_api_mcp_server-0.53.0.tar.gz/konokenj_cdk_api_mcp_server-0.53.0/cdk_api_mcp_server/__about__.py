# SPDX-FileCopyrightText: 2025-present Kenji Kono <konoken@amazon.co.jp>
#
# SPDX-License-Identifier: MIT
__version__ = "0.53.0"
