"""Enable execution via: python -m hatiyar"""

from hatiyar.main import main

if __name__ == "__main__":
    raise SystemExit(main())
