"""Smart contract constants."""

from somnia_streams.types.contracts import Chains, CHAIN_ID_NAME

__all__ = ["Chains", "CHAIN_ID_NAME"]
