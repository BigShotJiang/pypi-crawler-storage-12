"""SDK-wide constants."""

ZERO_BYTES32 = "0x" + "00" * 32
