class RowNotFoundError(Exception):
    pass
