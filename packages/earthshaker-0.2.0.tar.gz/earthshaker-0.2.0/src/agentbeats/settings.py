from pydantic_settings import BaseSettings, SettingsConfigDict


class ControllerSettings(BaseSettings):
    host: str = "0.0.0.0"
    port: int = 8010
    https_enabled: bool = False
    cloudrun_host: str | None = None  # for getting the correct url to internal agent
    agent_maintainer_sleep_n_seconds: float = 1.0


class GCPSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    gcp_project_id: str | None = None
    gcp_region: str | None = None
    gcp_repo_name: str = "agentbeats-agent-repo"
    gcp_endpoint_suffix: str | None = None


class BackendSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    client_secret: str | None = None
