import os
import typer
import uvicorn
import multiprocessing
from agentbeats.controller import main as controller_main
from agentbeats.runner import (
    cloudrun_runner_loop,
    agent_check_runner_loop,
    assessment_runner_loop,
)

typer_app = typer.Typer()


@typer_app.command()
def serve(reload: bool = False):
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    cloudrun_p = multiprocessing.Process(target=cloudrun_runner_loop)
    cloudrun_p.start()
    agentcheck_p = multiprocessing.Process(target=agent_check_runner_loop)
    agentcheck_p.start()
    assessment_p = multiprocessing.Process(target=assessment_runner_loop, args=(4,))
    assessment_p.start()
    uvicorn.run("agentbeats.backend:app", host=host, port=port, reload=reload)


typer_app.command("run_ctrl")(controller_main)


if __name__ == "__main__":
    typer_app()
