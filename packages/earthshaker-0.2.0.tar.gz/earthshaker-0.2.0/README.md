# Earthshaker: New Impl for Project AgentBeats

The repo contains
- Frontend
- Backend
- SDK
- Docs