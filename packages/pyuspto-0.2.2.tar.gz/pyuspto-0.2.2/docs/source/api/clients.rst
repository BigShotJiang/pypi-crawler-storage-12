Clients
=======

.. automodule:: pyUSPTO.clients.bulk_data
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pyUSPTO.clients.patent_data
   :members:
   :undoc-members:
   :show-inheritance:
