# This makes the class available as:
# from icss_feature_selection import ICSSFeatureSelector
from .selector import ICSSFeatureSelector

__version__ = "0.1.0"