##################
 Nuitka Changelog
##################

In this document, we track the per version changes and comments. This is
now maintained separately at https://nuitka.net/changelog/Changelog.html
please check it out from there.
