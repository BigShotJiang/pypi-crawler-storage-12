# Codex Curator Examples

- canon_to_codex.json
- spoiler_strip.json
