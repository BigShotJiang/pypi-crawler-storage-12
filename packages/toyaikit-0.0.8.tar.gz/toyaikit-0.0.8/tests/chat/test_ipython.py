# Tests for toyaikit.chat.ipython.py
