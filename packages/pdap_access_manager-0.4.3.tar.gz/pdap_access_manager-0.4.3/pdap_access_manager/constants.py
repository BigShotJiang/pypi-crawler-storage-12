DEFAULT_DATA_SOURCES_URL = "https://data-sources.pdap.io/api"
DEFAULT_SOURCE_COLLECTOR_URL = "https://source-collector.pdap.io"
