from .base import ZaloSendMessage
