import unittest


class ZaloSendMessage(unittest.TestCase):
    def setUp(self):
        self.app_id = ""
        self.secret_key = ""
        self.user_id = ""
        self.access_token = ""
        self.refresh_token = ""
        self.quote_message_id = ""
