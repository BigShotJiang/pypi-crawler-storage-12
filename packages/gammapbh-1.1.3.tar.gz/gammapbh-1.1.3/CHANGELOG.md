﻿# Changelog

## v1.1.2
- Capped histogram bins at max 20 (all histogram paths).
- Restored original UI flow; banner now uses colorama.
- Fixed 'Custom Equation' path and 'View previous spectra' labeling/overlays.
- All references updated to 1.1.2.
