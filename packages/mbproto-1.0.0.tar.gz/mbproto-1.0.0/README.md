# mbproto

Protobuf definitions of Wireless-Modbus-Bridge