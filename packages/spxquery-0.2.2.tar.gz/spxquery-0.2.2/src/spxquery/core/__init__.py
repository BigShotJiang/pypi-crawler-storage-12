"""Core functionality for SPXQuery package."""
