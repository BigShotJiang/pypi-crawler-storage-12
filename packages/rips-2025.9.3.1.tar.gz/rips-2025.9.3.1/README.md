# ResInsight Processing Server - rips

A Python interface for the ResInsight visualization and post-processing suite for Reservoir Simulations

[Learn More](https://www.resinsight.org)
