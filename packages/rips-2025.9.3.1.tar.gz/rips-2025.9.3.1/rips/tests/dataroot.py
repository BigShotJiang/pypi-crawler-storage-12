# The path here is intended to be used when pytest is launced from the source tree of the ResInsight repository
# This enables use of test datasets from the TestModels folder
PATH = "../../../TestModels"
