"""Hatchling metadata hook to automatically generate 'all' extras."""

from __future__ import annotations

from hatchling_autoextras_hook.hooks import AutoExtrasMetadataHook

__all__ = ["AutoExtrasMetadataHook"]
