"""Tests for hatchling-autoextras-hook."""
