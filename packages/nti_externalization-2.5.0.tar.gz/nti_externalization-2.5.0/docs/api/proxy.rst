================================================================
 ``nti.externalization.proxy``: Support for transparent proxies
================================================================

.. automodule:: nti.externalization.proxy
