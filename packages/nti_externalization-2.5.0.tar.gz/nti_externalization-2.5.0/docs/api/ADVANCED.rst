========================
 Advanced Customization
========================

.. toctree::
   :maxdepth: 2

   extension_points
   proxy
