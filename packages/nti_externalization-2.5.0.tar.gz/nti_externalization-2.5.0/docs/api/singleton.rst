===========
 Singleton
===========

.. automodule:: nti.externalization.singleton
