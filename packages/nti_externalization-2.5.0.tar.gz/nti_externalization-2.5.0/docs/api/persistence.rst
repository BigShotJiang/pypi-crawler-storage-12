================================================================
 ``nti.externalization.persistence``: Pickling and ZODB support
================================================================

.. automodule:: nti.externalization.persistence
