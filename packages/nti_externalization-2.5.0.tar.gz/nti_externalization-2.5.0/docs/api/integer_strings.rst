=====================================================================================
 ``nti.externalization.integer_strings``: Short readable strings from large integers
=====================================================================================

.. automodule:: nti.externalization.integer_strings
