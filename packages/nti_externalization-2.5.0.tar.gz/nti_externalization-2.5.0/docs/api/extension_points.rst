==================================================================
 ``nti.externalization.extension_points``: Pluggable integrations
==================================================================

.. automodule:: nti.externalization.extension_points

..
  Things decorated with @hookable have to be manually listed,
  even when they are in __all__

.. autofunction:: nti.externalization.extension_points.get_current_request
.. autofunction:: nti.externalization.extension_points.set_external_identifiers
