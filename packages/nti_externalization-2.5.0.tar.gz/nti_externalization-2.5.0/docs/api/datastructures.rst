================
 Datastructures
================

.. automodule:: nti.externalization.datastructures
   :private-members:
