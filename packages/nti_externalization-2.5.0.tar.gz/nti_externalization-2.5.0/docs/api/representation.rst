================================================================================
 ``nti.externalization.representation``: Reading and writing objects to strings
================================================================================

.. automodule:: nti.externalization.representation
