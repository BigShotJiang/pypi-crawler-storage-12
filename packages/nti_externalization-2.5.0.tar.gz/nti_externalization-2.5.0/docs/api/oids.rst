=========================================================
 ``nti.externalization.oids``: Stable object identifiers
=========================================================

.. automodule:: nti.externalization.oids
