"""i2 usage examples"""
