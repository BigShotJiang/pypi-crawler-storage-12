from typing import List

def mzy() -> str:
    """Return a confession string."""
    return "I LOVE WeiJinHe"


def print_my_name() -> str:
    """Return personal intro."""
    return "My name is Mzy, I am a student in BPU."