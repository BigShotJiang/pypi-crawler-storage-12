"""
PyMPDATA 2D advection-diffusion example with gif creation.

advection-diffusion-2d.ipynb:
.. include:: ./advection-diffusion-2d.ipynb.badges.md
"""
