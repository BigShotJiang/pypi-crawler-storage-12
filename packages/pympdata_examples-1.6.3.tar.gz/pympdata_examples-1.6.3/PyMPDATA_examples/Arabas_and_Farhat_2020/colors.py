colors = ("purple", "teal", "turquoise")
