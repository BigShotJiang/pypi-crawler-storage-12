"""
This is an example based on the solid-body rotation test made for PyMPDATA Wikipedia page.

demo.ipynb:
.. include:: ./demo.ipynb.badges.md
"""
