__all__ = ["ComicInfo", "MetronInfo"]

from perdoo.metadata.comic_info import ComicInfo
from perdoo.metadata.metron_info import MetronInfo
