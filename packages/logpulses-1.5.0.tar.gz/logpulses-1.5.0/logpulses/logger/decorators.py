def log_request(func):
    """Deprecated: Middleware handles logging automatically."""
    return func
