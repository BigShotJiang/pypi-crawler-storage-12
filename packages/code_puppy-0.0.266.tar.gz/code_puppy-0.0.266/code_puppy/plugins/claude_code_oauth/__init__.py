"""
Claude Code OAuth Plugin for Code Puppy

This plugin provides OAuth authentication for Claude Code and automatically
adds available models to the extra_models.json configuration.
"""
