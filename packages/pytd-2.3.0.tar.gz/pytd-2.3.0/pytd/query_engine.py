import abc
import importlib.metadata
import logging
import os
from typing import Any, TypeAlias, TypedDict
from urllib.parse import urlparse

import tdclient
import trino
from tdclient.connection import Connection as TDClientConnection
from tdclient.cursor import Cursor as TDClientCursor

__version__ = importlib.metadata.version("pytd")

logger = logging.getLogger(__name__)


class QueryResult(TypedDict):
    """Query execution result."""

    data: list[list[Any]]
    columns: list[str] | None


class CustomTrinoCursor(trino.dbapi.Cursor):
    """Custom Trino cursor that supports user-agent override."""

    def __init__(
        self,
        connection: trino.dbapi.Connection,
        request: trino.client.TrinoRequest,
        user_agent: str,
        legacy_primitive_types: bool = False,
    ) -> None:
        super().__init__(connection, request, legacy_primitive_types)  # type: ignore[misc]
        self._custom_user_agent = user_agent

    def execute(
        self, operation: str, params: list[Any] | tuple[Any, ...] | None = None
    ) -> "CustomTrinoCursor":
        # Prepare additional headers with custom user-agent
        additional_headers = {"User-Agent": self._custom_user_agent}

        if params:
            assert isinstance(params, list | tuple), (
                "params must be a list or tuple containing the query parameter values"
            )

            if self.connection._use_legacy_prepared_statements():  # type: ignore[attr-defined]
                statement_name = self._generate_unique_statement_name()
                self._prepare_statement(operation, statement_name)

                try:
                    # Send execute statement and assign the return value to `results`
                    # as it will be returned by the function
                    self._query = self._execute_prepared_statement(  # type: ignore[misc]
                        statement_name, params
                    )
                    self._iterator = iter(  # type: ignore[misc]
                        self._query.execute(additional_http_headers=additional_headers)  # type: ignore[misc]
                    )
                finally:
                    # Send deallocate statement
                    # At this point the query can be deallocated since it has already
                    # been executed
                    # TODO: Consider caching prepared statements if requested by caller
                    self._deallocate_prepared_statement(statement_name)
            else:
                self._query = self._execute_immediate_statement(operation, params)  # type: ignore[misc]
                self._iterator = iter(  # type: ignore[misc]
                    self._query.execute(additional_http_headers=additional_headers)  # type: ignore[misc]
                )

        else:
            self._query = trino.client.TrinoQuery(
                self._request,  # type: ignore[misc]
                query=operation,
                legacy_primitive_types=self._legacy_primitive_types,
            )
            self._iterator = iter(  # type: ignore[misc]
                self._query.execute(additional_http_headers=additional_headers)  # type: ignore[misc]
            )
        return self


# Type alias for cursor types returned by query engines
Cursor: TypeAlias = CustomTrinoCursor | TDClientCursor


class QueryEngine(metaclass=abc.ABCMeta):
    """An interface to Treasure Data query engine.

    Parameters
    ----------
    apikey : str
        Treasure Data API key.

    endpoint : str
        Treasure Data API server.

    database : str
        Name of connected database.

    header : str or bool
        Prepend comment strings, in the form "-- comment", as a header of queries.
    """

    def __init__(
        self, apikey: str, endpoint: str, database: str, header: str | bool
    ) -> None:
        if len(urlparse(endpoint).scheme) == 0:
            endpoint = f"https://{endpoint}"
        self.apikey: str = apikey
        self.endpoint: str = endpoint
        self.database: str = database
        self.header: str | bool = header
        self.executed: str | trino.client.TrinoResult | None = None

    @property
    def user_agent(self) -> str:
        """User agent passed to a query engine connection."""
        return f"pytd/{__version__}"

    def execute(self, query: str, **kwargs: Any) -> QueryResult:
        """Execute a given SQL statement and return results.

        Executed result returned by Cursor object is stored in
        ``self.executed``.

        Parameters
        ----------
        query : str
            Query.

        **kwargs
            Treasure Data-specific optional query parameters. Giving these
            keyword arguments forces query engine to issue a query via Treasure
            Data REST API provided by ``tdclient``, rather than using a direct
            connection established by the ``trino`` package.

            - ``db`` (str): use the database
            - ``result_url`` (str): result output URL
            - ``priority`` (int or str): priority

                - -2: "VERY LOW"
                - -1: "LOW"
                -  0: "NORMAL"
                -  1: "HIGH"
                -  2: "VERY HIGH"
            - ``retry_limit`` (int): max number of automatic retries
            - ``wait_interval`` (int): sleep interval until job finish
            - ``wait_callback`` (function): called every interval against job itself
            - ``engine_version`` (str): run query with Hive 2 if this parameter
              is set to ``"stable"`` in ``HiveQueryEngine``.
              https://docs.treasuredata.com/display/public/PD/Writing+Hive+Queries

            Meanwhile, when a following argument is set to ``True``, query is
            deterministically issued via ``tdclient``.

            - ``force_tdclient`` (bool): force Presto engines to issue a query
              via ``tdclient`` rather than its default ``trino`` interface.

        Returns
        -------
        dict : keys ('data', 'columns')
            'data'
                List of rows. Every single row is represented as a list of
                column values.
            'columns'
                List of column names.
        """
        cur = self.cursor(**kwargs)
        self.executed = cur.execute(query)  # type: ignore[assignment]
        rows = cur.fetchall()
        # cur.description is None for CREATE and DROP statements in recent version of
        # Trino
        columns = [desc[0] for desc in cur.description] if cur.description else None
        return {"data": rows, "columns": columns}

    def create_header(
        self, extra_lines: str | list[str] | tuple[str, ...] | None = None
    ) -> str:
        """Build header comments.

        Parameters
        ----------
        extra_lines : string or array-like, default: []
            Comments appended to the default one, which corresponds to a user
            agent string. If ``self.header=None``, empty string is returned
            regardless of this argument.

        Returns
        -------
        str
        """
        if extra_lines is None:
            extra_lines = []

        if self.header is False:
            return ""

        if isinstance(self.header, str):
            header = f"-- {self.header}\n"
        else:
            header = f"-- client: {self.user_agent}\n"

        if isinstance(extra_lines, str):
            header += f"-- {extra_lines}\n"
        elif extra_lines:  # list or tuple
            header += "".join([f"-- {line}\n" for line in extra_lines])

        return header

    @abc.abstractmethod
    def cursor(self, force_tdclient: bool = False, **kwargs: Any) -> Cursor:
        pass

    @abc.abstractmethod
    def close(self) -> None:
        pass

    @abc.abstractmethod
    def _connect(self) -> Any:
        pass

    def _get_tdclient_cursor(
        self, con: TDClientConnection, **kwargs: Any
    ) -> TDClientCursor:
        """Get DB-API cursor from tdclient Connection instance.

        ``kwargs`` are for setting specific parameters to Treasure Data REST
        API requests. For that purpose, this method runs workaround to
        dynamically configure custom parameters for ``tdclient.cursor.Cursor``
        such as "priority"; because the only way to set the custom parameters
        is using an instance attribute
        ``tdclient.connection.Connection._cursor_kwargs``, this method
        temporarily overwrites the attribute before calling
        ``Connection#cursor``.

        See implementation of the Connection interface:
        https://github.com/treasure-data/td-client-python/blob/78e1e187c3e15d009fa2ce697dc938fc0ab02ada/tdclient/connection.py

        Parameters
        ----------
        con : :class:`tdclient.connection.Connection`
            Handler created by ``tdclient#connect``.

        **kwargs
            Treasure Data-specific optional query parameters. Giving these
            keyword arguments forces query engine to issue a query via Treasure
            Data REST API provided by ``tdclient``, rather than using a direct
            connection established by the ``trino`` package.

            - ``db`` (str): use the database
            - ``result_url`` (str): result output URL
            - ``priority`` (int or str): priority

                - -2: "VERY LOW"
                - -1: "LOW"
                -  0: "NORMAL"
                -  1: "HIGH"
                -  2: "VERY HIGH"
            - ``retry_limit`` (int): max number of automatic retries
            - ``wait_interval`` (int): sleep interval until job finish
            - ``wait_callback`` (function): called every interval against job itself
            - ``engine_version`` (str): run query with Hive 2 if this parameter
              is set to ``"stable"`` in ``HiveQueryEngine``.
              https://docs.treasuredata.com/display/public/PD/Writing+Hive+Queries

        Returns
        -------
        :class:`tdclient.cursor.Cursor`
        """
        api_param_names = set(
            [
                "db",
                "result_url",
                "priority",
                "retry_limit",
                "wait_interval",
                "wait_callback",
                "engine_version",
            ]
        )

        if "type" in kwargs:
            raise RuntimeError(
                "optional query parameter 'type' is unsupported. Issue query "
                "from a proper QueryEngine instance: "
                "{PrestoQueryEngine, HiveQueryEngine}."
            )

        # update a clone of the original params
        cursor_kwargs = con._cursor_kwargs.copy()  # type: ignore[attr-defined]
        for k, v in kwargs.items():
            if k not in api_param_names:
                raise RuntimeError(
                    "unknown parameter for Treasure Data query execution API; "
                    f"'{k}' is not in [{', '.join(api_param_names)}]."
                )
            cursor_kwargs[k] = v

        # keep the original `_cursor_kwargs`
        original_cursor_kwargs = con._cursor_kwargs.copy()  # type: ignore[attr-defined]

        # overwrite the original params
        con._cursor_kwargs = cursor_kwargs  # type: ignore[attr-defined]

        # `Connection#cursor` internally refers the customized
        # ``_cursor_kwargs``
        cursor = con.cursor()

        # write the original params back to `_cursor_kwargs`
        con._cursor_kwargs = original_cursor_kwargs  # type: ignore[attr-defined]

        logger.warning(
            "returning `tdclient.cursor.Cursor`. This cursor, `Cursor#fetchone` "
            "in particular, might behave different from your expectation, "
            "because it actually executes a job on Treasure Data and fetches all "
            "records at once from the job result."
        )
        return cursor


class PrestoQueryEngine(QueryEngine):
    """An interface to Treasure Data Presto query engine.

    Parameters
    ----------
    apikey : str
        Treasure Data API key.

    endpoint : str
        Treasure Data API server.

    database : str
        Name of connected database.

    header : str or bool
        Prepend comment strings, in the form "-- comment", as a header of queries.
    """

    def __init__(
        self, apikey: str, endpoint: str, database: str, header: str | bool
    ) -> None:
        super().__init__(apikey, endpoint, database, header)
        self.trino_connection, self.tdclient_connection = self._connect()

    @property
    def user_agent(self) -> str:
        """User agent passed to a Presto connection."""
        return (
            f"pytd/{__version__} "
            f"(trino/{trino.__version__}; "
            f"tdclient/{tdclient.__version__})"
        )

    @property
    def presto_api_host(self) -> str:
        """Presto API host obtained from ``TD_PRESTO_API`` env variable or
        inferred from Treasure Data REST API endpoint.
        """
        return os.getenv(
            "TD_PRESTO_API", urlparse(self.endpoint).netloc.replace("api", "api-presto")
        )

    def cursor(self, force_tdclient: bool = False, **kwargs: Any) -> Cursor:
        """Get cursor defined by DB-API.

        Parameters
        ----------
        force_tdclient : bool
            Specify whether the method always returns
            :class:`tdclient.cursor.Cursor`.  If ``False``, returned cursor
            type is dynamically selected depending on ``**kwargs``.

        **kwargs
            Treasure Data-specific optional query parameters. Giving these
            keyword arguments forces query engine to issue a query via Treasure
            Data REST API provided by ``tdclient``, rather than using a direct
            connection established by the ``trino`` package.

            - ``db`` (str): use the database
            - ``result_url`` (str): result output URL
            - ``priority`` (int or str): priority

                - -2: "VERY LOW"
                - -1: "LOW"
                -  0: "NORMAL"
                -  1: "HIGH"
                -  2: "VERY HIGH"
            - ``retry_limit`` (int): max number of automatic retries
            - ``wait_interval`` (int): sleep interval until job finish
            - ``wait_callback`` (function): called every interval against job itself

        Returns
        -------
        :class:`trino.dbapi.Cursor`, or :class:`tdclient.cursor.Cursor`
        """
        if not force_tdclient and len(kwargs) == 0:
            # Create a regular cursor first to get the request object
            regular_cursor = self.trino_connection.cursor()

            # In production, return our custom cursor with the same request object
            return CustomTrinoCursor(
                self.trino_connection,
                regular_cursor._request,  # type: ignore[attr-defined]
                self.user_agent,  # type: ignore[attr-defined]
            )

        return self._get_tdclient_cursor(self.tdclient_connection, **kwargs)

    def close(self) -> None:
        """Close a connection to Presto."""
        self.trino_connection.close()
        self.tdclient_connection.close()

    def _connect(
        self,
    ) -> tuple[trino.dbapi.Connection, TDClientConnection]:
        # Create trino connection
        trino_connection = trino.dbapi.connect(  # type: ignore[misc]
            host=self.presto_api_host,
            port=443,
            http_scheme="https",
            user=self.apikey,
            catalog="td-presto",
            schema=self.database,
        )

        return (
            trino_connection,
            tdclient.connect(
                apikey=self.apikey,
                endpoint=self.endpoint,
                db=self.database,
                user_agent=self.user_agent,
                type="presto",
            ),
        )


class HiveQueryEngine(QueryEngine):
    """An interface to Treasure Data Hive query engine.

    Parameters
    ----------
    apikey : str
        Treasure Data API key.

    endpoint : str
        Treasure Data API server.

    database : str
        Name of connected database.

    header : str or bool
        Prepend comment strings, in the form "-- comment", as a header of queries.
    """

    def __init__(
        self, apikey: str, endpoint: str, database: str, header: str | bool
    ) -> None:
        super().__init__(apikey, endpoint, database, header)
        self.engine = self._connect()

    @property
    def user_agent(self) -> str:
        """User agent passed to a Hive connection."""
        return f"pytd/{__version__} (tdclient/{tdclient.__version__})"

    def cursor(self, force_tdclient: bool = True, **kwargs: Any) -> TDClientCursor:
        """Get cursor defined by DB-API.

        Parameters
        ----------
        force_tdclient : bool
            Specify whether the method always returns
            :class:`tdclient.cursor.Cursor`.  Currently, the parameter changes
            nothing in ``HiveQueryEngine`` since
            :class:`tdclient.cursor.Curosr` is the only option as a type of
            returned value.

        **kwargs
            Treasure Data-specific optional query parameters. Giving these
            keyword arguments forces query engine to issue a query via Treasure
            Data REST API provided by ``tdclient``.

            - ``db`` (str): use the database
            - ``result_url`` (str): result output URL
            - ``priority`` (int or str): priority

                - -2: "VERY LOW"
                - -1: "LOW"
                -  0: "NORMAL"
                -  1: "HIGH"
                -  2: "VERY HIGH"
            - ``retry_limit`` (int): max number of automatic retries
            - ``wait_interval`` (int): sleep interval until job finish
            - ``wait_callback`` (function): called every interval against job itself
            - ``engine_version`` (str): run query with Hive 2 if this parameter
              is set to ``"stable"``.
              https://docs.treasuredata.com/display/public/PD/Writing+Hive+Queries

        Returns
        -------
        :class:`tdclient.cursor.Cursor`
        """
        return self._get_tdclient_cursor(self.engine, **kwargs)

    def close(self) -> None:
        """Close a connection to Hive."""
        self.engine.close()

    def _connect(self) -> TDClientConnection:
        return tdclient.connect(
            apikey=self.apikey,
            endpoint=self.endpoint,
            db=self.database,
            user_agent=self.user_agent,
            type="hive",
        )
