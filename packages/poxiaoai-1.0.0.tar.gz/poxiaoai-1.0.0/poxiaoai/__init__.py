"""
poxiaoai - 需要授权激活的Python工具包
"""

from .auth import activate, is_activated
from .cli import main

__version__ = "1.0.0"
__author__ = "poxiaoai"