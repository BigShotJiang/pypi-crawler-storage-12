# Washington

Washington state does not have a general income tax.
It does have a Working Families Tax Credit (implemented in PolicyEngine US) and a capital gains tax (currently facing a lawsuit, and not yet implemented in PolicyEngine US).
