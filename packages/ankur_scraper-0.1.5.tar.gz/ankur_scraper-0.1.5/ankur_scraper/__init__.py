# ankur_scraper/__init__.py
"""
Ankur Scraper - A robust website scraper with intelligent content extraction.

Supports both static and dynamic (JavaScript-rendered) websites with multiple
extraction strategies for maximum compatibility.
"""

try:
    from ._version import __version__
except ImportError:
    # Fallback version if _version.py doesn't exist
    __version__ = "0.1.5"

# Public API
from ankur_scraper.dispatcher import run_scraper
from ankur_scraper.core.url_utils import normalize_url

__all__ = [
    "__version__",
    "run_scraper",
    "normalize_url",
]