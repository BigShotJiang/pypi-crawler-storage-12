"""Matplotlib backends for terminal rendering."""
