"""Utility modules for vibecore."""

from vibecore.utils.text import TextExtractor

__all__ = ["TextExtractor"]
