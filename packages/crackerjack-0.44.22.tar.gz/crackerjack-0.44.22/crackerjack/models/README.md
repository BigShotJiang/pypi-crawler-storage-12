# Models

Data models and schemas. Favor explicit types and validation.
