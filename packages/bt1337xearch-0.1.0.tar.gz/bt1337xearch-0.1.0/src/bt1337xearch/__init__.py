from .parser import parser

def main() -> None:
    parser();
