"""
larder: Connect functions to stores - fetch inputs & persist outputs
"""

from larder.crude import store_on_output
from larder.dog import DOG
