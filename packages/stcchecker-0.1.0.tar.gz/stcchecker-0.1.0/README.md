# stcchecker

A simple Python wrapper for a remote STC check API.

## Installation