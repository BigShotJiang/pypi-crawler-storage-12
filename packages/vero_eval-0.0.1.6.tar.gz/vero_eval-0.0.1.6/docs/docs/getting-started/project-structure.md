---
id: project-structure
title: Project Structure
---
# **Project Structure**

```
.
├── src/
|   ├── vero/
|   │   ├── metrics/          # Main package for metrics
|   └── └──  all the metrics  # All the metrics are in here
└── tests/
    └── test_main.py/         # file for all the testing

```