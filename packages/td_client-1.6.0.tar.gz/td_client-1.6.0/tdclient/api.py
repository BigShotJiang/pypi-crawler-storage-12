#!/usr/bin/env python

import contextlib
import csv
import email.utils
import gzip
import http.client
import io
import json
import logging
import os
import ssl
import tempfile
import time
import urllib.parse as urlparse
from array import array
from collections.abc import Iterator
from typing import IO, Any, cast

import msgpack
import urllib3

from tdclient import errors, version
from tdclient.bulk_import_api import BulkImportAPI
from tdclient.connector_api import ConnectorAPI
from tdclient.database_api import DatabaseAPI
from tdclient.export_api import ExportAPI
from tdclient.import_api import ImportAPI
from tdclient.job_api import JobAPI
from tdclient.result_api import ResultAPI
from tdclient.schedule_api import ScheduleAPI
from tdclient.server_status_api import ServerStatusAPI
from tdclient.table_api import TableAPI
from tdclient.types import BytesOrStream, DataFormat, FileLike, StreamBody
from tdclient.user_api import UserAPI
from tdclient.util import (
    csv_dict_record_reader,
    csv_text_record_reader,
    normalized_msgpack,
    read_csv_records,
    validate_record,
)

try:
    import certifi  # type: ignore[reportMissingImports]
except ImportError:
    certifi = None

log = logging.getLogger(__name__)

APIError = errors.APIError
AuthError = errors.AuthError
ForbiddenError = errors.ForbiddenError
AlreadyExistsError = errors.AlreadyExistsError
NotFoundError = errors.NotFoundError


class API(
    BulkImportAPI,
    ConnectorAPI,
    DatabaseAPI,
    ExportAPI,
    ImportAPI,
    JobAPI,
    ResultAPI,
    ScheduleAPI,
    ServerStatusAPI,
    TableAPI,
    UserAPI,
):
    """Internal API class

    Args:
        apikey (str): the API key of Treasure Data Service. If `None` is given, `TD_API_KEY` will be used if available.
        user_agent (str): custom User-Agent.
        endpoint (str): custom endpoint URL. If `None` is given, `TD_API_SERVER` will be used if available.
        headers (dict): custom HTTP headers.
        retry_post_requests (bool): Specify whether allowing API client to retry POST requests. `False` by default.
        max_cumul_retry_delay (int): maximum retry limit in seconds. 600 seconds by default.
        http_proxy (str): HTTP proxy setting. if `None` is given, `HTTP_PROXY` will be used if available.
    """

    DEFAULT_ENDPOINT = "https://api.treasuredata.com/"
    DEFAULT_IMPORT_ENDPOINT = "https://api-import.treasuredata.com/"

    def __init__(
        self,
        apikey: str | None = None,
        user_agent: str | None = None,
        endpoint: str | None = None,
        headers: dict[str, str] | None = None,
        retry_post_requests: bool = False,
        max_cumul_retry_delay: int = 600,
        http_proxy: str | None = None,
        **kwargs: Any,
    ) -> None:
        headers = {} if headers is None else headers
        if apikey is not None:
            self._apikey = apikey
        elif "TD_API_KEY" in os.environ:
            self._apikey = os.getenv("TD_API_KEY")
        else:
            raise ValueError("no API key given")

        if user_agent is not None:
            self._user_agent = user_agent
        else:
            self._user_agent = f"TD-Client-Python/{version.__version__}"

        if endpoint is not None:
            if not urlparse.urlparse(endpoint).scheme:
                endpoint = f"https://{endpoint}"
            self._endpoint = endpoint
        elif os.getenv("TD_API_SERVER"):
            self._endpoint = os.getenv("TD_API_SERVER")
        else:
            self._endpoint = self.DEFAULT_ENDPOINT

        pool_options = dict(kwargs)
        if "ca_certs" not in pool_options and certifi:
            pool_options["ca_certs"] = certifi.where()

        if pool_options.get("ca_certs") is not None:
            pool_options["cert_reqs"] = ssl.CERT_REQUIRED

        if "timeout" not in pool_options:
            pool_options["timeout"] = 60

        self.http = self._init_http(
            http_proxy if http_proxy else os.getenv("HTTP_PROXY"), **pool_options
        )
        self._retry_post_requests = retry_post_requests
        self._max_cumul_retry_delay = max_cumul_retry_delay
        self._headers = {key.lower(): value for (key, value) in headers.items()}

    @property
    def apikey(self) -> str | None:
        return self._apikey

    @property
    def endpoint(self) -> str:
        assert self._endpoint is not None  # Always set in __init__
        return self._endpoint

    def _init_http(
        self, http_proxy: str | None = None, **kwargs: Any
    ) -> urllib3.PoolManager | urllib3.ProxyManager:
        if http_proxy is None:
            return urllib3.PoolManager(**kwargs)
        else:
            if http_proxy.startswith("http://"):
                return self._init_http_proxy(http_proxy, **kwargs)
            else:
                return self._init_http_proxy(f"http://{http_proxy}", **kwargs)

    def _init_http_proxy(self, http_proxy: str, **kwargs: Any) -> urllib3.ProxyManager:
        pool_options = dict(kwargs)
        p = urlparse.urlparse(http_proxy)
        scheme = p.scheme
        netloc = p.netloc
        if "@" in netloc:
            auth, netloc = netloc.split("@", 2)
            pool_options["proxy_headers"] = urllib3.make_headers(proxy_basic_auth=auth)
        return urllib3.ProxyManager(f"{scheme}://{netloc}", **pool_options)

    def get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> contextlib.AbstractContextManager[urllib3.BaseHTTPResponse]:
        headers = {} if headers is None else dict(headers)
        headers["accept-encoding"] = "deflate, gzip"
        url, headers = self.build_request(path=path, headers=headers, **kwargs)

        log.debug(
            "REST GET call:\n  headers: %s\n  path: %s\n  params: %s",
            repr(headers),
            repr(path),
            repr(params),
        )

        # up to 7 retries with exponential (base 2) back-off starting at 'retry_delay'
        retry_delay = 5
        cumul_retry_delay = 0

        # for both exceptions and 500+ errors retrying is enabled by default.
        # The total number of retries cumulatively should not exceed 10 minutes / 600 seconds
        response = None
        while True:
            try:
                response = self.send_request(
                    "GET",
                    url,
                    fields=params,
                    headers=headers,
                    decode_content=True,
                    preload_content=False,
                )
                # retry if the HTTP error code is 500 or higher and we did not run out of retrying attempts
                if response.status < 500:
                    break
                else:
                    log.warning(
                        "Error %d: %s. Retrying after %d seconds... (cumulative: %d/%d)",
                        response.status,
                        response.data,
                        retry_delay,
                        cumul_retry_delay,
                        self._max_cumul_retry_delay,
                    )
            except (
                OSError,
                urllib3.exceptions.TimeoutStateError,
                urllib3.exceptions.TimeoutError,
                urllib3.exceptions.PoolError,
                http.client.IncompleteRead,
                TimeoutError,
            ):
                pass

            if cumul_retry_delay <= self._max_cumul_retry_delay:
                log.warning(
                    "Retrying after %d seconds... (cumulative: %d/%d)",
                    retry_delay,
                    cumul_retry_delay,
                    self._max_cumul_retry_delay,
                )
                time.sleep(retry_delay)
                cumul_retry_delay += retry_delay
                retry_delay *= 2
            else:
                raise APIError(
                    f"Retrying stopped after {self._max_cumul_retry_delay} seconds. (cumulative: {cumul_retry_delay}/{self._max_cumul_retry_delay})"
                )

        log.debug(
            "REST GET response:\n  headers: %s\n  status: %d\n  body: <omitted>",
            repr(dict(response.getheaders())),
            response.status,
        )

        return contextlib.closing(response)

    def post(
        self,
        path: str,
        params: dict[str, Any] | bytes | None = None,
        headers: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> contextlib.AbstractContextManager[urllib3.BaseHTTPResponse]:
        headers = {} if headers is None else dict(headers)
        url, headers = self.build_request(path=path, headers=headers, **kwargs)

        log.debug(
            "REST POST call:\n  headers: %s\n  path: %s\n  params: %s",
            repr(headers),
            repr(path),
            repr(params),
        )

        # up to 7 retries with exponential (base 2) back-off starting at 'retry_delay'
        retry_delay = 5
        cumul_retry_delay = 0

        # for both exceptions and 500+ errors retrying can be enabled by initialization
        # parameter 'retry_post_requests'. The total number of retries cumulatively
        # should not exceed 10 minutes / 600 seconds

        # use `params` as request parameter if it is a `dict`.
        # otherwise, use it as byte string of request body.
        body = fields = None
        if isinstance(params, dict):
            fields = params
        else:
            body = params

        response = None
        while True:
            try:
                response = self.send_request(
                    "POST",
                    url,
                    fields=fields,
                    body=body,
                    headers=headers,
                    decode_content=True,
                    preload_content=False,
                )
                # if the HTTP error code is 500 or higher and the user requested retrying
                # on post request, attempt a retry
                if response.status < 500:
                    break
                else:
                    if not self._retry_post_requests:
                        raise APIError(
                            "Retrying stopped by retry_post_requests == False"
                        )
                    log.warning(
                        "Error %d: %s. Retrying after %d seconds... (cumulative: %d/%d)",
                        response.status,
                        response.data,
                        retry_delay,
                        cumul_retry_delay,
                        self._max_cumul_retry_delay,
                    )
            except (
                OSError,
                urllib3.exceptions.TimeoutStateError,
                urllib3.exceptions.TimeoutError,
                urllib3.exceptions.PoolError,
            ):
                if not self._retry_post_requests:
                    raise APIError(
                        "Retrying stopped by retry_post_requests == False"
                    ) from None

            if cumul_retry_delay <= self._max_cumul_retry_delay:
                log.warning(
                    "Retrying after %d seconds... (cumulative: %d/%d)",
                    retry_delay,
                    cumul_retry_delay,
                    self._max_cumul_retry_delay,
                )
                time.sleep(retry_delay)
                cumul_retry_delay += retry_delay
                retry_delay *= 2
            else:
                raise APIError(
                    f"Retrying stopped after {self._max_cumul_retry_delay} seconds. (cumulative: {cumul_retry_delay}/{self._max_cumul_retry_delay})"
                )

        log.debug(
            "REST POST response:\n  headers: %s\n  status: %d\n  body: <omitted>",
            repr(dict(response.getheaders())),
            response.status,
        )

        return contextlib.closing(response)

    def put(
        self,
        path: str,
        bytes_or_stream: BytesOrStream,
        size: int,
        headers: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> contextlib.AbstractContextManager[urllib3.BaseHTTPResponse]:
        headers = {} if headers is None else dict(headers)
        headers["content-length"] = str(size)
        if "content-type" not in headers:
            headers["content-type"] = "application/octet-stream"
        url, headers = self.build_request(path=path, headers=headers, **kwargs)

        log.debug(
            "REST PUT call:\n  headers: %s\n  path: %s\n  body: <omitted>",
            repr(headers),
            repr(path),
        )

        stream: array[int] | IO[bytes]
        if hasattr(bytes_or_stream, "read"):
            # file-like must support `read` and `fileno` to work with `httplib`
            # Type guard: if it has 'read', it's IO[bytes]
            file_like = cast(IO[bytes], bytes_or_stream)
            fileno_supported = hasattr(file_like, "fileno")
            if fileno_supported:
                try:
                    file_like.fileno()
                except io.UnsupportedOperation:
                    # `io.BytesIO` doesn't support `fileno`
                    fileno_supported = False
            if fileno_supported:
                stream = file_like
            else:
                stream = array("b", file_like.read())

        else:
            # send request body as an `array.array` since `httplib` requires the request body to be a unicode string
            # Type guard: if it doesn't have 'read', it's bytes | bytearray
            byte_data = cast("bytes | bytearray", bytes_or_stream)
            stream = array("b", byte_data)

        response = None
        try:
            response = self.send_request(
                "PUT",
                url,
                body=stream,
                headers=headers,
                decode_content=True,
                preload_content=False,
            )
            if response.status < 500:
                pass
            else:
                raise APIError("Error %d: %s", response.status, response.data)
        except (
            OSError,
            urllib3.exceptions.TimeoutStateError,
            urllib3.exceptions.TimeoutError,
            urllib3.exceptions.PoolError,
        ):
            raise APIError(f"Error: {repr(response)}") from None

        log.debug(
            "REST PUT response:\n  headers: %s\n  status: %d\n  body: <omitted>",
            repr(dict(response.getheaders())),
            response.status,
        )

        return contextlib.closing(response)

    def delete(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> contextlib.AbstractContextManager[urllib3.BaseHTTPResponse]:
        headers = {} if headers is None else dict(headers)
        url, headers = self.build_request(path=path, headers=headers, **kwargs)

        log.debug(
            "REST DELETE call:\n  headers: %s\n  path: %s\n  params: %s",
            repr(headers),
            repr(path),
            repr(params),
        )

        # up to 7 retries with exponential (base 2) back-off starting at 'retry_delay'
        retry_delay = 5
        cumul_retry_delay = 0

        # for both exceptions and 500+ errors retrying is enabled by default.
        # The total number of retries cumulatively should not exceed 10 minutes / 600 seconds
        response = None
        while True:
            try:
                response = self.send_request(
                    "DELETE",
                    url,
                    fields=params,
                    headers=headers,
                    decode_content=True,
                    preload_content=False,
                )
                # retry if the HTTP error code is 500 or higher and we did not run out of retrying attempts
                if response.status < 500:
                    break
                else:
                    log.warning(
                        "Error %d: %s. Retrying after %d seconds... (cumulative: %d/%d)",
                        response.status,
                        response.data,
                        retry_delay,
                        cumul_retry_delay,
                        self._max_cumul_retry_delay,
                    )
            except (
                OSError,
                urllib3.exceptions.TimeoutStateError,
                urllib3.exceptions.TimeoutError,
                urllib3.exceptions.PoolError,
            ):
                pass

            if cumul_retry_delay <= self._max_cumul_retry_delay:
                log.warning(
                    "Retrying after %d seconds... (cumulative: %d/%d)",
                    retry_delay,
                    cumul_retry_delay,
                    self._max_cumul_retry_delay,
                )
                time.sleep(retry_delay)
                cumul_retry_delay += retry_delay
                retry_delay *= 2
            else:
                raise APIError(
                    f"Retrying stopped after {self._max_cumul_retry_delay} seconds. (cumulative: {cumul_retry_delay}/{self._max_cumul_retry_delay})"
                )

        log.debug(
            "REST DELETE response:\n  headers: %s\n  status: %d\n  body: <omitted>",
            repr(dict(response.getheaders())),
            response.status,
        )

        return contextlib.closing(response)

    def build_request(
        self,
        path: str | None = None,
        headers: dict[str, str] | None = None,
        endpoint: str | None = None,
    ) -> tuple[str, dict[str, str]]:
        headers = {} if headers is None else headers
        if endpoint is None:
            endpoint = self._endpoint
        assert endpoint is not None  # endpoint is always set in __init__
        if path is None:
            url: str = endpoint
        else:
            p = urlparse.urlparse(endpoint)
            # should not use `os.path.join` since it returns path string like "/foo\\bar"
            # Type assertion: urlparse components are str not bytes for str input
            p_path = str(p.path)
            p_scheme = str(p.scheme)
            p_netloc = str(p.netloc)
            p_params = str(p.params)
            p_query = str(p.query)
            p_fragment = str(p.fragment)
            request_path = path if p_path == "/" else "/".join([p_path, path])
            url = urlparse.urlunparse(
                urlparse.ParseResult(
                    p_scheme, p_netloc, request_path, p_params, p_query, p_fragment
                )
            )
        # use default headers first
        _headers = dict(self._headers)
        # add default headers
        _headers["authorization"] = f"TD1 {self._apikey}"
        _headers["date"] = email.utils.formatdate(time.time())
        _headers["user-agent"] = self._user_agent
        # override given headers
        _headers.update({key.lower(): value for (key, value) in headers.items()})
        return (url, _headers)

    def send_request(
        self,
        method: str,
        url: str,
        fields: dict[str, Any] | None = None,
        body: StreamBody = None,
        headers: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> urllib3.BaseHTTPResponse:
        if body is None:
            return self.http.request(
                method, url, fields=fields, headers=headers, **kwargs
            )

        return self.http.urlopen(method, url, body=body, headers=headers, **kwargs)

    def raise_error(
        self, msg: str, res: urllib3.BaseHTTPResponse, body: bytes | str
    ) -> None:
        status_code = res.status
        s = body if isinstance(body, str) else body.decode("utf-8")
        if status_code == 404:
            raise errors.NotFoundError(f"{msg}: {s}")
        elif status_code == 409:
            raise errors.AlreadyExistsError(f"{msg}: {s}")
        elif status_code == 401:
            raise errors.AuthError(f"{msg}: {s}")
        elif status_code == 403:
            raise errors.ForbiddenError(f"{msg}: {s}")
        else:
            raise errors.APIError(f"{status_code}: {msg}: {s}")

    def checked_json(self, body: bytes, required: list[str]) -> dict[str, Any]:
        js = None
        try:
            js = json.loads(body.decode("utf-8"))
        except ValueError as error:
            raise APIError(f"Unexpected API response: {error}: {repr(body)}") from error
        js = dict(js)
        if 0 < [k in js for k in required].count(False):
            missing = [k for k in required if k not in js]
            raise APIError(f"Unexpected API response: {repr(missing)}: {repr(body)}")
        return js

    def close(self) -> None:
        # urllib3 doesn't allow to close all connections immediately.
        # all connections in pool will be closed eventually during gc.
        self.http.clear()

    def _prepare_file(
        self, file_like: FileLike, fmt: DataFormat, **kwargs: Any
    ) -> IO[bytes]:
        fp = tempfile.TemporaryFile()
        with contextlib.closing(gzip.GzipFile(mode="wb", fileobj=fp)) as gz:
            packer = msgpack.Packer()
            with contextlib.closing(self._read_file(file_like, fmt, **kwargs)) as items:
                for item in items:
                    try:
                        mp = packer.pack(item)
                    except (OverflowError, ValueError):
                        packer.reset()
                        mp = packer.pack(normalized_msgpack(item))
                    gz.write(mp)
        fp.seek(0)
        return fp

    def _read_file(self, file_like: FileLike, fmt: DataFormat, **kwargs: Any) -> Any:
        compressed = fmt.endswith(".gz")
        fmt_str = str(fmt)
        if compressed:
            fmt_str = fmt_str[0 : len(fmt_str) - len(".gz")]
        reader_name = f"_read_{fmt_str}_file"
        if hasattr(self, reader_name):
            reader = getattr(self, reader_name)
        else:
            raise TypeError(f"unknown format: {fmt}")
        if hasattr(file_like, "read"):
            if compressed:
                file_like = gzip.GzipFile(fileobj=file_like)  # type: ignore[arg-type]
            return reader(file_like, **kwargs)
        else:
            # At this point, file_like must be str or bytes (not IO[bytes])
            file_path = cast("str | bytes", file_like)
            if compressed:
                file_like = gzip.GzipFile(fileobj=open(file_path, "rb"))  # type: ignore[arg-type]
            else:
                file_like = open(file_path, "rb")
            return reader(file_like, **kwargs)

    def _read_msgpack_file(
        self, file_like: IO[bytes], **kwargs: Any
    ) -> Iterator[dict[str, Any]]:
        # current impl doesn't tolerate any unpack error
        unpacker = msgpack.Unpacker(file_like, raw=False)  # type: ignore[arg-type]
        for record in unpacker:
            validate_record(record)
            yield record

    def _read_json_file(
        self, file_like: IO[bytes], **kwargs: Any
    ) -> Iterator[dict[str, Any]]:
        # current impl doesn't tolerate any JSON parse error
        for s in file_like:
            record = json.loads(s.decode("utf-8"))
            validate_record(record)
            yield record

    def _read_csv_file(
        self,
        file_like: IO[bytes],
        dialect: type[csv.Dialect] = csv.excel,
        columns: list[str] | None = None,
        encoding: str = "utf-8",
        dtypes: dict[str, Any] | None = None,
        converters: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Iterator[dict[str, Any]]:
        if columns is None:
            reader = csv_dict_record_reader(file_like, encoding, dialect)  # type: ignore[arg-type]
        else:
            reader = csv_text_record_reader(file_like, encoding, dialect, columns)  # type: ignore[arg-type]

        return read_csv_records(reader, dtypes, converters, **kwargs)

    def _read_tsv_file(
        self, file_like: IO[bytes], **kwargs: Any
    ) -> Iterator[dict[str, Any]]:
        return self._read_csv_file(file_like, dialect=csv.excel_tab, **kwargs)
