"""Module for Insta quirks implementations."""

INSTA = "Insta GmbH"
