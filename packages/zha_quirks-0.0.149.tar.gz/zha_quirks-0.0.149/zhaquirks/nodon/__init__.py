"""NODON module for custom device handlers."""
