# ai-cache

**Lightweight automatic caching for LLM API responses**

Save time, tokens, and API costs by caching LLM responses locally. One line to enable, zero code changes needed.

## Features

- ✅ **One-line activation** - `ai_cache.enable()`
- ✅ **Multi-provider support** - OpenAI, Anthropic, Gemini
- ✅ **Local SQLite storage** - All data stays on your machine
- ✅ **Zero dependencies** - Only Python standard library
- ✅ **Cache expiration** - Optional TTL support
- ✅ **Cache statistics** - Monitor hits and savings

## Installation

```bash
pip install ai-cache
```

## Quick Start

```python
import ai_cache
ai_cache.enable()

# Use any LLM API as normal - responses are automatically cached
import openai
response = openai.ChatCompletion.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}]
)

# Second identical call returns instantly from cache
response = openai.ChatCompletion.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}]
)
```

## API

```python
# Enable caching
ai_cache.enable()                        # Default: ~/.ai-cache/
ai_cache.enable(cache_dir="./cache")     # Custom directory
ai_cache.enable(ttl=3600)                # With 1-hour expiration

# Manage cache
stats = ai_cache.get_stats()             # Get hit/miss statistics
ai_cache.clear()                         # Clear all cache
ai_cache.invalidate(provider="openai")   # Clear specific provider
ai_cache.invalidate(model="gpt-4")       # Clear specific model
ai_cache.disable()                       # Disable caching
```

## Supported Providers

- OpenAI (ChatGPT, GPT-4, etc.)
- Anthropic (Claude)
- Google Gemini

## How It Works

1. Call `ai_cache.enable()` to activate
2. Library intercepts LLM API calls
3. Requests are fingerprinted (SHA256 of model + prompt + params)
4. Cached responses returned instantly, new requests cached automatically
5. All data stored locally in SQLite

## License

MIT
