# Best practices 

* Don't omit where tenant= in queries for performance reasons.

* Create tenants in advance