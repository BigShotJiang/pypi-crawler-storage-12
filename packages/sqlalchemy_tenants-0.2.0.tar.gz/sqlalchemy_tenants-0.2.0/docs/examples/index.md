# Examples

* [FastAPI Integration](./fastapi-integration): 
  How to use sqlalchemy-tenants with FastAPI to automatically scope requests to the correct tenant.