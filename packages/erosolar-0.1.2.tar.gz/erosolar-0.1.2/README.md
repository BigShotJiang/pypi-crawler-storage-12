# Erosolar DeepSeek Agent System

[![PyPI version](https://badge.fury.io/py/erosolar.svg)](https://pypi.org/project/erosolar/)
[![Python Versions](https://img.shields.io/pypi/pyversions/erosolar.svg)](https://pypi.org/project/erosolar/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

An advanced AI-powered chat interface using DeepSeek with intelligent routing, tool execution, and embeddings-based agent selection.

## Features

- **Multiple Agent Architectures**: Choose from Legacy, Hybrid, and React agents
- **Intelligent Tool Routing**: Embeddings-based tool selection using OpenAI embeddings
- **Web Search Integration**: Built-in Tavily web search tools (optional)
- **Weather Tools**: Open-Meteo weather data integration
- **Persistent Chat History**: SQLite-based conversation storage
- **A/B Testing**: Built-in support for testing different routing strategies
- **Flask Web Interface**: Clean, modern chat UI with streaming responses

## Installation

```bash
pip install erosolar
```

### Optional Dependencies

For LangGraph support:
```bash
pip install erosolar[langgraph]
```

For development:
```bash
pip install erosolar[dev]
```

## Quick Start

### 1. Set up API Keys

```bash
export DEEPSEEK_API_KEY='your-deepseek-api-key'
export OPENAI_API_KEY='your-openai-api-key'  # Optional, for better embeddings
export TAVILY_API_KEY='your-tavily-api-key'  # Optional, for web search
```

### 2. Launch the Server

```bash
erosolar
```

The server will start on `http://localhost:5051` by default.

### 3. Access the Web Interface

Open your browser and navigate to:
```
http://localhost:5051
```

## Configuration

### Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DEEPSEEK_API_KEY` | Yes | - | Your DeepSeek API key |
| `OPENAI_API_KEY` | No | - | OpenAI key for embeddings (recommended) |
| `TAVILY_API_KEY` | No | - | Tavily key for web search tools |
| `PORT` | No | `5051` | Server port |
| `DEBUG` | No | `false` | Enable debug mode |
| `ENABLE_HYBRID_ROUTER` | No | `true` | Enable A/B testing |
| `HYBRID_ROUTER_PERCENT` | No | `0.1` | Percentage for hybrid routing |

### Data Directory

Chat history and application data are stored in platform-appropriate locations:

- **macOS/Linux**: `~/.local/share/erosolar/`
- **Windows**: `%APPDATA%\erosolar\`

## Agent Types

### Legacy Agent
Traditional sequential processing with basic tool routing.

### Hybrid Agent
Combines intent recognition with semantic tool matching for improved accuracy.

### React Agent (TrueReActAgent)
Advanced reasoning and acting agent with multi-step planning and execution.

## API Endpoints

### Chat Endpoints

- `GET /` - Web interface
- `POST /chat` - Streaming chat (SSE)
- `POST /chat_sync` - Synchronous chat

### Query Parameters

- `variant=legacy|hybrid|react` - Force specific agent variant
- `tools=tool1,tool2` - Specify tools to use
- `log_level=debug|info|warning|error` - Set client log level

### Example Request

```bash
curl -X POST http://localhost:5051/chat_sync \
  -H "Content-Type: application/json" \
  -d '{"prompt": "What is the weather in San Francisco?"}'
```

## Development & Contributing

We welcome contributions! Visit our GitHub repository to collaborate:

**https://github.com/ErosolarAI/deepseek**

### Setting up for Development

1. Clone the repository:
```bash
git clone https://github.com/ErosolarAI/deepseek.git
cd deepseek
```

2. Install in development mode:
```bash
pip install -e ".[dev]"
```

3. Run tests:
```bash
pytest
```

## Architecture

The system consists of several key components:

- **Tool Registry**: Manages available tools and workflows
- **Embeddings Router**: Uses vector similarity for intelligent tool selection
- **Vector Store**: Hierarchical vector storage for fast retrieval
- **Agent System**: Multiple agent implementations with different strategies
- **Chat Interface**: Flask-based web UI with SSE streaming

## Examples

### Using Web Search

```python
# Ask a question that triggers web search
"What are the latest developments in AI?"
```

### Weather Queries

```python
# Get current weather
"What's the weather like in New York?"
```

### Custom Tool Selection

```python
# Force specific tools via API
curl -X POST http://localhost:5051/chat_sync?tools=tavily_search \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Latest news about renewable energy"}'
```

## Database

The application uses SQLite for persistent chat history. The database is automatically created on first run and includes:

- Chat history with timestamps
- Prompt and response pairs
- Reasoning chains (for React agent)

## License

MIT License - see LICENSE file for details

## Support

- **Issues**: https://github.com/ErosolarAI/deepseek/issues
- **Discussions**: https://github.com/ErosolarAI/deepseek/discussions

## Acknowledgments

- Built with [DeepSeek](https://deepseek.com) API
- Embeddings via [OpenAI](https://openai.com)
- Web search powered by [Tavily](https://tavily.com)
- Weather data from [Open-Meteo](https://open-meteo.com)

---

**Join us in building the future of AI agents!**

Visit https://github.com/ErosolarAI/deepseek to contribute
