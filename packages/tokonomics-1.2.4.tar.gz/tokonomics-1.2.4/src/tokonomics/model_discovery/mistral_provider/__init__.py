"""Mistral model info Provider."""

from tokonomics.model_discovery.mistral_provider.provider import MistralProvider

__all__ = ["MistralProvider"]
