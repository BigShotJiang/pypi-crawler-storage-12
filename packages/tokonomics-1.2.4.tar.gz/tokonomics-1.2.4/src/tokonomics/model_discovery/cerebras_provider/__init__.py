"""Cerebras model info Provider."""

from tokonomics.model_discovery.cerebras_provider.provider import CerebrasProvider

__all__ = ["CerebrasProvider"]
