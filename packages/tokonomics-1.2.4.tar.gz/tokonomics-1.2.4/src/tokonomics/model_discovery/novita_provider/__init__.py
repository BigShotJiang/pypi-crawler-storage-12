"""Novita AI provider for model discovery."""

from tokonomics.model_discovery.novita_provider.provider import NovitaProvider

__all__ = ["NovitaProvider"]
