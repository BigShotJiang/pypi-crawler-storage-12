"""GitHub model info Provider."""

from tokonomics.model_discovery.github_provider.provider import GitHubProvider

__all__ = ["GitHubProvider"]
