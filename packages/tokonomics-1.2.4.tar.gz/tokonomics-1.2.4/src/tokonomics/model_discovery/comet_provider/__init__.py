"""Comet API model info Provider."""

from tokonomics.model_discovery.comet_provider.provider import CometProvider

__all__ = ["CometProvider"]
