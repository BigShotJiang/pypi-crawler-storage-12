from . import extend_partner_cnpj_search_wizard
