#. Para usar o SINTEGRAws
#. Acesse  Configurações
#. Clique na caixa de seleção "Activate state subscription search"
#. Insira o seu token da API no campo "SINTEGRA Token"
#. Preencha os campos obrigatórios, insira no campo de CNPJ o CNPJ que deseja buscar e clique na lupa ao lado do campo para buscar e o campo State Tax Number será preenchido com a inscrição estadual
