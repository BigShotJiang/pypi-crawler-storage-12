# pamdas

Tiny package that helps few B-batch students in there practical

## Usage

```python
import pamdas

pamdas.ls()
pamdas.read("pr1.txt")
pamdas.catall()