# Copyright (C) 2023 KMEE Informática LTDA
# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

DFE_VERSIONS = [("1.01", "1.01")]

DFE_VERSION_DEFAULT = "1.01"

DFE_ENVIRONMENTS = [("1", "Produção"), ("2", "Homologação")]

DFE_ENVIRONMENT_DEFAULT = "2"
