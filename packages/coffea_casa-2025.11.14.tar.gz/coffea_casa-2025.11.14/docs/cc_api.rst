.. _api:

.. py:currentmodule:: coffea_casa

``coffea_casa`` module API
===========================

.. autoclass:: CoffeaCasaCluster
   :members: security
