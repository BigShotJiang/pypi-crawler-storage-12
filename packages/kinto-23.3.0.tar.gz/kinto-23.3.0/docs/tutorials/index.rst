.. _tutorials:

Tutorials
#########

.. toctree::
   :maxdepth: 1

   install
   first-steps
   synchronisation
   notifications-custom
   custom-id-generator
   permissions
   write-plugin
   permission-setups
