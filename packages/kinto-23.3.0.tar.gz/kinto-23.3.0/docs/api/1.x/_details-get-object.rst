If the ``If-None-Match: "<timestamp>"`` request header is provided, and
if the object has not changed meanwhile, a |status-304| is returned.
