def load_from_config(config, prefix):
    return ()
