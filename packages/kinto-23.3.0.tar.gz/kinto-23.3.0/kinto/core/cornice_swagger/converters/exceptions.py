class ConversionError(Exception):
    pass


class NoSuchConverter(ConversionError):
    pass
