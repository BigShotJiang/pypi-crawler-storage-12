class ServerFlushed:
    def __init__(self, request):
        self.request = request
