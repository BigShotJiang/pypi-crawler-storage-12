# kinto-admin plugin setup

Update the `kinto-admin` version you want in the VERSION file of this plugin
