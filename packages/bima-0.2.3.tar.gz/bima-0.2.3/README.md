nbody simulation coy
