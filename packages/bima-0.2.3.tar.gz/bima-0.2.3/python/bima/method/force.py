from enum import IntEnum

class ForceMethod(IntEnum):
  Direct = 0
  Octree = 1