
from enum import IntEnum

class SolveMethod(IntEnum):
  Euler = 0
  RK4 = 1