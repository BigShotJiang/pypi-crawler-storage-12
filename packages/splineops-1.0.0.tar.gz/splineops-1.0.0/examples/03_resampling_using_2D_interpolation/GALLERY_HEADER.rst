.. splineops/examples/03_resampling_using_2d_interpolation/GALLERY_HEADER.rst

Resampling using 2D Samples
===========================

Examples using the Resize module on 2D samples.