.. splineops/examples/07_differentials/GALLERY_HEADER.rst

Differentials Examples
======================

Examples using the Differentials module.