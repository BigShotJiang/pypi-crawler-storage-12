.. splineops/docs/installation/index.rst

Installation
============

.. include:: ../../README.md
   :parser: myst