.. splineops/docs/api/04_adaptive_regression_splines.rst

.. _api-adaptive_regression_splines:

Adaptive Regression Splines
===========================

Functions to perform regression on 1D data.

.. automodule:: splineops.adaptive_regression_splines.sparsification
   :members:
   :undoc-members:
   :show-inheritance: