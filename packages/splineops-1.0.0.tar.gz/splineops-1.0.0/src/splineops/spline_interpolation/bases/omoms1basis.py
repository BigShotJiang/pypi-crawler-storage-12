# splineops/src/splineops/spline_interpolation/bases/omoms1basis.py

from .bspline1basis import BSpline1Basis

OMOMS1Basis = BSpline1Basis
