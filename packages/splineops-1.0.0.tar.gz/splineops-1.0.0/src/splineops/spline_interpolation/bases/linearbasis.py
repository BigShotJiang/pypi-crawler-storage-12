# splineops/src/splineops/spline_interpolation/bases/linearbasis.py

from .bspline1basis import BSpline1Basis

LinearBasis = BSpline1Basis
