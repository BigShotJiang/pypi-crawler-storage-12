# splineops/src/splineops/resize/__init__.py
from .resize import resize
__all__ = ["resize"]
