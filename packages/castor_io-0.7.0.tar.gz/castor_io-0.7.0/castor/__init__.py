from .core import Manager, task, Task

__version__ = "0.7.0"
