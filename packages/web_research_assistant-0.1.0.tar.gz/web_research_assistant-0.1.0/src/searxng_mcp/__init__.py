"""SearXNG-powered MCP server."""
