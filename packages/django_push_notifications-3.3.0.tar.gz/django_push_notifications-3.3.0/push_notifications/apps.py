from django.apps import AppConfig


class PushNotificationsConfig(AppConfig):
	name = "push_notifications"
	default_auto_field = "django.db.models.AutoField"
