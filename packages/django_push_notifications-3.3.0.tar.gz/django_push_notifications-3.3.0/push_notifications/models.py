from django.db import models
from django.utils.translation import gettext_lazy as _
from typing import List, Optional, Dict, Any
from .fields import HexIntegerField
from .settings import PUSH_NOTIFICATIONS_SETTINGS as SETTINGS


CLOUD_MESSAGE_TYPES = (
	("FCM", "Firebase Cloud Message"),
	("GCM", "Google Cloud Message"),
)

BROWSER_TYPES = (
	("CHROME", "Chrome"),
	("FIREFOX", "Firefox"),
	("OPERA", "Opera"),
	("EDGE", "Edge"),
	("SAFARI", "Safari")
)


class Device(models.Model):
	name = models.CharField(max_length=255, verbose_name=_("Name"), blank=True, null=True)
	active = models.BooleanField(
		verbose_name=_("Is active"), default=True,
		help_text=_("Inactive devices will not be sent notifications")
	)
	user = models.ForeignKey(
		SETTINGS["USER_MODEL"], blank=True, null=True, on_delete=models.CASCADE
	)
	date_created = models.DateTimeField(
		verbose_name=_("Creation date"), auto_now_add=True, null=True
	)
	application_id = models.CharField(
		max_length=64, verbose_name=_("Application ID"),
		help_text=_(
			"Opaque application identity, should be filled in for multiple"
			" key/certificate access"
		),
		blank=True, null=True
	)

	class Meta:
		abstract = True

	def __str__(self) -> str:
		return (
			self.name or
			str(self.device_id or "") or
			"{} for {}".format(self.__class__.__name__, self.user or "unknown user")
		)


class GCMDeviceManager(models.Manager):
	def get_queryset(self) -> "GCMDeviceQuerySet":
		return GCMDeviceQuerySet(self.model)


class GCMDeviceQuerySet(models.query.QuerySet):
	def send_message(self, message: Any, **kwargs: Any) -> Any:
		if self.exists():
			from .gcm import dict_to_fcm_message, messaging
			from .gcm import send_message as fcm_send_message

			if not isinstance(message, messaging.Message):
				data = kwargs.pop("extra", {})
				if message is not None:
					data["message"] = message
				# transform legacy data to new message object
				message = dict_to_fcm_message(data, **kwargs)

			app_ids = list(self.filter(active=True).order_by(
				"application_id"
			).values_list("application_id", flat=True).distinct())

			responses = []
			for app_id in app_ids:
				reg_ids = list(
					self.filter(
						active=True, cloud_message_type="FCM", application_id=app_id).values_list(
						"registration_id", flat=True
					)
				)
				if reg_ids:
					r = fcm_send_message(reg_ids, message, application_id=app_id, **kwargs)
					responses.extend(r.responses)

			return messaging.BatchResponse(responses)


class GCMDevice(Device):
	# device_id cannot be a reliable primary key as fragmentation between different devices
	# can make it turn out to be null and such:
	# http://android-developers.blogspot.co.uk/2011/03/identifying-app-installations.html
	device_id = HexIntegerField(
		verbose_name=_("Device ID"), blank=True, null=True, db_index=True,
		help_text=_("ANDROID_ID / TelephonyManager.getDeviceId() (always as hex)")
	)
	registration_id = models.TextField(verbose_name=_("Registration ID"), unique=SETTINGS["UNIQUE_REG_ID"])
	cloud_message_type = models.CharField(
		verbose_name=_("Cloud Message Type"), max_length=3,
		choices=CLOUD_MESSAGE_TYPES, default="FCM",
		help_text=_("You should choose FCM, GCM is deprecated")
	)
	objects = GCMDeviceManager()

	class Meta:
		verbose_name = _("FCM device")

	def send_message(self, message: Any, **kwargs: Any) -> Optional[Any]:
		from .gcm import dict_to_fcm_message, messaging
		from .gcm import send_message as fcm_send_message

		# GCM is not supported.
		if self.cloud_message_type == "GCM":
			return

		if not isinstance(message, messaging.Message):
			data: Dict[str, Any] = kwargs.pop("extra", {})
			if message is not None:
				data["message"] = message
			# transform legacy data to new message object
			message = dict_to_fcm_message(data, **kwargs)

		return fcm_send_message(
			self.registration_id, message,
			application_id=self.application_id, **kwargs
		)

class APNSDeviceManager(models.Manager):
	def get_queryset(self) -> "APNSDeviceQuerySet":
		return APNSDeviceQuerySet(self.model)


class APNSDeviceQuerySet(models.query.QuerySet):
	def send_message(self, message: Any, creds: Optional[Any] = None, **kwargs: Any) -> List[Any]:
		if self.exists():
			try:
				from .apns_async import apns_send_bulk_message
			except ImportError:
				from .apns import apns_send_bulk_message

			app_ids = self.filter(active=True).order_by("application_id") \
				.values_list("application_id", flat=True).distinct()
			res = []
			for app_id in app_ids:
				reg_ids = list(self.filter(active=True, application_id=app_id).values_list(
					"registration_id", flat=True)
				)
				r = apns_send_bulk_message(
					registration_ids=reg_ids, alert=message, application_id=app_id,
					creds=creds, **kwargs
				)
				if hasattr(r, "keys"):
					res += [r]
				elif hasattr(r, "__getitem__"):
					res += r
			return res


class APNSDevice(Device):
	device_id = models.UUIDField(
		verbose_name=_("Device ID"), blank=True, null=True, db_index=True,
		help_text=_("UUID / UIDevice.identifierForVendor()")
	)
	registration_id = models.CharField(
		verbose_name=_("Registration ID"), max_length=200,
		db_index=not SETTINGS["UNIQUE_REG_ID"],
		unique=SETTINGS["UNIQUE_REG_ID"],
	)

	objects = APNSDeviceManager()

	class Meta:
		verbose_name = _("APNS device")

	def send_message(self, message: Any, creds: Optional[Any] = None, **kwargs: Any) -> Any:
		try:
			from .apns_async import apns_send_message
		except ImportError:
			from .apns import apns_send_message

		return apns_send_message(
			registration_id=self.registration_id,
			alert=message,
			application_id=self.application_id, creds=creds,
			**kwargs
		)


class WNSDeviceManager(models.Manager):
	def get_queryset(self) -> "WNSDeviceQuerySet":
		return WNSDeviceQuerySet(self.model)


class WNSDeviceQuerySet(models.query.QuerySet):
	def send_message(self, message: Any, **kwargs: Any) -> List[Any]:
		from .wns import wns_send_bulk_message

		app_ids = list(self.filter(active=True).order_by("application_id").values_list(
			"application_id", flat=True
		).distinct())
		res = []
		for app_id in app_ids:
			reg_ids = list(self.filter(active=True, application_id=app_id).values_list(
				"registration_id", flat=True
			))
			r = wns_send_bulk_message(uri_list=reg_ids, message=message, **kwargs)
			if hasattr(r, "keys"):
				res += [r]
			elif hasattr(r, "__getitem__"):
				res += r

		return res


class WNSDevice(Device):
	device_id = models.UUIDField(
		verbose_name=_("Device ID"), blank=True, null=True, db_index=True,
		help_text=_("GUID()")
	)
	registration_id = models.TextField(verbose_name=_("Notification URI"), unique=SETTINGS["UNIQUE_REG_ID"])

	objects = WNSDeviceManager()

	class Meta:
		verbose_name = _("WNS device")

	def send_message(self, message: Any, **kwargs: Any) -> str:
		from .wns import wns_send_message

		return wns_send_message(
			uri=self.registration_id, message=message, application_id=self.application_id,
			**kwargs
		)


class WebPushDeviceManager(models.Manager):
	def get_queryset(self) -> "WebPushDeviceQuerySet":
		return WebPushDeviceQuerySet(self.model)


class WebPushDeviceQuerySet(models.query.QuerySet):
	def send_message(self, message: Any, **kwargs: Any) -> List[Any]:
		devices = self.filter(active=True).order_by("application_id").distinct()
		res: List[Any] = []
		for device in devices:
			res.append(device.send_message(message))

		return res


class WebPushDevice(Device):
	registration_id = models.TextField(verbose_name=_("Registration ID"), unique=SETTINGS["UNIQUE_REG_ID"])
	p256dh = models.CharField(
		verbose_name=_("User public encryption key"),
		max_length=88)
	auth = models.CharField(
		verbose_name=_("User auth secret"),
		max_length=24)
	browser = models.CharField(
		verbose_name=_("Browser"), max_length=10,
		choices=BROWSER_TYPES, default=BROWSER_TYPES[0][0],
		help_text=_("Currently only support to Chrome, Firefox, Edge, Safari and Opera browsers")
	)
	objects = WebPushDeviceManager()

	class Meta:
		verbose_name = _("WebPush device")

	@property
	def device_id(self) -> None:
		return None

	def send_message(self, message: Any, **kwargs: Any) -> Any:
		from .webpush import webpush_send_message

		return webpush_send_message(self, message, **kwargs)
