This library was created by Jerome Leclanche <jerome@leclan.ch>, for use on the
Anthill application (https://www.anthill.com).

Special thanks to the following core and frequent contributors:

Adam "Cezar" Jenkins
Arthur Silva
Camille Fabreguettes
Jamaal Scarlett
Matthew Hershberger
Pablo Martín


The full contributor list is available at the following URL:

https://github.com/jazzband/django-push-notifications/graphs/contributors
