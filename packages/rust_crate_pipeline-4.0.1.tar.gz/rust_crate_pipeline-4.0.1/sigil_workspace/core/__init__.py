"""Core module initialization"""
