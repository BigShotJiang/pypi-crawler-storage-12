*********************************
BGP speaker library API Reference
*********************************

BGPSpeaker class
================

.. autoclass:: os_ken.services.protocols.bgp.bgpspeaker.BGPSpeaker
   :members:

.. autoclass:: os_ken.services.protocols.bgp.bgpspeaker.EventPrefix
   :members:

.. autoclass:: os_ken.services.protocols.bgp.info_base.base.PrefixFilter
   :members:

.. autoclass:: os_ken.services.protocols.bgp.info_base.base.ASPathFilter
   :members:

.. autoclass:: os_ken.services.protocols.bgp.info_base.base.AttributeMap
   :members:
