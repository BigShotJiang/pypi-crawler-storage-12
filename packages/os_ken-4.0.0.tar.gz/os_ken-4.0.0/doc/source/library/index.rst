========
Usage
========

To use os-ken in a project::

    import os_ken
