#ifndef AC_CORE_MODEL_HPP
#define AC_CORE_MODEL_HPP

#include "AC/Core/Model/ACNet.hpp"
#include "AC/Core/Model/ARNet.hpp"

#endif
