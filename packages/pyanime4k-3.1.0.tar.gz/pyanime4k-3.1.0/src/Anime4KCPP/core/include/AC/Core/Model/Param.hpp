#ifndef AC_CORE_MODEL_PARAM_HPP
#define AC_CORE_MODEL_PARAM_HPP

namespace ac::core::model::param
{
#include "AC/Core/Model/Param/ACNet.p"
#include "AC/Core/Model/Param/ARNet.p"
}

#endif
