#ifndef AC_BINDING_C_CORE_H
#define AC_BINDING_C_CORE_H

#include "AC/Core/Image.h"
#include "AC/Core/Processor.h"
#include "AC/Error.h"

#endif
