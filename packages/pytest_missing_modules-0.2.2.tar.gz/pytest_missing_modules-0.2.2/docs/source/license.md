# License

```{include} ../../LICENSE.md
```
