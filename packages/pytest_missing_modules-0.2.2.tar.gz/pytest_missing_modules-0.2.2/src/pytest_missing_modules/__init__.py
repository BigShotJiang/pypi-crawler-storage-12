"""Pytest plugin for faking missing modules."""
