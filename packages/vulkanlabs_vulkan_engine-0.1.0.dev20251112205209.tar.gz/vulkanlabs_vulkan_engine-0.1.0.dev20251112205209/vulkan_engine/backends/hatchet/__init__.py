"""Hatchet integration module for vulkan-engine."""
