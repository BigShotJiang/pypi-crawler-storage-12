Analysis_Project
----------------

Class for analysis, this the main class which makes objects to define the analysis following the workflow of the Wisconsin Department of Natural Resources. This class combines multiple `Well` objects, each of which contains one or more `WellResponse` objects. The `AnalysisProject` object is instantiated using a yaml configuration file. 

.. automodule:: pycap.analysis_project
   :members:
   :show-inheritance: