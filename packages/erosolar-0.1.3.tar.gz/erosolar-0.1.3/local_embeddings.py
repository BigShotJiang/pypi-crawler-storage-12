"""Local embeddings using BGE models via sentence-transformers.

Provides OpenAI-compatible interface for local embeddings that match or beat
OpenAI's text-embedding-3 performance on MTEB benchmarks.

Performance comparison (MTEB):
- bge-large-en-v1.5: 64.23% (1024 dims, 335M params)
- OpenAI text-embedding-3-large: 64.6% (3072 dims)
- Difference: Only 0.37 percentage points

BGE is optimized for retrieval/matching tasks, making it ideal for tool selection.
"""

import logging
from typing import Any, Dict, List, Union

import numpy as np

logger = logging.getLogger(__name__)


class LocalEmbeddingClient:
    """
    OpenAI-compatible wrapper for local BGE embeddings via sentence-transformers.

    Provides the same interface as OpenAI's embedding API but runs 100% locally.
    Uses BAAI/bge-large-en-v1.5 which matches OpenAI's performance on MTEB.
    """

    def __init__(
        self,
        model_name: str = "BAAI/bge-large-en-v1.5",
        device: str = None,
        cache_folder: str = None
    ):
        """
        Initialize local embedding client.

        Args:
            model_name: HuggingFace model name (default: bge-large-en-v1.5)
            device: Device to run on ('cuda', 'cpu', or None for auto-detect)
            cache_folder: Custom cache folder for model files
        """
        self.model_name = model_name
        self._model = None
        self._device = device
        self._cache_folder = cache_folder

        logger.info(f"Initializing local embeddings: {model_name}")

    def _load_model(self):
        """Lazy-load the sentence-transformers model."""
        if self._model is not None:
            return

        try:
            from sentence_transformers import SentenceTransformer

            logger.info(f"Loading embedding model: {self.model_name}")
            self._model = SentenceTransformer(
                self.model_name,
                device=self._device,
                cache_folder=self._cache_folder
            )
            logger.info(f"Model loaded successfully on device: {self._model.device}")
        except ImportError:
            logger.error(
                "sentence-transformers not installed. "
                "Install with: pip install sentence-transformers"
            )
            raise
        except Exception as e:
            logger.error(f"Failed to load embedding model: {e}")
            raise

    @property
    def embeddings(self):
        """Provide OpenAI-compatible embeddings interface."""
        return self

    def create(
        self,
        input: Union[str, List[str]],
        model: str = None,
        **kwargs
    ) -> "EmbeddingResponse":
        """
        Create embeddings (OpenAI-compatible interface).

        Args:
            input: Single text or list of texts to embed
            model: Model name (ignored, uses initialized model)
            **kwargs: Additional args (ignored for compatibility)

        Returns:
            EmbeddingResponse with OpenAI-compatible structure
        """
        self._load_model()

        # Normalize input to list
        texts = [input] if isinstance(input, str) else input

        # Add BGE instruction prefix for better retrieval performance
        # BGE models are trained with "Represent this sentence for searching relevant passages:"
        # But for tool matching, we don't need the prefix as it's symmetric similarity

        # Generate embeddings
        embeddings = self._model.encode(
            texts,
            normalize_embeddings=True,  # L2 normalization for cosine similarity
            show_progress_bar=False,
            convert_to_numpy=True
        )

        # Convert to OpenAI-compatible response
        data = [
            {
                "object": "embedding",
                "index": i,
                "embedding": emb.tolist()
            }
            for i, emb in enumerate(embeddings)
        ]

        return EmbeddingResponse(
            object="list",
            data=data,
            model=self.model_name,
            usage={
                "prompt_tokens": sum(len(t.split()) for t in texts),  # Rough estimate
                "total_tokens": sum(len(t.split()) for t in texts)
            }
        )


class EmbeddingResponse:
    """OpenAI-compatible embedding response object."""

    def __init__(self, object: str, data: List[Dict], model: str, usage: Dict):
        self.object = object
        self.data = data
        self.model = model
        self.usage = usage

    def __getitem__(self, key):
        """Allow dict-like access for compatibility."""
        return getattr(self, key)


def get_embedding_client(prefer_local: bool = True) -> Any:
    """
    Get best available embedding client.

    Args:
        prefer_local: If True, use local BGE even if OpenAI key available

    Returns:
        LocalEmbeddingClient or OpenAI client
    """
    import os

    if prefer_local:
        logger.info("Using local BGE embeddings (matches OpenAI performance)")
        return LocalEmbeddingClient()

    # Check for OpenAI API key
    openai_key = os.environ.get("OPENAI_API_KEY")
    if openai_key:
        try:
            from openai import OpenAI
            logger.info("Using OpenAI embeddings API")
            return OpenAI(api_key=openai_key)
        except ImportError:
            logger.warning("OpenAI package not available, falling back to local")
            return LocalEmbeddingClient()

    logger.info("No OpenAI key found, using local BGE embeddings")
    return LocalEmbeddingClient()


# Convenience function for backward compatibility
def create_embedding_client(
    openai_api_key: str = None,
    prefer_local: bool = True,
    local_model: str = "BAAI/bge-large-en-v1.5"
) -> Any:
    """
    Create embedding client with smart defaults.

    Args:
        openai_api_key: OpenAI API key (optional)
        prefer_local: Use local embeddings even if OpenAI available
        local_model: Local model to use

    Returns:
        Embedding client (local or OpenAI)
    """
    if prefer_local:
        return LocalEmbeddingClient(model_name=local_model)

    if openai_api_key:
        from openai import OpenAI
        return OpenAI(api_key=openai_api_key)

    return LocalEmbeddingClient(model_name=local_model)
