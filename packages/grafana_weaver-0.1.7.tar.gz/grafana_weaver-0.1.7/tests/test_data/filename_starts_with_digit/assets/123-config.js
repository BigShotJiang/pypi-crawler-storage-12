// EXTERNAL:123-config.js
const config = {version: '1.23'};
