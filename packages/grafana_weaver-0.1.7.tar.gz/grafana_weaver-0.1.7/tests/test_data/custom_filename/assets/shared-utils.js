// EXTERNAL:shared-utils.js
const utils = {
  format: (x) => x.toFixed(2)
};
