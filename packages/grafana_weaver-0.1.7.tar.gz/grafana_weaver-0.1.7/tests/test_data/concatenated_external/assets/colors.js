// EXTERNAL:colors.js
const COLORS = {primary: '#3498db'};
