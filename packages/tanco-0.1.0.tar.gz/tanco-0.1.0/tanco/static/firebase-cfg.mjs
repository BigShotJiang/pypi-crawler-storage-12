
export const firebaseConfig = {
  apiKey: "AIzaSyB186Sn82G_z-u38HWQq5-PuMvTIDa4SX8",
  authDomain: "rogo-dev-4e99f.firebaseapp.com",
  projectId: "rogo-dev-4e99f",
  storageBucket: "rogo-dev-4e99f.appspot.com",
  messagingSenderId: "212137834895",
  appId: "1:212137834895:web:bcfcad4e186caef72273fa"};
