from __future__ import annotations

from docs2markdown.cli import app

if __name__ == "__main__":
    app()
