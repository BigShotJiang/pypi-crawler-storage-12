# wire-websocket

Wire for communicating over WebSocket.
