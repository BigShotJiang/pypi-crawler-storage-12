"""lazyreq - Smart Runtime Dependency Manager"""

from .core import require

__all__ = [
    "require"
]
