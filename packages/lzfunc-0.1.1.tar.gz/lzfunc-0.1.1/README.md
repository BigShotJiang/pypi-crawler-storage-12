# LzFunc - Lazy Functions Module

A small library with some 1-line functions to reduce boilerplate in the code. Also has some unusual functions.
The main part contains about 5 functions, 1 class and 1 extra error.

## About

```python
import LzFunc
help(LzFunc.core)

## Download

```bash
pip install LzFunc