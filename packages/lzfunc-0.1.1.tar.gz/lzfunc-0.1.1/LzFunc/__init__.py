"""
LzFunc - Lazy functions for a clean code
"""

__version__ = "0.1.1"
__author__ = "Pozitive_Guy"

from .core import *