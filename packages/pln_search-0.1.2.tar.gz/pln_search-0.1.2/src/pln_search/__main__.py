"""Entry point for python -m pln_search."""

from pln_search.cli import main

if __name__ == "__main__":
    main()
