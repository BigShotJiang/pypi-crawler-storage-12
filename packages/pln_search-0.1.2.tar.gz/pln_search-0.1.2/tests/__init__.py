"""Tests for pln-search."""
