from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass


VERSION = "directory_v1"

DEFAULT_FIELDS = "*"
