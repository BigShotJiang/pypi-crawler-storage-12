# -*- coding: utf-8 -*-
"""
Full wave form seismics utilities and simulations
"""
from . seismics import *
