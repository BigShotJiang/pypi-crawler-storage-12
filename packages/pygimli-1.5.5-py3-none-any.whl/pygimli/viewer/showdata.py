# -*- coding: utf-8 -*-
"""General methods to show data like structures. Maybe redundant (BERT).

no mpl specific stuff.
"""
