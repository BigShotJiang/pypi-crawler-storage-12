"""CLI module for chapkit project scaffolding."""

from chapkit.cli.cli import app

__all__ = ["app"]
