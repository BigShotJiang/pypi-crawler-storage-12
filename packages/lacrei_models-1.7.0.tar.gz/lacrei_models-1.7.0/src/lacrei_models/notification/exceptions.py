class SMSError(Exception):
    pass
