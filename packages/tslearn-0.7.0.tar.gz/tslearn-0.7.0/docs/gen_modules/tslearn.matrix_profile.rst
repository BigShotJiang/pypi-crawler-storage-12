.. _mod-matrix_profile:

tslearn.matrix_profile
======================

.. automodule:: tslearn.matrix_profile

   .. rubric:: Classes

   .. autosummary::
      :toctree: matrix_profile
      :template: class.rst
   
      MatrixProfile
   
   

   
   
   