tslearn.svm
===========

.. automodule:: tslearn.svm

   .. rubric:: Classes

   .. autosummary::
      :toctree: svm
      :template: class.rst
   
      TimeSeriesSVC
      TimeSeriesSVR

   

   
   
   