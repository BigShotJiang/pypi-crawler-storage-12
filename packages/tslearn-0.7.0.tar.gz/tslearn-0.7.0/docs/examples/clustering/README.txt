Clustering and Barycenters
--------------------------

