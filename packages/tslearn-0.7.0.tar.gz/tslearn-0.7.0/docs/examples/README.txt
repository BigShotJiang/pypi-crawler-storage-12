.. _examples-index:

Gallery of examples
===================

