User Guide
==========

.. toctree::
    :maxdepth: 2
    :numbered:

    dtw
    lcss
    kernel
    clustering
    shapelets
    matrix-profile
    early
