# Import de la classe OvhS3 depuis le module main
# Cela permet d'utiliser: from s3file import OvhS3
from .main import OvhS3

# Liste des symboles exportés publiquement par le package
__all__ = ["OvhS3"]

