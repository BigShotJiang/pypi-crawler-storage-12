python3 docs/quarto_table_build.py --out table.qmd
quarto render table.qmd
open table.html