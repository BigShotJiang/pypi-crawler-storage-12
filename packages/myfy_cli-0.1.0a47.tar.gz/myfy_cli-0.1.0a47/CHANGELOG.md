# Changelog - myfy-cli

All notable changes to myfy-cli will be documented in this file.

## [Unreleased]

## [0.1.0] - 2025-10-29

### Added
- `myfy run` command for running applications
- Rich console output
- Uvicorn integration for ASGI apps
- Command-line interface with Typer
