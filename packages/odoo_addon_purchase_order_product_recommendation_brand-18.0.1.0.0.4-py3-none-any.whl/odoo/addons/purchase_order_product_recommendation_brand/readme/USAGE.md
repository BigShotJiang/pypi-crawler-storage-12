To use this module, you need to:

1.  Create a new purchase order.
2.  Assign its supplier.
3.  Press *Recommended Products* button.
4.  Now you can also filter by product brands.
