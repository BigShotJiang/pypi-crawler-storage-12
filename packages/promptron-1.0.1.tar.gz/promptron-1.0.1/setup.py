"""Setup script for promptron package."""

from setuptools import setup

# This file is kept for compatibility, but pyproject.toml is the source of truth
setup()

