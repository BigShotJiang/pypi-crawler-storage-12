"""CLI 模块"""
from .main import cli

__all__ = ["cli"]
