"""Vibe Todo - 简洁实用的任务和工时管理工具"""

__version__ = "0.1.0"
