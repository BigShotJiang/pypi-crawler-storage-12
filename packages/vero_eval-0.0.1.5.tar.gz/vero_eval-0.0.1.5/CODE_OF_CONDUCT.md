# Code of Conduct
This project adheres to the [Contributor Covenant](https://www.contributor-covenant.org/version/2/1/code_of_conduct.html).
By participating, you are expected to uphold this code.
For any issues, contact: alakhagr@gmail.com, vishalsrivastava8203@gmail.com
