if __name__ == "__main__":
    from circuitydatabase_paulbillingross.cli import app
    app()
