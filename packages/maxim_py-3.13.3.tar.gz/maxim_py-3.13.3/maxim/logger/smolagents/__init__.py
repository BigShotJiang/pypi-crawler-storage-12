from .client import instrument_smolagents

__all__ = ["instrument_smolagents"]

