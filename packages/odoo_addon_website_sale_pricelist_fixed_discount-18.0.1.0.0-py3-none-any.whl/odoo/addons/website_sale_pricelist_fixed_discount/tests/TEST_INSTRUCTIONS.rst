Setup:

- Enable "Pricelists" settings option
- Enable "Discounts" settings option
- Open pricelist default
- Add fixed price 100 with 10% discount for all products with minimum qty 1.0
- Add fixed price 100 with 20% discount for all products with minimum qty 2.0

Cart:

- Open website
- Add a random product to the cart
- Ensure 10% discount is applied
- Increate qty to 2.0
- Ensure 20% discount is applied
