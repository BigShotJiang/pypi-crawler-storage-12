from typing_extensions import Literal

CuGraphKind = Literal['Graph', 'MultiGraph', 'BiPartiteGraph']
