"""V1 System: Pattern-based tool generation."""

from .system import V1System

__all__ = ["V1System"]
