# Robust compression of fixed-length housekeeping data, CCSDS 124.0-B-1.

The source code and the binaries are not redistributed with enb due to intellectual property issues.

