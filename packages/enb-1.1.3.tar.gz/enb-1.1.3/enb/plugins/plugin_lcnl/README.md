# Low-complexity near-lossless image compression (LCNL), CCSDS 123.0-B-2

The source code and the binaries are not redistributed with enb due to intellectual property issues.

The binaries can be obtained at https://logiciels.cnes.fr/en/license/173/728 provided by CNES.
