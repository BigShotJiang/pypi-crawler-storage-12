Unfortunately, no source code or binaries can be provided here due to IPR.

# Installation notes on Ubuntu: 

Installation instructions for Ubuntu 20.04 LTS, 2020 version:

0. Download the openssl-libs package from https://centos.pkgs.org/7/centos-x86_64/openssl-libs-1.0.2k-19.el7.x86_64.rpm.html
1. Unzip the RPM
2. Copy the libcrypto* files from ./usr/lib64 (from the RPM) into /usr/lib/
