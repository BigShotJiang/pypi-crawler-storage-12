# enb plugin for the libjpeg library from https://github.com/thorfdbg/libjpeg/archive/master.zip
