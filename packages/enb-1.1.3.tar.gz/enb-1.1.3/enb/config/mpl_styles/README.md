This folder contains the default style configuration files of enb.
Their format is compatible with matplotlib's rc files.

You can install your custom style files by copying them into the root
of your project(s). 

