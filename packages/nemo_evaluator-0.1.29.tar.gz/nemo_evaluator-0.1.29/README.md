# NeMo Evaluator

For complete documentation, please see: [docs/nemo-evaluator/index.md](https://github.com/NVIDIA-NeMo/Evaluator/tree/main/docs/nemo-evaluator/index.md)
