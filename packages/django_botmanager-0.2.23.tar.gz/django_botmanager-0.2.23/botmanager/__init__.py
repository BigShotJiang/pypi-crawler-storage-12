# -*- coding: utf-8 -*-


class BotManagerTaskError(Exception):
    pass
