"""Dependency module for igloo-mcp."""

from .dependency_service import DependencyService

__all__ = ["DependencyService"]
