"""Database layer - Engine, UoW, and RLS management."""
