"""Onboarding domain - User setup and preferences."""
