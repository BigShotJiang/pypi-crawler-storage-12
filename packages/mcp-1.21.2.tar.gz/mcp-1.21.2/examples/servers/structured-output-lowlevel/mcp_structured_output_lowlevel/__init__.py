"""Example of structured output with low-level MCP server."""
