"""FastMCP CLI package."""

from .cli import app

if __name__ == "__main__":  # pragma: no cover
    app()
