### Next Steps
- Identify the release that matches your research needs.
- Ask for differences between adjacent releases if unsure.
- Fetch detailed metadata via `get_dataset_info`.
