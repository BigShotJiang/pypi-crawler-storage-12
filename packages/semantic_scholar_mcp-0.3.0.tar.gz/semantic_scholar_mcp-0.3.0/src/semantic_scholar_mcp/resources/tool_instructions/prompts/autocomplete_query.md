### Next Steps
- Use the suggestions to craft a clearer search prompt.
- Ask for the pros and cons of the top suggested phrases.
- Run `search_papers` with the selected completion.
