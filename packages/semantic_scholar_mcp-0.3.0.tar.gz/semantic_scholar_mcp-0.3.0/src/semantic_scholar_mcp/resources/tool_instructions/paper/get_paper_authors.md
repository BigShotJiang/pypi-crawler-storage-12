### Next Steps
- Identify recurring collaborators or leading authors.
- Ask for author profiles to evaluate expertise.
- Follow up with `get_author_papers` for a selected researcher.
