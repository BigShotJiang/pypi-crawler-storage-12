### Next Steps
- Check each match score to gauge semantic proximity.
- Ask for a narrative summary of the closest matches.
- Feed chosen IDs into `get_paper` for full context.
