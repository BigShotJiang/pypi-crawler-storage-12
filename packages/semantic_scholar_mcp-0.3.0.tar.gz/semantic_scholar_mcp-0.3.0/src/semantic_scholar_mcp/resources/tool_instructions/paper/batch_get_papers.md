### Next Steps
- Check that each requested paper is present and complete.
- Ask for a synthesis across the batch to spot shared themes.
- Plan deeper dives using `get_paper` where more detail is needed.
