### Next Steps
- Review the returned `papers` list and flag items worth reading.
- Ask for summaries of any paper that stands out.
- Refine the query or add filters if the scope is still too broad.
