@CLAUDE.md
Explain in japanese.
Use Serena MCP.
Use uv for Python tooling.
