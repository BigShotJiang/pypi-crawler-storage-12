import logging
import math
from collections.abc import AsyncGenerator, AsyncIterator, Awaitable, Callable, Coroutine, Generator
from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass
from typing import Any

import anyio
from anyio.abc import AnyByteStream
from anyio.streams.memory import MemoryObjectReceiveStream

from .message import (
    Message,
    Request,
    RequestCancel,
    RequestStreamChunk,
    RequestStreamEnd,
    Response,
    ResponseStreamChunk,
    ResponseStreamEnd,
    message_from_bytes,
    message_to_bytes,
)

LOG = logging.getLogger(__name__)


class ClientError(Exception):
    """
    Base exception for remote client errors
    """


class RemoteError(ClientError):
    """
    Remote method raised an exception, wrapped within
    """


class InvalidValue(ValueError, ClientError):
    """
    Invalid value(s) passed to RPC method.
    """


class InternalError(ClientError):
    """
    Server encountered an internal error.
    """


class _RequestTask:
    """
    Container for streams associated with a request.
    """

    _value: Any = object()

    def __init__(self) -> None:
        # There will only ever be one response, buffer size of 1 is appropriate
        self.response_producer, self.response_consumer = anyio.create_memory_object_stream[Response](1)
        # There may be many stream chunks, do not block on receiving them.
        self.stream_producer, self.stream_consumer = anyio.create_memory_object_stream[Any](math.inf)

    async def get_response(self) -> Any:
        if self._value is not _RequestTask._value:
            # return cached value
            return self._value

        with self.response_producer, self.response_consumer:
            response = await self.response_consumer.receive()
            self._value = response.value

            if response.status_is_ok:
                return self._value
            elif response.status_is_invalid:
                raise InvalidValue(response.value)
            elif response.status_is_internal:
                raise InternalError(response.value)
            else:
                raise RemoteError(response.value)


@dataclass(repr=False)
class RequestStream(Awaitable[Any], AsyncIterator["RequestStream"]):
    """
    Yielded from `RPCClient.request_stream()`
    """

    _get_response: Callable[[], Coroutine[None, None, None]]
    _stream_consumer: MemoryObjectReceiveStream[Any]
    send: Callable[[Any], Coroutine[None, None, None]]

    def __aiter__(self) -> "RequestStream":
        return self

    async def __anext__(self) -> Any:
        try:
            return await self._stream_consumer.receive()
        except anyio.EndOfStream:
            raise StopAsyncIteration()

    def __await__(self) -> Generator[None, None, Any]:
        return self._get_response().__await__()


class RPCClient:
    def __init__(self, stream: AnyByteStream, raise_on_error: bool = False) -> None:
        self.stream = stream
        self.raise_on_error = raise_on_error
        #: In-flight requests, key is request id
        self.tasks: dict[int, _RequestTask] = {}
        self._next_id = 0
        # This represents the maximum number of concurrent requests
        # We don't want this to be huge so the message size stays small
        self._max_id = 2**16 - 1
        self._timeout = 10

    @property
    def next_msg_id(self) -> int:
        if self._next_id >= self._max_id:  # pragma: nocover
            self._next_id = 0
        else:
            self._next_id += 1
        while self._next_id in self.tasks:  # pragma: nocover
            # Make sure task with this ID isn't already in-flight
            self._next_id += 1
        return self._next_id

    @asynccontextmanager
    async def _make_ctx(self) -> AsyncGenerator["RPCClient", None]:
        try:
            async with anyio.create_task_group() as task_group:
                task_group.start_soon(self.receive_loop)
                yield self
                task_group.cancel_scope.cancel()
        finally:
            self.tasks.clear()

    async def __aenter__(self) -> "RPCClient":
        self._ctx = self._make_ctx()
        return await self._ctx.__aenter__()

    async def __aexit__(self, *args: Any) -> bool | None:
        return await self._ctx.__aexit__(*args)

    @contextmanager
    def _make_req_task(self, req_id: int) -> Generator[_RequestTask, None, None]:
        task = self.tasks[req_id] = _RequestTask()
        try:
            with task.response_consumer, task.response_producer, task.stream_consumer, task.stream_producer:
                yield task
        finally:
            del self.tasks[req_id]

    async def request(self, method: str, *args: Any, **kwargs: Any) -> Any:
        req = Request(id=self.next_msg_id, method=method, args=args, kwargs=kwargs)
        await self.send_msg(req)

        with self._make_req_task(req.id) as task:
            try:
                return await task.get_response()
            except anyio.get_cancelled_exc_class():
                with anyio.CancelScope(shield=True):
                    await self.send_msg(RequestCancel(req.id))
                raise

    @asynccontextmanager
    async def request_stream(self, method: str, *args: Any, **kwargs: Any) -> AsyncGenerator[RequestStream, None]:
        req = Request(id=self.next_msg_id, method=method, args=args, kwargs=kwargs)
        await self.send_msg(req)

        did_send_chunk = False

        async def send_stream_chunk(value: Any) -> None:
            nonlocal did_send_chunk
            did_send_chunk = True
            await self.send_msg(RequestStreamChunk(req.id, value))

        with self._make_req_task(req.id) as task:
            try:
                yield RequestStream(
                    _get_response=task.get_response,
                    _stream_consumer=task.stream_consumer,
                    send=send_stream_chunk,
                )
                if did_send_chunk:
                    # Sent a stream chunk, must send the stream end
                    await self.send_msg(RequestStreamEnd(req.id))
                await task.get_response()
            except anyio.get_cancelled_exc_class():
                with anyio.CancelScope(shield=True):
                    await self.send_msg(RequestCancel(req.id))
                raise

    async def receive_loop(self) -> None:
        """
        Receives data on the websocket and runs handlers.
        """
        async for data in self.stream:
            msg = message_from_bytes(data)
            task = self.tasks.get(msg.id)

            # If we cancel a request, it is possible that responses could come after deleting the task.
            # In this case, we do not care about those responses.
            if task is not None:
                try:
                    if isinstance(msg, Response):
                        await task.response_producer.send(msg)
                    elif isinstance(msg, ResponseStreamChunk):
                        await task.stream_producer.send(msg.value)
                    elif isinstance(msg, ResponseStreamEnd):
                        task.stream_producer.close()
                    else:
                        LOG.warning("Received unhandled message: %s", msg)
                except anyio.get_cancelled_exc_class():  # pragma: nocover
                    raise
                except:
                    if self.raise_on_error:
                        raise
                    else:
                        LOG.exception("Client receive error: %s", msg)

    async def send_msg(self, msg: Message) -> None:
        await self.stream.send(message_to_bytes(msg))
