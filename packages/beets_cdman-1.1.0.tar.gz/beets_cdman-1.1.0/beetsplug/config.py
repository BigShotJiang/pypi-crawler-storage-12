class Config:
    dry = False
    verbose = False
