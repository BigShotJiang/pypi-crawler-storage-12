# This must be same with v6d:modules/io/python/drivers/io/kube_ssh.sh
ANALYTICAL_CONTAINER_NAME = "engine"
INTERACTIVE_FRONTEND_CONTAINER_NAME = "frontend"
INTERACTIVE_EXECUTOR_CONTAINER_NAME = "executor"
GRAPHLEARN_CONTAINER_NAME = "graphlearn"
GRAPHLEARN_TORCH_CONTAINER_NAME = "graphlearn-torch"
DATASET_CONTAINER_NAME = "dataset"
MARS_CONTAINER_NAME = "mars"
VINEYARD_CONTAINER_NAME = "vineyard"
