"""
Open edX Learning ("Learning Core").
"""

__version__ = "0.30.1"
