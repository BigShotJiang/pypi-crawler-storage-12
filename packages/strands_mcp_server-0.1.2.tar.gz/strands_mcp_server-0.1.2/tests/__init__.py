"""Tests for strands-mcp-server package."""
