from . import test_partner_shipping_policy
