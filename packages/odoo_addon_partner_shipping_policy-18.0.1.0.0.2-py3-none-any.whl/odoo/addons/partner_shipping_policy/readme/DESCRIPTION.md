A new field is introduced to specify the shipping policy for each
partner. In sales orders, the shipping policy will be set to the
delivery address contact shipping policy. If the field is empty, it
falls back to the shipping policy set in the main contact. If neither
the delivery address nor the customer contact has a shipping policy set,
it will be set with the configured default value.
