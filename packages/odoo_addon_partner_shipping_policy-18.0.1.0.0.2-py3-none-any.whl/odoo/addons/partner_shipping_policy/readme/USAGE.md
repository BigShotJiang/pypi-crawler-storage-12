Fill in the shipping policy field for the contact in the contact form.
You can find this new field in the "Sales & Purchase" tab. When creating
a sales order the shipping policy will be set taking into account the
delivery address shipping policy or the main contact shipping policy.
