from setuptools import setup

# This file is maintained for backward compatibility
# All configuration is now in pyproject.toml
setup()
