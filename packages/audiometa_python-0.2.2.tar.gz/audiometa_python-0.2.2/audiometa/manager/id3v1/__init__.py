"""ID3v1 metadata management."""
