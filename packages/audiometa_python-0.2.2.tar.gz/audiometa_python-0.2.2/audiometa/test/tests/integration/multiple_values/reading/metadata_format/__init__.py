"""Tests for reading multiple entries for the same tag in different metadata formats."""
