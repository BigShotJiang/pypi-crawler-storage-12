#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__version__ = '2.5'
__author__ = 'Bruno Chaves'
__license__ = 'MIT'
__module_name__ = 'convert_stream'
__modify_date__ = '2025-11-15'

