__all__ = [
    'tabulate',
]


__version__ = '0.6.1'

from .api import tabulate
