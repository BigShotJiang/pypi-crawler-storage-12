

class InvalidExpression(ValueError):
    pass


class IncompatiblePaths(ValueError):
    pass
