This is a package used during testing.
The tests that use this, may override files, including setup.py.
