Module blaxel.openai
====================