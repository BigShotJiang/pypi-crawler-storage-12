Module blaxel.core.client.api.volumes
=====================================

Sub-modules
-----------
* blaxel.core.client.api.volumes.create_volume
* blaxel.core.client.api.volumes.delete_volume
* blaxel.core.client.api.volumes.get_volume
* blaxel.core.client.api.volumes.list_volumes