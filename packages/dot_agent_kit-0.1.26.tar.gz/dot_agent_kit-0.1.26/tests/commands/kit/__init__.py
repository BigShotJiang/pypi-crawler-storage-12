"""Tests for kit commands."""
