"""Tests for kits."""
