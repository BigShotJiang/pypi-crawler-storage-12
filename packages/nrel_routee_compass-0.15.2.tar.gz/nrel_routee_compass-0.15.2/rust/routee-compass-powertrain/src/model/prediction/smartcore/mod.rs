mod smartcore_model;

pub use smartcore_model::SmartcoreModel;
