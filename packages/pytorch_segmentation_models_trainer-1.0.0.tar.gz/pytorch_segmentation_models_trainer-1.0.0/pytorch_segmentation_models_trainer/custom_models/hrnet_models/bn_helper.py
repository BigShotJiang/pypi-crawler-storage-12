import torch
import functools

relu_inplace = True
