from dbt.tests.adapter.empty.test_empty import BaseTestEmpty, BaseTestEmptyInlineSourceRef


class TestRedshiftEmpty(BaseTestEmpty):
    pass


class TestRedshiftEmptyInlineSourceRef(BaseTestEmptyInlineSourceRef):
    pass
