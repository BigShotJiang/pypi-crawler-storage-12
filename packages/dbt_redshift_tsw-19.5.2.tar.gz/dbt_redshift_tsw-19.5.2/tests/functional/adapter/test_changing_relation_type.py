from dbt.tests.adapter.relations.test_changing_relation_type import BaseChangeRelationTypeValidator


class TestRedshiftChangeRelationTypes(BaseChangeRelationTypeValidator):
    pass
