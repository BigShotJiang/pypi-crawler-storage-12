from dbt.tests.adapter.sample_mode.test_sample_mode import (
    BaseSampleModeTest,
)


class TestRedshiftSampleMode(BaseSampleModeTest):
    pass
