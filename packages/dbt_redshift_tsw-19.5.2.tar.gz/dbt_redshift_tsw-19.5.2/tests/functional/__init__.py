# supports namespacing during test discovery
