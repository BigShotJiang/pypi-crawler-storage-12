
Knwl has a rich output and formatting system which allows to render data to markdown, html and console. The output system is modular and allows to create custom renderers for different data types.
