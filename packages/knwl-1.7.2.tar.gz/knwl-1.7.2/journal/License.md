Knwl is under the MIT License.
Copyright (c) Francois Vanderseypen (Orbifold Consulting)

Whether this prohibits abuse in faraway countries and via AI is doubtful.
If you find this software useful, spread the word, fork it, star it.

If you need support or guidance, contact us at any of the following:

    🌎 https://orbifold.net/contact/

    ✉️ swa@orbifold.net

    🛜 https://www.linkedin.com/in/francoisvanderseypen/

