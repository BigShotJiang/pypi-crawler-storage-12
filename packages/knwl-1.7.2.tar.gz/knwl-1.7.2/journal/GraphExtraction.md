You can use Knwl to extract knowledge graphs without storing anything in a database.

