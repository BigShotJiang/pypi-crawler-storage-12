from knwl.storage.sql_base import SqlStorageBase


class SqliteStorage(SqlStorageBase):
    pass