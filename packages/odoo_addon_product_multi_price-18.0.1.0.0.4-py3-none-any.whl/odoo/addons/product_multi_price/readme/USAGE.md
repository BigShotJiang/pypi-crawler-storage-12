To use this module, you need to:

1.  Go to the product page.
2.  In the general tab, there's a list called *Other Prices*.
3.  You can add one for every price name available.

To base pricelist rules on that fields, in the pricelist:

1.  Add a rule and choose *formula* as the computing method.
2.  In the *Based on* dropdown list, select *Other Price*.
3.  A new list appear: *Other Price Name*. Pick the one you need.
4.  Configure the formula.
5.  Now the rule is based on that price for the products that have it
    configured. Otherwise, it will return 0.
