This module allows to set multiple prices to products and base pricelist
rules on them.
