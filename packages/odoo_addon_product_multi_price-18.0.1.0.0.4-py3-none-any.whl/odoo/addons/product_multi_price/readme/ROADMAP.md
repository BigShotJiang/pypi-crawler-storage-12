- Add mechanisms that allow to set multiprices values from external
  flows. For example: having AVCO, FIFO and Standard prices computed
  simultaneously in this table.
