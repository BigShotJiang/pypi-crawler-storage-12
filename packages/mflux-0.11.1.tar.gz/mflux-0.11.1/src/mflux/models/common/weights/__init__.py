"""Common weight mapping utilities."""
