"""ZSH completion generator for mflux CLI commands."""
