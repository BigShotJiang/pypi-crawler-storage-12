# -*- coding: utf-8 -*-
"""async_upnp_client.profiles module."""
