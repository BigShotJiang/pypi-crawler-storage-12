# -*- coding: utf-8 -*-
"""async_upnp_client module."""

__version__ = "0.46.0"
