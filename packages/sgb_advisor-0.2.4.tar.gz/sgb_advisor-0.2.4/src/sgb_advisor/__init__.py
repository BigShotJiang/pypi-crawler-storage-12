"""
A tool to analyse Sovereign Gold Bonds and compare their yields.
"""

from .__main__ import runner as runner
