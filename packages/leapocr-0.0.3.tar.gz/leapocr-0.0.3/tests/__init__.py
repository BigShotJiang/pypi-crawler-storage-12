"""Test suite for LeapOCR Python SDK."""
