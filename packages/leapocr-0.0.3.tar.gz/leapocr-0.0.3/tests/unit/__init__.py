"""Unit tests for LeapOCR SDK."""
