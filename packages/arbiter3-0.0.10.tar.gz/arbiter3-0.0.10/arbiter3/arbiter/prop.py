CPU_QUOTA = "CPUQuotaPerSecUSec"
MEMORY_HIGH = "MemoryHigh"
MEMORY_MAX = "MemoryMax"
MEMORY_SWAP_MAX = "MemorySwapMax"
