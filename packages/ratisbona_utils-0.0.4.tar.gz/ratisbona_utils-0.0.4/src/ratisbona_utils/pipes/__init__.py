# __init__.py-file.
from .pipes import cat, fcat, collect