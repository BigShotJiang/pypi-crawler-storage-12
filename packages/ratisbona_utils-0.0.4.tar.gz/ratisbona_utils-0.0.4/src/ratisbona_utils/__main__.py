import typer
from ratisbona_utils.example import greet


if __name__ == "__main__":
    typer.run(greet)
