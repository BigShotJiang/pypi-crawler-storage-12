
class QtContext:
    def __init__(self, painter):
        self.painter = painter

    def rect(x, y, width, height):
        return plt.Rectangle((x, y), width, height, **kwargs)