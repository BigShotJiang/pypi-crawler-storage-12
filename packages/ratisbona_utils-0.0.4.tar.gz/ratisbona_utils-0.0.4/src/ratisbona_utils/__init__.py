__app_name__ = "ratisbona_utils"
__version__ = "0.0.1"