from .file_iterator import FileIterable
from ._io import maybe_backup_file, UTF8, errprint, get_config_dir, get_resource