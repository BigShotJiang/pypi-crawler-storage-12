"""
    Extensions for the Cli parser library Click.
"""
from ._click_extensions import DefaultGroup