from ratisbona_utils.colors.palette_cli import palette_cli


def main():
    palette_cli()


if __name__ == "__main__":
    main()