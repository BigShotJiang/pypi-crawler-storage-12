from matplotlib import colormaps

