from enum import Enum
from typing import List

from ratisbona_utils.latex.quotes_parser import QuotesParser



