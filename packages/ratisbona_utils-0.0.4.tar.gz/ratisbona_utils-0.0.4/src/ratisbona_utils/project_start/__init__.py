"""
    Module hinting on how to start a project in python.
"""

def print_hint():
    print(
        """# Please execute:
git clone -o template git clone git://git.code.sf.net/p/ratisbona-template-project/code YOUR_PROJECT_NAME_HERE
"""
    )
