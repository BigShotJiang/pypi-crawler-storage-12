from . import print_hint

def main():
    print_hint()

if __name__ == "__main__":
    main()
