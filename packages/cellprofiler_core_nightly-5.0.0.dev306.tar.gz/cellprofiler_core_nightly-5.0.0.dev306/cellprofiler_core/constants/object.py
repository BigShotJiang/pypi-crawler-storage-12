OBJECT_TYPE_NAME = "objects"
