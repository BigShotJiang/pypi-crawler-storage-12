# SPDX-FileCopyrightText: 2025 Florent Rougon
# SPDX-License-Identifier: GPL-2.0-or-later
# SPDX-FileComment: Initialization of the 'flightgear.meta.scripts.i18n' package

"""Scripts used to help make FlightGear available in various languages."""
