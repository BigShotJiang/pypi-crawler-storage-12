# SPDX-FileCopyrightText: 2025 Florent Rougon
# SPDX-License-Identifier: GPL-2.0-or-later

"""Automated tests for code in flightgear.meta.scripts.i18n."""
