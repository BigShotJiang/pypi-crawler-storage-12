"""Automated tests for the flightgear.meta package."""
