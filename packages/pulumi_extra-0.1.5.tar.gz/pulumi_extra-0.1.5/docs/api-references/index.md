::: pulumi_extra.resource_
    options:
        show_root_heading: true

::: pulumi_extra.stack_reference
    options:
        show_root_heading: true

::: pulumi_extra.output
    options:
        show_root_heading: true

::: pulumi_extra.transforms
    options:
        show_root_heading: true
