# pulumi-extra

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![codecov](https://codecov.io/gh/lasuillard-s/pulumi-extra/graph/badge.svg?token=uuckU93NAu)](https://codecov.io/gh/lasuillard-s/pulumi-extra)
[![PyPI - Version](https://img.shields.io/pypi/v/pulumi-extra)](https://pypi.org/project/pulumi-extra/)

Extra Pulumi utils and resources.
