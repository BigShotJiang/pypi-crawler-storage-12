from .require_description import require_description
from .require_labels import require_labels

__all__ = ("require_description", "require_labels")
