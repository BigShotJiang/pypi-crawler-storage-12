# noqa: D100
class UnknownResourceTypeError(Exception):
    """Raised when an unknown resource type is encountered."""
