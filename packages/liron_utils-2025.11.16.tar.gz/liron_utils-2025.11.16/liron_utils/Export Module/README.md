# Export `liron-utils` as a standalone Python module

`setup.py` file must be located at the same parent directory as `liron-utils` (not inside it).\
Run:

```bash
python -m build
```
