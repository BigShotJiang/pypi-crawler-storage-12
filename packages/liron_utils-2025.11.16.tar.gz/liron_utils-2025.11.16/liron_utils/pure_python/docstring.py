import matplotlib.pyplot as plt

copy_docstring_and_deprecators = plt._copy_docstring_and_deprecators  # pylint: disable=protected-access
