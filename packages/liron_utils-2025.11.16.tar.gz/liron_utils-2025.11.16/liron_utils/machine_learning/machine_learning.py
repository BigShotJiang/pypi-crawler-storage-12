import sklearn
import sklearn.mixture

gmm = sklearn.mixture.GaussianMixture
svm = sklearn.svm
lr = sklearn.linear_model.LinearRegression
