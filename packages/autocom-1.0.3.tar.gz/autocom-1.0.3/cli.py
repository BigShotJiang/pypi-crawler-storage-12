"""AutoCom CLI 入口"""

from AutoCom import run_main

def main():
    """CLI 入口函数"""
    run_main()

if __name__ == "__main__":
    main()
