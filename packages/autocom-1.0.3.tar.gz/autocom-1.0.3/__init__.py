"""AutoCom - 自动化串口命令测试工具"""

from .version import __version__

__all__ = ['__version__']
