from mhlabs_mcp_tools.nlp_components.nlp_model import register_nlp_tools

__all__ = ["register_nlp_tools"]