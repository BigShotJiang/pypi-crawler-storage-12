class IllegalOperationError(Exception):
    """
    Raised if performing an illegal operation with
    the ``devilry.devilry_account`` models.
    """
    pass
