# from django.test import TestCase
#
#
# class TestCrAdminInstance(TestCase):
