class AbstractIsAdmin(object):
    """
    Deprecated class - needs to clear migrations before this can be removed.
    """
