"""Qwen VL examples for vision-language model experiments with Crafter."""

