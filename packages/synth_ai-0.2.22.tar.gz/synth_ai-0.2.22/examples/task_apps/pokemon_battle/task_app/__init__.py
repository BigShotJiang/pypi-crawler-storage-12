"""Pokemon Showdown task app configuration."""

from .pokemon_showdown import build_config

__all__ = ["build_config"]

