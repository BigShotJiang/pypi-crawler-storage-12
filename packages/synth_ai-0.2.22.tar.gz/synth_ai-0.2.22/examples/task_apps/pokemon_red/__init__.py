"""Pokémon Red task app example package."""


