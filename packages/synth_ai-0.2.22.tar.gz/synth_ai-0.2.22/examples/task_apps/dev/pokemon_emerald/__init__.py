"""Pokémon Emerald speedrun task app examples."""

