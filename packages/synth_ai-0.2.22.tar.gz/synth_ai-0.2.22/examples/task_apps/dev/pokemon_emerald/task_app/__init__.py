"""Pokemon Emerald task app configuration."""

from .pokemon_emerald import build_config

__all__ = ["build_config"]

