"""Banking77 task app package."""

from .banking77_task_app import build_config

__all__ = ["build_config"]

