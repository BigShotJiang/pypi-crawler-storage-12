"""Banking77 two-step pipeline task app."""

from .banking77_pipeline_task_app import build_config

__all__ = ["build_config"]

