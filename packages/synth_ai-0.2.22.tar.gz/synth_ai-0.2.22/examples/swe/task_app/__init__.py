"""Task app configuration for the mini-SWE integration."""

