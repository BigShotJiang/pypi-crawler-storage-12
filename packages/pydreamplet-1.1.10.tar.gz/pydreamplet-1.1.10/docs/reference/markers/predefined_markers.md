---
icon: material/shape
---

# Predefined Markers

### `ARROW`

  ![Example](assets/ARROW.svg){width="32"}

### `ARROW_BASIC`

  ![Example](assets/ARROW_BASIC.svg){width="32"}

### `ARROW_CONCAVE`

  ![Example](assets/ARROW_CONCAVE.svg){width="32"}


### `ARROW_CONVEX`

  ![Example](assets/ARROW_CONVEX.svg){width="32"}

### `ARROW_SIMPLE`

  ![Example](assets/ARROW_SIMPLE.svg){width="32"}

### `CROSS`

  ![Example](assets/CROSS.svg){width="32"}

### `DIAMOND`

  ![Example](assets/DIAMOND.svg){width="32"}

### `DOT`

  ![Example](assets/DOT.svg){width="32"}

### `SQUARE`

  ![Example](assets/SQUARE.svg){width="32"}

### `TICK_TOP`

  ![Example](assets/TICK_TOP.svg){width="32"}

### `TICK_BOTTOM`

  ![Example](assets/TICK_BOTTOM.svg){width="32"}

### `TICK_LEFT`

  ![Example](assets/TICK_LEFT.svg){width="32"}

### `TICK_RIGHT`

  ![Example](assets/TICK_RIGHT.svg){width="32"}

### `TICK_HORIZONTAL`

  ![Example](assets/TICK_HORIZONTAL.svg){width="32"}

### `TICK_VERTICAL`

  ![Example](assets/TICK_VERTICAL.svg){width="32"}
