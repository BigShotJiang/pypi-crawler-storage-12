# PyRelukko

[![PyPI - Version](https://img.shields.io/pypi/v/pyrelukko.svg)](https://pypi.org/project/pyrelukko)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyrelukko.svg)](https://pypi.org/project/pyrelukko)
![Python Version from PEP 621 TOML](https://img.shields.io/python/required-version-toml?tomlFilePath=https%3A%2F%2Fgitlab.com%2Frelukko%2Fpyrelukko%2F-%2Fraw%2Fmaster%2Fpyproject.toml%3Fref_type%3Dheads)
![Gitlab Pipeline Status](https://img.shields.io/gitlab/pipeline-status/relukko%2Fpyrelukko?branch=master)
![PyPI - Downloads](https://img.shields.io/pypi/dm/pyrelukko)
![PyPI - License](https://img.shields.io/pypi/l/pyrelukko)
![GitLab License](https://img.shields.io/gitlab/license/relukko%2Fpyrelukko)
![PyPI - Format](https://img.shields.io/pypi/format/pyrelukko)
![PyPI - Status](https://img.shields.io/pypi/status/pyrelukko)
![PyPI - Implementation](https://img.shields.io/pypi/implementation/pyrelukko)
![PyPI - Wheel](https://img.shields.io/pypi/wheel/pyrelukko)
![GitLab Stars](https://img.shields.io/gitlab/stars/relukko%2Fpyrelukko)
![GitLab Forks](https://img.shields.io/gitlab/forks/relukko%2Fpyrelukko)
-----

Python library to access a
[Relukko back-end](https://gitlab.com/relukko/relukko).
