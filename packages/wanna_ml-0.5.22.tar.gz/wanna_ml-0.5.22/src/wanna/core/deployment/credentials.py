from wanna.core.utils.credentials import get_credentials


class GCPCredentialsMixIn:
    credentials = get_credentials()
