# Quick Start: Publishing Synqed

## ✅ Package is Built and Ready!

Your Synqed v1.0.0 package has been successfully built and is ready to publish.

## 📦 What Was Built

- `synqed-1.0.0-py3-none-any.whl` - Wheel distribution
- `synqed-1.0.0.tar.gz` - Source distribution

Both are in the `dist/` directory.

## 🚀 Publishing Steps

### Step 1: Install Publishing Tools

```bash
pip install --upgrade build twine
```

### Step 2: Create PyPI Account

1. **Test PyPI** (recommended first): https://test.pypi.org/account/register/
2. **Production PyPI**: https://pypi.org/account/register/

### Step 3: Set Up Environment Variables

1. **Generate API Tokens**:
   - Test PyPI: https://test.pypi.org/manage/account/token/
   - Production PyPI: https://pypi.org/manage/account/token/

2. **Create .env file** (copy from .env.example):
```bash
cp .env.example .env
```

3. **Add your tokens to .env**:
```bash
# Edit .env file
TWINE_PASSWORD=your-production-pypi-token-here
TWINE_TEST_PASSWORD=your-test-pypi-token-here
TWINE_USERNAME=__token__
```

The .env file is in .gitignore so your tokens stay secure!

### Step 4: Test on Test PyPI (Recommended)

**Using the automated script (recommended):**
```bash
./scripts/publish.sh --test
```

**Or manually:**
```bash
# Token is read from .env file automatically
twine upload --repository testpypi dist/* --username __token__ --password $TWINE_TEST_PASSWORD

# Test installation
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple synqed

# Verify it works
python -c "import synqed; print(synqed.__version__)"
```

### Step 5: Publish to Production PyPI

**Using the automated script (recommended):**
```bash
./scripts/publish.sh --prod
```

**Or manually:**
```bash
# Token is read from .env file automatically
twine upload dist/* --username __token__ --password $TWINE_PASSWORD

# Verify on PyPI
# Visit: https://pypi.org/project/synqed/

# Test installation
pip install synqed
```

## 🛠️ Using the Automated Scripts

We've created helper scripts for you:

### Quick Build
```bash
./scripts/build_package.sh
```

### Publish to Test PyPI
```bash
./scripts/publish.sh --test
```

### Publish to Production PyPI
```bash
./scripts/publish.sh --prod
```

## 📋 Pre-Publishing Checklist

- [x] Package builds successfully
- [x] Tests pass (you may need to run: `pytest tests/`)
- [x] Documentation is complete
- [x] LICENSE file present
- [x] README.md is comprehensive
- [x] CHANGELOG.md updated
- [x] Version number set correctly (1.0.0)
- [ ] PyPI accounts created
- [ ] API tokens generated

## 🔒 Security Tips

1. **Never commit API tokens** to git
2. Add `.pypirc` to `.gitignore` (already done ✓)
3. Use separate tokens for test and production
4. Store tokens in environment variables or password manager

## 📝 After Publishing

1. **Tag the release**:
```bash
git tag -a v1.0.0 -m "Release version 1.0.0"
git push origin v1.0.0
```

2. **Update documentation** with installation instructions

3. **Test the published package**:
```bash
pip install synqed
python -c "import synqed; print('Synqed installed successfully!')"
```

## 🆘 Troubleshooting

### "File already exists" error
- You cannot re-upload the same version
- Increment version in `pyproject.toml`
- Rebuild: `./scripts/build_package.sh`
- Upload again

### Authentication errors
- Double-check your API token
- Make sure username is `__token__` (with underscores)
- Verify token hasn't expired

### Import errors after install
- Make sure all dependencies are correctly specified
- Test in a clean virtual environment

## 📚 Full Documentation

For complete details, see `PUBLISHING.md`

## 🎉 Ready to Go!

Your package is ready! Just follow the steps above to publish to PyPI.

Good luck! 🚀

