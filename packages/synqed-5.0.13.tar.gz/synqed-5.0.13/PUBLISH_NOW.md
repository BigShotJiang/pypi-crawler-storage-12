# 🚀 Publish Synqed Now - Quick Guide

Your package is ready! Follow these steps to publish.

## ✅ Pre-Flight Check

- [x] Package built successfully
- [x] All files validated
- [x] Scripts are executable
- [x] .env file is set up

## 📝 Step-by-Step Instructions

### 1. Set Up Your .env File

```bash
# Copy the example
cp .env.example .env

# Edit .env and add your PyPI token
# Get token from: https://pypi.org/manage/account/token/
```

Your `.env` should look like:
```
TWINE_PASSWORD=pypi-AgEIcHlwaS5vcmcC...your-token...
TWINE_USERNAME=__token__
```

### 2. Test on Test PyPI First (Recommended)

```bash
./scripts/publish.sh --test
```

This will:
- Load your token from `.env`
- Upload to Test PyPI
- Show you the URL to verify

Test the installation:
```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple synqed
python -c "import synqed; print(synqed.__version__)"
```

### 3. Publish to Production PyPI

Once you've verified everything works on Test PyPI:

```bash
./scripts/publish.sh --prod
```

You'll be asked to confirm (type `yes`), then it will:
- Load your token from `.env`
- Upload to PyPI
- Show you the URL

### 4. Verify It Worked

```bash
# Install from PyPI
pip install synqed

# Test it
python -c "import synqed; print('Synqed v' + synqed.__version__ + ' installed!')"
```

Visit: https://pypi.org/project/synqed/

## 🔧 Manual Publishing (Alternative)

If you prefer to do it manually:

```bash
# Load environment variables
source .env

# Upload to Test PyPI
twine upload --repository testpypi dist/* --username __token__ --password $TWINE_TEST_PASSWORD

# Or upload to Production PyPI
twine upload dist/* --username __token__ --password $TWINE_PASSWORD
```

## 🆘 Troubleshooting

### "TWINE_PASSWORD not set" error

Make sure your `.env` file exists and contains:
```
TWINE_PASSWORD=your-token-here
```

### "Invalid credentials" error

- Double-check your token is correct
- Make sure there are no extra spaces
- Verify the token hasn't been revoked

### "File already exists" error

- You cannot re-upload version 1.0.0
- Update version in `pyproject.toml` to 1.0.1
- Rebuild: `./scripts/build_package.sh`
- Try again

### Permission denied on scripts

```bash
chmod +x scripts/*.sh
```

## 📊 What Happens Next

1. Package appears on PyPI within minutes
2. Anyone can install with: `pip install synqed`
3. Documentation at: https://pypi.org/project/synqed/

## 🎯 All Set!

Your `.env` file is configured, so publishing is as simple as:

```bash
# Test first
./scripts/publish.sh --test

# Then production
./scripts/publish.sh --prod
```

That's it! 🎉

