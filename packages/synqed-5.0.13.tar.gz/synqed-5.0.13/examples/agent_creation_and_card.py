import asyncio
import synqed

async def agent_logic(context):
    user_message = context.get_user_input()
    return f"Your task has been received. Task: '{user_message}'"

async def main():

    # Create agent
    agent = synqed.Agent(
        name="Customer Support Assistant",
        description="Automated support agent that handles customer inquiries and service requests efficiently",
        skills=["customer_support", "ticket_routing", "inquiry_handling"],
        executor = agent_logic
    )

    # See agent card. Running on http://localhost:8000/
    # print(agent.card) 

    # Create server
    server = synqed.AgentServer(agent, port=8000)
    print(f"Server binding to {server.url}")  # Binds to all interfaces: http://0.0.0.0:8000
    print(f"Client URL: {agent.url}")  # Client connects to: http://localhost:8000
    print(f"Agent running at {agent.url}")  # http://localhost:8000
    await server.start()

if __name__ == "__main__":
    asyncio.run(main())
