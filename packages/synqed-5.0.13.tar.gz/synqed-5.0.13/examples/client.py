import asyncio
import synqed

async def main():

    # Specify the client url
    async with synqed.Client("http://localhost:8000") as client:

        # Test 1: Complete response (`ask`)
            # Waits for the agent to finish processing and returns the complete response as a single string.
        response = await client.ask("Add a support ticket.")
        print(f"Response: {response}")
        
        # Test 2: Streaming response (`stream`)
            # Yields response chunks in real-time as the agent generates them, allowing you to display or process the response progressively.
        print("\nStreaming response:")
        async for chunk in client.stream("Where are your customers based in?"):
            print(chunk, end="", flush=True)
        print()

if __name__ == "__main__":
    asyncio.run(main())