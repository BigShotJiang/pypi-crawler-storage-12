TODO:

- better server shutdown handling. especially if using ctr+C

ex. 
```
Agent running at http://0.0.0.0:8000
INFO:     Started server process [16183]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
INFO:     127.0.0.1:58345 - "GET / HTTP/1.1" 200 OK
INFO:     127.0.0.1:58345 - "GET /favicon.ico HTTP/1.1" 204 No Content
INFO:     127.0.0.1:58359 - "GET / HTTP/1.1" 200 OK
INFO:     127.0.0.1:58364 - "GET / HTTP/1.1" 200 OK
INFO:     127.0.0.1:58364 - "GET /favicon.ico HTTP/1.1" 204 No Content
^CINFO:     Shutting down
INFO:     Waiting for application shutdown.
INFO:     Application shutdown complete.
INFO:     Finished server process [16183]
Traceback (most recent call last):
  File "/opt/anaconda3/envs/synq_3/lib/python3.14/asyncio/runners.py", line 127, in run
    return self._loop.run_until_complete(task)
           ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^
  File "/opt/anaconda3/envs/synq_3/lib/python3.14/asyncio/base_events.py", line 719, in run_until_complete
    return future.result()
           ~~~~~~~~~~~~~^^
asyncio.exceptions.CancelledError

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/Users/dorsa/Desktop/PROJECTS/synq_2/Synq/examples/agent_creation_and_card.py", line 26, in <module>
    if __name__ == "__main__":
        ^^^^^^^^^^^^^^^^^^^
  File "/opt/anaconda3/envs/synq_3/lib/python3.14/asyncio/runners.py", line 204, in run
    return runner.run(main)
           ~~~~~~~~~~^^^^^^
  File "/opt/anaconda3/envs/synq_3/lib/python3.14/asyncio/runners.py", line 132, in run
    raise KeyboardInterrupt()
KeyboardInterrupt
```