class ConfigError(Exception):
    """Config error."""

    pass


class IndexerError(Exception):
    """Indexer error."""

    pass
