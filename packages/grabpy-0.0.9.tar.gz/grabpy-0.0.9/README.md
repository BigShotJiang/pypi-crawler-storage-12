# Grabpy

Simple respectful web scraper

## LOGGING

How to enable logging for this package.

```python
import logging

logging.basicConfig(level=logging.DEBUG)
logging.getLogger('grabpy').setLevel(logging.DEBUG)
logging.getLogger().setLevel(logging.WARNING)
```
