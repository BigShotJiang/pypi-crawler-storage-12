from pycodb.entities.database import DataBase
from pycodb.entities.basetable import BaseTable