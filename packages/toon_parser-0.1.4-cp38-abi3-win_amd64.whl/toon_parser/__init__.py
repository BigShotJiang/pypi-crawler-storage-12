from .toon_parser import *

__doc__ = toon_parser.__doc__
if hasattr(toon_parser, "__all__"):
    __all__ = toon_parser.__all__