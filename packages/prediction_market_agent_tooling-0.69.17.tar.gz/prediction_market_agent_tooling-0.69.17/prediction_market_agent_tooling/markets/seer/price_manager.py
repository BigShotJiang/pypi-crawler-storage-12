from cachetools import TTLCache, cached
from pydantic import BaseModel
from web3 import Web3

from prediction_market_agent_tooling.deploy.constants import is_invalid_outcome
from prediction_market_agent_tooling.gtypes import (
    ChecksumAddress,
    CollateralToken,
    HexAddress,
    OutcomeStr,
    OutcomeToken,
    Probability,
    Wei,
)
from prediction_market_agent_tooling.loggers import logger
from prediction_market_agent_tooling.markets.seer.data_models import SeerMarket
from prediction_market_agent_tooling.markets.seer.exceptions import (
    PriceCalculationError,
)
from prediction_market_agent_tooling.markets.seer.seer_contracts import (
    QuoteExactInputSingleParams,
    SwaprQuoterContract,
)
from prediction_market_agent_tooling.markets.seer.seer_subgraph_handler import (
    SeerSubgraphHandler,
)
from prediction_market_agent_tooling.tools.cow.cow_order import (
    get_buy_token_amount_else_raise,
)
from prediction_market_agent_tooling.tools.hexbytes_custom import HexBytes


class Prices(BaseModel):
    priceOfCollateralInAskingToken: CollateralToken
    priceOfAskingTokenInCollateral: CollateralToken


class PriceManager:
    def __init__(self, seer_market: SeerMarket, seer_subgraph: SeerSubgraphHandler):
        self.seer_market = seer_market
        self.seer_subgraph = seer_subgraph

    @staticmethod
    def build(market_id: HexBytes) -> "PriceManager":
        s = SeerSubgraphHandler()
        market = s.get_market_by_id(market_id=market_id)
        return PriceManager(seer_market=market, seer_subgraph=s)

    def _log_track_price_normalization_diff(
        self, old_price: float, normalized_price: float, max_price_diff: float = 0.05
    ) -> None:
        # We add max(price,0.01) to avoid division by 0
        price_diff_pct = abs(old_price - normalized_price) / max(old_price, 0.01)
        if price_diff_pct > max_price_diff:
            logger.info(
                f"{price_diff_pct=} larger than {max_price_diff=} for seer market {self.seer_market.id.to_0x_hex()} "
            )

    def get_price_for_token(self, token: ChecksumAddress) -> CollateralToken | None:
        return self.get_amount_of_token_in_collateral(token, OutcomeToken(1))

    @cached(TTLCache(maxsize=100, ttl=5 * 60))
    def get_amount_of_collateral_in_token(
        self,
        token: ChecksumAddress,
        collateral_exchange_amount: CollateralToken,
    ) -> OutcomeToken | None:
        if token == self.seer_market.collateral_token_contract_address_checksummed:
            return OutcomeToken(collateral_exchange_amount.value)

        try:
            buy_token_amount = get_buy_token_amount_else_raise(
                sell_amount=collateral_exchange_amount.as_wei,
                sell_token=self.seer_market.collateral_token_contract_address_checksummed,
                buy_token=token,
            )
            return OutcomeToken.from_token(buy_token_amount.as_token)

        except Exception as e:
            logger.warning(
                f"Could not get quote for {token=} from Cow, exception {e=}. Falling back to pools. "
            )
            quote = self.get_swapr_input_quote(
                input_token=self.seer_market.collateral_token_contract_address_checksummed,
                output_token=token,
                input_amount=collateral_exchange_amount.as_wei,
            )
            return OutcomeToken.from_token(quote.as_token)

    @cached(TTLCache(maxsize=100, ttl=5 * 60))
    def get_amount_of_token_in_collateral(
        self,
        token: ChecksumAddress,
        token_exchange_amount: OutcomeToken,
    ) -> CollateralToken | None:
        if token == self.seer_market.collateral_token_contract_address_checksummed:
            return token_exchange_amount.as_token

        try:
            buy_collateral_amount = get_buy_token_amount_else_raise(
                sell_amount=token_exchange_amount.as_outcome_wei.as_wei,
                sell_token=token,
                buy_token=self.seer_market.collateral_token_contract_address_checksummed,
            )
            return buy_collateral_amount.as_token

        except Exception as e:
            logger.warning(
                f"Could not get quote for {token=} from Cow, exception {e=}. Falling back to pools. "
            )
            quote = self.get_swapr_input_quote(
                input_token=token,
                output_token=self.seer_market.collateral_token_contract_address_checksummed,
                input_amount=token_exchange_amount.as_outcome_wei.as_wei,
            )
            return quote.as_token

    def get_token_price_from_pools(
        self,
        token: ChecksumAddress,
    ) -> Prices | None:
        """
        Although this might come handy,
        consider using `get_amount_of_collateral_in_token` or `get_amount_of_token_in_collateral` to have an exact quote.
        """
        pool = SeerSubgraphHandler().get_pool_by_token(
            token_address=token,
            collateral_address=self.seer_market.collateral_token_contract_address_checksummed,
        )

        if not pool:
            logger.warning(f"Could not find a pool for {token=}")
            return None

        if (
            Web3.to_checksum_address(pool.token0.id)
            == self.seer_market.collateral_token_contract_address_checksummed
        ):
            price_coll_in_asking = (
                pool.token1Price
            )  # how many outcome tokens per 1 collateral
            price_asking_in_coll = (
                pool.token0Price
            )  # how many collateral tokens per 1 outcome
        else:
            price_coll_in_asking = pool.token0Price
            price_asking_in_coll = pool.token1Price

        return Prices(
            priceOfCollateralInAskingToken=price_coll_in_asking,
            priceOfAskingTokenInCollateral=price_asking_in_coll,
        )

    def build_probability_map(self) -> dict[OutcomeStr, Probability]:
        # Inspired by https://github.com/seer-pm/demo/blob/ca682153a6b4d4dd3dcc4ad8bdcbe32202fc8fe7/web/src/hooks/useMarketOdds.ts#L15
        price_data: dict[HexAddress, CollateralToken] = {}

        for idx, wrapped_token in enumerate(self.seer_market.wrapped_tokens):
            price = self.get_price_for_token(
                token=Web3.to_checksum_address(wrapped_token),
            )
            # It's okay if invalid (last) outcome has price 0, but not the other outcomes.
            if price is None and idx != len(self.seer_market.wrapped_tokens) - 1:
                raise PriceCalculationError(
                    f"Couldn't get price for {wrapped_token} for market {self.seer_market.url}."
                )
            price_data[wrapped_token] = (
                price if price is not None else CollateralToken.zero()
            )

        # We normalize the prices to sum up to 1.
        normalized_prices = {}

        if not price_data or (
            sum(price_data.values(), start=CollateralToken.zero())
            == CollateralToken.zero()
        ):
            raise PriceCalculationError(
                f"All prices for market {self.seer_market.url} are zero. This shouldn't happen."
            )

        for outcome_token, price in price_data.items():
            old_price = price
            new_price = Probability(
                price / (sum(price_data.values(), start=CollateralToken.zero()))
            )
            self._log_track_price_normalization_diff(
                old_price=old_price.value, normalized_price=new_price
            )
            outcome = self.seer_market.outcomes[
                self.seer_market.wrapped_tokens.index(outcome_token)
            ]
            normalized_prices[outcome] = new_price

        return normalized_prices

    def build_initial_probs_from_pool(
        self, model: SeerMarket, wrapped_tokens: list[ChecksumAddress]
    ) -> tuple[dict[OutcomeStr, Probability], dict[OutcomeStr, OutcomeToken]]:
        """
        Builds a map of outcome to probability and outcome token pool.
        """
        probability_map = {}
        outcome_token_pool = {}
        wrapped_tokens_with_supply = [
            (
                token,
                SeerSubgraphHandler().get_pool_by_token(
                    token, model.collateral_token_contract_address_checksummed
                ),
            )
            for token in wrapped_tokens
        ]
        wrapped_tokens_with_supply = [
            (token, pool)
            for token, pool in wrapped_tokens_with_supply
            if pool is not None
        ]

        for token, pool in wrapped_tokens_with_supply:
            if pool is None or pool.token1.id is None or pool.token0.id is None:
                continue
            if HexBytes(token) == HexBytes(pool.token1.id):
                outcome_token_pool[
                    OutcomeStr(model.outcomes[wrapped_tokens.index(token)])
                ] = (
                    OutcomeToken(pool.totalValueLockedToken0)
                    if pool.totalValueLockedToken0 is not None
                    else OutcomeToken(0)
                )
                probability_map[
                    OutcomeStr(model.outcomes[wrapped_tokens.index(token)])
                ] = Probability(pool.token0Price.value)
            else:
                outcome_token_pool[
                    OutcomeStr(model.outcomes[wrapped_tokens.index(token)])
                ] = (
                    OutcomeToken(pool.totalValueLockedToken1)
                    if pool.totalValueLockedToken1 is not None
                    else OutcomeToken(0)
                )
                probability_map[
                    OutcomeStr(model.outcomes[wrapped_tokens.index(token)])
                ] = Probability(pool.token1Price.value)

        for outcome in model.outcomes:
            if outcome not in outcome_token_pool:
                outcome_token_pool[outcome] = OutcomeToken(0)
                logger.warning(
                    f"Outcome {outcome} not found in outcome_token_pool for market {self.seer_market.url}."
                )
            if outcome not in probability_map:
                if not is_invalid_outcome(outcome):
                    raise PriceCalculationError(
                        f"Couldn't get probability for {outcome} for market {self.seer_market.url}."
                    )
                else:
                    probability_map[outcome] = Probability(0)
        return probability_map, outcome_token_pool

    def get_swapr_input_quote(
        self,
        input_token: ChecksumAddress,
        output_token: ChecksumAddress,
        input_amount: Wei,
        web3: Web3 | None = None,
    ) -> Wei:  # Not marked as OutcomeWei, but this works for both buying and selling.
        quoter = SwaprQuoterContract()
        amount_out, _ = quoter.quote_exact_input_single(
            QuoteExactInputSingleParams(
                token_in=input_token,
                token_out=output_token,
                amount_in=input_amount,
            ),
            web3=web3,
        )
        return amount_out
