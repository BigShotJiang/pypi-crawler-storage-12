__version__ = '2.0.0'

from puid.chars import Chars
from puid.puid import Puid
