# chromy

一个处理以 Chromium 为核心的浏览器用户数据的 Python 库
