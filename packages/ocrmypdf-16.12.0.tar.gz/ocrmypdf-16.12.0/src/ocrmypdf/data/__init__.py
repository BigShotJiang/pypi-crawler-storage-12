# SPDX-FileCopyrightText: 2022 James R. Barlow
# SPDX-License-Identifier: MPL-2.0
"""Data files used to generate certain PDFs."""

from __future__ import annotations
