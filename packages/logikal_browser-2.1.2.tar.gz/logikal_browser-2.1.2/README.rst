logikal-browser
===============
Common browser automation utilities.

Getting Started
---------------
You can find the project documentation under `docs.logikal.io/logikal-browser/
<https://docs.logikal.io/logikal-browser/>`_.
