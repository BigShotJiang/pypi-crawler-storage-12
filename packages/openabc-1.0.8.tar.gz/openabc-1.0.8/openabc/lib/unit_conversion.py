import numpy as np

_kcal_to_kj = 4.184
_angstrom_to_nm = 0.1
_deg_to_rad = np.pi/180


