# DNA residue names are DA, DC, DG, and DT. 
_dna_nucleotides = ['DA', 'DC', 'DG', 'DT']
_dna_WC_pair_dict = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C'}


