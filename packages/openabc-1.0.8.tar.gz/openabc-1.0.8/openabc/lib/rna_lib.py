# RNA residue names are A, C, G, and U. 
_rna_nucleotides = ['A', 'C', 'G', 'U']


