"""Shared default values for Optilogic Datastar library models."""

DEFAULT_DESCRIPTION = "Created by the Optilogic Datastar library"

# Special task names
START_TASK_NAME = "Start"
