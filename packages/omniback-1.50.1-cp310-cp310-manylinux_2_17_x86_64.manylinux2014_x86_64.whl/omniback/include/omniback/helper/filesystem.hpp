#pragma once

#include <string>
namespace omniback::filesystem {
bool exists(const std::string& path);
}