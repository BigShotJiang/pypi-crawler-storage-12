"""
Setup.py - 向后兼容文件
推荐使用 pyproject.toml，但保留此文件以支持旧版本的 pip
"""
from setuptools import setup

# 配置已经在 pyproject.toml 中定义
# 这个文件主要用于向后兼容
setup()

