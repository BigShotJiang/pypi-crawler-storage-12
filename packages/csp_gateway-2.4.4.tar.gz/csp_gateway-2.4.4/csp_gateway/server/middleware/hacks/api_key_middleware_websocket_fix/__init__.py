# https://github.com/tiangolo/fastapi/pull/10147
