# Picteus extension Python SDK

This package provides the Picteus extension Python SDK, which allows you to interact with the Picteus API and to augment the features of the application by developing an extension.
