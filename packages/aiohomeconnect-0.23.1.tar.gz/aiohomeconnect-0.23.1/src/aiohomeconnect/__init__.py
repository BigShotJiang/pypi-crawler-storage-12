"""Asynchronous Python client for Home Connect API."""

__version__ = "0.23.1"
