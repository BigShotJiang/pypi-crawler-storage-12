from zrb.task.base_task import BaseTask


class Task(BaseTask):
    pass
