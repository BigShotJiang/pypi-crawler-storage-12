# AutoPublisherFacebook SDK

Este SDK permite la automatización de publicaciones en grupos de Facebook utilizando Playwright. Está diseñado para ser integrado en entornos SaaS, ofreciendo funcionalidades como persistencia de sesión, uso de proxies y modo headless, detección de errores y confirmación de publicaciones.

## Características

- **Persistencia de Sesión**: Mantiene las sesiones de Facebook activas para evitar inicios de sesión repetitivos.
- **Soporte de Proxy/Headless**: Permite la ejecución con proxies y en modo headless para mayor flexibilidad y rendimiento.
- **Manejo de Errores**: Incluye mecanismos para detectar y manejar errores durante el proceso de publicación.
- **Confirmación de Publicaciones**: Verifica la correcta publicación del contenido en los grupos de Facebook.
- **Docstrings Google-style**: Documentación clara y concisa para facilitar el desarrollo y mantenimiento.

## Instalación

```bash
pip install autopublisher-facebook-sdk
```

## Uso

```python
from facebook_sdk import FacebookClient

# Ejemplo de uso (se requiere configuración adicional para credenciales y proxies)
client = FacebookClient(headless=True)
client.login("tu_usuario", "tu_contraseña")
client.publish_to_group("id_del_grupo", "Tu mensaje de publicación")
client.close()
```

## Contribución

Si deseas contribuir a este proyecto, por favor, sigue las directrices de contribución.

## Licencia

Este proyecto es propietario y no está disponible para distribución pública sin permiso.