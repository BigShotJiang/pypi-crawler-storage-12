"""Book Data Maker - CLI tool for text extraction and dataset generation."""

__version__ = "0.1.0"
