"""
Query Analyzer for Execution Routing

This module analyzes compiled SQL queries to determine the optimal execution strategy:
- Pushdown: All sources from same connection → execute on source database
- Federated: Sources from multiple connections → use compute layer

The analyzer respects user configuration overrides while providing intelligent defaults.
"""

import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Set
from dbt.contracts.graph.manifest import Manifest
from dbt.contracts.graph.nodes import ManifestNode, SourceDefinition
from dbt_common.exceptions import DbtRuntimeError


@dataclass
class QueryAnalysisResult:
    """
    Result of query analysis.

    Contains information about source connections and recommended execution strategy.
    """

    # Set of connection names used by this query
    source_connections: Set[str]

    # Set of source unique_ids referenced
    source_refs: Set[str]

    # Recommended execution strategy
    strategy: str  # "pushdown" or "federated"

    # Primary connection (for pushdown) or None (for federated)
    primary_connection: Optional[str]

    # Reason for the chosen strategy
    reason: str

    # User override applied (if any)
    user_override: Optional[str] = None

    @property
    def is_pushdown(self) -> bool:
        """Check if pushdown strategy is recommended."""
        return self.strategy == "pushdown"

    @property
    def is_federated(self) -> bool:
        """Check if federated strategy is recommended."""
        return self.strategy == "federated"

    @property
    def is_homogeneous(self) -> bool:
        """Check if all sources are from the same connection."""
        return len(self.source_connections) <= 1


class QueryAnalyzer:
    """
    Analyzes compiled SQL queries to determine execution strategy.

    The analyzer:
    1. Identifies all source() and ref() references in the query
    2. Determines which connections are involved
    3. Recommends pushdown (homogeneous) or federated (heterogeneous) execution
    4. Respects user configuration overrides
    """

    def __init__(self, manifest: Manifest):
        """
        Initialize query analyzer.

        :param manifest: The parsed dbt manifest with all nodes and sources
        """
        self.manifest = manifest
        # Cache for source connection mappings
        self._source_connection_cache: Dict[str, str] = {}

    def analyze(
        self,
        node: ManifestNode,
        user_compute_override: Optional[str] = None
    ) -> QueryAnalysisResult:
        """
        Analyze a compiled node to determine execution strategy.

        :param node: The compiled ManifestNode to analyze
        :param user_compute_override: User's compute config (if specified)
        :returns: QueryAnalysisResult with execution strategy
        """
        # Extract source and ref dependencies
        source_refs = self._extract_source_references(node)

        # Map sources to their connections
        source_connections = self._map_sources_to_connections(source_refs)

        # Determine strategy
        if user_compute_override:
            # User explicitly specified compute engine
            strategy = "federated"
            reason = f"User specified compute engine: {user_compute_override}"
            primary_connection = None
            user_override = user_compute_override

        elif len(source_connections) == 0:
            # No sources (e.g., seed, snapshot, or ephemeral model)
            # Use default connection for execution
            strategy = "pushdown"
            reason = "No source dependencies - using default connection"
            primary_connection = None  # Will use default from profile
            user_override = None

        elif len(source_connections) == 1:
            # Homogeneous - all sources from same connection
            strategy = "pushdown"
            primary_connection = list(source_connections)[0]
            reason = f"All sources from connection '{primary_connection}' - pushdown eligible"
            user_override = None

        else:
            # Heterogeneous - sources from multiple connections
            strategy = "federated"
            reason = f"Sources span {len(source_connections)} connections: {sorted(source_connections)} - requires compute layer"
            primary_connection = None
            user_override = None

        return QueryAnalysisResult(
            source_connections=source_connections,
            source_refs=source_refs,
            strategy=strategy,
            primary_connection=primary_connection,
            reason=reason,
            user_override=user_override
        )

    def _extract_source_references(self, node: ManifestNode) -> Set[str]:
        """
        Extract all source unique_ids referenced by this node.

        This includes both direct source() references and ref() to models
        that depend on sources.

        :param node: The node to analyze
        :returns: Set of source unique_ids
        """
        source_refs = set()

        # Direct source dependencies
        if hasattr(node, 'sources') and node.sources:
            source_refs.update(node.sources)

        # Recursively trace ref() dependencies to find underlying sources
        if hasattr(node, 'depends_on') and node.depends_on:
            for dep_id in node.depends_on.nodes:
                sources = self._trace_node_to_sources(dep_id)
                source_refs.update(sources)

        return source_refs

    def _trace_node_to_sources(self, node_id: str, visited: Optional[Set[str]] = None) -> Set[str]:
        """
        Recursively trace a node's dependencies to find all underlying sources.

        :param node_id: Unique ID of the node to trace
        :param visited: Set of already-visited nodes (for cycle detection)
        :returns: Set of source unique_ids
        """
        if visited is None:
            visited = set()

        if node_id in visited:
            return set()

        visited.add(node_id)
        sources = set()

        # Check if this is a source
        if node_id.startswith('source.'):
            sources.add(node_id)
            return sources

        # Get the node from manifest
        node = self.manifest.nodes.get(node_id)
        if not node:
            # Node not found (could be disabled or external)
            return sources

        # Add direct source dependencies
        if hasattr(node, 'sources') and node.sources:
            sources.update(node.sources)

        # Recursively trace node dependencies
        if hasattr(node, 'depends_on') and node.depends_on:
            for dep_id in node.depends_on.nodes:
                dep_sources = self._trace_node_to_sources(dep_id, visited)
                sources.update(dep_sources)

        return sources

    def _map_sources_to_connections(self, source_refs: Set[str]) -> Set[str]:
        """
        Map source unique_ids to their connection names.

        :param source_refs: Set of source unique_ids
        :returns: Set of connection names
        """
        connections = set()

        for source_id in source_refs:
            connection = self._get_source_connection(source_id)
            if connection:
                connections.add(connection)

        return connections

    def _get_source_connection(self, source_id: str) -> Optional[str]:
        """
        Get the connection name for a source.

        Uses caching for performance.

        :param source_id: Source unique_id
        :returns: Connection name or None if not specified
        """
        # Check cache
        if source_id in self._source_connection_cache:
            return self._source_connection_cache[source_id]

        # Look up source in manifest
        source = self.manifest.sources.get(source_id)
        if not source:
            return None

        # Get connection (may be None for legacy sources)
        connection = source.connection if hasattr(source, 'connection') else None

        # Cache and return
        self._source_connection_cache[source_id] = connection
        return connection

    def get_execution_summary(self, node: ManifestNode) -> str:
        """
        Get a human-readable summary of the execution strategy for a node.

        Useful for logging and debugging.

        :param node: The node to analyze
        :returns: Summary string
        """
        result = self.analyze(node)

        summary_parts = [
            f"Node: {node.unique_id}",
            f"Strategy: {result.strategy.upper()}",
            f"Reason: {result.reason}",
            f"Source Connections: {sorted(result.source_connections) if result.source_connections else 'None'}",
            f"Source Count: {len(result.source_refs)}",
        ]

        if result.primary_connection:
            summary_parts.append(f"Execution Connection: {result.primary_connection}")

        if result.user_override:
            summary_parts.append(f"User Override: {result.user_override}")

        return "\n".join(summary_parts)

    def analyze_batch(
        self,
        nodes: List[ManifestNode]
    ) -> Dict[str, QueryAnalysisResult]:
        """
        Analyze multiple nodes in batch.

        More efficient than analyzing one at a time due to caching.

        :param nodes: List of nodes to analyze
        :returns: Dict mapping node unique_id to QueryAnalysisResult
        """
        results = {}

        for node in nodes:
            result = self.analyze(node)
            results[node.unique_id] = result

        return results

    def get_federated_nodes(
        self,
        nodes: List[ManifestNode]
    ) -> List[ManifestNode]:
        """
        Filter nodes that require federated execution.

        :param nodes: List of nodes to filter
        :returns: List of nodes requiring federated execution
        """
        federated = []

        for node in nodes:
            result = self.analyze(node)
            if result.is_federated:
                federated.append(node)

        return federated

    def get_pushdown_nodes(
        self,
        nodes: List[ManifestNode]
    ) -> List[ManifestNode]:
        """
        Filter nodes eligible for pushdown execution.

        :param nodes: List of nodes to filter
        :returns: List of nodes eligible for pushdown
        """
        pushdown = []

        for node in nodes:
            result = self.analyze(node)
            if result.is_pushdown:
                pushdown.append(node)

        return pushdown
