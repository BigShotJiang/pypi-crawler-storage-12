# MusicMCP.AI MCP Server

<div class="title-block" style="text-align: center;" align="center">

# 🎵 MusicMCP.AI MCP Server

**AI-Powered Music Generation with Model Context Protocol**

</div>

<p align="center">
  Official MusicMCP.AI Model Context Protocol (MCP) server that enables seamless interaction with our advanced AI music generation platform. This server allows MCP clients like <a href="https://www.anthropic.com/claude">Claude Desktop</a>, <a href="https://github.com/openai/openai-agents-python">OpenAI Agents</a> and others to generate AI music through natural language commands.
</p>

## ✨ Features

- **🎼 AI Music Generation**: Generate songs based on text prompts using MusicMCP.AI's state-of-the-art AI models
- **🎵 Dual Generation Modes**: Support for both inspiration mode and custom mode
- **🔗 Direct Download Links**: Get direct download URLs for generated music
- **🤖 Multiple Models**: Support for different AI models including chirp-v3-5 and chirp-v4
- **🎹 Instrumental Options**: Generate instrumental-only music or full songs with vocals
- **⚡ Async Processing**: Efficient asynchronous handling of long-running music generation tasks
- **✅ API Key Validation**: Check your API key validity and remaining credits
- **🏥 Health Monitoring**: Check API service health status
- **📊 API Information**: Get detailed information about available endpoints and costs

## 🚀 Quickstart with Claude Desktop

1. **Get Your API Key**: Obtain your API key from [MusicMCP.AI Platform](https://www.musicmcp.ai)
2. **Install uv**: Install the Python package manager with `curl -LsSf https://astral.sh/uv/install.sh | sh`
3. **Configure Claude**: Go to Claude > Settings > Developer > Edit Config > claude_desktop_config.json and add:

```json
{
    "mcpServers": {
        "MusicMCP.AI": {
            "command": "uvx",
            "args": [
                "aimusic-mcp"
            ],
            "env": {
                "MUSICMCP_API_KEY": "<insert-your-api-key-here>",
                "MUSICMCP_API_URL": "https://www.musicmcp.ai/api",
                "TIME_OUT_SECONDS": "600"
            }
        }
    }
}
```

4. **Restart Claude**: Restart the Claude app and you'll see **5 MCP tools** available, indicating successful loading

## ⚙️ Environment Variables

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `MUSICMCP_API_KEY` | Your MusicMCP.AI API key | - | ✅ Yes |
| `MUSICMCP_API_URL` | MusicMCP.AI API base URL | `https://www.musicmcp.ai/api` | ❌ No |
| `TIME_OUT_SECONDS` | Timeout for music generation in seconds | `600` (10 min) | ❌ No |

## 🛠️ Available Tools

### 1. 🎼 Generate Prompt Song (灵感模式)
Generate AI music based on simple text descriptions. AI automatically creates title, lyrics, and style.

**Cost**: 5 credits per generation

**Parameters:**
- `prompt` (str): Simple description of the music theme (1-1200 characters)
- `instrumental` (bool): Whether to generate instrumental music only
- `style` (str, optional): Music style (e.g., "ambient", "pop", "rock")

**Example Prompts:**
```
"帮我生成一首关于和平早晨的歌"
"想要一首表达思念的歌曲"
"创作一首关于友谊的音乐"
```

**Output Example:**
```
✅ Song 1 generated successfully!

📌 Title: Peaceful Morning
🆔 ID: abc123def456
🔗 Download URL: https://cdn.musicmcp.ai/songs/abc123.mp3

You can download or play the audio from the URL above.
```

### 2. 🎵 Generate Custom Song (自定义模式)
Generate AI music with specific lyrics, title, and style parameters that you provide.

**Cost**: 5 credits per generation

**Parameters:**
- `title` (str): Song title (required)
- `lyric` (str): Complete lyrics content (required)
- `tags` (str): Music style tags (e.g., 'pop', 'rock', 'folk') (required)
- `instrumental` (bool): Whether to generate instrumental music only

**Example Usage:**
```
请帮我生成一首歌
歌名：蝉蜕的夏天
歌词：[完整歌词内容]
风格使用民谣
```

**Output Example:**
```
✅ Custom song '蝉蜕的夏天' (version 1) generated successfully!

📌 Title: 蝉蜕的夏天
🆔 ID: xyz789abc123
🔗 Download URL: https://cdn.musicmcp.ai/songs/xyz789.mp3

You can download or play the audio from the URL above.
```

### 3. ✅ Validate API Key
Check if your API key is valid and see your remaining credits.

**Cost**: Free

**Example Usage:**
```
"验证我的 API 密钥"
"检查我的积分余额"
```

### 4. 🏥 Check API Health
Monitor the health status of the MusicMCP.AI API service.

**Cost**: Free

**Example Usage:**
```
"检查 API 服务状态"
```

### 5. 📊 Get API Info
Get detailed information about the API including rate limits and documentation.

**Cost**: Free

**Example Usage:**
```
"获取 API 信息"
```

## 💰 Credits & Pricing

| Operation | Credits Cost |
|-----------|-------------|
| Generate Inspiration Music | 5 credits |
| Generate Custom Music | 5 credits |
| Query Music Status | 0 credits (Free) |
| Validate API Key | 0 credits (Free) |
| API Health Check | 0 credits (Free) |
| Get API Info | 0 credits (Free) |

## 💡 Example Usage

⚠️ **Note**: MusicMCP.AI credits are required to use the music generation tools.

### Try asking Claude:

#### **灵感模式 (Inspiration Mode):**
- "请帮我生成一首关于和平早晨的歌"
- "想要一首表达思念的歌曲"
- "创作一首关于友谊的音乐"
- "生成一首 180 秒的氛围音乐"

#### **自定义模式 (Custom Mode):**
- "请帮我生成一首歌，歌名：蝉蜕的夏天，歌词：[完整歌词]，风格使用民谣"
- "创作一首歌，标题：春天的约定，歌词：[完整歌词]，流行风格"

#### **管理功能:**
- "验证我的 API 密钥"
- "检查我还有多少积分"
- "检查 API 服务状态"

## 📦 Installation

### Using uv (Recommended)
```bash
uvx aimusic-mcp
```

### Using pip
```bash
pip install aimusic-mcp
```

### From Source
```bash
git clone https://github.com/puyue-ai/musicmcp-ai-mcp.git
cd musicmcp-ai-mcp
pip install -e .
```

### Quick Install Script
```bash
chmod +x install.sh
./install.sh
```

## 🔌 API Integration

This MCP server integrates with MusicMCP.AI's RESTful API:

- **`POST /music/generate/inspiration`**: Create music generation task (inspiration mode)
- **`POST /music/generate/custom`**: Create custom music generation task
- **`POST /music/generate/query`**: Query music status (batch query supported)
- **`POST /validate`**: Validate API key and check credits
- **`GET /health`**: Check API service health
- **`GET /info`**: Get API information

### API Workflow
1. Submit generation request with API key in header (`api-key: your-key`)
2. Receive song IDs in response
3. Poll `/music/generate/query` for completion status
4. Receive download URLs for generated music
5. User can download or play music directly from URLs

## 🐛 Troubleshooting

### Common Issues

1. **API Key Error**: Ensure `MUSICMCP_API_KEY` is set correctly
   - Use the `validate_api_key` tool to check your key

2. **Insufficient Credits (402 Error)**: You don't have enough credits
   - Check your balance at https://www.musicmcp.ai
   - Recharge your account

3. **Timeout Errors**: Increase `TIME_OUT_SECONDS` if music generation takes longer

### Logs

When running with Claude Desktop, logs can be found at:

- **Windows**: `%APPDATA%\Claude\logs\mcp-server-MusicMCP.AI.log`
- **macOS**: `~/Library/Logs/Claude/mcp-server-MusicMCP.AI.log`

## 🧪 Development

### Running Tests
```bash
pytest tests/
```

### Local Development
```bash
python -m musicmcp_ai_mcp.api
```

### Code Structure
```
musicmcp_ai_mcp/
├── __init__.py          # Package initialization
├── __main__.py          # CLI entry point
└── api.py               # Core MCP server implementation (430 lines)
```

## 🔗 Links

- **Platform**: https://www.musicmcp.ai
- **Documentation**: https://docs.aimusicmcp.com
- **GitHub**: https://github.com/puyue-ai/musicmcp-ai-mcp
- **Issues**: https://github.com/puyue-ai/musicmcp-ai-mcp/issues

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

<div align="center">

**Made with ❤️ by the MusicMCP.AI Team**

*Transform your ideas into music with AI*

</div>
