Setup:

- Install sale_order_line_form_action
- Open sale order or create new one

Check Button:

- Check if "Show Details" button (list icon) in sale order line is present
- Click "Show Details"
- Check if Pop-up with sale order line appears
