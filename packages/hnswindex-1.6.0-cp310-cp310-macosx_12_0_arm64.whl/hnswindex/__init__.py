from .bindings import Index

__all__ = ["Index"]
