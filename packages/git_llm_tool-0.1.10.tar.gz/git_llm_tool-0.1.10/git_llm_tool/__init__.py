"""Git-LLM-Tool: AI-powered git commit message and changelog generator."""

__version__ = "0.1.5"
__author__ = "skyler-gogolook"
__email__ = "skyler.lo@gogolook.com"