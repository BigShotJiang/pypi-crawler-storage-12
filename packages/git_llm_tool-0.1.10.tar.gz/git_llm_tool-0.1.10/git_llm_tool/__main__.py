"""Entry point for running git-llm-tool as a module."""

from git_llm_tool.cli import main

if __name__ == "__main__":
    main()