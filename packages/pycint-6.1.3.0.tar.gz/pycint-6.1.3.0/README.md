# pycint

`pycint` is a unofficial `cffi`-based Python
[`libcint`](https://github.com/sunqm/libcint) wrapper.
