#!/usr/bin/env python
"""The setup script."""

from setuptools import setup

# All configuration is now in pyproject.toml
setup()