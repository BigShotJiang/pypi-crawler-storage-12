"""Reg.ru DNS authenticator plugin for Certbot"""
