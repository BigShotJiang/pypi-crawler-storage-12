from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="DeprecatedProviderConfig")


@_attrs_define
class DeprecatedProviderConfig:
    """Information about a provider instance with deprecated config.

    Attributes:
        provider_id (UUID):
        name (str):
        provider_type (str):
        current_version (int):
        latest_version (int):
        warning (str):
        can_auto_migrate (bool):
        auto_upgrade_enabled (bool):
    """

    provider_id: UUID
    name: str
    provider_type: str
    current_version: int
    latest_version: int
    warning: str
    can_auto_migrate: bool
    auto_upgrade_enabled: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        provider_id = str(self.provider_id)

        name = self.name

        provider_type = self.provider_type

        current_version = self.current_version

        latest_version = self.latest_version

        warning = self.warning

        can_auto_migrate = self.can_auto_migrate

        auto_upgrade_enabled = self.auto_upgrade_enabled

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "provider_id": provider_id,
                "name": name,
                "provider_type": provider_type,
                "current_version": current_version,
                "latest_version": latest_version,
                "warning": warning,
                "can_auto_migrate": can_auto_migrate,
                "auto_upgrade_enabled": auto_upgrade_enabled,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        provider_id = UUID(d.pop("provider_id"))

        name = d.pop("name")

        provider_type = d.pop("provider_type")

        current_version = d.pop("current_version")

        latest_version = d.pop("latest_version")

        warning = d.pop("warning")

        can_auto_migrate = d.pop("can_auto_migrate")

        auto_upgrade_enabled = d.pop("auto_upgrade_enabled")

        deprecated_provider_config = cls(
            provider_id=provider_id,
            name=name,
            provider_type=provider_type,
            current_version=current_version,
            latest_version=latest_version,
            warning=warning,
            can_auto_migrate=can_auto_migrate,
            auto_upgrade_enabled=auto_upgrade_enabled,
        )

        deprecated_provider_config.additional_properties = d
        return deprecated_provider_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
