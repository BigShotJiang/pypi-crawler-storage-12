"""
Temporary shims for rendercanvas.
"""

from rendercanvas import BaseRenderCanvas

WgpuCanvasBase = BaseRenderCanvas
del BaseRenderCanvas
