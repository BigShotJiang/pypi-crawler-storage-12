# -*- coding: UTF-8 -*-
# Copyright 2025 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from django.db.models import Q
# from lino.core.model import Model
# from lino.core.fields import ForeignKey
from lino.api import dd
from lino.core.roles import SiteAdmin
from lino.modlib.users.mixins import UserAuthored
