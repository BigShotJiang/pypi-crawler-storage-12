"""
WeData Feature Engineering
A toolkit for automated feature engineering
"""
from wedata.common.constants import constants

__version__ = f"{constants.FEATURE_LOOKUP_CLIENT_MAJOR_VERSION}"


