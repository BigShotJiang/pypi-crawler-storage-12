from .cli.main import COMMAND, app

app(prog_name=COMMAND)
