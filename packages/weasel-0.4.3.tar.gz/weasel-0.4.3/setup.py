#!/usr/bin/env python


if __name__ == "__main__":
    from setuptools import find_packages, setup

    setup(packages=find_packages())
