"""
API module for MCP Open Client.
"""