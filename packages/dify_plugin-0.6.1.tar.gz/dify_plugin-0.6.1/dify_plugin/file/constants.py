DIFY_FILE_IDENTITY = "__dify__file__"
DIFY_TOOL_SELECTOR_IDENTITY = "__dify__tool_selector__"
