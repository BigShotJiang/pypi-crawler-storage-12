class ArgumentValidationError(Exception):
    """
    A CLI argument is invalid.
    """
