It's handy to have this default information available in the invoice.
There might be case where there's no delivery slip or it isn't handed to the customer.