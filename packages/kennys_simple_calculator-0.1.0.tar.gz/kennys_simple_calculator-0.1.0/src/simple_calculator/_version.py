"""Version information for simple_calculator."""

__version__ = "0.1.0"
