"""
C108 Core Library
"""

# Formatting tools ----------------------------------------

# from .tools import fmt_value, fmt_sequence, fmt_mapping

# Core utilities ------------------------------------------

# from .utils import class_name
