from ._main import Dict

__all__ = ["Dict"]
