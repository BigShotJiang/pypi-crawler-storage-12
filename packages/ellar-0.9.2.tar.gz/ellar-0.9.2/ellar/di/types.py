import typing as t

T = t.TypeVar("T")
