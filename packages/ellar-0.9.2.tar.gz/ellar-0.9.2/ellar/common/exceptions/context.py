class HostContextException(Exception):
    pass


class ExecutionContextException(Exception):
    pass
