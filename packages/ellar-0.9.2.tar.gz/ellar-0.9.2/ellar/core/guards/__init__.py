from .consumer import GuardConsumer

__all__ = [
    "GuardConsumer",
]
