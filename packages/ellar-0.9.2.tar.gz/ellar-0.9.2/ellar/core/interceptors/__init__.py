from .consumer import EllarInterceptorConsumer

__all__ = ["EllarInterceptorConsumer"]
