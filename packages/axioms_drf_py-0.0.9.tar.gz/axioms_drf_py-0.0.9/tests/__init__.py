"""Tests for axioms-drf-py package."""
