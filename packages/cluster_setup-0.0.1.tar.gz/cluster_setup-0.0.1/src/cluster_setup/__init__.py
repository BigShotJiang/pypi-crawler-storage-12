"""A tool for initializing environments on Compute Canada clusters."""
# SPDX-FileCopyrightText: 2025-present Ugochukwu Nwosu <ugognw@gmail.com>
#
# SPDX-License-Identifier: MIT
