"""
Tests for the extension bridging ``sphinx-confluencebuilder`` directives with
other builders.
"""
