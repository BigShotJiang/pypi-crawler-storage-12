import logging

logger = logging.getLogger("ellar")
request_logger = logging.getLogger("ellar.request")
