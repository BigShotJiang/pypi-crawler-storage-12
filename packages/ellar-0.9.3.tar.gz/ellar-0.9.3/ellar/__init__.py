"""Ellar - Python ASGI web framework for building fast, efficient, and scalable RESTful APIs and server-side applications."""

__version__ = "0.9.3"
