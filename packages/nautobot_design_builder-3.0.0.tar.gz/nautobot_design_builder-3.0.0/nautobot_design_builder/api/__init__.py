"""REST API module for nautobot_design_builder app."""
