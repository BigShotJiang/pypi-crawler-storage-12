"""Unit tests for nautobot_design_builder plugin."""

import logging

logging.disable(logging.INFO)
