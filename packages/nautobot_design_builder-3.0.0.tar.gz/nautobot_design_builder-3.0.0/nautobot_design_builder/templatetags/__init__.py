"""Django template tag definitions."""
