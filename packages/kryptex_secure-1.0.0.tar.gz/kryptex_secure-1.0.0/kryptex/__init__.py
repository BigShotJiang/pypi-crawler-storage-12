"""
Kryptex - Secure key wrapping and file encryption tool.

A product of CyberSynth
"""

__version__ = "1.0.0"
__author__ = "Adegboyega Samuel"
__license__ = "MIT"

from kryptex.cli import main

__all__ = ["main"]