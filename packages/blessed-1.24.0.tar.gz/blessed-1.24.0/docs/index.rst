=================================
Welcome to Blessed documentation!
=================================

.. toctree::
   :maxdepth: 3

   intro
   terminal
   colors
   keyboard
   keyboard_kitty
   mouse
   dec_modes
   location
   measuring
   sixel
   examples
   api
   project
   history

=======
Indexes
=======

* :ref:`genindex`
* :ref:`modindex`
