dec_modes.py
------------

.. automodule:: blessed.dec_modes
   :members:
   :undoc-members:
