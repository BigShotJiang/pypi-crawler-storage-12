formatters.py
-------------

.. automodule:: blessed.formatters
   :members:
   :undoc-members:
   :private-members:
   :special-members: __call__
