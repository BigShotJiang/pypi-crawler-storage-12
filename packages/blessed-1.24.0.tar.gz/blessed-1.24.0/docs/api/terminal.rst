terminal.py
-----------

.. automodule:: blessed.terminal
   :members:
   :undoc-members:
   :special-members: __getattr__
.. autodata:: _CUR_TERM
