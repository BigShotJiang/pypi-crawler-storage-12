"""Resource management for the arXiv MCP server."""

from .papers import PaperManager

__all__ = ["PaperManager"]
