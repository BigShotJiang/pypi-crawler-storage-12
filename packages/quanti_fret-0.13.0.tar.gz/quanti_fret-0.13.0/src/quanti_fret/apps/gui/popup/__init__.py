from quanti_fret.apps.gui.popup.manager import PopUpManager  # noqa: F401


__ALL__ = [
    'PopUpManager'
]
