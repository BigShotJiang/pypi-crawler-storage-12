"""Core modules for MorphML."""

__all__ = []
