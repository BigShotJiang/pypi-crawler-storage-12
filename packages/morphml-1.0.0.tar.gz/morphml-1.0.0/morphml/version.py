"""Version information for MorphML."""

__version__ = "1.0.0"
__author__ = "Vedanth & Eshan Roy"
__email__ = "vedanth@vedanthq.com, eshanized@proton.me"
__organization__ = "TONMOY INFRASTRUCTURE & VISION"
__repository__ = "https://github.com/TIVerse/MorphML"
