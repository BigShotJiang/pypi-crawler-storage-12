"""Command-line interface for MorphML."""

from morphml.cli.main import cli

__all__ = ["cli"]
