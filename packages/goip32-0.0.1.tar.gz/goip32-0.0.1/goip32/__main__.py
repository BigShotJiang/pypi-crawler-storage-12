#!/usr/bin/env python
# by Dominik Stanisław Suchora <hexderm@gmail.com>
# License: GNU GPLv3

import sys
from goip32 import main

if __name__ == "__main__":
    sys.exit(main())
