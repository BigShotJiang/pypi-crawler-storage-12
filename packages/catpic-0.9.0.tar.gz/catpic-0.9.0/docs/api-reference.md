# API Reference

High-level API concepts that apply across all implementations.

See language-specific documentation for details:
- [Python API](./implementations/python.md)
- [C API](./implementations/c.md)
