# Getting Started

## Installation

Choose your language:

### Python
See [python/README.md](../python/README.md)

### C
See [c/README.md](../c/README.md)

## Basic Usage

[Add basic usage examples here]
