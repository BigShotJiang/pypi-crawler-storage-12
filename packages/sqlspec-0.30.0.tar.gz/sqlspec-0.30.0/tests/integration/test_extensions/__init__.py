"""Integration tests for SQLSpec extensions."""
