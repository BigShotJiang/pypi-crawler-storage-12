"""OracleDB adapter integration tests."""

import pytest

pytestmark = pytest.mark.xdist_group("oracle")
