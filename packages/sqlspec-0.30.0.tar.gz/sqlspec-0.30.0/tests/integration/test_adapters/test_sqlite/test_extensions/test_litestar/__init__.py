"""Integration tests for SQLite Litestar extensions."""
