"""Tests for SQLite ADK store implementation."""
