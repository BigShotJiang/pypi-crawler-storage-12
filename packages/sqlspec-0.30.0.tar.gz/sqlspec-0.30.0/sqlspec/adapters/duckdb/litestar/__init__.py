"""Litestar integration for DuckDB adapter."""

from sqlspec.adapters.duckdb.litestar.store import DuckdbStore

__all__ = ("DuckdbStore",)
