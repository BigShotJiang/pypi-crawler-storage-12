"""Litestar integration for AsyncMy adapter."""

from sqlspec.adapters.asyncmy.litestar.store import AsyncmyStore

__all__ = ("AsyncmyStore",)
