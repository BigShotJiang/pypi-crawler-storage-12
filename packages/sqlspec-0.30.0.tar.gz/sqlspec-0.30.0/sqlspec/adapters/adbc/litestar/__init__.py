"""Litestar integration for ADBC adapter."""

from sqlspec.adapters.adbc.litestar.store import ADBCStore

__all__ = ("ADBCStore",)
