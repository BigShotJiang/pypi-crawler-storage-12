#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Package for nti.property.

"""

from __future__ import print_function, absolute_import, division
__docformat__ = "restructuredtext en"
