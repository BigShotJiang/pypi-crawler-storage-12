=============
 nti.property
=============

.. image:: https://img.shields.io/pypi/v/nti.property.svg
        :target: https://pypi.python.org/pypi/nti.property/
        :alt: Latest Version

.. image:: https://github.com/OpenNTI/nti.property/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/OpenNTI/nti.property/actions/workflows/tests.yml

.. image:: https://readthedocs.org/projects/ntiproperty/badge/?version=latest
        :target: http://ntiproperty.readthedocs.org/en/latest/
        :alt: Documentation Status

nti.property offers a set of classes and utility functions to set
properties on objects or classes.

Complete documentation can be found at http://ntiproperty.readthedocs.io
