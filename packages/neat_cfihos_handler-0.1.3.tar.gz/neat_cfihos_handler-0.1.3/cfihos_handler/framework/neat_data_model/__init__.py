"""Neat Data Model package for the CFIHOS framework.

This package includes Neat Data Model components, modules, and utilities
for handling the Neat Data Model within the CFIHOS processing framework.
"""
