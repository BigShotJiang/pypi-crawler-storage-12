```{eval-rst}
.. automodule:: ape_safe.client
    :members:
```
