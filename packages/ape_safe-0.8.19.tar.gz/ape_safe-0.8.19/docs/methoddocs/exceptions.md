```{eval-rst}
.. automodule:: ape_safe.exceptions
    :members:
```
