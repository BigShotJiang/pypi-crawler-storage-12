# Pyarmor 9.2.0 (basic), 009672, 2025-11-16T18:22:51.453944
from .pyarmor_runtime import __pyarmor__
