#!/usr/bin/env python

from coolbox.cli import CLI
import fire


def main():
    fire.Fire(CLI)


if __name__ == "__main__":
    main()
