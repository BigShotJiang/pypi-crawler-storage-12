from .full import FullWidgets
from .simple import SimpleWidgets
