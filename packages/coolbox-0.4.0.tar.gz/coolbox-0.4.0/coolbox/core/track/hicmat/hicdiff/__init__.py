from .diff import HiCDiff
from .selfish import Selfish
