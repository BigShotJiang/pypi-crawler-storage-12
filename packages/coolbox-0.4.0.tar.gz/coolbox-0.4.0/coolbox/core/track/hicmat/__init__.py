from .base import HicMatBase
from .cool import Cool
from .dothic import DotHiC
from .hicdiff import HiCDiff, Selfish
from .hicmat import HiCMat


