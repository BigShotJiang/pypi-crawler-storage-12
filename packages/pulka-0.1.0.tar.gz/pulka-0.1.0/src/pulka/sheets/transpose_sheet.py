"""Compatibility wrapper for legacy transpose sheet imports."""

from pulka_builtin_plugins.transpose.plugin import TransposeSheet

__all__ = ["TransposeSheet"]
