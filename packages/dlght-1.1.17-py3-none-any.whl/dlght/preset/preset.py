from prompt_toolkit import prompt
from prompt_toolkit.completion import WordCompleter

class PRESET():
    def __init__(self):
        # 预设的软件列表
        software_list = ['v2ray', 'clash', 'clash-verge', 'v2rayN', 'shadowsocks', 'trojan']
        
        # 创建自动补全器
        completer = WordCompleter(software_list, ignore_case=True)
        
        # 显示提示并获取用户输入
        print("请选择要下载的软件（支持自动补全，按 Tab 键）:")
        user_input = prompt('> ', completer=completer)
        
        if user_input in software_list:
            print(f"您选择了: {user_input}")
            self.download_software(user_input)
        else:
            print(f"未找到软件: {user_input}")
    
    def download_software(self, software_name):
        """下载指定的软件"""
        # TODO: 实现具体的下载逻辑
        print(f"开始下载 {software_name}...")
