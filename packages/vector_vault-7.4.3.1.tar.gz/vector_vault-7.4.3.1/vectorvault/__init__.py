from importlib import metadata as _metadata

from .vault import Vault  # noqa: F401
from .utils import download_url, wrap  # noqa: F401

try:
    __version__ = _metadata.version("vector_vault")
except _metadata.PackageNotFoundError:
    __version__ = "0.0.0"