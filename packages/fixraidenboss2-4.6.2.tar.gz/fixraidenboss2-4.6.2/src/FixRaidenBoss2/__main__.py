from .main import remapMain

##### Script
if __name__ == '__main__':
    remapMain()
##### EndScript