"""Esprit - A minimal terminal-based spreadsheet editor."""

__version__ = "0.1.0"
