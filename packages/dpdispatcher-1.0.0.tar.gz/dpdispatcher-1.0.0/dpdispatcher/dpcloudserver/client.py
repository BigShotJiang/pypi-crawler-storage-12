"""Provide backward compatbility with dflow."""

from dpdispatcher.utils.dpcloudserver.client import RequestInfoException

__all__ = [
    "RequestInfoException",
]
