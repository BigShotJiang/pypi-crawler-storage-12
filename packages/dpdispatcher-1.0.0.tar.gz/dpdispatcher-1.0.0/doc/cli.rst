.. _cli:

Command line interface
======================

.. argparse::
   :module: dpdispatcher.dpdisp
   :func: main_parser
   :prog: dpdisp
