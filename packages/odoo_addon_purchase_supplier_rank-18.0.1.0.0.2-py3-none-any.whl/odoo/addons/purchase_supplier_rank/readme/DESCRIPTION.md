This module updates supplier_rank for partners when creating purchase
orders. Normally supplier_rank is only updated by creating vendor
invoices.
