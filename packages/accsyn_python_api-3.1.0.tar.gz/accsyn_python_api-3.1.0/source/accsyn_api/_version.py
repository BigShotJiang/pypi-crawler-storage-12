# :coding: utf-8
# :copyright: Copyright (c) 2015-2023 accsyn/HDR AB

__version__ = "3.1.0-1"
