"""
GLM Vision MCP Server
AI-powered image and video analysis for developers using ZhipuAI's GLM-4.5V model
"""

__version__ = "2.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .server import mcp, main

__all__ = ["mcp", "main"]
