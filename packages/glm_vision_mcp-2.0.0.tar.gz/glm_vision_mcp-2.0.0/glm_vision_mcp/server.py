"""
GLM Vision MCP Server - Main entry point
"""

from fastmcp import FastMCP
from .config import SERVER_NAME, SERVER_VERSION
from .tools import register_all_tools


# Create MCP server instance
mcp = FastMCP(
    name=SERVER_NAME,
    instructions="Provides specialized vision analysis tools for common developer scenarios using ZhipuAI's GLM-4.5V model",
    version=SERVER_VERSION
)


# Register all tools
register_all_tools(mcp)


def main():
    """Main entry point for the MCP server"""
    # Run the MCP server in stdio mode
    mcp.run()


if __name__ == "__main__":
    main()
