"""
Utility functions for file validation, encoding, and processing
"""

import os
import base64
import mimetypes
from pathlib import Path
from .config import (
    MAX_IMAGE_SIZE,
    MAX_VIDEO_SIZE,
    SUPPORTED_IMAGE_FORMATS,
    SUPPORTED_VIDEO_FORMATS
)


def get_api_key() -> str:
    """
    Get ZhipuAI API key from environment variable

    Returns:
        str: API key

    Raises:
        ValueError: If ZHIPU_API_KEY is not set
    """
    api_key = os.getenv("ZHIPU_API_KEY")
    if not api_key:
        raise ValueError(
            "ZHIPU_API_KEY environment variable is not set. "
            "Please set it with your ZhipuAI API key."
        )
    return api_key


def validate_file_path(file_path: str) -> Path:
    """
    Validate that the file exists and return Path object

    Args:
        file_path: Path to the file

    Returns:
        Path: Validated Path object

    Raises:
        FileNotFoundError: If file doesn't exist
        ValueError: If path is not a file
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    if not path.is_file():
        raise ValueError(f"Path is not a file: {file_path}")
    return path


def validate_image_file(file_path: str) -> Path:
    """
    Validate image file format and size

    Args:
        file_path: Path to the image file

    Returns:
        Path: Validated Path object

    Raises:
        ValueError: If format is unsupported or file is too large
    """
    path = validate_file_path(file_path)

    # Check file extension
    if path.suffix.lower() not in SUPPORTED_IMAGE_FORMATS:
        raise ValueError(
            f"Unsupported image format: {path.suffix}. "
            f"Supported formats: {', '.join(SUPPORTED_IMAGE_FORMATS)}"
        )

    # Check file size
    file_size = path.stat().st_size
    if file_size > MAX_IMAGE_SIZE:
        raise ValueError(
            f"Image file too large: {file_size / 1024 / 1024:.2f}MB. "
            f"Maximum size: {MAX_IMAGE_SIZE / 1024 / 1024}MB"
        )

    return path


def validate_video_file(file_path: str) -> Path:
    """
    Validate video file format and size

    Args:
        file_path: Path to the video file

    Returns:
        Path: Validated Path object

    Raises:
        ValueError: If format is unsupported or file is too large
    """
    path = validate_file_path(file_path)

    # Check file extension
    if path.suffix.lower() not in SUPPORTED_VIDEO_FORMATS:
        raise ValueError(
            f"Unsupported video format: {path.suffix}. "
            f"Supported formats: {', '.join(SUPPORTED_VIDEO_FORMATS)}"
        )

    # Check file size
    file_size = path.stat().st_size
    if file_size > MAX_VIDEO_SIZE:
        raise ValueError(
            f"Video file too large: {file_size / 1024 / 1024:.2f}MB. "
            f"Maximum size: {MAX_VIDEO_SIZE / 1024 / 1024}MB"
        )

    return path


def encode_file_to_base64(file_path: Path) -> str:
    """
    Read file and encode to base64 string

    Args:
        file_path: Path object to the file

    Returns:
        str: Base64 encoded string
    """
    with open(file_path, "rb") as f:
        file_content = f.read()
    return base64.b64encode(file_content).decode("utf-8")


def get_mime_type(file_path: Path) -> str:
    """
    Get MIME type for the file

    Args:
        file_path: Path object to the file

    Returns:
        str: MIME type string
    """
    mime_type, _ = mimetypes.guess_type(str(file_path))
    if not mime_type:
        # Fallback MIME types
        ext = file_path.suffix.lower()
        mime_map = {
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.mp4': 'video/mp4',
            '.mov': 'video/quicktime',
            '.m4v': 'video/x-m4v'
        }
        mime_type = mime_map.get(ext, 'application/octet-stream')
    return mime_type


def create_data_uri(file_path: Path, base64_data: str) -> str:
    """
    Create data URI from base64 encoded data

    Args:
        file_path: Path object to determine MIME type
        base64_data: Base64 encoded file data

    Returns:
        str: Data URI string
    """
    mime_type = get_mime_type(file_path)
    return f"data:{mime_type};base64,{base64_data}"
