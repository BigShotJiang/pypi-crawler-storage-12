"""
Technical Diagram Understanding tool - Analyze architecture diagrams, flowcharts, UML, etc.
"""

from typing import Annotated
from fastmcp import FastMCP
from ..utils import validate_image_file, encode_file_to_base64, create_data_uri
from ..api_client import call_glm_api
from ..prompts import DIAGRAM_UNDERSTANDING_PROMPT


def register_diagram_analysis(mcp: FastMCP):
    """Register understand_technical_diagram tool"""

    @mcp.tool()
    async def understand_technical_diagram(
        image_path: Annotated[str, "Local file path to the technical diagram (PNG, JPG, JPEG). Should contain architecture diagrams, flowcharts, UML diagrams, ER diagrams, sequence diagrams, or system design diagrams."],
        prompt: Annotated[str, "What you want to understand or extract from this diagram."],
        diagram_type: Annotated[str, "Optional: specify the diagram type if known (e.g., 'architecture', 'flowchart', 'uml', 'er-diagram', 'sequence'). Leave empty for auto-detection."] = ""
    ) -> str:
        """
        Analyze and explain technical diagrams including architecture diagrams, flowcharts, UML, ER diagrams, and system design diagrams.

        Use this tool ONLY when the user has a technical diagram and wants to understand its structure or components.
        This tool specializes in interpreting visual technical documentation.

        Do NOT use for: UI screenshots, error messages, or data visualizations/charts.
        """
        try:
            # Validate image
            img_path = validate_image_file(image_path)

            # Encode to base64
            base64_data = encode_file_to_base64(img_path)
            data_uri = create_data_uri(img_path, base64_data)

            # Enhance prompt with diagram type hint if provided
            enhanced_prompt = prompt
            if diagram_type:
                enhanced_prompt = f"{prompt}\n\n<diagram_type_hint>This is a {diagram_type} diagram.</diagram_type_hint>"

            # Call API
            result = await call_glm_api(DIAGRAM_UNDERSTANDING_PROMPT, enhanced_prompt, [data_uri])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
