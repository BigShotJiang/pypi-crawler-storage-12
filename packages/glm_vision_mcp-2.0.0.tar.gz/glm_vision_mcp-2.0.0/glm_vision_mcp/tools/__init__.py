"""
MCP tool definitions for GLM Vision Server
Import and register all tools
"""

from fastmcp import FastMCP
from .ui_to_artifact import register_ui_to_artifact
from .text_extraction import register_text_extraction
from .error_diagnosis import register_error_diagnosis
from .diagram_analysis import register_diagram_analysis
from .data_viz import register_data_viz
from .ui_diff import register_ui_diff
from .video_analysis import register_video_analysis
from .general_image import register_general_image


def register_all_tools(mcp: FastMCP):
    """Register all tools with the MCP server"""
    register_ui_to_artifact(mcp)
    register_text_extraction(mcp)
    register_error_diagnosis(mcp)
    register_diagram_analysis(mcp)
    register_data_viz(mcp)
    register_ui_diff(mcp)
    register_video_analysis(mcp)
    register_general_image(mcp)
