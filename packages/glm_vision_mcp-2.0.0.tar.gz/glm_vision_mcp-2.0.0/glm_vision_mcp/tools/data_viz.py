"""
Data Visualization Analysis tool - Analyze charts, graphs, and dashboards
"""

from typing import Annotated
from fastmcp import FastMCP
from ..utils import validate_image_file, encode_file_to_base64, create_data_uri
from ..api_client import call_glm_api
from ..prompts import DATA_VIZ_ANALYSIS_PROMPT


def register_data_viz(mcp: FastMCP):
    """Register analyze_data_visualization tool"""

    @mcp.tool()
    async def analyze_data_visualization(
        image_path: Annotated[str, "Local file path to the data visualization screenshot (PNG, JPG, JPEG). Should contain charts, graphs, dashboards, or monitoring panels."],
        prompt: Annotated[str, "What insights or information you want to extract from this visualization."],
        analysis_focus: Annotated[str, "Optional: specify what to focus on (e.g., 'trends', 'anomalies', 'comparisons', 'performance metrics'). Leave empty for comprehensive analysis."] = ""
    ) -> str:
        """
        Analyze data visualizations, charts, graphs, and dashboards to extract insights and trends.

        Use this tool ONLY when the user has a data visualization image and wants to understand the data patterns or metrics.
        This tool specializes in interpreting visual data representations.

        Do NOT use for: UI mockups, error messages, or technical architecture diagrams.
        """
        try:
            # Validate image
            img_path = validate_image_file(image_path)

            # Encode to base64
            base64_data = encode_file_to_base64(img_path)
            data_uri = create_data_uri(img_path, base64_data)

            # Enhance prompt with analysis focus if provided
            enhanced_prompt = prompt
            if analysis_focus:
                enhanced_prompt = f"{prompt}\n\n<analysis_focus>Focus particularly on: {analysis_focus}.</analysis_focus>"

            # Call API
            result = await call_glm_api(DATA_VIZ_ANALYSIS_PROMPT, enhanced_prompt, [data_uri])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
