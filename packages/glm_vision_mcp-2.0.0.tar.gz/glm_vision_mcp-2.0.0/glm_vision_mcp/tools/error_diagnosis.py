"""
Error Diagnosis tool - Diagnose and analyze error screenshots
"""

from typing import Annotated
from fastmcp import FastMCP
from ..utils import validate_image_file, encode_file_to_base64, create_data_uri
from ..api_client import call_glm_api
from ..prompts import ERROR_DIAGNOSIS_PROMPT


def register_error_diagnosis(mcp: FastMCP):
    """Register diagnose_error_screenshot tool"""

    @mcp.tool()
    async def diagnose_error_screenshot(
        image_path: Annotated[str, "Local file path to the error screenshot (PNG, JPG, JPEG). Must contain error messages, exceptions, stack traces, compilation errors, or runtime errors."],
        prompt: Annotated[str, "Description of what you need help with regarding this error. Include any relevant context about when it occurred."],
        context: Annotated[str, "Optional: additional context about when the error occurred (e.g., 'during npm install', 'when running the app', 'after deployment'). Helps with more accurate diagnosis."] = ""
    ) -> str:
        """
        Diagnose and analyze error messages, stack traces, and exception screenshots.

        Use this tool ONLY when the user has an error screenshot and needs help understanding or fixing it.
        This tool specializes in error analysis and provides actionable solutions.

        Do NOT use for: code extraction, UI analysis, or diagram understanding.
        """
        try:
            # Validate image
            img_path = validate_image_file(image_path)

            # Encode to base64
            base64_data = encode_file_to_base64(img_path)
            data_uri = create_data_uri(img_path, base64_data)

            # Enhance prompt with context if provided
            enhanced_prompt = prompt
            if context:
                enhanced_prompt = f"{prompt}\n\n<error_context>This error occurred {context}.</error_context>"

            # Call API
            result = await call_glm_api(ERROR_DIAGNOSIS_PROMPT, enhanced_prompt, [data_uri])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
