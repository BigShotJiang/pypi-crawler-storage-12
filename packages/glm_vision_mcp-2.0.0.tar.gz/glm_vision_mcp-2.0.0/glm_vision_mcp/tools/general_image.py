"""
General Image Analysis tool - Fallback for any image analysis not covered by specialized tools
"""

from typing import Annotated
from fastmcp import FastMCP
from ..utils import validate_image_file, encode_file_to_base64, create_data_uri
from ..api_client import call_glm_api
from ..prompts import GENERAL_IMAGE_ANALYSIS_PROMPT


def register_general_image(mcp: FastMCP):
    """Register analyze_image tool"""

    @mcp.tool()
    async def analyze_image(
        image_path: Annotated[str, "Local file path to any image (PNG, JPG, JPEG)"],
        prompt: Annotated[str, "Detailed description of what you want to analyze, extract, or understand from the image. Be specific about your requirements."]
    ) -> str:
        """
        General-purpose image analysis for scenarios not covered by specialized tools.

        Use this tool as a FALLBACK when none of the other specialized tools (ui_to_artifact, extract_text_from_screenshot,
        diagnose_error_screenshot, understand_technical_diagram, analyze_data_visualization, ui_diff_check) fit the user's need.

        This tool provides flexible image understanding for any visual content.
        """
        try:
            # Validate image
            img_path = validate_image_file(image_path)

            # Encode to base64
            base64_data = encode_file_to_base64(img_path)
            data_uri = create_data_uri(img_path, base64_data)

            # Call API
            result = await call_glm_api(GENERAL_IMAGE_ANALYSIS_PROMPT, prompt, [data_uri])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
