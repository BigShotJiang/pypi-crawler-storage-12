"""
UI to Artifact tool - Convert UI screenshots to code/prompts/specs/descriptions
"""

from typing import Annotated
from fastmcp import FastMCP
from ..utils import validate_image_file, encode_file_to_base64, create_data_uri
from ..api_client import call_glm_api
from ..prompts import UI_TO_ARTIFACT_PROMPTS


def register_ui_to_artifact(mcp: FastMCP):
    """Register ui_to_artifact tool"""

    @mcp.tool()
    async def ui_to_artifact(
        image_path: Annotated[str, "Local file path to the UI screenshot or design mockup (PNG, JPG, JPEG). Must contain web UI, mobile UI, or design mockup/wireframe."],
        output_type: Annotated[str, "Type of output to generate. Options: 'code' (generate frontend code), 'prompt' (generate AI prompt for recreating this UI), 'spec' (generate design specification document), 'description' (natural language description of the UI)."],
        prompt: Annotated[str, "Detailed instructions describing what to generate from this UI image. Should clearly state the desired output and any specific requirements."]
    ) -> str:
        """
        Convert UI screenshots into various artifacts: code, prompts, design specifications, or descriptions.

        Use this tool ONLY when the user wants to:
        - Generate frontend code from UI design (output_type='code')
        - Create AI prompts for UI generation (output_type='prompt')
        - Extract design specifications (output_type='spec')
        - Get natural language description of the UI (output_type='description')

        Do NOT use for: screenshots containing text/code to extract, error messages, diagrams, or data visualizations.
        """
        try:
            # Validate image
            img_path = validate_image_file(image_path)

            # Encode to base64
            base64_data = encode_file_to_base64(img_path)
            data_uri = create_data_uri(img_path, base64_data)

            # Get appropriate system prompt
            system_prompt = UI_TO_ARTIFACT_PROMPTS.get(output_type.lower())
            if not system_prompt:
                return f"Error: Invalid output_type '{output_type}'. Must be one of: code, prompt, spec, description"

            # Call API
            result = await call_glm_api(system_prompt, prompt, [data_uri])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
