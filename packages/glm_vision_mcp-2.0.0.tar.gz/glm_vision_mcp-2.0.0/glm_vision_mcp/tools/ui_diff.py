"""
UI Diff Check tool - Compare two UI screenshots for visual regression testing
"""

from typing import Annotated
from fastmcp import FastMCP
from ..utils import validate_image_file, encode_file_to_base64, create_data_uri
from ..api_client import call_glm_api
from ..prompts import UI_DIFF_CHECK_PROMPT


def register_ui_diff(mcp: FastMCP):
    """Register ui_diff_check tool"""

    @mcp.tool()
    async def ui_diff_check(
        expected_image_path: Annotated[str, "Local file path to the EXPECTED/reference UI screenshot (PNG, JPG, JPEG). This is the design spec or target UI."],
        actual_image_path: Annotated[str, "Local file path to the ACTUAL/current UI screenshot (PNG, JPG, JPEG). This is the implementation that needs to be checked."],
        prompt: Annotated[str, "Instructions for the comparison. Specify what aspects to focus on or what level of detail is needed."]
    ) -> str:
        """
        Compare two UI screenshots to identify visual differences and implementation discrepancies.

        Use this tool ONLY when the user wants to compare an expected/reference UI with an actual implementation.
        This tool is specialized for UI quality assurance and design-to-implementation verification.

        Do NOT use for: general image comparison, error diagnosis, or analyzing single UIs.
        """
        try:
            # Validate both images
            expected_path = validate_image_file(expected_image_path)
            actual_path = validate_image_file(actual_image_path)

            # Encode both images to base64
            expected_base64 = encode_file_to_base64(expected_path)
            expected_uri = create_data_uri(expected_path, expected_base64)

            actual_base64 = encode_file_to_base64(actual_path)
            actual_uri = create_data_uri(actual_path, actual_base64)

            # Enhance prompt to clarify which image is which
            enhanced_prompt = f"""<images>
The first image is the EXPECTED/REFERENCE design (the target).
The second image is the ACTUAL/CURRENT implementation (what needs to be checked).
</images>

{prompt}"""

            # Call API with both images
            result = await call_glm_api(UI_DIFF_CHECK_PROMPT, enhanced_prompt, [expected_uri, actual_uri])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
