"""
Video Analysis tool - Analyze video content and sequences
"""

from typing import Annotated
from fastmcp import FastMCP
from ..utils import validate_video_file, encode_file_to_base64, create_data_uri
from ..api_client import call_glm_api
from ..prompts import VIDEO_ANALYSIS_PROMPT


def register_video_analysis(mcp: FastMCP):
    """Register analyze_video tool"""

    @mcp.tool()
    async def analyze_video(
        video_path: Annotated[str, "Local file path to the video (MP4, MOV, M4V). Maximum file size: 8MB."],
        prompt: Annotated[str, "Detailed instructions describing what to analyze, extract, or understand from the video. Be specific about your requirements."]
    ) -> str:
        """
        Analyze video content using advanced AI vision models.

        Use this tool when the user wants to:
        - Understand what happens in a video
        - Extract key moments or actions from video
        - Analyze video content, scenes, or sequences
        - Get descriptions of video footage
        - Identify objects, people, or activities in video

        Maximum file size: 8MB. Supports MP4, MOV, M4V formats.
        """
        try:
            # Validate and process the video file
            vid_path = validate_video_file(video_path)
            base64_data = encode_file_to_base64(vid_path)
            data_uri = create_data_uri(vid_path, base64_data)

            # Call GLM API with video
            result = await call_glm_api(VIDEO_ANALYSIS_PROMPT, prompt, [data_uri])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
