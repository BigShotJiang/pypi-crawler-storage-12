"""
GLM API client for making requests to ZhipuAI's GLM-4.5V model
"""

from typing import List
import httpx
from .config import GLM_API_URL, MODEL_NAME, TEMPERATURE, TOP_P, MAX_TOKENS
from .utils import get_api_key


async def call_glm_api(system_prompt: str, user_prompt: str, media_data_uris: List[str]) -> str:
    """
    Call ZhipuAI GLM API with system prompt, user prompt, and media files

    Args:
        system_prompt: The system-level instructions defining the task and role
        user_prompt: The user's specific request and requirements
        media_data_uris: List of image or video data URIs to include in the request

    Returns:
        str: Model's response content

    Raises:
        RuntimeError: If API request fails or returns unexpected format
    """
    api_key = get_api_key()

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    # Build user content with media (images or videos)
    user_content = []

    # Add all media files first (detect type from data URI)
    for data_uri in media_data_uris:
        # Detect if this is a video or image based on MIME type in data URI
        if data_uri.startswith("data:video/"):
            user_content.append({
                "type": "video_url",
                "video_url": {
                    "url": data_uri
                }
            })
        else:
            # Default to image
            user_content.append({
                "type": "image_url",
                "image_url": {
                    "url": data_uri
                }
            })

    # Add user prompt (from Claude Code)
    user_content.append({
        "type": "text",
        "text": user_prompt
    })

    # Build messages with system and user roles
    payload = {
        "model": MODEL_NAME,
        "messages": [
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": user_content
            }
        ],
        "temperature": TEMPERATURE,
        "top_p": TOP_P,
        "max_tokens": MAX_TOKENS
    }

    async with httpx.AsyncClient(timeout=300.0) as client:
        try:
            response = await client.post(GLM_API_URL, json=payload, headers=headers)
            response.raise_for_status()
            result = response.json()

            # Extract the response content
            if "choices" in result and len(result["choices"]) > 0:
                return result["choices"][0]["message"]["content"]
            else:
                raise ValueError(f"Unexpected API response format: {result}")

        except httpx.HTTPStatusError as e:
            error_detail = ""
            try:
                error_json = e.response.json()
                error_detail = f": {error_json}"
            except:
                error_detail = f": {e.response.text}"
            raise RuntimeError(
                f"GLM API request failed with status {e.response.status_code}{error_detail}"
            )
        except httpx.RequestError as e:
            raise RuntimeError(f"Network error occurred while calling GLM API: {str(e)}")
