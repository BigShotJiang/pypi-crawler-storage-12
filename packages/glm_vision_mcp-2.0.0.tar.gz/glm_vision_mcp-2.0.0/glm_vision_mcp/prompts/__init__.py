"""
System prompts for GLM Vision MCP tools
Import all prompts from individual modules
"""

from .ui_to_artifact import UI_TO_ARTIFACT_PROMPTS
from .text_extraction import TEXT_EXTRACTION_PROMPT
from .error_diagnosis import ERROR_DIAGNOSIS_PROMPT
from .diagram_analysis import DIAGRAM_UNDERSTANDING_PROMPT
from .data_viz import DATA_VIZ_ANALYSIS_PROMPT
from .ui_diff import UI_DIFF_CHECK_PROMPT
from .video_analysis import VIDEO_ANALYSIS_PROMPT
from .general_image import GENERAL_IMAGE_ANALYSIS_PROMPT

__all__ = [
    "UI_TO_ARTIFACT_PROMPTS",
    "TEXT_EXTRACTION_PROMPT",
    "ERROR_DIAGNOSIS_PROMPT",
    "DIAGRAM_UNDERSTANDING_PROMPT",
    "DATA_VIZ_ANALYSIS_PROMPT",
    "UI_DIFF_CHECK_PROMPT",
    "VIDEO_ANALYSIS_PROMPT",
    "GENERAL_IMAGE_ANALYSIS_PROMPT",
]
