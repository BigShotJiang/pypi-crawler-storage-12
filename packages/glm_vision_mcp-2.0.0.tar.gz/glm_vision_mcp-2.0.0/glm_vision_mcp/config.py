"""
Configuration constants for GLM Vision MCP Server
"""

# File size limits
MAX_IMAGE_SIZE = 5 * 1024 * 1024  # 5MB
MAX_VIDEO_SIZE = 8 * 1024 * 1024  # 8MB

# Supported file formats
SUPPORTED_IMAGE_FORMATS = {'.png', '.jpg', '.jpeg'}
SUPPORTED_VIDEO_FORMATS = {'.mp4', '.mov', '.m4v'}

# GLM API configuration
GLM_API_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
MODEL_NAME = "glm-4.5v"

# Model parameters
TEMPERATURE = 0.8  # Controls randomness (0.0-1.0)
TOP_P = 0.6        # Nucleus sampling parameter (0.0-1.0)
MAX_TOKENS = 16384 # Maximum response length

# Server metadata
SERVER_NAME = "GLM Vision Scene Server"
SERVER_VERSION = "1.0.0"
SERVER_INSTRUCTIONS = "Provides specialized vision analysis tools for common developer scenarios using ZhipuAI's GLM-4.5V model"
