# GLM Vision MCP Server

🚀 AI-powered image and video analysis tools for Claude Code, powered by ZhipuAI's GLM-4.5V model.

## Features

This MCP server provides 8 specialized tools for common developer scenarios:

- **🎨 ui_to_artifact** - Convert UI screenshots to code, prompts, specs, or descriptions
- **📝 extract_text_from_screenshot** - Extract code, terminal output, or any text from screenshots
- **🐛 diagnose_error_screenshot** - Analyze and fix errors from screenshots
- **📊 understand_technical_diagram** - Interpret architecture diagrams, flowcharts, UML, and ER diagrams
- **📈 analyze_data_visualization** - Extract insights from charts, graphs, and dashboards
- **🔍 ui_diff_check** - Compare design mockups vs implementations for QA
- **🎥 analyze_video** - Understand video content and extract information
- **🖼️ analyze_image** - General-purpose image analysis for any scenario

## Quick Start

### Prerequisites

1. **Get API Key**: Register at [ZhipuAI Platform](https://open.bigmodel.cn/) and create an API key
2. **Install uv**: `curl -LsSf https://astral.sh/uv/install.sh | sh` (macOS/Linux) or `powershell -c "irm https://astral.sh/uv/install.ps1 | iex"` (Windows)
3. **Set API Key**: `export ZHIPU_API_KEY="your_api_key_here"`

### Installation

**Option 1: Using uvx (Recommended - fastest and simplest)**

```bash
claude mcp add glm-vision \
  --env ZHIPU_API_KEY=your_api_key \
  -- uvx glm-vision-mcp
```

**Option 2: Using pipx**

```bash
claude mcp add glm-vision \
  --env ZHIPU_API_KEY=your_api_key \
  -- pipx run glm-vision-mcp
```

**Option 3: From source (for development)**

```bash
# Clone the repository
git clone https://github.com/yourusername/glm-vision-mcp.git
cd glm-vision-mcp

# Install with uv
claude mcp add glm-vision \
  --env ZHIPU_API_KEY=your_api_key \
  -- uv run --with fastmcp --with httpx fastmcp run glm_vision_mcp/server.py
```

Replace `your_api_key` with your actual ZhipuAI API key.

### Manual Installation

1. Install the package globally:
```bash
npm install -g @zhipu/glm-mcp-server
```

2. Set the environment variable:
```bash
export Z_AI_API_KEY=your_api_key
```

3. Run the server:
```bash
glm-mcp-server
```

## Configuration

The server requires the `Z_AI_API_KEY` environment variable to be set. You can obtain an API key from [ZhipuAI](https://open.bigmodel.cn/).

### Claude Code MCP Configuration

Add to your Claude Code MCP settings:

```json
{
  "mcpServers": {
    "glm-mcp-server": {
      "command": "npx",
      "args": ["-y", "@zhipu/glm-mcp-server"],
      "env": {
        "Z_AI_API_KEY": "your_api_key"
      }
    }
  }
}
```

## Usage Examples

### Extract Text from Screenshot

```
Extract the code from this screenshot: /path/to/code-screenshot.png
```

### Analyze UI Design

```
Convert this UI mockup to React code: /path/to/design.png
```

### Diagnose Errors

```
Help me understand this error: /path/to/error-screenshot.png
```

### Compare UI Versions

```
Compare these two screenshots for visual differences: /path/to/before.png and /path/to/after.png
```

## Supported File Formats

- **Images**: PNG, JPG, JPEG (max 5MB)
- **Videos**: MP4, MOV, M4V (max 8MB)

## Model Parameters

- **Model**: glm-4.5v
- **Temperature**: 0.8
- **Top P**: 0.6
- **Max Tokens**: 16384

## Development

### Local Development

1. Clone the repository
2. Install dependencies: `npm install`
3. Set environment variable: `export Z_AI_API_KEY=your_api_key`
4. Test locally: `npm test`

### Publishing

```bash
npm publish --access public
```

## Technical Architecture

- **Framework**: FastMCP 2.0
- **HTTP Client**: httpx (async)
- **Encoding**: Base64 + Data URI
- **Communication**: Stdio mode

## License

MIT

## Support

For issues and feature requests, please visit the [GitHub repository](https://github.com/yourusername/glm-mcp-server).
