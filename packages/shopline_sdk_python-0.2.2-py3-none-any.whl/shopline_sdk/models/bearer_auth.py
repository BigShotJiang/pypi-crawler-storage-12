"""Shopline API 数据模型 - bearerAuth"""

from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, Field
from typing_extensions import Literal


class bearerAuth(BaseModel):
    pass