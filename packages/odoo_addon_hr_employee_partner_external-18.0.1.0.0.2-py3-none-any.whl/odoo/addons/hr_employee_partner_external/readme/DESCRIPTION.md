Add the following fields to employee

- is_external
- hr_external_partner_id
