Associates a Partner to an Employee to indicate that this Employee is
administrated by the Partner but works in the Company.

This Employee can be a real person or a "virtual" one: on second case is
the Partner that defines the "real" person who works when requested.

On Employees select an Employee and check option that he is an external,
then associate the Partner.
