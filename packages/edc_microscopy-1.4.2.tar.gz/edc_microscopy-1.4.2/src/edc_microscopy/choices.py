from clinicedc_constants import MICROSCOPY, NOT_APPLICABLE, RAPID_TEST

MALARIA_TEST_CHOICES = (
    (RAPID_TEST, "Rapid test"),
    (MICROSCOPY, "Microscopy"),
    (NOT_APPLICABLE, "Not applicable"),
)
