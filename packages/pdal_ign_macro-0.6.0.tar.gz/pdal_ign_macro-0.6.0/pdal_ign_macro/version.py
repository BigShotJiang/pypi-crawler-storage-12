__version__ = "0.6.0"


if __name__ == "__main__":
    print(__version__)
