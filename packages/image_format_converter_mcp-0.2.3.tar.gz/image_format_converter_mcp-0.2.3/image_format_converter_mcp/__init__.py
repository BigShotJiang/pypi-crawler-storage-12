"""Image Convertor MCP - Model Context Protocol Server for Image Processing."""

__version__ = "0.1.6"
__author__ = "Beta"
