#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
CLI entry point for py-subconverter
"""

from .cli import main

if __name__ == "__main__":
    main()
