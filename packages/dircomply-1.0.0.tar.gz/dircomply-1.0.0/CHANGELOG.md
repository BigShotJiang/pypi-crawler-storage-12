# Changelog
## Version 1.0.0 - 15-11-2025

- Added LICENSE and MANIFEST.in
- Create first AUR Release

## Version 0.9.0 - 12-11-2025

- Added existence check these extensions- ".pdf",
- Added content check these extensions- ".ini", ".in", ".sh", ".gitignore"

## Version 0.8.0 - 21-09-2025

- Added existence check these extensions- ".xlsx", ".csv", ".docx",".png", ".jpeg", ".jpg", ".ods"

## Version 0.7.0 - 20-09-2025

- Added file support on ".yaml", ".yml"

## Version 0.6.0 - 19-06-2025

- Added file support on ".md",".tcl"

## Version 0.5.0 - 17-06-2025

- Added file support on ".json", ".ts", ".scss" for angular dev.

## Version 0.4.0 - 08-04-2025

- Report shows both folder paths in top for quick reference.

## Version 0.3.0 - 08-04-2025

- Show Folder Paths dynamically in report.

## Version 0.2.0 - 07-04-2025

- Added sort feature in all output files list. (Path)
- Updated readme and changelog.
- Added compare on cli mode.

## Version 0.1 - 18-12-2024

- The app will compare two folders and show the difference in ".txt", ".py", ".bat", ".html" files in both repo.
- Along with app will display unique files for each repo.
