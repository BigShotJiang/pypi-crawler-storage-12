"""
version.py

Author: Benevant Mathew
Date: 2025-11-15
"""
__version__ = "1.0.0"
__author__ = "Benevant Mathew"
__email__ = "benevantmathewv@gmail.com"
__release_date__="15-11-2025"

if __name__ == "__main__":
    print(__version__)
