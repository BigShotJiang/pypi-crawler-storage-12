"""
config.py

Author: Benevant Mathew
Date: 2025-09-21
"""
from dircomply.utils import load_extensions

content_exts, existence_exts = load_extensions()
