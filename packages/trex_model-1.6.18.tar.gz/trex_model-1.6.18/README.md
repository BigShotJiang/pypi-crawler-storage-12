This is database modelusing google datastore mode module
