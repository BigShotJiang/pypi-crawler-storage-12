.. _optimizer:

Optimizer
=========

.. module:: mlip.training.optimizer

    .. autofunction:: get_default_mlip_optimizer

    .. autofunction:: get_mlip_optimizer_chain_with_flexible_base_optimizer

.. module:: mlip.training.optimizer_config

    .. autoclass:: OptimizerConfig

        .. automethod:: __init__
