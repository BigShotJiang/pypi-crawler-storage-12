.. _jaxmd_sim_config:

.. module:: mlip.simulation.configs.jax_md_config

JAX-MD Simulation Config
========================

.. autoclass:: JaxMDSimulationConfig
