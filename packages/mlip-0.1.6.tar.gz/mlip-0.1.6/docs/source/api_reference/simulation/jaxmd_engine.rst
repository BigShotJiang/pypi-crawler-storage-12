.. _jaxmd_simulation_engine:

.. module:: mlip.simulation.jax_md.jax_md_simulation_engine

JAX-MD Simulation Engine
========================

.. autoclass:: JaxMDSimulationEngine

    .. automethod:: __init__

    .. automethod:: run

    .. automethod:: attach_logger
