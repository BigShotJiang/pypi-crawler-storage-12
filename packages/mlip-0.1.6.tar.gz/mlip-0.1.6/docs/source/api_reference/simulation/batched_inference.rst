.. _batched_inference:

.. module:: mlip.inference.batched_inference

Batched inference
=================

.. autofunction:: run_batched_inference
