.. _nequip:

NequIP
======

.. module:: mlip.models.nequip.models

    .. autoclass:: Nequip

        .. automethod:: __call__

.. module:: mlip.models.nequip.config

    .. autoclass:: NequipConfig
