.. _chemical_systems_reader:

.. module:: mlip.data.chemical_systems_readers.chemical_systems_reader

Chemical Systems Reader: Interface
==================================

.. autoclass:: ChemicalSystemsReader

    .. automethod:: __init__

    .. automethod:: load
