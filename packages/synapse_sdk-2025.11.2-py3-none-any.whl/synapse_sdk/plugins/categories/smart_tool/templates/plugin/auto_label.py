class MyAutoLabel:
    def __init__(self, **kwargs):
        pass

    def handle_input(self, input_data):
        """smart tool의 input을 model의 input 형태로 변환"""
        return

    def handle_output(self, output_data):
        """model의 output을 smart tool의 output 형태로 변환"""
        return
