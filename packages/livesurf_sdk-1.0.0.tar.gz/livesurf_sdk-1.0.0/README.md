# LiveSurf SDK (Python)

- NodeJS SDK для LiveSurf API (https://api.livesurf.ru/).
- Документация API (https://livesurf.ru/api_documentation.html)
- Получить API-ключ (https://livesurf.ru/api)

---


## 🧩 Возможности

- Авторизация по API ключу
- Все методы API LiveSurf
- Повтор запросов при 429/5xx
- Лимит 10 запросов/сек
- Простая интеграция и читаемые исключения

---

## 📦 Установка

```bash
pip install livesurf-sdk
```

---

## 🚀 Пример использования

```python
from livesurf_sdk.api import LiveSurfApi

api = LiveSurfApi("ВАШ_API_КЛЮЧ")

user = api.get_user()
print(user)
```

---

## ⚙️ Дополнительные параметры

```python
api = LiveSurfApi("API_KEY", timeout=20, rate_limit=5, max_retries=5)
```

---

## Доступные методы API

### Пользователь
| Метод | Описание |
|-------|----------|
| `getUser()` | Получение информации о пользователе |
| `setAutoMode()` | Включение автоматического режима (АРК) |
| `setManualMode()` | Включение ручного режима работы |

### Категории, страны, языки, источники
| Метод | Описание |
|-------|----------|
| `getCategories()` | Список возможных категорий |
| `getCountries()` | Список возможных стран |
| `getLanguages()` | Список доступных языков |
| `getSourcesAd()` | Список рекламных площадок |
| `getSourcesMessengers()` | Список мессенджеров |
| `getSourcesSearch()` | Список поисковых систем |
| `getSourcesSocial()` | Список социальных сетей |

### Группы
| Метод | Описание |
|-------|----------|
| `getGroups()` | Информация о всех добавленных группах |
| `getGroup(id)` | Информация о конкретной группе |
| `updateGroup(id, data)` | Изменение настроек группы |
| `deleteGroup(id)` | Удаление группы |
| `createGroup(data)` | Создание новой группы |
| `cloneGroup(id, name)` | Клонирование группы |
| `addGroupCredits(id, credits)` | Зачисление кредитов группы |

### Страницы
| Метод | Описание |
|-------|----------|
| `getPage(id)` | Информация о конкретной странице |
| `updatePage(id, data)` | Изменение настроек страницы |
| `deletePage(id)` | Удаление страницы |
| `createPage(data)` | Создание новой страницы |
| `clonePage(id)` | Клонирование страницы |
| `movePageUp(id)` | Перемещение страницы вверх |
| `movePageDown(id)` | Перемещение страницы вниз |
| `startPage(id)` | Запуск страницы в работу |
| `stopPage(id)` | Остановка работы страницы |
| `getStats(params)` | Статистика показа страницы |

## Лицензия

MIT License — свободное использование, копирование и модификация.
