"""
Utility functions and helpers
""" 