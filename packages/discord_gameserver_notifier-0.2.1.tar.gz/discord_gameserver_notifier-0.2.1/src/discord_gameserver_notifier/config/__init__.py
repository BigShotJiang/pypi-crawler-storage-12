"""
Configuration management package
""" 