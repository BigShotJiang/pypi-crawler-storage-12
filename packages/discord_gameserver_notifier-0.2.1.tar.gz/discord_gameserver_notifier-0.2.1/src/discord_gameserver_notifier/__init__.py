"""
Discord Gameserver Notifier - Main Package
""" 