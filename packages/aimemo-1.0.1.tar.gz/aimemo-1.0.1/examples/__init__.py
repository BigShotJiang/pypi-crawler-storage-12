"""
Examples for AIMemo
"""

