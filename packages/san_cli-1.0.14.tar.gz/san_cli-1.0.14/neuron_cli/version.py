"""Version information for Neuron CLI"""

__version__ = "1.0.14"  # SAN CLI (SPACE Agent Neuron CLI) - No Hardcoded Credentials
__author__ = "Kai Gartner (https://linkedin.com/in/kaigartner)"
__license__ = "Commercial - All Rights Reserved"
