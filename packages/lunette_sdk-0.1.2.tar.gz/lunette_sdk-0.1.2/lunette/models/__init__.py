"""Lunette models for working with Inspect AI trajectories."""
