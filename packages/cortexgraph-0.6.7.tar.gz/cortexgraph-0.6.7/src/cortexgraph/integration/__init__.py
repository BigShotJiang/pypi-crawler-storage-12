"""Integration layer for external systems."""

from .basic_memory import BasicMemoryIntegration

__all__ = ["BasicMemoryIntegration"]
