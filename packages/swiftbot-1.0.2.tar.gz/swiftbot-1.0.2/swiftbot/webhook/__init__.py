"""
Webhook server
Copyright (c) 2025 Arjun-M/SwiftBot
"""

from .server import WebhookServer

__all__ = ["WebhookServer"]
