"""
Telegram Bot API wrapper
Copyright (c) 2025 Arjun-M/SwiftBot
"""

from .telegram import TelegramAPI

__all__ = ["TelegramAPI"]
