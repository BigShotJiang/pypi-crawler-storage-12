"""
CLI interface for mimir_io.

Provides commands for:
- Running training from configs
- Cache management
- Pipeline profiling
- Model testing
- Running comparative benchmarks
"""

import click
import json
from pathlib import Path
from typing import List, Optional, Dict, Any
import sys

try:
    import torch
    import torch.nn as nn
    _torch_available = True
except ImportError:
    _torch_available = False
    torch = None
    nn = None

from mimir_io import Dataset
from mimir_io.experiment import (
    quick_train,
    quick_test,
    train_from_config_file,
    ExperimentConfig,
)
from mimir_io.models import (
    create_model,
    load_config,
    BaseTrainer,
    BaseTester,
)
from mimir_io.models.benchmark import run_benchmarks, list_benchmarks
from mimir_io.models.compare_experiments import compare_experiments, ExperimentComparator
from mimir_io.models.experiment_results import ExperimentResultsManager
from mimir_io.profiling import (
    profile_pipeline,
    print_profile_report,
    generate_html_report,
    generate_recommendations,
)
from mimir_io.experiment import find_experiment_files
from mimir_io import __version__


@click.group()
@click.version_option(version=__version__)
def cli():
    """mimir_io - End-to-end ML workflow framework CLI."""
    pass


# ========== TRAIN COMMAND ==========

@cli.command()
@click.argument('config_path', type=click.Path(exists=True))
@click.option('--model-name', help='Name of registered model (if using model registry)')
@click.option('--data-dir', type=click.Path(exists=True), help='Data directory (overrides config)')
@click.option('--split-path', type=click.Path(), help='Path to dataset split file')
@click.option('--device', help='Device to use (cuda/cpu, default: auto-detect)')
@click.option('--checkpoint-dir', type=click.Path(), help='Directory to save checkpoints')
@click.option('--no-benchmarks', is_flag=True, help='Skip running benchmarks after training')
@click.option('--no-results', is_flag=True, help='Skip saving experiment results')
def train(
    config_path: str,
    model_name: Optional[str],
    data_dir: Optional[str],
    split_path: Optional[str],
    device: Optional[str],
    checkpoint_dir: Optional[str],
    no_benchmarks: bool,
    no_results: bool,
):
    """
    Run training from a configuration file.
    
    CONFIG_PATH: Path to YAML configuration file
    """
    if not _torch_available:
        click.echo("Error: PyTorch is required for training. Install with: pip install torch", err=True)
        sys.exit(1)
    
    try:
        # Load configuration
        config_dict = load_config(config_path)
        
        # Override parameters from command line
        if data_dir:
            config_dict.setdefault('data', {})['data_dir'] = data_dir
        if checkpoint_dir:
            config_dict.setdefault('training', {})['save_dir'] = checkpoint_dir
        if device:
            config_dict.setdefault('training', {})['device'] = device
        
        # Create model
        if model_name:
            model = create_model(model_name, config_dict.get('model', {}))
        elif 'model' in config_dict and 'name' in config_dict['model']:
            model = create_model(
                config_dict['model']['name'],
                config_dict['model']
            )
        else:
            click.echo("Error: Model name not specified. Use --model-name or specify in config.", err=True)
            sys.exit(1)
        
        # Prepare files
        data_dir_path = Path(config_dict.get('data', {}).get('data_dir', './data'))
        file_paths = list(data_dir_path.glob('**/*.wav'))
        
        if not file_paths:
            click.echo(f"Warning: No WAV files found in {data_dir_path}", err=True)
        
        # Create experiment configuration
        exp_config = ExperimentConfig(**config_dict)
        exp_config.run_benchmarks = not no_benchmarks
        exp_config.save_results = not no_results
        
        # Start training
        click.echo(f"Starting training with config: {config_path}")
        click.echo(f"Model: {model_name or config_dict.get('model', {}).get('name', 'unknown')}")
        click.echo(f"Data directory: {data_dir_path}")
        click.echo(f"Number of files: {len(file_paths)}")
        
        trainer = quick_train(
            model=model,
            file_paths=file_paths,
            config=exp_config,
            split_path=split_path,
        )
        
        click.echo("\nTraining completed successfully!")
        click.echo(f"Checkpoints saved to: {trainer.save_dir}")
        
    except Exception as e:
        click.echo(f"Error during training: {e}", err=True)
        import traceback
        if '--debug' in sys.argv:
            traceback.print_exc()
        sys.exit(1)


# ========== CACHE COMMAND ==========

@cli.group()
def cache():
    """Cache management."""
    pass


@cache.command('info')
@click.argument('data_dir', type=click.Path(exists=True), default='./data')
@click.option('--format', 'output_format', type=click.Choice(['text', 'json']), default='text')
def cache_info(data_dir: str, output_format: str):
    """Show cache information."""
    dataset = Dataset(data_dir=data_dir)
    stats = dataset.cache_stats()
    
    if output_format == 'json':
        click.echo(json.dumps(stats, indent=2))
    else:
        click.echo("\nCache Statistics:")
        click.echo(f"  Total files: {stats['total_files']}")
        click.echo(f"  Total size: {stats['total_size_mb']:.2f} MB")
        click.echo(f"  Total size: {stats['total_size_bytes']:,} bytes")
        
        if stats['by_extension']:
            click.echo("\n  By extension:")
            for ext, ext_stats in sorted(stats['by_extension'].items()):
                click.echo(
                    f"    {ext}: {ext_stats['count']} files, "
                    f"{ext_stats['size_mb']:.2f} MB"
                )


@cache.command('clear')
@click.argument('data_dir', type=click.Path(exists=True), default='./data')
@click.option('--pattern', help='Glob pattern to match files (e.g., "*.wav")')
@click.option('--yes', '-y', is_flag=True, help='Skip confirmation')
def cache_clear(data_dir: str, pattern: Optional[str], yes: bool):
    """Clear cache."""
    dataset = Dataset(data_dir=data_dir)
    stats = dataset.cache_stats()
    
    if pattern:
        message = f"Clear cache files matching '{pattern}'? ({stats['total_files']} files)"
    else:
        message = f"Clear all cache? ({stats['total_files']} files, {stats['total_size_mb']:.2f} MB)"
    
    if not yes:
        if not click.confirm(message):
            click.echo("Cancelled.")
            return
    
    deleted = dataset.clear_cache(pattern=pattern)
    click.echo(f"Deleted {deleted} cache files.")


@cache.command('list')
@click.argument('data_dir', type=click.Path(exists=True), default='./data')
@click.option('--pattern', help='Glob pattern to match files')
@click.option('--limit', type=int, default=100, help='Maximum number of files to show')
def cache_list(data_dir: str, pattern: Optional[str], limit: int):
    """List files in cache."""
    dataset = Dataset(data_dir=data_dir)
    keys = dataset.list_cached_keys(pattern=pattern)
    
    if not keys:
        click.echo("Cache is empty.")
        return
    
    click.echo(f"\nFound {len(keys)} cached files:")
    if pattern:
        click.echo(f"Pattern: {pattern}")
    
    for i, key in enumerate(keys[:limit]):
        info = dataset.get_cache_info(key)
        if info:
            size_mb = info['size_bytes'] / (1024 * 1024)
            click.echo(f"  {key} ({size_mb:.2f} MB)")
        else:
            click.echo(f"  {key}")
    
    if len(keys) > limit:
        click.echo(f"\n... and {len(keys) - limit} more files")


# ========== PROFILE COMMAND ==========

@cli.command()
@click.argument('data_dir', type=click.Path(exists=True))
@click.argument('pipeline_file', type=click.Path(exists=True))
@click.argument('sample_data_file', type=click.Path(exists=True))
@click.option('--runs', type=int, default=5, help='Number of runs for averaging')
@click.option('--warmup', type=int, default=1, help='Number of warmup runs')
@click.option('--output', type=click.Path(), help='Save report to file (JSON)')
@click.option('--html', type=click.Path(), help='Generate interactive HTML report')
@click.option('--show-recommendations', is_flag=True, help='Show optimization recommendations')
def profile(
    data_dir: str,
    pipeline_file: str,
    sample_data_file: str,
    runs: int,
    warmup: int,
    output: Optional[str],
    html: Optional[str],
    show_recommendations: bool,
):
    """
    Profile a data processing pipeline.
    
    PIPELINE_FILE: Python file with pipeline definition (variable 'pipeline')
    SAMPLE_DATA_FILE: Path to file with test data
    """
    try:
        # Load pipeline
        import importlib.util
        spec = importlib.util.spec_from_file_location("pipeline_module", pipeline_file)
        pipeline_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(pipeline_module)
        
        if not hasattr(pipeline_module, 'pipeline'):
            click.echo(f"Error: 'pipeline' variable not found in {pipeline_file}", err=True)
            sys.exit(1)
        
        pipeline = pipeline_module.pipeline
        
        # Load test data
        sample_path = Path(sample_data_file)
        dataset = Dataset(data_dir=data_dir)
        
        # Try to load as audio
        try:
            from mimir_io.rayframe import load_audio_frame
            sample_data = dataset.apply(load_audio_frame(sample_path), None)
            sample_data = sample_data.data if hasattr(sample_data, 'data') else sample_data
        except Exception:
            # If not audio, try as pickle
            import pickle
            with open(sample_path, 'rb') as f:
                sample_data = pickle.load(f)
        
        # Profiling
        click.echo(f"Profiling pipeline from {pipeline_file}")
        click.echo(f"Sample data: {sample_data_file}")
        click.echo(f"Runs: {runs}, Warmup: {warmup}")
        
        stats = profile_pipeline(
            dataset=dataset,
            lens=pipeline,
            data=sample_data,
            num_runs=runs,
            warmup_runs=warmup,
        )
        
        # Print report
        print_profile_report(stats)
        
        # Show recommendations if needed
        if show_recommendations:
            recommendations = generate_recommendations(stats)
            if recommendations:
                click.echo("\n" + "=" * 60)
                click.echo("Optimization Recommendations:")
                click.echo("=" * 60)
                for rec in recommendations:
                    priority = rec.get('priority', 'low').upper()
                    click.echo(f"\n[{priority}] {rec.get('title', 'Recommendation')}")
                    click.echo(f"  {rec.get('description', '')}")
                    click.echo(f"  💡 {rec.get('suggestion', '')}")
                click.echo("\n" + "=" * 60)
        
        # Generate HTML report
        if html:
            generate_html_report(stats, output_path=html)
            click.echo(f"\nInteractive HTML report saved to: {html}")
        
        # Save to file (JSON)
        if output:
            with open(output, 'w') as f:
                json.dump(stats, f, indent=2)
            click.echo(f"JSON report saved to: {output}")
    
    except Exception as e:
        click.echo(f"Error during profiling: {e}", err=True)
        import traceback
        if '--debug' in sys.argv:
            traceback.print_exc()
        sys.exit(1)


# ========== TEST COMMAND ==========

@cli.command()
@click.argument('config_path', type=click.Path(exists=True), required=False)
@click.argument('checkpoint_path', type=click.Path(exists=True), required=False)
@click.option('--experiment-dir', type=click.Path(exists=True), help='Path to experiment directory (alternative to config_path and checkpoint_path)')
@click.option('--model-name', help='Name of registered model')
@click.option('--split-path', type=click.Path(), help='Path to dataset split file')
@click.option('--test-files', multiple=True, help='Test files (if not using split)')
@click.option('--device', help='Device to use (cuda/cpu)')
@click.option('--no-benchmarks', is_flag=True, help='Skip running benchmarks')
def test(
    config_path: Optional[str],
    checkpoint_path: Optional[str],
    experiment_dir: Optional[str],
    model_name: Optional[str],
    split_path: Optional[str],
    test_files: tuple,
    device: Optional[str],
    no_benchmarks: bool,
):
    """
    Test a model.
    
    You can specify either CONFIG_PATH and CHECKPOINT_PATH separately, or --experiment-dir.
    
    CONFIG_PATH: Path to configuration file (required if --experiment-dir is not used)
    CHECKPOINT_PATH: Path to checkpoint file with model weights (required if --experiment-dir is not used)
    """
    if not _torch_available:
        click.echo("Error: PyTorch is required for testing.", err=True)
        sys.exit(1)
    
    # Handle experiment_dir option
    if experiment_dir:
        if config_path or checkpoint_path:
            click.echo("Warning: --experiment-dir specified, ignoring config_path and checkpoint_path arguments", err=True)
        
        exp_files = find_experiment_files(experiment_dir)
        
        if not exp_files["checkpoint"]:
            click.echo(f"Error: Checkpoint file not found in experiment directory: {experiment_dir}", err=True)
            click.echo("Expected: best_model.pt or checkpoint_epoch_*.pt", err=True)
            sys.exit(1)
        
        if not exp_files["config"]:
            click.echo(f"Error: Config file not found in experiment directory: {experiment_dir}", err=True)
            click.echo("Expected: config.yaml or config.yml", err=True)
            sys.exit(1)
        
        checkpoint_path = str(exp_files["checkpoint"])
        config_path = str(exp_files["config"])
        
        # Use split from experiment directory if not specified otherwise
        if not split_path and exp_files["split"]:
            split_path = str(exp_files["split"])
        
        click.echo(f"Using experiment directory: {experiment_dir}")
        click.echo(f"  Config: {config_path}")
        click.echo(f"  Checkpoint: {checkpoint_path}")
        if split_path:
            click.echo(f"  Split: {split_path}")
    else:
        # Check required arguments
        if not config_path:
            click.echo("Error: CONFIG_PATH is required or use --experiment-dir", err=True)
            sys.exit(1)
        
        if not checkpoint_path:
            click.echo("Error: CHECKPOINT_PATH is required or use --experiment-dir", err=True)
            sys.exit(1)
    
    try:
        # Load configuration
        config_dict = load_config(config_path)
        
        # Create model
        if model_name:
            model = create_model(model_name, config_dict.get('model', {}))
        elif 'model' in config_dict and 'name' in config_dict['model']:
            model = create_model(
                config_dict['model']['name'],
                config_dict['model']
            )
        else:
            click.echo("Error: Model name not specified.", err=True)
            sys.exit(1)
        
        # Prepare configuration
        exp_config = ExperimentConfig(**config_dict)
        exp_config.run_benchmarks = not no_benchmarks
        
        # Prepare test files
        file_paths = list(test_files) if test_files else None
        
        # Start testing
        click.echo(f"Testing model: {model_name or config_dict.get('model', {}).get('name', 'unknown')}")
        click.echo(f"Checkpoint: {checkpoint_path}")
        
        tester = quick_test(
            model=model,
            config=exp_config,
            split_path=split_path,
            file_paths=file_paths,
            checkpoint_path=checkpoint_path,
            use_test_split=split_path is not None,
        )
        
        click.echo("\nTesting completed successfully!")
    
    except Exception as e:
        click.echo(f"Error during testing: {e}", err=True)
        import traceback
        if '--debug' in sys.argv:
            traceback.print_exc()
        sys.exit(1)


# ========== BENCHMARK COMMAND ==========

@cli.group()
def benchmark():
    """Run comparative benchmarks."""
    pass


@benchmark.command('run')
@click.argument('checkpoint_path', type=click.Path(exists=True), required=False)
@click.argument('config_path', type=click.Path(exists=True), required=False)
@click.option('--experiment-dir', type=click.Path(exists=True), help='Path to experiment directory (alternative to config_path and checkpoint_path)')
@click.option('--model-name', help='Name of registered model')
@click.option('--split-path', type=click.Path(), help='Path to dataset split file')
@click.option('--benchmarks', multiple=True, help='Specific benchmarks to run (default: all)')
@click.option('--device', help='Device to use (cuda/cpu)')
@click.option('--output', type=click.Path(), help='Save results to JSON file')
def benchmark_run(
    checkpoint_path: Optional[str],
    config_path: Optional[str],
    experiment_dir: Optional[str],
    model_name: Optional[str],
    split_path: Optional[str],
    benchmarks: tuple,
    device: Optional[str],
    output: Optional[str],
):
    """
    Run benchmarks for a model.
    
    You can specify either CHECKPOINT_PATH and CONFIG_PATH separately, or --experiment-dir.
    
    CHECKPOINT_PATH: Path to checkpoint file (required if --experiment-dir is not used)
    CONFIG_PATH: Path to configuration file (required if --experiment-dir is not used)
    """
    if not _torch_available:
        click.echo("Error: PyTorch is required for benchmarks.", err=True)
        sys.exit(1)
    
    # Handle experiment_dir option
    if experiment_dir:
        if config_path or checkpoint_path:
            click.echo("Warning: --experiment-dir specified, ignoring config_path and checkpoint_path arguments", err=True)
        
        exp_files = find_experiment_files(experiment_dir)
        
        if not exp_files["checkpoint"]:
            click.echo(f"Error: Checkpoint file not found in experiment directory: {experiment_dir}", err=True)
            click.echo("Expected: best_model.pt or checkpoint_epoch_*.pt", err=True)
            sys.exit(1)
        
        if not exp_files["config"]:
            click.echo(f"Error: Config file not found in experiment directory: {experiment_dir}", err=True)
            click.echo("Expected: config.yaml or config.yml", err=True)
            sys.exit(1)
        
        checkpoint_path = str(exp_files["checkpoint"])
        config_path = str(exp_files["config"])
        
        # Use split from experiment directory if not specified otherwise
        if not split_path and exp_files["split"]:
            split_path = str(exp_files["split"])
        
        click.echo(f"Using experiment directory: {experiment_dir}")
        click.echo(f"  Config: {config_path}")
        click.echo(f"  Checkpoint: {checkpoint_path}")
        if split_path:
            click.echo(f"  Split: {split_path}")
    else:
        # Check required arguments
        if not config_path:
            click.echo("Error: CONFIG_PATH is required or use --experiment-dir", err=True)
            sys.exit(1)
        
        if not checkpoint_path:
            click.echo("Error: CHECKPOINT_PATH is required or use --experiment-dir", err=True)
            sys.exit(1)
    
    try:
        # Load configuration
        config_dict = load_config(config_path)
        
        # Create model
        if model_name:
            model = create_model(model_name, config_dict.get('model', {}))
        elif 'model' in config_dict and 'name' in config_dict['model']:
            model = create_model(
                config_dict['model']['name'],
                config_dict['model']
            )
        else:
            click.echo("Error: Model name not specified.", err=True)
            sys.exit(1)
        
        # Load weights
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        
        checkpoint = torch.load(checkpoint_path, map_location=device)
        if "model_state_dict" in checkpoint:
            model.load_state_dict(checkpoint["model_state_dict"])
        elif "state_dict" in checkpoint:
            model.load_state_dict(checkpoint["state_dict"])
        else:
            model.load_state_dict(checkpoint)
        
        model = model.to(device)
        model.eval()
        
        # Prepare test dataloader
        from mimir_io.experiment import setup_test
        exp_config = ExperimentConfig(**config_dict)
        
        test_loader, _, _ = setup_test(
            file_paths=[],
            config=exp_config,
            split_path=split_path,
            use_test_split=split_path is not None,
        )
        
        # Run benchmarks
        benchmark_names = list(benchmarks) if benchmarks else None
        
        click.echo(f"Running benchmarks for model: {model_name or 'unknown'}")
        if benchmark_names:
            click.echo(f"Benchmarks: {', '.join(benchmark_names)}")
        else:
            click.echo("Running all available benchmarks")
        
        results = run_benchmarks(
            model=model,
            test_loader=test_loader,
            benchmark_names=benchmark_names,
            device=device,
        )
        
        # Print results
        click.echo("\nBenchmark Results:")
        for bench_name, bench_result in results.items():
            if "error" in bench_result:
                click.echo(f"  {bench_name}: ERROR - {bench_result['error']}")
            else:
                click.echo(f"  {bench_name}:")
                for key, value in bench_result.items():
                    if not key.startswith("_"):
                        if isinstance(value, float):
                            click.echo(f"    {key}: {value:.4f}")
                        else:
                            click.echo(f"    {key}: {value}")
        
        # Save results
        if output:
            with open(output, 'w') as f:
                json.dump(results, f, indent=2)
            click.echo(f"\nResults saved to: {output}")
    
    except Exception as e:
        click.echo(f"Error during benchmarking: {e}", err=True)
        import traceback
        if '--debug' in sys.argv:
            traceback.print_exc()
        sys.exit(1)


@benchmark.command('list')
def benchmark_list():
    """List available benchmarks."""
    benchmarks = list_benchmarks()
    
    if not benchmarks:
        click.echo("No benchmarks available.")
        return
    
    click.echo("\nAvailable benchmarks:")
    for bench_name in benchmarks:
        click.echo(f"  - {bench_name}")


@benchmark.command('compare')
@click.argument('experiment_ids', nargs=-1, required=False)
@click.option('--experiment-dirs', multiple=True, help='Paths to experiment directories (alternative to experiment_ids)')
@click.option('--results-dir', type=click.Path(exists=True), default='./experiment_results')
@click.option('--output', type=click.Path(), help='Save comparison report to file')
@click.option('--format', 'report_format', type=click.Choice(['markdown', 'html', 'text']), default='markdown')
def benchmark_compare(
    experiment_ids: tuple,
    experiment_dirs: tuple,
    results_dir: str,
    output: Optional[str],
    report_format: str,
):
    """
    Compare experiment results.
    
    You can specify either EXPERIMENT_IDS or --experiment-dirs.
    
    EXPERIMENT_IDS: List of experiment IDs to compare (required if --experiment-dirs is not used)
    """
    try:
        # Check that at least one method is specified
        if not experiment_ids and not experiment_dirs:
            click.echo("Error: Either EXPERIMENT_IDS or --experiment-dirs must be provided", err=True)
            sys.exit(1)
        
        comparator = compare_experiments(
            experiment_ids=list(experiment_ids) if experiment_ids else None,
            experiment_dirs=list(experiment_dirs) if experiment_dirs else None,
            results_dir=results_dir,
        )
        
        # Generate report
        report = comparator.generate_report(format=report_format)
        
        if output:
            Path(output).write_text(report, encoding='utf-8')
            click.echo(f"Comparison report saved to: {output}")
        else:
            click.echo(report)
    
    except Exception as e:
        click.echo(f"Error during comparison: {e}", err=True)
        import traceback
        if '--debug' in sys.argv:
            traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    cli()

