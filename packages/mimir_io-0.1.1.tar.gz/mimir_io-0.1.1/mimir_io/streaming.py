"""
Streaming Dataset for large datasets that don't fit in memory.

Provides lazy loading with prefetching for efficient data access.
"""

from pathlib import Path
from typing import List, Optional, Any, Union, Callable, Dict
from collections import deque
import threading
import queue
import time
from dataclasses import dataclass

try:
    import torch
    from torch.utils.data import Dataset
    _torch_available = True
except ImportError:
    _torch_available = False
    Dataset = object  # type: ignore

from mimir_io.dataset import Dataset as MimirDataset
from mimir_io.lens import Lens
from mimir_io.rayframe import load_audio_frame

# Import MimirTorchDataset conditionally
if _torch_available:
    try:
        from mimir_io.torch_dataset import MimirTorchDataset
        _mimir_torch_dataset_available = True
    except (ImportError, AttributeError):
        _mimir_torch_dataset_available = False
        MimirTorchDataset = object  # type: ignore
else:
    _mimir_torch_dataset_available = False
    MimirTorchDataset = object  # type: ignore


@dataclass
class PrefetchStats:
    """Statistics about prefetching performance."""
    total_loaded: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    prefetch_queue_size: int = 0
    avg_load_time: float = 0.0


if _mimir_torch_dataset_available:
    _BaseDatasetClass = MimirTorchDataset
else:
    # Fallback base class when MimirTorchDataset is not available
    class _BaseDatasetClass:  # type: ignore
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "StreamingDataset requires PyTorch and MimirTorchDataset. "
                "Install with: pip install torch"
            )


class StreamingDataset(_BaseDatasetClass):
    """
    Streaming Dataset that loads data on-the-fly with prefetching.
    
    Designed for large datasets that don't fit in memory. Data is loaded
    lazily and prefetched in background threads for optimal performance.
    
    Requires PyTorch to be installed.
    
    Example:
        >>> from mimir_io.streaming import StreamingDataset
        >>> from mimir_io.audio import resample, log_mel_spectrogram
        >>>
        >>> # Large dataset with 100k+ files
        >>> streaming_dataset = StreamingDataset(
        ...     mimir_dataset=dataset,
        ...     file_paths=large_file_list,  # Can be millions of files
        ...     transform_pipeline=resample(16000) | log_mel_spectrogram(n_mels=80),
        ...     labels=labels,
        ...     prefetch_size=100,  # Prefetch 100 items ahead
        ...     num_prefetch_workers=4,  # Use 4 threads for prefetching
        ... )
        >>>
        >>> loader = DataLoader(streaming_dataset, batch_size=32, num_workers=4)
        >>> for batch in loader:
        ...     # Data is loaded on-the-fly, memory efficient!
        ...     pass
    """
    
    def __init__(
        self,
        mimir_dataset: MimirDataset,
        file_paths: List[Union[str, Path]],
        transform_pipeline: Lens,
        labels: Optional[List[Any]] = None,
        use_augmentation: bool = False,
        augmentation_pipeline: Optional[Lens] = None,
        load_audio_lens: Optional[Lens] = None,
        collate_fn: Optional[Callable] = None,
        epoch: Optional[int] = None,
        prefetch_size: int = 100,
        num_prefetch_workers: int = 2,
        enable_prefetch: bool = True,
        max_prefetch_wait: float = 5.0,
    ):
        """
        Initialize Streaming Dataset.
        
        Args:
            mimir_dataset: Instance of mimir_io.Dataset for caching
            file_paths: List of paths to files (can be very large)
            transform_pipeline: Lens with transformation pipeline
            labels: Optional labels for each file
            use_augmentation: Whether to use augmentations
            augmentation_pipeline: Lens with augmentation pipeline
            load_audio_lens: Custom lens for loading (defaults to load_audio_frame)
            collate_fn: Custom function for batching
            epoch: Optional epoch number for different augmentations each epoch
            prefetch_size: Number of items to prefetch ahead (default: 100)
            num_prefetch_workers: Number of threads for prefetching (default: 2)
            enable_prefetch: Whether to enable prefetching (default: True)
            max_prefetch_wait: Maximum time to wait for prefetch (seconds, default: 5.0)
        """
        # Initialize base class
        super().__init__(
            mimir_dataset=mimir_dataset,
            file_paths=file_paths,
            transform_pipeline=transform_pipeline,
            labels=labels,
            use_augmentation=use_augmentation,
            augmentation_pipeline=augmentation_pipeline,
            load_audio_lens=load_audio_lens,
            collate_fn=collate_fn,
            epoch=epoch,
        )
        
        # Streaming-specific parameters
        self.prefetch_size = prefetch_size
        self.num_prefetch_workers = num_prefetch_workers
        self.enable_prefetch = enable_prefetch
        self.max_prefetch_wait = max_prefetch_wait
        
        # Prefetching infrastructure
        self._prefetch_queue: Optional[queue.Queue] = None
        self._prefetch_threads: List[threading.Thread] = []
        self._prefetch_stop_event = threading.Event()
        self._prefetch_stats = PrefetchStats()
        self._prefetch_lock = threading.Lock()
        
        # Current position tracking for prefetching
        self._current_idx = 0
        self._prefetched_items: Dict[int, Any] = {}
        self._prefetch_order = deque()
        
        # Start prefetching if enabled
        if self.enable_prefetch and len(self.file_paths) > 0:
            self._start_prefetching()
    
    def _start_prefetching(self) -> None:
        """Start background prefetching threads."""
        if self.num_prefetch_workers <= 0:
            return
        
        self._prefetch_queue = queue.Queue(maxsize=self.prefetch_size * 2)
        self._prefetch_stop_event.clear()
        
        # Start prefetch workers
        for i in range(self.num_prefetch_workers):
            thread = threading.Thread(
                target=self._prefetch_worker,
                args=(i,),
                daemon=True,
                name=f"PrefetchWorker-{i}",
            )
            thread.start()
            self._prefetch_threads.append(thread)
        
        # Initial prefetch
        self._request_prefetch(range(min(self.prefetch_size, len(self.file_paths))))
    
    def _request_prefetch(self, indices: Union[range, List[int]]) -> None:
        """Request prefetching of specific indices."""
        if not self.enable_prefetch or self._prefetch_queue is None:
            return
        
        for idx in indices:
            if idx < len(self.file_paths) and idx not in self._prefetched_items:
                try:
                    self._prefetch_queue.put_nowait(idx)
                except queue.Full:
                    # Queue is full, skip
                    break
    
    def _prefetch_worker(self, worker_id: int) -> None:
        """Worker thread that prefetches data."""
        while not self._prefetch_stop_event.is_set():
            try:
                # Get index to prefetch (with timeout to check stop event)
                idx = self._prefetch_queue.get(timeout=0.1)
                
                # Skip if already prefetched
                if idx in self._prefetched_items:
                    self._prefetch_queue.task_done()
                    continue
                
                # Load and process data
                start_time = time.time()
                try:
                    result = self._load_item(idx)
                    
                    with self._prefetch_lock:
                        self._prefetched_items[idx] = result
                        self._prefetch_order.append(idx)
                        
                        # Limit prefetched items
                        if len(self._prefetched_items) > self.prefetch_size * 2:
                            oldest_idx = self._prefetch_order.popleft()
                            if oldest_idx in self._prefetched_items:
                                del self._prefetched_items[oldest_idx]
                    
                    load_time = time.time() - start_time
                    with self._prefetch_lock:
                        self._prefetch_stats.total_loaded += 1
                        # Update average load time
                        n = self._prefetch_stats.total_loaded
                        self._prefetch_stats.avg_load_time = (
                            (self._prefetch_stats.avg_load_time * (n - 1) + load_time) / n
                        )
                
                except Exception as e:
                    # Store error for later handling
                    with self._prefetch_lock:
                        self._prefetched_items[idx] = Exception(f"Prefetch error: {e}")
                
                self._prefetch_queue.task_done()
                
            except queue.Empty:
                continue
            except Exception as e:
                # Log error but continue
                continue
    
    def _load_item(self, idx: int) -> Any:
        """
        Load a single item (same logic as __getitem__ but without prefetch check).
        
        This is used by prefetch workers.
        """
        # Load audio (with caching)
        if self.load_audio_lens is load_audio_frame:
            audio_frame = self.mimir_dataset.load_audio(
                str(self.file_paths[idx]), 
                use_cache=True
            )
        else:
            audio_frame = self.mimir_dataset.apply(
                self.load_audio_lens(str(self.file_paths[idx])),
                None,
                use_cache=True,
            )
        
        # Apply augmentation (if training)
        if self.use_augmentation:
            seed = self._generate_augmentation_seed(idx)
            audio_frame = self.mimir_dataset.apply(
                self.augmentation_pipeline,
                audio_frame,
                use_cache=False,
                seed=seed,
            )
        
        # Apply transformations
        features = self.mimir_dataset.apply(
            self.transform_pipeline,
            audio_frame.data,
            use_cache=True,
        )
        
        # Convert to tensor if not already a tensor
        if _torch_available:
            if not isinstance(features, torch.Tensor):
                features = torch.tensor(features)
            
            # Return features and label (if available)
            if self.labels is not None:
                label = self.labels[idx]
                if not isinstance(label, torch.Tensor):
                    label = torch.tensor(label)
                return (features, label)
        else:
            # Without torch, return as-is
            if self.labels is not None:
                return (features, self.labels[idx])
        
        return features
    
    def __getitem__(self, idx: int):
        """
        Loads and processes one sample.
        
        Uses prefetched data if available, otherwise loads on-demand.
        """
        # Check if prefetched
        if self.enable_prefetch:
            with self._prefetch_lock:
                if idx in self._prefetched_items:
                    result = self._prefetched_items.pop(idx)
                    # Remove from order tracking
                    if idx in self._prefetch_order:
                        self._prefetch_order.remove(idx)
                    
                    # If it's an exception, raise it
                    if isinstance(result, Exception):
                        raise result
                    
                    # Request prefetch for next items
                    next_indices = range(
                        idx + 1, 
                        min(idx + 1 + self.prefetch_size, len(self.file_paths))
                    )
                    self._request_prefetch(next_indices)
                    
                    return result
        
        # Load on-demand (fallback)
        result = self._load_item(idx)
        
        # Request prefetch for next items
        if self.enable_prefetch:
            next_indices = range(
                idx + 1,
                min(idx + 1 + self.prefetch_size, len(self.file_paths))
            )
            self._request_prefetch(next_indices)
        
        return result
    
    def get_prefetch_stats(self) -> PrefetchStats:
        """
        Get statistics about prefetching performance.
        
        Returns:
            PrefetchStats object with prefetching metrics
        """
        with self._prefetch_lock:
            stats = PrefetchStats(
                total_loaded=self._prefetch_stats.total_loaded,
                cache_hits=self._prefetch_stats.cache_hits,
                cache_misses=self._prefetch_stats.cache_misses,
                prefetch_queue_size=self._prefetch_queue.qsize() if self._prefetch_queue else 0,
                avg_load_time=self._prefetch_stats.avg_load_time,
            )
        return stats
    
    def reset_prefetch(self) -> None:
        """Reset prefetching state (useful when dataset order changes)."""
        self._stop_prefetching()
        with self._prefetch_lock:
            self._prefetched_items.clear()
            self._prefetch_order.clear()
        if self.enable_prefetch:
            self._start_prefetching()
    
    def _stop_prefetching(self) -> None:
        """Stop all prefetching threads."""
        if self._prefetch_stop_event:
            self._prefetch_stop_event.set()
        
        # Wait for threads to finish
        for thread in self._prefetch_threads:
            thread.join(timeout=1.0)
        
        self._prefetch_threads.clear()
        self._prefetch_queue = None
    
    def __del__(self):
        """Cleanup when dataset is destroyed."""
        self._stop_prefetching()
    
    def set_epoch(self, epoch: int) -> None:
        """Set epoch number and reset prefetching."""
        super().set_epoch(epoch)
        # Reset prefetching when epoch changes
        self.reset_prefetch()


def create_streaming_dataloader(
    mimir_dataset: MimirDataset,
    file_paths: List[Union[str, Path]],
    transform_pipeline: Lens,
    labels: Optional[List[Any]] = None,
    batch_size: int = 32,
    shuffle: bool = True,
    num_workers: int = 4,
    pin_memory: bool = True,
    use_augmentation: bool = False,
    augmentation_pipeline: Optional[Lens] = None,
    persistent_workers: bool = False,
    prefetch_factor: Optional[int] = None,
    timeout: float = 0,
    drop_last: bool = False,
    collate_fn: Optional[Callable] = None,
    worker_init_fn: Optional[Callable] = None,
    # Streaming-specific parameters
    prefetch_size: int = 100,
    num_prefetch_workers: int = 2,
    enable_prefetch: bool = True,
    **dataloader_kwargs,
) -> torch.utils.data.DataLoader:
    """
    Create DataLoader with StreamingDataset for large datasets.
    
    Convenience function for creating DataLoader with streaming support.
    Perfect for datasets that don't fit in memory.
    
    Requires PyTorch to be installed.
    
    Args:
        mimir_dataset: Instance of mimir_io.Dataset for caching
        file_paths: List of paths to files (can be very large)
        transform_pipeline: Lens with transformation pipeline
        labels: Optional labels for each file
        batch_size: Number of samples per batch
        shuffle: Whether to shuffle data each epoch
        num_workers: Number of worker processes for DataLoader
        pin_memory: Whether to pin memory for faster GPU transfer
        use_augmentation: Whether to use augmentations
        augmentation_pipeline: Lens with augmentation pipeline
        persistent_workers: Keep workers alive between epochs
        prefetch_factor: Number of batches prefetched per worker
        timeout: Timeout for getting a batch from workers
        drop_last: Drop last incomplete batch
        collate_fn: Custom function for batching
        worker_init_fn: Custom worker initialization function
        prefetch_size: Number of items to prefetch ahead in StreamingDataset
        num_prefetch_workers: Number of threads for prefetching in StreamingDataset
        enable_prefetch: Whether to enable prefetching in StreamingDataset
        **dataloader_kwargs: Additional arguments passed to DataLoader
    
    Returns:
        PyTorch DataLoader instance with StreamingDataset
    
    Example:
        >>> from mimir_io.streaming import create_streaming_dataloader
        >>> from mimir_io.audio import resample, log_mel_spectrogram
        >>>
        >>> # Large dataset - streaming with prefetching
        >>> loader = create_streaming_dataloader(
        ...     mimir_dataset=dataset,
        ...     file_paths=large_file_list,  # Millions of files
        ...     transform_pipeline=resample(16000) | log_mel_spectrogram(n_mels=80),
        ...     labels=labels,
        ...     batch_size=32,
        ...     num_workers=4,
        ...     prefetch_size=200,  # Prefetch 200 items ahead
        ...     num_prefetch_workers=4,  # Use 4 threads for prefetching
        ... )
        >>>
        >>> for batch in loader:
        ...     # Memory efficient - data loaded on-the-fly!
        ...     pass
    """
    if not _torch_available:
        raise ImportError(
            "PyTorch is required for streaming dataloader. "
            "Install with: pip install torch"
        )
    
    dataset = StreamingDataset(
        mimir_dataset=mimir_dataset,
        file_paths=file_paths,
        transform_pipeline=transform_pipeline,
        labels=labels,
        use_augmentation=use_augmentation,
        augmentation_pipeline=augmentation_pipeline,
        collate_fn=collate_fn,
        prefetch_size=prefetch_size,
        num_prefetch_workers=num_prefetch_workers,
        enable_prefetch=enable_prefetch,
    )
    
    # Use default worker_init_fn if augmentations are enabled and none provided
    if worker_init_fn is None and use_augmentation and num_workers > 0:
        try:
            from mimir_io.torch_dataset import _worker_init_fn
            worker_init_fn = _worker_init_fn
        except ImportError:
            pass  # Use default worker_init_fn
    
    # Build DataLoader kwargs
    loader_kwargs = {
        "batch_size": batch_size,
        "shuffle": shuffle,
        "num_workers": num_workers,
        "pin_memory": pin_memory,
        "drop_last": drop_last,
        "timeout": timeout,
    }
    
    # Add optional parameters
    if persistent_workers and num_workers > 0:
        loader_kwargs["persistent_workers"] = True
    
    if prefetch_factor is not None and num_workers > 0:
        loader_kwargs["prefetch_factor"] = prefetch_factor
    
    if collate_fn is not None:
        loader_kwargs["collate_fn"] = collate_fn
    
    if worker_init_fn is not None:
        loader_kwargs["worker_init_fn"] = worker_init_fn
    
    # Add any additional kwargs
    loader_kwargs.update(dataloader_kwargs)
    
    return torch.utils.data.DataLoader(dataset, **loader_kwargs)

