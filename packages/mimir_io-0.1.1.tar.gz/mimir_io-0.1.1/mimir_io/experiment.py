"""
Модуль для максимального зменшення бойлерплейту при створенні експериментів.

Надає прості функції для швидкого налаштування тренування з мінімальним кодом.
"""

from typing import Optional, List, Union, Dict, Any, Tuple
from pathlib import Path

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader
    _torch_available = True
except ImportError:
    _torch_available = False
    torch = object  # type: ignore
    nn = object  # type: ignore
    DataLoader = object  # type: ignore

from mimir_io import Dataset, split_dataset, split_by_directory, DatasetSplit
from mimir_io.audio import resample, log_mel_spectrogram
from mimir_io.rayframe.audio import augment_audio_frame
from mimir_io.torch_dataset import create_dataloader, MimirTorchDataset
from mimir_io.models.trainer import BaseTrainer
from mimir_io.models.tester import BaseTester
from mimir_io.models.config import load_config
from mimir_io.models.benchmark import run_benchmarks
from mimir_io.models.experiment_results import ExperimentResult, ExperimentResultsManager
from mimir_io.lens import Lens
from datetime import datetime
from mimir_io.pipeline_registry import (
    create_pipeline,
    has_pipeline,
    list_pipelines,
)


def find_experiment_files(experiment_dir: Union[str, Path]) -> Dict[str, Optional[Path]]:
    """
    Знаходить файли експерименту в папці.
    
    Args:
        experiment_dir: Шлях до папки експерименту
        
    Returns:
        Словник з шляхами до файлів:
        - checkpoint: Шлях до checkpoint файлу (best_model.pt або останній checkpoint_epoch_*.pt)
        - config: Шлях до конфігураційного файлу (config.yaml або config.yml)
        - split: Шлях до split файлу (split.json, якщо існує)
        
    Example:
        >>> from mimir_io.experiment import find_experiment_files
        >>> files = find_experiment_files("./experiments/exp_001")
        >>> print(f"Checkpoint: {files['checkpoint']}")
        >>> print(f"Config: {files['config']}")
    """
    experiment_dir = Path(experiment_dir)
    
    if not experiment_dir.exists():
        raise FileNotFoundError(f"Experiment directory not found: {experiment_dir}")
    
    if not experiment_dir.is_dir():
        raise ValueError(f"Path is not a directory: {experiment_dir}")
    
    result = {
        "checkpoint": None,
        "config": None,
        "split": None,
    }
    
    # Пошук checkpoint файлу
    best_model = experiment_dir / "best_model.pt"
    if best_model.exists():
        result["checkpoint"] = best_model
    else:
        # Шукаємо останній checkpoint_epoch_*.pt
        checkpoints = sorted(experiment_dir.glob("checkpoint_epoch_*.pt"))
        if checkpoints:
            result["checkpoint"] = checkpoints[-1]
    
    # Пошук конфігураційного файлу
    config_yaml = experiment_dir / "config.yaml"
    config_yml = experiment_dir / "config.yml"
    if config_yaml.exists():
        result["config"] = config_yaml
    elif config_yml.exists():
        result["config"] = config_yml
    else:
        # Шукаємо будь-який YAML файл
        yaml_files = list(experiment_dir.glob("*.yaml")) + list(experiment_dir.glob("*.yml"))
        if yaml_files:
            result["config"] = yaml_files[0]
    
    # Пошук split файлу
    split_file = experiment_dir / "split.json"
    if split_file.exists():
        result["split"] = split_file
    
    return result


class ExperimentConfig:
    """
    Experiment configuration with smart default values.
    
    Allows quick experiment setup with minimal parameters.
    """
    
    def __init__(
        self,
        data_dir: Union[str, Path] = "./data",
        train_ratio: float = 0.7,
        val_ratio: float = 0.15,
        test_ratio: float = 0.15,
        batch_size: int = 32,
        num_workers: int = 4,
        sample_rate: int = 16000,
        n_mels: int = 80,
        n_fft: int = 2048,
        hop_length: int = 512,
        epochs: int = 10,
        learning_rate: float = 0.001,
        optimizer: str = "Adam",
        criterion: str = "CrossEntropyLoss",
        use_augmentation: bool = True,
        augmentation_config: Optional[Dict[str, Any]] = None,
        split_seed: int = 42,
        stratify: bool = True,
        save_dir: Optional[Union[str, Path]] = None,
        device: Optional[str] = None,
        early_stopping: Optional[Dict[str, Any]] = None,
        gradient_clipping: Optional[Dict[str, Any]] = None,
        mixed_precision: Optional[Dict[str, Any]] = None,
        scheduler: Optional[Dict[str, Any]] = None,
        distributed: Optional[Dict[str, Any]] = None,
        run_benchmarks: bool = True,
        benchmark_names: Optional[List[str]] = None,
        save_results: bool = True,
        experiment_name: Optional[str] = None,
        results_dir: Optional[Union[str, Path]] = None,
        **kwargs,
    ):
        """
        Initialize experiment configuration.
        
        Args:
            data_dir: Base data directory
            train_ratio: Training data ratio
            val_ratio: Validation data ratio
            test_ratio: Test data ratio
            batch_size: Batch size
            num_workers: Number of workers for DataLoader
            sample_rate: Target sample rate
            n_mels: Number of mel bins
            n_fft: FFT window size
            hop_length: STFT hop length
            epochs: Number of epochs
            learning_rate: Learning rate
            optimizer: Optimizer type (Adam, SGD)
            criterion: Loss function type (CrossEntropyLoss, MSELoss)
            use_augmentation: Whether to use augmentations
            augmentation_config: Augmentation configuration
            split_seed: Seed for dataset splitting
            stratify: Whether to maintain class distribution when splitting
            save_dir: Directory for saving checkpoints
            device: Training device (None = auto-detect)
            early_stopping: Early stopping configuration (dict with enabled, patience, monitor, etc.)
            gradient_clipping: Gradient clipping configuration (dict with enabled, max_norm, norm_type)
            mixed_precision: Mixed precision training configuration (dict with enabled, init_scale, etc.)
            scheduler: Learning rate scheduler configuration (dict with enabled, type, params)
            distributed: Distributed training configuration (dict with enabled, num_gpus, backend, etc.)
            run_benchmarks: Whether to run benchmarks after training/testing
            benchmark_names: List of benchmark names to run (None = run all)
            save_results: Whether to save experiment results
            experiment_name: Name for the experiment (for saving results)
            results_dir: Directory for saving experiment results
            **kwargs: Additional parameters
        """
        self.data_dir = Path(data_dir)
        self.train_ratio = train_ratio
        self.val_ratio = val_ratio
        self.test_ratio = test_ratio
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.sample_rate = sample_rate
        self.n_mels = n_mels
        self.n_fft = n_fft
        self.hop_length = hop_length
        self.epochs = epochs
        self.learning_rate = learning_rate
        self.optimizer = optimizer
        self.criterion = criterion
        self.use_augmentation = use_augmentation
        self.augmentation_config = augmentation_config or {}
        self.split_seed = split_seed
        self.stratify = stratify
        self.save_dir = Path(save_dir) if save_dir else self.data_dir / "checkpoints"
        self.device = device
        self.early_stopping = early_stopping or {}
        self.gradient_clipping = gradient_clipping or {}
        self.mixed_precision = mixed_precision or {}
        self.scheduler = scheduler or {}
        self.distributed = distributed or {}
        self.run_benchmarks = run_benchmarks
        self.benchmark_names = benchmark_names
        self.save_results = save_results
        self.experiment_name = experiment_name or f"experiment_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.results_dir = Path(results_dir) if results_dir else self.data_dir / "experiment_results"
        self.extra = kwargs
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary for YAML."""
        training_config = {
            "epochs": self.epochs,
            "batch_size": self.batch_size,
            "save_dir": str(self.save_dir),
            "optimizer": {
                "type": self.optimizer,
                "lr": self.learning_rate,
            },
            "criterion": {
                "type": self.criterion,
            },
        }
        
        # Add early stopping if configured
        if self.early_stopping:
            training_config["early_stopping"] = self.early_stopping
        
        # Add gradient clipping if configured
        if self.gradient_clipping:
            training_config["gradient_clipping"] = self.gradient_clipping
        
        # Add mixed precision if configured
        if self.mixed_precision:
            training_config["mixed_precision"] = self.mixed_precision
        
        # Add scheduler if configured
        if self.scheduler:
            training_config["scheduler"] = self.scheduler
        
        # Add distributed training if configured
        if self.distributed:
            training_config["distributed"] = self.distributed
        
        return {
            "data": {
                "data_dir": str(self.data_dir),
                "sample_rate": self.sample_rate,
                "n_mels": self.n_mels,
                "n_fft": self.n_fft,
                "hop_length": self.hop_length,
            },
            "training": training_config,
            "augmentation": self.augmentation_config,
            **self.extra,
        }


def setup_experiment(
    file_paths: List[Union[str, Path]],
    labels: Optional[List[Any]] = None,
    config: Optional[Union[ExperimentConfig, Dict[str, Any]]] = None,
    split_path: Optional[Union[str, Path]] = None,
    transform_pipeline: Optional[Lens] = None,
    augmentation_pipeline: Optional[Lens] = None,
    precompute_cache: bool = False,
    num_precompute_workers: Optional[int] = None,
) -> Tuple[DataLoader, DataLoader, Optional[DataLoader], Dataset, Dict[str, Any]]:
    """
    Setup entire experiment with minimal boilerplate.
    
    Automatically creates:
    - Dataset split (train/val/test)
    - Transform pipeline (resample + mel spectrogram)
    - Augmentation pipeline
    - PyTorch DataLoaders
    - Training config
    
    Args:
        file_paths: List of paths to audio files
        labels: Optional labels for each file
        config: Experiment configuration (ExperimentConfig or dict)
        split_path: Path for saving/loading split (optional)
        transform_pipeline: Custom transform pipeline (optional)
        augmentation_pipeline: Custom augmentation pipeline (optional)
        precompute_cache: Whether to precompute cache (for speedup)
        num_precompute_workers: Number of workers for precomputation
        
    Returns:
        Tuple of (train_loader, val_loader, test_loader, dataset, training_config)
        
    Example:
        >>> from mimir_io.experiment import setup_experiment
        >>> from pathlib import Path
        >>>
        >>> # Minimal example
        >>> files = list(Path("./data/raw").glob("*.wav"))
        >>> labels = [0, 1, 0, 1, ...]  # Your labels
        >>> train_loader, val_loader, test_loader, dataset, config = setup_experiment(
        ...     file_paths=files,
        ...     labels=labels,
        ... )
        >>>
        >>> # With custom configuration
        >>> from mimir_io.experiment import ExperimentConfig
        >>> config = ExperimentConfig(
        ...     batch_size=64,
        ...     epochs=20,
        ...     learning_rate=0.0001,
        ... )
        >>> train_loader, val_loader, test_loader, dataset, training_config = setup_experiment(
        ...     file_paths=files,
        ...     labels=labels,
        ...     config=config,
        ... )
    """
    if not _torch_available:
        raise ImportError("PyTorch is required for experiments")
    
    # Prepare configuration
    if config is None:
        exp_config = ExperimentConfig()
    elif isinstance(config, dict):
        # Extract pipeline configs before creating ExperimentConfig
        config_copy = config.copy()
        pipeline_config = config_copy.pop("pipeline", {})
        aug_pipeline_config = config_copy.pop("augmentation_pipeline", {})
        exp_config = ExperimentConfig(**config_copy)
        # Store pipeline configs in extra
        exp_config.extra["pipeline"] = pipeline_config
        exp_config.extra["augmentation_pipeline"] = aug_pipeline_config
    else:
        exp_config = config
    
    # Create Dataset
    dataset = Dataset(data_dir=exp_config.data_dir)
    
    # Create split
    split = None
    if split_path and Path(split_path).exists():
        # Load existing split
        split = DatasetSplit.load(split_path)
    else:
        # Create new split
        split = split_dataset(
            file_paths=file_paths,
            labels=labels,
            train_ratio=exp_config.train_ratio,
            val_ratio=exp_config.val_ratio,
            test_ratio=exp_config.test_ratio,
            stratify=exp_config.stratify,
            seed=exp_config.split_seed,
        )
        # Save split if specified
        if split_path:
            split.save(split_path)
    
    # Create transform pipeline
    if transform_pipeline is None:
        # Check if pipeline is specified in config
        pipeline_config = exp_config.extra.get("pipeline", {})
        pipeline_name = pipeline_config.get("type", "mel_spectrogram")
        
        if has_pipeline(pipeline_name, is_augmentation=False):
            # Create pipeline from registry
            pipeline_params = pipeline_config.get("params", {})
            # Merge with experiment config defaults
            pipeline_params.setdefault("sample_rate", exp_config.sample_rate)
            pipeline_params.setdefault("n_mels", exp_config.n_mels)
            pipeline_params.setdefault("n_fft", exp_config.n_fft)
            pipeline_params.setdefault("hop_length", exp_config.hop_length)
            transform_pipeline = create_pipeline(
                name=pipeline_name,
                config=pipeline_params,
                is_augmentation=False,
            )
        else:
            # Fallback to default hardcoded pipeline (for backward compatibility)
            transform_pipeline = (
                resample(exp_config.sample_rate).no_cache()
                | log_mel_spectrogram(
                    sample_rate=exp_config.sample_rate,
                    n_mels=exp_config.n_mels,
                    n_fft=exp_config.n_fft,
                    hop_length=exp_config.hop_length,
                ).cache()
            )
    
    # Create augmentation pipeline
    if augmentation_pipeline is None and exp_config.use_augmentation:
        # Check if augmentation pipeline is specified in config
        aug_pipeline_config = exp_config.extra.get("augmentation_pipeline", {})
        aug_pipeline_name = aug_pipeline_config.get("type", "standard_augmentation")
        
        if has_pipeline(aug_pipeline_name, is_augmentation=True):
            # Create augmentation pipeline from registry
            aug_params = aug_pipeline_config.get("params", {})
            # Merge with augmentation config defaults
            aug_config = exp_config.augmentation_config
            aug_params.setdefault("time_shift_max", aug_config.get("time_shift_max", 1600))
            aug_params.setdefault("gain_range", tuple(aug_config.get("gain_range", [0.7, 1.3])))
            aug_params.setdefault("noise_snr", aug_config.get("noise_snr", 20.0))
            aug_params.setdefault("speed_range", tuple(aug_config.get("speed_range", [0.9, 1.1])))
            augmentation_pipeline = create_pipeline(
                name=aug_pipeline_name,
                config=aug_params,
                is_augmentation=True,
            )
        else:
            # Fallback to default hardcoded augmentation (for backward compatibility)
            aug_config = exp_config.augmentation_config
            augmentation_pipeline = augment_audio_frame(
                time_shift_max=aug_config.get("time_shift_max", 1600),
                gain_range=aug_config.get("gain_range", (0.7, 1.3)),
                noise_snr=aug_config.get("noise_snr", 20.0),
                speed_range=aug_config.get("speed_range", (0.9, 1.1)),
            )
    
    # Precompute cache (optional)
    if precompute_cache:
        num_workers = num_precompute_workers or exp_config.num_workers
        print("Precomputing cache for training data...")
        dataset.precompute_batch(
            transform_pipeline,
            split.train_files,
            num_workers=num_workers,
            show_progress=True,
            desc="Precomputing training cache",
        )
        print("Precomputing cache for validation data...")
        dataset.precompute_batch(
            transform_pipeline,
            split.val_files,
            num_workers=num_workers,
            show_progress=True,
            desc="Precomputing validation cache",
        )
        if split.test_files:
            print("Precomputing cache for test data...")
            dataset.precompute_batch(
                transform_pipeline,
                split.test_files,
                num_workers=num_workers,
                show_progress=True,
                desc="Precomputing test cache",
            )
    
    # Check if distributed training is enabled
    distributed_config = exp_config.distributed
    use_distributed = distributed_config.get("enabled", False) if distributed_config else False
    
    # Setup distributed samplers if needed
    train_sampler = None
    val_sampler = None
    test_sampler = None
    
    if use_distributed:
        try:
            from mimir_io.models.distributed import setup_distributed_sampler, is_distributed
            if is_distributed():
                train_sampler = setup_distributed_sampler(
                    MimirTorchDataset(
                        mimir_dataset=dataset,
                        file_paths=split.train_files,
                        transform_pipeline=transform_pipeline,
                        labels=split.train_labels,
                    ),
                    shuffle=True,
                    seed=exp_config.split_seed,
                )
                val_sampler = setup_distributed_sampler(
                    MimirTorchDataset(
                        mimir_dataset=dataset,
                        file_paths=split.val_files,
                        transform_pipeline=transform_pipeline,
                        labels=split.val_labels,
                    ),
                    shuffle=False,
                )
                if split.test_files:
                    test_sampler = setup_distributed_sampler(
                        MimirTorchDataset(
                            mimir_dataset=dataset,
                            file_paths=split.test_files,
                            transform_pipeline=transform_pipeline,
                            labels=split.test_labels,
                        ),
                        shuffle=False,
                    )
        except ImportError:
            pass
    
    # Create DataLoaders
    train_loader = create_dataloader(
        mimir_dataset=dataset,
        file_paths=split.train_files,
        transform_pipeline=transform_pipeline,
        labels=split.train_labels,
        batch_size=exp_config.batch_size,
        shuffle=True if train_sampler is None else False,
        num_workers=exp_config.num_workers,
        pin_memory=True,
        persistent_workers=exp_config.num_workers > 0,
        use_augmentation=exp_config.use_augmentation,
        augmentation_pipeline=augmentation_pipeline,
        distributed=use_distributed,
        distributed_sampler=train_sampler,
    )
    
    val_loader = create_dataloader(
        mimir_dataset=dataset,
        file_paths=split.val_files,
        transform_pipeline=transform_pipeline,
        labels=split.val_labels,
        batch_size=exp_config.batch_size,
        shuffle=False,
        num_workers=exp_config.num_workers,
        pin_memory=True,
        use_augmentation=False,  # No augmentations for validation
        distributed=use_distributed,
        distributed_sampler=val_sampler,
    )
    
    test_loader = None
    if split.test_files:
        test_loader = create_dataloader(
            mimir_dataset=dataset,
            file_paths=split.test_files,
            transform_pipeline=transform_pipeline,
            labels=split.test_labels,
            batch_size=exp_config.batch_size,
            shuffle=False,
            num_workers=exp_config.num_workers,
            pin_memory=True,
            use_augmentation=False,
            distributed=use_distributed,
            distributed_sampler=test_sampler,
        )
    
    # Create training config
    training_config = exp_config.to_dict()
    
    return train_loader, val_loader, test_loader, dataset, training_config


def quick_train(
    model: nn.Module,
    file_paths: List[Union[str, Path]],
    labels: Optional[List[Any]] = None,
    config: Optional[Union[ExperimentConfig, Dict[str, Any]]] = None,
    split_path: Optional[Union[str, Path]] = None,
    callbacks: Optional[List[Any]] = None,
    **setup_kwargs,
) -> BaseTrainer:
    """
    Quick start training with minimal code.
    
    Automatically sets up everything needed and starts training.
    
    Args:
        model: PyTorch model (nn.Module)
        file_paths: List of paths to audio files
        labels: Optional labels
        config: Experiment configuration
        split_path: Path for saving/loading split
        callbacks: List of callbacks for training
        **setup_kwargs: Additional arguments for setup_experiment
        
    Returns:
        Trainer instance (after training completion)
        
    Example:
        >>> from mimir_io.experiment import quick_train
        >>> import torch.nn as nn
        >>>
        >>> # Create model
        >>> model = nn.Sequential(
        ...     nn.Linear(80, 128),
        ...     nn.ReLU(),
        ...     nn.Linear(128, 10),
        ... )
        >>>
        >>> # Start training
        >>> trainer = quick_train(
        ...     model=model,
        ...     file_paths=list(Path("./data/raw").glob("*.wav")),
        ...     labels=[0, 1, 0, 1, ...],
        ... )
    """
    if not _torch_available:
        raise ImportError("PyTorch is required for training")
    
    # Setup experiment
    train_loader, val_loader, test_loader, dataset, training_config = setup_experiment(
        file_paths=file_paths,
        labels=labels,
        config=config,
        split_path=split_path,
        **setup_kwargs,
    )
    
    # Create trainer
    device = training_config.get("training", {}).get("device")
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    
    trainer = BaseTrainer(
        model=model,
        config=training_config,
        train_loader=train_loader,
        val_loader=val_loader,
        device=device,
        callbacks=callbacks,
    )
    
    # Check if distributed training should be launched automatically
    distributed_config = training_config.get("training", {}).get("distributed", {})
    use_distributed = distributed_config.get("enabled", False)
    
    if use_distributed:
        # Use launch_distributed to automatically spawn processes
        try:
            from mimir_io.models.distributed import launch_distributed, is_distributed
            
            # Check if we're already in a distributed process
            if not is_distributed():
                # Launch distributed training
                num_gpus = distributed_config.get("num_gpus")
                backend = distributed_config.get("backend", "nccl")
                
                def _train_func():
                    # This will run on each GPU process
                    # Recreate trainer in each process (needed for multiprocessing)
                    train_loader, val_loader, test_loader, dataset, training_config = setup_experiment(
                        file_paths=file_paths,
                        labels=labels,
                        config=config,
                        split_path=split_path,
                        **setup_kwargs,
                    )
                    
                    device = training_config.get("training", {}).get("device")
                    if device is None:
                        device = "cuda" if torch.cuda.is_available() else "cpu"
                    
                    trainer = BaseTrainer(
                        model=model,
                        config=training_config,
                        train_loader=train_loader,
                        val_loader=val_loader,
                        device=device,
                        callbacks=callbacks,
                    )
                    
                    trainer.train()
                    return trainer
                
                # Launch distributed training
                launch_distributed(_train_func, num_gpus=num_gpus, backend=backend)
                # Return a dummy trainer (actual training happened in subprocesses)
                return trainer
        except ImportError:
            # Fallback to single GPU if distributed not available
            pass
    
    # Start training (single GPU or already in distributed process)
    trainer.train()
    
    # Get experiment config
    if isinstance(config, ExperimentConfig):
        exp_config = config
    elif isinstance(config, dict):
        exp_config = ExperimentConfig(**config)
    else:
        exp_config = ExperimentConfig()
    
    # Collect training metrics (if available)
    training_metrics = {}
    if hasattr(trainer, 'training_history'):
        training_metrics = trainer.training_history
    
    # Run benchmarks if enabled and test_loader is available
    benchmark_results = {}
    if exp_config.run_benchmarks and test_loader is not None:
        print("\nRunning benchmarks...")
        benchmark_results = run_benchmarks(
            model=model,
            test_loader=test_loader,
            benchmark_names=exp_config.benchmark_names,
            device=device,
        )
        print("Benchmarks completed!")
        for bench_name, bench_result in benchmark_results.items():
            if "error" not in bench_result:
                print(f"  {bench_name}: {bench_result}")
    
    # Save results if enabled
    if exp_config.save_results:
        results_manager = ExperimentResultsManager(exp_config.results_dir)
        
        # Prepare metadata
        metadata = {
            "checkpoint_path": str(trainer.save_dir / "best_model.pt"),
            "split_path": str(split_path) if split_path else None,
        }
        
        # Create and save experiment result
        result = ExperimentResult(
            experiment_name=exp_config.experiment_name,
            config=training_config,
            training_metrics=training_metrics,
            benchmark_results=benchmark_results,
            metadata=metadata,
        )
        
        result_path = results_manager.save_result(result)
        print(f"\nExperiment results saved to: {result_path}")
        print(f"Experiment ID: {result.experiment_id}")
    
    return trainer


def train_from_config_file(
    model: nn.Module,
    config_path: Union[str, Path],
    file_paths: Optional[List[Union[str, Path]]] = None,
    labels: Optional[List[Any]] = None,
    split_path: Optional[Union[str, Path]] = None,
) -> BaseTrainer:
    """
    Training from YAML configuration file.
    
    Loads configuration from YAML file and sets up experiment.
    
    Args:
        model: PyTorch model
        config_path: Path to YAML configuration
        file_paths: List of files (if not specified in config)
        labels: Labels (if not specified in config)
        split_path: Path for split (optional)
        
    Returns:
        Trainer instance
        
    Example:
        >>> from mimir_io.experiment import train_from_config_file
        >>> trainer = train_from_config_file(
        ...     model=model,
        ...     config_path="configs/my_experiment.yaml",
        ...     file_paths=files,
        ...     labels=labels,
        ... )
    """
    if not _torch_available:
        raise ImportError("PyTorch is required for training")
    
    # Load configuration
    config_dict = load_config(config_path)
    
    # Use file_paths from configuration if not specified
    if file_paths is None:
        data_dir = Path(config_dict.get("data", {}).get("data_dir", "./data"))
        file_paths = list(data_dir.glob("**/*.wav"))
    
    # Setup experiment
    train_loader, val_loader, test_loader, dataset, training_config = setup_experiment(
        file_paths=file_paths,
        labels=labels,
        config=config_dict,
        split_path=split_path,
    )
    
    # Create trainer
    device = training_config.get("training", {}).get("device")
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    
    trainer = BaseTrainer(
        model=model,
        config=training_config,
        train_loader=train_loader,
        val_loader=val_loader,
        device=device,
    )
    
    # Start training
    trainer.train()
    
    return trainer


def setup_test(
    file_paths: List[Union[str, Path]],
    labels: Optional[List[Any]] = None,
    config: Optional[Union[ExperimentConfig, Dict[str, Any]]] = None,
    split_path: Optional[Union[str, Path]] = None,
    transform_pipeline: Optional[Lens] = None,
    use_test_split: bool = True,
) -> Tuple[DataLoader, Dataset, Dict[str, Any]]:
    """
    Setup test evaluation with minimal boilerplate.
    
    Automatically creates:
    - Test DataLoader from split or provided files
    - Transform pipeline (resample + mel spectrogram)
    - Testing config
    
    Args:
        file_paths: List of paths to audio files (or test files if use_test_split=True)
        labels: Optional labels for each file
        config: Experiment configuration (ExperimentConfig or dict)
        split_path: Path for loading split (required if use_test_split=True)
        transform_pipeline: Custom transform pipeline (optional)
        use_test_split: If True, loads test split from split_path. If False, uses provided file_paths.
        
    Returns:
        Tuple of (test_loader, dataset, testing_config)
        
    Example:
        >>> from mimir_io.experiment import setup_test
        >>> from pathlib import Path
        >>>
        >>> # Load test split from saved split
        >>> test_loader, dataset, config = setup_test(
        ...     file_paths=[],  # Ignored if use_test_split=True
        ...     split_path="./data/split.json",
        ...     use_test_split=True,
        ... )
        >>>
        >>> # Or use custom test files
        >>> test_files = list(Path("./data/test").glob("*.wav"))
        >>> test_labels = [0, 1, 0, 1, ...]
        >>> test_loader, dataset, config = setup_test(
        ...     file_paths=test_files,
        ...     labels=test_labels,
        ...     use_test_split=False,
        ... )
    """
    if not _torch_available:
        raise ImportError("PyTorch is required for testing")
    
    # Prepare configuration
    if config is None:
        exp_config = ExperimentConfig()
    elif isinstance(config, dict):
        # Extract pipeline config before creating ExperimentConfig
        config_copy = config.copy()
        pipeline_config = config_copy.pop("pipeline", {})
        exp_config = ExperimentConfig(**config_copy)
        # Store pipeline config in extra
        exp_config.extra["pipeline"] = pipeline_config
    else:
        exp_config = config
    
    # Create Dataset
    dataset = Dataset(data_dir=exp_config.data_dir)
    
    # Get test files and labels
    if use_test_split:
        if split_path is None or not Path(split_path).exists():
            raise ValueError(
                "split_path must be provided and exist when use_test_split=True. "
                "Make sure you have saved a split during training."
            )
        split = DatasetSplit.load(split_path)
        if not split.test_files:
            raise ValueError("Test split is empty. Make sure test_ratio > 0 when creating split.")
        test_files = split.test_files
        test_labels = split.test_labels
    else:
        if not file_paths:
            raise ValueError("file_paths must be provided when use_test_split=False")
        test_files = file_paths
        test_labels = labels
    
    # Create transform pipeline
    if transform_pipeline is None:
        # Check if pipeline is specified in config
        pipeline_config = exp_config.extra.get("pipeline", {})
        pipeline_name = pipeline_config.get("type", "mel_spectrogram")
        
        if has_pipeline(pipeline_name, is_augmentation=False):
            # Create pipeline from registry
            pipeline_params = pipeline_config.get("params", {})
            # Merge with experiment config defaults
            pipeline_params.setdefault("sample_rate", exp_config.sample_rate)
            pipeline_params.setdefault("n_mels", exp_config.n_mels)
            pipeline_params.setdefault("n_fft", exp_config.n_fft)
            pipeline_params.setdefault("hop_length", exp_config.hop_length)
            transform_pipeline = create_pipeline(
                name=pipeline_name,
                config=pipeline_params,
                is_augmentation=False,
            )
        else:
            # Fallback to default hardcoded pipeline (for backward compatibility)
            transform_pipeline = (
                resample(exp_config.sample_rate).no_cache()
                | log_mel_spectrogram(
                    sample_rate=exp_config.sample_rate,
                    n_mels=exp_config.n_mels,
                    n_fft=exp_config.n_fft,
                    hop_length=exp_config.hop_length,
                ).cache()
            )
    
    # Create test DataLoader (no augmentations)
    test_loader = create_dataloader(
        mimir_dataset=dataset,
        file_paths=test_files,
        transform_pipeline=transform_pipeline,
        labels=test_labels,
        batch_size=exp_config.batch_size,
        shuffle=False,  # Never shuffle test data
        num_workers=exp_config.num_workers,
        pin_memory=True,
        use_augmentation=False,  # No augmentations for testing
    )
    
    # Create testing config
    testing_config = {
        "testing": {
            "criterion": {
                "type": exp_config.criterion,
            },
        },
        "data": {
            "data_dir": str(exp_config.data_dir),
            "sample_rate": exp_config.sample_rate,
            "n_mels": exp_config.n_mels,
            "n_fft": exp_config.n_fft,
            "hop_length": exp_config.hop_length,
        },
    }
    
    return test_loader, dataset, testing_config


def quick_test(
    model: nn.Module,
    file_paths: Optional[List[Union[str, Path]]] = None,
    labels: Optional[List[Any]] = None,
    config: Optional[Union[ExperimentConfig, Dict[str, Any]]] = None,
    split_path: Optional[Union[str, Path]] = None,
    checkpoint_path: Optional[Union[str, Path]] = None,
    experiment_dir: Optional[Union[str, Path]] = None,
    callbacks: Optional[List[Any]] = None,
    use_test_split: bool = True,
    **setup_kwargs,
) -> BaseTester:
    """
    Quick start testing with minimal code.
    
    Automatically sets up everything needed and runs test evaluation.
    
    Args:
        model: PyTorch model (nn.Module)
        file_paths: List of paths to audio files (optional if use_test_split=True)
        labels: Optional labels (optional if use_test_split=True)
        config: Experiment configuration (ignored if experiment_dir is provided)
        split_path: Path for loading split (required if use_test_split=True, ignored if experiment_dir is provided)
        checkpoint_path: Path to checkpoint file to load model weights (ignored if experiment_dir is provided)
        experiment_dir: Path to experiment directory (alternative to config, split_path, checkpoint_path)
                       Automatically finds config.yaml, best_model.pt, and split.json in the directory
        callbacks: List of callbacks for testing
        use_test_split: If True, loads test split from split_path. If False, uses provided file_paths.
        **setup_kwargs: Additional arguments for setup_test
        
    Returns:
        Tester instance (after testing completion)
        
    Example:
        >>> from mimir_io.experiment import quick_test
        >>> import torch.nn as nn
        >>>
        >>> # Create model
        >>> model = nn.Sequential(
        ...     nn.Linear(80, 128),
        ...     nn.ReLU(),
        ...     nn.Linear(128, 10),
        ... )
        >>>
        >>> # Run test evaluation with experiment directory
        >>> tester = quick_test(
        ...     model=model,
        ...     experiment_dir="./experiments/exp_001",
        ... )
        >>> print(f"Test Accuracy: {tester.test()['test_accuracy']:.2f}%")
        >>>
        >>> # Or with separate files
        >>> tester = quick_test(
        ...     model=model,
        ...     split_path="./data/split.json",
        ...     checkpoint_path="./checkpoints/best_model.pt",
        ... )
    """
    if not _torch_available:
        raise ImportError("PyTorch is required for testing")
    
    # Обробка experiment_dir опції
    if experiment_dir:
        exp_files = find_experiment_files(experiment_dir)
        
        if not exp_files["checkpoint"]:
            raise FileNotFoundError(
                f"Checkpoint file not found in experiment directory: {experiment_dir}. "
                f"Expected: best_model.pt or checkpoint_epoch_*.pt"
            )
        
        if not exp_files["config"]:
            raise FileNotFoundError(
                f"Config file not found in experiment directory: {experiment_dir}. "
                f"Expected: config.yaml or config.yml"
            )
        
        # Використовуємо знайдені файли
        checkpoint_path = exp_files["checkpoint"]
        config_dict = load_config(exp_files["config"])
        config = config_dict
        
        # Використовуємо split з папки експерименту, якщо не вказано інше
        if not split_path and exp_files["split"]:
            split_path = exp_files["split"]
    
    # Setup test
    test_loader, dataset, testing_config = setup_test(
        file_paths=file_paths or [],
        labels=labels,
        config=config,
        split_path=split_path,
        use_test_split=use_test_split,
        **setup_kwargs,
    )
    
    # Create tester
    device = testing_config.get("training", {}).get("device")
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    
    tester = BaseTester(
        model=model,
        config=testing_config,
        test_loader=test_loader,
        device=device,
        callbacks=callbacks,
        checkpoint_path=checkpoint_path,
    )
    
    # Run test evaluation
    metrics = tester.test()
    
    # Print results
    print("\nTest Results:")
    for key, value in metrics.items():
        if not key.startswith("_"):  # Skip internal metrics
            if isinstance(value, float):
                print(f"  {key}: {value:.4f}")
            else:
                print(f"  {key}: {value}")
    
    # Get experiment config
    if isinstance(config, ExperimentConfig):
        exp_config = config
    elif isinstance(config, dict):
        exp_config = ExperimentConfig(**config)
    else:
        exp_config = ExperimentConfig()
    
    # Run benchmarks if enabled
    benchmark_results = {}
    if exp_config.run_benchmarks:
        print("\nRunning benchmarks...")
        benchmark_results = run_benchmarks(
            model=model,
            test_loader=test_loader,
            benchmark_names=exp_config.benchmark_names,
            device=device,
        )
        print("Benchmarks completed!")
        for bench_name, bench_result in benchmark_results.items():
            if "error" not in bench_result:
                print(f"  {bench_name}: {bench_result}")
    
    # Save results if enabled
    if exp_config.save_results:
        results_manager = ExperimentResultsManager(exp_config.results_dir)
        
        # Prepare metadata
        metadata = {
            "checkpoint_path": str(checkpoint_path) if checkpoint_path else None,
            "split_path": str(split_path) if split_path else None,
        }
        
        # Create and save experiment result
        result = ExperimentResult(
            experiment_name=exp_config.experiment_name,
            config=testing_config,
            training_metrics={},  # No training metrics for test-only
            benchmark_results=benchmark_results,
            metadata=metadata,
        )
        
        result_path = results_manager.save_result(result)
        print(f"\nExperiment results saved to: {result_path}")
        print(f"Experiment ID: {result.experiment_id}")
    
    return tester
