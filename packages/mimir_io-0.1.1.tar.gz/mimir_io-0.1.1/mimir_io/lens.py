"""
Lens system for declarative data transformations.

Lenses provide a functional way to compose transformations
on data structures with automatic caching support.
"""

from typing import Callable, TypeVar, Generic, Optional, Any
import hashlib
import json

# Try to use faster hash library if available
try:
    import xxhash
    _xxhash_available = True
except ImportError:
    _xxhash_available = False

T = TypeVar("T")
U = TypeVar("U")
V = TypeVar("V")


class Lens(Generic[T, U]):
    """
    A lens represents a transformation from type T to type U.

    Lenses can be composed together to create complex transformations.
    Each lens operation is cached based on its input hash.
    """

    def __init__(
        self,
        getter: Callable[[T], U],
        name: Optional[str] = None,
        cache_key: Optional[Callable[[T], str]] = None,
        should_cache: bool = True,
    ):
        """
        Initialize a lens.

        Args:
            getter: Function that transforms T to U
            name: Optional name for the lens (for debugging)
            cache_key: Optional function to generate cache key from input
            should_cache: Whether this lens should be cached (default: True)
        """
        self._getter = getter
        self._name = name or getter.__name__
        self._cache_key_fn = cache_key or self._default_cache_key
        self._should_cache = should_cache

    def __call__(self, data: T) -> U:
        """Apply the lens transformation to data."""
        return self._getter(data)

    def __or__(self, other: "Lens[U, Any]") -> "Lens[T, Any]":
        """Compose two lenses using the | operator."""
        return compose(self, other)

    def __repr__(self) -> str:
        return f"Lens({self._name})"

    def _fast_hash(self, data: bytes) -> str:
        """Fast hash function using xxhash if available, fallback to SHA256."""
        if _xxhash_available:
            return xxhash.xxh64(data).hexdigest()
        return hashlib.sha256(data).hexdigest()
    
    def _default_cache_key(self, data: T) -> str:
        """Generate a default cache key from data."""
        # Optimize for common types
        if isinstance(data, str):
            # Direct hash for strings
            return self._fast_hash(data.encode('utf-8'))
        
        # Check if it's a torch Tensor
        try:
            import torch
            if isinstance(data, torch.Tensor):
                # For tensors, use shape + dtype + hash of data pointer or small sample
                # This avoids expensive serialization
                # Move to CPU if needed for numpy conversion
                cpu_data = data.cpu() if data.is_cuda else data
                
                if cpu_data.numel() < 1000:
                    # Small tensor - hash the data directly
                    try:
                        return self._fast_hash(cpu_data.numpy().tobytes())
                    except (RuntimeError, AttributeError):
                        # Fallback if numpy conversion fails
                        shape_str = str(tuple(cpu_data.shape))
                        dtype_str = str(cpu_data.dtype)
                        return self._fast_hash(f"{shape_str}:{dtype_str}".encode('utf-8'))
                else:
                    # Large tensor - use shape + dtype + hash of first/last samples
                    sample_size = min(100, cpu_data.numel())
                    flat_data = cpu_data.flatten()
                    if sample_size >= 2:
                        sample = torch.cat([flat_data[:sample_size//2], 
                                           flat_data[-sample_size//2:]])
                        try:
                            sample_bytes = sample.numpy().tobytes()
                        except (RuntimeError, AttributeError):
                            sample_bytes = str(sample.tolist()).encode('utf-8')
                    else:
                        sample_bytes = str(flat_data.tolist()).encode('utf-8')
                    
                    shape_str = str(tuple(cpu_data.shape))
                    dtype_str = str(cpu_data.dtype)
                    combined = f"{shape_str}:{dtype_str}:{self._fast_hash(sample_bytes)}"
                    return self._fast_hash(combined.encode('utf-8'))
        except (ImportError, AttributeError):
            pass
        
        # Check if it's AudioRayFrame - use source path if available
        try:
            from mimir_io.rayframe.audio_frame import AudioRayFrame
            if isinstance(data, AudioRayFrame):
                # Use source path from metadata if available
                source_path = data.metadata.get('source_path') if hasattr(data, 'metadata') else None
                if source_path:
                    # Use path + sample_rate + shape for cache key
                    key_parts = [
                        str(source_path),
                        str(data.sample_rate),
                        str(tuple(data.data.shape)),
                        str(data.data.dtype)
                    ]
                    combined = ":".join(key_parts)
                    return self._fast_hash(combined.encode('utf-8'))
        except (ImportError, AttributeError):
            pass
        
        # Fallback to JSON serialization for other types
        try:
            data_str = json.dumps(data, sort_keys=True, default=str)
            return self._fast_hash(data_str.encode('utf-8'))
        except (TypeError, ValueError):
            return self._fast_hash(str(data).encode('utf-8'))

    def cache_key(self, data: T) -> str:
        """Generate a cache key for the given data."""
        return f"{self._name}:{self._cache_key_fn(data)}"
    
    def cache(self) -> "Lens[T, U]":
        """
        Mark this lens to be cached.
        
        Returns:
            New lens instance with caching enabled
        """
        new_lens = Lens(self._getter, self._name, self._cache_key_fn, should_cache=True)
        return new_lens
    
    def no_cache(self) -> "Lens[T, U]":
        """
        Mark this lens to not be cached.
        
        Useful for cheap operations or when you only want to cache the final result.
        
        Returns:
            New lens instance with caching disabled
            
        Example:
            >>> # Only cache the final mel spectrogram, not intermediate steps
            >>> pipeline = (
            ...     resample(16000).no_cache()
            ...     | normalize().no_cache()
            ...     | mel_spectrogram(n_mels=80).cache()  # Cache only this
            ... )
        """
        new_lens = Lens(self._getter, self._name, self._cache_key_fn, should_cache=False)
        return new_lens


def identity() -> Lens[T, T]:
    """Create an identity lens that returns data unchanged."""
    return Lens(lambda x: x, name="identity")


def compose(lens1: Lens[T, U], lens2: Lens[U, V]) -> Lens[T, V]:
    """
    Compose two lenses into a new lens.

    Args:
        lens1: First lens (T -> U)
        lens2: Second lens (U -> V)

    Returns:
        A new lens that applies lens1 then lens2 (T -> V)
    """
    name = f"{lens1._name} | {lens2._name}"

    def composed(data: T) -> V:
        return lens2(lens1(data))

    # Зберігаємо компоненти для можливості розбиття пайплайну
    components = []
    if hasattr(lens1, '_components'):
        components.extend(lens1._components)
    else:
        components.append(lens1)
    
    if hasattr(lens2, '_components'):
        components.extend(lens2._components)
    else:
        components.append(lens2)
    
    composed_lens = Lens(composed, name=name)
    composed_lens._components = components  # type: ignore
    
    return composed_lens

