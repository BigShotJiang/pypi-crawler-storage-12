"""
In-memory cache index for fast cache existence checks.

This module provides a fast in-memory index to avoid multiple filesystem
calls when checking if cache entries exist.
"""

from pathlib import Path
from typing import Dict, Tuple, Optional, Set
import time
import os
import threading


class CacheIndex:
    """
    In-memory index for cache files to speed up existence checks.
    
    Maintains a mapping of cache keys to their existence status and format,
    with TTL (time-to-live) to handle filesystem changes.
    """
    
    def __init__(self, cache_dir: Path, ttl: float = 3600.0, auto_refresh: bool = True):
        """
        Initialize cache index.
        
        Args:
            cache_dir: Directory where cache files are stored
            ttl: Time-to-live for index entries in seconds (default: 1 hour)
            auto_refresh: If True, automatically refresh stale entries
        """
        self.cache_dir = Path(cache_dir)
        self.ttl = ttl
        self.auto_refresh = auto_refresh
        
        # Index: cache_key -> (exists: bool, format: str, timestamp: float)
        self._index: Dict[str, Tuple[bool, Optional[str], float]] = {}
        self._lock = threading.Lock()
        
        # Set of known cache file extensions
        self._extensions = {'.wav', '.pkl', '.png', '.wav.meta.json', '.pkl.meta.json', '.png.meta.json'}
        
        # Load initial index if cache directory exists
        if self.cache_dir.exists():
            self._load_index()
    
    def _load_index(self) -> None:
        """Load index from filesystem by scanning cache directory."""
        if not self.cache_dir.exists():
            return
        
        try:
            # Use os.scandir for efficient directory scanning
            with os.scandir(self.cache_dir) as entries:
                for entry in entries:
                    if entry.is_file():
                        name = entry.name
                        # Remove extension to get cache key
                        for ext in self._extensions:
                            if name.endswith(ext):
                                cache_key = name[:-len(ext)]
                                # Determine format
                                if ext.endswith('.meta.json'):
                                    continue  # Skip meta files
                                format_ext = ext
                                self._index[cache_key] = (True, format_ext, time.time())
                                break
        except (OSError, PermissionError):
            # If we can't scan, start with empty index
            pass
    
    def exists(self, cache_key: str) -> Optional[bool]:
        """
        Check if cache exists for the given key.
        
        Args:
            cache_key: Cache key to check
            
        Returns:
            True if cache exists, False if it doesn't, None if unknown
        """
        with self._lock:
            if cache_key in self._index:
                exists, format_ext, timestamp = self._index[cache_key]
                
                # Check if entry is still valid
                if time.time() - timestamp < self.ttl:
                    return exists
                elif self.auto_refresh:
                    # Entry is stale, refresh it
                    return self._check_filesystem(cache_key)
            
            # Not in index, check filesystem
            if self.auto_refresh:
                return self._check_filesystem(cache_key)
            
            return None
    
    def _check_filesystem(self, cache_key: str) -> bool:
        """
        Check filesystem for cache existence and update index.
        
        Args:
            cache_key: Cache key to check
            
        Returns:
            True if cache exists, False otherwise
        """
        cache_path = self.cache_dir / cache_key
        
        # Check all possible formats
        for ext in ['.wav', '.pkl', '.png']:
            data_path = cache_path.with_suffix(ext)
            if data_path.exists():
                self._index[cache_key] = (True, ext, time.time())
                return True
        
        # Not found
        self._index[cache_key] = (False, None, time.time())
        return False
    
    def mark_exists(self, cache_key: str, format_ext: Optional[str] = None) -> None:
        """
        Mark cache as existing in the index.
        
        Useful when we know a cache file was just created.
        
        Args:
            cache_key: Cache key
            format_ext: Optional format extension (e.g., '.wav', '.pkl')
        """
        with self._lock:
            self._index[cache_key] = (True, format_ext, time.time())
    
    def mark_missing(self, cache_key: str) -> None:
        """
        Mark cache as missing in the index.
        
        Args:
            cache_key: Cache key
        """
        with self._lock:
            self._index[cache_key] = (False, None, time.time())
    
    def batch_exists(self, cache_keys: list[str]) -> Dict[str, bool]:
        """
        Check existence for multiple cache keys efficiently.
        
        Uses a single filesystem scan for all keys.
        
        Args:
            cache_keys: List of cache keys to check
            
        Returns:
            Dictionary mapping cache keys to existence status
        """
        results = {}
        
        # First, check what we have in index
        keys_to_check = []
        with self._lock:
            for key in cache_keys:
                if key in self._index:
                    exists, _, timestamp = self._index[key]
                    if time.time() - timestamp < self.ttl:
                        results[key] = exists
                        continue
                keys_to_check.append(key)
        
        # If we need to check filesystem, do batch scan
        if keys_to_check:
            # Get all existing files in cache directory
            existing_files: Set[str] = set()
            if self.cache_dir.exists():
                try:
                    with os.scandir(self.cache_dir) as entries:
                        for entry in entries:
                            if entry.is_file():
                                name = entry.name
                                # Remove extension to get cache key
                                for ext in ['.wav', '.pkl', '.png']:
                                    if name.endswith(ext):
                                        cache_key = name[:-len(ext)]
                                        existing_files.add(cache_key)
                                        break
                except (OSError, PermissionError):
                    pass
            
            # Update index and results
            with self._lock:
                for key in keys_to_check:
                    exists = key in existing_files
                    results[key] = exists
                    # Update index
                    if exists:
                        # Try to determine format
                        format_ext = None
                        for ext in ['.wav', '.pkl', '.png']:
                            if (self.cache_dir / f"{key}{ext}").exists():
                                format_ext = ext
                                break
                        self._index[key] = (True, format_ext, time.time())
                    else:
                        self._index[key] = (False, None, time.time())
        
        return results
    
    def clear(self) -> None:
        """Clear the entire index."""
        with self._lock:
            self._index.clear()
    
    def refresh(self) -> None:
        """Refresh the entire index from filesystem."""
        with self._lock:
            self._index.clear()
        self._load_index()
    
    def get_stats(self) -> Dict[str, int]:
        """
        Get statistics about the index.
        
        Returns:
            Dictionary with index statistics
        """
        with self._lock:
            total = len(self._index)
            existing = sum(1 for exists, _, _ in self._index.values() if exists)
            stale = sum(
                1 for _, _, timestamp in self._index.values()
                if time.time() - timestamp >= self.ttl
            )
            
            return {
                "total_entries": total,
                "existing_entries": existing,
                "missing_entries": total - existing,
                "stale_entries": stale,
            }


