"""
Base RayFrame class for structured data representation.
"""

from abc import ABC
from typing import Dict, Any
from dataclasses import dataclass, field
import torch


@dataclass
class RayFrame(ABC):
    """
    Base RayFrame class for structured data representation.

    All RayFrame subclasses inherit common functionality for working with
    tensor data and metadata.

    Attributes:
        data: Tensor data
        metadata: Additional metadata dictionary
    """

    data: torch.Tensor
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def shape(self) -> tuple:
        """Get the shape of the data tensor."""
        return self.data.shape

    @property
    def dtype(self) -> torch.dtype:
        """Get the data type of the tensor."""
        return self.data.dtype

    def to_dict(self) -> Dict[str, Any]:
        """Convert frame to dictionary representation."""
        return {
            "data": self.data,
            "metadata": self.metadata,
        }

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(shape={self.shape})"

