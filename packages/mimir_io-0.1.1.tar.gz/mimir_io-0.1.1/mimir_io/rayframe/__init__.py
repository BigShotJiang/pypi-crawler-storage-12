"""
RayFrame classes for structured data representation.

RayFrame provides a structured wrapper around tensors with metadata,
enabling type-safe transformations and better data organization.
"""

from mimir_io.rayframe.base import RayFrame
from mimir_io.rayframe.image_frame import ImageRayFrame
from mimir_io.rayframe.audio_frame import AudioRayFrame
from mimir_io.rayframe.mel_frame import MelRayFrame

# Import lenses for each RayFrame type
from mimir_io.rayframe.audio import (
    load_audio_frame,
    to_audio_frame,
    resample_frame,
    normalize_frame,
    trim_silence_frame,
    preemphasis_frame,
    to_mono_frame,
    augment_audio_frame,
    time_shift_frame,
    gain_variation_frame,
    add_noise_frame,
    speed_change_frame,
)
from mimir_io.rayframe.image import (
    to_image_frame,
    mel_to_frame,
    time_mask_frame,
    frequency_mask_frame,
    spec_augment_frame,
    random_horizontal_flip,
    random_vertical_flip,
    random_rotation,
    random_crop,
    center_crop,
    color_jitter,
    random_erasing,
    normalize,
    random_affine,
)
from mimir_io.rayframe.mel import (
    to_mel_frame,
    delta_frame,
    delta_delta_frame,
    stack_delta_features_frame,
)

__all__ = [
    # RayFrame classes
    "RayFrame",
    "ImageRayFrame",
    "AudioRayFrame",
    "MelRayFrame",
    # AudioRayFrame lenses
    "load_audio_frame",
    "to_audio_frame",
    "resample_frame",
    "normalize_frame",
    "trim_silence_frame",
    "preemphasis_frame",
    "to_mono_frame",
    # AudioRayFrame augmentations
    "augment_audio_frame",
    "time_shift_frame",
    "gain_variation_frame",
    "add_noise_frame",
    "speed_change_frame",
    # ImageRayFrame lenses
    "to_image_frame",
    "mel_to_frame",
    "time_mask_frame",
    "frequency_mask_frame",
    "spec_augment_frame",
    # ImageRayFrame augmentations (GPU-accelerated)
    "random_horizontal_flip",
    "random_vertical_flip",
    "random_rotation",
    "random_crop",
    "center_crop",
    "color_jitter",
    "random_erasing",
    "normalize",
    "random_affine",
    # MelRayFrame lenses
    "to_mel_frame",
    "delta_frame",
    "delta_delta_frame",
    "stack_delta_features_frame",
]

