"""
ImageRayFrame for image-like data representation.
"""

from typing import Optional, Dict, Any
from dataclasses import dataclass
from mimir_io.rayframe.base import RayFrame


@dataclass
class ImageRayFrame(RayFrame):
    """
    RayFrame for image-like data (e.g., Mel spectrograms).

    This frame represents 2D or 3D image data with channels, height, and width dimensions.
    Commonly used for Mel spectrograms where dimensions are (channels, n_mels, time_frames).

    Attributes:
        data: Tensor data with shape (C, H, W) or (H, W)
        channels: Number of channels (default: 1)
        height: Height dimension (n_mels for spectrograms)
        width: Width dimension (time_frames for spectrograms)
        sample_rate: Sample rate if applicable (for audio-derived images)
        metadata: Additional metadata dictionary
    """

    channels: int = 1
    height: Optional[int] = None
    width: Optional[int] = None
    sample_rate: Optional[int] = None

    def __post_init__(self):
        """Validate and set dimensions from data if not provided."""
        shape = self.data.shape
        ndim = len(shape)

        if ndim == 2:
            # (H, W) - single channel
            if self.height is None:
                self.height = shape[0]
            if self.width is None:
                self.width = shape[1]
            if self.data.numel() > 0 and self.channels == 1:
                # Add channel dimension only if tensor is not empty
                self.data = self.data.unsqueeze(0)
        elif ndim == 3:
            # (C, H, W) - multi-channel
            # Set channels from shape if not explicitly set (default is 1)
            if self.channels == 1 and shape[0] != 1:
                self.channels = shape[0]
            if self.height is None:
                self.height = shape[1]
            if self.width is None:
                self.width = shape[2]
        else:
            raise ValueError(
                f"ImageRayFrame expects 2D or 3D tensor, got {ndim}D tensor with shape {shape}"
            )

    def to_dict(self) -> Dict[str, Any]:
        """Convert frame to dictionary representation."""
        result = super().to_dict()
        result.update({
            "channels": self.channels,
            "height": self.height,
            "width": self.width,
            "sample_rate": self.sample_rate,
        })
        return result

    def __repr__(self) -> str:
        return (
            f"ImageRayFrame(shape={self.shape}, channels={self.channels}, "
            f"height={self.height}, width={self.width}, "
            f"sample_rate={self.sample_rate})"
        )

