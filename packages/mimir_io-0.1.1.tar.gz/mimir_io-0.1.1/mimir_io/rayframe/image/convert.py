"""
Lenses for creating and converting ImageRayFrame objects.
"""

from typing import Optional
import torch
from mimir_io.lens import Lens
from mimir_io.rayframe import ImageRayFrame


def to_image_frame(
    sample_rate: Optional[int] = None,
    height: Optional[int] = None,
    width: Optional[int] = None,
) -> Lens[torch.Tensor, ImageRayFrame]:
    """
    Create a lens that converts spectrogram tensor to ImageRayFrame.

    Args:
        sample_rate: Optional sample rate (for audio-derived images)
        height: Optional height dimension (n_mels for spectrograms)
        width: Optional width dimension (time_frames for spectrograms)

    Returns:
        Lens that converts tensor to ImageRayFrame
    """
    def _to_frame(spectrogram: torch.Tensor) -> ImageRayFrame:
        return ImageRayFrame(
            data=spectrogram,
            sample_rate=sample_rate,
            height=height,
            width=width,
        )

    return Lens(_to_frame, name="to_image_frame")


def mel_to_frame(sample_rate: int) -> Lens[torch.Tensor, ImageRayFrame]:
    """
    Create a lens that converts Mel spectrogram to ImageRayFrame.

    Args:
        sample_rate: Sample rate of the original audio

    Returns:
        Lens that converts Mel spectrogram to ImageRayFrame
    """
    def _to_frame(mel_spec: torch.Tensor) -> ImageRayFrame:
        # Mel spectrogram shape is typically (n_mels, time_frames)
        # or (channels, n_mels, time_frames)
        height = mel_spec.shape[-2] if len(mel_spec.shape) >= 2 else None
        width = mel_spec.shape[-1] if len(mel_spec.shape) >= 1 else None
        
        # Determine channels from shape
        channels = None
        if len(mel_spec.shape) == 3:
            channels = mel_spec.shape[0]

        return ImageRayFrame(
            data=mel_spec,
            sample_rate=sample_rate,
            height=height,
            width=width,
            channels=channels if channels is not None else 1,
            metadata={"type": "mel_spectrogram"},
        )

    return Lens(_to_frame, name=f"mel_to_frame(sr={sample_rate})")

