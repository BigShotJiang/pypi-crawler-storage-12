"""
Lenses for working with ImageRayFrame.
"""

from mimir_io.rayframe.image.convert import to_image_frame, mel_to_frame
from mimir_io.rayframe.image.augment import (
    time_mask_frame,
    frequency_mask_frame,
    spec_augment_frame,
    random_horizontal_flip,
    random_vertical_flip,
    random_rotation,
    random_crop,
    center_crop,
    color_jitter,
    random_erasing,
    normalize,
    random_affine,
)

__all__ = [
    "to_image_frame",
    "mel_to_frame",
    "time_mask_frame",
    "frequency_mask_frame",
    "spec_augment_frame",
    "random_horizontal_flip",
    "random_vertical_flip",
    "random_rotation",
    "random_crop",
    "center_crop",
    "color_jitter",
    "random_erasing",
    "normalize",
    "random_affine",
]


