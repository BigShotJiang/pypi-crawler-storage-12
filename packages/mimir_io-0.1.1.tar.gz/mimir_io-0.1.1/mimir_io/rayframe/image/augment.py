"""
Augmentation lenses for ImageRayFrame (SpecAugment-style and basic image augmentations).

Includes:
- SpecAugment-style augmentations (time/frequency masking)
- Basic image augmentations (flips, rotation, crop, color jitter, etc.)
- All augmentations are designed to work on GPU tensors.
"""

import torch
import torch.nn.functional as F
import math
from typing import Optional, Tuple
from mimir_io.lens import Lens
from mimir_io.rayframe import ImageRayFrame
from mimir_io.random import get_seed, create_generator


def time_mask_frame(
    max_mask_size: int,
    num_masks: int = 1,
    fill_value: float = 0.0,
    seed: Optional[int] = None,
) -> Lens[ImageRayFrame, ImageRayFrame]:
    """
    Create a lens that applies time masking to ImageRayFrame (SpecAugment).

    Args:
        max_mask_size: Maximum number of time frames to mask
        num_masks: Number of masks to apply
        fill_value: Value to fill masked regions (default: 0.0)
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that applies time masking to ImageRayFrame
    """
    # Store seed for later use, but don't create generator yet
    stored_seed = seed
    
    def _time_mask_frame(frame: ImageRayFrame) -> ImageRayFrame:
        if frame.data.numel() == 0:
            return frame

        # Create generator at execution time, checking global seed
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)

        masked_data = frame.data.clone()
        time_frames = masked_data.shape[-1]

        for _ in range(num_masks):
            mask_size = torch.randint(0, max_mask_size + 1, (1,), generator=gen).item()
            if mask_size == 0 or mask_size >= time_frames:
                continue

            t0 = torch.randint(0, time_frames - mask_size + 1, (1,), generator=gen).item()
            
            if masked_data.dim() == 2:
                # (H, W)
                masked_data[:, t0:t0 + mask_size] = fill_value
            elif masked_data.dim() == 3:
                # (C, H, W)
                masked_data[:, :, t0:t0 + mask_size] = fill_value

        return ImageRayFrame(
            data=masked_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            height=frame.height,
            width=frame.width,
            metadata={**frame.metadata, "time_masked": True},
        )

    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_time_mask_frame, name=f"time_mask_frame(max={max_mask_size}{seed_suffix})")


def frequency_mask_frame(
    max_mask_size: int,
    num_masks: int = 1,
    fill_value: float = 0.0,
    seed: Optional[int] = None,
) -> Lens[ImageRayFrame, ImageRayFrame]:
    """
    Create a lens that applies frequency masking to ImageRayFrame (SpecAugment).

    Args:
        max_mask_size: Maximum number of frequency bins to mask
        num_masks: Number of masks to apply
        fill_value: Value to fill masked regions (default: 0.0)
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that applies frequency masking to ImageRayFrame
    """
    # Store seed for later use, but don't create generator yet
    stored_seed = seed
    
    def _frequency_mask_frame(frame: ImageRayFrame) -> ImageRayFrame:
        if frame.data.numel() == 0:
            return frame

        # Create generator at execution time, checking global seed
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)

        masked_data = frame.data.clone()
        freq_bins = masked_data.shape[-2]

        for _ in range(num_masks):
            mask_size = torch.randint(0, max_mask_size + 1, (1,), generator=gen).item()
            if mask_size == 0 or mask_size >= freq_bins:
                continue

            f0 = torch.randint(0, freq_bins - mask_size + 1, (1,), generator=gen).item()
            
            if masked_data.dim() == 2:
                # (H, W)
                masked_data[f0:f0 + mask_size, :] = fill_value
            elif masked_data.dim() == 3:
                # (C, H, W)
                masked_data[:, f0:f0 + mask_size, :] = fill_value

        return ImageRayFrame(
            data=masked_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            height=frame.height,
            width=frame.width,
            metadata={**frame.metadata, "frequency_masked": True},
        )

    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_frequency_mask_frame, name=f"frequency_mask_frame(max={max_mask_size}{seed_suffix})")


# ========== SpecAugment (повна версія для ImageRayFrame) ==========

def spec_augment_frame(
    time_mask_param: int = 27,
    num_time_masks: int = 2,
    freq_mask_param: int = 12,
    num_freq_masks: int = 2,
    fill_value: float = 0.0,
    seed: Optional[int] = None,
) -> Lens[ImageRayFrame, ImageRayFrame]:
    """
    Повна реалізація SpecAugment для ImageRayFrame (спектрограм).
    
    SpecAugment - це техніка аугментації, яка маскує часові та частотні області
    спектрограми для покращення узагальнення моделі.
    
    Args:
        time_mask_param: Максимальна кількість часових фреймів для маскування
        num_time_masks: Кількість часових масок
        freq_mask_param: Максимальна кількість частотних бінів для маскування
        num_freq_masks: Кількість частотних масок
        fill_value: Значення для заповнення замаскованих областей (зазвичай 0.0 або середнє)
        seed: Опціональний seed для відтворюваності
        
    Returns:
        Lens що застосовує SpecAugment до ImageRayFrame
        
    Example:
        >>> from mimir_io.rayframe.image.augment import spec_augment_frame
        >>> aug = spec_augment_frame(time_mask_param=27, num_time_masks=2, 
        ...                          freq_mask_param=12, num_freq_masks=2)
        >>> augmented_frame = aug(mel_frame)
    """
    stored_seed = seed
    
    def _spec_augment_frame(frame: ImageRayFrame) -> ImageRayFrame:
        if frame.data.numel() == 0:
            return frame
        
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)
        
        masked_data = frame.data.clone()
        
        # Визначаємо розміри
        if frame.data.dim() == 2:
            # (freq_bins, time_frames)
            freq_bins, time_frames = frame.data.shape
        elif frame.data.dim() == 3:
            # (channels, freq_bins, time_frames)
            _, freq_bins, time_frames = frame.data.shape
        else:
            return frame
        
        # Частотне маскування
        for _ in range(num_freq_masks):
            f = torch.randint(0, freq_mask_param + 1, (1,), generator=gen).item()
            if f == 0 or f >= freq_bins:
                continue
                
            f0 = torch.randint(0, freq_bins - f + 1, (1,), generator=gen).item()
            
            if frame.data.dim() == 2:
                masked_data[f0:f0 + f, :] = fill_value
            else:
                masked_data[:, f0:f0 + f, :] = fill_value
        
        # Часове маскування
        for _ in range(num_time_masks):
            t = torch.randint(0, time_mask_param + 1, (1,), generator=gen).item()
            if t == 0 or t >= time_frames:
                continue
                
            t0 = torch.randint(0, time_frames - t + 1, (1,), generator=gen).item()
            
            if frame.data.dim() == 2:
                masked_data[:, t0:t0 + t] = fill_value
            else:
                masked_data[:, :, t0:t0 + t] = fill_value
        
        return ImageRayFrame(
            data=masked_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            height=frame.height,
            width=frame.width,
            metadata={**frame.metadata, "spec_augmented": True},
        )
    
    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(
        _spec_augment_frame,
        name=f"spec_augment_frame(tm={time_mask_param},fm={freq_mask_param}{seed_suffix})"
    )


# ========== Basic Image Augmentations (GPU-accelerated) ==========

def random_horizontal_flip(probability: float = 0.5, seed: Optional[int] = None) -> Lens[ImageRayFrame, ImageRayFrame]:
    """
    Випадкове горизонтальне відображення зображення (GPU-прискорене).
    
    Args:
        probability: Ймовірність застосування відображення (0.0-1.0)
        seed: Опціональний seed для відтворюваності
        
    Returns:
        Lens що застосовує горизонтальне відображення
        
    Example:
        >>> from mimir_io.rayframe.image.augment import random_horizontal_flip
        >>> aug = random_horizontal_flip(probability=0.5)
        >>> flipped_frame = aug(image_frame)
    """
    stored_seed = seed
    
    def _random_horizontal_flip(frame: ImageRayFrame) -> ImageRayFrame:
        if frame.data.numel() == 0:
            return frame
            
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)
        
        # Generate random number on CPU, then use it for logic
        rand_val = torch.rand(1, generator=gen).item()
        if rand_val < probability:
            # Flip along width dimension (last dimension)
            flipped_data = torch.flip(frame.data, dims=[-1])
            
            return ImageRayFrame(
                data=flipped_data,
                sample_rate=frame.sample_rate,
                channels=frame.channels,
                height=frame.height,
                width=frame.width,
                metadata={**frame.metadata, "horizontal_flipped": True},
            )
        
        return frame
    
    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_random_horizontal_flip, name=f"random_horizontal_flip(p={probability}{seed_suffix})")


def random_vertical_flip(probability: float = 0.5, seed: Optional[int] = None) -> Lens[ImageRayFrame, ImageRayFrame]:
    """
    Випадкове вертикальне відображення зображення (GPU-прискорене).
    
    Args:
        probability: Ймовірність застосування відображення (0.0-1.0)
        seed: Опціональний seed для відтворюваності
        
    Returns:
        Lens що застосовує вертикальне відображення
        
    Example:
        >>> from mimir_io.rayframe.image.augment import random_vertical_flip
        >>> aug = random_vertical_flip(probability=0.5)
        >>> flipped_frame = aug(image_frame)
    """
    stored_seed = seed
    
    def _random_vertical_flip(frame: ImageRayFrame) -> ImageRayFrame:
        if frame.data.numel() == 0:
            return frame
            
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)
        
        # Generate random number on CPU, then use it for logic
        rand_val = torch.rand(1, generator=gen).item()
        if rand_val < probability:
            # Flip along height dimension (second to last dimension)
            if frame.data.dim() == 2:
                flipped_data = torch.flip(frame.data, dims=[0])
            else:
                flipped_data = torch.flip(frame.data, dims=[-2])
            
            return ImageRayFrame(
                data=flipped_data,
                sample_rate=frame.sample_rate,
                channels=frame.channels,
                height=frame.height,
                width=frame.width,
                metadata={**frame.metadata, "vertical_flipped": True},
            )
        
        return frame
    
    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_random_vertical_flip, name=f"random_vertical_flip(p={probability}{seed_suffix})")


def random_rotation(degrees: float = 15.0, seed: Optional[int] = None) -> Lens[ImageRayFrame, ImageRayFrame]:
    """
    Випадкове обертання зображення на заданий кут (GPU-прискорене).
    
    Args:
        degrees: Максимальний кут обертання в градусах
        seed: Опціональний seed для відтворюваності
        
    Returns:
        Lens що застосовує випадкове обертання
        
    Example:
        >>> from mimir_io.rayframe.image.augment import random_rotation
        >>> aug = random_rotation(degrees=15.0)
        >>> rotated_frame = aug(image_frame)
    """
    stored_seed = seed
    
    def _random_rotation(frame: ImageRayFrame) -> ImageRayFrame:
        if frame.data.numel() == 0:
            return frame
            
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)
        
        # Random angle in radians (generate on CPU, then convert)
        angle = (torch.rand(1, generator=gen).item() * 2 - 1) * degrees
        angle_rad = math.radians(angle)
        
        if abs(angle) < 0.1:
            return frame
        
        # Prepare data for rotation
        if frame.data.dim() == 2:
            # (H, W) -> (1, 1, H, W) for grid_sample
            data = frame.data.unsqueeze(0).unsqueeze(0)
        else:
            # (C, H, W) -> (1, C, H, W)
            data = frame.data.unsqueeze(0)
        
        # Create rotation matrix
        cos_a = math.cos(angle_rad)
        sin_a = math.sin(angle_rad)
        
        # Center of rotation
        h, w = data.shape[-2], data.shape[-1]
        center_x, center_y = w / 2.0, h / 2.0
        
        # Create affine transformation matrix
        theta = torch.tensor([
            [cos_a, -sin_a, (1 - cos_a) * center_x + sin_a * center_y],
            [sin_a, cos_a, (1 - cos_a) * center_y - sin_a * center_x]
        ], dtype=data.dtype, device=data.device).unsqueeze(0)
        
        # Create grid
        grid = F.affine_grid(theta, data.size(), align_corners=False)
        
        # Apply rotation
        rotated = F.grid_sample(data, grid, mode='bilinear', padding_mode='zeros', align_corners=False)
        
        # Remove batch dimension
        if frame.data.dim() == 2:
            rotated_data = rotated.squeeze(0).squeeze(0)
        else:
            rotated_data = rotated.squeeze(0)
        
        return ImageRayFrame(
            data=rotated_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            height=frame.height,
            width=frame.width,
            metadata={**frame.metadata, "rotated": angle},
        )
    
    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_random_rotation, name=f"random_rotation(deg={degrees}{seed_suffix})")


def random_crop(size: Tuple[int, int], seed: Optional[int] = None) -> Lens[ImageRayFrame, ImageRayFrame]:
    """
    Випадковий кроп зображення до заданого розміру (GPU-прискорене).
    
    Args:
        size: Цільовий розмір (height, width)
        seed: Опціональний seed для відтворюваності
        
    Returns:
        Lens що застосовує випадковий кроп
        
    Example:
        >>> from mimir_io.rayframe.image.augment import random_crop
        >>> aug = random_crop(size=(224, 224))
        >>> cropped_frame = aug(image_frame)
    """
    stored_seed = seed
    target_h, target_w = size
    
    def _random_crop(frame: ImageRayFrame) -> ImageRayFrame:
        if frame.data.numel() == 0:
            return frame
            
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)
        
        # Get current dimensions
        if frame.data.dim() == 2:
            h, w = frame.data.shape
            data = frame.data
        else:
            h, w = frame.data.shape[-2], frame.data.shape[-1]
            data = frame.data
        
        # Check if crop is needed
        if h <= target_h and w <= target_w:
            # If image is smaller, pad it
            pad_h = max(0, target_h - h)
            pad_w = max(0, target_w - w)
            
            if frame.data.dim() == 2:
                padded = F.pad(data.unsqueeze(0), (pad_w // 2, pad_w - pad_w // 2, pad_h // 2, pad_h - pad_h // 2), mode='reflect').squeeze(0)
            else:
                padded = F.pad(data, (pad_w // 2, pad_w - pad_w // 2, pad_h // 2, pad_h - pad_h // 2), mode='reflect')
            
            return ImageRayFrame(
                data=padded,
                sample_rate=frame.sample_rate,
                channels=frame.channels,
                height=padded.shape[-2] if frame.data.dim() == 2 else padded.shape[-2],
                width=padded.shape[-1] if frame.data.dim() == 2 else padded.shape[-1],
                metadata={**frame.metadata, "padded": True},
            )
        
        # Random crop position
        max_h = h - target_h
        max_w = w - target_w
        
        # Generate random integers on CPU
        top = torch.randint(0, max_h + 1, (1,), generator=gen).item()
        left = torch.randint(0, max_w + 1, (1,), generator=gen).item()
        
        if frame.data.dim() == 2:
            cropped_data = data[top:top + target_h, left:left + target_w]
        else:
            cropped_data = data[:, top:top + target_h, left:left + target_w]
        
        return ImageRayFrame(
            data=cropped_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            height=target_h,
            width=target_w,
            metadata={**frame.metadata, "cropped": (top, left)},
        )
    
    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_random_crop, name=f"random_crop(size={size}{seed_suffix})")


def center_crop(size: Tuple[int, int]) -> Lens[ImageRayFrame, ImageRayFrame]:
    """
    Центральний кроп зображення до заданого розміру (GPU-прискорене).
    
    Args:
        size: Цільовий розмір (height, width)
        
    Returns:
        Lens що застосовує центральний кроп
        
    Example:
        >>> from mimir_io.rayframe.image.augment import center_crop
        >>> aug = center_crop(size=(224, 224))
        >>> cropped_frame = aug(image_frame)
    """
    target_h, target_w = size
    
    def _center_crop(frame: ImageRayFrame) -> ImageRayFrame:
        if frame.data.numel() == 0:
            return frame
        
        # Get current dimensions
        if frame.data.dim() == 2:
            h, w = frame.data.shape
            data = frame.data
        else:
            h, w = frame.data.shape[-2], frame.data.shape[-1]
            data = frame.data
        
        # Check if crop is needed
        if h <= target_h and w <= target_w:
            # If image is smaller, pad it
            pad_h = max(0, target_h - h)
            pad_w = max(0, target_w - w)
            
            if frame.data.dim() == 2:
                padded = F.pad(data.unsqueeze(0), (pad_w // 2, pad_w - pad_w // 2, pad_h // 2, pad_h - pad_h // 2), mode='reflect').squeeze(0)
            else:
                padded = F.pad(data, (pad_w // 2, pad_w - pad_w // 2, pad_h // 2, pad_h - pad_h // 2), mode='reflect')
            
            return ImageRayFrame(
                data=padded,
                sample_rate=frame.sample_rate,
                channels=frame.channels,
                height=padded.shape[-2] if frame.data.dim() == 2 else padded.shape[-2],
                width=padded.shape[-1] if frame.data.dim() == 2 else padded.shape[-1],
                metadata={**frame.metadata, "padded": True},
            )
        
        # Center crop
        top = (h - target_h) // 2
        left = (w - target_w) // 2
        
        if frame.data.dim() == 2:
            cropped_data = data[top:top + target_h, left:left + target_w]
        else:
            cropped_data = data[:, top:top + target_h, left:left + target_w]
        
        return ImageRayFrame(
            data=cropped_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            height=target_h,
            width=target_w,
            metadata={**frame.metadata, "center_cropped": True},
        )
    
    return Lens(_center_crop, name=f"center_crop(size={size})")


def color_jitter(
    brightness: float = 0.0,
    contrast: float = 0.0,
    saturation: float = 0.0,
    hue: float = 0.0,
    seed: Optional[int] = None,
) -> Lens[ImageRayFrame, ImageRayFrame]:
    """
    Випадкове змінювання кольорів зображення (GPU-прискорене).
    
    Args:
        brightness: Максимальна зміна яскравості (0.0-1.0)
        contrast: Максимальна зміна контрасту (0.0-1.0)
        saturation: Максимальна зміна насиченості (0.0-1.0)
        hue: Максимальна зміна відтінку (0.0-0.5)
        seed: Опціональний seed для відтворюваності
        
    Returns:
        Lens що застосовує color jitter
        
    Example:
        >>> from mimir_io.rayframe.image.augment import color_jitter
        >>> aug = color_jitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1)
        >>> jittered_frame = aug(image_frame)
    """
    stored_seed = seed
    
    def _color_jitter(frame: ImageRayFrame) -> ImageRayFrame:
        if frame.data.numel() == 0:
            return frame
            
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)
        
        data = frame.data.clone()
        
        # Apply brightness
        if brightness > 0:
            brightness_factor = 1.0 + (torch.rand(1, generator=gen).item() * 2 - 1) * brightness
            if frame.data.dim() == 2:
                data = data * brightness_factor
            else:
                data = data * brightness_factor
        
        # Apply contrast
        if contrast > 0:
            contrast_factor = 1.0 + (torch.rand(1, generator=gen).item() * 2 - 1) * contrast
            if frame.data.dim() == 2:
                mean = data.mean()
                data = (data - mean) * contrast_factor + mean
            else:
                # For multi-channel, apply per-channel
                for c in range(data.shape[0]):
                    mean = data[c].mean()
                    data[c] = (data[c] - mean) * contrast_factor + mean
        
        # Apply saturation (only for multi-channel images)
        if saturation > 0 and frame.data.dim() == 3 and frame.channels >= 3:
            saturation_factor = 1.0 + (torch.rand(1, generator=gen).item() * 2 - 1) * saturation
            # Convert to grayscale and blend
            gray = data.mean(dim=0, keepdim=True).expand_as(data)
            data = data * saturation_factor + gray * (1 - saturation_factor)
        
        # Apply hue (only for RGB images)
        if hue > 0 and frame.data.dim() == 3 and frame.channels >= 3:
            hue_factor = (torch.rand(1, generator=gen).item() * 2 - 1) * hue
            # Simple hue rotation for RGB
            # This is a simplified version - full HSV conversion would be more accurate
            if frame.channels >= 3:
                # Rotate RGB channels
                shift = int(hue_factor * 3)
                if shift != 0:
                    data[:3] = torch.roll(data[:3], shift, dims=0)
        
        return ImageRayFrame(
            data=data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            height=frame.height,
            width=frame.width,
            metadata={**frame.metadata, "color_jittered": True},
        )
    
    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_color_jitter, name=f"color_jitter(b={brightness},c={contrast},s={saturation},h={hue}{seed_suffix})")


def random_erasing(
    probability: float = 0.5,
    scale: Tuple[float, float] = (0.02, 0.33),
    ratio: Tuple[float, float] = (0.3, 3.3),
    value: float = 0.0,
    seed: Optional[int] = None,
) -> Lens[ImageRayFrame, ImageRayFrame]:
    """
    Випадкове стирання області зображення (Random Erasing, GPU-прискорене).
    
    Args:
        probability: Ймовірність застосування стирання
        scale: Діапазон площі стирання відносно зображення
        ratio: Діапазон співвідношення сторін стирання
        value: Значення для заповнення стираної області
        seed: Опціональний seed для відтворюваності
        
    Returns:
        Lens що застосовує random erasing
        
    Example:
        >>> from mimir_io.rayframe.image.augment import random_erasing
        >>> aug = random_erasing(probability=0.5, scale=(0.02, 0.33))
        >>> erased_frame = aug(image_frame)
    """
    stored_seed = seed
    
    def _random_erasing(frame: ImageRayFrame) -> ImageRayFrame:
        if frame.data.numel() == 0:
            return frame
            
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)
        
        # Generate random number on CPU
        rand_val = torch.rand(1, generator=gen).item()
        if rand_val >= probability:
            return frame
        
        data = frame.data.clone()
        
        # Get dimensions
        if frame.data.dim() == 2:
            h, w = frame.data.shape
        else:
            h, w = frame.data.shape[-2], frame.data.shape[-1]
        
        # Random area (generate on CPU)
        area = h * w
        target_area = area * (torch.rand(1, generator=gen).item() * (scale[1] - scale[0]) + scale[0])
        aspect_ratio = torch.rand(1, generator=gen).item() * (ratio[1] - ratio[0]) + ratio[0]
        
        # Calculate erasing size
        erase_h = int(round(math.sqrt(target_area * aspect_ratio)))
        erase_w = int(round(math.sqrt(target_area / aspect_ratio)))
        
        if erase_h < h and erase_w < w:
            # Random position (generate on CPU)
            top = torch.randint(0, h - erase_h + 1, (1,), generator=gen).item()
            left = torch.randint(0, w - erase_w + 1, (1,), generator=gen).item()
            
            # Erase
            if frame.data.dim() == 2:
                data[top:top + erase_h, left:left + erase_w] = value
            else:
                data[:, top:top + erase_h, left:left + erase_w] = value
        
        return ImageRayFrame(
            data=data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            height=frame.height,
            width=frame.width,
            metadata={**frame.metadata, "random_erased": True},
        )
    
    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_random_erasing, name=f"random_erasing(p={probability}{seed_suffix})")


def normalize(
    mean: Tuple[float, ...],
    std: Tuple[float, ...],
) -> Lens[ImageRayFrame, ImageRayFrame]:
    """
    Нормалізація зображення за середнім та стандартним відхиленням (GPU-прискорене).
    
    Args:
        mean: Середнє значення для кожного каналу
        std: Стандартне відхилення для кожного каналу
        
    Returns:
        Lens що застосовує нормалізацію
        
    Example:
        >>> from mimir_io.rayframe.image.augment import normalize
        >>> aug = normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225))
        >>> normalized_frame = aug(image_frame)
    """
    mean_tensor = torch.tensor(mean, dtype=torch.float32)
    std_tensor = torch.tensor(std, dtype=torch.float32)
    
    def _normalize(frame: ImageRayFrame) -> ImageRayFrame:
        if frame.data.numel() == 0:
            return frame
        
        data = frame.data.clone().float()
        
        # Move mean and std to same device as data
        mean_t = mean_tensor.to(data.device)
        std_t = std_tensor.to(data.device)
        
        if frame.data.dim() == 2:
            # Single channel - use first mean/std
            data = (data - mean_t[0]) / std_t[0]
        else:
            # Multi-channel
            for c in range(min(len(mean_t), data.shape[0])):
                data[c] = (data[c] - mean_t[c]) / std_t[c]
        
        return ImageRayFrame(
            data=data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            height=frame.height,
            width=frame.width,
            metadata={**frame.metadata, "normalized": True},
        )
    
    return Lens(_normalize, name=f"normalize(mean={mean},std={std})")


def random_affine(
    degrees: float = 0.0,
    translate: Tuple[float, float] = (0.0, 0.0),
    scale: Tuple[float, float] = (1.0, 1.0),
    shear: float = 0.0,
    seed: Optional[int] = None,
) -> Lens[ImageRayFrame, ImageRayFrame]:
    """
    Випадкові афінні трансформації зображення (GPU-прискорене).
    
    Args:
        degrees: Максимальний кут обертання в градусах
        translate: Максимальний зсув (width, height) як частка розміру
        scale: Діапазон масштабування (min, max)
        shear: Максимальний кут зсуву в градусах
        seed: Опціональний seed для відтворюваності
        
    Returns:
        Lens що застосовує випадкові афінні трансформації
        
    Example:
        >>> from mimir_io.rayframe.image.augment import random_affine
        >>> aug = random_affine(degrees=15, translate=(0.1, 0.1), scale=(0.9, 1.1))
        >>> transformed_frame = aug(image_frame)
    """
    stored_seed = seed
    
    def _random_affine(frame: ImageRayFrame) -> ImageRayFrame:
        if frame.data.numel() == 0:
            return frame
            
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)
        
        # Prepare data
        if frame.data.dim() == 2:
            data = frame.data.unsqueeze(0).unsqueeze(0)
        else:
            data = frame.data.unsqueeze(0)
        
        h, w = data.shape[-2], data.shape[-1]
        
        # Random parameters (generate on CPU)
        angle = (torch.rand(1, generator=gen).item() * 2 - 1) * degrees
        tx = (torch.rand(1, generator=gen).item() * 2 - 1) * translate[0] * w
        ty = (torch.rand(1, generator=gen).item() * 2 - 1) * translate[1] * h
        scale_factor = torch.rand(1, generator=gen).item() * (scale[1] - scale[0]) + scale[0]
        shear_x = (torch.rand(1, generator=gen).item() * 2 - 1) * shear
        shear_y = (torch.rand(1, generator=gen).item() * 2 - 1) * shear
        
        # Convert to radians
        angle_rad = math.radians(angle)
        shear_x_rad = math.radians(shear_x)
        shear_y_rad = math.radians(shear_y)
        
        # Build affine matrix
        cos_a = math.cos(angle_rad)
        sin_a = math.sin(angle_rad)
        
        # Center
        center_x, center_y = w / 2.0, h / 2.0
        
        # Affine transformation matrix
        theta = torch.zeros(2, 3, dtype=data.dtype, device=data.device)
        
        # Rotation and scale
        theta[0, 0] = cos_a * scale_factor
        theta[0, 1] = -sin_a * scale_factor
        theta[1, 0] = sin_a * scale_factor
        theta[1, 1] = cos_a * scale_factor
        
        # Shear
        theta[0, 1] += shear_x_rad * cos_a * scale_factor
        theta[1, 1] += shear_x_rad * sin_a * scale_factor
        
        # Translation
        theta[0, 2] = tx + (1 - cos_a) * center_x + sin_a * center_y
        theta[1, 2] = ty + (1 - cos_a) * center_y - sin_a * center_x
        
        theta = theta.unsqueeze(0)
        
        # Create grid and apply transformation
        grid = F.affine_grid(theta, data.size(), align_corners=False)
        transformed = F.grid_sample(data, grid, mode='bilinear', padding_mode='zeros', align_corners=False)
        
        # Remove batch dimension
        if frame.data.dim() == 2:
            transformed_data = transformed.squeeze(0).squeeze(0)
        else:
            transformed_data = transformed.squeeze(0)
        
        return ImageRayFrame(
            data=transformed_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            height=frame.height,
            width=frame.width,
            metadata={**frame.metadata, "affine_transformed": True},
        )
    
    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_random_affine, name=f"random_affine(deg={degrees}{seed_suffix})")

