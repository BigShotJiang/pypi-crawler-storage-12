"""
Lenses for working with AudioRayFrame.
"""

from mimir_io.rayframe.audio.load import load_audio_frame, to_audio_frame
from mimir_io.rayframe.audio.transform import (
    resample_frame,
    normalize_frame,
    trim_silence_frame,
    preemphasis_frame,
    to_mono_frame,
)
from mimir_io.rayframe.audio.augment import (
    augment_audio_frame,
    time_shift_frame,
    gain_variation_frame,
    add_noise_frame,
    speed_change_frame,
)

__all__ = [
    "load_audio_frame",
    "to_audio_frame",
    "resample_frame",
    "normalize_frame",
    "trim_silence_frame",
    "preemphasis_frame",
    "to_mono_frame",
    # Augmentations
    "augment_audio_frame",
    "time_shift_frame",
    "gain_variation_frame",
    "add_noise_frame",
    "speed_change_frame",
]

