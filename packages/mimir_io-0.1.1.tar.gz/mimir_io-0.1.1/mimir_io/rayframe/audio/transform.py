"""
Transformation lenses for AudioRayFrame.
"""

from typing import Optional
import torch
import torchaudio
from mimir_io.lens import Lens
from mimir_io.rayframe import AudioRayFrame
from mimir_io.audio.resample import resample as resample_tensor
from mimir_io.audio.transform import normalize as normalize_tensor
from mimir_io.audio.transform import trim_silence as trim_silence_tensor
from mimir_io.audio.preemphasis import preemphasis as preemphasis_tensor


def resample_frame(
    target_sample_rate: int,
    resampling_method: str = "sinc_interp_kaiser",
    lowpass_filter_width: int = 64,
    rolloff: float = 0.99,
) -> Lens[AudioRayFrame, AudioRayFrame]:
    """
    Create a lens that resamples AudioRayFrame to a target sample rate.

    Args:
        target_sample_rate: Target sample rate in Hz
        resampling_method: Resampling method
        lowpass_filter_width: Width of low-pass filter
        rolloff: Rolloff frequency as fraction of Nyquist

    Returns:
        Lens that resamples AudioRayFrame
    """
    def _resample_frame(frame: AudioRayFrame) -> AudioRayFrame:
        if frame.sample_rate == target_sample_rate:
            return frame

        resample_lens = resample_tensor(
            target_sample_rate=target_sample_rate,
            orig_sample_rate=frame.sample_rate,
            resampling_method=resampling_method,
            lowpass_filter_width=lowpass_filter_width,
            rolloff=rolloff,
        )

        resampled_data = resample_lens(frame.data)
        return AudioRayFrame(
            data=resampled_data,
            sample_rate=target_sample_rate,
            metadata={**frame.metadata, "resampled_from": frame.sample_rate},
        )

    return Lens(_resample_frame, name=f"resample_frame({target_sample_rate}Hz)")


def normalize_frame(target_db: float = -20.0) -> Lens[AudioRayFrame, AudioRayFrame]:
    """
    Create a lens that normalizes AudioRayFrame to a target dB level.

    Args:
        target_db: Target decibel level

    Returns:
        Lens that normalizes AudioRayFrame
    """
    normalize_lens = normalize_tensor(target_db=target_db)

    def _normalize_frame(frame: AudioRayFrame) -> AudioRayFrame:
        normalized_data = normalize_lens(frame.data)
        return AudioRayFrame(
            data=normalized_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            metadata={**frame.metadata, "normalized_to_db": target_db},
        )

    return Lens(_normalize_frame, name=f"normalize_frame({target_db}dB)")


def trim_silence_frame(threshold: float = 0.01) -> Lens[AudioRayFrame, AudioRayFrame]:
    """
    Create a lens that trims silence from AudioRayFrame.

    Args:
        threshold: Amplitude threshold below which is considered silence

    Returns:
        Lens that trims silence from AudioRayFrame
    """
    trim_lens = trim_silence_tensor(threshold=threshold)

    def _trim_silence_frame(frame: AudioRayFrame) -> AudioRayFrame:
        trimmed_data = trim_lens(frame.data)
        return AudioRayFrame(
            data=trimmed_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            metadata={**frame.metadata, "trimmed_silence": threshold},
        )

    return Lens(_trim_silence_frame, name=f"trim_silence_frame({threshold})")


def preemphasis_frame(coeff: float = 0.97) -> Lens[AudioRayFrame, AudioRayFrame]:
    """
    Create a lens that applies pre-emphasis filter to AudioRayFrame.

    Args:
        coeff: Pre-emphasis coefficient (default: 0.97)

    Returns:
        Lens that applies pre-emphasis to AudioRayFrame
    """
    preemphasis_lens = preemphasis_tensor(coeff=coeff)

    def _preemphasis_frame(frame: AudioRayFrame) -> AudioRayFrame:
        emphasized_data = preemphasis_lens(frame.data)
        return AudioRayFrame(
            data=emphasized_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            metadata={**frame.metadata, "preemphasis_coeff": coeff},
        )

    return Lens(_preemphasis_frame, name=f"preemphasis_frame({coeff})")


def to_mono_frame(method: str = "average") -> Lens[AudioRayFrame, AudioRayFrame]:
    """
    Create a lens that converts AudioRayFrame to mono.

    Args:
        method: Conversion method - "average" (default) or "select" (selects first channel)

    Returns:
        Lens that converts to mono AudioRayFrame
    """
    def _to_mono_frame(frame: AudioRayFrame) -> AudioRayFrame:
        if frame.channels == 1:
            return frame

        if method == "average":
            mono_data = frame.data.mean(dim=0, keepdim=True)
        elif method == "select":
            mono_data = frame.data[0:1]
        else:
            raise ValueError(f"Unknown method: {method}. Use 'average' or 'select'")

        return AudioRayFrame(
            data=mono_data,
            sample_rate=frame.sample_rate,
            channels=1,
            metadata={**frame.metadata, "converted_to_mono": method},
        )

    return Lens(_to_mono_frame, name=f"to_mono_frame({method})")

