"""
Fast augmentation lenses for AudioRayFrame.
"""

from typing import Optional, Tuple
import torch
from mimir_io.lens import Lens
from mimir_io.rayframe import AudioRayFrame
from mimir_io.audio.augment import (
    time_shift,
    gain_variation,
    add_noise,
    time_mask,
    speed_change,
    pitch_shift,
    random_pitch_shift,
    time_stretch,
    reverb,
    bandpass_filter,
    highpass_filter,
    lowpass_filter,
    polarity_inversion,
    clipping_distortion,
    echo,
    compose_augmentations,
)


def augment_audio_frame(
    time_shift_max: Optional[int] = None,
    gain_range: Optional[Tuple[float, float]] = None,
    noise_snr: Optional[float] = None,
    time_mask_max: Optional[int] = None,
    num_time_masks: int = 1,
    speed_range: Optional[Tuple[float, float]] = None,
    pitch_steps: Optional[float] = None,
    pitch_range: Optional[Tuple[float, float]] = None,
    time_stretch_range: Optional[Tuple[float, float]] = None,
    reverb_room_size: Optional[float] = None,
    bandpass_range: Optional[Tuple[float, float]] = None,
    apply_polarity_inversion: bool = False,
    clipping_range: Optional[Tuple[float, float]] = None,
    echo_params: Optional[Tuple[float, float, int]] = None,
    seed: Optional[int] = None,
) -> Lens[AudioRayFrame, AudioRayFrame]:
    """
    Create a composite augmentation lens for AudioRayFrame.

    Args:
        time_shift_max: Maximum time shift in samples
        gain_range: (min_gain, max_gain) tuple for gain variation
        noise_snr: SNR in dB for noise injection
        time_mask_max: Maximum samples to mask
        num_time_masks: Number of time masks to apply
        speed_range: (min_speed, max_speed) tuple for speed change
        pitch_steps: Fixed semitones to shift pitch
        pitch_range: (min_steps, max_steps) tuple for random pitch shift
        time_stretch_range: (min_rate, max_rate) tuple for time stretching
        reverb_room_size: Room size for reverb (0.0-1.0)
        bandpass_range: (low_freq, high_freq) tuple for bandpass filtering
        apply_polarity_inversion: Whether to randomly invert polarity
        clipping_range: (min_threshold, max_threshold) tuple for clipping
        echo_params: (delay_ms, decay, num_echos) tuple for echo effect
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that applies selected augmentations to AudioRayFrame

    Example:
        lens = augment_audio_frame(
            time_shift_max=1600,
            gain_range=(0.7, 1.3),
            noise_snr=20.0,
            speed_range=(0.9, 1.1),
            time_stretch_range=(0.9, 1.1),
            reverb_room_size=0.3,
            bandpass_range=(300, 3400),
            apply_polarity_inversion=True,
            echo_params=(100, 0.3, 1)
        )
        augmented_frame = lens(audio_frame)
    """
    def _augment(frame: AudioRayFrame) -> AudioRayFrame:
        waveform = frame.data
        augs = []

        if time_shift_max:
            augs.append(time_shift(time_shift_max, seed=seed))
        if gain_range:
            augs.append(gain_variation(gain_range[0], gain_range[1], seed=seed))
        if noise_snr is not None:
            augs.append(add_noise(noise_snr, seed=seed))
        if time_mask_max:
            augs.append(time_mask(time_mask_max, num_time_masks, seed=seed))
        if speed_range:
            augs.append(speed_change(frame.sample_rate, speed_range[0], speed_range[1], seed=seed))
        if pitch_steps is not None:
            augs.append(pitch_shift(frame.sample_rate, pitch_steps))
        elif pitch_range:
            augs.append(random_pitch_shift(frame.sample_rate, pitch_range[0], pitch_range[1], seed=seed))
        if time_stretch_range:
            augs.append(time_stretch(frame.sample_rate, time_stretch_range[0], time_stretch_range[1], seed=seed))
        if reverb_room_size is not None:
            augs.append(reverb(room_size=reverb_room_size, seed=seed))
        if bandpass_range:
            augs.append(bandpass_filter(frame.sample_rate, bandpass_range[0], bandpass_range[1]))
        if apply_polarity_inversion:
            augs.append(polarity_inversion(seed=seed))
        if clipping_range:
            augs.append(clipping_distortion(clipping_range[0], clipping_range[1], seed=seed))
        if echo_params:
            delay_ms, decay, num_echos = echo_params
            augs.append(echo(frame.sample_rate, delay_ms, decay, num_echos))

        # Apply augmentations
        for aug in augs:
            waveform = aug(waveform)

        # Recalculate duration if waveform length changed
        new_duration = waveform.shape[-1] / frame.sample_rate

        return AudioRayFrame(
            data=waveform,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            duration=new_duration,
            metadata={**frame.metadata, "augmented": True},
        )

    return Lens(_augment, name="augment_audio_frame")


def time_shift_frame(max_shift_samples: int, seed: Optional[int] = None) -> Lens[AudioRayFrame, AudioRayFrame]:
    """
    Time shift augmentation for AudioRayFrame.

    Args:
        max_shift_samples: Maximum number of samples to shift
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that applies time shifting
    """
    def _time_shift_frame(frame: AudioRayFrame) -> AudioRayFrame:
        shifted_data = time_shift(max_shift_samples, seed=seed)(frame.data)
        return AudioRayFrame(
            data=shifted_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            duration=frame.duration,
            metadata={**frame.metadata, "time_shifted": True},
        )

    return Lens(_time_shift_frame, name=f"time_shift_frame(max={max_shift_samples})")


def gain_variation_frame(
    min_gain: float = 0.5, max_gain: float = 1.5, seed: Optional[int] = None
) -> Lens[AudioRayFrame, AudioRayFrame]:
    """
    Gain variation augmentation for AudioRayFrame.

    Args:
        min_gain: Minimum gain multiplier
        max_gain: Maximum gain multiplier
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that applies gain variation
    """
    def _gain_variation_frame(frame: AudioRayFrame) -> AudioRayFrame:
        augmented_data = gain_variation(min_gain, max_gain, seed=seed)(frame.data)
        return AudioRayFrame(
            data=augmented_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            duration=frame.duration,
            metadata={**frame.metadata, "gain_varied": True},
        )

    return Lens(_gain_variation_frame, name=f"gain_variation_frame({min_gain}-{max_gain})")


def add_noise_frame(snr_db: float = 20.0, seed: Optional[int] = None) -> Lens[AudioRayFrame, AudioRayFrame]:
    """
    Noise injection augmentation for AudioRayFrame.

    Args:
        snr_db: Signal-to-noise ratio in dB
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that adds noise
    """
    def _add_noise_frame(frame: AudioRayFrame) -> AudioRayFrame:
        noisy_data = add_noise(snr_db, seed=seed)(frame.data)
        return AudioRayFrame(
            data=noisy_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            duration=frame.duration,
            metadata={**frame.metadata, "noise_added": True},
        )

    return Lens(_add_noise_frame, name=f"add_noise_frame(snr={snr_db}dB)")


def speed_change_frame(
    min_speed: float = 0.9, max_speed: float = 1.1, seed: Optional[int] = None
) -> Lens[AudioRayFrame, AudioRayFrame]:
    """
    Speed change augmentation for AudioRayFrame.

    Args:
        min_speed: Minimum speed multiplier
        max_speed: Maximum speed multiplier
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that changes playback speed
    """
    def _speed_change_frame(frame: AudioRayFrame) -> AudioRayFrame:
        speed_changed_data = speed_change(frame.sample_rate, min_speed, max_speed, seed=seed)(frame.data)
        new_duration = speed_changed_data.shape[-1] / frame.sample_rate
        return AudioRayFrame(
            data=speed_changed_data,
            sample_rate=frame.sample_rate,
            channels=frame.channels,
            duration=new_duration,
            metadata={**frame.metadata, "speed_changed": True},
        )

    return Lens(_speed_change_frame, name=f"speed_change_frame({min_speed}-{max_speed})")

