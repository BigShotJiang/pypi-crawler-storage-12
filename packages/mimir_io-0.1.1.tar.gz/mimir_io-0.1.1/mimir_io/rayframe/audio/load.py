"""
Lenses for loading and creating AudioRayFrame objects.
"""

from pathlib import Path
from typing import Union, Optional
import torch
from mimir_io.lens import Lens
from mimir_io.rayframe import AudioRayFrame
from mimir_io.audio.load import _load_audio_file


def load_audio_frame(
    path: Union[str, Path], backend: Optional[str] = None
) -> Lens[None, AudioRayFrame]:
    """
    Create a lens that loads audio and returns AudioRayFrame.

    Supports WAV, MP3, FLAC, OGG, M4A, and AAC formats with automatic
    backend selection and fallback.

    Args:
        path: Path to audio file
        backend: Optional backend name ('soundfile', 'sox', 'ffmpeg').
                 If None, automatically selects best backend for format.

    Returns:
        Lens that loads audio as AudioRayFrame

    Example:
        # Load WAV file as AudioRayFrame
        lens = load_audio_frame("audio.wav")
        audio_frame = lens(None)

        # Load MP3 file (auto-detects backend)
        lens = load_audio_frame("audio.mp3")
        audio_frame = lens(None)

        # Load FLAC file with explicit backend
        lens = load_audio_frame("audio.flac", backend="soundfile")
        audio_frame = lens(None)
    """
    path = Path(path)

    def _load(_: None) -> AudioRayFrame:
        waveform, sample_rate = _load_audio_file(path, backend)
        return AudioRayFrame(
            data=waveform,
            sample_rate=sample_rate,
            metadata={"source_path": str(path), "format": path.suffix.lower()},
        )

    return Lens(_load, name=f"load_audio_frame({path.name})")


def to_audio_frame(sample_rate: int) -> Lens[torch.Tensor, AudioRayFrame]:
    """
    Create a lens that converts waveform tensor to AudioRayFrame.

    Args:
        sample_rate: Sample rate in Hz

    Returns:
        Lens that converts tensor to AudioRayFrame
    """
    def _to_frame(waveform: torch.Tensor) -> AudioRayFrame:
        return AudioRayFrame(data=waveform, sample_rate=sample_rate)

    return Lens(_to_frame, name=f"to_audio_frame(sr={sample_rate})")

