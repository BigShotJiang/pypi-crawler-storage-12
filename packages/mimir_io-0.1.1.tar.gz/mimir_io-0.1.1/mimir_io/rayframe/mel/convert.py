"""
Lenses for creating and converting MelRayFrame objects.
"""

from typing import Optional
import torch
from mimir_io.lens import Lens
from mimir_io.rayframe import MelRayFrame


def to_mel_frame(
    sample_rate: int,
    n_mels: int,
    n_fft: int,
    hop_length: int,
    win_length: Optional[int] = None,
    f_min: float = 0.0,
    f_max: Optional[float] = None,
) -> Lens[torch.Tensor, MelRayFrame]:
    """
    Create a lens that converts Mel spectrogram tensor to MelRayFrame.

    Args:
        sample_rate: Sample rate of the original audio
        n_mels: Number of mel filterbanks
        n_fft: Size of FFT used
        hop_length: Length of hop between STFT windows
        win_length: Window size used for STFT (defaults to n_fft)
        f_min: Minimum frequency in Hz
        f_max: Maximum frequency in Hz (defaults to sample_rate // 2)

    Returns:
        Lens that converts Mel spectrogram to MelRayFrame

    Example:
        lens = to_mel_frame(
            sample_rate=16000,
            n_mels=80,
            n_fft=2048,
            hop_length=512,
        )
        mel_frame = lens(mel_spec)
    """
    def _to_frame(mel_spec: torch.Tensor) -> MelRayFrame:
        return MelRayFrame(
            data=mel_spec,
            sample_rate=sample_rate,
            n_mels=n_mels,
            n_fft=n_fft,
            hop_length=hop_length,
            win_length=win_length,
            f_min=f_min,
            f_max=f_max,
        )

    return Lens(
        _to_frame,
        name=f"to_mel_frame(sr={sample_rate},n_mels={n_mels})",
    )



