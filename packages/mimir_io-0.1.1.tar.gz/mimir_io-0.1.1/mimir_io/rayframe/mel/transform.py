"""
Transformation lenses for MelRayFrame (delta features).
"""

import torch
import torchaudio
from mimir_io.lens import Lens
from mimir_io.rayframe import MelRayFrame


def delta_frame(
    win_length: int = 5,
    mode: str = "replicate",
) -> Lens[MelRayFrame, MelRayFrame]:
    """
    Create a lens that computes delta (first derivative) features from MelRayFrame.

    Delta features represent the rate of change of spectral features over time.

    Args:
        win_length: Length of the window used for computing delta (default: 5)
                   Must be odd. Larger values smooth the delta computation.
        mode: Padding mode for edge frames - "replicate", "constant", or "reflect"

    Returns:
        Lens that computes delta features from MelRayFrame

    Example:
        lens = delta_frame(win_length=5)
        delta_frame_result = lens(mel_frame)
    """
    if win_length % 2 == 0:
        raise ValueError(f"win_length must be odd, got {win_length}")

    delta_transform = torchaudio.transforms.ComputeDeltas(
        win_length=win_length,
        mode=mode,
    )

    def _delta_frame(frame: MelRayFrame) -> MelRayFrame:
        if frame.data.numel() == 0:
            return frame

        # Remove channel dimension temporarily for delta computation
        # Delta expects (n_mels, time_frames) or (n_mfcc, time_frames)
        if frame.data.dim() == 3:
            # (channels, n_mels, time_frames) -> (n_mels, time_frames)
            data_2d = frame.data.squeeze(0) if frame.channels == 1 else frame.data[0]
        else:
            data_2d = frame.data

        delta_data = delta_transform(data_2d)

        # Add channel dimension back if needed
        if frame.data.dim() == 3:
            delta_data = delta_data.unsqueeze(0)

        return MelRayFrame(
            data=delta_data,
            sample_rate=frame.sample_rate,
            n_mels=frame.n_mels,
            n_fft=frame.n_fft,
            hop_length=frame.hop_length,
            win_length=frame.win_length,
            f_min=frame.f_min,
            f_max=frame.f_max,
            metadata={**frame.metadata, "delta_features": True, "delta_win_length": win_length},
        )

    return Lens(_delta_frame, name=f"delta_frame(win={win_length})")


def delta_delta_frame(
    win_length: int = 5,
    mode: str = "replicate",
) -> Lens[MelRayFrame, MelRayFrame]:
    """
    Create a lens that computes delta-delta (second derivative) features from MelRayFrame.

    Delta-delta features represent the acceleration of spectral features over time.

    Args:
        win_length: Length of the window used for computing delta (default: 5)
                   Must be odd.
        mode: Padding mode for edge frames - "replicate", "constant", or "reflect"

    Returns:
        Lens that computes delta-delta features from MelRayFrame
    """
    if win_length % 2 == 0:
        raise ValueError(f"win_length must be odd, got {win_length}")

    delta_transform = torchaudio.transforms.ComputeDeltas(
        win_length=win_length,
        mode=mode,
    )

    def _delta_delta_frame(frame: MelRayFrame) -> MelRayFrame:
        if frame.data.numel() == 0:
            return frame

        # Remove channel dimension temporarily
        if frame.data.dim() == 3:
            data_2d = frame.data.squeeze(0) if frame.channels == 1 else frame.data[0]
        else:
            data_2d = frame.data

        # Compute delta first
        delta_features = delta_transform(data_2d)
        # Compute delta-delta (delta of delta)
        delta_delta_features = delta_transform(delta_features)

        # Add channel dimension back if needed
        if frame.data.dim() == 3:
            delta_delta_features = delta_delta_features.unsqueeze(0)

        return MelRayFrame(
            data=delta_delta_features,
            sample_rate=frame.sample_rate,
            n_mels=frame.n_mels,
            n_fft=frame.n_fft,
            hop_length=frame.hop_length,
            win_length=frame.win_length,
            f_min=frame.f_min,
            f_max=frame.f_max,
            metadata={**frame.metadata, "delta_delta_features": True, "delta_win_length": win_length},
        )

    return Lens(_delta_delta_frame, name=f"delta_delta_frame(win={win_length})")


def stack_delta_features_frame(
    win_length: int = 5,
    mode: str = "replicate",
) -> Lens[MelRayFrame, MelRayFrame]:
    """
    Create a lens that stacks original, delta, and delta-delta features in MelRayFrame.

    This creates a 3-channel representation: (original, delta, delta-delta).

    Args:
        win_length: Length of the window used for computing delta (default: 5)
                   Must be odd.
        mode: Padding mode for edge frames - "replicate", "constant", or "reflect"

    Returns:
        Lens that stacks features. Output MelRayFrame has shape (3, n_mels, time_frames)
    """
    if win_length % 2 == 0:
        raise ValueError(f"win_length must be odd, got {win_length}")

    delta_transform = torchaudio.transforms.ComputeDeltas(
        win_length=win_length,
        mode=mode,
    )

    def _stack_features_frame(frame: MelRayFrame) -> MelRayFrame:
        if frame.data.numel() == 0:
            # Return empty tensor with correct shape
            if frame.data.dim() == 2:
                empty_data = torch.empty((3, frame.n_mels, 0))
            else:
                empty_data = torch.empty((3, *frame.data.shape[1:]))
            return MelRayFrame(
                data=empty_data,
                sample_rate=frame.sample_rate,
                n_mels=frame.n_mels,
                n_fft=frame.n_fft,
                hop_length=frame.hop_length,
                win_length=frame.win_length,
                f_min=frame.f_min,
                f_max=frame.f_max,
                channels=3,
            )

        # Remove channel dimension temporarily
        if frame.data.dim() == 3:
            data_2d = frame.data.squeeze(0) if frame.channels == 1 else frame.data[0]
        else:
            data_2d = frame.data

        # Compute delta
        delta_features = delta_transform(data_2d)
        # Compute delta-delta
        delta_delta_features = delta_transform(delta_features)

        # Stack along channel dimension: (3, n_mels, time_frames)
        stacked = torch.stack([data_2d, delta_features, delta_delta_features], dim=0)

        return MelRayFrame(
            data=stacked,
            sample_rate=frame.sample_rate,
            n_mels=frame.n_mels,
            n_fft=frame.n_fft,
            hop_length=frame.hop_length,
            win_length=frame.win_length,
            f_min=frame.f_min,
            f_max=frame.f_max,
            channels=3,
            metadata={**frame.metadata, "stacked_delta_features": True, "delta_win_length": win_length},
        )

    return Lens(_stack_features_frame, name=f"stack_delta_features_frame(win={win_length})")



