"""
AudioRayFrame for audio waveform data representation.
"""

from typing import Optional, Dict, Any
from dataclasses import dataclass, field
import torch
from mimir_io.rayframe.base import RayFrame


@dataclass
class AudioRayFrame(RayFrame):
    """
    RayFrame for audio waveform data.

    This frame represents 1D or 2D audio waveform data with sample rate information.
    Dimensions are typically (channels, samples) or (samples,) for mono audio.

    Attributes:
        data: Tensor data with shape (C, T) or (T) where T is time samples
        sample_rate: Sample rate in Hz
        channels: Number of audio channels (default: 1 for mono)
        duration: Duration in seconds (calculated from samples and sample_rate)
        metadata: Additional metadata dictionary
    """

    # Redefine all fields to control order properly
    # Required fields first (no defaults)
    data: torch.Tensor
    # sample_rate must have default to avoid ordering issues with inherited metadata field
    sample_rate: Optional[int] = None
    # Fields with defaults come after required fields
    channels: int = 1
    duration: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Validate and set dimensions from data if not provided."""
        # Validate that sample_rate is provided
        if self.sample_rate is None:
            raise ValueError("sample_rate is required for AudioRayFrame")
        
        if self.data.numel() == 0:
            self.duration = 0.0
            return

        shape = self.data.shape
        ndim = len(shape)

        if ndim == 1:
            # (T) - mono audio
            samples = shape[0]
            if self.channels == 1:
                # Add channel dimension
                self.data = self.data.unsqueeze(0)
        elif ndim == 2:
            # (C, T) - multi-channel audio
            self.channels = shape[0]
            samples = shape[1]
        else:
            raise ValueError(
                f"AudioRayFrame expects 1D or 2D tensor, got {ndim}D tensor with shape {shape}"
            )

        # Calculate duration
        if self.duration is None:
            self.duration = samples / self.sample_rate

    @property
    def num_samples(self) -> int:
        """Get the number of samples (time dimension)."""
        if len(self.data.shape) == 1:
            return self.data.shape[0]
        return self.data.shape[1]

    def to_dict(self) -> Dict[str, Any]:
        """Convert frame to dictionary representation."""
        result = super().to_dict()
        result.update({
            "sample_rate": self.sample_rate,
            "channels": self.channels,
            "duration": self.duration,
        })
        return result

    def __repr__(self) -> str:
        return (
            f"AudioRayFrame(shape={self.shape}, channels={self.channels}, "
            f"sample_rate={self.sample_rate}Hz, duration={self.duration:.2f}s)"
        )

