"""
MelRayFrame for Mel spectrogram data representation.
"""

from typing import Optional, Dict, Any
from dataclasses import dataclass, field
import torch
from mimir_io.rayframe.image_frame import ImageRayFrame


@dataclass
class MelRayFrame(ImageRayFrame):
    """
    RayFrame specifically for Mel spectrogram data.

    This frame represents Mel spectrograms with all relevant STFT and Mel filterbank
    parameters, providing complete context for the spectral representation.
    Inherits from ImageRayFrame for image-like structure.

    Attributes:
        data: Tensor data with shape (n_mels, time_frames) or (channels, n_mels, time_frames)
        sample_rate: Sample rate of the original audio in Hz
        n_mels: Number of mel filterbanks
        n_fft: Size of FFT used
        hop_length: Length of hop between STFT windows
        win_length: Window size used for STFT
        time_frames: Number of time frames (calculated from data)
        duration: Duration in seconds (calculated from time_frames and hop_length)
        f_min: Minimum frequency in Hz
        f_max: Maximum frequency in Hz
        channels: Number of channels (default: 1)
        metadata: Additional metadata dictionary
    """

    # Redefine all fields to control order properly
    # Required fields must have defaults to avoid ordering issues with inherited fields
    data: torch.Tensor
    sample_rate: Optional[int] = None
    n_mels: Optional[int] = None
    n_fft: Optional[int] = None
    hop_length: Optional[int] = None
    # Fields with defaults come after required fields
    channels: int = 1
    height: Optional[int] = None
    width: Optional[int] = None
    win_length: Optional[int] = None
    f_min: float = 0.0
    f_max: Optional[float] = None
    time_frames: int = field(init=False)
    duration: float = field(init=False)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Validate and set dimensions from data if not provided."""
        # Validate required fields
        if self.sample_rate is None:
            raise ValueError("sample_rate is required for MelRayFrame")
        if self.n_mels is None:
            raise ValueError("n_mels is required for MelRayFrame")
        if self.n_fft is None:
            raise ValueError("n_fft is required for MelRayFrame")
        if self.hop_length is None:
            raise ValueError("hop_length is required for MelRayFrame")
        
        if self.data.numel() == 0:
            self.time_frames = 0
            self.duration = 0.0
            # Set height/width for empty tensor
            self.height = self.n_mels
            self.width = 0
            return

        shape = self.data.shape
        ndim = len(shape)

        if ndim == 2:
            # (n_mels, time_frames)
            if shape[0] != self.n_mels:
                raise ValueError(
                    f"First dimension must match n_mels ({self.n_mels}), got {shape[0]}"
                )
            self.time_frames = shape[1]
            self.height = self.n_mels
            self.width = self.time_frames
            # Add channel dimension
            self.data = self.data.unsqueeze(0)
            self.channels = 1
        elif ndim == 3:
            # (channels, n_mels, time_frames)
            self.channels = shape[0]
            if shape[1] != self.n_mels:
                raise ValueError(
                    f"Second dimension must match n_mels ({self.n_mels}), got {shape[1]}"
                )
            self.time_frames = shape[2]
            self.height = self.n_mels
            self.width = self.time_frames
        else:
            raise ValueError(
                f"MelRayFrame expects 2D or 3D tensor, got {ndim}D tensor with shape {shape}"
            )

        # Calculate duration from time_frames and hop_length
        self.duration = (self.time_frames - 1) * self.hop_length / self.sample_rate

        # Set default f_max if not provided
        if self.f_max is None:
            self.f_max = float(self.sample_rate // 2)

        # Set default win_length if not provided
        if self.win_length is None:
            self.win_length = self.n_fft

    @property
    def time_resolution(self) -> float:
        """Get time resolution in seconds per frame."""
        return self.hop_length / self.sample_rate

    @property
    def frequency_resolution(self) -> float:
        """Get frequency resolution in Hz per mel bin."""
        return (self.f_max - self.f_min) / self.n_mels

    def to_dict(self) -> Dict[str, Any]:
        """Convert frame to dictionary representation."""
        result = super().to_dict()
        result.update({
            "n_mels": self.n_mels,
            "n_fft": self.n_fft,
            "hop_length": self.hop_length,
            "win_length": self.win_length,
            "time_frames": self.time_frames,
            "duration": self.duration,
            "f_min": self.f_min,
            "f_max": self.f_max,
        })
        return result

    def __repr__(self) -> str:
        return (
            f"MelRayFrame(shape={self.shape}, n_mels={self.n_mels}, "
            f"time_frames={self.time_frames}, sample_rate={self.sample_rate}Hz, "
            f"duration={self.duration:.2f}s, hop_length={self.hop_length})"
        )

