"""
PyTorch Dataset wrapper for mimir_io.

This module provides integration with PyTorch DataLoader for using
mimir_io data processing pipelines when training neural networks.
"""

from typing import List, Optional, Any, Callable, Union
from pathlib import Path
import os

try:
    import torch
    from torch.utils.data import Dataset
    _torch_available = True
except ImportError:
    _torch_available = False
    # Create stubs for type checking
    Dataset = object  # type: ignore

from mimir_io.dataset import Dataset as MimirDataset
from mimir_io.lens import Lens
from mimir_io.rayframe import load_audio_frame


class MimirTorchDataset(Dataset):
    """
    PyTorch Dataset wrapper for mimir_io.
    
    Allows using mimir_io data processing pipelines directly
    with PyTorch DataLoader.
    
    Example:
        >>> from mimir_io import Dataset
        >>> from mimir_io.audio import resample, log_mel_spectrogram
        >>> from mimir_io.torch_dataset import MimirTorchDataset
        >>> from torch.utils.data import DataLoader
        >>>
        >>> mimir_dataset = Dataset(data_dir="./data")
        >>> mel_pipeline = resample(16000) | log_mel_spectrogram(n_mels=80)
        >>>
        >>> torch_dataset = MimirTorchDataset(
        ...     mimir_dataset=mimir_dataset,
        ...     file_paths=["audio1.wav", "audio2.wav"],
        ...     transform_pipeline=mel_pipeline,
        ...     labels=[0, 1],
        ... )
        >>>
        >>> loader = DataLoader(torch_dataset, batch_size=32, shuffle=True)
        >>> for features, labels in loader:
        ...     # Training model
        ...     pass
    """
    
    def __init__(
        self,
        mimir_dataset: MimirDataset,
        file_paths: List[Union[str, Path]],
        transform_pipeline: Lens,
        labels: Optional[List[Any]] = None,
        use_augmentation: bool = False,
        augmentation_pipeline: Optional[Lens] = None,
        load_audio_lens: Optional[Lens] = None,
        collate_fn: Optional[Callable] = None,
        epoch: Optional[int] = None,
    ):
        """
        Initialize PyTorch Dataset.
        
        Args:
            mimir_dataset: Instance of mimir_io.Dataset for caching
            file_paths: List of paths to audio files
            transform_pipeline: Lens with transformation pipeline (e.g., mel spectrogram)
            labels: Optional labels for each file
            use_augmentation: Whether to use augmentations (usually True for train, False for val)
            augmentation_pipeline: Lens with augmentation pipeline (if use_augmentation=True)
            load_audio_lens: Custom lens for loading audio (defaults to load_audio_frame)
            collate_fn: Custom function for batching (defaults to torch.stack)
            epoch: Optional epoch number for different augmentations each epoch
        """
        self.mimir_dataset = mimir_dataset
        self.file_paths = [Path(p) for p in file_paths]
        self.transform_pipeline = transform_pipeline
        self.labels = labels
        self.use_augmentation = use_augmentation and augmentation_pipeline is not None
        self.augmentation_pipeline = augmentation_pipeline
        self.load_audio_lens = load_audio_lens or load_audio_frame
        self.collate_fn = collate_fn or self._default_collate_fn
        self.epoch = epoch
        
        if labels is not None and len(labels) != len(file_paths):
            raise ValueError(
                f"Number of labels ({len(labels)}) does not match "
                f"number of files ({len(file_paths)})"
            )
    
    def set_epoch(self, epoch: int) -> None:
        """
        Set epoch number for different augmentations each epoch.
        
        Useful for ensuring different augmentations on each epoch
        when using multiprocessing DataLoader.
        
        Args:
            epoch: Epoch number
        """
        self.epoch = epoch
    
    def __len__(self) -> int:
        """Returns the number of samples in the dataset."""
        return len(self.file_paths)
    
    def __getitem__(self, idx: int):
        """
        Loads and processes one sample.
        
        Args:
            idx: Sample index
            
        Returns:
            If labels provided: (features, label)
            Otherwise: features
        """
        # Load audio (with caching)
        # Use load_audio if it's the default load_audio_frame, otherwise use apply
        if self.load_audio_lens is load_audio_frame:
            audio_frame = self.mimir_dataset.load_audio(str(self.file_paths[idx]), use_cache=True)
        else:
            audio_frame = self.mimir_dataset.apply(
                self.load_audio_lens(str(self.file_paths[idx])),
                None,
                use_cache=True,
            )
        
        # Apply augmentation (if training)
        if self.use_augmentation:
            # Generate seed based on idx and epoch for reproducible augmentations
            seed = self._generate_augmentation_seed(idx)
            audio_frame = self.mimir_dataset.apply(
                self.augmentation_pipeline,
                audio_frame,
                use_cache=False,  # Augmentations are not cached
                seed=seed,
            )
        
        # Apply transformations (e.g., mel spectrogram)
        features = self.mimir_dataset.apply(
            self.transform_pipeline,
            audio_frame.data,
            use_cache=True,
        )
        
        # Convert to tensor if not already a tensor
        if not isinstance(features, torch.Tensor):
            features = torch.tensor(features)
        
        # Return features and label (if available)
        if self.labels is not None:
            label = self.labels[idx]
            # Convert label to tensor if needed
            if not isinstance(label, torch.Tensor):
                label = torch.tensor(label)
            return features, label
        
        return features
    
    def _generate_augmentation_seed(self, idx: int) -> Optional[int]:
        """
        Generate seed for augmentation based on idx and epoch.
        
        Args:
            idx: Sample index
            
        Returns:
            Seed value or None for random
        """
        if self.epoch is not None:
            # Combine idx and epoch for unique seed per epoch
            return idx * 10000 + self.epoch
        return None
    
    @staticmethod
    def _default_collate_fn(batch):
        """
        Default function for batching.
        
        Handles both cases with and without labels.
        """
        if isinstance(batch[0], tuple):
            # Case with labels: batch = [(features, label), ...]
            features, labels = zip(*batch)
            features_batch = torch.stack(features)
            labels_batch = torch.stack(labels) if isinstance(labels[0], torch.Tensor) else torch.tensor(labels)
            return features_batch, labels_batch
        else:
            # Case without labels: batch = [features, ...]
            return torch.stack(batch)


class MimirTorchDatasetWithAugmentation(MimirTorchDataset):
    """
    Extended version with seed support for deterministic augmentations.
    
    Allows controlling seed for augmentations via worker_id,
    useful for reproducibility with multi-threaded loading.
    """
    
    def __init__(
        self,
        *args,
        worker_id: Optional[int] = None,
        epoch: Optional[int] = None,
        **kwargs,
    ):
        """
        Initialize Dataset with seed support.
        
        Args:
            *args: Arguments for base class
            worker_id: Worker ID (for deterministic augmentations)
            epoch: Epoch number (for different augmentations on each epoch)
            **kwargs: Keyword arguments for base class
        """
        super().__init__(*args, **kwargs)
        self.worker_id = worker_id
        self.epoch = epoch
    
    def __getitem__(self, idx: int):
        """Loads sample with seed for augmentations."""
        # Load audio
        # Use load_audio if it's the default load_audio_frame, otherwise use apply
        if self.load_audio_lens is load_audio_frame:
            audio_frame = self.mimir_dataset.load_audio(str(self.file_paths[idx]), use_cache=True)
        else:
            audio_frame = self.mimir_dataset.apply(
                self.load_audio_lens(str(self.file_paths[idx])),
                None,
                use_cache=True,
            )
        
        # Apply augmentation with seed
        if self.use_augmentation:
            # Generate seed based on idx, worker_id, and epoch
            seed = self._generate_seed(idx)
            audio_frame = self.mimir_dataset.apply(
                self.augmentation_pipeline,
                audio_frame,
                use_cache=False,
                seed=seed,
            )
        
        # Apply transformations
        features = self.mimir_dataset.apply(
            self.transform_pipeline,
            audio_frame.data,
            use_cache=True,
        )
        
        if not isinstance(features, torch.Tensor):
            features = torch.tensor(features)
        
        if self.labels is not None:
            label = self.labels[idx]
            if not isinstance(label, torch.Tensor):
                label = torch.tensor(label)
            return features, label
        
        return features
    
    def _generate_seed(self, idx: int) -> int:
        """Generates seed for augmentation based on idx, worker_id, and epoch."""
        # Use combination for unique seed
        seed = idx
        if self.worker_id is not None:
            seed = seed * 1000 + self.worker_id
        if self.epoch is not None:
            seed = seed * 10000 + self.epoch
        return seed


def _worker_init_fn(worker_id: int) -> None:
    """
    Worker initialization function for DataLoader.
    
    Sets up proper random seed for each worker process.
    This ensures reproducible augmentations with multiprocessing.
    
    Args:
        worker_id: Worker process ID
    """
    import random
    import numpy as np
    
    # Get base seed from environment or use worker_id
    base_seed = int(os.environ.get("PYTHONHASHSEED", 0)) + worker_id
    
    # Set seeds for all random number generators
    random.seed(base_seed)
    np.random.seed(base_seed)
    if _torch_available:
        torch.manual_seed(base_seed)
        torch.cuda.manual_seed_all(base_seed)


def create_dataloader(
    mimir_dataset: MimirDataset,
    file_paths: List[Union[str, Path]],
    transform_pipeline: Lens,
    labels: Optional[List[Any]] = None,
    batch_size: int = 32,
    shuffle: bool = True,
    num_workers: int = 4,
    pin_memory: bool = True,
    use_augmentation: bool = False,
    augmentation_pipeline: Optional[Lens] = None,
    persistent_workers: bool = False,
    prefetch_factor: Optional[int] = None,
    timeout: float = 0,
    drop_last: bool = False,
    distributed: bool = False,
    distributed_sampler: Optional[Any] = None,
    collate_fn: Optional[Callable] = None,
    worker_init_fn: Optional[Callable] = None,
    **dataloader_kwargs,
) -> torch.utils.data.DataLoader:
    """
    Convenience function for creating DataLoader with mimir_io pipeline.
    
    Provides full control over DataLoader parameters for optimal performance.
    
    Args:
        mimir_dataset: Instance of mimir_io.Dataset for caching
        file_paths: List of paths to audio files
        transform_pipeline: Lens with transformation pipeline (e.g., mel spectrogram)
        labels: Optional labels for each file
        batch_size: Number of samples per batch
        shuffle: Whether to shuffle data each epoch
        num_workers: Number of worker processes for data loading
        pin_memory: Whether to pin memory for faster GPU transfer
        use_augmentation: Whether to use augmentations
        augmentation_pipeline: Lens with augmentation pipeline
        persistent_workers: Keep workers alive between epochs (faster, uses more memory)
        prefetch_factor: Number of batches prefetched per worker (default: 2)
        timeout: Timeout for getting a batch from workers (0 = no timeout)
        drop_last: Drop last incomplete batch
        collate_fn: Custom function for batching (default: automatic)
        worker_init_fn: Custom worker initialization function (default: seed setup)
        **dataloader_kwargs: Additional arguments passed to DataLoader
    
    Returns:
        PyTorch DataLoader instance
        
    Example:
        >>> from mimir_io.torch_dataset import create_dataloader
        >>> from mimir_io.audio import resample, log_mel_spectrogram
        >>>
        >>> loader = create_dataloader(
        ...     mimir_dataset=dataset,
        ...     file_paths=train_files,
        ...     transform_pipeline=resample(16000) | log_mel_spectrogram(n_mels=80),
        ...     labels=train_labels,
        ...     batch_size=32,
        ...     shuffle=True,
        ...     num_workers=4,
        ...     pin_memory=True,
        ...     persistent_workers=True,  # Keep workers alive
        ...     prefetch_factor=4,  # Prefetch more batches
        ...     use_augmentation=True,
        ...     augmentation_pipeline=aug_pipeline,
        ... )
    """
    dataset = MimirTorchDataset(
        mimir_dataset=mimir_dataset,
        file_paths=file_paths,
        transform_pipeline=transform_pipeline,
        labels=labels,
        use_augmentation=use_augmentation,
        augmentation_pipeline=augmentation_pipeline,
        collate_fn=collate_fn,
    )
    
    # Use default worker_init_fn if augmentations are enabled and none provided
    if worker_init_fn is None and use_augmentation and num_workers > 0:
        worker_init_fn = _worker_init_fn
    
    # Setup distributed sampler if provided
    sampler = None
    if distributed_sampler is not None:
        sampler = distributed_sampler
        shuffle = False  # DistributedSampler handles shuffling
    elif distributed:
        # Try to create distributed sampler automatically
        try:
            from mimir_io.models.distributed import setup_distributed_sampler, is_distributed
            if is_distributed():
                sampler = setup_distributed_sampler(dataset, shuffle=shuffle)
                shuffle = False
        except ImportError:
            pass
    
    # Build DataLoader kwargs
    loader_kwargs = {
        "batch_size": batch_size,
        "shuffle": shuffle if sampler is None else False,
        "num_workers": num_workers,
        "pin_memory": pin_memory,
        "drop_last": drop_last,
        "timeout": timeout,
    }
    
    # Add sampler if using distributed training
    if sampler is not None:
        loader_kwargs["sampler"] = sampler
        loader_kwargs.pop("shuffle", None)  # Remove shuffle when using sampler
    
    # Add optional parameters
    if persistent_workers and num_workers > 0:
        loader_kwargs["persistent_workers"] = True
    
    if prefetch_factor is not None and num_workers > 0:
        loader_kwargs["prefetch_factor"] = prefetch_factor
    
    if collate_fn is not None:
        loader_kwargs["collate_fn"] = collate_fn
    
    if worker_init_fn is not None:
        loader_kwargs["worker_init_fn"] = worker_init_fn
    
    # Add any additional kwargs
    loader_kwargs.update(dataloader_kwargs)
    
    return torch.utils.data.DataLoader(dataset, **loader_kwargs)
