"""
Dataset class for managing data with lens-based transformations.
"""

from pathlib import Path
from typing import Optional, Any, Dict, Union, List
import pickle
import hashlib
import os
import multiprocessing
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed

try:
    from tqdm.auto import tqdm  # Автоматично вибирає notebook або console
    _tqdm_available = True
except ImportError:
    _tqdm_available = False
    # Fallback: create a no-op wrapper
    def tqdm(iterable, desc=None, **kwargs):
        return iterable

from mimir_io.lens import Lens
from mimir_io.backends import get_backend
from mimir_io.cache_index import CacheIndex


# Worker function for multiprocessing (must be at module level for pickle)
def _worker_process_item(args: tuple) -> tuple[int, Any, Optional[str]]:
    """
    Worker function for processing a single item in a separate process.
    
    Args:
        args: Tuple of (idx, data, lens, dataset_params, use_cache, seed)
        
    Returns:
        Tuple of (index, result, error_message)
    """
    idx, data, lens, dataset_params, use_cache, seed = args
    
    try:
        # Import Dataset and Path here to avoid circular imports in worker processes
        from mimir_io.dataset import Dataset
        from pathlib import Path
        
        # Create a new Dataset instance in worker process
        # Convert string paths to Path objects
        worker_dataset = Dataset(
            data_dir=Path(dataset_params['data_dir']),
            cache_dir=Path(dataset_params['cache_dir']) if dataset_params['cache_dir'] else None,
            raw_dir=Path(dataset_params['raw_dir']) if dataset_params['raw_dir'] else None,
            use_compressed_cache=dataset_params['use_compressed_cache'],
        )
        
        # Apply lens transformation
        item_seed = seed + idx if seed is not None else None
        result = worker_dataset.apply(lens, data, use_cache=use_cache, seed=item_seed)
        
        return (idx, result, None)
    except Exception as e:
        # Return error message instead of raising
        return (idx, None, str(e))


class Dataset:
    """
    Dataset manager that handles data loading, transformation via lenses,
    automatic caching, and automatic pipeline optimization.
    """

    def __init__(
        self,
        data_dir: Path,
        cache_dir: Optional[Path] = None,
        raw_dir: Optional[Path] = None,
        use_compressed_cache: bool = True,
    ):
        """
        Initialize a dataset.

        Args:
            data_dir: Base directory for data
            cache_dir: Directory for cached transformations (default: data_dir/cache)
            raw_dir: Directory for raw data (default: data_dir/raw)
            use_compressed_cache: If True, uses compressed formats (WAV/PNG) for caching
                                  AudioRayFrame and ImageRayFrame. If False, uses pickle.
        """
        self.data_dir = Path(data_dir)
        self.cache_dir = cache_dir or self.data_dir / "cache"
        self.raw_dir = raw_dir or self.data_dir / "raw"
        self.use_compressed_cache = use_compressed_cache

        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize cache index for fast existence checks
        self._cache_index = CacheIndex(self.cache_dir, ttl=3600.0, auto_refresh=True)
        
        # Cache for optimized pipelines (to avoid re-optimizing the same pipeline)
        self._optimized_lens_cache: Dict[str, Lens] = {}

    def _get_cache_path(self, cache_key: str) -> Path:
        """
        Get cache path from cache key, handling long filenames.
        
        Args:
            cache_key: Cache key (may be long)
            
        Returns:
            Path to cache file
        """
        # If cache key is too long, use hash instead
        max_filename_length = 255  # Common filesystem limit
        if len(cache_key) > max_filename_length:
            # Use hash of cache_key as filename
            key_hash = hashlib.sha256(cache_key.encode()).hexdigest()
            return self.cache_dir / key_hash
        return self.cache_dir / cache_key
    
    def _load_from_cache(self, cache_path: Path) -> Optional[Any]:
        """
        Load data from cache if it exists.
        
        Uses cache index for fast existence checks.
        
        Args:
            cache_path: Base path for cache (without extension)
            
        Returns:
            Cached data if exists, None otherwise
        """
        # Get cache key from path (relative to cache_dir)
        try:
            cache_key = cache_path.relative_to(self.cache_dir).as_posix()
        except ValueError:
            # If path is not relative, use name
            cache_key = cache_path.name
        
        # Fast check using cache index
        exists = self._cache_index.exists(cache_key)
        if exists is False:
            return None
        
        # If index says it exists or is unknown, check filesystem
        try:
            if self.use_compressed_cache:
                from mimir_io.cache_formats import cache_exists, load_cached_data
                if cache_exists(cache_path):
                    # Update index
                    self._cache_index.mark_exists(cache_key)
                    return load_cached_data(cache_path)
            else:
                # Old way - pickle only
                pickle_path = cache_path.with_suffix(".pkl")
                if pickle_path.exists():
                    # Update index
                    self._cache_index.mark_exists(cache_key, '.pkl')
                    with open(pickle_path, "rb") as f:
                        return pickle.load(f)
        except (IOError, OSError, PermissionError, pickle.UnpicklingError) as e:
            # If cache is corrupted or inaccessible, mark as missing and return None
            self._cache_index.mark_missing(cache_key)
            return None
        
        # Not found, mark as missing
        self._cache_index.mark_missing(cache_key)
        return None
    
    def _save_to_cache(self, data: Any, cache_path: Path) -> None:
        """
        Save data to cache.
        
        Updates cache index after successful save.
        
        Args:
            data: Data to save
            cache_path: Base path for cache (without extension)
        """
        # Get cache key from path (relative to cache_dir)
        try:
            cache_key = cache_path.relative_to(self.cache_dir).as_posix()
        except ValueError:
            # If path is not relative, use name
            cache_key = cache_path.name
        
        try:
            if self.use_compressed_cache:
                from mimir_io.cache_formats import get_cache_format, save_cached_data
                fmt_class = get_cache_format(data)
                save_cached_data(data, cache_path)
                # Update index with format
                self._cache_index.mark_exists(cache_key, fmt_class.get_extension())
            else:
                # Old way - pickle only
                pickle_path = cache_path.with_suffix(".pkl")
                with open(pickle_path, "wb") as f:
                    pickle.dump(data, f)
                # Update index
                self._cache_index.mark_exists(cache_key, '.pkl')
        except (IOError, OSError, PermissionError) as e:
            # If we can't save to cache, just continue
            # This allows computation to proceed even if cache fails
            pass

    def apply(
        self, 
        lens: Lens[Any, Any], 
        data: Any, 
        use_cache: bool = True, 
        seed: Optional[int] = None,
        auto_optimize: bool = True
    ) -> Any:
        """
        Apply a lens transformation to data with optional caching and automatic optimization.

        Args:
            lens: Lens to apply
            data: Input data
            use_cache: Whether to use cached results if available
            seed: Optional random seed. If None, uses global seed or random.
                  Note: seed only affects augmentations if they support it.
            auto_optimize: Whether to automatically optimize the pipeline order (default: True)

        Returns:
            Transformed data
        """
        from mimir_io.random import seed_context
        
        # Auto-optimize pipeline if enabled and pipeline is composable
        if auto_optimize:
            lens = self._get_optimized_lens(lens)
        
        # Check if lens should be cached
        should_cache_this = use_cache and lens._should_cache
        
        # If no caching needed, just apply lens
        if not should_cache_this:
            if seed is not None:
                with seed_context(seed):
                    return lens(data)
            else:
                return lens(data)
        
        # Get cache path
        cache_key = lens.cache_key(data)
        cache_path = self._get_cache_path(cache_key)
        
        # Try to load from cache
        cached_result = self._load_from_cache(cache_path)
        if cached_result is not None:
            return cached_result
        
        # Compute result
        if seed is not None:
            with seed_context(seed):
                result = lens(data)
        else:
            result = lens(data)
        
        # Save to cache
        self._save_to_cache(result, cache_path)
        
        return result
    
    def _get_optimized_lens(self, lens: Lens) -> Lens:
        """
        Get optimized version of a lens, using cache to avoid re-optimization.
        
        Args:
            lens: Lens to optimize
            
        Returns:
            Optimized lens (or original if not composable)
        """
        # Check if lens is composable (has multiple transformations)
        if not hasattr(lens, '_name') or ' | ' not in lens._name:
            # Simple lens, no optimization needed
            return lens
        
        # Use lens name as cache key
        lens_key = lens._name
        
        # Check cache
        if lens_key in self._optimized_lens_cache:
            return self._optimized_lens_cache[lens_key]
        
        # Optimize pipeline
        try:
            from mimir_io.optimization import optimize_pipeline
            optimized = optimize_pipeline(lens)
            
            # Cache optimized lens
            self._optimized_lens_cache[lens_key] = optimized
            
            return optimized
        except Exception:
            # If optimization fails, return original lens
            return lens

    def load_raw(self, filename: str) -> Any:
        """
        Load raw data from the raw directory.

        Args:
            filename: Name of the file to load

        Returns:
            Loaded data
        """
        path = self.raw_dir / filename
        if not path.exists():
            raise FileNotFoundError(f"Raw data file not found: {path}")

        # For now, assume pickle format
        # In the future, this could support multiple formats
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_raw(self, data: Any, filename: str) -> None:
        """
        Save data to the raw directory.

        Args:
            data: Data to save
            filename: Name of the file
        """
        path = self.raw_dir / filename
        with open(path, "wb") as f:
            pickle.dump(data, f)
    
    def load_audio(self, path: Union[str, Path], use_cache: bool = True) -> Any:
        """
        Convenience method to load audio file as AudioRayFrame.
        
        This is equivalent to:
            dataset.apply(load_audio_frame(path), None, use_cache=use_cache)
        
        Args:
            path: Path to audio file (supports WAV, MP3, FLAC, M4A, OGG, AAC)
            use_cache: Whether to use cached results if available
            
        Returns:
            AudioRayFrame instance
            
        Example:
            >>> dataset = Dataset(data_dir="./data")
            >>> audio_frame = dataset.load_audio("./data/raw/audio.wav")
            >>> # Instead of: dataset.apply(load_audio_frame("./data/raw/audio.wav"), None)
        """
        from mimir_io.rayframe import load_audio_frame
        return self.apply(load_audio_frame(path), None, use_cache=use_cache)
    
    def precompute(
        self,
        lens: Lens[Any, Any],
        data: Any,
        cache_intermediate: bool = False,
        seed: Optional[int] = None,
    ) -> Any:
        """
        Precompute and cache only the final result of a pipeline.
        
        This is useful for training workflows where you only want to cache
        the final features (e.g., mel spectrogram) and not intermediate steps
        (resample, normalize, etc.), saving disk space.
        
        Args:
            lens: Lens (can be a composed pipeline) to apply
            data: Input data
            cache_intermediate: If True, caches intermediate steps in composed pipelines.
                               If False (default), only caches the final result.
            seed: Optional random seed
            
        Returns:
            Transformed data
            
        Example:
            >>> # Only cache final mel spectrogram, not intermediate steps
            >>> pipeline = (
            ...     resample(16000).no_cache()
            ...     | normalize().no_cache()
            ...     | mel_spectrogram(n_mels=80).cache()
            ... )
            >>> result = dataset.precompute(pipeline, audio_data)
            >>> # Or use cache_intermediate=False to ignore lens cache settings
            >>> result = dataset.precompute(pipeline, audio_data, cache_intermediate=False)
        """
        # If cache_intermediate is False, temporarily disable caching for intermediate steps
        if not cache_intermediate:
            # Apply the lens normally, but it will respect lens._should_cache flags
            return self.apply(lens, data, use_cache=True, seed=seed)
        else:
            # Cache everything as normal
            return self.apply(lens, data, use_cache=True, seed=seed)
    
    def apply_batch(
        self,
        lens: Lens[Any, Any],
        data_list: List[Any],
        use_cache: bool = True,
        seed: Optional[int] = None,
        show_progress: bool = False,
        desc: Optional[str] = None,
        num_workers: Optional[int] = None,
        use_threads: bool = False,
    ) -> List[Any]:
        """
        Apply lens transformation to a batch of data items.
        
        Supports parallel processing using multiprocessing for CPU-bound operations.
        For small batches (<=1 item) or num_workers<=1, uses sequential processing.
        
        Args:
            lens: Lens to apply (must be pickle-able for multiprocessing)
            data_list: List of input data items
            use_cache: Whether to use cached results if available
            seed: Optional random seed (for each item, seed will be seed + idx)
            show_progress: Whether to show progress bar
            desc: Description for progress bar
            num_workers: Number of worker processes/threads. If None, uses os.cpu_count().
                        Set to 1 or less to disable parallel processing.
            use_threads: If True, use ThreadPoolExecutor (better for I/O-bound operations).
                        If False, use ProcessPoolExecutor (better for CPU-bound operations).
            
        Returns:
            List of transformed data (in same order as input)
            
        Example:
            >>> audio_files = [audio1, audio2, audio3]
            >>> # Sequential processing (default for small batches)
            >>> results = dataset.apply_batch(mel_pipeline, audio_files)
            >>> 
            >>> # Parallel processing with multiprocessing (CPU-bound)
            >>> results = dataset.apply_batch(
            ...     mel_pipeline, audio_files,
            ...     num_workers=8,
            ...     show_progress=True
            ... )
            >>> 
            >>> # Parallel processing with threads (I/O-bound, e.g., loading audio)
            >>> results = dataset.apply_batch(
            ...     mel_pipeline, audio_files,
            ...     num_workers=8,
            ...     use_threads=True,
            ...     show_progress=True
            ... )
        """
        # Determine number of workers
        if num_workers is None:
            num_workers = os.cpu_count() or 1
        
        # For small batches or single worker, use sequential processing
        if num_workers <= 1 or len(data_list) <= 1:
            if show_progress and _tqdm_available:
                data_list = tqdm(data_list, desc=desc or "Processing batch")
            
            results = []
            for idx, data in enumerate(data_list):
                item_seed = seed + idx if seed is not None else None
                result = self.apply(lens, data, use_cache=use_cache, seed=item_seed)
                results.append(result)
            
            return results
        
        # Choose parallel processing method
        if use_threads:
            return self._apply_batch_threading(
                lens, data_list, use_cache, seed, show_progress, desc, num_workers
            )
        else:
            return self._apply_batch_multiprocessing(
                lens, data_list, use_cache, seed, show_progress, desc, num_workers
            )
    
    def _apply_batch_threading(
        self,
        lens: Lens[Any, Any],
        data_list: List[Any],
        use_cache: bool,
        seed: Optional[int],
        show_progress: bool,
        desc: Optional[str],
        num_workers: int,
    ) -> List[Any]:
        """
        Apply batch using threading (good for I/O-bound operations).
        
        Uses ThreadPoolExecutor which is more efficient for I/O operations
        like loading audio files, as it avoids pickle serialization overhead.
        
        Note: Dataset instance is shared, but cache operations are thread-safe.
        """
        def _worker_process_item_thread(args: tuple) -> tuple[int, Any, Optional[str]]:
            """Worker function for threading (uses shared Dataset instance)."""
            idx, data, lens, use_cache, seed = args
            
            try:
                # Use the shared Dataset instance - cache_index is thread-safe
                item_seed = seed + idx if seed is not None else None
                result = self.apply(lens, data, use_cache=use_cache, seed=item_seed)
                return (idx, result, None)
            except Exception as e:
                return (idx, None, str(e))
        
        # Prepare arguments for workers
        worker_args = [
            (idx, data, lens, use_cache, seed)
            for idx, data in enumerate(data_list)
        ]
        
        results = [None] * len(data_list)
        errors = []
        
        # Use ThreadPoolExecutor for I/O-bound operations
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            # Submit all tasks
            future_to_idx = {
                executor.submit(_worker_process_item_thread, args): idx
                for idx, args in enumerate(worker_args)
            }
            
            # Collect results with progress bar
            if show_progress and _tqdm_available:
                futures = tqdm(
                    as_completed(future_to_idx),
                    total=len(data_list),
                    desc=desc or "Processing batch"
                )
            else:
                futures = as_completed(future_to_idx)
            
            for future in futures:
                idx, result, error_msg = future.result()
                
                if error_msg is not None:
                    errors.append((idx, error_msg))
                    results[idx] = None
                else:
                    results[idx] = result
        
        # Raise exception if there were errors
        if errors:
            error_messages = [f"Item {idx}: {msg}" for idx, msg in errors]
            raise RuntimeError(
                f"Errors occurred during parallel processing:\n" + 
                "\n".join(error_messages)
            )
        
        return results
    
    def _apply_batch_multiprocessing(
        self,
        lens: Lens[Any, Any],
        data_list: List[Any],
        use_cache: bool,
        seed: Optional[int],
        show_progress: bool,
        desc: Optional[str],
        num_workers: int,
    ) -> List[Any]:
        """
        Apply batch using multiprocessing (good for CPU-bound operations).
        
        Note: lens must be pickle-able for this to work.
        """
        # Prepare dataset parameters for workers (must be pickle-able)
        dataset_params = {
            'data_dir': str(self.data_dir),
            'cache_dir': str(self.cache_dir) if self.cache_dir else None,
            'raw_dir': str(self.raw_dir) if self.raw_dir else None,
            'use_compressed_cache': self.use_compressed_cache,
        }
        
        # Prepare arguments for workers
        worker_args = [
            (idx, data, lens, dataset_params, use_cache, seed)
            for idx, data in enumerate(data_list)
        ]
        
        results = [None] * len(data_list)
        errors = []
        
        # Use ProcessPoolExecutor with 'spawn' method to avoid fork() warnings
        # 'spawn' is safer for multi-threaded environments (Python 3.12+)
        mp_context = multiprocessing.get_context('spawn')
        with ProcessPoolExecutor(max_workers=num_workers, mp_context=mp_context) as executor:
            # Submit all tasks
            future_to_idx = {
                executor.submit(_worker_process_item, args): idx
                for idx, args in enumerate(worker_args)
            }
            
            # Collect results with progress bar
            if show_progress and _tqdm_available:
                futures = tqdm(
                    as_completed(future_to_idx),
                    total=len(data_list),
                    desc=desc or "Processing batch"
                )
            else:
                futures = as_completed(future_to_idx)
            
            for future in futures:
                idx, result, error_msg = future.result()
                
                if error_msg is not None:
                    errors.append((idx, error_msg))
                    # Store None for failed items
                    results[idx] = None
                else:
                    results[idx] = result
        
        # Raise exception if there were errors
        if errors:
            error_messages = [f"Item {idx}: {msg}" for idx, msg in errors]
            raise RuntimeError(
                f"Errors occurred during parallel processing:\n" + 
                "\n".join(error_messages)
            )
        
        return results
    
    def precompute_batch(
        self,
        lens: Lens[Any, Any],
        data_list: List[Any],
        cache_intermediate: bool = False,
        seed: Optional[int] = None,
        show_progress: bool = True,
        desc: Optional[str] = None,
        num_workers: Optional[int] = None,
    ) -> List[Any]:
        """
        Precompute and cache results for a batch of data items.
        
        Supports parallel processing using multiprocessing - see apply_batch for details.
        
        Args:
            lens: Lens to apply
            data_list: List of input data items
            cache_intermediate: Whether to cache intermediate steps
            seed: Optional random seed
            show_progress: Whether to show progress bar
            desc: Description for progress bar
            num_workers: Number of worker processes (see apply_batch)
            
        Returns:
            List of transformed data
            
        Example:
            >>> audio_files = [audio1, audio2, audio3]
            >>> # Parallel precomputation
            >>> results = dataset.precompute_batch(
            ...     mel_pipeline, audio_files,
            ...     num_workers=8,
            ...     show_progress=True
            ... )
        """
        return self.apply_batch(
            lens, data_list,
            use_cache=True,
            seed=seed,
            show_progress=show_progress,
            desc=desc or "Precomputing batch",
            num_workers=num_workers,
        )
    
    def clear_cache(self, pattern: Optional[str] = None) -> int:
        """
        Clear cache files.
        
        Args:
            pattern: Optional glob pattern to match cache files (e.g., "*.wav", "*.pkl")
                    If None, clears all cache files.
                    
        Returns:
            Number of files deleted
            
        Example:
            >>> # Clear all cache
            >>> dataset.clear_cache()
            >>> # Clear only WAV files
            >>> dataset.clear_cache("*.wav")
        """
        deleted_count = 0
        
        if pattern:
            # Delete files matching pattern
            for cache_file in self.cache_dir.glob(pattern):
                try:
                    cache_file.unlink()
                    deleted_count += 1
                except OSError:
                    pass
            # Also delete meta files
            for meta_file in self.cache_dir.glob(pattern + ".meta.json"):
                try:
                    meta_file.unlink()
                except OSError:
                    pass
        else:
            # Delete all cache files
            for cache_file in self.cache_dir.iterdir():
                if cache_file.is_file():
                    try:
                        cache_file.unlink()
                        deleted_count += 1
                    except OSError:
                        pass
        
        return deleted_count
    
    def cache_stats(self) -> Dict[str, Any]:
        """
        Get statistics about the cache.
        
        Returns:
            Dictionary with cache statistics:
            - total_files: Total number of cache files
            - total_size_bytes: Total size of cache in bytes
            - total_size_mb: Total size of cache in MB
            - by_extension: Count and size by file extension
            
        Example:
            >>> stats = dataset.cache_stats()
            >>> print(f"Cache size: {stats['total_size_mb']:.2f} MB")
        """
        stats = {
            "total_files": 0,
            "total_size_bytes": 0,
            "total_size_mb": 0.0,
            "by_extension": {},
        }
        
        for cache_file in self.cache_dir.iterdir():
            if cache_file.is_file():
                # Skip meta files
                if cache_file.suffix == ".json" and ".meta.json" in cache_file.name:
                    continue
                
                try:
                    file_size = cache_file.stat().st_size
                    stats["total_files"] += 1
                    stats["total_size_bytes"] += file_size
                    
                    ext = cache_file.suffix or ".no_ext"
                    if ext not in stats["by_extension"]:
                        stats["by_extension"][ext] = {"count": 0, "size_bytes": 0}
                    stats["by_extension"][ext]["count"] += 1
                    stats["by_extension"][ext]["size_bytes"] += file_size
                except OSError:
                    pass
        
        stats["total_size_mb"] = stats["total_size_bytes"] / (1024 * 1024)
        
        return stats
    
    def cache_size(self) -> int:
        """
        Get total cache size in bytes.
        
        Returns:
            Total size of cache in bytes
        """
        return self.cache_stats()["total_size_bytes"]
    
    def list_cached_keys(self, pattern: Optional[str] = None) -> List[str]:
        """
        List all cache keys in the cache directory.
        
        Args:
            pattern: Optional glob pattern to filter keys
            
        Returns:
            List of cache keys (filenames without extensions)
            
        Example:
            >>> keys = dataset.list_cached_keys("*.wav")
        """
        keys = set()
        
        for cache_file in self.cache_dir.iterdir():
            if cache_file.is_file():
                # Skip meta files
                if cache_file.suffix == ".json" and ".meta.json" in cache_file.name:
                    continue
                
                if pattern and not cache_file.match(pattern):
                    continue
                
                # Remove extension to get cache key
                key = cache_file.stem
                keys.add(key)
        
        return sorted(keys)
    
    def get_cache_info(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a specific cache entry.
        
        Args:
            cache_key: Cache key to look up
            
        Returns:
            Dictionary with cache info (size, modification time, etc.) or None if not found
            
        Example:
            >>> info = dataset.get_cache_info("some_cache_key")
            >>> if info:
            ...     print(f"Size: {info['size_bytes']} bytes")
        """
        cache_path = self._get_cache_path(cache_key)
        
        # Check all possible formats
        from mimir_io.cache_formats import CACHE_FORMATS
        
        for fmt_class in CACHE_FORMATS:
            data_path = cache_path.with_suffix(fmt_class.get_extension())
            if data_path.exists():
                try:
                    stat = data_path.stat()
                    info = {
                        "cache_key": cache_key,
                        "path": str(data_path),
                        "format": fmt_class.get_extension(),
                        "size_bytes": stat.st_size,
                        "modified_time": stat.st_mtime,
                        "exists": True,
                    }
                    
                    # Try to load metadata if available
                    meta_path = cache_path.with_suffix(fmt_class.get_extension() + ".meta.json")
                    if meta_path.exists():
                        try:
                            import json
                            with open(meta_path, "r") as f:
                                info["metadata"] = json.load(f)
                        except (IOError, json.JSONDecodeError):
                            pass
                    
                    return info
                except OSError:
                    pass
        
        return None
    
    def validate_data(
        self,
        lens: Lens[Any, Any],
        data: Any,
        checks: Optional[List[str]] = None,
    ) -> List[str]:
        """
        Validate data before or after transformation.
        
        Args:
            lens: Lens to apply (or None to validate input data)
            data: Data to validate
            checks: List of checks to perform. Options:
                   - "nan": Check for NaN values
                   - "inf": Check for Inf values
                   - "empty": Check if data is empty
                   - "shape": Check if data has valid shape
                   If None, performs all checks.
                   
        Returns:
            List of validation issues (empty if all checks pass)
            
        Example:
            >>> issues = dataset.validate_data(mel_pipeline, audio_data)
            >>> if issues:
            ...     print(f"Found {len(issues)} issues: {issues}")
        """
        if checks is None:
            checks = ["nan", "inf", "empty", "shape"]
        
        issues = []
        
        # Apply lens if provided
        if lens is not None:
            try:
                data = lens(data)
            except Exception as e:
                issues.append(f"Lens application failed: {e}")
                return issues
        
        # Check for NaN
        if "nan" in checks:
            try:
                import torch
                if isinstance(data, torch.Tensor):
                    if torch.isnan(data).any():
                        issues.append("Data contains NaN values")
            except (ImportError, AttributeError):
                pass
        
        # Check for Inf
        if "inf" in checks:
            try:
                import torch
                if isinstance(data, torch.Tensor):
                    if torch.isinf(data).any():
                        issues.append("Data contains Inf values")
            except (ImportError, AttributeError):
                pass
        
        # Check if empty
        if "empty" in checks:
            try:
                import torch
                if isinstance(data, torch.Tensor):
                    if data.numel() == 0:
                        issues.append("Data is empty (zero elements)")
            except (ImportError, AttributeError):
                if hasattr(data, "__len__") and len(data) == 0:
                    issues.append("Data is empty")
        
        # Check shape
        if "shape" in checks:
            try:
                import torch
                if isinstance(data, torch.Tensor):
                    if any(s <= 0 for s in data.shape):
                        issues.append(f"Data has invalid shape: {data.shape}")
            except (ImportError, AttributeError):
                pass
        
        return issues