"""
MFCC (Mel-frequency cepstral coefficients) lenses.
"""

from typing import Optional
import torch
import torchaudio
from mimir_io.lens import Lens


def mfcc(
    sample_rate: int = 16000,
    n_mfcc: int = 13,
    n_fft: int = 2048,
    win_length: Optional[int] = None,
    hop_length: Optional[int] = None,
    n_mels: int = 128,
    f_min: float = 0.0,
    f_max: Optional[float] = None,
    window_fn: str = "hann",
    mel_scale: str = "htk",
    norm: Optional[str] = None,
    log_mels: bool = True,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that converts waveform to MFCC (Mel-frequency cepstral coefficients).

    MFCC features are widely used in speech recognition and audio classification.
    They represent the cepstral representation of the Mel spectrogram.

    Args:
        sample_rate: Sample rate of the input audio
        n_mfcc: Number of MFCC coefficients to return (default: 13)
        n_fft: Size of FFT, creates n_fft // 2 + 1 bins
        win_length: Window size. If None, defaults to n_fft
        hop_length: Length of hop between STFT windows. If None, defaults to win_length // 4
        n_mels: Number of mel filterbanks
        f_min: Minimum frequency in Hz
        f_max: Maximum frequency in Hz. If None, defaults to sample_rate // 2
        window_fn: Window function - "hann", "hamming", "blackman", etc.
        mel_scale: Mel scale to use ("htk" or "slaney")
        norm: Normalization mode for mel filterbank ("slaney" or None)
        log_mels: Whether to use log-mel spectrograms as input (default: True)

    Returns:
        Lens that converts waveform to MFCC features

    Example:
        lens = mfcc(sample_rate=16000, n_mfcc=13)
        mfcc_features = lens(waveform)  # Shape: (n_mfcc, time_frames)
    """
    if f_max is None:
        f_max = float(sample_rate // 2)

    if win_length is None:
        win_length = n_fft

    if hop_length is None:
        hop_length = win_length // 4

    window_fn_map = {
        "hann": torch.hann_window,
        "hamming": torch.hamming_window,
        "blackman": torch.blackman_window,
        "bartlett": torch.bartlett_window,
        "kaiser": torch.kaiser_window,
    }
    window_function = window_fn_map.get(window_fn, torch.hann_window)

    mfcc_transform = torchaudio.transforms.MFCC(
        sample_rate=sample_rate,
        n_mfcc=n_mfcc,
        melkwargs={
            "n_fft": n_fft,
            "win_length": win_length,
            "hop_length": hop_length,
            "n_mels": n_mels,
            "f_min": f_min,
            "f_max": f_max,
            "window_fn": window_function,
            "mel_scale": mel_scale,
            "norm": norm,
        },
    )

    def _mfcc(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return torch.empty((n_mfcc, 0))
        result = mfcc_transform(waveform)
        # Remove channel dimension if single channel: (1, n_mfcc, time) -> (n_mfcc, time)
        if result.dim() == 3 and result.shape[0] == 1:
            return result.squeeze(0)
        return result

    return Lens(_mfcc, name=f"mfcc(sr={sample_rate},n_mfcc={n_mfcc})")


def mfcc_with_delta(
    sample_rate: int = 16000,
    n_mfcc: int = 13,
    n_fft: int = 2048,
    win_length: Optional[int] = None,
    hop_length: Optional[int] = None,
    n_mels: int = 128,
    f_min: float = 0.0,
    f_max: Optional[float] = None,
    window_fn: str = "hann",
    mel_scale: str = "htk",
    norm: Optional[str] = None,
    log_mels: bool = True,
    delta_win_length: int = 5,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that computes MFCC with delta and delta-delta features.

    Returns stacked features: (mfcc, delta, delta-delta) with shape (3, n_mfcc, time_frames).

    Args:
        sample_rate: Sample rate of the input audio
        n_mfcc: Number of MFCC coefficients to return (default: 13)
        n_fft: Size of FFT, creates n_fft // 2 + 1 bins
        win_length: Window size. If None, defaults to n_fft
        hop_length: Length of hop between STFT windows. If None, defaults to win_length // 4
        n_mels: Number of mel filterbanks
        f_min: Minimum frequency in Hz
        f_max: Maximum frequency in Hz. If None, defaults to sample_rate // 2
        window_fn: Window function - "hann", "hamming", "blackman", etc.
        mel_scale: Mel scale to use ("htk" or "slaney")
        norm: Normalization mode for mel filterbank ("slaney" or None)
        log_mels: Whether to use log-mel spectrograms as input (default: True)
        delta_win_length: Window length for delta computation (must be odd)

    Returns:
        Lens that computes MFCC with delta features. Shape: (3, n_mfcc, time_frames)

    Example:
        lens = mfcc_with_delta(sample_rate=16000, n_mfcc=13)
        mfcc_features = lens(waveform)  # Shape: (3, 13, time_frames)
    """
    if delta_win_length % 2 == 0:
        raise ValueError(f"delta_win_length must be odd, got {delta_win_length}")

    mfcc_lens = mfcc(
        sample_rate=sample_rate,
        n_mfcc=n_mfcc,
        n_fft=n_fft,
        win_length=win_length,
        hop_length=hop_length,
        n_mels=n_mels,
        f_min=f_min,
        f_max=f_max,
        window_fn=window_fn,
        mel_scale=mel_scale,
        norm=norm,
        log_mels=log_mels,
    )

    delta_transform = torchaudio.transforms.ComputeDeltas(
        win_length=delta_win_length,
        mode="replicate",
    )

    def _mfcc_with_delta(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return torch.empty((3, n_mfcc, 0))

        mfcc_features = mfcc_lens(waveform)
        # Ensure mfcc_features is 2D (n_mfcc, time)
        # Remove channel dimension if present: (channels, n_mfcc, time) -> (n_mfcc, time)
        if mfcc_features.dim() == 3:
            # If single channel, squeeze it out
            if mfcc_features.shape[0] == 1:
                mfcc_features = mfcc_features.squeeze(0)
            else:
                # For multi-channel, take first channel or average? For now, take first
                mfcc_features = mfcc_features[0]
        
        delta_features = delta_transform(mfcc_features)
        delta_delta_features = delta_transform(delta_features)

        return torch.stack([mfcc_features, delta_features, delta_delta_features], dim=0)

    return Lens(_mfcc_with_delta, name=f"mfcc_with_delta(sr={sample_rate},n_mfcc={n_mfcc})")

