"""
Audio transformation lenses.
"""

import torch
from mimir_io.lens import Lens
from mimir_io.backends import get_backend


def to_tensor() -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that ensures data is a tensor.

    Returns:
        Lens that converts data to tensor format
    """
    backend = get_backend()

    def _to_tensor(data: torch.Tensor) -> torch.Tensor:
        if isinstance(data, torch.Tensor):
            return data
        return backend.array(data)

    return Lens(_to_tensor, name="to_tensor")


def normalize(target_db: float = -20.0) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that normalizes audio to a target dB level.

    Args:
        target_db: Target decibel level

    Returns:
        Lens that normalizes audio
    """
    def _normalize(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        rms = torch.sqrt(torch.mean(waveform ** 2))
        if rms == 0:
            return waveform

        target_rms = 10 ** (target_db / 20.0)
        gain = target_rms / rms
        return waveform * gain

    return Lens(_normalize, name=f"normalize({target_db}dB)")


def trim_silence(threshold: float = 0.01) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that trims silence from the beginning and end of audio.

    Args:
        threshold: Amplitude threshold below which is considered silence

    Returns:
        Lens that trims silence
    """
    def _trim_silence(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Find non-silent regions
        abs_waveform = torch.abs(waveform)
        if abs_waveform.dim() > 1:
            abs_waveform = torch.max(abs_waveform, dim=0)[0]

        non_silent = abs_waveform > threshold
        if not torch.any(non_silent):
            return waveform

        first_non_silent = torch.argmax(non_silent.int())
        last_non_silent = len(non_silent) - torch.argmax(non_silent.flip(0).int()) - 1

        if waveform.dim() > 1:
            return waveform[:, first_non_silent:last_non_silent + 1]
        return waveform[first_non_silent:last_non_silent + 1]

    return Lens(_trim_silence, name=f"trim_silence({threshold})")

