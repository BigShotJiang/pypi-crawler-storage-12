"""
Pre-emphasis filter lenses for audio preprocessing.
"""

import torch
from mimir_io.lens import Lens


def preemphasis(coeff: float = 0.97) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that applies pre-emphasis filter to audio.

    Pre-emphasis filter amplifies high frequencies, which is commonly used
    before computing MFCC or other spectral features in speech processing.

    The filter is: y[n] = x[n] - coeff * x[n-1]

    Args:
        coeff: Pre-emphasis coefficient (default: 0.97, typical range: 0.9-0.99)

    Returns:
        Lens that applies pre-emphasis filter

    Example:
        lens = preemphasis(coeff=0.97)
        emphasized = lens(waveform)
    """
    def _preemphasis(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Apply pre-emphasis: y[n] = x[n] - coeff * x[n-1]
        if waveform.dim() == 1:
            # 1D: (samples,)
            emphasized = torch.zeros_like(waveform)
            emphasized[0] = waveform[0]
            emphasized[1:] = waveform[1:] - coeff * waveform[:-1]
            return emphasized
        else:
            # 2D: (channels, samples)
            emphasized = torch.zeros_like(waveform)
            emphasized[:, 0] = waveform[:, 0]
            emphasized[:, 1:] = waveform[:, 1:] - coeff * waveform[:, :-1]
            return emphasized

    return Lens(_preemphasis, name=f"preemphasis({coeff})")



