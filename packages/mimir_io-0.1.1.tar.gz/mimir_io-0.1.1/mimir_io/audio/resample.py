"""
Audio resampling lenses.
"""

from typing import Optional, Union, Tuple
import torch
import torchaudio
from mimir_io.lens import Lens


def resample(
    target_sample_rate: int,
    orig_sample_rate: Optional[int] = None,
    resampling_method: str = "sinc_interp_kaiser",
    lowpass_filter_width: int = 64,
    rolloff: float = 0.99,
    dtype: Optional[torch.dtype] = None,
) -> Lens[Union[torch.Tensor, Tuple[torch.Tensor, int]], Union[torch.Tensor, Tuple[torch.Tensor, int]]]:
    """
    Create a lens that resamples audio to a target sample rate with maximum quality.

    Supports two modes:
    1. If orig_sample_rate is provided: works with waveform tensor directly
    2. If orig_sample_rate is None: works with tuple (waveform, sample_rate)

    Uses high-quality resampling via torchaudio with Kaiser windowed sinc
    interpolation by default. For fixed orig_sample_rate, uses optimized
    transforms.Resample. For dynamic sample rates (tuple mode), uses
    functional.resample.

    Quality parameters (defaults optimized for maximum quality):
    - lowpass_filter_width: Width of low-pass filter (default: 64, higher = better quality, slower)
      Standard values: 6 (fast), 16 (good), 64 (high quality), 128 (ultra quality)
    - rolloff: Rolloff frequency as fraction of Nyquist (default: 0.99, closer to 1.0 = sharper cutoff)
      Range: 0.0 to 1.0, higher values reduce aliasing but may introduce ringing

    Args:
        target_sample_rate: Target sample rate in Hz
        orig_sample_rate: Original sample rate (if None, expects tuple input)
        resampling_method: Resampling method - "sinc_interp_kaiser" (default, highest quality),
                          "sinc_interp_hann", or "sinc_interp_linear"
        lowpass_filter_width: Width of low-pass filter (default: 64 for max quality)
        rolloff: Rolloff frequency as fraction of Nyquist (default: 0.99)
        dtype: Output dtype (None = same as input)

    Returns:
        Lens that resamples audio. Returns waveform if orig_sample_rate provided,
        or tuple (waveform, target_sample_rate) if working with tuple input.

    Example:
        # With explicit sample rate (maximum quality)
        lens = resample(16000, orig_sample_rate=44100)
        resampled = lens(waveform)

        # With tuple input
        lens = resample(16000)
        resampled_waveform, new_sr = lens((waveform, 44100))

        # Custom quality settings
        lens = resample(16000, orig_sample_rate=44100, lowpass_filter_width=128)
    """
    if orig_sample_rate is not None:
        # Mode 1: Work with waveform directly, orig_sample_rate is known
        if orig_sample_rate == target_sample_rate:
            # No resampling needed
            def _resample_noop(waveform: torch.Tensor) -> torch.Tensor:
                return waveform
            return Lens(_resample_noop, name=f"resample({target_sample_rate}Hz,noop)")

        # Build kwargs for Resample, excluding None values
        resample_kwargs = {
            "orig_freq": orig_sample_rate,
            "new_freq": target_sample_rate,
            "resampling_method": resampling_method,
            "lowpass_filter_width": lowpass_filter_width,
            "rolloff": rolloff,
        }
        if dtype is not None:
            resample_kwargs["dtype"] = dtype

        resampler = torchaudio.transforms.Resample(**resample_kwargs)

        def _resample_direct(waveform: torch.Tensor) -> torch.Tensor:
            if waveform.numel() == 0:
                return waveform
            return resampler(waveform)

        return Lens(
            _resample_direct,
            name=f"resample({orig_sample_rate}->{target_sample_rate}Hz)",
        )
    else:
        # Mode 2: Work with tuple (waveform, sample_rate)
        # Use functional resample for dynamic orig_sr values
        def _resample_tuple(data: Tuple[torch.Tensor, int]) -> Tuple[torch.Tensor, int]:
            waveform, orig_sr = data
            if waveform.numel() == 0:
                return waveform, target_sample_rate
            if orig_sr == target_sample_rate:
                return waveform, target_sample_rate

            # Use functional resample for efficiency when orig_sr varies
            resample_kwargs = {
                "orig_freq": orig_sr,
                "new_freq": target_sample_rate,
                "resampling_method": resampling_method,
                "lowpass_filter_width": lowpass_filter_width,
                "rolloff": rolloff,
            }
            if dtype is not None:
                resample_kwargs["dtype"] = dtype

            resampled_waveform = torchaudio.functional.resample(
                waveform,
                **resample_kwargs,
            )
            return resampled_waveform, target_sample_rate

        return Lens(
            _resample_tuple,
            name=f"resample(->{target_sample_rate}Hz)",
        )

