"""
Audio loading lenses with support for WAV, MP3, and FLAC formats.
"""

from pathlib import Path
from typing import Union, Tuple, Optional
import torch
import torchaudio
from mimir_io.lens import Lens


# Supported audio formats
SUPPORTED_FORMATS = {".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac"}


def _get_audio_format(path: Path) -> str:
    """
    Get audio format from file extension.

    Args:
        path: Path to audio file

    Returns:
        Lowercase file extension (e.g., '.wav', '.mp3')

    Raises:
        ValueError: If format is not supported
    """
    ext = path.suffix.lower()
    if ext not in SUPPORTED_FORMATS:
        raise ValueError(
            f"Unsupported audio format: {ext}. "
            f"Supported formats: {', '.join(sorted(SUPPORTED_FORMATS))}"
        )
    return ext


def _get_backend_for_format(file_format: str) -> Optional[str]:
    """
    Get recommended backend for audio format.

    Args:
        file_format: Audio file format (e.g., '.wav', '.mp3')

    Returns:
        Backend name or None for auto-detection
    """
    format_backends = {
        ".wav": "soundfile",  # soundfile is fast and reliable for WAV
        ".flac": "soundfile",  # soundfile supports FLAC
        ".mp3": None,  # Auto-detect (sox or ffmpeg)
        ".ogg": "soundfile",  # soundfile supports OGG
        ".m4a": None,  # Auto-detect
        ".aac": None,  # Auto-detect
    }
    return format_backends.get(file_format)


def _load_audio_file(
    path: Path, backend: Optional[str] = None
) -> Tuple[torch.Tensor, int]:
    """
    Load audio file with automatic backend selection and fallback.

    Args:
        path: Path to audio file
        backend: Optional backend name (None for auto-detection)

    Returns:
        Tuple of (waveform, sample_rate)

    Raises:
        FileNotFoundError: If file doesn't exist
        RuntimeError: If loading fails
    """
    if not path.exists():
        raise FileNotFoundError(f"Audio file not found: {path}")

    file_format = _get_audio_format(path)
    recommended_backend = backend or _get_backend_for_format(file_format)

    # Try loading with recommended backend first
    if recommended_backend:
        try:
            waveform, sample_rate = torchaudio.load(
                str(path), backend=recommended_backend
            )
            return waveform, int(sample_rate)
        except Exception as e:
            # Fallback to auto-detection if specific backend fails
            pass

    # Try auto-detection (torchaudio will choose best available backend)
    try:
        waveform, sample_rate = torchaudio.load(str(path))
        return waveform, int(sample_rate)
    except Exception as e:
        raise RuntimeError(
            f"Failed to load audio file {path}. "
            f"Format: {file_format}. "
            f"Error: {str(e)}. "
            f"Make sure you have the required backend installed "
            f"(soundfile for WAV/FLAC, sox or ffmpeg for MP3)."
        ) from e


def load_audio(
    path: Union[str, Path], backend: Optional[str] = None
) -> Lens[None, torch.Tensor]:
    """
    Create a lens that loads audio from a file path.

    Supports WAV, MP3, FLAC, OGG, M4A, and AAC formats with automatic
    backend selection and fallback.

    Args:
        path: Path to audio file
        backend: Optional backend name ('soundfile', 'sox', 'ffmpeg').
                 If None, automatically selects best backend for format.

    Returns:
        Lens that loads audio as a tensor

    Example:
        # Load WAV file (uses soundfile backend)
        lens = load_audio("audio.wav")
        waveform = lens(None)

        # Load MP3 file (auto-detects backend)
        lens = load_audio("audio.mp3")
        waveform = lens(None)

        # Load FLAC file with explicit backend
        lens = load_audio("audio.flac", backend="soundfile")
        waveform = lens(None)
    """
    path = Path(path)

    def _load(_: None) -> torch.Tensor:
        waveform, _ = _load_audio_file(path, backend)
        return waveform

    return Lens(_load, name=f"load_audio({path.name})")


def load_audio_with_sr(
    path: Union[str, Path], backend: Optional[str] = None
) -> Lens[None, Tuple[torch.Tensor, int]]:
    """
    Create a lens that loads audio from a file path with sample rate.

    Supports WAV, MP3, FLAC, OGG, M4A, and AAC formats with automatic
    backend selection and fallback.

    Args:
        path: Path to audio file
        backend: Optional backend name ('soundfile', 'sox', 'ffmpeg').
                 If None, automatically selects best backend for format.

    Returns:
        Lens that loads audio as a tuple (waveform, sample_rate)

    Example:
        # Load WAV file with sample rate
        lens = load_audio_with_sr("audio.wav")
        waveform, sr = lens(None)

        # Load MP3 file (auto-detects backend)
        lens = load_audio_with_sr("audio.mp3")
        waveform, sr = lens(None)
    """
    path = Path(path)

    def _load(_: None) -> Tuple[torch.Tensor, int]:
        return _load_audio_file(path, backend)

    return Lens(_load, name=f"load_audio_with_sr({path.name})")

