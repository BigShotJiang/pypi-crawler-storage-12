"""
Audio spectrogram lenses for Mel and Log Mel spectrograms.
"""

from typing import Optional
import torch
import torchaudio
from mimir_io.lens import Lens


def mel_spectrogram(
    sample_rate: int = 16000,
    n_fft: int = 2048,
    win_length: Optional[int] = None,
    hop_length: Optional[int] = None,
    n_mels: int = 128,
    f_min: float = 0.0,
    f_max: Optional[float] = None,
    window_fn: str = "hann",
    power: float = 2.0,
    normalized: bool = False,
    center: bool = True,
    pad_mode: str = "reflect",
    norm: Optional[str] = None,
    mel_scale: str = "htk",
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that converts waveform to Mel spectrogram.

    Args:
        sample_rate: Sample rate of the input audio
        n_fft: Size of FFT, creates n_fft // 2 + 1 bins
        win_length: Window size. If None, defaults to n_fft
        hop_length: Length of hop between STFT windows. If None, defaults to win_length // 4
        n_mels: Number of mel filterbanks
        f_min: Minimum frequency in Hz
        f_max: Maximum frequency in Hz. If None, defaults to sample_rate // 2
        window_fn: Window function - "hann", "hamming", "blackman", etc.
        power: Exponent for the magnitude spectrogram (2.0 for power, 1.0 for magnitude)
        normalized: Whether to normalize by magnitude after stft
        center: Whether to pad waveform on both sides
        pad_mode: Padding mode when center is True
        norm: Normalization mode for mel filterbank ("slaney" or None)
        mel_scale: Mel scale to use ("htk" or "slaney")

    Returns:
        Lens that converts waveform to Mel spectrogram

    Example:
        lens = mel_spectrogram(sample_rate=16000, n_mels=80)
        mel_spec = lens(waveform)  # Shape: (n_mels, time_frames)
    """
    if f_max is None:
        f_max = float(sample_rate // 2)

    if win_length is None:
        win_length = n_fft

    if hop_length is None:
        hop_length = win_length // 4

    # Map window function name to torch function
    window_fn_map = {
        "hann": torch.hann_window,
        "hamming": torch.hamming_window,
        "blackman": torch.blackman_window,
        "bartlett": torch.bartlett_window,
        "kaiser": torch.kaiser_window,
    }
    window_function = window_fn_map.get(window_fn, torch.hann_window)

    mel_transform = torchaudio.transforms.MelSpectrogram(
        sample_rate=sample_rate,
        n_fft=n_fft,
        win_length=win_length,
        hop_length=hop_length,
        n_mels=n_mels,
        f_min=f_min,
        f_max=f_max,
        window_fn=window_function,
        power=power,
        normalized=normalized,
        center=center,
        pad_mode=pad_mode,
        norm=norm,
        mel_scale=mel_scale,
    )

    def _mel_spectrogram(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return torch.empty((n_mels, 0))
        result = mel_transform(waveform)
        # Remove channel dimension: (channels, n_mels, time) -> (n_mels, time)
        if result.dim() == 3:
            if result.shape[0] == 1:
                # Single channel: just squeeze
                return result.squeeze(0)
            else:
                # Multi-channel: average across channels
                return result.mean(dim=0)
        return result

    return Lens(
        _mel_spectrogram,
        name=f"mel_spectrogram(sr={sample_rate},n_mels={n_mels})",
    )


def log_mel_spectrogram(
    sample_rate: int = 16000,
    n_fft: int = 2048,
    win_length: Optional[int] = None,
    hop_length: Optional[int] = None,
    n_mels: int = 128,
    f_min: float = 0.0,
    f_max: Optional[float] = None,
    window_fn: str = "hann",
    power: float = 2.0,
    normalized: bool = False,
    center: bool = True,
    pad_mode: str = "reflect",
    norm: Optional[str] = None,
    mel_scale: str = "htk",
    log_offset: float = 1e-6,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that converts waveform to Log Mel spectrogram.

    This applies logarithm to the Mel spectrogram, which is commonly used
    in speech recognition and audio classification tasks.

    Args:
        sample_rate: Sample rate of the input audio
        n_fft: Size of FFT, creates n_fft // 2 + 1 bins
        win_length: Window size. If None, defaults to n_fft
        hop_length: Length of hop between STFT windows. If None, defaults to win_length // 4
        n_mels: Number of mel filterbanks
        f_min: Minimum frequency in Hz
        f_max: Maximum frequency in Hz. If None, defaults to sample_rate // 2
        window_fn: Window function - "hann", "hamming", "blackman", etc.
        power: Exponent for the magnitude spectrogram (2.0 for power, 1.0 for magnitude)
        normalized: Whether to normalize by magnitude after stft
        center: Whether to pad waveform on both sides
        pad_mode: Padding mode when center is True
        norm: Normalization mode for mel filterbank ("slaney" or None)
        mel_scale: Mel scale to use ("htk" or "slaney")
        log_offset: Small value added before taking log to avoid log(0)

    Returns:
        Lens that converts waveform to Log Mel spectrogram

    Example:
        lens = log_mel_spectrogram(sample_rate=16000, n_mels=80)
        log_mel_spec = lens(waveform)  # Shape: (n_mels, time_frames)
    """
    if f_max is None:
        f_max = float(sample_rate // 2)

    if win_length is None:
        win_length = n_fft

    if hop_length is None:
        hop_length = win_length // 4

    # Map window function name to torch function
    window_fn_map = {
        "hann": torch.hann_window,
        "hamming": torch.hamming_window,
        "blackman": torch.blackman_window,
        "bartlett": torch.bartlett_window,
        "kaiser": torch.kaiser_window,
    }
    window_function = window_fn_map.get(window_fn, torch.hann_window)

    mel_transform = torchaudio.transforms.MelSpectrogram(
        sample_rate=sample_rate,
        n_fft=n_fft,
        win_length=win_length,
        hop_length=hop_length,
        n_mels=n_mels,
        f_min=f_min,
        f_max=f_max,
        window_fn=window_function,
        power=power,
        normalized=normalized,
        center=center,
        pad_mode=pad_mode,
        norm=norm,
        mel_scale=mel_scale,
    )

    def _log_mel_spectrogram(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return torch.empty((n_mels, 0))
        mel_spec = mel_transform(waveform)
        # Remove channel dimension: (channels, n_mels, time) -> (n_mels, time)
        if mel_spec.dim() == 3:
            if mel_spec.shape[0] == 1:
                # Single channel: just squeeze
                mel_spec = mel_spec.squeeze(0)
            else:
                # Multi-channel: average across channels
                mel_spec = mel_spec.mean(dim=0)
        return torch.log(mel_spec + log_offset)

    return Lens(
        _log_mel_spectrogram,
        name=f"log_mel_spectrogram(sr={sample_rate},n_mels={n_mels})",
    )


def delta(
    win_length: int = 5,
    mode: str = "replicate",
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that computes delta (first derivative) features from spectrogram.

    Delta features represent the rate of change of spectral features over time,
    commonly used in speech recognition to capture temporal dynamics.

    Args:
        win_length: Length of the window used for computing delta (default: 5)
                   Must be odd. Larger values smooth the delta computation.
        mode: Padding mode for edge frames - "replicate", "constant", or "reflect"

    Returns:
        Lens that computes delta features from input spectrogram

    Example:
        lens = delta(win_length=5)
        delta_features = lens(mel_spec)  # Shape: same as input
    """
    if win_length % 2 == 0:
        raise ValueError(f"win_length must be odd, got {win_length}")

    delta_transform = torchaudio.transforms.ComputeDeltas(
        win_length=win_length,
        mode=mode,
    )

    def _delta(spectrogram: torch.Tensor) -> torch.Tensor:
        if spectrogram.numel() == 0:
            return spectrogram
        return delta_transform(spectrogram)

    return Lens(_delta, name=f"delta(win={win_length})")


def delta_delta(
    win_length: int = 5,
    mode: str = "replicate",
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that computes delta-delta (second derivative) features from spectrogram.

    Delta-delta features represent the acceleration of spectral features over time,
    providing additional temporal information beyond delta features.

    Args:
        win_length: Length of the window used for computing delta (default: 5)
                   Must be odd. Larger values smooth the delta computation.
        mode: Padding mode for edge frames - "replicate", "constant", or "reflect"

    Returns:
        Lens that computes delta-delta features from input spectrogram

    Example:
        lens = delta_delta(win_length=5)
        delta_delta_features = lens(mel_spec)  # Shape: same as input
    """
    if win_length % 2 == 0:
        raise ValueError(f"win_length must be odd, got {win_length}")

    delta_transform = torchaudio.transforms.ComputeDeltas(
        win_length=win_length,
        mode=mode,
    )

    def _delta_delta(spectrogram: torch.Tensor) -> torch.Tensor:
        if spectrogram.numel() == 0:
            return spectrogram
        # Compute delta first
        delta_features = delta_transform(spectrogram)
        # Compute delta-delta (delta of delta)
        delta_delta_features = delta_transform(delta_features)
        return delta_delta_features

    return Lens(_delta_delta, name=f"delta_delta(win={win_length})")


def stack_delta_features(
    win_length: int = 5,
    mode: str = "replicate",
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that stacks original, delta, and delta-delta features.

    This creates a 3-channel representation: (original, delta, delta-delta),
    commonly used in speech recognition systems.

    Args:
        win_length: Length of the window used for computing delta (default: 5)
                   Must be odd.
        mode: Padding mode for edge frames - "replicate", "constant", or "reflect"

    Returns:
        Lens that stacks features. Output shape: (3, n_mels, time_frames)

    Example:
        lens = stack_delta_features(win_length=5)
        stacked = lens(mel_spec)  # Shape: (3, n_mels, time_frames)
    """
    if win_length % 2 == 0:
        raise ValueError(f"win_length must be odd, got {win_length}")

    delta_transform = torchaudio.transforms.ComputeDeltas(
        win_length=win_length,
        mode=mode,
    )

    def _stack_features(spectrogram: torch.Tensor) -> torch.Tensor:
        if spectrogram.numel() == 0:
            # Return empty tensor with correct shape
            if len(spectrogram.shape) == 2:
                return torch.empty((3, spectrogram.shape[0], 0))
            return torch.empty((3, *spectrogram.shape))

        # Compute delta
        delta_features = delta_transform(spectrogram)
        # Compute delta-delta
        delta_delta_features = delta_transform(delta_features)

        # Stack along channel dimension
        stacked = torch.stack([spectrogram, delta_features, delta_delta_features], dim=0)
        return stacked

    return Lens(_stack_features, name=f"stack_delta_features(win={win_length})")

