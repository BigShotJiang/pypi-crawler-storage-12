"""
Additional audio feature extraction lenses.
"""

from typing import Optional
import torch
from mimir_io.lens import Lens


def power_to_db(
    ref: float = 1.0,
    amin: float = 1e-10,
    top_db: Optional[float] = None,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that converts power spectrogram to decibel scale.

    Args:
        ref: Reference value for dB calculation (default: 1.0)
        amin: Minimum value to avoid log(0) (default: 1e-10)
        top_db: Maximum dB value to clip at (None = no clipping)

    Returns:
        Lens that converts power to dB

    Example:
        lens = power_to_db(ref=1.0, top_db=80.0)
        db_spec = lens(power_spec)
    """
    def _power_to_db(power: torch.Tensor) -> torch.Tensor:
        if power.numel() == 0:
            return power

        # Convert to dB: 10 * log10(power / ref)
        power_clamped = torch.clamp(power, min=amin)
        db = 10.0 * torch.log10(power_clamped / ref)

        if top_db is not None:
            db = torch.clamp(db, min=db.max() - top_db)

        return db

    return Lens(_power_to_db, name=f"power_to_db(ref={ref})")


def amplitude_to_db(
    ref: float = 1.0,
    amin: float = 1e-5,
    top_db: Optional[float] = None,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that converts amplitude spectrogram to decibel scale.

    Args:
        ref: Reference value for dB calculation (default: 1.0)
        amin: Minimum value to avoid log(0) (default: 1e-5)
        top_db: Maximum dB value to clip at (None = no clipping)

    Returns:
        Lens that converts amplitude to dB

    Example:
        lens = amplitude_to_db(ref=1.0, top_db=80.0)
        db_spec = lens(magnitude_spec)
    """
    def _amplitude_to_db(amplitude: torch.Tensor) -> torch.Tensor:
        if amplitude.numel() == 0:
            return amplitude

        # Convert to dB: 20 * log10(amplitude / ref)
        amplitude_clamped = torch.clamp(amplitude, min=amin)
        db = 20.0 * torch.log10(amplitude_clamped / ref)

        if top_db is not None:
            db = torch.clamp(db, min=db.max() - top_db)

        return db

    return Lens(_amplitude_to_db, name=f"amplitude_to_db(ref={ref})")


def zero_crossing_rate(
    frame_length: int = 2048,
    hop_length: int = 512,
    center: bool = True,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that computes zero crossing rate (ZCR).

    ZCR is the rate at which the signal changes sign, useful for
    detecting pitch and distinguishing voiced from unvoiced speech.

    Args:
        frame_length: Length of analysis window
        hop_length: Number of samples between successive frames
        center: Whether to pad signal on both sides

    Returns:
        Lens that computes zero crossing rate

    Example:
        lens = zero_crossing_rate(frame_length=2048, hop_length=512)
        zcr = lens(waveform)  # Shape: (1, time_frames) for mono
    """
    def _zero_crossing_rate(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return torch.empty((1, 0))

        if waveform.dim() == 1:
            waveform = waveform.unsqueeze(0)

        if center:
            pad_width = frame_length // 2
            waveform = torch.nn.functional.pad(waveform, (pad_width, pad_width), mode="reflect")

        n_frames = 1 + (waveform.shape[-1] - frame_length) // hop_length
        zcr = torch.zeros((waveform.shape[0], n_frames))

        for i in range(n_frames):
            start = i * hop_length
            end = start + frame_length
            frame = waveform[:, start:end]

            # Count sign changes
            sign_changes = torch.diff(torch.sign(frame), dim=-1)
            zcr[:, i] = torch.sum(torch.abs(sign_changes), dim=-1) / (2.0 * frame_length)

        return zcr

    return Lens(_zero_crossing_rate, name=f"zero_crossing_rate(frame={frame_length})")


def rms_energy(
    frame_length: int = 2048,
    hop_length: int = 512,
    center: bool = True,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that computes RMS (Root Mean Square) energy per frame.

    RMS energy represents the average power of the signal in each frame.

    Args:
        frame_length: Length of analysis window
        hop_length: Number of samples between successive frames
        center: Whether to pad signal on both sides

    Returns:
        Lens that computes RMS energy

    Example:
        lens = rms_energy(frame_length=2048, hop_length=512)
        rms = lens(waveform)  # Shape: (channels, time_frames)
    """
    def _rms_energy(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            if waveform.dim() == 1:
                return torch.empty((1, 0))
            return torch.empty((waveform.shape[0], 0))

        if waveform.dim() == 1:
            waveform = waveform.unsqueeze(0)

        if center:
            pad_width = frame_length // 2
            waveform = torch.nn.functional.pad(waveform, (pad_width, pad_width), mode="reflect")

        n_frames = 1 + (waveform.shape[-1] - frame_length) // hop_length
        rms = torch.zeros((waveform.shape[0], n_frames))

        for i in range(n_frames):
            start = i * hop_length
            end = start + frame_length
            frame = waveform[:, start:end]

            # RMS = sqrt(mean(square(frame)))
            rms[:, i] = torch.sqrt(torch.mean(frame ** 2, dim=-1))

        return rms

    return Lens(_rms_energy, name=f"rms_energy(frame={frame_length})")

