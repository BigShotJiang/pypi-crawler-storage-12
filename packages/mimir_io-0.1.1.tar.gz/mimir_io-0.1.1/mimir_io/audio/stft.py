"""
STFT (Short-Time Fourier Transform) lenses.
"""

from typing import Optional
import torch
import torchaudio
from mimir_io.lens import Lens


def stft(
    n_fft: int = 2048,
    win_length: Optional[int] = None,
    hop_length: Optional[int] = None,
    window_fn: str = "hann",
    normalized: bool = False,
    center: bool = True,
    pad_mode: str = "reflect",
    return_complex: bool = True,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that computes Short-Time Fourier Transform (STFT).

    STFT is the fundamental transform for time-frequency analysis,
    used as a building block for spectrograms and other features.

    Args:
        n_fft: Size of FFT, creates n_fft // 2 + 1 bins
        win_length: Window size. If None, defaults to n_fft
        hop_length: Length of hop between STFT windows. If None, defaults to win_length // 4
        window_fn: Window function - "hann", "hamming", "blackman", etc.
        normalized: Whether to normalize by magnitude after stft
        center: Whether to pad waveform on both sides
        pad_mode: Padding mode when center is True
        return_complex: Whether to return complex tensor (default: True)

    Returns:
        Lens that computes STFT. Returns complex tensor if return_complex=True,
        otherwise returns magnitude spectrogram.

    Example:
        lens = stft(n_fft=2048, hop_length=512)
        stft_result = lens(waveform)  # Shape: (n_fft//2+1, time_frames)
    """
    if win_length is None:
        win_length = n_fft

    if hop_length is None:
        hop_length = win_length // 4

    window_fn_map = {
        "hann": torch.hann_window,
        "hamming": torch.hamming_window,
        "blackman": torch.blackman_window,
        "bartlett": torch.bartlett_window,
        "kaiser": torch.kaiser_window,
    }
    window_function = window_fn_map.get(window_fn, torch.hann_window)

    if return_complex:
        # Use functional STFT for complex output
        def _stft(waveform: torch.Tensor) -> torch.Tensor:
            if waveform.numel() == 0:
                n_bins = n_fft // 2 + 1
                return torch.empty((n_bins, 0), dtype=torch.complex64)
            
            window = window_function(win_length)
            result = torchaudio.functional.spectrogram(
                waveform,
                pad=0 if not center else win_length // 2,
                window=window,
                n_fft=n_fft,
                hop_length=hop_length,
                win_length=win_length,
                power=None,
                normalized=normalized,
                center=center,
                pad_mode=pad_mode,
            )
            # Remove channel dimension if single channel: (1, freq, time) -> (freq, time)
            if result.dim() == 3 and result.shape[0] == 1:
                return result.squeeze(0)
            return result
    else:
        # Use Spectrogram transform for magnitude output
        stft_transform = torchaudio.transforms.Spectrogram(
            n_fft=n_fft,
            win_length=win_length,
            hop_length=hop_length,
            window_fn=window_function,
            power=1.0,
            normalized=normalized,
            center=center,
            pad_mode=pad_mode,
        )

        def _stft(waveform: torch.Tensor) -> torch.Tensor:
            if waveform.numel() == 0:
                n_bins = n_fft // 2 + 1
                return torch.empty((n_bins, 0))
            result = stft_transform(waveform)
            # Remove channel dimension if single channel: (1, freq, time) -> (freq, time)
            if result.dim() == 3 and result.shape[0] == 1:
                return result.squeeze(0)
            return result

    return Lens(_stft, name=f"stft(n_fft={n_fft})")


def magnitude_spectrogram(
    n_fft: int = 2048,
    win_length: Optional[int] = None,
    hop_length: Optional[int] = None,
    window_fn: str = "hann",
    normalized: bool = False,
    center: bool = True,
    pad_mode: str = "reflect",
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that computes magnitude spectrogram from STFT.

    Args:
        n_fft: Size of FFT, creates n_fft // 2 + 1 bins
        win_length: Window size. If None, defaults to n_fft
        hop_length: Length of hop between STFT windows. If None, defaults to win_length // 4
        window_fn: Window function - "hann", "hamming", "blackman", etc.
        normalized: Whether to normalize by magnitude after stft
        center: Whether to pad waveform on both sides
        pad_mode: Padding mode when center is True

    Returns:
        Lens that computes magnitude spectrogram

    Example:
        lens = magnitude_spectrogram(n_fft=2048, hop_length=512)
        magnitude = lens(waveform)  # Shape: (n_fft//2+1, time_frames)
    """
    if win_length is None:
        win_length = n_fft

    if hop_length is None:
        hop_length = win_length // 4

    window_fn_map = {
        "hann": torch.hann_window,
        "hamming": torch.hamming_window,
        "blackman": torch.blackman_window,
        "bartlett": torch.bartlett_window,
        "kaiser": torch.kaiser_window,
    }
    window_function = window_fn_map.get(window_fn, torch.hann_window)

    spectrogram_transform = torchaudio.transforms.Spectrogram(
        n_fft=n_fft,
        win_length=win_length,
        hop_length=hop_length,
        window_fn=window_function,
        power=1.0,
        normalized=normalized,
        center=center,
        pad_mode=pad_mode,
    )

    def _magnitude_spectrogram(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            n_bins = n_fft // 2 + 1
            return torch.empty((n_bins, 0))
        result = spectrogram_transform(waveform)
        # Remove channel dimension if single channel: (1, freq, time) -> (freq, time)
        if result.dim() == 3 and result.shape[0] == 1:
            return result.squeeze(0)
        return result

    return Lens(_magnitude_spectrogram, name=f"magnitude_spectrogram(n_fft={n_fft})")


def power_spectrogram(
    n_fft: int = 2048,
    win_length: Optional[int] = None,
    hop_length: Optional[int] = None,
    window_fn: str = "hann",
    normalized: bool = False,
    center: bool = True,
    pad_mode: str = "reflect",
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Create a lens that computes power spectrogram from STFT.

    Args:
        n_fft: Size of FFT, creates n_fft // 2 + 1 bins
        win_length: Window size. If None, defaults to n_fft
        hop_length: Length of hop between STFT windows. If None, defaults to win_length // 4
        window_fn: Window function - "hann", "hamming", "blackman", etc.
        normalized: Whether to normalize by magnitude after stft
        center: Whether to pad waveform on both sides
        pad_mode: Padding mode when center is True

    Returns:
        Lens that computes power spectrogram

    Example:
        lens = power_spectrogram(n_fft=2048, hop_length=512)
        power = lens(waveform)  # Shape: (n_fft//2+1, time_frames)
    """
    if win_length is None:
        win_length = n_fft

    if hop_length is None:
        hop_length = win_length // 4

    window_fn_map = {
        "hann": torch.hann_window,
        "hamming": torch.hamming_window,
        "blackman": torch.blackman_window,
        "bartlett": torch.bartlett_window,
        "kaiser": torch.kaiser_window,
    }
    window_function = window_fn_map.get(window_fn, torch.hann_window)

    spectrogram_transform = torchaudio.transforms.Spectrogram(
        n_fft=n_fft,
        win_length=win_length,
        hop_length=hop_length,
        window_fn=window_function,
        power=2.0,
        normalized=normalized,
        center=center,
        pad_mode=pad_mode,
    )

    def _power_spectrogram(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            n_bins = n_fft // 2 + 1
            return torch.empty((n_bins, 0))
        result = spectrogram_transform(waveform)
        # Remove channel dimension if single channel: (1, freq, time) -> (freq, time)
        if result.dim() == 3 and result.shape[0] == 1:
            return result.squeeze(0)
        return result

    return Lens(_power_spectrogram, name=f"power_spectrogram(n_fft={n_fft})")

