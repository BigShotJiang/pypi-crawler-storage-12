"""
Audio augmentation lenses for waveform data and spectrograms.

Includes:
- Time domain augmentations (time shift, gain, noise, etc.)
- Frequency domain augmentations (filters, pitch shift, etc.)
- Advanced augmentations (SpecAugment, Mixup, CutMix, RandAugment)
- Adaptive augmentation

All augmentations are designed to be fast and work on GPU tensors.
"""

import torch
import torch.nn.functional as F
from typing import Optional, Tuple, Callable, Dict, Any
from mimir_io.lens import Lens
from mimir_io.random import get_seed, create_generator


# ========== Time Domain Augmentations ==========

def time_shift(max_shift_samples: int, seed: Optional[int] = None) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Fast time shifting augmentation (circular shift).

    Args:
        max_shift_samples: Maximum number of samples to shift
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that randomly shifts audio in time

    Example:
        lens = time_shift(max_shift_samples=1600)  # ±100ms at 16kHz
        shifted = lens(waveform)
    """
    # Store seed for later use, but don't create generator yet
    stored_seed = seed
    
    def _time_shift(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Create generator at execution time, checking global seed
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)

        shift = torch.randint(-max_shift_samples, max_shift_samples + 1, (1,), generator=gen).item()
        if shift == 0:
            return waveform

        return torch.roll(waveform, shift, dims=-1)

    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_time_shift, name=f"time_shift(max={max_shift_samples}{seed_suffix})")


def gain_variation(min_gain: float = 0.5, max_gain: float = 1.5, seed: Optional[int] = None) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Fast gain variation augmentation (random volume change).

    Args:
        min_gain: Minimum gain multiplier
        max_gain: Maximum gain multiplier
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that applies random gain

    Example:
        lens = gain_variation(min_gain=0.7, max_gain=1.3)
        augmented = lens(waveform)
    """
    # Store seed for later use, but don't create generator yet
    stored_seed = seed
    
    def _gain_variation(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Create generator at execution time, checking global seed
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)

        gain = torch.rand(1, generator=gen, device=waveform.device, dtype=waveform.dtype).item() * (max_gain - min_gain) + min_gain
        return waveform * gain

    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_gain_variation, name=f"gain_variation({min_gain}-{max_gain}{seed_suffix})")


def add_noise(snr_db: float = 20.0, seed: Optional[int] = None) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Fast noise injection augmentation.

    Args:
        snr_db: Signal-to-noise ratio in dB
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that adds Gaussian noise

    Example:
        lens = add_noise(snr_db=20.0)
        noisy = lens(waveform)
    """
    # Store seed for later use, but don't create generator yet
    stored_seed = seed
    
    def _add_noise(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Create generator at execution time, checking global seed
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)

        # Calculate signal power
        signal_power = torch.mean(waveform ** 2)
        if signal_power == 0:
            return waveform

        # Calculate noise power for desired SNR
        snr_linear = 10 ** (snr_db / 10.0)
        noise_power = signal_power / snr_linear

        # Generate noise
        noise = torch.randn(waveform.shape, generator=gen, dtype=waveform.dtype, device=waveform.device) * torch.sqrt(noise_power)
        return waveform + noise

    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_add_noise, name=f"add_noise(snr={snr_db}dB{seed_suffix})")


def time_mask(max_mask_samples: int, num_masks: int = 1, seed: Optional[int] = None) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Fast time masking augmentation (zero out time regions).

    Args:
        max_mask_samples: Maximum number of samples to mask
        num_masks: Number of masks to apply
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that applies time masking

    Example:
        lens = time_mask(max_mask_samples=1600, num_masks=2)
        masked = lens(waveform)
    """
    # Store seed for later use, but don't create generator yet
    stored_seed = seed
    
    def _time_mask(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Create generator at execution time, checking global seed
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)

        masked = waveform.clone()
        length = masked.shape[-1]

        for _ in range(num_masks):
            mask_size = torch.randint(0, max_mask_samples + 1, (1,), generator=gen).item()
            if mask_size == 0 or mask_size >= length:
                continue

            t0 = torch.randint(0, length - mask_size + 1, (1,), generator=gen).item()
            if masked.dim() == 1:
                masked[t0:t0 + mask_size] = 0.0
            else:
                masked[..., t0:t0 + mask_size] = 0.0

        return masked

    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_time_mask, name=f"time_mask(max={max_mask_samples},num={num_masks}{seed_suffix})")


def speed_change(
    sample_rate: int, min_speed: float = 0.9, max_speed: float = 1.1, seed: Optional[int] = None
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Fast speed change augmentation using resampling.

    Args:
        sample_rate: Original sample rate
        min_speed: Minimum speed multiplier (0.9 = 90% speed)
        max_speed: Maximum speed multiplier (1.1 = 110% speed)
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that changes playback speed

    Example:
        lens = speed_change(sample_rate=16000, min_speed=0.9, max_speed=1.1)
        speed_changed = lens(waveform)
    """
    import torchaudio
    # Store seed for later use, but don't create generator yet
    stored_seed = seed

    def _speed_change(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Create generator at execution time, checking global seed
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)

        speed = torch.rand(1, generator=gen, device=waveform.device, dtype=waveform.dtype).item() * (max_speed - min_speed) + min_speed
        if speed == 1.0:
            return waveform

        # Resample to change speed
        new_sample_rate = int(sample_rate * speed)
        resampled = torchaudio.functional.resample(
            waveform, orig_freq=sample_rate, new_freq=new_sample_rate
        )

        # Trim or pad to original length
        target_length = waveform.shape[-1]
        if resampled.shape[-1] > target_length:
            return resampled[..., :target_length]
        elif resampled.shape[-1] < target_length:
            padding = target_length - resampled.shape[-1]
            return F.pad(resampled, (0, padding))
        return resampled

    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_speed_change, name=f"speed_change({min_speed}-{max_speed}{seed_suffix})")


# ========== Advanced Augmentations ==========

def pitch_shift(sample_rate: int, n_steps: float = 2.0) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Fast pitch shifting using resampling + time stretch.

    Args:
        sample_rate: Original sample rate
        n_steps: Number of semitones to shift (can be negative)

    Returns:
        Lens that shifts pitch

    Example:
        lens = pitch_shift(sample_rate=16000, n_steps=2.0)  # Shift up 2 semitones
        pitch_shifted = lens(waveform)
    """
    import torchaudio

    def _pitch_shift(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Calculate pitch shift ratio
        pitch_ratio = 2 ** (n_steps / 12.0)

        # Resample to change pitch
        new_sr = int(sample_rate * pitch_ratio)
        resampled = torchaudio.functional.resample(
            waveform, orig_freq=sample_rate, new_freq=new_sr
        )

        # Time stretch back to original length
        target_length = waveform.shape[-1]
        if resampled.shape[-1] != target_length:
            # Simple resampling back (could use more sophisticated time stretch)
            final = torchaudio.functional.resample(
                resampled, orig_freq=new_sr, new_freq=sample_rate
            )
            if final.shape[-1] > target_length:
                return final[..., :target_length]
            elif final.shape[-1] < target_length:
                return F.pad(final, (0, target_length - final.shape[-1]))
            return final
        return resampled

    return Lens(_pitch_shift, name=f"pitch_shift({n_steps}st)")


def random_pitch_shift(
    sample_rate: int, min_steps: float = -2.0, max_steps: float = 2.0, seed: Optional[int] = None
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Random pitch shifting within a range.

    Args:
        sample_rate: Original sample rate
        min_steps: Minimum semitones to shift (can be negative)
        max_steps: Maximum semitones to shift
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that randomly shifts pitch

    Example:
        lens = random_pitch_shift(sample_rate=16000, min_steps=-2.0, max_steps=2.0)
        pitch_shifted = lens(waveform)
    """
    # Store seed for later use, but don't create generator yet
    stored_seed = seed
    
    def _random_pitch_shift(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Create generator at execution time, checking global seed
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)

        n_steps = torch.rand(1, generator=gen, device=waveform.device, dtype=waveform.dtype).item() * (max_steps - min_steps) + min_steps
        if n_steps == 0.0:
            return waveform

        return pitch_shift(sample_rate, n_steps)(waveform)

    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_random_pitch_shift, name=f"random_pitch_shift({min_steps}-{max_steps}st{seed_suffix})")


# ========== Advanced Time Domain Augmentations ==========

def time_stretch(
    sample_rate: int, min_rate: float = 0.8, max_rate: float = 1.25, seed: Optional[int] = None
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Time stretching without pitch change using torchaudio TimeStretch.

    Args:
        sample_rate: Sample rate of the audio
        min_rate: Minimum stretch rate (0.8 = 80% speed, longer duration)
        max_rate: Maximum stretch rate (1.25 = 125% speed, shorter duration)
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that applies time stretching

    Example:
        lens = time_stretch(sample_rate=16000, min_rate=0.9, max_rate=1.1)
        stretched = lens(waveform)
    """
    import torchaudio
    # Store seed for later use, but don't create generator yet
    stored_seed = seed

    def _time_stretch(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Create generator at execution time, checking global seed
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)

        rate = torch.rand(1, generator=gen, device=waveform.device, dtype=waveform.dtype).item() * (max_rate - min_rate) + min_rate
        if rate == 1.0:
            return waveform

        # TimeStretch requires complex spectrogram, so we use a workaround
        # For simplicity, we use resampling with length adjustment
        # A more accurate implementation would use torchaudio.transforms.TimeStretch
        # but it requires complex spectrograms
        
        # Simple approximation: resample and adjust length
        new_length = int(waveform.shape[-1] / rate)
        if new_length == 0:
            return waveform
            
        # Use interpolation to stretch/compress
        if waveform.dim() == 1:
            stretched = F.interpolate(
                waveform.unsqueeze(0).unsqueeze(0),
                size=new_length,
                mode="linear",
                align_corners=False,
            ).squeeze()
        else:
            stretched = F.interpolate(
                waveform.unsqueeze(0),
                size=new_length,
                mode="linear",
                align_corners=False,
            ).squeeze(0)

        # Trim or pad to original length
        target_length = waveform.shape[-1]
        if stretched.shape[-1] > target_length:
            return stretched[..., :target_length]
        elif stretched.shape[-1] < target_length:
            padding = target_length - stretched.shape[-1]
            return F.pad(stretched, (0, padding))
        return stretched

    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_time_stretch, name=f"time_stretch({min_rate}-{max_rate}{seed_suffix})")


def reverb(
    impulse_response: Optional[torch.Tensor] = None,
    room_size: float = 0.3,
    damping: float = 0.5,
    seed: Optional[int] = None,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Reverb augmentation using convolution with impulse response.

    Args:
        impulse_response: Optional custom impulse response tensor.
                         If None, generates a simple exponential decay IR.
        room_size: Room size parameter (0.0-1.0) for generated IR
        damping: Damping parameter (0.0-1.0) for generated IR
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that applies reverb

    Example:
        lens = reverb(room_size=0.5, damping=0.7)
        reverbed = lens(waveform)
    """
    # Store seed for later use, but don't create generator yet
    stored_seed = seed
    
    def _reverb(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Create generator at execution time, checking global seed
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)

        if impulse_response is None:
            # Generate simple exponential decay impulse response
            ir_length = int(waveform.shape[-1] * room_size)
            if ir_length < 10:
                return waveform

            t = torch.arange(ir_length, dtype=waveform.dtype, device=waveform.device)
            decay = torch.exp(-t / (ir_length * damping))
            ir = decay * torch.randn(ir_length, generator=gen, dtype=waveform.dtype, device=waveform.device) * 0.1
            ir = ir / torch.norm(ir)
        else:
            ir = impulse_response

        # Apply convolution
        if waveform.dim() == 1:
            reverbed = F.conv1d(
                waveform.unsqueeze(0).unsqueeze(0),
                ir.unsqueeze(0).unsqueeze(0),
                padding=ir.shape[-1] - 1,
            ).squeeze()
            # Trim to original length
            return reverbed[: waveform.shape[-1]]
        else:
            reverbed = F.conv1d(
                waveform.unsqueeze(0),
                ir.unsqueeze(0).unsqueeze(0),
                padding=ir.shape[-1] - 1,
            ).squeeze(0)
            return reverbed[:, : waveform.shape[-1]]

    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_reverb, name=f"reverb(room={room_size}{seed_suffix})")


def bandpass_filter(
    sample_rate: int,
    low_freq: float = 300.0,
    high_freq: float = 3400.0,
    order: int = 4,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Bandpass filter augmentation (simulates telephone quality).

    Args:
        sample_rate: Sample rate
        low_freq: Low cutoff frequency in Hz
        high_freq: High cutoff frequency in Hz
        order: Filter order (higher = sharper cutoff)

    Returns:
        Lens that applies bandpass filtering

    Example:
        lens = bandpass_filter(sample_rate=16000, low_freq=300, high_freq=3400)
        filtered = lens(waveform)
    """
    import torchaudio

    def _bandpass_filter(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        nyquist = sample_rate / 2.0
        low_freq_norm = low_freq / nyquist
        high_freq_norm = high_freq / nyquist

        # Use torchaudio's functional highpass and lowpass filters
        # Apply highpass then lowpass
        filtered = torchaudio.functional.highpass_biquad(
            waveform, sample_rate=sample_rate, cutoff_freq=low_freq
        )
        filtered = torchaudio.functional.lowpass_biquad(
            filtered, sample_rate=sample_rate, cutoff_freq=high_freq
        )
        return filtered

    return Lens(_bandpass_filter, name=f"bandpass({low_freq}-{high_freq}Hz)")


def highpass_filter(
    sample_rate: int, cutoff_freq: float = 80.0
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Highpass filter augmentation.

    Args:
        sample_rate: Sample rate
        cutoff_freq: Cutoff frequency in Hz

    Returns:
        Lens that applies highpass filtering

    Example:
        lens = highpass_filter(sample_rate=16000, cutoff_freq=80)
        filtered = lens(waveform)
    """
    import torchaudio

    def _highpass_filter(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        return torchaudio.functional.highpass_biquad(
            waveform, sample_rate=sample_rate, cutoff_freq=cutoff_freq
        )

    return Lens(_highpass_filter, name=f"highpass({cutoff_freq}Hz)")


def lowpass_filter(
    sample_rate: int, cutoff_freq: float = 8000.0
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Lowpass filter augmentation.

    Args:
        sample_rate: Sample rate
        cutoff_freq: Cutoff frequency in Hz

    Returns:
        Lens that applies lowpass filtering

    Example:
        lens = lowpass_filter(sample_rate=16000, cutoff_freq=8000)
        filtered = lens(waveform)
    """
    import torchaudio

    def _lowpass_filter(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        return torchaudio.functional.lowpass_biquad(
            waveform, sample_rate=sample_rate, cutoff_freq=cutoff_freq
        )

    return Lens(_lowpass_filter, name=f"lowpass({cutoff_freq}Hz)")


def polarity_inversion(seed: Optional[int] = None) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Polarity inversion augmentation (phase flip).

    Randomly inverts the polarity of the signal.

    Args:
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that randomly inverts polarity

    Example:
        lens = polarity_inversion()
        inverted = lens(waveform)
    """
    # Store seed for later use, but don't create generator yet
    stored_seed = seed
    
    def _polarity_inversion(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Create generator at execution time, checking global seed
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)

        # Randomly decide whether to invert
        if torch.rand(1, generator=gen).item() < 0.5:
            return waveform
        return -waveform

    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_polarity_inversion, name=f"polarity_inversion({seed_suffix})")


def clipping_distortion(
    min_threshold: float = 0.5, max_threshold: float = 0.95, seed: Optional[int] = None
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Clipping distortion augmentation.

    Args:
        min_threshold: Minimum clipping threshold (0.0-1.0)
        max_threshold: Maximum clipping threshold (0.0-1.0)
        seed: Optional random seed. If None, uses global seed or random.

    Returns:
        Lens that applies clipping distortion

    Example:
        lens = clipping_distortion(min_threshold=0.7, max_threshold=0.95)
        clipped = lens(waveform)
    """
    # Store seed for later use, but don't create generator yet
    stored_seed = seed
    
    def _clipping_distortion(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        # Create generator at execution time, checking global seed
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)

        threshold = torch.rand(1, generator=gen, device=waveform.device, dtype=waveform.dtype).item() * (max_threshold - min_threshold) + min_threshold
        clipped = torch.clamp(waveform, -threshold, threshold)
        # Normalize back to original range
        if threshold < 1.0:
            clipped = clipped / threshold
        return clipped

    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(_clipping_distortion, name=f"clipping({min_threshold}-{max_threshold}{seed_suffix})")


def echo(
    sample_rate: int,
    delay_ms: float = 100.0,
    decay: float = 0.3,
    num_echos: int = 1,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    Echo/Delay augmentation.

    Args:
        sample_rate: Sample rate
        delay_ms: Delay in milliseconds
        decay: Decay factor for each echo (0.0-1.0)
        num_echos: Number of echoes

    Returns:
        Lens that applies echo effect

    Example:
        lens = echo(sample_rate=16000, delay_ms=100, decay=0.3)
        echoed = lens(waveform)
    """
    def _echo(waveform: torch.Tensor) -> torch.Tensor:
        if waveform.numel() == 0:
            return waveform

        delay_samples = int(delay_ms * sample_rate / 1000.0)
        if delay_samples == 0 or delay_samples >= waveform.shape[-1]:
            return waveform

        echoed = waveform.clone()
        current_decay = decay

        for _ in range(num_echos):
            echo_signal = waveform * current_decay
            # Shift echo signal
            echo_signal = F.pad(echo_signal, (delay_samples, 0))[
                ..., : waveform.shape[-1]
            ]
            echoed = echoed + echo_signal
            current_decay *= decay

        # Normalize to prevent clipping
        max_val = torch.abs(echoed).max()
        if max_val > 1.0:
            echoed = echoed / max_val

        return echoed

    return Lens(_echo, name=f"echo(delay={delay_ms}ms,decay={decay})")


# ========== SpecAugment ==========

def spec_augment(
    time_mask_param: int = 27,
    num_time_masks: int = 2,
    freq_mask_param: int = 12,
    num_freq_masks: int = 2,
    fill_value: float = 0.0,
    seed: Optional[int] = None,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    SpecAugment augmentation for spectrograms.
    
    SpecAugment masks time and frequency regions of spectrograms to improve
    model generalization. This is the standard technique for audio classification.
    
    Args:
        time_mask_param: Maximum number of time frames to mask
        num_time_masks: Number of time masks to apply
        freq_mask_param: Maximum number of frequency bins to mask
        num_freq_masks: Number of frequency masks to apply
        fill_value: Value to fill masked regions (usually 0.0 or mean)
        seed: Optional random seed for reproducibility
        
    Returns:
        Lens that applies SpecAugment to spectrogram
        
    Example:
        >>> from mimir_io.audio import spec_augment, resample, log_mel_spectrogram
        >>> # For log mel spectrogram: (n_mels, time_frames)
        >>> aug = spec_augment(time_mask_param=27, num_time_masks=2, 
        ...                    freq_mask_param=12, num_freq_masks=2)
        >>> augmented_spec = aug(mel_spec)
    """
    stored_seed = seed
    
    def _spec_augment(spec: torch.Tensor) -> torch.Tensor:
        if spec.numel() == 0:
            return spec
            
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)
        
        masked_spec = spec.clone()
        
        # Determine dimensions
        if spec.dim() == 2:
            # (freq_bins, time_frames)
            freq_bins, time_frames = spec.shape
        elif spec.dim() == 3:
            # (channels, freq_bins, time_frames) or (batch, freq_bins, time_frames)
            # Assume last two dimensions are freq and time
            _, freq_bins, time_frames = spec.shape
        else:
            return spec
        
        # Frequency masking
        for _ in range(num_freq_masks):
            f = torch.randint(0, freq_mask_param + 1, (1,), generator=gen).item()
            if f == 0 or f >= freq_bins:
                continue
                
            f0 = torch.randint(0, freq_bins - f + 1, (1,), generator=gen).item()
            
            if spec.dim() == 2:
                masked_spec[f0:f0 + f, :] = fill_value
            else:
                masked_spec[:, f0:f0 + f, :] = fill_value
        
        # Time masking
        for _ in range(num_time_masks):
            t = torch.randint(0, time_mask_param + 1, (1,), generator=gen).item()
            if t == 0 or t >= time_frames:
                continue
                
            t0 = torch.randint(0, time_frames - t + 1, (1,), generator=gen).item()
            
            if spec.dim() == 2:
                masked_spec[:, t0:t0 + t] = fill_value
            else:
                masked_spec[:, :, t0:t0 + t] = fill_value
        
        return masked_spec
    
    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(
        _spec_augment,
        name=f"spec_augment(tm={time_mask_param},fm={freq_mask_param}{seed_suffix})"
    )


# ========== Mixup ==========

def mixup_batch(
    alpha: float = 0.2,
    seed: Optional[int] = None,
) -> Callable[[torch.Tensor, torch.Tensor], Tuple[torch.Tensor, torch.Tensor, torch.Tensor]]:
    """
    Mixup augmentation for batches.
    
    Mixup creates new samples as linear combinations of two samples:
    x_new = lambda * x1 + (1 - lambda) * x2
    y_new = lambda * y1 + (1 - lambda) * y2
    
    Args:
        alpha: Beta distribution parameter for lambda (higher = more mixing)
        seed: Optional random seed
        
    Returns:
        Function that takes (batch_x, batch_y) and returns (x_mixed, y_mixed, lambda)
        
    Example:
        >>> from mimir_io.audio import mixup_batch
        >>> mixup_fn = mixup_batch(alpha=0.2)
        >>> x_mixed, y_mixed, lam = mixup_fn(batch_x, batch_y)
    """
    stored_seed = seed
    
    def _mixup_batch(
        batch_x: torch.Tensor,
        batch_y: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Apply Mixup to batch.
        
        Args:
            batch_x: Data tensor shape (batch_size, ...)
            batch_y: Label tensor shape (batch_size, ...) or (batch_size,)
            
        Returns:
            (x_mixed, y_mixed, lambda_values)
        """
        if batch_x.size(0) < 2:
            # Not enough samples for mixup
            lam = torch.ones(batch_x.size(0), device=batch_x.device)
            return batch_x, batch_y, lam
        
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)
        
        batch_size = batch_x.size(0)
        
        # Generate lambda for each sample
        if alpha > 0:
            lam = torch.distributions.Beta(alpha, alpha).sample((batch_size,), generator=gen).to(batch_x.device)
            lam = torch.max(lam, 1 - lam)  # Use max(lambda, 1-lambda) for symmetry
        else:
            lam = torch.ones(batch_size, device=batch_x.device)
        
        # Random permutation of indices
        index = torch.randperm(batch_size, generator=gen, device=batch_x.device)
        
        # Mix data
        lam_expanded = lam.view(-1, *([1] * (batch_x.dim() - 1)))
        x_mixed = lam_expanded * batch_x + (1 - lam_expanded) * batch_x[index]
        
        # Mix labels
        if batch_y.dim() == 1:
            # Scalar labels
            y_mixed = lam * batch_y.float() + (1 - lam) * batch_y[index].float()
        else:
            # One-hot or multi-label
            lam_y = lam.view(-1, *([1] * (batch_y.dim() - 1)))
            y_mixed = lam_y * batch_y.float() + (1 - lam_y) * batch_y[index].float()
        
        return x_mixed, y_mixed, lam
    
    return _mixup_batch


# ========== CutMix ==========

def cutmix_batch(
    alpha: float = 1.0,
    seed: Optional[int] = None,
) -> Callable[[torch.Tensor, torch.Tensor], Tuple[torch.Tensor, torch.Tensor, torch.Tensor]]:
    """
    CutMix augmentation for batches - cuts region from one sample and pastes into another.
    
    CutMix works better for images/spectrograms than Mixup because it preserves
    local structure of data.
    
    Args:
        alpha: Beta distribution parameter for cut region size
        seed: Optional random seed
        
    Returns:
        Function that takes (batch_x, batch_y) and returns (x_mixed, y_mixed, lambda)
        
    Example:
        >>> from mimir_io.audio import cutmix_batch
        >>> cutmix_fn = cutmix_batch(alpha=1.0)
        >>> x_mixed, y_mixed, lam = cutmix_fn(batch_x, batch_y)
    """
    stored_seed = seed
    
    def _cutmix_batch(
        batch_x: torch.Tensor,
        batch_y: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Apply CutMix to batch.
        
        Args:
            batch_x: Data tensor shape (batch_size, channels, freq, time) or (batch_size, freq, time)
            batch_y: Label tensor shape (batch_size, ...) or (batch_size,)
            
        Returns:
            (x_mixed, y_mixed, lambda_values)
        """
        if batch_x.size(0) < 2:
            lam = torch.ones(batch_x.size(0), device=batch_x.device)
            return batch_x, batch_y, lam
        
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)
        
        batch_size = batch_x.size(0)
        
        # Generate lambda from beta distribution
        if alpha > 0:
            lam = torch.distributions.Beta(alpha, alpha).sample((batch_size,), generator=gen).to(batch_x.device)
            lam = torch.max(lam, 1 - lam)  # Use max(lambda, 1-lambda)
        else:
            lam = torch.ones(batch_size, device=batch_x.device)
        
        # Random permutation of indices
        index = torch.randperm(batch_size, generator=gen, device=batch_x.device)
        
        # Determine dimensions
        if batch_x.dim() == 3:
            # (batch, freq, time)
            B, H, W = batch_x.shape
            x_mixed = batch_x.clone()
            
            for i in range(batch_size):
                # Calculate cut region size
                cut_ratio = (1 - lam[i].item()) ** 0.5
                cut_h = int(H * cut_ratio)
                cut_w = int(W * cut_ratio)
                
                # Random position
                cy = torch.randint(0, H, (1,), generator=gen).item()
                cx = torch.randint(0, W, (1,), generator=gen).item()
                
                # Clip boundaries
                bby1 = max(0, cy - cut_h // 2)
                bbx1 = max(0, cx - cut_w // 2)
                bby2 = min(H, cy + cut_h // 2)
                bbx2 = min(W, cx + cut_w // 2)
                
                # Paste cut region
                x_mixed[i, bby1:bby2, bbx1:bbx2] = batch_x[index[i], bby1:bby2, bbx1:bbx2]
                
                # Update lambda based on actual area
                lam[i] = 1 - ((bby2 - bby1) * (bbx2 - bbx1) / (H * W))
                
        elif batch_x.dim() == 4:
            # (batch, channels, freq, time)
            B, C, H, W = batch_x.shape
            x_mixed = batch_x.clone()
            
            for i in range(batch_size):
                cut_ratio = (1 - lam[i].item()) ** 0.5
                cut_h = int(H * cut_ratio)
                cut_w = int(W * cut_ratio)
                
                cy = torch.randint(0, H, (1,), generator=gen).item()
                cx = torch.randint(0, W, (1,), generator=gen).item()
                
                bby1 = max(0, cy - cut_h // 2)
                bbx1 = max(0, cx - cut_w // 2)
                bby2 = min(H, cy + cut_h // 2)
                bbx2 = min(W, cx + cut_w // 2)
                
                x_mixed[i, :, bby1:bby2, bbx1:bbx2] = batch_x[index[i], :, bby1:bby2, bbx1:bbx2]
                lam[i] = 1 - ((bby2 - bby1) * (bbx2 - bbx1) / (H * W))
        else:
            # Fallback to mixup for other formats
            lam_expanded = lam.view(-1, *([1] * (batch_x.dim() - 1)))
            x_mixed = lam_expanded * batch_x + (1 - lam_expanded) * batch_x[index]
        
        # Mix labels
        if batch_y.dim() == 1:
            y_mixed = lam * batch_y.float() + (1 - lam) * batch_y[index].float()
        else:
            lam_y = lam.view(-1, *([1] * (batch_y.dim() - 1)))
            y_mixed = lam_y * batch_y.float() + (1 - lam_y) * batch_y[index].float()
        
        return x_mixed, y_mixed, lam
    
    return _cutmix_batch


# ========== RandAugment ==========

def rand_augment(
    num_ops: int = 2,
    magnitude: int = 9,
    num_magnitude_bins: int = 10,
    seed: Optional[int] = None,
) -> Lens[torch.Tensor, torch.Tensor]:
    """
    RandAugment - simplified version of AutoAugment.
    
    Randomly selects and applies augmentation operations with fixed magnitude.
    For spectrograms, uses SpecAugment with random parameters.
    
    Args:
        num_ops: Number of operations to apply
        magnitude: Augmentation magnitude (0-10)
        num_magnitude_bins: Number of magnitude bins
        seed: Optional random seed
        
    Returns:
        Lens that applies RandAugment
        
    Example:
        >>> from mimir_io.audio import rand_augment
        >>> aug = rand_augment(num_ops=2, magnitude=9)
        >>> augmented = aug(spec)
    """
    stored_seed = seed
    
    def _rand_augment(x: torch.Tensor) -> torch.Tensor:
        if x.numel() == 0:
            return x
            
        actual_seed = get_seed(stored_seed)
        gen = create_generator(actual_seed)
        
        # For spectrograms, apply SpecAugment with random parameters
        if x.dim() >= 2:
            # Determine dimensions
            if x.dim() == 2:
                freq_bins, time_frames = x.shape
            elif x.dim() == 3:
                # Assume last two dimensions are freq and time
                _, freq_bins, time_frames = x.shape
            else:
                return x
            
            # Random parameters for SpecAugment based on magnitude
            magnitude_ratio = magnitude / num_magnitude_bins
            
            time_mask_param = max(1, int(time_frames * 0.1 * magnitude_ratio))
            freq_mask_param = max(1, int(freq_bins * 0.1 * magnitude_ratio))
            
            # Random number of masks
            num_time = torch.randint(1, num_ops + 1, (1,), generator=gen).item()
            num_freq = torch.randint(1, num_ops + 1, (1,), generator=gen).item()
            
            # Apply SpecAugment
            aug_lens = spec_augment(
                time_mask_param=time_mask_param,
                num_time_masks=num_time,
                freq_mask_param=freq_mask_param,
                num_freq_masks=num_freq,
                seed=actual_seed,
            )
            return aug_lens(x)
        
        return x
    
    seed_suffix = f",seed={stored_seed}" if stored_seed is not None else ""
    return Lens(
        _rand_augment,
        name=f"rand_augment(ops={num_ops},mag={magnitude}{seed_suffix})"
    )


# ========== Adaptive Augmentation ==========

class AdaptiveAugmentation:
    """
    Adaptive augmentation based on training metrics.
    
    Automatically adjusts augmentation intensity based on:
    - Overfitting (large gap between train and val loss)
    - Underfitting (high train loss)
    - Validation metrics
    """
    
    def __init__(
        self,
        initial_magnitude: float = 0.5,
        min_magnitude: float = 0.0,
        max_magnitude: float = 1.0,
        adaptation_rate: float = 0.1,
    ):
        """
        Args:
            initial_magnitude: Initial augmentation magnitude
            min_magnitude: Minimum magnitude
            max_magnitude: Maximum magnitude
            adaptation_rate: Adaptation rate
        """
        self.magnitude = initial_magnitude
        self.min_magnitude = min_magnitude
        self.max_magnitude = max_magnitude
        self.adaptation_rate = adaptation_rate
        self.history = []
    
    def update(
        self,
        train_loss: float,
        val_loss: float,
        val_metric: Optional[float] = None,
    ) -> None:
        """
        Update augmentation magnitude based on metrics.
        
        Args:
            train_loss: Current train loss
            val_loss: Current validation loss
            val_metric: Optional metric (accuracy etc.)
        """
        # Calculate gap between train and val loss
        gap = val_loss - train_loss
        
        # If gap is large (overfitting) - increase augmentation
        # If gap is small or negative (underfitting) - decrease augmentation
        if gap > 0.1:  # Overfitting
            self.magnitude = min(
                self.max_magnitude,
                self.magnitude + self.adaptation_rate * gap
            )
        elif gap < -0.05:  # Underfitting
            self.magnitude = max(
                self.min_magnitude,
                self.magnitude - self.adaptation_rate * abs(gap)
            )
        
        # Save history
        self.history.append({
            'magnitude': self.magnitude,
            'train_loss': train_loss,
            'val_loss': val_loss,
            'gap': gap,
        })
    
    def get_augmentation_lens(
        self,
        base_augmentation: Lens,
        seed: Optional[int] = None,
    ) -> Lens:
        """
        Create lens with adaptive magnitude.
        
        Args:
            base_augmentation: Base augmentation lens
            seed: Optional seed
            
        Returns:
            Lens with adaptive magnitude
        """
        # For SpecAugment and RandAugment, can scale parameters
        # For now, return base lens
        # Can be extended for dynamic parameter changes
        return base_augmentation
    
    def get_magnitude(self) -> float:
        """Return current magnitude."""
        return self.magnitude


# ========== Composite Augmentations ==========

def compose_augmentations(*augmentations: Lens) -> Lens:
    """
    Compose multiple augmentations into a single lens.

    Args:
        *augmentations: Variable number of augmentation lenses

    Returns:
        Composed lens that applies all augmentations in sequence

    Example:
        augs = compose_augmentations(
            time_shift(1600),
            gain_variation(0.7, 1.3),
            add_noise(20.0)
        )
        augmented = augs(waveform)
    """
    from mimir_io.lens import compose, identity

    if not augmentations:
        return identity()

    # Compose lenses using the | operator
    result = augmentations[0]
    for aug in augmentations[1:]:
        result = result | aug

    return result

