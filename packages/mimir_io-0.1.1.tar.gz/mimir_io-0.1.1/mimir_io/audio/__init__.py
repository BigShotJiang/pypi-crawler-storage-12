"""
Audio-specific lens transformations and utilities.
"""

from mimir_io.audio.load import load_audio, load_audio_with_sr
from mimir_io.audio.transform import to_tensor, normalize, trim_silence
from mimir_io.audio.resample import resample
from mimir_io.audio.preemphasis import preemphasis
from mimir_io.audio.stft import stft, magnitude_spectrogram, power_spectrogram
from mimir_io.audio.spectrogram import (
    mel_spectrogram,
    log_mel_spectrogram,
    delta,
    delta_delta,
    stack_delta_features,
)
from mimir_io.audio.mfcc import mfcc, mfcc_with_delta
from mimir_io.audio.features import (
    power_to_db,
    amplitude_to_db,
    zero_crossing_rate,
    rms_energy,
)
from mimir_io.audio.augment import (
    time_shift,
    gain_variation,
    add_noise,
    time_mask,
    speed_change,
    pitch_shift,
    random_pitch_shift,
    time_stretch,
    reverb,
    bandpass_filter,
    highpass_filter,
    lowpass_filter,
    polarity_inversion,
    clipping_distortion,
    echo,
    compose_augmentations,
    spec_augment,
    mixup_batch,
    cutmix_batch,
    rand_augment,
    AdaptiveAugmentation,
)
# Frame lenses moved to rayframe subdirectories
# Import from rayframe instead:
# from mimir_io.rayframe import load_audio_frame, to_audio_frame, etc.

__all__ = [
    "load_audio",
    "load_audio_with_sr",
    "to_tensor",
    "normalize",
    "resample",
    "trim_silence",
    "preemphasis",
    "stft",
    "magnitude_spectrogram",
    "power_spectrogram",
    "mel_spectrogram",
    "log_mel_spectrogram",
    "delta",
    "delta_delta",
    "stack_delta_features",
    "mfcc",
    "mfcc_with_delta",
    "power_to_db",
    "amplitude_to_db",
    "zero_crossing_rate",
    "rms_energy",
    # Augmentations
    "time_shift",
    "gain_variation",
    "add_noise",
    "time_mask",
    "speed_change",
    "pitch_shift",
    "random_pitch_shift",
    "time_stretch",
    "reverb",
    "bandpass_filter",
    "highpass_filter",
    "lowpass_filter",
    "polarity_inversion",
    "clipping_distortion",
    "echo",
    "compose_augmentations",
    # Advanced augmentations
    "spec_augment",
    "mixup_batch",
    "cutmix_batch",
    "rand_augment",
    "AdaptiveAugmentation",
    "spec_augment_frame",
    # Frame lenses moved to mimir_io.rayframe
]

