"""
Модуль оптимізації порядку трансформацій у пайплайнах.

Реалізує автоматичну оптимізацію порядку трансформацій для підвищення
швидкості обробки даних.

Підтримує кілька алгоритмів оптимізації:
- heuristic: Швидка евристична оптимізація (за замовчуванням)
- dp: Dynamic Programming для оптимального рішення (для невеликих пайплайнів)
- exhaustive: Повний перебір всіх можливих порядків (для дуже малих пайплайнів)
- genetic: Генетичний алгоритм для складних пайплайнів
"""

from typing import List, Dict, Optional, Any, Tuple, Set
from enum import Enum
import time
import re
import itertools
import random
from mimir_io.lens import Lens, compose


class TransformationType(Enum):
    """Типи трансформацій для класифікації."""
    LOAD = "load"
    WAVEFORM_PREPROCESSING = "waveform_preprocessing"
    WAVEFORM_AUGMENTATION = "waveform_augmentation"
    SPECTROGRAM_GENERATION = "spectrogram_generation"
    SPECTROGRAM_AUGMENTATION = "spectrogram_augmentation"
    FEATURE_EXTRACTION = "feature_extraction"
    UNKNOWN = "unknown"


class TransformationCost(Enum):
    """Оцінка витрат трансформації."""
    VERY_CHEAP = 1
    CHEAP = 2
    MEDIUM = 3
    EXPENSIVE = 4
    VERY_EXPENSIVE = 5


# Словник класифікації трансформацій за назвою
TRANSFORMATION_CLASSIFICATION: Dict[str, Tuple[TransformationType, TransformationCost]] = {
    # Завантаження
    "load_audio": (TransformationType.LOAD, TransformationCost.MEDIUM),
    "load_audio_with_sr": (TransformationType.LOAD, TransformationCost.MEDIUM),
    "load_audio_frame": (TransformationType.LOAD, TransformationCost.MEDIUM),
    
    # Обробка waveform
    "resample": (TransformationType.WAVEFORM_PREPROCESSING, TransformationCost.EXPENSIVE),
    "normalize": (TransformationType.WAVEFORM_PREPROCESSING, TransformationCost.CHEAP),
    "trim_silence": (TransformationType.WAVEFORM_PREPROCESSING, TransformationCost.MEDIUM),
    "preemphasis": (TransformationType.WAVEFORM_PREPROCESSING, TransformationCost.CHEAP),
    "to_tensor": (TransformationType.WAVEFORM_PREPROCESSING, TransformationCost.VERY_CHEAP),
    
    # Фільтри (обробка waveform)
    "bandpass_filter": (TransformationType.WAVEFORM_PREPROCESSING, TransformationCost.MEDIUM),
    "highpass_filter": (TransformationType.WAVEFORM_PREPROCESSING, TransformationCost.MEDIUM),
    "lowpass_filter": (TransformationType.WAVEFORM_PREPROCESSING, TransformationCost.MEDIUM),
    
    # Аугментації waveform
    "time_shift": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.CHEAP),
    "gain_variation": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.VERY_CHEAP),
    "add_noise": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.CHEAP),
    "time_mask": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.VERY_CHEAP),
    "speed_change": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.EXPENSIVE),
    "pitch_shift": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.EXPENSIVE),
    "random_pitch_shift": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.EXPENSIVE),
    "time_stretch": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.EXPENSIVE),
    "reverb": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.MEDIUM),
    "echo": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.MEDIUM),
    "polarity_inversion": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.VERY_CHEAP),
    "clipping_distortion": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.VERY_CHEAP),
    "augment_audio_frame": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.MEDIUM),
    "compose_augmentations": (TransformationType.WAVEFORM_AUGMENTATION, TransformationCost.MEDIUM),
    
    # Генерація спектрограм
    "stft": (TransformationType.SPECTROGRAM_GENERATION, TransformationCost.EXPENSIVE),
    "magnitude_spectrogram": (TransformationType.SPECTROGRAM_GENERATION, TransformationCost.EXPENSIVE),
    "power_spectrogram": (TransformationType.SPECTROGRAM_GENERATION, TransformationCost.EXPENSIVE),
    "mel_spectrogram": (TransformationType.SPECTROGRAM_GENERATION, TransformationCost.VERY_EXPENSIVE),
    "log_mel_spectrogram": (TransformationType.SPECTROGRAM_GENERATION, TransformationCost.VERY_EXPENSIVE),
    
    # Аугментації спектрограм
    "spec_augment": (TransformationType.SPECTROGRAM_AUGMENTATION, TransformationCost.VERY_CHEAP),
    "spec_augment_frame": (TransformationType.SPECTROGRAM_AUGMENTATION, TransformationCost.VERY_CHEAP),
    
    # Витягування ознак
    "mfcc": (TransformationType.FEATURE_EXTRACTION, TransformationCost.VERY_EXPENSIVE),
    "mfcc_with_delta": (TransformationType.FEATURE_EXTRACTION, TransformationCost.VERY_EXPENSIVE),
    "delta": (TransformationType.FEATURE_EXTRACTION, TransformationCost.CHEAP),
    "delta_delta": (TransformationType.FEATURE_EXTRACTION, TransformationCost.CHEAP),
    "stack_delta_features": (TransformationType.FEATURE_EXTRACTION, TransformationCost.CHEAP),
    "power_to_db": (TransformationType.FEATURE_EXTRACTION, TransformationCost.CHEAP),
    "amplitude_to_db": (TransformationType.FEATURE_EXTRACTION, TransformationCost.CHEAP),
    "zero_crossing_rate": (TransformationType.FEATURE_EXTRACTION, TransformationCost.MEDIUM),
    "rms_energy": (TransformationType.FEATURE_EXTRACTION, TransformationCost.MEDIUM),
}


def _classify_transformation(name: str) -> Tuple[TransformationType, TransformationCost]:
    """
    Класифікує трансформацію за назвою.
    
    Args:
        name: Назва трансформації (може містити параметри)
        
    Returns:
        Кортеж (тип, витрати)
    """
    # Видаляємо параметри з назви для пошуку
    base_name = name.split('(')[0].strip()
    
    # Перевіряємо точну відповідність
    if base_name in TRANSFORMATION_CLASSIFICATION:
        return TRANSFORMATION_CLASSIFICATION[base_name]
    
    # Перевіряємо часткові збіги
    for key, value in TRANSFORMATION_CLASSIFICATION.items():
        if key in name or name.startswith(key):
            return value
    
    # За замовчуванням
    return (TransformationType.UNKNOWN, TransformationCost.MEDIUM)


def _decompose_pipeline(lens: Lens) -> List[Lens]:
    """
    Розбиває композований lens на окремі трансформації.
    
    Args:
        lens: Композований або простий lens
        
    Returns:
        Список окремих lens трансформацій
    """
    # Якщо lens має збережені компоненти, використовуємо їх
    if hasattr(lens, '_components'):
        return lens._components  # type: ignore
    
    # Якщо це простий lens (без композиції)
    if not hasattr(lens, '_name') or ' | ' not in lens._name:
        return [lens]
    
    # Якщо компоненти не збережені, але є композиція в назві,
    # намагаємося відновити через рекурсивне розбиття
    # Це працює тільки якщо lens були створені через compose()
    # Для інших випадків повертаємо оригінальний lens
    return [lens]


def _get_dependency_order() -> List[TransformationType]:
    """
    Повертає порядок залежностей типів трансформацій.
    
    Returns:
        Список типів у порядку виконання
    """
    return [
        TransformationType.LOAD,
        TransformationType.WAVEFORM_PREPROCESSING,
        TransformationType.WAVEFORM_AUGMENTATION,
        TransformationType.SPECTROGRAM_GENERATION,
        TransformationType.SPECTROGRAM_AUGMENTATION,
        TransformationType.FEATURE_EXTRACTION,
        TransformationType.UNKNOWN,
    ]


def _can_reorder(trans1: Lens, trans2: Lens) -> bool:
    """
    Перевіряє, чи можна переставити дві трансформації місцями.
    
    Args:
        trans1: Перша трансформація
        trans2: Друга трансформація
        
    Returns:
        True, якщо можна переставити
    """
    type1, _ = _classify_transformation(trans1._name)
    type2, _ = _classify_transformation(trans2._name)
    
    # Отримуємо порядок залежностей
    order = _get_dependency_order()
    
    # Знаходимо індекси типів
    try:
        idx1 = order.index(type1)
        idx2 = order.index(type2)
    except ValueError:
        # Якщо тип не знайдено, не переставляємо
        return False
    
    # Можна переставити, якщо вони одного типу або сусідні
    return abs(idx1 - idx2) <= 1


def _optimize_within_category(transformations: List[Lens]) -> List[Lens]:
    """
    Оптимізує порядок трансформацій всередині однієї категорії.
    
    Правила:
    1. Дешеві операції перед дорогими
    2. Кешовані операції перед некешованими (якщо можливо)
    3. Операції, що зменшують розмір, перед операціями, що збільшують
    
    Args:
        transformations: Список трансформацій одного типу
        
    Returns:
        Оптимізований список
    """
    if len(transformations) <= 1:
        return transformations
    
    # Сортуємо за витратами (дешеві перші)
    def get_cost_key(trans: Lens) -> Tuple[int, bool]:
        _, cost = _classify_transformation(trans._name)
        should_cache = getattr(trans, '_should_cache', True)
        # Кешовані мають пріоритет (False = кешовані перші)
        return (cost.value, not should_cache)
    
    return sorted(transformations, key=get_cost_key)


def _group_by_type(transformations: List[Lens]) -> Dict[TransformationType, List[Lens]]:
    """
    Групує трансформації за типами.
    
    Args:
        transformations: Список трансформацій
        
    Returns:
        Словник тип -> список трансформацій
    """
    groups: Dict[TransformationType, List[Lens]] = {}
    
    for trans in transformations:
        trans_type, _ = _classify_transformation(trans._name)
        if trans_type not in groups:
            groups[trans_type] = []
        groups[trans_type].append(trans)
    
    return groups


class OptimizationAlgorithm(Enum):
    """Алгоритми оптимізації."""
    HEURISTIC = "heuristic"  # Швидка евристика (за замовчуванням)
    DP = "dp"  # Dynamic Programming (для невеликих пайплайнів)
    EXHAUSTIVE = "exhaustive"  # Повний перебір (для дуже малих пайплайнів)
    GENETIC = "genetic"  # Генетичний алгоритм (для складних пайплайнів)


def optimize_pipeline(
    pipeline: Lens,
    sample_data: Optional[Any] = None,
    target: str = "speed",
    enable_profiling: bool = False,
    algorithm: str = "heuristic",
    max_permutations: int = 10000,
) -> Lens:
    """
    Оптимізує порядок трансформацій у пайплайні.
    
    Підтримує кілька алгоритмів оптимізації:
    - heuristic: Швидка евристична оптимізація (за замовчуванням)
    - dp: Dynamic Programming для оптимального рішення
    - exhaustive: Повний перебір всіх можливих порядків
    - genetic: Генетичний алгоритм для складних пайплайнів
    
    Args:
        pipeline: Пайплайн для оптимізації
        sample_data: Тестові дані для профілювання (опціонально)
        target: Ціль оптимізації - "speed" (швидкість) або "memory" (пам'ять)
        enable_profiling: Чи використовувати профілювання для вимірювання витрат
        algorithm: Алгоритм оптимізації - "heuristic", "dp", "exhaustive", "genetic"
        max_permutations: Максимальна кількість перестановок для exhaustive/genetic
        
    Returns:
        Оптимізований пайплайн
        
    Example:
        >>> from mimir_io.optimization import optimize_pipeline
        >>> from mimir_io.audio import resample, normalize, log_mel_spectrogram
        >>> 
        >>> # Створюємо пайплайн
        >>> original = normalize() | resample(16000) | log_mel_spectrogram(16000)
        >>> 
        >>> # Оптимізуємо з евристикою (швидко)
        >>> optimized = optimize_pipeline(original, algorithm="heuristic")
        >>> 
        >>> # Або з Dynamic Programming (оптимально)
        >>> optimized = optimize_pipeline(original, algorithm="dp", enable_profiling=True)
    """
    # Розбиваємо пайплайн на окремі трансформації
    transformations = _decompose_pipeline(pipeline)
    
    if len(transformations) <= 1:
        # Немає що оптимізувати
        return pipeline
    
    # Профілювання (якщо увімкнено та є тестові дані)
    cost_map: Dict[str, float] = {}
    if enable_profiling and sample_data is not None:
        cost_map = _profile_transformations(transformations, sample_data)
    
    # Вибираємо алгоритм оптимізації
    algorithm_lower = algorithm.lower()
    
    if algorithm_lower == "dp":
        optimized = _optimize_dp(transformations, cost_map, sample_data)
    elif algorithm_lower == "exhaustive":
        optimized = _optimize_exhaustive(transformations, cost_map, sample_data, max_permutations)
    elif algorithm_lower == "genetic":
        optimized = _optimize_genetic(transformations, cost_map, sample_data, max_permutations)
    else:
        # Default: heuristic
        optimized = _optimize_heuristic(transformations, cost_map)
    
    # Перекомпозуємо пайплайн
    if len(optimized) == 0:
        return pipeline
    
    result = optimized[0]
    for trans in optimized[1:]:
        result = compose(result, trans)
    
    return result


def _optimize_heuristic(
    transformations: List[Lens],
    cost_map: Dict[str, float],
) -> List[Lens]:
    """
    Евристична оптимізація (швидка, але не завжди оптимальна).
    
    Args:
        transformations: Список трансформацій
        cost_map: Словник з витратами (якщо є профілювання)
        
    Returns:
        Оптимізований список трансформацій
    """
    # Групуємо за типами
    groups = _group_by_type(transformations)
    
    # Отримуємо порядок залежностей
    dependency_order = _get_dependency_order()
    
    # Будуємо оптимізований список
    optimized: List[Lens] = []
    
    for trans_type in dependency_order:
        if trans_type in groups:
            # Оптимізуємо всередині категорії
            category_transforms = groups[trans_type]
            
            # Якщо є профілювання, сортуємо за реальними витратами
            if cost_map:
                category_transforms.sort(
                    key=lambda t: cost_map.get(t._name, float('inf'))
                )
            else:
                # Інакше використовуємо евристику
                category_transforms = _optimize_within_category(category_transforms)
            
            optimized.extend(category_transforms)
    
    return optimized


def _optimize_dp(
    transformations: List[Lens],
    cost_map: Dict[str, float],
    sample_data: Optional[Any],
) -> List[Lens]:
    """
    Dynamic Programming оптимізація для знаходження оптимального порядку.
    
    Використовує DP для знаходження порядку з мінімальними витратами.
    Працює добре для пайплайнів до ~10 трансформацій.
    
    Args:
        transformations: Список трансформацій
        cost_map: Словник з витратами
        sample_data: Тестові дані для вимірювання витрат
        
    Returns:
        Оптимізований список трансформацій
    """
    n = len(transformations)
    
    # Для великих пайплайнів використовуємо евристику
    if n > 12:
        return _optimize_heuristic(transformations, cost_map)
    
    # Отримуємо витрати для кожної трансформації
    if not cost_map and sample_data is not None:
        cost_map = _profile_transformations(transformations, sample_data)
    
    # Якщо немає витрат, використовуємо евристику
    if not cost_map:
        return _optimize_heuristic(transformations, cost_map)
    
    # Будуємо граф залежностей
    dependency_graph = _build_dependency_graph(transformations)
    
    # DP: dp[mask] = (min_cost, last_transformation)
    # mask - бітова маска виконаних трансформацій
    dp: Dict[int, Tuple[float, Optional[int]]] = {0: (0.0, None)}
    
    # Перебираємо всі можливі стани
    for mask in range(1, 1 << n):
        min_cost = float('inf')
        best_last = None
        
        # Перебираємо всі можливі останні трансформації
        for i in range(n):
            if not (mask & (1 << i)):
                continue
            
            # Перевіряємо залежності
            if not _can_execute(i, mask ^ (1 << i), dependency_graph):
                continue
            
            # Обчислюємо витрати
            prev_mask = mask ^ (1 << i)
            if prev_mask not in dp:
                continue
            
            prev_cost, _ = dp[prev_mask]
            trans_cost = cost_map.get(transformations[i]._name, float('inf'))
            
            total_cost = prev_cost + trans_cost
            
            if total_cost < min_cost:
                min_cost = total_cost
                best_last = i
        
        if best_last is not None:
            dp[mask] = (min_cost, best_last)
    
    # Відновлюємо оптимальний порядок
    if (1 << n) - 1 not in dp:
        # Якщо не знайдено рішення, використовуємо евристику
        return _optimize_heuristic(transformations, cost_map)
    
    # Відновлюємо порядок з кінця
    order: List[int] = []
    mask = (1 << n) - 1
    
    while mask > 0:
        if mask not in dp:
            break
        _, last = dp[mask]
        if last is None:
            break
        order.append(last)
        mask ^= (1 << last)
    
    order.reverse()
    
    # Перевіряємо, чи всі трансформації включені
    if len(order) != n:
        return _optimize_heuristic(transformations, cost_map)
    
    return [transformations[i] for i in order]


def _optimize_exhaustive(
    transformations: List[Lens],
    cost_map: Dict[str, float],
    sample_data: Optional[Any],
    max_permutations: int,
) -> List[Lens]:
    """
    Повний перебір всіх можливих порядків.
    
    Працює тільки для дуже малих пайплайнів (до 7-8 трансформацій).
    
    Args:
        transformations: Список трансформацій
        cost_map: Словник з витратами
        sample_data: Тестові дані для вимірювання витрат
        max_permutations: Максимальна кількість перестановок
        
    Returns:
        Оптимізований список трансформацій
    """
    n = len(transformations)
    
    # Для великих пайплайнів використовуємо інший алгоритм
    # Перевіряємо кількість перестановок (n!)
    import math
    num_permutations = math.factorial(n) if n <= 10 else float('inf')
    
    if n > 8 or num_permutations > max_permutations:
        return _optimize_heuristic(transformations, cost_map)
    
    # Отримуємо витрати
    if not cost_map and sample_data is not None:
        cost_map = _profile_transformations(transformations, sample_data)
    
    # Будуємо граф залежностей
    dependency_graph = _build_dependency_graph(transformations)
    
    # Перебираємо всі можливі порядки
    best_order: Optional[List[int]] = None
    best_cost = float('inf')
    
    for perm in itertools.permutations(range(n)):
        # Перевіряємо залежності
        if not _is_valid_order(perm, dependency_graph):
            continue
        
        # Обчислюємо загальні витрати
        total_cost = sum(cost_map.get(transformations[i]._name, float('inf')) for i in perm)
        
        if total_cost < best_cost:
            best_cost = total_cost
            best_order = list(perm)
    
    if best_order is None:
        return _optimize_heuristic(transformations, cost_map)
    
    return [transformations[i] for i in best_order]


def _optimize_genetic(
    transformations: List[Lens],
    cost_map: Dict[str, float],
    sample_data: Optional[Any],
    max_permutations: int,
) -> List[Lens]:
    """
    Генетичний алгоритм для оптимізації порядку.
    
    Використовується для складних пайплайнів, де повний перебір неможливий.
    
    Args:
        transformations: Список трансформацій
        cost_map: Словник з витратами
        sample_data: Тестові дані для вимірювання витрат
        max_permutations: Максимальна кількість оцінок
        
    Returns:
        Оптимізований список трансформацій
    """
    n = len(transformations)
    
    # Отримуємо витрати
    if not cost_map and sample_data is not None:
        cost_map = _profile_transformations(transformations, sample_data)
    
    # Будуємо граф залежностей
    dependency_graph = _build_dependency_graph(transformations)
    
    # Параметри генетичного алгоритму
    population_size = min(50, max(10, n * 5))
    generations = min(100, max_permutations // population_size)
    mutation_rate = 0.1
    crossover_rate = 0.7
    
    # Створюємо початкову популяцію
    population: List[List[int]] = []
    for _ in range(population_size):
        order = list(range(n))
        random.shuffle(order)
        # Виправляємо порядок з урахуванням залежностей
        order = _fix_order_dependencies(order, dependency_graph)
        population.append(order)
    
    # Оцінюємо початкову популяцію
    def evaluate(order: List[int]) -> float:
        if not _is_valid_order(order, dependency_graph):
            return float('inf')
        return sum(cost_map.get(transformations[i]._name, float('inf')) for i in order)
    
    # Основний цикл генетичного алгоритму
    for generation in range(generations):
        # Оцінюємо популяцію
        fitness = [(evaluate(order), order) for order in population]
        fitness.sort(key=lambda x: x[0])
        
        # Відбираємо найкращих
        elite_size = population_size // 4
        elite = [order for _, order in fitness[:elite_size]]
        
        # Створюємо нову популяцію
        new_population = elite.copy()
        
        while len(new_population) < population_size:
            # Вибір батьків (турнірний відбір)
            parent1 = _tournament_selection(fitness, tournament_size=3)[1]
            parent2 = _tournament_selection(fitness, tournament_size=3)[1]
            
            # Кросовер
            if random.random() < crossover_rate:
                child = _order_crossover(parent1, parent2, dependency_graph)
            else:
                child = parent1.copy()
            
            # Мутація
            if random.random() < mutation_rate:
                child = _mutate_order(child, dependency_graph)
            
            new_population.append(child)
        
        population = new_population
    
    # Повертаємо найкращий результат
    fitness = [(evaluate(order), order) for order in population]
    fitness.sort(key=lambda x: x[0])
    
    best_order = fitness[0][1]
    return [transformations[i] for i in best_order]


def _build_dependency_graph(transformations: List[Lens]) -> Dict[int, Set[int]]:
    """
    Будує граф залежностей між трансформаціями.
    
    Args:
        transformations: Список трансформацій
        
    Returns:
        Словник: трансформація -> множина залежних трансформацій
    """
    n = len(transformations)
    graph: Dict[int, Set[int]] = {i: set() for i in range(n)}
    
    # Отримуємо типи трансформацій
    types = [_classify_transformation(t._name)[0] for t in transformations]
    dependency_order = _get_dependency_order()
    
    # Додаємо залежності на основі типів
    for i in range(n):
        type_i = types[i]
        idx_i = dependency_order.index(type_i) if type_i in dependency_order else len(dependency_order)
        
        for j in range(n):
            if i == j:
                continue
            type_j = types[j]
            idx_j = dependency_order.index(type_j) if type_j in dependency_order else len(dependency_order)
            
            # Якщо j має виконуватися після i
            if idx_j < idx_i:
                graph[j].add(i)
    
    return graph


def _can_execute(trans_idx: int, executed_mask: int, dependency_graph: Dict[int, Set[int]]) -> bool:
    """Перевіряє, чи можна виконати трансформацію після виконаних."""
    required = dependency_graph.get(trans_idx, set())
    for req in required:
        if not (executed_mask & (1 << req)):
            return False
    return True


def _is_valid_order(order: List[int], dependency_graph: Dict[int, Set[int]]) -> bool:
    """Перевіряє, чи порядок задовольняє залежності."""
    executed = set()
    for trans_idx in order:
        required = dependency_graph.get(trans_idx, set())
        if not required.issubset(executed):
            return False
        executed.add(trans_idx)
    return True


def _fix_order_dependencies(order: List[int], dependency_graph: Dict[int, Set[int]]) -> List[int]:
    """Виправляє порядок з урахуванням залежностей."""
    result: List[int] = []
    remaining = set(order)
    
    while remaining:
        # Знаходимо трансформації, які можна виконати
        available = [
            idx for idx in remaining
            if dependency_graph.get(idx, set()).issubset(set(result))
        ]
        
        if not available:
            # Якщо немає доступних, додаємо першу з решти
            available = [next(iter(remaining))]
        
        # Додаємо випадкову доступну трансформацію
        chosen = random.choice(available)
        result.append(chosen)
        remaining.remove(chosen)
    
    return result


def _tournament_selection(fitness: List[Tuple[float, List[int]]], tournament_size: int) -> Tuple[float, List[int]]:
    """Турнірний відбір для генетичного алгоритму."""
    tournament = random.sample(fitness, min(tournament_size, len(fitness)))
    tournament.sort(key=lambda x: x[0])
    return tournament[0]


def _order_crossover(parent1: List[int], parent2: List[int], dependency_graph: Dict[int, Set[int]]) -> List[int]:
    """Кросовер порядку для генетичного алгоритму."""
    n = len(parent1)
    start = random.randint(0, n - 1)
    end = random.randint(start, n)
    
    # Беремо сегмент з першого батька
    child = parent1[start:end]
    
    # Додаємо решту з другого батька в порядку появи
    remaining = [x for x in parent2 if x not in child]
    child = child + remaining
    
    # Виправляємо залежності
    return _fix_order_dependencies(child, dependency_graph)


def _mutate_order(order: List[int], dependency_graph: Dict[int, Set[int]]) -> List[int]:
    """Мутація порядку для генетичного алгоритму."""
    n = len(order)
    if n < 2:
        return order
    
    # Обмінюємо два елементи
    i, j = random.sample(range(n), 2)
    new_order = order.copy()
    new_order[i], new_order[j] = new_order[j], new_order[i]
    
    # Виправляємо залежності
    return _fix_order_dependencies(new_order, dependency_graph)


def _profile_transformations(
    transformations: List[Lens],
    sample_data: Any,
    num_runs: int = 3,
) -> Dict[str, float]:
    """
    Профілює трансформації для вимірювання реальних витрат.
    
    Застосовує трансформації послідовно, вимірюючи час кожної окремо.
    
    Args:
        transformations: Список трансформацій
        sample_data: Тестові дані
        num_runs: Кількість запусків для усереднення
        
    Returns:
        Словник назва -> середній час виконання
    """
    cost_map: Dict[str, float] = {}
    
    # Застосовуємо трансформації послідовно, вимірюючи кожну окремо
    for trans in transformations:
        times = []
        
        for _ in range(num_runs):
            try:
                # Застосовуємо всі попередні трансформації для отримання правильних даних
                current_data = sample_data
                for prev_trans in transformations:
                    if prev_trans == trans:
                        break
                    current_data = prev_trans(current_data)
                
                # Вимірюємо час поточної трансформації
                start = time.perf_counter()
                result = trans(current_data)
                end = time.perf_counter()
                times.append(end - start)
            except Exception:
                # Якщо трансформація не може бути виконана, пропускаємо
                times.append(float('inf'))
                break
        
        if times:
            cost_map[trans._name] = sum(times) / len(times)
    
    return cost_map


def analyze_pipeline(pipeline: Lens) -> Dict[str, Any]:
    """
    Аналізує пайплайн та повертає інформацію про його структуру.
    
    Args:
        pipeline: Пайплайн для аналізу
        
    Returns:
        Словник з інформацією про пайплайн
    """
    transformations = _decompose_pipeline(pipeline)
    
    analysis = {
        "total_transformations": len(transformations),
        "transformations": [],
        "type_distribution": {},
    }
    
    for trans in transformations:
        trans_type, cost = _classify_transformation(trans._name)
        should_cache = getattr(trans, '_should_cache', True)
        
        trans_info = {
            "name": trans._name,
            "type": trans_type.value,
            "cost": cost.value,
            "cached": should_cache,
        }
        
        analysis["transformations"].append(trans_info)
        
        # Підрахунок розподілу типів
        type_name = trans_type.value
        analysis["type_distribution"][type_name] = (
            analysis["type_distribution"].get(type_name, 0) + 1
        )
    
    return analysis

