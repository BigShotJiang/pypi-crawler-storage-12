"""
Random seed management for deterministic augmentations.
"""

import torch
from typing import Optional
from contextlib import contextmanager


_global_seed: Optional[int] = None


def set_global_seed(seed: Optional[int]) -> None:
    """
    Set global random seed for all augmentations.

    Args:
        seed: Random seed value. If None, disables global seed.
    """
    global _global_seed
    _global_seed = seed
    if seed is not None:
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)


def get_global_seed() -> Optional[int]:
    """
    Get current global random seed.

    Returns:
        Current global seed or None if not set
    """
    return _global_seed


def clear_global_seed() -> None:
    """Clear global random seed."""
    set_global_seed(None)


@contextmanager
def seed_context(seed: Optional[int]):
    """
    Context manager for temporary seed setting.

    Args:
        seed: Random seed to use within context

    Example:
        with seed_context(42):
            augmented = lens(waveform)  # Uses seed 42
        # Seed restored after context
    """
    global _global_seed
    old_seed = _global_seed
    old_cpu_state = torch.get_rng_state()
    old_cuda_states = None
    
    if torch.cuda.is_available():
        old_cuda_states = torch.cuda.get_rng_state_all()
    
    try:
        set_global_seed(seed)
        yield
    finally:
        _global_seed = old_seed
        torch.set_rng_state(old_cpu_state)
        if old_cuda_states is not None:
            torch.cuda.set_rng_state_all(old_cuda_states)


def get_seed(seed: Optional[int] = None) -> Optional[int]:
    """
    Get seed to use, preferring provided seed over global seed.

    Args:
        seed: Optional explicit seed value

    Returns:
        Seed to use (explicit seed or global seed)
    """
    return seed if seed is not None else _global_seed


def create_generator(seed: Optional[int] = None) -> torch.Generator:
    """
    Create a PyTorch generator with specified or global seed.

    Args:
        seed: Optional explicit seed. If None, uses global seed or creates random.

    Returns:
        PyTorch Generator instance
    """
    gen = torch.Generator()
    actual_seed = get_seed(seed)
    if actual_seed is not None:
        gen.manual_seed(actual_seed)
    return gen

