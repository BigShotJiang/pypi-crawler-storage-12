"""
Cache formats for different data types.
Supports compressed formats (WAV, PNG) instead of pickle to save disk space.
"""

from pathlib import Path
from typing import Any, Optional, Tuple, Dict
import json
import pickle
import torch
import numpy as np
from mimir_io.rayframe.audio_frame import AudioRayFrame
from mimir_io.rayframe.image_frame import ImageRayFrame


class CacheFormat:
    """Base class for cache formats."""
    
    @staticmethod
    def can_handle(data: Any) -> bool:
        """Checks if the format can handle the data."""
        raise NotImplementedError
    
    @staticmethod
    def save(data: Any, data_path: Path, meta_path: Path) -> None:
        """Saves data in the format."""
        raise NotImplementedError
    
    @staticmethod
    def load(data_path: Path, meta_path: Path) -> Any:
        """Loads data from the format."""
        raise NotImplementedError
    
    @staticmethod
    def get_extension() -> str:
        """Returns the file extension for the format."""
        raise NotImplementedError


class AudioWAVFormat(CacheFormat):
    """Cache format for AudioRayFrame in WAV format."""
    
    @staticmethod
    def can_handle(data: Any) -> bool:
        """Checks if this is an AudioRayFrame."""
        return isinstance(data, AudioRayFrame)
    
    @staticmethod
    def save(data: AudioRayFrame, data_path: Path, meta_path: Path) -> None:
        """Saves audio in WAV format and metadata in JSON."""
        try:
            import soundfile as sf
        except ImportError:
            raise ImportError(
                "soundfile is required for WAV cache format. "
                "Install with: pip install soundfile"
            )
        
        # Convert tensor to numpy array
        waveform = data.data
        if waveform.dim() == 1:
            waveform_np = waveform.numpy()
        elif waveform.dim() == 2:
            # If (C, T), take first channel or convert to mono
            if waveform.shape[0] == 1:
                waveform_np = waveform[0].numpy()
            else:
                # Convert to mono (mean value)
                waveform_np = waveform.mean(dim=0).numpy()
        else:
            raise ValueError(f"Unexpected waveform shape: {waveform.shape}")
        
        # Save as 32-bit float WAV (preserves quality)
        sf.write(str(data_path), waveform_np, data.sample_rate, subtype='FLOAT')
        
        # Save metadata in JSON
        metadata = {
            "sample_rate": data.sample_rate,
            "channels": data.channels,
            "duration": data.duration,
            "metadata": data.metadata,
            "shape": list(data.data.shape),
            "dtype": str(data.data.dtype),
        }
        with open(meta_path, "w") as f:
            json.dump(metadata, f, indent=2)
    
    @staticmethod
    def load(data_path: Path, meta_path: Path) -> AudioRayFrame:
        """Loads audio from WAV file and restores AudioRayFrame."""
        try:
            import soundfile as sf
        except ImportError:
            raise ImportError(
                "soundfile is required for WAV cache format. "
                "Install with: pip install soundfile"
            )
        
        # Load audio
        waveform_np, sample_rate = sf.read(str(data_path), dtype='float32')
        waveform = torch.from_numpy(waveform_np)
        
        # Load metadata
        with open(meta_path, "r") as f:
            metadata = json.load(f)
        
        # Restore shape if needed
        if len(waveform.shape) == 1 and metadata.get("channels", 1) > 1:
            # If original shape was (C, T) but saved as mono
            waveform = waveform.unsqueeze(0)
        
        return AudioRayFrame(
            data=waveform,
            sample_rate=metadata["sample_rate"],
            channels=metadata.get("channels", 1),
            duration=metadata.get("duration"),
            metadata=metadata.get("metadata", {}),
        )
    
    @staticmethod
    def get_extension() -> str:
        return ".wav"


class ImagePNGFormat(CacheFormat):
    """Cache format for ImageRayFrame in PNG format."""
    
    @staticmethod
    def can_handle(data: Any) -> bool:
        """Checks if this is an ImageRayFrame."""
        return isinstance(data, ImageRayFrame)
    
    @staticmethod
    def save(data: ImageRayFrame, data_path: Path, meta_path: Path) -> None:
        """Saves image in PNG format and metadata in JSON."""
        try:
            from PIL import Image
        except ImportError:
            raise ImportError(
                "Pillow is required for PNG cache format. "
                "Install with: pip install pillow"
            )
        
        # Convert tensor to numpy array
        img_tensor = data.data
        
        # If channel dimension exists, take first channel or convert
        if img_tensor.dim() == 3:
            if img_tensor.shape[0] == 1:
                img_array = img_tensor[0].numpy()
            else:
                # For multi-channel images, take first channel
                # (or could convert to grayscale)
                img_array = img_tensor[0].numpy()
        elif img_tensor.dim() == 2:
            img_array = img_tensor.numpy()
        else:
            raise ValueError(f"Unexpected image shape: {img_tensor.shape}")
        
        # Normalize to 0-255
        img_min = img_array.min()
        img_max = img_array.max()
        if img_max > img_min:
            img_normalized = ((img_array - img_min) / (img_max - img_min) * 255).astype(np.uint8)
        else:
            img_normalized = np.zeros_like(img_array, dtype=np.uint8)
        
        # Save as PNG
        img = Image.fromarray(img_normalized, mode='L')
        img.save(data_path, optimize=True)
        
        # Save metadata in JSON (including min/max for restoration)
        metadata = {
            "channels": data.channels,
            "height": data.height,
            "width": data.width,
            "sample_rate": data.sample_rate,
            "metadata": data.metadata,
            "shape": list(data.data.shape),
            "dtype": str(data.data.dtype),
            "value_range": {
                "min": float(img_min),
                "max": float(img_max),
            },
        }
        with open(meta_path, "w") as f:
            json.dump(metadata, f, indent=2)
    
    @staticmethod
    def load(data_path: Path, meta_path: Path) -> ImageRayFrame:
        """Loads image from PNG file and restores ImageRayFrame."""
        try:
            from PIL import Image
        except ImportError:
            raise ImportError(
                "Pillow is required for PNG cache format. "
                "Install with: pip install pillow"
            )
        
        # Load image
        img = Image.open(data_path)
        img_array = np.array(img, dtype=np.float32)
        
        # Load metadata
        with open(meta_path, "r") as f:
            metadata = json.load(f)
        
        # Restore original value range
        value_range = metadata.get("value_range", {})
        img_min = value_range.get("min", 0.0)
        img_max = value_range.get("max", 255.0)
        
        if img_max > img_min:
            img_array = (img_array / 255.0) * (img_max - img_min) + img_min
        
        # Convert to tensor
        img_tensor = torch.from_numpy(img_array)
        
        # Add channel dimension if needed
        if img_tensor.dim() == 2:
            img_tensor = img_tensor.unsqueeze(0)
        
        return ImageRayFrame(
            data=img_tensor,
            channels=metadata.get("channels", 1),
            height=metadata.get("height"),
            width=metadata.get("width"),
            sample_rate=metadata.get("sample_rate"),
            metadata=metadata.get("metadata", {}),
        )
    
    @staticmethod
    def get_extension() -> str:
        return ".png"


class PickleFormat(CacheFormat):
    """Default cache format (pickle) for other data types."""
    
    @staticmethod
    def can_handle(data: Any) -> bool:
        """Pickle can handle any data."""
        return True
    
    @staticmethod
    def save(data: Any, data_path: Path, meta_path: Path) -> None:
        """Saves data in pickle format."""
        with open(data_path, "wb") as f:
            pickle.dump(data, f)
        # Create empty meta file for consistency
        meta_path.touch()
    
    @staticmethod
    def load(data_path: Path, meta_path: Path) -> Any:
        """Loads data from pickle file."""
        with open(data_path, "rb") as f:
            return pickle.load(f)
    
    @staticmethod
    def get_extension() -> str:
        return ".pkl"


# Format registry (order matters - checked from top to bottom)
CACHE_FORMATS = [
    AudioWAVFormat,
    ImagePNGFormat,
    PickleFormat,  # Always last as fallback
]


def get_cache_format(data: Any):
    """Gets the appropriate cache format class for the data."""
    for fmt_class in CACHE_FORMATS:
        if fmt_class.can_handle(data):
            return fmt_class
    # Fallback to pickle
    return PickleFormat


def save_cached_data(data: Any, cache_path: Path) -> None:
    """
    Saves data to cache in the appropriate format.
    
    Args:
        data: Data to save
        cache_path: Base path for cache (without extension)
    """
    fmt_class = get_cache_format(data)
    data_path = cache_path.with_suffix(fmt_class.get_extension())
    meta_path = cache_path.with_suffix(fmt_class.get_extension() + ".meta.json")
    
    fmt_class.save(data, data_path, meta_path)


def load_cached_data(cache_path: Path) -> Any:
    """
    Loads data from cache, automatically detecting the format.
    
    Args:
        cache_path: Base path for cache (without extension)
    
    Returns:
        Loaded data
    
    Raises:
        FileNotFoundError: If cache file is not found
    """
    # Check all possible formats
    for fmt_class in CACHE_FORMATS:
        data_path = cache_path.with_suffix(fmt_class.get_extension())
        meta_path = cache_path.with_suffix(fmt_class.get_extension() + ".meta.json")
        
        if data_path.exists():
            return fmt_class.load(data_path, meta_path)
    
    raise FileNotFoundError(f"Cache file not found: {cache_path}")


def cache_exists(cache_path: Path) -> bool:
    """
    Checks if cache exists for the given path.
    
    Args:
        cache_path: Base path for cache (without extension)
    
    Returns:
        True if cache exists, False otherwise
    """
    for fmt_class in CACHE_FORMATS:
        data_path = cache_path.with_suffix(fmt_class.get_extension())
        if data_path.exists():
            return True
    return False

