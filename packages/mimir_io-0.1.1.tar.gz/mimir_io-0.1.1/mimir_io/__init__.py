"""
Mimir IO - End-to-end ML workflow framework.

This library provides:
- Declarative dataset processing with lens-based transformations
- Automatic caching and backend compatibility layers
- Built-in training infrastructure (BaseTrainer, quick_train)
- Model management and experiment setup
- Minimal boilerplate for ML experiments
"""

from mimir_io.lens import Lens, compose, identity
from mimir_io.dataset import Dataset
from mimir_io.backends import get_backend, set_backend, Backend
from mimir_io.rayframe import RayFrame, ImageRayFrame, AudioRayFrame, MelRayFrame
from mimir_io.random import (
    set_global_seed,
    get_global_seed,
    clear_global_seed,
    seed_context,
    get_seed,
    create_generator,
)
from mimir_io.split import (
    DatasetSplit,
    split_dataset,
    split_by_directory,
    split_by_metadata,
    load_from_class_directories,
    split_by_class_directories,
)

# PyTorch integration (optional, requires torch)
try:
    from mimir_io.torch_dataset import (
        MimirTorchDataset,
        MimirTorchDatasetWithAugmentation,
        create_dataloader,
    )
    _torch_available = True
except ImportError:
    _torch_available = False

# Streaming Dataset (optional, requires torch)
try:
    from mimir_io.streaming import (
        StreamingDataset,
        create_streaming_dataloader,
        PrefetchStats,
    )
    _streaming_available = True
except ImportError:
    _streaming_available = False

__version__ = "0.1.0"
__all__ = [
    "Lens",
    "compose",
    "identity",
    "Dataset",
    "get_backend",
    "set_backend",
    "Backend",
    "RayFrame",
    "ImageRayFrame",
    "AudioRayFrame",
    "MelRayFrame",
    "set_global_seed",
    "get_global_seed",
    "clear_global_seed",
    "seed_context",
    "get_seed",
    "create_generator",
    "DatasetSplit",
    "split_dataset",
    "split_by_directory",
    "split_by_metadata",
    "load_from_class_directories",
    "split_by_class_directories",
]

# Add PyTorch integration if available
if _torch_available:
    __all__.extend([
        "MimirTorchDataset",
        "MimirTorchDatasetWithAugmentation",
        "create_dataloader",
    ])

# Add Streaming Dataset if available
if _streaming_available:
    __all__.extend([
        "StreamingDataset",
        "create_streaming_dataloader",
        "PrefetchStats",
    ])

# Model management (optional, requires torch)
try:
    from mimir_io.models import (
        register_model,
        create_model,
        get_model,
        list_models,
        has_model,
        load_config,
        save_config,
        BaseTrainer,
        BaseTester,
    )
    _models_available = True
except ImportError:
    _models_available = False

if _models_available:
    __all__.extend([
        "register_model",
        "create_model",
        "get_model",
        "list_models",
        "has_model",
        "load_config",
        "save_config",
        "BaseTrainer",
        "BaseTester",
    ])

# Pipeline registry (optional, requires lens)
try:
    from mimir_io.pipeline_registry import (
        register_pipeline,
        create_pipeline,
        get_pipeline_factory,
        list_pipelines,
        has_pipeline,
        PipelineRegistry,
    )
    _pipeline_registry_available = True
except ImportError:
    _pipeline_registry_available = False

if _pipeline_registry_available:
    __all__.extend([
        "register_pipeline",
        "create_pipeline",
        "get_pipeline_factory",
        "list_pipelines",
        "has_pipeline",
        "PipelineRegistry",
    ])

# Experiment setup (optional, requires torch)
try:
    from mimir_io.experiment import (
        ExperimentConfig,
        setup_experiment,
        quick_train,
        train_from_config_file,
        setup_test,
        quick_test,
    )
    _experiment_available = True
except ImportError:
    _experiment_available = False

if _experiment_available:
    __all__.extend([
        "ExperimentConfig",
        "setup_experiment",
        "quick_train",
        "train_from_config_file",
        "setup_test",
        "quick_test",
        "find_experiment_files",
    ])

# PyTorch Lightning integration (optional, requires pytorch-lightning)
try:
    from mimir_io.lightning import MimirDataModule
    _lightning_available = True
except ImportError:
    _lightning_available = False

if _lightning_available:
    __all__.extend([
        "MimirDataModule",
    ])

# Profiling (optional)
try:
    from mimir_io.profiling import (
        PipelineProfiler,
        profile_pipeline,
        print_profile_report,
        generate_html_report,
        generate_recommendations,
    )
    _profiling_available = True
except ImportError:
    _profiling_available = False

if _profiling_available:
    __all__.extend([
        "PipelineProfiler",
        "profile_pipeline",
        "print_profile_report",
        "generate_html_report",
        "generate_recommendations",
    ])

# Async loading (optional, requires torch)
try:
    from mimir_io.async_loader import (
        AsyncAudioLoader,
        get_default_loader,
        reset_default_loader,
    )
    _async_loader_available = True
except ImportError:
    _async_loader_available = False

if _async_loader_available:
    __all__.extend([
        "AsyncAudioLoader",
        "get_default_loader",
        "reset_default_loader",
    ])

# Cache index (always available)
from mimir_io.cache_index import CacheIndex
__all__.append("CacheIndex")

# Visualization (optional, requires graphviz or matplotlib)
try:
    from mimir_io.visualization import visualize_pipeline
    _visualization_available = True
except ImportError:
    _visualization_available = False

if _visualization_available:
    __all__.append("visualize_pipeline")

# Optimization (always available)
try:
    from mimir_io.optimization import (
        optimize_pipeline,
        analyze_pipeline,
        TransformationType,
        TransformationCost,
        OptimizationAlgorithm,
    )
    _optimization_available = True
except ImportError:
    _optimization_available = False

if _optimization_available:
    __all__.extend([
        "optimize_pipeline",
        "analyze_pipeline",
        "TransformationType",
        "TransformationCost",
        "OptimizationAlgorithm",
    ])

