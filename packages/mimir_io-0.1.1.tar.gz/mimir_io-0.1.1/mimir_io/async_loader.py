"""
Asynchronous audio loading for improved I/O performance.

This module provides async loading capabilities for audio files,
allowing parallel I/O operations without blocking.
"""

from pathlib import Path
from typing import Optional, Tuple, List, Union
from concurrent.futures import ThreadPoolExecutor
import asyncio

try:
    import torch
    import torchaudio
    _torch_available = True
except ImportError:
    _torch_available = False
    torch = None  # type: ignore
    torchaudio = None  # type: ignore

from mimir_io.audio.load import _load_audio_file, _get_backend_for_format, _get_audio_format


class AsyncAudioLoader:
    """
    Asynchronous audio loader using ThreadPoolExecutor for I/O-bound operations.
    
    This allows loading multiple audio files in parallel without blocking
    the main thread, significantly improving performance for batch operations.
    """
    
    def __init__(self, max_workers: int = 4):
        """
        Initialize async audio loader.
        
        Args:
            max_workers: Maximum number of worker threads for parallel loading
        """
        if not _torch_available:
            raise ImportError("PyTorch and torchaudio are required for async loading")
        
        self.max_workers = max_workers
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
    
    async def load_audio_async(
        self, 
        path: Union[str, Path], 
        backend: Optional[str] = None
    ) -> Tuple[torch.Tensor, int]:
        """
        Load audio file asynchronously.
        
        Args:
            path: Path to audio file
            backend: Optional backend name
            
        Returns:
            Tuple of (waveform, sample_rate)
        """
        path = Path(path)
        loop = asyncio.get_event_loop()
        
        # Run blocking I/O operation in thread pool
        waveform, sample_rate = await loop.run_in_executor(
            self.executor,
            _load_audio_file,
            path,
            backend
        )
        
        return waveform, int(sample_rate)
    
    async def load_audio_batch_async(
        self,
        paths: List[Union[str, Path]],
        backend: Optional[str] = None,
    ) -> List[Tuple[torch.Tensor, int]]:
        """
        Load multiple audio files asynchronously in parallel.
        
        Args:
            paths: List of paths to audio files
            backend: Optional backend name
            
        Returns:
            List of tuples (waveform, sample_rate)
        """
        # Create tasks for all files
        tasks = [
            self.load_audio_async(path, backend)
            for path in paths
        ]
        
        # Wait for all tasks to complete
        results = await asyncio.gather(*tasks)
        return results
    
    def load_audio_batch_sync(
        self,
        paths: List[Union[str, Path]],
        backend: Optional[str] = None,
    ) -> List[Tuple[torch.Tensor, int]]:
        """
        Load multiple audio files in parallel using ThreadPoolExecutor (synchronous API).
        
        This is a convenience method that doesn't require async/await.
        
        Args:
            paths: List of paths to audio files
            backend: Optional backend name
            
        Returns:
            List of tuples (waveform, sample_rate)
        """
        if not _torch_available:
            raise ImportError("PyTorch and torchaudio are required")
        
        # Submit all tasks
        futures = [
            self.executor.submit(_load_audio_file, Path(path), backend)
            for path in paths
        ]
        
        # Collect results
        results = []
        for future in futures:
            waveform, sample_rate = future.result()
            results.append((waveform, int(sample_rate)))
        
        return results
    
    def shutdown(self, wait: bool = True) -> None:
        """
        Shutdown the executor.
        
        Args:
            wait: If True, wait for all pending tasks to complete
        """
        self.executor.shutdown(wait=wait)
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.shutdown(wait=True)


# Global instance for convenience (optional)
_default_loader: Optional[AsyncAudioLoader] = None


def get_default_loader() -> AsyncAudioLoader:
    """Get or create default async audio loader."""
    global _default_loader
    if _default_loader is None:
        _default_loader = AsyncAudioLoader()
    return _default_loader


def reset_default_loader() -> None:
    """Reset the default loader (useful for testing)."""
    global _default_loader
    if _default_loader is not None:
        _default_loader.shutdown()
        _default_loader = None


