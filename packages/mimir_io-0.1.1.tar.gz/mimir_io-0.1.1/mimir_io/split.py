"""
Dataset splitting utilities for train/validation/test splits.

Provides various strategies for splitting datasets while maintaining
reproducibility and supporting different use cases.
"""

from typing import List, Tuple, Optional, Union, Dict, Any
from pathlib import Path
import json
import hashlib

try:
    from sklearn.model_selection import train_test_split, StratifiedShuffleSplit
    _sklearn_available = True
except ImportError:
    _sklearn_available = False

from mimir_io.random import get_seed, create_generator


class DatasetSplit:
    """
    Container for dataset splits.
    
    Stores file paths and labels for train, validation, and test sets.
    """
    
    def __init__(
        self,
        train_files: List[Union[str, Path]],
        val_files: List[Union[str, Path]],
        test_files: Optional[List[Union[str, Path]]] = None,
        train_labels: Optional[List[Any]] = None,
        val_labels: Optional[List[Any]] = None,
        test_labels: Optional[List[Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize dataset split.
        
        Args:
            train_files: List of file paths for training set
            val_files: List of file paths for validation set
            test_files: Optional list of file paths for test set
            train_labels: Optional labels for training set
            val_labels: Optional labels for validation set
            test_labels: Optional labels for test set
            metadata: Optional metadata about the split
        """
        self.train_files = [Path(f) for f in train_files]
        self.val_files = [Path(f) for f in val_files]
        self.test_files = [Path(f) for f in test_files] if test_files else []
        
        self.train_labels = train_labels
        self.val_labels = val_labels
        self.test_labels = test_labels
        self.metadata = metadata or {}
    
    def __repr__(self) -> str:
        parts = [
            f"train={len(self.train_files)}",
            f"val={len(self.val_files)}",
        ]
        if self.test_files:
            parts.append(f"test={len(self.test_files)}")
        return f"DatasetSplit({', '.join(parts)})"
    
    def save(self, path: Union[str, Path]) -> None:
        """
        Save split to JSON file.
        
        Args:
            path: Path to save the split configuration
        """
        path = Path(path)
        data = {
            "train_files": [str(f) for f in self.train_files],
            "val_files": [str(f) for f in self.val_files],
            "test_files": [str(f) for f in self.test_files] if self.test_files else None,
            "train_labels": self.train_labels,
            "val_labels": self.val_labels,
            "test_labels": self.test_labels,
            "metadata": self.metadata,
        }
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
    
    @classmethod
    def load(cls, path: Union[str, Path]) -> "DatasetSplit":
        """
        Load split from JSON file.
        
        Args:
            path: Path to load the split configuration from
            
        Returns:
            DatasetSplit instance
        """
        path = Path(path)
        with open(path, "r") as f:
            data = json.load(f)
        
        return cls(
            train_files=data["train_files"],
            val_files=data["val_files"],
            test_files=data.get("test_files"),
            train_labels=data.get("train_labels"),
            val_labels=data.get("val_labels"),
            test_labels=data.get("test_labels"),
            metadata=data.get("metadata", {}),
        )


def split_dataset(
    file_paths: List[Union[str, Path]],
    labels: Optional[List[Any]] = None,
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    stratify: bool = False,
    seed: Optional[int] = None,
    shuffle: bool = True,
) -> DatasetSplit:
    """
    Split dataset into train/validation/test sets.
    
    Args:
        file_paths: List of file paths to split
        labels: Optional labels for stratified splitting
        train_ratio: Proportion of data for training (default: 0.7)
        val_ratio: Proportion of data for validation (default: 0.15)
        test_ratio: Proportion of data for testing (default: 0.15)
        stratify: Whether to use stratified splitting (requires labels)
        seed: Random seed for reproducibility
        shuffle: Whether to shuffle before splitting
        
    Returns:
        DatasetSplit instance
        
    Raises:
        ValueError: If ratios don't sum to 1.0 or if stratify=True but labels=None
        
    Example:
        >>> file_paths = ["audio1.wav", "audio2.wav", ...]
        >>> labels = [0, 1, 0, 1, ...]
        >>> split = split_dataset(
        ...     file_paths=file_paths,
        ...     labels=labels,
        ...     train_ratio=0.7,
        ...     val_ratio=0.15,
        ...     test_ratio=0.15,
        ...     stratify=True,
        ...     seed=42,
        ... )
        >>> print(split.train_files)
        >>> print(split.val_files)
        >>> print(split.test_files)
    """
    # Validate ratios
    total_ratio = train_ratio + val_ratio + test_ratio
    if abs(total_ratio - 1.0) > 1e-6:
        raise ValueError(
            f"Ratios must sum to 1.0, got {total_ratio:.6f}"
        )
    
    # Validate stratify
    if stratify and labels is None:
        raise ValueError("stratify=True requires labels to be provided")
    
    # Convert to Path objects
    file_paths = [Path(p) for p in file_paths]
    
    # Get seed
    actual_seed = get_seed(seed)
    
    # Use sklearn if available and stratify is requested
    if stratify and _sklearn_available:
        return _split_with_sklearn(
            file_paths=file_paths,
            labels=labels,
            train_ratio=train_ratio,
            val_ratio=val_ratio,
            test_ratio=test_ratio,
            seed=actual_seed,
            shuffle=shuffle,
        )
    
    # Simple random split
    return _split_simple(
        file_paths=file_paths,
        labels=labels,
        train_ratio=train_ratio,
        val_ratio=val_ratio,
        test_ratio=test_ratio,
        seed=actual_seed,
        shuffle=shuffle,
    )


def _split_simple(
    file_paths: List[Path],
    labels: Optional[List[Any]],
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
    seed: int,
    shuffle: bool,
) -> DatasetSplit:
    """Simple random split without stratification."""
    import random
    
    # Create indices
    indices = list(range(len(file_paths)))
    
    # Shuffle if requested
    if shuffle:
        rng = random.Random(seed)
        rng.shuffle(indices)
    
    # Calculate split points
    n_total = len(file_paths)
    n_train = int(n_total * train_ratio)
    n_val = int(n_total * val_ratio)
    
    # Split indices
    train_indices = indices[:n_train]
    val_indices = indices[n_train:n_train + n_val]
    test_indices = indices[n_train + n_val:]
    
    # Split files
    train_files = [file_paths[i] for i in train_indices]
    val_files = [file_paths[i] for i in val_indices]
    test_files = [file_paths[i] for i in test_indices]
    
    # Split labels if provided
    train_labels = [labels[i] for i in train_indices] if labels else None
    val_labels = [labels[i] for i in val_indices] if labels else None
    test_labels = [labels[i] for i in test_indices] if labels else None
    
    metadata = {
        "method": "simple_random",
        "seed": seed,
        "shuffle": shuffle,
        "train_ratio": train_ratio,
        "val_ratio": val_ratio,
        "test_ratio": test_ratio,
    }
    
    return DatasetSplit(
        train_files=train_files,
        val_files=val_files,
        test_files=test_files,
        train_labels=train_labels,
        val_labels=val_labels,
        test_labels=test_labels,
        metadata=metadata,
    )


def _split_with_sklearn(
    file_paths: List[Path],
    labels: List[Any],
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
    seed: int,
    shuffle: bool,
) -> DatasetSplit:
    """Split using sklearn for stratified splitting."""
    # First split: train vs (val + test)
    train_size = train_ratio
    val_test_size = val_ratio + test_ratio
    
    train_indices, val_test_indices = train_test_split(
        range(len(file_paths)),
        train_size=train_size,
        test_size=val_test_size,
        stratify=labels,
        random_state=seed,
        shuffle=shuffle,
    )
    
    # Split labels for val_test
    val_test_labels = [labels[i] for i in val_test_indices]
    
    # Second split: val vs test
    val_size = val_ratio / val_test_size  # Relative to val_test
    
    val_indices_rel, test_indices_rel = train_test_split(
        range(len(val_test_indices)),
        train_size=val_size,
        test_size=1 - val_size,
        stratify=val_test_labels,
        random_state=seed,
        shuffle=shuffle,
    )
    
    # Map back to original indices
    val_indices = [val_test_indices[i] for i in val_indices_rel]
    test_indices = [val_test_indices[i] for i in test_indices_rel]
    
    # Split files
    train_files = [file_paths[i] for i in train_indices]
    val_files = [file_paths[i] for i in val_indices]
    test_files = [file_paths[i] for i in test_indices]
    
    # Split labels
    train_labels = [labels[i] for i in train_indices]
    val_labels = [labels[i] for i in val_indices]
    test_labels = [labels[i] for i in test_indices]
    
    metadata = {
        "method": "stratified",
        "seed": seed,
        "shuffle": shuffle,
        "train_ratio": train_ratio,
        "val_ratio": val_ratio,
        "test_ratio": test_ratio,
    }
    
    return DatasetSplit(
        train_files=train_files,
        val_files=val_files,
        test_files=test_files,
        train_labels=train_labels,
        val_labels=val_labels,
        test_labels=test_labels,
        metadata=metadata,
    )


def split_by_directory(
    data_dir: Union[str, Path],
    train_dir: str = "train",
    val_dir: str = "val",
    test_dir: Optional[str] = "test",
    pattern: str = "**/*",
    extensions: Optional[List[str]] = None,
) -> DatasetSplit:
    """
    Split dataset based on directory structure.
    
    Assumes data is already organized in train/val/test directories.
    
    Args:
        data_dir: Base directory containing train/val/test subdirectories
        train_dir: Name of training directory (default: "train")
        val_dir: Name of validation directory (default: "val")
        test_dir: Name of test directory (default: "test", None to skip)
        pattern: Glob pattern to match files (default: "**/*")
        extensions: Optional list of file extensions to include (e.g., [".wav", ".mp3"])
        
    Returns:
        DatasetSplit instance
        
    Example:
        >>> # Data structure:
        >>> # data/
        >>> #   train/
        >>> #     audio1.wav
        >>> #     audio2.wav
        >>> #   val/
        >>> #     audio3.wav
        >>> #   test/
        >>> #     audio4.wav
        >>> split = split_by_directory("./data")
    """
    data_dir = Path(data_dir)
    
    # Find files in each directory
    train_path = data_dir / train_dir
    val_path = data_dir / val_dir
    test_path = data_dir / test_dir if test_dir else None
    
    def find_files(directory: Path) -> List[Path]:
        if not directory.exists():
            return []
        files = list(directory.glob(pattern))
        if extensions:
            files = [f for f in files if f.suffix.lower() in extensions]
        return sorted(files)
    
    train_files = find_files(train_path)
    val_files = find_files(val_path)
    test_files = find_files(test_path) if test_path else []
    
    metadata = {
        "method": "directory_based",
        "data_dir": str(data_dir),
        "train_dir": train_dir,
        "val_dir": val_dir,
        "test_dir": test_dir,
    }
    
    return DatasetSplit(
        train_files=train_files,
        val_files=val_files,
        test_files=test_files if test_files else None,
        metadata=metadata,
    )


def split_by_metadata(
    file_paths: List[Union[str, Path]],
    metadata_func: callable,
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    stratify_by: Optional[str] = None,
    seed: Optional[int] = None,
) -> DatasetSplit:
    """
    Split dataset based on metadata extracted from files.
    
    Useful for time-based splits, speaker-based splits, etc.
    
    Args:
        file_paths: List of file paths
        metadata_func: Function that takes a file path and returns metadata dict
        train_ratio: Proportion for training
        val_ratio: Proportion for validation
        test_ratio: Proportion for testing
        stratify_by: Optional metadata key to stratify by
        seed: Random seed
        
    Returns:
        DatasetSplit instance
        
    Example:
        >>> def get_speaker_metadata(file_path):
        ...     # Extract speaker ID from filename
        ...     return {"speaker": file_path.stem.split("_")[0]}
        >>>
        >>> split = split_by_metadata(
        ...     file_paths=files,
        ...     metadata_func=get_speaker_metadata,
        ...     stratify_by="speaker",
        ...     seed=42,
        ... )
    """
    # Extract metadata
    metadata_list = [metadata_func(Path(f)) for f in file_paths]
    
    # Extract labels for stratification if requested
    labels = None
    if stratify_by:
        labels = [m.get(stratify_by) for m in metadata_list]
    
    return split_dataset(
        file_paths=file_paths,
        labels=labels,
        train_ratio=train_ratio,
        val_ratio=val_ratio,
        test_ratio=test_ratio,
        stratify=(stratify_by is not None),
        seed=seed,
    )


def load_from_class_directories(
    data_dir: Union[str, Path],
    pattern: str = "**/*",
    extensions: Optional[List[str]] = None,
    class_to_label: Optional[Dict[str, int]] = None,
    auto_label: bool = True,
) -> Tuple[List[Path], List[int], Dict[str, int]]:
    """
    Load dataset organized by class directories.
    
    Assumes structure:
        data_dir/
            class1/
                file1.wav
                file2.wav
            class2/
                file3.wav
            classn/
                file4.wav
    
    Args:
        data_dir: Base directory containing class subdirectories
        pattern: Glob pattern to match files (default: "**/*")
        extensions: Optional list of file extensions to include (e.g., [".wav", ".mp3"])
        class_to_label: Optional mapping from class name to label integer.
                       If None and auto_label=True, creates automatic mapping.
        auto_label: If True, automatically creates label mapping from class names
        
    Returns:
        Tuple of (file_paths, labels, class_to_label_mapping)
        
    Example:
        >>> # Data structure:
        >>> # data/
        >>> #   cat/
        >>> #     cat1.wav
        >>> #     cat2.wav
        >>> #   dog/
        >>> #     dog1.wav
        >>> #     dog2.wav
        >>> file_paths, labels, class_map = load_from_class_directories("./data")
        >>> print(class_map)  # {'cat': 0, 'dog': 1}
        >>> 
        >>> # Then use with split_dataset
        >>> split = split_dataset(
        ...     file_paths=file_paths,
        ...     labels=labels,
        ...     stratify=True,
        ...     seed=42,
        ... )
    """
    data_dir = Path(data_dir)
    
    if not data_dir.exists():
        raise ValueError(f"Data directory does not exist: {data_dir}")
    
    # Find all class directories (non-hidden directories)
    class_dirs = [
        d for d in data_dir.iterdir()
        if d.is_dir() and not d.name.startswith(".")
    ]
    
    if not class_dirs:
        raise ValueError(f"No class directories found in {data_dir}")
    
    # Sort for reproducibility
    class_dirs = sorted(class_dirs)
    
    # Create or use class to label mapping
    if class_to_label is None:
        if auto_label:
            class_to_label = {class_dir.name: idx for idx, class_dir in enumerate(class_dirs)}
        else:
            raise ValueError("Either class_to_label must be provided or auto_label=True")
    
    # Collect files and labels
    file_paths = []
    labels = []
    
    for class_dir in class_dirs:
        class_name = class_dir.name
        
        if class_name not in class_to_label:
            # Skip directories not in mapping
            continue
        
        label = class_to_label[class_name]
        
        # Find files in this class directory
        files = list(class_dir.glob(pattern))
        
        # Filter by extension if specified
        if extensions:
            files = [f for f in files if f.suffix.lower() in extensions]
        
        # Filter out directories
        files = [f for f in files if f.is_file()]
        
        # Add to lists
        file_paths.extend(files)
        labels.extend([label] * len(files))
    
    return file_paths, labels, class_to_label


def split_by_class_directories(
    data_dir: Union[str, Path],
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    pattern: str = "**/*",
    extensions: Optional[List[str]] = None,
    class_to_label: Optional[Dict[str, int]] = None,
    auto_label: bool = True,
    stratify: bool = True,
    seed: Optional[int] = None,
) -> DatasetSplit:
    """
    Load dataset from class directories and split into train/val/test.
    
    This is a convenience function that combines load_from_class_directories
    and split_dataset for the common case of working with class-organized datasets.
    
    Assumes structure:
        data_dir/
            class1/
                file1.wav
                file2.wav
            class2/
                file3.wav
            classn/
                file4.wav
    
    Args:
        data_dir: Base directory containing class subdirectories
        train_ratio: Proportion for training (default: 0.7)
        val_ratio: Proportion for validation (default: 0.15)
        test_ratio: Proportion for testing (default: 0.15)
        pattern: Glob pattern to match files (default: "**/*")
        extensions: Optional list of file extensions to include (e.g., [".wav", ".mp3"])
        class_to_label: Optional mapping from class name to label integer.
                       If None and auto_label=True, creates automatic mapping.
        auto_label: If True, automatically creates label mapping from class names
        stratify: Whether to use stratified splitting (maintains class distribution)
        seed: Random seed for reproducibility
        
    Returns:
        DatasetSplit instance with class information in metadata
        
    Example:
        >>> # Data structure:
        >>> # data/
        >>> #   cat/
        >>> #     cat1.wav, cat2.wav, ...
        >>> #   dog/
        >>> #     dog1.wav, dog2.wav, ...
        >>> #   bird/
        >>> #     bird1.wav, bird2.wav, ...
        >>> 
        >>> split = split_by_class_directories(
        ...     data_dir="./data",
        ...     train_ratio=0.7,
        ...     val_ratio=0.15,
        ...     test_ratio=0.15,
        ...     extensions=[".wav", ".mp3"],
        ...     stratify=True,
        ...     seed=42,
        ... )
        >>> 
        >>> print(f"Train: {len(split.train_files)} files")
        >>> print(f"Val: {len(split.val_files)} files")
        >>> print(f"Test: {len(split.test_files)} files")
        >>> print(f"Classes: {split.metadata['class_to_label']}")
    """
    # Load files and labels from class directories
    file_paths, labels, class_to_label = load_from_class_directories(
        data_dir=data_dir,
        pattern=pattern,
        extensions=extensions,
        class_to_label=class_to_label,
        auto_label=auto_label,
    )
    
    if not file_paths:
        raise ValueError(f"No files found in {data_dir}")
    
    # Split dataset
    split = split_dataset(
        file_paths=file_paths,
        labels=labels,
        train_ratio=train_ratio,
        val_ratio=val_ratio,
        test_ratio=test_ratio,
        stratify=stratify,
        seed=seed,
    )
    
    # Add class information to metadata
    split.metadata.update({
        "method": "class_directories",
        "data_dir": str(data_dir),
        "class_to_label": class_to_label,
        "label_to_class": {v: k for k, v in class_to_label.items()},
        "num_classes": len(class_to_label),
    })
    
    return split

