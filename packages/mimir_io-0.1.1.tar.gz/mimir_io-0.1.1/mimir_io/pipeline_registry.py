"""
Реєстр пайплайнів трансформацій для гнучкого налаштування експериментів.

Дозволяє реєструвати пайплайни трансформацій та аугментацій без зміни коду experiment.py.
"""

from typing import Dict, Callable, Any, Optional, List
from functools import wraps

try:
    from mimir_io.lens import Lens
    _lens_available = True
except ImportError:
    _lens_available = False
    Lens = object  # type: ignore


class PipelineRegistry:
    """
    Реєстр пайплайнів трансформацій.
    
    Пайплайни реєструються через декоратор @register_pipeline
    та можуть бути отримані за ім'ям з конфігурації.
    """
    
    def __init__(self):
        self._pipelines: Dict[str, Callable] = {}
        self._augmentation_pipelines: Dict[str, Callable] = {}
    
    def register(
        self,
        name: str,
        pipeline_factory: Callable,
        is_augmentation: bool = False,
    ) -> None:
        """
        Реєстрація фабрики пайплайну.
        
        Args:
            name: Унікальна назва пайплайну
            pipeline_factory: Функція, яка приймає **config та повертає Lens
            is_augmentation: Чи це пайплайн аугментації (за замовчуванням False - трансформація)
        """
        if not _lens_available:
            raise ImportError("Lens system is required for pipeline registry")
        
        registry = self._augmentation_pipelines if is_augmentation else self._pipelines
        
        if name in registry:
            raise ValueError(f"Pipeline '{name}' is already registered")
        
        registry[name] = pipeline_factory
    
    def get(self, name: str, is_augmentation: bool = False) -> Callable:
        """
        Отримати фабрику пайплайну за ім'ям.
        
        Args:
            name: Назва пайплайну
            is_augmentation: Чи це пайплайн аугментації
            
        Returns:
            Функція-фабрика пайплайну
            
        Raises:
            KeyError: Якщо пайплайн не знайдено
        """
        registry = self._augmentation_pipelines if is_augmentation else self._pipelines
        
        if name not in registry:
            available = ", ".join(registry.keys())
            pipeline_type = "augmentation" if is_augmentation else "transformation"
            raise KeyError(
                f"{pipeline_type.capitalize()} pipeline '{name}' not found. "
                f"Available {pipeline_type} pipelines: {available}"
            )
        return registry[name]
    
    def create(
        self,
        name: str,
        config: Optional[Dict[str, Any]] = None,
        is_augmentation: bool = False,
    ) -> Lens:
        """
        Створити екземпляр пайплайну за ім'ям.
        
        Args:
            name: Назва пайплайну
            config: Словник конфігурації (виключаючи 'type')
            is_augmentation: Чи це пайплайн аугментації
            
        Returns:
            Екземпляр Lens (пайплайн)
        """
        if config is None:
            config = {}
        
        factory = self.get(name, is_augmentation=is_augmentation)
        return factory(**config)
    
    def list(self, is_augmentation: bool = False) -> List[str]:
        """
        Список всіх зареєстрованих пайплайнів.
        
        Args:
            is_augmentation: Чи повертати пайплайни аугментації
            
        Returns:
            Список назв пайплайнів
        """
        registry = self._augmentation_pipelines if is_augmentation else self._pipelines
        return list(registry.keys())
    
    def has(self, name: str, is_augmentation: bool = False) -> bool:
        """
        Перевірити, чи зареєстрований пайплайн.
        
        Args:
            name: Назва пайплайну
            is_augmentation: Чи це пайплайн аугментації
            
        Returns:
            True якщо зареєстрований, False інакше
        """
        registry = self._augmentation_pipelines if is_augmentation else self._pipelines
        return name in registry


# Глобальний екземпляр реєстру
_pipeline_registry = PipelineRegistry()


def register_pipeline(
    name: Optional[str] = None,
    is_augmentation: bool = False,
) -> Callable:
    """
    Декоратор для реєстрації пайплайну трансформації або аугментації.
    
    Args:
        name: Назва пайплайну (за замовчуванням - назва функції)
        is_augmentation: Чи це пайплайн аугментації (за замовчуванням False)
    
    Example:
        @register_pipeline("mel_spectrogram")
        def mel_spectrogram_pipeline(sample_rate=16000, n_mels=80, **kwargs):
            from mimir_io.audio import resample, log_mel_spectrogram
            return (
                resample(sample_rate).no_cache()
                | log_mel_spectrogram(sample_rate=sample_rate, n_mels=n_mels).cache()
            )
    """
    def decorator(factory: Callable) -> Callable:
        pipeline_name = name or factory.__name__
        _pipeline_registry.register(pipeline_name, factory, is_augmentation=is_augmentation)
        return factory
    
    return decorator


def get_pipeline_factory(name: str, is_augmentation: bool = False) -> Callable:
    """
    Отримати фабрику пайплайну за ім'ям.
    
    Args:
        name: Назва пайплайну
        is_augmentation: Чи це пайплайн аугментації
        
    Returns:
        Функція-фабрика пайплайну
    """
    return _pipeline_registry.get(name, is_augmentation=is_augmentation)


def create_pipeline(
    name: str,
    config: Optional[Dict[str, Any]] = None,
    is_augmentation: bool = False,
) -> Lens:
    """
    Створити екземпляр пайплайну за ім'ям.
    
    Args:
        name: Назва пайплайну
        config: Словник конфігурації
        
    Returns:
        Екземпляр Lens (пайплайн)
    """
    return _pipeline_registry.create(name, config, is_augmentation=is_augmentation)


def list_pipelines(is_augmentation: bool = False) -> List[str]:
    """
    Список всіх зареєстрованих пайплайнів.
    
    Args:
        is_augmentation: Чи повертати пайплайни аугментації
        
    Returns:
        Список назв пайплайнів
    """
    return _pipeline_registry.list(is_augmentation=is_augmentation)


def has_pipeline(name: str, is_augmentation: bool = False) -> bool:
    """
    Перевірити, чи зареєстрований пайплайн.
    
    Args:
        name: Назва пайплайну
        is_augmentation: Чи це пайплайн аугментації
        
    Returns:
        True якщо зареєстрований, False інакше
    """
    return _pipeline_registry.has(name, is_augmentation=is_augmentation)


# Реєстрація стандартних пайплайнів
if _lens_available:
    @register_pipeline("mel_spectrogram")
    def mel_spectrogram_pipeline(
        sample_rate: int = 16000,
        n_mels: int = 80,
        n_fft: int = 2048,
        hop_length: int = 512,
        **kwargs,
    ):
        """
        Стандартний пайплайн: resample + log_mel_spectrogram.
        
        Args:
            sample_rate: Цільова частота дискретизації
            n_mels: Кількість mel-бінів
            n_fft: Розмір FFT вікна
            hop_length: Довжина hop для STFT
        """
        from mimir_io.audio import resample, log_mel_spectrogram
        
        return (
            resample(sample_rate).no_cache()
            | log_mel_spectrogram(
                sample_rate=sample_rate,
                n_mels=n_mels,
                n_fft=n_fft,
                hop_length=hop_length,
            ).cache()
        )
    
    @register_pipeline("mfcc")
    def mfcc_pipeline(
        sample_rate: int = 16000,
        n_mfcc: int = 13,
        n_mels: int = 80,
        n_fft: int = 2048,
        hop_length: int = 512,
        **kwargs,
    ):
        """
        Пайплайн для MFCC features.
        
        Args:
            sample_rate: Цільова частота дискретизації
            n_mfcc: Кількість MFCC коефіцієнтів
            n_mels: Кількість mel-бінів
            n_fft: Розмір FFT вікна
            hop_length: Довжина hop для STFT
        """
        from mimir_io.audio import resample, mfcc
        
        return (
            resample(sample_rate).no_cache()
            | mfcc(
                sample_rate=sample_rate,
                n_mfcc=n_mfcc,
                n_mels=n_mels,
                n_fft=n_fft,
                hop_length=hop_length,
            ).cache()
        )
    
    @register_pipeline("standard_augmentation", is_augmentation=True)
    def standard_augmentation_pipeline(
        time_shift_max: int = 1600,
        gain_range: tuple = (0.7, 1.3),
        noise_snr: float = 20.0,
        speed_range: tuple = (0.9, 1.1),
        **kwargs,
    ):
        """
        Стандартний пайплайн аугментації.
        
        Args:
            time_shift_max: Максимальний зсув часу в семплах
            gain_range: Діапазон зміни гучності (min, max)
            noise_snr: SNR для додавання шуму
            speed_range: Діапазон зміни швидкості (min, max)
        """
        from mimir_io.rayframe.audio import augment_audio_frame
        
        return augment_audio_frame(
            time_shift_max=time_shift_max,
            gain_range=gain_range,
            noise_snr=noise_snr,
            speed_range=speed_range,
        )

