"""
PyTorch Lightning integration for mimir_io.

Provides MimirDataModule for seamless integration with PyTorch Lightning,
solving common Lightning problems with automatic caching, seed management,
and GPU-accelerated augmentations.
"""

from typing import Optional, List, Union, Dict, Any
from pathlib import Path

try:
    import pytorch_lightning as pl
    _lightning_available = True
except ImportError:
    _lightning_available = False
    # Create stub for type checking
    pl = None  # type: ignore

try:
    import torch
    from torch.utils.data import DataLoader
    _torch_available = True
except ImportError:
    _torch_available = False
    torch = object  # type: ignore
    DataLoader = object  # type: ignore

from mimir_io import Dataset, split_dataset, DatasetSplit
from mimir_io.lens import Lens
from mimir_io.torch_dataset import create_dataloader, MimirTorchDataset
from mimir_io.rayframe.audio import augment_audio_frame


if _lightning_available and pl is not None:
    _BaseClass = pl.LightningDataModule
else:
    # Create a dummy base class when Lightning is not available
    class _BaseClass:  # type: ignore
        def __init__(self):
            pass


class MimirDataModule(_BaseClass):
    """
    PyTorch Lightning DataModule for mimir_io.
    
    Solves common Lightning problems:
    - Automatic caching (10-100x faster after first epoch)
    - Proper seed management for reproducibility
    - GPU-accelerated augmentations
    - Easy multiprocessing setup
    
    Example:
        >>> from mimir_io.lightning import MimirDataModule
        >>> from mimir_io.audio import resample, log_mel_spectrogram
        >>>
        >>> datamodule = MimirDataModule(
        ...     file_paths=all_files,
        ...     labels=all_labels,
        ...     transform_pipeline=resample(16000) | log_mel_spectrogram(n_mels=80),
        ...     batch_size=32,
        ... )
        >>>
        >>> trainer = pl.Trainer()
        >>> trainer.fit(model, datamodule)
    """
    
    def __init__(
        self,
        file_paths: List[Union[str, Path]],
        labels: Optional[List[Any]] = None,
        transform_pipeline: Optional[Lens] = None,
        augmentation_pipeline: Optional[Lens] = None,
        data_dir: Union[str, Path] = "./data",
        train_ratio: float = 0.7,
        val_ratio: float = 0.15,
        test_ratio: float = 0.15,
        batch_size: int = 32,
        num_workers: int = 4,
        pin_memory: bool = True,
        persistent_workers: bool = False,
        prefetch_factor: Optional[int] = None,
        shuffle: bool = True,
        drop_last: bool = False,
        split_seed: int = 42,
        stratify: bool = True,
        split_path: Optional[Union[str, Path]] = None,
        use_augmentation: bool = True,
        precompute_cache: bool = False,
        **dataloader_kwargs,
    ):
        """
        Initialize MimirDataModule.
        
        Args:
            file_paths: List of paths to audio files
            labels: Optional labels for each file
            transform_pipeline: Lens with transformation pipeline (e.g., mel spectrogram)
            augmentation_pipeline: Lens with augmentation pipeline (for training)
            data_dir: Base data directory for mimir_io Dataset
            train_ratio: Training data ratio
            val_ratio: Validation data ratio
            test_ratio: Test data ratio
            batch_size: Batch size for DataLoader
            num_workers: Number of workers for DataLoader
            pin_memory: Whether to pin memory (faster GPU transfer)
            persistent_workers: Keep workers alive between epochs (faster, uses more memory)
            prefetch_factor: Number of batches prefetched per worker
            shuffle: Whether to shuffle training data
            drop_last: Drop last incomplete batch
            split_seed: Seed for dataset splitting
            stratify: Whether to maintain class distribution when splitting
            split_path: Path to save/load dataset split (for reproducibility)
            use_augmentation: Whether to use augmentations for training
            precompute_cache: Whether to precompute cache before training (recommended)
            **dataloader_kwargs: Additional arguments passed to DataLoader
        """
        if not _lightning_available:
            raise ImportError(
                "PyTorch Lightning is required. Install with: pip install pytorch-lightning"
            )
        
        if not _torch_available:
            raise ImportError("PyTorch is required")
        
        # Call super().__init__() only if Lightning is available
        if _lightning_available and pl is not None:
            super().__init__()
        
        self.file_paths = [Path(p) for p in file_paths]
        self.labels = labels
        self.transform_pipeline = transform_pipeline
        self.augmentation_pipeline = augmentation_pipeline
        self.data_dir = Path(data_dir)
        self.train_ratio = train_ratio
        self.val_ratio = val_ratio
        self.test_ratio = test_ratio
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.pin_memory = pin_memory
        self.persistent_workers = persistent_workers
        self.prefetch_factor = prefetch_factor
        self.shuffle = shuffle
        self.drop_last = drop_last
        self.split_seed = split_seed
        self.stratify = stratify
        self.split_path = Path(split_path) if split_path else None
        self.use_augmentation = use_augmentation
        self.precompute_cache = precompute_cache
        self.dataloader_kwargs = dataloader_kwargs
        
        # Will be set in setup()
        self.mimir_dataset: Optional[Dataset] = None
        self.split: Optional[DatasetSplit] = None
        self.train_dataset: Optional[MimirTorchDataset] = None
        self.val_dataset: Optional[MimirTorchDataset] = None
        self.test_dataset: Optional[MimirTorchDataset] = None
    
    def prepare_data(self) -> None:
        """
        Prepare data (download, precompute cache, etc.).
        
        This is called only on main process (rank 0) in distributed training.
        Perfect place to precompute cache!
        """
        if self.precompute_cache and self.transform_pipeline is not None:
            # Create dataset for cache precomputation
            dataset = Dataset(data_dir=self.data_dir)
            
            # Load or create split
            if self.split_path and self.split_path.exists():
                split = DatasetSplit.load(self.split_path)
            else:
                split = split_dataset(
                    file_paths=self.file_paths,
                    labels=self.labels,
                    train_ratio=self.train_ratio,
                    val_ratio=self.val_ratio,
                    test_ratio=self.test_ratio,
                    stratify=self.stratify,
                    seed=self.split_seed,
                )
            
            # Precompute cache for all splits
            print("Precomputing cache...")
            all_files = split.train_files + split.val_files + split.test_files
            
            dataset.precompute_batch(
                lens=self.transform_pipeline,
                data_list=[dataset.load_audio(str(f)) for f in all_files],
                show_progress=True,
                desc="Precomputing cache",
            )
            print("Cache precomputation completed!")
    
    def setup(self, stage: Optional[str] = None) -> None:
        """
        Setup datasets for training/validation/testing.
        
        Called on every GPU/process in distributed training.
        """
        # Create mimir_io Dataset
        self.mimir_dataset = Dataset(data_dir=self.data_dir)
        
        # Load or create split
        if self.split_path and self.split_path.exists():
            self.split = DatasetSplit.load(self.split_path)
            print(f"Loaded split from {self.split_path}")
        else:
            self.split = split_dataset(
                file_paths=self.file_paths,
                labels=self.labels,
                train_ratio=self.train_ratio,
                val_ratio=self.val_ratio,
                test_ratio=self.test_ratio,
                stratify=self.stratify,
                seed=self.split_seed,
            )
            
            # Save split for reproducibility
            if self.split_path:
                self.split.save(self.split_path)
                print(f"Saved split to {self.split_path}")
        
        # Create default transform pipeline if not provided
        if self.transform_pipeline is None:
            from mimir_io.audio import resample, log_mel_spectrogram
            self.transform_pipeline = (
                resample(16000) | log_mel_spectrogram(n_mels=80)
            )
        
        # Create default augmentation pipeline if not provided and augmentation enabled
        if self.use_augmentation and self.augmentation_pipeline is None:
            self.augmentation_pipeline = augment_audio_frame(
                time_shift_max=1600,
                gain_range=(0.7, 1.3),
            )
        
        # Create datasets
        if stage == "fit" or stage is None:
            # Training dataset with augmentations
            self.train_dataset = MimirTorchDataset(
                mimir_dataset=self.mimir_dataset,
                file_paths=self.split.train_files,
                transform_pipeline=self.transform_pipeline,
                labels=self.split.train_labels,
                use_augmentation=self.use_augmentation,
                augmentation_pipeline=self.augmentation_pipeline,
            )
            
            # Validation dataset without augmentations
            self.val_dataset = MimirTorchDataset(
                mimir_dataset=self.mimir_dataset,
                file_paths=self.split.val_files,
                transform_pipeline=self.transform_pipeline,
                labels=self.split.val_labels,
                use_augmentation=False,  # No augmentations for validation
            )
        
        if stage == "test" or stage is None:
            # Test dataset without augmentations
            self.test_dataset = MimirTorchDataset(
                mimir_dataset=self.mimir_dataset,
                file_paths=self.split.test_files,
                transform_pipeline=self.transform_pipeline,
                labels=self.split.test_labels,
                use_augmentation=False,  # No augmentations for testing
            )
    
    
    def val_dataloader(self) -> DataLoader:
        """Create validation DataLoader."""
        if self.val_dataset is None:
            raise RuntimeError("val_dataset is not set. Call setup('fit') first.")
        
        return create_dataloader(
            mimir_dataset=self.mimir_dataset,
            file_paths=self.split.val_files,
            transform_pipeline=self.transform_pipeline,
            labels=self.split.val_labels,
            batch_size=self.batch_size,
            shuffle=False,  # Never shuffle validation
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            persistent_workers=self.persistent_workers,
            prefetch_factor=self.prefetch_factor,
            drop_last=False,  # Don't drop last batch in validation
            use_augmentation=False,  # No augmentations for validation
            **self.dataloader_kwargs,
        )
    
    def test_dataloader(self) -> DataLoader:
        """Create test DataLoader."""
        if self.test_dataset is None:
            raise RuntimeError("test_dataset is not set. Call setup('test') first.")
        
        return create_dataloader(
            mimir_dataset=self.mimir_dataset,
            file_paths=self.split.test_files,
            transform_pipeline=self.transform_pipeline,
            labels=self.split.test_labels,
            batch_size=self.batch_size,
            shuffle=False,  # Never shuffle test
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            persistent_workers=self.persistent_workers,
            prefetch_factor=self.prefetch_factor,
            drop_last=False,  # Don't drop last batch in test
            use_augmentation=False,  # No augmentations for testing
            **self.dataloader_kwargs,
        )
    
    def train_dataloader(self) -> DataLoader:
        """
        Create training DataLoader.
        
        Note: Epoch is set automatically via dataset.set_epoch() in Lightning's
        training loop. The dataset will receive epoch updates through the
        DataLoader's worker processes.
        """
        if self.train_dataset is None:
            raise RuntimeError("train_dataset is not set. Call setup('fit') first.")
        
        loader = create_dataloader(
            mimir_dataset=self.mimir_dataset,
            file_paths=self.split.train_files,
            transform_pipeline=self.transform_pipeline,
            labels=self.split.train_labels,
            batch_size=self.batch_size,
            shuffle=self.shuffle,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            persistent_workers=self.persistent_workers,
            prefetch_factor=self.prefetch_factor,
            drop_last=self.drop_last,
            use_augmentation=self.use_augmentation,
            augmentation_pipeline=self.augmentation_pipeline,
            **self.dataloader_kwargs,
        )
        
        return loader
    
    def on_train_epoch_start(self) -> None:
        """
        Called at the start of each training epoch.
        
        Sets epoch for dataset to ensure different augmentations each epoch.
        """
        if self.train_dataset is not None and self.trainer is not None:
            epoch = self.trainer.current_epoch
            if epoch is not None:
                self.train_dataset.set_epoch(epoch)

