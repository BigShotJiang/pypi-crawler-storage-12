"""
Base backend interface.

All backends must implement this interface to be compatible with mimir_io.
"""

from abc import ABC, abstractmethod
from typing import Any, Optional


class Backend(ABC):
    """
    Abstract base class for computation backends.

    Backends provide a unified interface for tensor operations,
    allowing mimir_io to work with different computation libraries.
    """

    @abstractmethod
    def array(self, data: Any, dtype: Optional[Any] = None) -> Any:
        """
        Create an array/tensor from data.

        Args:
            data: Input data (list, numpy array, etc.)
            dtype: Optional data type

        Returns:
            Backend-specific array/tensor
        """
        pass

    @abstractmethod
    def shape(self, tensor: Any) -> tuple:
        """
        Get the shape of a tensor.

        Args:
            tensor: Backend tensor

        Returns:
            Shape tuple
        """
        pass

    @abstractmethod
    def dtype(self, tensor: Any) -> Any:
        """
        Get the data type of a tensor.

        Args:
            tensor: Backend tensor

        Returns:
            Data type
        """
        pass

    @abstractmethod
    def name(self) -> str:
        """Return the name of this backend."""
        pass

