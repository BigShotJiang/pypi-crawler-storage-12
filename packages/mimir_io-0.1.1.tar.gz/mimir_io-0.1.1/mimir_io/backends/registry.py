"""
Backend registry for managing active backend instances.
"""

from typing import Optional
from mimir_io.backends.base import Backend
from mimir_io.backends.torch_backend import TorchBackend

_default_backend: Optional[Backend] = None


def get_backend() -> Backend:
    """
    Get the current active backend.

    Returns:
        The active backend instance

    Raises:
        RuntimeError: If no backend has been set
    """
    global _default_backend
    if _default_backend is None:
        _default_backend = TorchBackend()
    return _default_backend


def set_backend(backend: Backend) -> None:
    """
    Set the active backend.

    Args:
        backend: Backend instance to use
    """
    global _default_backend
    _default_backend = backend


def register_backend(name: str, backend: Backend) -> None:
    """
    Register a named backend.

    This is a placeholder for future functionality where
    multiple backends can be registered and switched by name.

    Args:
        name: Name to register the backend under
        backend: Backend instance
    """
    # For now, just set it as the default
    # In the future, this could maintain a registry of named backends
    set_backend(backend)

