"""
PyTorch backend implementation.
"""

import torch
from typing import Any, Optional
from mimir_io.backends.base import Backend


class TorchBackend(Backend):
    """PyTorch implementation of the Backend interface."""

    def array(self, data: Any, dtype: Optional[Any] = None) -> torch.Tensor:
        """Create a PyTorch tensor from data."""
        if isinstance(data, torch.Tensor):
            return data if dtype is None else data.to(dtype)
        return torch.tensor(data, dtype=dtype)

    def shape(self, tensor: torch.Tensor) -> tuple:
        """Get the shape of a PyTorch tensor."""
        return tuple(tensor.shape)

    def dtype(self, tensor: torch.Tensor) -> torch.dtype:
        """Get the data type of a PyTorch tensor."""
        return tensor.dtype

    def name(self) -> str:
        """Return the backend name."""
        return "torch"

