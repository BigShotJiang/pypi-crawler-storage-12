"""
Backend compatibility layer.

This module provides a unified interface for different computation backends
(e.g., torch, numpy, etc.) allowing the library to work with various data types.
"""

from mimir_io.backends.base import Backend
from mimir_io.backends.torch_backend import TorchBackend
from mimir_io.backends.registry import get_backend, set_backend, register_backend

__all__ = [
    "Backend",
    "TorchBackend",
    "get_backend",
    "set_backend",
    "register_backend",
]

