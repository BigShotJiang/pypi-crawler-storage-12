"""
Профілювання пайплайнів для визначення вузьких місць у обробці даних.

Надає інструменти для аналізу продуктивності lens-трансформацій та кешування.
"""

import time
import json
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path
from collections import defaultdict

try:
    import torch
    _torch_available = True
except ImportError:
    _torch_available = False
    torch = object  # type: ignore

from mimir_io.lens import Lens
from mimir_io.dataset import Dataset


class PipelineProfiler:
    """
    Профілер для аналізу продуктивності пайплайнів.
    
    Вимірює час виконання кожного lens у пайплайні та ефективність кешування.
    """
    
    def __init__(self, dataset: Dataset):
        """
        Ініціалізація профілера.
        
        Args:
            dataset: Dataset instance для доступу до кешу
        """
        self.dataset = dataset
        self.stats: Dict[str, List[float]] = defaultdict(list)
        self.cache_hits = 0
        self.cache_misses = 0
    
    def profile(
        self,
        lens: Lens,
        data: Any,
        num_runs: int = 1,
        warmup_runs: int = 0,
    ) -> Dict[str, Any]:
        """
        Профілювання lens або пайплайну.
        
        Args:
            lens: Lens або пайплайн для профілювання
            data: Вхідні дані
            num_runs: Кількість запусків для усереднення
            warmup_runs: Кількість прогрівальних запусків (не враховуються в статистиці)
            
        Returns:
            Словник зі статистикою:
            - total_time: Загальний час виконання
            - lens_times: Час для кожного lens
            - cache_hit_rate: Відсоток попадань у кеш
            - breakdown: Детальна розбивка по lens
        """
        # Прогрівання
        for _ in range(warmup_runs):
            try:
                self.dataset.apply(lens, data, use_cache=True)
            except Exception:
                pass
        
        # Очищення статистики
        self.stats.clear()
        self.cache_hits = 0
        self.cache_misses = 0
        
        # Вимірювання
        total_times = []
        
        for run in range(num_runs):
            start_time = time.perf_counter()
            
            # Застосовуємо lens з відстеженням кешу
            result = self._apply_with_profiling(lens, data)
            
            end_time = time.perf_counter()
            total_times.append(end_time - start_time)
        
        # Обчислення статистики
        avg_total_time = sum(total_times) / len(total_times) if total_times else 0.0
        
        # Статистика по lens
        lens_stats = {}
        for lens_name, times in self.stats.items():
            if times:
                lens_stats[lens_name] = {
                    "total_time": sum(times),
                    "avg_time": sum(times) / len(times),
                    "min_time": min(times),
                    "max_time": max(times),
                    "num_calls": len(times),
                    "percentage": (sum(times) / avg_total_time * 100) if avg_total_time > 0 else 0.0,
                }
        
        # Cache hit rate
        total_cache_ops = self.cache_hits + self.cache_misses
        cache_hit_rate = (self.cache_hits / total_cache_ops * 100) if total_cache_ops > 0 else 0.0
        
        return {
            "total_time": avg_total_time,
            "total_time_ms": avg_total_time * 1000,
            "lens_times": lens_stats,
            "cache_hit_rate": cache_hit_rate,
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "num_runs": num_runs,
            "breakdown": self._generate_breakdown(lens_stats, avg_total_time),
        }
    
    def _apply_with_profiling(self, lens: Lens, data: Any) -> Any:
        """
        Застосування lens з профілюванням.
        
        Внутрішній метод для відстеження часу виконання кожного lens.
        """
        # Для композованих lens профілюємо кожен компонент окремо
        if hasattr(lens, '_getter') and hasattr(lens, '_name'):
            # Перевіряємо чи це композований lens (має "|" в назві)
            if ' | ' in lens._name:
                # Це композований lens - профілюємо як цілий
                lens_name = lens._name
            else:
                lens_name = lens._name
        else:
            lens_name = getattr(lens, 'name', 'unnamed_lens')
        
        start = time.perf_counter()
        
        # Перевіряємо кеш перед застосуванням
        should_cache = getattr(lens, '_should_cache', True)
        if should_cache:
            try:
                cache_key = lens.cache_key(data)
                cache_path = self.dataset._get_cache_path(cache_key)
                
                # Перевіряємо чи існує кеш
                cached_result = self.dataset._load_from_cache(cache_path)
                if cached_result is not None:
                    self.cache_hits += 1
                else:
                    self.cache_misses += 1
            except Exception:
                # Якщо не вдалося перевірити кеш, вважаємо промахом
                self.cache_misses += 1
        
        # Застосовуємо lens через dataset.apply для правильного кешування
        result = self.dataset.apply(lens, data, use_cache=True)
        
        end = time.perf_counter()
        self.stats[lens_name].append(end - start)
        
        return result
    
    def _generate_breakdown(
        self,
        lens_stats: Dict[str, Dict[str, Any]],
        total_time: float,
    ) -> List[Dict[str, Any]]:
        """
        Генерація детальної розбивки по lens.
        
        Args:
            lens_stats: Статистика по lens
            total_time: Загальний час
            
        Returns:
            Список словників з детальною інформацією
        """
        breakdown = []
        
        for lens_name, stats in sorted(
            lens_stats.items(),
            key=lambda x: x[1]["total_time"],
            reverse=True,
        ):
            breakdown.append({
                "lens": lens_name,
                "total_time_ms": stats["total_time"] * 1000,
                "avg_time_ms": stats["avg_time"] * 1000,
                "percentage": stats["percentage"],
                "num_calls": stats["num_calls"],
            })
        
        return breakdown


def profile_pipeline(
    dataset: Dataset,
    lens: Lens,
    data: Any,
    num_runs: int = 5,
    warmup_runs: int = 1,
) -> Dict[str, Any]:
    """
    Профілювання пайплайну з автоматичним звітом.
    
    Args:
        dataset: Dataset instance
        lens: Lens або пайплайн для профілювання
        data: Вхідні дані
        num_runs: Кількість запусків для усереднення
        warmup_runs: Кількість прогрівальних запусків
        
    Returns:
        Словник зі статистикою профілювання
        
    Example:
        >>> from mimir_io import Dataset
        >>> from mimir_io.profiling import profile_pipeline
        >>> from mimir_io.audio import resample, log_mel_spectrogram
        >>>
        >>> dataset = Dataset(data_dir="./data")
        >>> pipeline = resample(16000) | log_mel_spectrogram(n_mels=80)
        >>> stats = profile_pipeline(dataset, pipeline, audio_data)
        >>> print(f"Total time: {stats['total_time_ms']:.2f}ms")
    """
    profiler = PipelineProfiler(dataset)
    return profiler.profile(lens, data, num_runs=num_runs, warmup_runs=warmup_runs)


def print_profile_report(stats: Dict[str, Any]) -> None:
    """
    Виведення звіту профілювання у читабельному форматі.
    
    Args:
        stats: Статистика з profile_pipeline
    """
    print("\n" + "=" * 60)
    print("Pipeline Profiling Report")
    print("=" * 60)
    
    print(f"\nTotal Time: {stats['total_time_ms']:.2f} ms")
    print(f"Number of Runs: {stats['num_runs']}")
    
    if stats['cache_hits'] + stats['cache_misses'] > 0:
        print(f"\nCache Statistics:")
        print(f"  Hit Rate: {stats['cache_hit_rate']:.1f}%")
        print(f"  Hits: {stats['cache_hits']}")
        print(f"  Misses: {stats['cache_misses']}")
    
    if stats['breakdown']:
        print(f"\nLens Breakdown:")
        print(f"{'Lens Name':<30} {'Time (ms)':<15} {'%':<10} {'Calls':<10}")
        print("-" * 65)
        
        for item in stats['breakdown']:
            print(
                f"{item['lens']:<30} "
                f"{item['avg_time_ms']:<15.2f} "
                f"{item['percentage']:<10.1f} "
                f"{item['num_calls']:<10}"
            )
    
    print("\n" + "=" * 60)


def generate_recommendations(stats: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Генерація рекомендацій щодо оптимізації на основі профілювання.
    
    Args:
        stats: Статистика з profile_pipeline
        
    Returns:
        Список рекомендацій з пріоритетом та описом
    """
    recommendations = []
    
    # Аналіз кешування
    cache_hit_rate = stats.get('cache_hit_rate', 0.0)
    if cache_hit_rate < 50.0:
        recommendations.append({
            "priority": "high",
            "category": "caching",
            "title": "Низький рівень попадань у кеш",
            "description": f"Поточний рівень попадань у кеш: {cache_hit_rate:.1f}%. Рекомендується перевірити стратегію кешування.",
            "suggestion": "Переконайтеся, що дорогі операції (наприклад, спектрограми) мають увімкнене кешування. Використовуйте .cache() для lens, які виконуються повільно.",
            "impact": "high",
        })
    
    # Аналіз найповільніших lens
    breakdown = stats.get('breakdown', [])
    if breakdown:
        # Знаходимо lens, які займають більше 30% часу
        slow_lens = [item for item in breakdown if item['percentage'] > 30.0]
        if slow_lens:
            for item in slow_lens:
                recommendations.append({
                    "priority": "high",
                    "category": "performance",
                    "title": f"Вузьке місце: {item['lens']}",
                    "description": f"Lens '{item['lens']}' займає {item['percentage']:.1f}% загального часу ({item['avg_time_ms']:.2f}ms).",
                    "suggestion": f"Розгляньте можливість оптимізації або кешування для '{item['lens']}'. Якщо це можливо, перемістіть цю операцію пізніше в пайплайн після дешевших операцій.",
                    "impact": "high",
                })
        
        # Перевірка на наявність дуже швидких операцій без кешування перед повільними
        total_time = stats.get('total_time_ms', 0)
        if total_time > 0:
            # Знаходимо операції, які можна оптимізувати порядком
            expensive_ops = [item for item in breakdown if item['avg_time_ms'] > total_time * 0.1]
            cheap_ops = [item for item in breakdown if item['avg_time_ms'] < total_time * 0.05]
            
            if expensive_ops and cheap_ops:
                recommendations.append({
                    "priority": "medium",
                    "category": "optimization",
                    "title": "Можливість оптимізації порядку операцій",
                    "description": "Виявлено комбінацію дорогих та дешевих операцій. Порядок операцій може впливати на продуктивність.",
                    "suggestion": "Розгляньте використання optimize_pipeline() для автоматичної оптимізації порядку операцій. Дешевші операції краще виконувати перед дорогими.",
                    "impact": "medium",
                })
    
    # Перевірка на надмірну кількість запусків
    num_runs = stats.get('num_runs', 1)
    if num_runs < 3:
        recommendations.append({
            "priority": "low",
            "category": "profiling",
            "title": "Недостатня кількість запусків для профілювання",
            "description": f"Профілювання виконано лише {num_runs} раз(ів). Для більш точних результатів рекомендується більше запусків.",
            "suggestion": "Збільште параметр num_runs до 5-10 для більш точного профілювання.",
            "impact": "low",
        })
    
    # Перевірка на велику варіативність часу виконання
    lens_stats = stats.get('lens_times', {})
    for lens_name, lens_stat in lens_stats.items():
        if lens_stat.get('num_calls', 0) > 1:
            min_time = lens_stat.get('min_time', 0) * 1000
            max_time = lens_stat.get('max_time', 0) * 1000
            if min_time > 0 and (max_time / min_time) > 2.0:
                recommendations.append({
                    "priority": "medium",
                    "category": "stability",
                    "title": f"Висока варіативність часу виконання: {lens_name}",
                    "description": f"Час виконання '{lens_name}' сильно варіюється (від {min_time:.2f}ms до {max_time:.2f}ms).",
                    "suggestion": "Це може вказувати на проблеми з кешуванням або нестабільністю операції. Перевірте, чи правильно налаштоване кешування.",
                    "impact": "medium",
                })
    
    # Сортування за пріоритетом
    priority_order = {"high": 0, "medium": 1, "low": 2}
    recommendations.sort(key=lambda x: priority_order.get(x.get("priority", "low"), 2))
    
    return recommendations


def generate_html_report(
    stats: Dict[str, Any],
    recommendations: Optional[List[Dict[str, Any]]] = None,
    output_path: Optional[str] = None,
) -> str:
    """
    Генерація інтерактивного HTML звіту профілювання.
    
    Args:
        stats: Статистика з profile_pipeline
        recommendations: Список рекомендацій (якщо None, генерується автоматично)
        output_path: Шлях для збереження HTML файлу (опціонально)
        
    Returns:
        HTML звіт як рядок
        
    Example:
        >>> from mimir_io.profiling import profile_pipeline, generate_html_report
        >>> stats = profile_pipeline(dataset, pipeline, data)
        >>> html = generate_html_report(stats, output_path="report.html")
    """
    if recommendations is None:
        recommendations = generate_recommendations(stats)
    
    # Підготовка даних для графіків
    breakdown = stats.get('breakdown', [])
    lens_names = [item['lens'] for item in breakdown]
    lens_times = [item['avg_time_ms'] for item in breakdown]
    
    # Дані для графіка кешування
    cache_hits = stats.get('cache_hits', 0)
    cache_misses = stats.get('cache_misses', 0)
    
    # Генерація HTML
    html_parts = [
        "<!DOCTYPE html>",
        "<html lang='uk'>",
        "<head>",
        "    <meta charset='UTF-8'>",
        "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>",
        "    <title>Pipeline Profiling Report</title>",
        "    <script src='https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js'></script>",
        "    <style>",
        "        * { margin: 0; padding: 0; box-sizing: border-box; }",
        "        body {",
        "            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;",
        "            line-height: 1.6;",
        "            color: #333;",
        "            background: #f5f5f5;",
        "            padding: 20px;",
        "        }",
        "        .container {",
        "            max-width: 1200px;",
        "            margin: 0 auto;",
        "            background: white;",
        "            padding: 30px;",
        "            border-radius: 8px;",
        "            box-shadow: 0 2px 10px rgba(0,0,0,0.1);",
        "        }",
        "        h1 {",
        "            color: #2c3e50;",
        "            border-bottom: 3px solid #3498db;",
        "            padding-bottom: 10px;",
        "            margin-bottom: 30px;",
        "        }",
        "        h2 {",
        "            color: #34495e;",
        "            margin-top: 30px;",
        "            margin-bottom: 15px;",
        "        }",
        "        .summary {",
        "            display: grid;",
        "            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));",
        "            gap: 20px;",
        "            margin-bottom: 30px;",
        "        }",
        "        .summary-card {",
        "            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);",
        "            color: white;",
        "            padding: 20px;",
        "            border-radius: 8px;",
        "            text-align: center;",
        "        }",
        "        .summary-card h3 {",
        "            font-size: 14px;",
        "            opacity: 0.9;",
        "            margin-bottom: 10px;",
        "        }",
        "        .summary-card .value {",
        "            font-size: 32px;",
        "            font-weight: bold;",
        "        }",
        "        .chart-container {",
        "            margin: 30px 0;",
        "            position: relative;",
        "            height: 400px;",
        "        }",
        "        table {",
        "            width: 100%;",
        "            border-collapse: collapse;",
        "            margin: 20px 0;",
        "        }",
        "        th, td {",
        "            padding: 12px;",
        "            text-align: left;",
        "            border-bottom: 1px solid #ddd;",
        "        }",
        "        th {",
        "            background-color: #3498db;",
        "            color: white;",
        "            font-weight: bold;",
        "        }",
        "        tr:hover {",
        "            background-color: #f5f5f5;",
        "        }",
        "        .recommendation {",
        "            margin: 15px 0;",
        "            padding: 15px;",
        "            border-left: 4px solid #3498db;",
        "            background: #ecf0f1;",
        "            border-radius: 4px;",
        "        }",
        "        .recommendation.high {",
        "            border-left-color: #e74c3c;",
        "            background: #fee;",
        "        }",
        "        .recommendation.medium {",
        "            border-left-color: #f39c12;",
        "            background: #fff8e1;",
        "        }",
        "        .recommendation.low {",
        "            border-left-color: #95a5a6;",
        "            background: #f8f9fa;",
        "        }",
        "        .recommendation h4 {",
        "            color: #2c3e50;",
        "            margin-bottom: 8px;",
        "        }",
        "        .recommendation .category {",
        "            font-size: 12px;",
        "            color: #7f8c8d;",
        "            text-transform: uppercase;",
        "        }",
        "        .recommendation .suggestion {",
        "            margin-top: 10px;",
        "            padding-top: 10px;",
        "            border-top: 1px solid #ddd;",
        "            color: #555;",
        "        }",
        "        .badge {",
        "            display: inline-block;",
        "            padding: 4px 8px;",
        "            border-radius: 4px;",
        "            font-size: 12px;",
        "            font-weight: bold;",
        "            margin-left: 10px;",
        "        }",
        "        .badge.high { background: #e74c3c; color: white; }",
        "        .badge.medium { background: #f39c12; color: white; }",
        "        .badge.low { background: #95a5a6; color: white; }",
        "    </style>",
        "</head>",
        "<body>",
        "    <div class='container'>",
        f"        <h1>📊 Pipeline Profiling Report</h1>",
        f"        <p style='color: #7f8c8d; margin-bottom: 30px;'>Згенеровано: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>",
        "",
        "        <!-- Summary Cards -->",
        "        <div class='summary'>",
        f"            <div class='summary-card'><h3>Загальний час</h3><div class='value'>{stats.get('total_time_ms', 0):.2f} ms</div></div>",
        f"            <div class='summary-card'><h3>Кількість запусків</h3><div class='value'>{stats.get('num_runs', 0)}</div></div>",
        f"            <div class='summary-card'><h3>Попадання у кеш</h3><div class='value'>{stats.get('cache_hit_rate', 0):.1f}%</div></div>",
        f"            <div class='summary-card'><h3>Компонентів</h3><div class='value'>{len(breakdown)}</div></div>",
        "        </div>",
        "",
        "        <!-- Performance Chart -->",
        "        <h2>⏱️ Час виконання по компонентах</h2>",
        "        <div class='chart-container'>",
        "            <canvas id='performanceChart'></canvas>",
        "        </div>",
        "",
        "        <!-- Cache Chart -->",
        "        <h2>💾 Статистика кешування</h2>",
        "        <div class='chart-container' style='height: 300px;'>",
        "            <canvas id='cacheChart'></canvas>",
        "        </div>",
        "",
        "        <!-- Breakdown Table -->",
        "        <h2>📋 Детальна розбивка</h2>",
        "        <table>",
        "            <thead>",
        "                <tr>",
        "                    <th>Компонент</th>",
        "                    <th>Середній час (ms)</th>",
        "                    <th>% від загального</th>",
        "                    <th>Кількість викликів</th>",
        "                </tr>",
        "            </thead>",
        "            <tbody>",
    ]
    
    # Додаємо рядки таблиці
    for item in breakdown:
        html_parts.append(
            f"                <tr><td>{item['lens']}</td><td>{item['avg_time_ms']:.2f}</td><td>{item['percentage']:.1f}%</td><td>{item['num_calls']}</td></tr>"
        )
    
    html_parts.extend([
        "            </tbody>",
        "        </table>",
        "",
        "        <!-- Recommendations -->",
        "        <h2>💡 Рекомендації щодо оптимізації</h2>",
    ])
    
    if recommendations:
        for rec in recommendations:
            priority = rec.get('priority', 'low')
            html_parts.extend([
                f"        <div class='recommendation {priority}'>",
                f"            <span class='category'>{rec.get('category', 'general')}</span>",
                f"            <span class='badge {priority}'>{priority.upper()}</span>",
                f"            <h4>{rec.get('title', 'Рекомендація')}</h4>",
                f"            <p>{rec.get('description', '')}</p>",
                f"            <div class='suggestion'><strong>Рекомендація:</strong> {rec.get('suggestion', '')}</div>",
                "        </div>",
            ])
    else:
        html_parts.append("        <p>Немає рекомендацій. Пайплайн працює оптимально!</p>")
    
    # JavaScript для графіків
    html_parts.extend([
        "    </div>",
        "    <script>",
        "        // Performance Chart",
        "        const performanceCtx = document.getElementById('performanceChart').getContext('2d');",
        "        new Chart(performanceCtx, {",
        "            type: 'bar',",
        "            data: {",
        f"                labels: {json.dumps(lens_names)},",
        "                datasets: [{",
        "                    label: 'Час виконання (ms)',",
        "                    data: " + json.dumps(lens_times) + ",",
        "                    backgroundColor: 'rgba(52, 152, 219, 0.8)',",
        "                    borderColor: 'rgba(52, 152, 219, 1)',",
        "                    borderWidth: 1",
        "                }]",
        "            },",
        "            options: {",
        "                responsive: true,",
        "                maintainAspectRatio: false,",
        "                scales: {",
        "                    y: {",
        "                        beginAtZero: true,",
        "                        title: {",
        "                            display: true,",
        "                            text: 'Час (ms)'",
        "                        }",
        "                    }",
        "                }",
        "            }",
        "        });",
        "",
        "        // Cache Chart",
        "        const cacheCtx = document.getElementById('cacheChart').getContext('2d');",
        "        new Chart(cacheCtx, {",
        "            type: 'doughnut',",
        "            data: {",
        "                labels: ['Попадання', 'Промахи'],",
        f"                datasets: [{{",
        f"                    data: [{cache_hits}, {cache_misses}],",
        "                    backgroundColor: [",
        "                        'rgba(46, 204, 113, 0.8)',",
        "                        'rgba(231, 76, 60, 0.8)'",
        "                    ],",
        "                    borderColor: [",
        "                        'rgba(46, 204, 113, 1)',",
        "                        'rgba(231, 76, 60, 1)'",
        "                    ],",
        "                    borderWidth: 2",
        "                }]",
        "            },",
        "            options: {",
        "                responsive: true,",
        "                maintainAspectRatio: false,",
        "                plugins: {",
        "                    legend: {",
        "                        position: 'bottom'",
        "                    }",
        "                }",
        "            }",
        "        });",
        "    </script>",
        "</body>",
        "</html>",
    ])
    
    html_content = "\n".join(html_parts)
    
    # Збереження у файл, якщо вказано
    if output_path:
        Path(output_path).write_text(html_content, encoding='utf-8')
    
    return html_content

