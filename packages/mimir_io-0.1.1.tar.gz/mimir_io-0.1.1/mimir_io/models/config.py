"""
Configuration management for models using YAML files.
"""

from typing import Dict, Any, Optional, Union
from pathlib import Path
import yaml
import copy


class ConfigLoader:
    """
    Loader for YAML configuration files.
    
    Supports:
    - Loading from YAML files
    - Merging multiple configs
    - Environment variable substitution
    - Default values
    """
    
    @staticmethod
    def load(path: Union[str, Path]) -> Dict[str, Any]:
        """
        Load configuration from YAML file.
        
        Args:
            path: Path to YAML file
            
        Returns:
            Configuration dictionary
            
        Example:
            config = ConfigLoader.load("configs/my_model.yaml")
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        
        with open(path, "r") as f:
            config = yaml.safe_load(f)
        
        if config is None:
            config = {}
        
        return config
    
    @staticmethod
    def save(config: Dict[str, Any], path: Union[str, Path]) -> None:
        """
        Save configuration to YAML file.
        
        Args:
            config: Configuration dictionary
            path: Path to save YAML file
            
        Example:
            ConfigLoader.save(config, "configs/my_model.yaml")
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(path, "w") as f:
            yaml.dump(config, f, default_flow_style=False, sort_keys=False)
    
    @staticmethod
    def merge(*configs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Merge multiple configuration dictionaries.
        
        Later configs override earlier ones.
        
        Args:
            *configs: Configuration dictionaries to merge
            
        Returns:
            Merged configuration dictionary
            
        Example:
            base_config = ConfigLoader.load("configs/base.yaml")
            model_config = ConfigLoader.load("configs/model.yaml")
            merged = ConfigLoader.merge(base_config, model_config)
        """
        result = {}
        for config in configs:
            if config:
                result = _deep_merge(result, copy.deepcopy(config))
        return result


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Deep merge two dictionaries."""
    result = base.copy()
    
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    
    return result


def load_config(path: Union[str, Path]) -> Dict[str, Any]:
    """
    Load configuration from YAML file.
    
    Args:
        path: Path to YAML file
        
    Returns:
        Configuration dictionary
        
    Example:
        config = load_config("configs/my_model.yaml")
    """
    return ConfigLoader.load(path)


def save_config(config: Dict[str, Any], path: Union[str, Path]) -> None:
    """
    Save configuration to YAML file.
    
    Args:
        config: Configuration dictionary
        path: Path to save YAML file
        
    Example:
        save_config(config, "configs/my_model.yaml")
    """
    ConfigLoader.save(config, path)


def merge_configs(*configs: Dict[str, Any]) -> Dict[str, Any]:
    """
    Merge multiple configuration dictionaries.
    
    Args:
        *configs: Configuration dictionaries to merge
        
    Returns:
        Merged configuration dictionary
        
    Example:
        merged = merge_configs(config1, config2, config3)
    """
    return ConfigLoader.merge(*configs)

