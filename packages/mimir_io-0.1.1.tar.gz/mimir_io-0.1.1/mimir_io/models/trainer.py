"""
Base trainer for training PyTorch models with mimir_io.
Works with any nn.Module - no special base class required.
"""

from typing import Dict, Any, Optional, Union, List
from pathlib import Path
import warnings

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader
    _torch_available = True
except ImportError:
    _torch_available = False
    torch = object  # type: ignore
    nn = object  # type: ignore
    DataLoader = object  # type: ignore

from mimir_io.models.config import load_config
from mimir_io.models.callbacks import Callback, CallbackManager, EarlyStoppingCallback
from mimir_io.models.optimizer_registry import create_optimizer, create_criterion, create_scheduler

# Import WarmupScheduler for type checking
try:
    from mimir_io.models.warmup_scheduler import WarmupScheduler
    _warmup_available = True
except ImportError:
    _warmup_available = False
    WarmupScheduler = None

# Import distributed utilities
try:
    import torch.distributed as dist
    from mimir_io.models.distributed import (
        init_distributed,
        cleanup_distributed,
        is_distributed,
        get_rank,
        get_world_size,
        is_main_process,
        setup_ddp_model,
        setup_distributed_sampler,
        get_device,
        all_reduce_mean,
        barrier,
    )
    _distributed_available = True
except ImportError:
    _distributed_available = False
    dist = None  # type: ignore
    init_distributed = None  # type: ignore
    cleanup_distributed = None  # type: ignore
    is_distributed = lambda: False  # type: ignore
    get_rank = lambda: 0  # type: ignore
    get_world_size = lambda: 1  # type: ignore
    is_main_process = lambda: True  # type: ignore
    setup_ddp_model = lambda m, d=None: m  # type: ignore
    setup_distributed_sampler = lambda *args, **kwargs: None  # type: ignore
    get_device = lambda: torch.device("cuda" if torch.cuda.is_available() else "cpu")  # type: ignore
    all_reduce_mean = lambda t: t  # type: ignore
    barrier = lambda: None  # type: ignore


class BaseTrainer:
    """
    Base trainer class for training PyTorch models.
    
    Works with any nn.Module - no special base class required.
    Configuration comes from YAML file.
    """
    
    def __init__(
        self,
        model: nn.Module,
        config: Dict[str, Any],
        train_loader: Optional[DataLoader] = None,
        val_loader: Optional[DataLoader] = None,
        device: Optional[str] = None,
        callbacks: Optional[List[Callback]] = None,
    ):
        """
        Initialize trainer.
        
        Args:
            model: PyTorch model (any nn.Module)
            config: Training configuration
            train_loader: Training DataLoader
            val_loader: Validation DataLoader
            device: Device to train on (default: auto-detect)
            callbacks: List of callbacks for training events
        """
        if not _torch_available:
            raise ImportError("PyTorch is required for training")
        
        self.model = model
        self.config = config
        self.train_loader = train_loader
        self.val_loader = val_loader
        
        # Setup distributed training
        distributed_config = config.get("training", {}).get("distributed", {})
        self.use_distributed = distributed_config.get("enabled", False) and _distributed_available
        
        if self.use_distributed:
            # Initialize distributed training
            backend = distributed_config.get("backend", "nccl")
            if not init_distributed(backend=backend):
                warnings.warn(
                    "Failed to initialize distributed training. Continuing with single GPU.",
                    UserWarning
                )
                self.use_distributed = False
            
            if is_distributed():
                # Setup device for distributed training
                self.device = get_device()
                # Wrap model with DDP
                device_id = get_rank()
                self.model = setup_ddp_model(self.model, device_id=device_id)
                self.is_main_process = is_main_process()
            else:
                self.use_distributed = False
                self.is_main_process = True
                # Fallback to single GPU
                if device is None:
                    device = "cuda" if torch.cuda.is_available() else "cpu"
                self.device = torch.device(device)
                self.model = self.model.to(self.device)
        else:
            self.is_main_process = True
            # Setup device for single GPU/CPU
            if device is None:
                device = "cuda" if torch.cuda.is_available() else "cpu"
            self.device = torch.device(device)
            self.model = self.model.to(self.device)
        
        # Training config
        self.epochs = config.get("training", {}).get("epochs", 10)
        self.save_dir = Path(config.get("training", {}).get("save_dir", "./checkpoints"))
        self.save_dir.mkdir(parents=True, exist_ok=True)
        
        # Early stopping config
        early_stopping_config = config.get("training", {}).get("early_stopping", {})
        if early_stopping_config.get("enabled", False):
            early_stopping_callback = EarlyStoppingCallback(
                monitor=early_stopping_config.get("monitor", "val_loss"),
                patience=early_stopping_config.get("patience", 5),
                min_delta=early_stopping_config.get("min_delta", 0.0),
                mode=early_stopping_config.get("mode", "min"),
                restore_best_weights=early_stopping_config.get("restore_best_weights", True),
            )
            if callbacks is None:
                callbacks = []
            callbacks.append(early_stopping_callback)
        
        # Setup callbacks
        self.callback_manager = CallbackManager(callbacks)
        
        # Flag for early stopping
        self.should_stop = False
        
        # Setup optimizer and criterion
        self._setup_optimizer()
        self._setup_criterion()
        self._setup_scheduler()
        
        # Setup gradient clipping
        self._setup_gradient_clipping()
        
        # Setup mixed precision training (AMP)
        self._setup_mixed_precision()
        
        # Determine if warmup scheduler is used
        self.use_warmup = (
            _warmup_available 
            and self.scheduler is not None 
            and isinstance(self.scheduler, WarmupScheduler)
            and not self.scheduler.warmup_finished
        )
    
    def _setup_optimizer(self) -> None:
        """Setup optimizer from config using registry."""
        opt_config = self.config.get("training", {}).get("optimizer", {})
        opt_type = opt_config.get("type", "Adam")
        
        # Видаляємо 'type' з конфігурації перед передачею в реєстр
        optimizer_config = {k: v for k, v in opt_config.items() if k != "type"}
        
        # Створюємо оптимізатор через реєстр
        self.optimizer = create_optimizer(
            name=opt_type,
            model_parameters=self.model.parameters(),
            config=optimizer_config
        )
    
    def _setup_criterion(self) -> None:
        """Setup loss criterion from config using registry."""
        criterion_config = self.config.get("training", {}).get("criterion", {})
        criterion_type = criterion_config.get("type", "CrossEntropyLoss")
        
        # Видаляємо 'type' з конфігурації перед передачею в реєстр
        criterion_params = {k: v for k, v in criterion_config.items() if k != "type"}
        
        # Створюємо критерій через реєстр
        self.criterion = create_criterion(
            name=criterion_type,
            config=criterion_params
        )
    
    def _setup_scheduler(self) -> None:
        """Setup learning rate scheduler from config using registry."""
        scheduler_config = self.config.get("training", {}).get("scheduler", {})
        
        # Якщо scheduler не налаштовано, встановлюємо None
        if not scheduler_config or not scheduler_config.get("enabled", False):
            self.scheduler = None
            return
        
        scheduler_type = scheduler_config.get("type", "StepLR")
        
        # Видаляємо 'type' та 'enabled' з конфігурації перед передачею в реєстр
        scheduler_params = {
            k: v for k, v in scheduler_config.items() 
            if k not in ("type", "enabled")
        }
        
        # Для ReduceLROnPlateau потрібен monitor (за замовчуванням val_loss)
        if scheduler_type == "ReduceLROnPlateau":
            scheduler_params.setdefault("monitor", "val_loss")
        
        # Створюємо scheduler через реєстр
        self.scheduler = create_scheduler(
            name=scheduler_type,
            optimizer=self.optimizer,
            config=scheduler_params
        )
    
    def _setup_gradient_clipping(self) -> None:
        """Setup gradient clipping from config."""
        grad_clip_config = self.config.get("training", {}).get("gradient_clipping", {})
        
        if grad_clip_config.get("enabled", False):
            self.gradient_clip_value = grad_clip_config.get("max_norm", None)
            self.gradient_clip_norm_type = grad_clip_config.get("norm_type", 2.0)
        else:
            self.gradient_clip_value = None
            self.gradient_clip_norm_type = 2.0
    
    def _setup_mixed_precision(self) -> None:
        """Setup mixed precision training (AMP) from config."""
        amp_config = self.config.get("training", {}).get("mixed_precision", {})
        
        if amp_config.get("enabled", False):
            if not torch.cuda.is_available():
                import warnings
                warnings.warn(
                    "Mixed precision training requires CUDA. Disabling AMP.",
                    UserWarning
                )
                self.use_amp = False
                self.scaler = None
            else:
                self.use_amp = True
                # Initialize GradScaler for AMP
                self.scaler = torch.cuda.amp.GradScaler(
                    init_scale=amp_config.get("init_scale", 2.0**16),
                    growth_factor=amp_config.get("growth_factor", 2.0),
                    backoff_factor=amp_config.get("backoff_factor", 0.5),
                    growth_interval=amp_config.get("growth_interval", 2000),
                )
        else:
            self.use_amp = False
            self.scaler = None
    
    def train_epoch(self) -> Dict[str, float]:
        """
        Train for one epoch.
        
        Returns:
            Dictionary with training metrics
        """
        self.model.train()
        total_loss = 0.0
        num_batches = 0
        
        if self.train_loader is None:
            raise ValueError("train_loader is not set")
        
        for batch_idx, (features, labels) in enumerate(self.train_loader):
            # Callback: on_batch_begin
            self.callback_manager.on_batch_begin(self, batch_idx)
            
            features = features.to(self.device)
            labels = labels.to(self.device)
            
            # Forward pass (with mixed precision if enabled)
            if self.use_amp:
                with torch.cuda.amp.autocast():
                    outputs = self.model(features)
                    loss = self.criterion(outputs, labels)
            else:
                outputs = self.model(features)
                loss = self.criterion(outputs, labels)
            
            # Backward pass
            self.optimizer.zero_grad()
            
            if self.use_amp:
                # Scale loss and backward pass for AMP
                self.scaler.scale(loss).backward()
                
                # Gradient clipping with AMP scaler
                if self.gradient_clip_value is not None:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(),
                        self.gradient_clip_value,
                        norm_type=self.gradient_clip_norm_type
                    )
                
                # Optimizer step with scaler
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                # Standard backward pass
                loss.backward()
                
                # Gradient clipping (standard)
                if self.gradient_clip_value is not None:
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(),
                        self.gradient_clip_value,
                        norm_type=self.gradient_clip_norm_type
                    )
                
                self.optimizer.step()
            
            loss_value = loss.item()
            
            # Aggregate loss across all processes in distributed training
            if self.use_distributed and is_distributed() and dist is not None:
                loss_tensor = torch.tensor(loss_value, device=self.device)
                loss_tensor = all_reduce_mean(loss_tensor)
                loss_value = loss_tensor.item()
            
            total_loss += loss_value
            num_batches += 1
            
            # If warmup scheduler is used, call step after each batch
            if self.use_warmup and self.scheduler is not None:
                # For warmup call step without parameters (step-based warmup)
                self.scheduler.step()
                # Check if warmup is finished
                if self.scheduler.warmup_finished:
                    self.use_warmup = False
            
            # Callback: on_batch_end
            self.callback_manager.on_batch_end(self, batch_idx, loss_value)
        
        metrics = {
            "train_loss": total_loss / num_batches if num_batches > 0 else 0.0,
        }
        
        # Add learning rate to metrics if scheduler is available
        if self.scheduler is not None:
            metrics["learning_rate"] = self.optimizer.param_groups[0]["lr"]
        
        return metrics
    
    def validate(self) -> Dict[str, float]:
        """
        Validate model.
        
        Returns:
            Dictionary with validation metrics
        """
        self.model.eval()
        total_loss = 0.0
        correct = 0
        total = 0
        num_batches = 0
        
        if self.val_loader is None:
            return {}
        
        with torch.no_grad():
            for features, labels in self.val_loader:
                features = features.to(self.device)
                labels = labels.to(self.device)
                
                outputs = self.model(features)
                loss = self.criterion(outputs, labels)
                
                total_loss += loss.item()
                num_batches += 1
                
                # Calculate accuracy (for classification)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
        
        # Aggregate metrics across all processes in distributed training
        if self.use_distributed and is_distributed() and dist is not None:
            # All-reduce loss and accuracy
            loss_tensor = torch.tensor(total_loss / num_batches if num_batches > 0 else 0.0, device=self.device)
            correct_tensor = torch.tensor(correct, device=self.device)
            total_tensor = torch.tensor(total, device=self.device)
            
            loss_tensor = all_reduce_mean(loss_tensor)
            dist.all_reduce(correct_tensor, op=dist.ReduceOp.SUM)
            dist.all_reduce(total_tensor, op=dist.ReduceOp.SUM)
            
            metrics = {
                "val_loss": loss_tensor.item(),
            }
            
            if total_tensor.item() > 0:
                metrics["val_accuracy"] = 100.0 * correct_tensor.item() / total_tensor.item()
        else:
            metrics = {
                "val_loss": total_loss / num_batches if num_batches > 0 else 0.0,
            }
            
            if total > 0:
                metrics["val_accuracy"] = 100.0 * correct / total
        
        return metrics
    
    def train(self) -> None:
        """
        Full training loop with callbacks support.
        """
        best_val_loss = float("inf")
        self.should_stop = False
        
        # Callback: on_train_begin
        self.callback_manager.on_train_begin(self)
        
        # Setup progress bar with tqdm
        try:
            from tqdm.auto import tqdm  # Автоматично вибирає notebook або console
            _tqdm_available = True
        except ImportError:
            _tqdm_available = False
            tqdm = None
        
        # Get warmup info callback if available
        warmup_callback = None
        for callback in self.callback_manager.callbacks:
            try:
                from mimir_io.models.callbacks import WarmupInfoCallback
                if isinstance(callback, WarmupInfoCallback):
                    warmup_callback = callback
                    break
            except ImportError:
                pass
        
        try:
            # Create progress bar for epochs
            if _tqdm_available:
                epochs_pbar = tqdm(
                    range(self.epochs),
                    desc="Training",
                    unit="epoch",
                    bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]',
                )
            else:
                epochs_pbar = None
            
            for epoch in range(self.epochs):
                # Callback: on_epoch_begin
                self.callback_manager.on_epoch_begin(self, epoch)
                
                # Set epoch for dataset (if it has set_epoch method)
                if self.train_loader and hasattr(self.train_loader.dataset, "set_epoch"):
                    self.train_loader.dataset.set_epoch(epoch)
                
                # Train
                train_metrics = self.train_epoch()
                
                # Validate
                val_metrics = self.validate()
                
                # Combine metrics
                all_metrics = {**train_metrics, **val_metrics}
                
                # Update progress bar with metrics and warmup info
                if epochs_pbar is not None:
                    # Build postfix with metrics
                    postfix = {
                        "loss": f"{train_metrics['train_loss']:.4f}",
                    }
                    if "learning_rate" in train_metrics:
                        postfix["lr"] = f"{train_metrics['learning_rate']:.2e}"
                    if val_metrics:
                        postfix["val_loss"] = f"{val_metrics.get('val_loss', 0):.4f}"
                        if "val_accuracy" in val_metrics:
                            postfix["val_acc"] = f"{val_metrics['val_accuracy']:.2f}%"
                    
                    epochs_pbar.set_postfix(postfix)
                    
                    # Add warmup info to description if available
                    if warmup_callback:
                        warmup_str = warmup_callback.get_warmup_info_string()
                        if warmup_str:
                            epochs_pbar.set_description_str(f"Training | {warmup_str}")
                    
                    epochs_pbar.update(1)
                else:
                    # Print metrics if no progress bar
                    print(f"Epoch {epoch + 1}/{self.epochs}:")
                    print(f"  Train Loss: {train_metrics['train_loss']:.4f}")
                    if "learning_rate" in train_metrics:
                        print(f"  Learning Rate: {train_metrics['learning_rate']:.6f}")
                    if val_metrics:
                        print(f"  Val Loss: {val_metrics.get('val_loss', 0):.4f}")
                        if "val_accuracy" in val_metrics:
                            print(f"  Val Accuracy: {val_metrics['val_accuracy']:.2f}%")
                    
                    # Print warmup info if available
                    if warmup_callback:
                        warmup_str = warmup_callback.get_warmup_info_string()
                        if warmup_str:
                            print(f"  {warmup_str}")
                
                # Update scheduler
                if self.scheduler is not None:
                    # If warmup hasn't finished and epoch-based warmup is used
                    if self.use_warmup and self.scheduler.warmup_steps is None:
                        # Epoch-based warmup - call step with epoch
                        self.scheduler.step(epoch=epoch)
                        if self.scheduler.warmup_finished:
                            self.use_warmup = False
                    else:
                        # After warmup or if warmup is not used
                        # ReduceLROnPlateau requires metric for step()
                        if isinstance(self.scheduler, WarmupScheduler):
                            # WarmupScheduler handles ReduceLROnPlateau internally
                            base_scheduler = self.scheduler.base_scheduler
                            if isinstance(base_scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                                monitor = self.config.get("training", {}).get("scheduler", {}).get("monitor", "val_loss")
                                metric_value = all_metrics.get(monitor, None)
                                if metric_value is not None:
                                    self.scheduler.step(epoch=epoch, metric=metric_value)
                            else:
                                self.scheduler.step(epoch=epoch)
                        elif isinstance(self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                            monitor = self.config.get("training", {}).get("scheduler", {}).get("monitor", "val_loss")
                            metric_value = all_metrics.get(monitor, None)
                            if metric_value is not None:
                                self.scheduler.step(metric_value)
                        else:
                            self.scheduler.step()
                
                # Save checkpoint (only on main process in distributed training)
                if self.is_main_process:
                    val_loss = val_metrics.get("val_loss", float("inf"))
                    if val_loss < best_val_loss:
                        best_val_loss = val_loss
                        self.save_checkpoint(epoch, is_best=True)
                    else:
                        self.save_checkpoint(epoch, is_best=False)
                
                # Synchronize all processes before next epoch
                if self.use_distributed:
                    barrier()
                
                # Callback: on_epoch_end
                self.callback_manager.on_epoch_end(self, epoch, all_metrics)
                
                # Check for early stopping
                if self.should_stop:
                    break
            
            # Close progress bar
            if epochs_pbar is not None:
                epochs_pbar.close()
        finally:
            # Callback: on_train_end
            self.callback_manager.on_train_end(self)
            
            # Cleanup distributed training
            if self.use_distributed and _distributed_available:
                cleanup_distributed()
    
    def load_checkpoint(self, checkpoint_path: Union[str, Path], resume_training: bool = False) -> None:
        """
        Load model checkpoint.
        
        Args:
            checkpoint_path: Path to checkpoint file
            resume_training: If True, also loads optimizer and scheduler state
        """
        checkpoint_path = Path(checkpoint_path)
        if not checkpoint_path.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
        
        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        
        # Load model state
        if "model_state_dict" in checkpoint:
            self.model.load_state_dict(checkpoint["model_state_dict"])
        elif "state_dict" in checkpoint:
            self.model.load_state_dict(checkpoint["state_dict"])
        else:
            # Assume the checkpoint is the state dict itself
            self.model.load_state_dict(checkpoint)
        
        if resume_training:
            # Load optimizer state
            if "optimizer_state_dict" in checkpoint:
                self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
            
            # Load scheduler state
            if "scheduler_state_dict" in checkpoint and self.scheduler is not None:
                self.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
                # Restore warmup state
                if isinstance(self.scheduler, WarmupScheduler):
                    self.use_warmup = checkpoint.get("use_warmup", False) and not self.scheduler.warmup_finished
            
            # Load scaler state for mixed precision
            if "scaler_state_dict" in checkpoint and self.use_amp and self.scaler is not None:
                self.scaler.load_state_dict(checkpoint["scaler_state_dict"])
        
        print(f"Loaded checkpoint from {checkpoint_path}")
        if "epoch" in checkpoint:
            print(f"  Epoch: {checkpoint['epoch']}")
    
    def save_checkpoint(self, epoch: int, is_best: bool = False) -> None:
        """
        Save model checkpoint.
        
        Args:
            epoch: Current epoch
            is_best: Whether this is the best model so far
        """
        # Get model state dict (unwrap DDP if needed)
        if self.use_distributed and hasattr(self.model, "module"):
            model_state_dict = self.model.module.state_dict()
        else:
            model_state_dict = self.model.state_dict()
        
        checkpoint = {
            "epoch": epoch,
            "model_state_dict": model_state_dict,
            "optimizer_state_dict": self.optimizer.state_dict(),
            "config": self.config,
        }
        
        # Add scheduler state if available
        if self.scheduler is not None:
            checkpoint["scheduler_state_dict"] = self.scheduler.state_dict()
            # Add warmup information for restoration
            if isinstance(self.scheduler, WarmupScheduler):
                checkpoint["use_warmup"] = self.use_warmup
        
        # Add scaler state for mixed precision if used
        if self.use_amp and self.scaler is not None:
            checkpoint["scaler_state_dict"] = self.scaler.state_dict()
        
        # Save regular checkpoint
        checkpoint_path = self.save_dir / f"checkpoint_epoch_{epoch + 1}.pt"
        torch.save(checkpoint, checkpoint_path)
        
        # Save best model
        if is_best:
            best_path = self.save_dir / "best_model.pt"
            torch.save(checkpoint, best_path)
            print(f"  Saved best model to {best_path}")
    
    @classmethod
    def from_config(
        cls,
        config_path: Union[str, Path],
        model: nn.Module,
        train_loader: Optional[DataLoader] = None,
        val_loader: Optional[DataLoader] = None,
        callbacks: Optional[List[Callback]] = None,
    ) -> "BaseTrainer":
        """
        Create trainer from config file.
        
        Args:
            config_path: Path to YAML config file
            model: Model instance (any nn.Module)
            train_loader: Training DataLoader
            val_loader: Validation DataLoader
            callbacks: List of callbacks
            
        Returns:
            Trainer instance
        """
        config = load_config(config_path)
        return cls(model, config, train_loader, val_loader, callbacks=callbacks)
