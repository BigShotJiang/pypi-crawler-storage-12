"""
Base tester for evaluating PyTorch models with mimir_io.
Works with any nn.Module - no special base class required.
"""

from typing import Dict, Any, Optional, Union, List
from pathlib import Path

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader
    _torch_available = True
except ImportError:
    _torch_available = False
    torch = object  # type: ignore
    nn = object  # type: ignore
    DataLoader = object  # type: ignore

from mimir_io.models.config import load_config
from mimir_io.models.callbacks import Callback, CallbackManager
from mimir_io.models.optimizer_registry import create_criterion


class BaseTester:
    """
    Base tester class for evaluating PyTorch models.
    
    Works with any nn.Module - no special base class required.
    Provides declarative testing similar to BaseTrainer for training.
    """
    
    def __init__(
        self,
        model: nn.Module,
        config: Optional[Dict[str, Any]] = None,
        test_loader: Optional[DataLoader] = None,
        device: Optional[str] = None,
        callbacks: Optional[List[Callback]] = None,
        checkpoint_path: Optional[Union[str, Path]] = None,
    ):
        """
        Initialize tester.
        
        Args:
            model: PyTorch model (any nn.Module)
            config: Testing configuration (optional, can be empty dict)
            test_loader: Test DataLoader
            device: Device to test on (default: auto-detect)
            callbacks: List of callbacks for testing events
            checkpoint_path: Path to checkpoint to load model weights from
        """
        if not _torch_available:
            raise ImportError("PyTorch is required for testing")
        
        self.model = model
        self.config = config or {}
        self.test_loader = test_loader
        
        # Setup device
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = torch.device(device)
        self.model = self.model.to(self.device)
        
        # Load checkpoint if specified
        if checkpoint_path:
            self.load_checkpoint(checkpoint_path)
        
        # Setup callbacks
        self.callback_manager = CallbackManager(callbacks)
        
        # Setup criterion if specified in config
        self.criterion = None
        criterion_config = self.config.get("testing", {}).get("criterion", {})
        if criterion_config:
            self._setup_criterion(criterion_config)
    
    def _setup_criterion(self, criterion_config: Dict[str, Any]) -> None:
        """Setup loss criterion from config using registry."""
        criterion_type = criterion_config.get("type", "CrossEntropyLoss")
        
        # Видаляємо 'type' з конфігурації перед передачею в реєстр
        criterion_params = {k: v for k, v in criterion_config.items() if k != "type"}
        
        # Створюємо критерій через реєстр
        self.criterion = create_criterion(
            name=criterion_type,
            config=criterion_params
        )
    
    def load_checkpoint(self, checkpoint_path: Union[str, Path]) -> None:
        """
        Load model weights from checkpoint.
        
        Args:
            checkpoint_path: Path to checkpoint file
        """
        checkpoint_path = Path(checkpoint_path)
        if not checkpoint_path.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
        
        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        
        # Handle different checkpoint formats
        if "model_state_dict" in checkpoint:
            self.model.load_state_dict(checkpoint["model_state_dict"])
        elif "state_dict" in checkpoint:
            self.model.load_state_dict(checkpoint["state_dict"])
        else:
            # Assume the checkpoint is the state dict itself
            self.model.load_state_dict(checkpoint)
        
        print(f"Loaded checkpoint from {checkpoint_path}")
    
    def test(self) -> Dict[str, float]:
        """
        Run full test evaluation.
        
        Returns:
            Dictionary with test metrics
        """
        if self.test_loader is None:
            raise ValueError("test_loader is not set")
        
        # Callback: on_test_begin
        self.callback_manager.on_test_begin(self)
        
        try:
            metrics = self.test_epoch()
            
            # Callback: on_test_end
            self.callback_manager.on_test_end(self, metrics)
            
            return metrics
        except Exception as e:
            # Callback: on_test_end even on error
            self.callback_manager.on_test_end(self, {})
            raise
    
    def test_epoch(self) -> Dict[str, float]:
        """
        Test for one pass through the test dataset.
        
        Returns:
            Dictionary with test metrics
        """
        self.model.eval()
        total_loss = 0.0
        correct = 0
        total = 0
        num_batches = 0
        
        # Collect all predictions and labels for detailed metrics
        all_predictions = []
        all_labels = []
        all_probabilities = []
        
        if self.test_loader is None:
            raise ValueError("test_loader is not set")
        
        with torch.no_grad():
            for batch_idx, (features, labels) in enumerate(self.test_loader):
                # Callback: on_batch_begin
                self.callback_manager.on_batch_begin(self, batch_idx)
                
                features = features.to(self.device)
                labels = labels.to(self.device)
                
                # Forward pass
                outputs = self.model(features)
                
                # Calculate loss if criterion is set
                loss_value = 0.0
                if self.criterion is not None:
                    loss = self.criterion(outputs, labels)
                    loss_value = loss.item()
                    total_loss += loss_value
                
                num_batches += 1
                
                # Calculate accuracy (for classification)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
                
                # Collect predictions for detailed metrics
                all_predictions.extend(predicted.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
                if outputs.dim() > 1:
                    probs = torch.softmax(outputs, dim=1)
                    all_probabilities.extend(probs.cpu().numpy())
                
                # Callback: on_batch_end
                self.callback_manager.on_batch_end(self, batch_idx, loss_value)
        
        # Build metrics dictionary
        metrics = {}
        
        if self.criterion is not None and num_batches > 0:
            metrics["test_loss"] = total_loss / num_batches
        
        if total > 0:
            metrics["test_accuracy"] = 100.0 * correct / total
        
        # Store detailed predictions for callbacks
        metrics["_predictions"] = all_predictions
        metrics["_labels"] = all_labels
        if all_probabilities:
            metrics["_probabilities"] = all_probabilities
        
        return metrics
    
    def predict(self, features: torch.Tensor) -> torch.Tensor:
        """
        Make predictions on a batch of features.
        
        Args:
            features: Input features tensor
            
        Returns:
            Model predictions
        """
        self.model.eval()
        features = features.to(self.device)
        
        with torch.no_grad():
            outputs = self.model(features)
        
        return outputs
    
    def predict_batch(self, dataloader: Optional[DataLoader] = None) -> List[torch.Tensor]:
        """
        Make predictions on entire dataset.
        
        Args:
            dataloader: DataLoader to use (default: self.test_loader)
            
        Returns:
            List of prediction tensors for each batch
        """
        if dataloader is None:
            dataloader = self.test_loader
        
        if dataloader is None:
            raise ValueError("dataloader is not set")
        
        self.model.eval()
        predictions = []
        
        with torch.no_grad():
            for features, _ in dataloader:
                features = features.to(self.device)
                outputs = self.model(features)
                predictions.append(outputs.cpu())
        
        return predictions
    
    @classmethod
    def from_config(
        cls,
        config_path: Union[str, Path],
        model: nn.Module,
        test_loader: Optional[DataLoader] = None,
        checkpoint_path: Optional[Union[str, Path]] = None,
        callbacks: Optional[List[Callback]] = None,
    ) -> "BaseTester":
        """
        Create tester from config file.
        
        Args:
            config_path: Path to YAML config file
            model: Model instance (any nn.Module)
            test_loader: Test DataLoader
            checkpoint_path: Path to checkpoint file
            callbacks: List of callbacks
            
        Returns:
            Tester instance
        """
        config = load_config(config_path)
        return cls(
            model=model,
            config=config,
            test_loader=test_loader,
            checkpoint_path=checkpoint_path,
            callbacks=callbacks,
        )

