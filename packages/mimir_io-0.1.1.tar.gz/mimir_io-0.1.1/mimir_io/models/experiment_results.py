"""
System for storing and loading experiment results.

Allows saving experiment configurations, training metrics, and benchmark results
for later comparison and analysis.
"""

from typing import Dict, Any, Optional, List, Union
from pathlib import Path
import json
from datetime import datetime
import hashlib


class ExperimentResult:
    """
    Container for experiment results.
    
    Stores configuration, training metrics, benchmark results, and metadata.
    """
    
    def __init__(
        self,
        experiment_name: str,
        config: Dict[str, Any],
        training_metrics: Optional[Dict[str, Any]] = None,
        benchmark_results: Optional[Dict[str, Dict[str, Any]]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        timestamp: Optional[str] = None,
    ):
        """
        Initialize experiment result.
        
        Args:
            experiment_name: Name of the experiment
            config: Experiment configuration
            training_metrics: Training metrics (loss, accuracy per epoch, etc.)
            benchmark_results: Benchmark results
            metadata: Additional metadata (model path, checkpoint path, etc.)
            timestamp: Timestamp of experiment (default: current time)
        """
        self.experiment_name = experiment_name
        self.config = config
        self.training_metrics = training_metrics or {}
        self.benchmark_results = benchmark_results or {}
        self.metadata = metadata or {}
        self.timestamp = timestamp or datetime.now().isoformat()
        
        # Generate unique ID from config and timestamp
        self.experiment_id = self._generate_id()
    
    def _generate_id(self) -> str:
        """Generate unique experiment ID."""
        config_str = json.dumps(self.config, sort_keys=True, default=str)
        combined = f"{self.experiment_name}:{config_str}:{self.timestamp}"
        return hashlib.sha256(combined.encode()).hexdigest()[:16]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "experiment_name": self.experiment_name,
            "experiment_id": self.experiment_id,
            "timestamp": self.timestamp,
            "config": self.config,
            "training_metrics": self.training_metrics,
            "benchmark_results": self.benchmark_results,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ExperimentResult":
        """Create from dictionary."""
        return cls(
            experiment_name=data["experiment_name"],
            config=data["config"],
            training_metrics=data.get("training_metrics"),
            benchmark_results=data.get("benchmark_results"),
            metadata=data.get("metadata"),
            timestamp=data.get("timestamp"),
        )
    
    def save(self, results_dir: Union[str, Path]) -> Path:
        """
        Save experiment result to file.
        
        Args:
            results_dir: Directory to save results
            
        Returns:
            Path to saved file
        """
        results_dir = Path(results_dir)
        results_dir.mkdir(parents=True, exist_ok=True)
        
        # Create filename from experiment name and timestamp
        safe_name = "".join(c if c.isalnum() or c in ('-', '_') else '_' for c in self.experiment_name)
        filename = f"{safe_name}_{self.experiment_id}.json"
        filepath = results_dir / filename
        
        # Save to JSON
        with open(filepath, "w") as f:
            json.dump(self.to_dict(), f, indent=2, default=str)
        
        return filepath
    
    @classmethod
    def load(cls, filepath: Union[str, Path]) -> "ExperimentResult":
        """
        Load experiment result from file.
        
        Args:
            filepath: Path to result file
            
        Returns:
            ExperimentResult instance
        """
        filepath = Path(filepath)
        if not filepath.exists():
            raise FileNotFoundError(f"Result file not found: {filepath}")
        
        with open(filepath, "r") as f:
            data = json.load(f)
        
        return cls.from_dict(data)


class ExperimentResultsManager:
    """
    Manager for storing and loading experiment results.
    
    Provides methods to save, load, and query experiment results.
    """
    
    def __init__(self, results_dir: Union[str, Path] = "./experiment_results"):
        """
        Initialize results manager.
        
        Args:
            results_dir: Directory for storing results
        """
        self.results_dir = Path(results_dir)
        self.results_dir.mkdir(parents=True, exist_ok=True)
    
    def save_result(self, result: ExperimentResult) -> Path:
        """
        Save experiment result.
        
        Args:
            result: ExperimentResult to save
            
        Returns:
            Path to saved file
        """
        return result.save(self.results_dir)
    
    def load_result(self, filepath: Union[str, Path]) -> ExperimentResult:
        """
        Load experiment result.
        
        Args:
            filepath: Path to result file or experiment ID
            
        Returns:
            ExperimentResult instance
        """
        filepath = Path(filepath)
        
        # If it's an ID, search for the file
        if not filepath.exists() and len(filepath.name) == 16:
            # Try to find by ID
            for result_file in self.results_dir.glob("*.json"):
                try:
                    result = ExperimentResult.load(result_file)
                    if result.experiment_id == filepath.name:
                        return result
                except Exception:
                    continue
            raise FileNotFoundError(f"Result with ID '{filepath.name}' not found")
        
        return ExperimentResult.load(filepath)
    
    def list_results(self) -> List[ExperimentResult]:
        """
        List all saved experiment results.
        
        Returns:
            List of ExperimentResult instances
        """
        results = []
        for result_file in self.results_dir.glob("*.json"):
            try:
                result = ExperimentResult.load(result_file)
                results.append(result)
            except Exception as e:
                print(f"Warning: Failed to load {result_file}: {e}")
        
        # Sort by timestamp (newest first)
        results.sort(key=lambda r: r.timestamp, reverse=True)
        return results
    
    def get_result_by_name(self, experiment_name: str) -> Optional[ExperimentResult]:
        """
        Get latest result by experiment name.
        
        Args:
            experiment_name: Name of experiment
            
        Returns:
            Latest ExperimentResult with given name, or None if not found
        """
        results = [r for r in self.list_results() if r.experiment_name == experiment_name]
        if not results:
            return None
        # Return newest
        return max(results, key=lambda r: r.timestamp)
    
    def get_results_by_name(self, experiment_name: str) -> List[ExperimentResult]:
        """
        Get all results by experiment name.
        
        Args:
            experiment_name: Name of experiment
            
        Returns:
            List of ExperimentResult instances
        """
        return [r for r in self.list_results() if r.experiment_name == experiment_name]
    
    def delete_result(self, filepath: Union[str, Path]) -> None:
        """
        Delete experiment result.
        
        Args:
            filepath: Path to result file or experiment ID
        """
        filepath = Path(filepath)
        
        # If it's an ID, find the file
        if not filepath.exists() and len(filepath.name) == 16:
            for result_file in self.results_dir.glob("*.json"):
                try:
                    result = ExperimentResult.load(result_file)
                    if result.experiment_id == filepath.name:
                        filepath = result_file
                        break
                except Exception:
                    continue
        
        if filepath.exists():
            filepath.unlink()
        else:
            raise FileNotFoundError(f"Result file not found: {filepath}")

