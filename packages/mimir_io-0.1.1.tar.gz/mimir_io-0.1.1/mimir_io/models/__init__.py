"""
Model management system with YAML configs and decorators.

Provides a clean way to manage PyTorch models without requiring special base classes.
Models remain regular nn.Module - just register them with decorators!
"""

from mimir_io.models.registry import (
    register_model,
    get_model,
    create_model,
    list_models,
    has_model,
    ModelRegistry,
)
from mimir_io.models.optimizer_registry import (
    register_optimizer,
    register_criterion,
    get_optimizer_factory,
    get_criterion_factory,
    create_optimizer,
    create_criterion,
    list_optimizers,
    list_criteria,
    has_optimizer,
    has_criterion,
    OptimizerRegistry,
    CriterionRegistry,
)
from mimir_io.models.config import (
    load_config,
    save_config,
    ConfigLoader,
    merge_configs,
)

# Trainer (optional, requires torch)
try:
    from mimir_io.models.trainer import BaseTrainer
    _trainer_available = True
except ImportError:
    _trainer_available = False

# Tester (optional, requires torch)
try:
    from mimir_io.models.tester import BaseTester
    _tester_available = True
except ImportError:
    _tester_available = False

# Callbacks (optional, requires torch)
try:
    from mimir_io.models.callbacks import (
        Callback,
        CallbackManager,
        EarlyStoppingCallback,
        ImageMetricsCallback,
        CSVLoggerCallback,
        WarmupInfoCallback,
        TensorBoardCallback,
        WandBCallback,
    )
    _callbacks_available = True
except ImportError:
    _callbacks_available = False

# Benchmarks (optional, requires torch)
try:
    from mimir_io.models.benchmark import (
        Benchmark,
        BenchmarkRegistry,
        register_benchmark,
        get_benchmark,
        list_benchmarks,
        has_benchmark,
        run_benchmarks,
    )
    _benchmarks_available = True
except ImportError:
    _benchmarks_available = False

# Experiment Results (optional, requires torch)
try:
    from mimir_io.models.experiment_results import (
        ExperimentResult,
        ExperimentResultsManager,
    )
    _experiment_results_available = True
except ImportError:
    _experiment_results_available = False

# Experiment Comparison (optional, requires torch and pandas)
try:
    from mimir_io.models.compare_experiments import (
        ExperimentComparator,
        compare_experiments,
    )
    _experiment_comparison_available = True
except ImportError:
    _experiment_comparison_available = False

# Distributed Training (optional, requires torch)
try:
    from mimir_io.models.distributed import (
        init_distributed,
        cleanup_distributed,
        is_distributed,
        get_rank,
        get_world_size,
        is_main_process,
        setup_ddp_model,
        setup_distributed_sampler,
        get_device,
        all_reduce_mean,
        barrier,
        get_ddp_config,
    )
    _distributed_available = True
except ImportError:
    _distributed_available = False

__all__ = [
    "register_model",
    "get_model",
    "create_model",
    "list_models",
    "has_model",
    "ModelRegistry",
    "register_optimizer",
    "register_criterion",
    "get_optimizer_factory",
    "get_criterion_factory",
    "create_optimizer",
    "create_criterion",
    "list_optimizers",
    "list_criteria",
    "has_optimizer",
    "has_criterion",
    "OptimizerRegistry",
    "CriterionRegistry",
    "load_config",
    "save_config",
    "ConfigLoader",
    "merge_configs",
]

if _trainer_available:
    __all__.append("BaseTrainer")

if _tester_available:
    __all__.append("BaseTester")

if _callbacks_available:
    __all__.extend([
        "Callback",
        "CallbackManager",
        "EarlyStoppingCallback",
        "ImageMetricsCallback",
        "CSVLoggerCallback",
        "WarmupInfoCallback",
        "TensorBoardCallback",
        "WandBCallback",
    ])

if _benchmarks_available:
    __all__.extend([
        "Benchmark",
        "BenchmarkRegistry",
        "register_benchmark",
        "get_benchmark",
        "list_benchmarks",
        "has_benchmark",
        "run_benchmarks",
    ])

if _experiment_results_available:
    __all__.extend([
        "ExperimentResult",
        "ExperimentResultsManager",
    ])

if _experiment_comparison_available:
    __all__.extend([
        "ExperimentComparator",
        "compare_experiments",
    ])

if _distributed_available:
    __all__.extend([
        "init_distributed",
        "cleanup_distributed",
        "is_distributed",
        "get_rank",
        "get_world_size",
        "is_main_process",
        "setup_ddp_model",
        "setup_distributed_sampler",
        "get_device",
        "all_reduce_mean",
        "barrier",
        "get_ddp_config",
        "launch_distributed",
    ])
