"""
Model registry for managing PyTorch models with decorators and type hints.
"""

from typing import Dict, Type, Callable, Any, Optional, get_type_hints, get_origin, get_args
from functools import wraps
import inspect

try:
    import torch.nn as nn
    _torch_available = True
except ImportError:
    _torch_available = False
    nn = object  # type: ignore


class ModelRegistry:
    """
    Registry for PyTorch model classes.
    
    Models are registered using the @register_model decorator
    and can be retrieved by name. Models remain regular nn.Module.
    """
    
    def __init__(self):
        self._models: Dict[str, Type[nn.Module]] = {}
        self._model_factories: Dict[str, Callable] = {}
        self._model_config_types: Dict[str, Any] = {}
    
    def register(
        self,
        name: str,
        model_class: Type[nn.Module],
        config_type: Optional[Any] = None,
    ) -> None:
        """
        Register a model class.
        
        Args:
            name: Unique model name
            model_class: Model class (must be nn.Module)
            config_type: Optional type hint for configuration (dataclass, TypedDict, etc.)
        """
        if not _torch_available:
            raise ImportError("PyTorch is required for model registry")
        
        if not issubclass(model_class, nn.Module):
            raise TypeError(f"Model {name} must be a PyTorch nn.Module")
        
        if name in self._models:
            raise ValueError(f"Model {name} is already registered")
        
        self._models[name] = model_class
        
        # Extract config type from __init__ signature if not provided
        if config_type is None:
            config_type = self._extract_config_type(model_class)
        
        if config_type:
            self._model_config_types[name] = config_type
    
    def _extract_config_type(self, model_class: Type[nn.Module]) -> Optional[Any]:
        """Extract config type from __init__ signature."""
        try:
            hints = get_type_hints(model_class.__init__)
            # Look for config parameter
            if 'config' in hints:
                return hints['config']
            # Or check first parameter after self
            sig = inspect.signature(model_class.__init__)
            params = list(sig.parameters.values())[1:]  # Skip self
            if params:
                param = params[0]
                if param.annotation != inspect.Parameter.empty:
                    return param.annotation
        except Exception:
            pass
        return None
    
    def get(self, name: str) -> Type[nn.Module]:
        """
        Get model class by name.
        
        Args:
            name: Model name
            
        Returns:
            Model class
            
        Raises:
            KeyError: If model not found
        """
        if name not in self._models:
            available = ", ".join(self._models.keys())
            raise KeyError(
                f"Model '{name}' not found. Available models: {available}"
            )
        return self._models[name]
    
    def create(
        self,
        name: str,
        config: Optional[Dict[str, Any]] = None,
    ) -> nn.Module:
        """
        Create model instance by name.
        
        Args:
            name: Model name
            config: Configuration dictionary
            
        Returns:
            Model instance
        """
        model_class = self.get(name)
        
        if config is None:
            config = {}
        
        # Try to instantiate with config
        try:
            # Check if model accepts config parameter
            sig = inspect.signature(model_class.__init__)
            params = list(sig.parameters.values())[1:]  # Skip self
            
            if params and 'config' in [p.name for p in params]:
                return model_class(config)
            else:
                # Unpack config as kwargs
                return model_class(**config)
        except Exception as e:
            raise ValueError(
                f"Failed to create model '{name}' with config {config}: {e}"
            )
    
    def list(self) -> list[str]:
        """
        List all registered model names.
        
        Returns:
            List of model names
        """
        return list(self._models.keys())
    
    def has(self, name: str) -> bool:
        """
        Check if model is registered.
        
        Args:
            name: Model name
            
        Returns:
            True if registered, False otherwise
        """
        return name in self._models


# Global registry instance
_registry = ModelRegistry()


def register_model(
    name: Optional[str] = None,
    config_type: Optional[Any] = None,
) -> Callable:
    """
    Decorator to register a PyTorch model class.
    
    Models remain regular nn.Module - no inheritance required!
    
    Args:
        name: Model name (defaults to class name)
        config_type: Optional type hint for configuration
    
    Example:
        @register_model("my_model")
        class MyModel(nn.Module):
            def __init__(self, n_classes: int = 10, hidden_dim: int = 128):
                super().__init__()
                self.fc = nn.Linear(hidden_dim, n_classes)
            
            def forward(self, x):
                return self.fc(x)
        
        # Or with type hints:
        from typing import TypedDict
        
        class MyModelConfig(TypedDict):
            n_classes: int
            hidden_dim: int
        
        @register_model("my_model", config_type=MyModelConfig)
        class MyModel(nn.Module):
            def __init__(self, config: MyModelConfig):
                super().__init__()
                self.fc = nn.Linear(config["hidden_dim"], config["n_classes"])
    """
    def decorator(model_class: Type[nn.Module]) -> Type[nn.Module]:
        model_name = name or model_class.__name__
        _registry.register(model_name, model_class, config_type)
        
        # Add registry reference to class
        model_class._registry = _registry  # type: ignore
        model_class._model_name = model_name  # type: ignore
        
        return model_class
    
    return decorator


def get_model(name: str) -> Type[nn.Module]:
    """
    Get model class by name.
    
    Args:
        name: Model name
        
    Returns:
        Model class
        
    Example:
        ModelClass = get_model("my_model")
        model = ModelClass(n_classes=10)
    """
    return _registry.get(name)


def create_model(
    name: str,
    config: Optional[Dict[str, Any]] = None,
) -> nn.Module:
    """
    Create model instance by name.
    
    Args:
        name: Model name
        config: Configuration dictionary (passed as kwargs or config parameter)
        
    Returns:
        Model instance
        
    Example:
        model = create_model("my_model", config={"n_classes": 10, "hidden_dim": 128})
    """
    return _registry.create(name, config)


def list_models() -> list[str]:
    """
    List all registered model names.
    
    Returns:
        List of model names
        
    Example:
        models = list_models()
        print(f"Available models: {models}")
    """
    return _registry.list()


def has_model(name: str) -> bool:
    """
    Check if model is registered.
    
    Args:
        name: Model name
        
    Returns:
        True if registered, False otherwise
    """
    return _registry.has(name)
