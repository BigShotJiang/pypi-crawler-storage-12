"""
Distributed training utilities for multi-GPU and multi-node training.

Provides DDP (Distributed Data Parallel) support for mimir_io.
"""

import os
from typing import Optional, List
import warnings

try:
    import torch
    import torch.distributed as dist
    import torch.nn as nn
    from torch.nn.parallel import DistributedDataParallel as DDP
    from torch.utils.data import DataLoader, DistributedSampler
    _torch_available = True
except ImportError:
    _torch_available = False
    torch = None  # type: ignore
    dist = None  # type: ignore
    nn = None  # type: ignore
    DDP = None  # type: ignore
    DistributedSampler = None  # type: ignore


def init_distributed(
    backend: str = "nccl",
    init_method: Optional[str] = None,
    world_size: Optional[int] = None,
    rank: Optional[int] = None,
) -> bool:
    """
    Initialize distributed training environment.
    
    Args:
        backend: Distributed backend ('nccl' for GPU, 'gloo' for CPU)
        init_method: Initialization method (default: 'env://' uses environment variables)
        world_size: Total number of processes (default: from environment)
        rank: Process rank (default: from environment)
        
    Returns:
        True if distributed training is initialized, False otherwise
        
    Example:
        >>> if init_distributed():
        ...     print(f"Rank {get_rank()}, World Size {get_world_size()}")
    """
    if not _torch_available:
        return False
    
    if not torch.cuda.is_available():
        warnings.warn(
            "CUDA is not available. Distributed training requires CUDA for GPU training.",
            UserWarning
        )
        return False
    
    # Check if already initialized
    if dist.is_initialized():
        return True
    
    # Use environment variables if not specified
    if init_method is None:
        init_method = os.environ.get("MASTER_ADDR", None)
        if init_method:
            port = os.environ.get("MASTER_PORT", "29500")
            init_method = f"tcp://{init_method}:{port}"
        else:
            init_method = "env://"
    
    if world_size is None:
        world_size = int(os.environ.get("WORLD_SIZE", 1))
    
    if rank is None:
        rank = int(os.environ.get("RANK", -1))
    
    # If rank is -1, try to get from LOCAL_RANK
    if rank == -1:
        rank = int(os.environ.get("LOCAL_RANK", -1))
    
    # If still -1, we're not in distributed mode
    if rank == -1:
        return False
    
    try:
        dist.init_process_group(
            backend=backend,
            init_method=init_method,
            world_size=world_size,
            rank=rank,
        )
        return True
    except Exception as e:
        warnings.warn(
            f"Failed to initialize distributed training: {e}. "
            "Continuing with single GPU/CPU training.",
            UserWarning
        )
        return False


def cleanup_distributed() -> None:
    """Cleanup distributed training environment."""
    if _torch_available and dist.is_initialized():
        dist.destroy_process_group()


def is_distributed() -> bool:
    """Check if distributed training is initialized."""
    if not _torch_available:
        return False
    return dist.is_initialized()


def get_rank() -> int:
    """Get current process rank."""
    if not _torch_available or not dist.is_initialized():
        return 0
    return dist.get_rank()


def get_world_size() -> int:
    """Get total number of processes."""
    if not _torch_available or not dist.is_initialized():
        return 1
    return dist.get_world_size()


def is_main_process() -> bool:
    """Check if current process is the main process (rank 0)."""
    return get_rank() == 0


def setup_ddp_model(model: nn.Module, device_id: Optional[int] = None) -> nn.Module:
    """
    Wrap model with DDP for distributed training.
    
    Args:
        model: PyTorch model to wrap
        device_id: Device ID for this process (default: get_rank())
        
    Returns:
        DDP-wrapped model if distributed, original model otherwise
        
    Example:
        >>> model = MyModel()
        >>> model = setup_ddp_model(model)
    """
    if not _torch_available:
        return model
    
    if not is_distributed():
        return model
    
    if device_id is None:
        device_id = get_rank()
    
    # Move model to device
    device = torch.device(f"cuda:{device_id}")
    model = model.to(device)
    
    # Wrap with DDP
    model = DDP(model, device_ids=[device_id], output_device=device_id)
    
    return model


def setup_distributed_sampler(
    dataset,
    shuffle: bool = True,
    seed: Optional[int] = None,
) -> Optional[DistributedSampler]:
    """
    Create DistributedSampler for DataLoader.
    
    Args:
        dataset: Dataset to sample from
        shuffle: Whether to shuffle data
        seed: Random seed for shuffling
        
    Returns:
        DistributedSampler if distributed, None otherwise
        
    Example:
        >>> sampler = setup_distributed_sampler(train_dataset, shuffle=True, seed=42)
        >>> train_loader = DataLoader(train_dataset, sampler=sampler, ...)
    """
    if not _torch_available:
        return None
    
    if not is_distributed():
        return None
    
    sampler = DistributedSampler(
        dataset,
        num_replicas=get_world_size(),
        rank=get_rank(),
        shuffle=shuffle,
        seed=seed,
    )
    
    return sampler


def get_device() -> torch.device:
    """
    Get device for current process in distributed training.
    
    Returns:
        torch.device for current process
        
    Example:
        >>> device = get_device()
        >>> data = data.to(device)
    """
    if not _torch_available:
        return torch.device("cpu")
    
    if is_distributed():
        device_id = get_rank()
        return torch.device(f"cuda:{device_id}")
    
    # Single GPU or CPU
    if torch.cuda.is_available():
        return torch.device("cuda:0")
    
    return torch.device("cpu")


def all_reduce_mean(tensor: torch.Tensor) -> torch.Tensor:
    """
    All-reduce tensor and compute mean across all processes.
    
    Args:
        tensor: Tensor to reduce
        
    Returns:
        Mean value across all processes
        
    Example:
        >>> loss_value = torch.tensor(0.5)
        >>> avg_loss = all_reduce_mean(loss_value)
    """
    if not _torch_available or not is_distributed() or dist is None:
        return tensor
    
    dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
    tensor = tensor / get_world_size()
    return tensor


def barrier() -> None:
    """Synchronize all processes."""
    if _torch_available and is_distributed():
        dist.barrier()


def get_ddp_config(
    num_gpus: Optional[int] = None,
    backend: str = "nccl",
    find_unused_parameters: bool = False,
) -> dict:
    """
    Get DDP configuration dictionary.
    
    Args:
        num_gpus: Number of GPUs to use (None = auto-detect)
        backend: Distributed backend ('nccl' for GPU, 'gloo' for CPU)
        find_unused_parameters: Whether to find unused parameters in DDP
        
    Returns:
        Configuration dictionary for distributed training
        
    Example:
        >>> ddp_config = get_ddp_config(num_gpus=4)
        >>> config["training"]["distributed"] = ddp_config
    """
    if not _torch_available:
        return {"enabled": False}
    
    if num_gpus is None:
        num_gpus = torch.cuda.device_count() if torch.cuda.is_available() else 0
    
    return {
        "enabled": num_gpus > 1,
        "num_gpus": num_gpus,
        "backend": backend,
        "find_unused_parameters": find_unused_parameters,
    }


def launch_distributed(
    main_func,
    num_gpus: Optional[int] = None,
    backend: str = "nccl",
    args: tuple = (),
    kwargs: Optional[dict] = None,
):
    """
    Launch distributed training automatically from code.
    
    This function automatically spawns multiple processes for multi-GPU training
    without needing torchrun or manual process management.
    
    Args:
        main_func: Main function to run (will be called on each process)
        num_gpus: Number of GPUs to use (None = use all available)
        backend: Distributed backend ('nccl' for GPU, 'gloo' for CPU)
        args: Arguments to pass to main_func
        kwargs: Keyword arguments to pass to main_func
        
    Example:
        >>> def train():
        ...     # Your training code here
        ...     trainer = quick_train(...)
        ...
        >>> launch_distributed(train, num_gpus=4)
    """
    if not _torch_available:
        raise ImportError("PyTorch is required for distributed training")
    
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is not available. Distributed training requires CUDA.")
    
    if num_gpus is None:
        num_gpus = torch.cuda.device_count()
    
    if num_gpus <= 1:
        # Single GPU or CPU - just run normally
        return main_func(*args, **(kwargs or {}))
    
    # Use torch.multiprocessing to spawn processes
    import torch.multiprocessing as mp
    
    # Set start method
    try:
        mp.set_start_method('spawn', force=True)
    except RuntimeError:
        # Already set
        pass
    
    # Spawn processes
    processes = []
    for rank in range(num_gpus):
        p = mp.Process(
            target=_distributed_worker,
            args=(rank, num_gpus, backend, main_func, args, kwargs or {})
        )
        p.start()
        processes.append(p)
    
    # Wait for all processes to complete
    for p in processes:
        p.join()
    
    # Check if any process failed
    for p in processes:
        if p.exitcode != 0:
            raise RuntimeError(f"Process {p.pid} exited with code {p.exitcode}")


def _distributed_worker(
    rank: int,
    world_size: int,
    backend: str,
    main_func,
    args: tuple,
    kwargs: dict,
):
    """
    Worker function for distributed training.
    
    Sets up environment variables and initializes distributed training
    before calling the main function.
    """
    import os
    
    # Set environment variables for this process
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = '29500'
    os.environ['WORLD_SIZE'] = str(world_size)
    os.environ['RANK'] = str(rank)
    os.environ['LOCAL_RANK'] = str(rank)
    
    # Initialize distributed training
    if not init_distributed(backend=backend, world_size=world_size, rank=rank):
        raise RuntimeError(f"Failed to initialize distributed training on rank {rank}")
    
    try:
        # Call main function
        return main_func(*args, **kwargs)
    finally:
        # Cleanup
        cleanup_distributed()

