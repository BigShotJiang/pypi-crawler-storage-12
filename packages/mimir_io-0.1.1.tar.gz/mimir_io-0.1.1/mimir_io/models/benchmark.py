"""
Benchmark system for evaluating models after training.

Provides a registry-based system for running various benchmarks and metrics.
"""

from typing import Dict, Any, Optional, List, Callable, Union
from pathlib import Path
from abc import ABC, abstractmethod
import json
from datetime import datetime

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader
    import numpy as np
    _torch_available = True
except ImportError:
    _torch_available = False
    torch = object  # type: ignore
    nn = object  # type: ignore
    DataLoader = object  # type: ignore
    np = object  # type: ignore


class Benchmark(ABC):
    """
    Base class for benchmarks.
    
    Benchmarks are functions that evaluate model performance
    and return metrics as a dictionary.
    """
    
    @abstractmethod
    def run(
        self,
        model: nn.Module,
        test_loader: DataLoader,
        device: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Run the benchmark.
        
        Args:
            model: PyTorch model to evaluate
            test_loader: DataLoader with test data
            device: Device to run on (default: auto-detect)
            **kwargs: Additional benchmark-specific parameters
            
        Returns:
            Dictionary with benchmark results
        """
        pass
    
    @abstractmethod
    def name(self) -> str:
        """Return the name of this benchmark."""
        pass


class BenchmarkRegistry:
    """Registry for benchmarks."""
    
    def __init__(self):
        self._benchmarks: Dict[str, Benchmark] = {}
    
    def register(self, name: str, benchmark: Benchmark) -> None:
        """
        Register a benchmark.
        
        Args:
            name: Benchmark name
            benchmark: Benchmark instance
        """
        if name in self._benchmarks:
            raise ValueError(f"Benchmark '{name}' is already registered")
        self._benchmarks[name] = benchmark
    
    def get(self, name: str) -> Benchmark:
        """
        Get benchmark by name.
        
        Args:
            name: Benchmark name
            
        Returns:
            Benchmark instance
            
        Raises:
            KeyError: If benchmark not found
        """
        if name not in self._benchmarks:
            available = ", ".join(self._benchmarks.keys())
            raise KeyError(
                f"Benchmark '{name}' not found. Available benchmarks: {available}"
            )
        return self._benchmarks[name]
    
    def list(self) -> List[str]:
        """List all registered benchmark names."""
        return list(self._benchmarks.keys())
    
    def has(self, name: str) -> bool:
        """Check if benchmark is registered."""
        return name in self._benchmarks


# Global registry instance
_benchmark_registry = BenchmarkRegistry()


def register_benchmark(name: Optional[str] = None) -> Callable:
    """
    Decorator to register a benchmark class.
    
    Args:
        name: Benchmark name (defaults to class name)
        
    Example:
        @register_benchmark("accuracy")
        class AccuracyBenchmark(Benchmark):
            def run(self, model, test_loader, **kwargs):
                # Calculate accuracy
                return {"accuracy": 0.95}
            
            def name(self):
                return "accuracy"
    """
    def decorator(benchmark_class: type) -> type:
        benchmark_name = name or benchmark_class.__name__.replace("Benchmark", "").lower()
        benchmark_instance = benchmark_class()
        _benchmark_registry.register(benchmark_name, benchmark_instance)
        return benchmark_class
    return decorator


def get_benchmark(name: str) -> Benchmark:
    """Get benchmark by name."""
    return _benchmark_registry.get(name)


def list_benchmarks() -> List[str]:
    """List all registered benchmarks."""
    return _benchmark_registry.list()


def has_benchmark(name: str) -> bool:
    """Check if benchmark is registered."""
    return _benchmark_registry.has(name)


# ========== Standard Benchmarks ==========

@register_benchmark("accuracy")
class AccuracyBenchmark(Benchmark):
    """Benchmark for classification accuracy."""
    
    def run(
        self,
        model: nn.Module,
        test_loader: DataLoader,
        device: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Calculate classification accuracy."""
        if not _torch_available:
            raise ImportError("PyTorch is required for benchmarks")
        
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        device = torch.device(device)
        
        model.eval()
        correct = 0
        total = 0
        
        with torch.no_grad():
            for features, labels in test_loader:
                features = features.to(device)
                labels = labels.to(device)
                
                outputs = model(features)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
        
        accuracy = 100.0 * correct / total if total > 0 else 0.0
        
        return {
            "accuracy": accuracy,
            "correct": correct,
            "total": total,
        }
    
    def name(self) -> str:
        return "accuracy"


@register_benchmark("classification_metrics")
class ClassificationMetricsBenchmark(Benchmark):
    """Benchmark for classification metrics (precision, recall, F1)."""
    
    def run(
        self,
        model: nn.Module,
        test_loader: DataLoader,
        device: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Calculate classification metrics."""
        if not _torch_available:
            raise ImportError("PyTorch is required for benchmarks")
        
        try:
            from sklearn.metrics import precision_score, recall_score, f1_score, classification_report
        except ImportError:
            raise ImportError("scikit-learn is required for classification metrics")
        
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        device = torch.device(device)
        
        model.eval()
        all_predictions = []
        all_labels = []
        
        with torch.no_grad():
            for features, labels in test_loader:
                features = features.to(device)
                labels = labels.to(device)
                
                outputs = model(features)
                _, predicted = torch.max(outputs.data, 1)
                
                all_predictions.extend(predicted.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
        
        # Calculate metrics
        precision = precision_score(all_labels, all_predictions, average='weighted', zero_division=0)
        recall = recall_score(all_labels, all_predictions, average='weighted', zero_division=0)
        f1 = f1_score(all_labels, all_predictions, average='weighted', zero_division=0)
        
        # Per-class metrics
        precision_macro = precision_score(all_labels, all_predictions, average='macro', zero_division=0)
        recall_macro = recall_score(all_labels, all_predictions, average='macro', zero_division=0)
        f1_macro = f1_score(all_labels, all_predictions, average='macro', zero_division=0)
        
        return {
            "precision_weighted": precision,
            "recall_weighted": recall,
            "f1_weighted": f1,
            "precision_macro": precision_macro,
            "recall_macro": recall_macro,
            "f1_macro": f1_macro,
            "classification_report": classification_report(all_labels, all_predictions, output_dict=True),
        }
    
    def name(self) -> str:
        return "classification_metrics"


@register_benchmark("confusion_matrix")
class ConfusionMatrixBenchmark(Benchmark):
    """Benchmark for confusion matrix."""
    
    def run(
        self,
        model: nn.Module,
        test_loader: DataLoader,
        device: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Calculate confusion matrix."""
        if not _torch_available:
            raise ImportError("PyTorch is required for benchmarks")
        
        try:
            from sklearn.metrics import confusion_matrix
        except ImportError:
            raise ImportError("scikit-learn is required for confusion matrix")
        
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        device = torch.device(device)
        
        model.eval()
        all_predictions = []
        all_labels = []
        
        with torch.no_grad():
            for features, labels in test_loader:
                features = features.to(device)
                labels = labels.to(device)
                
                outputs = model(features)
                _, predicted = torch.max(outputs.data, 1)
                
                all_predictions.extend(predicted.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
        
        cm = confusion_matrix(all_labels, all_predictions)
        
        return {
            "confusion_matrix": cm.tolist(),
            "num_classes": len(np.unique(all_labels)),
        }
    
    def name(self) -> str:
        return "confusion_matrix"


@register_benchmark("loss")
class LossBenchmark(Benchmark):
    """Benchmark for calculating loss."""
    
    def run(
        self,
        model: nn.Module,
        test_loader: DataLoader,
        device: Optional[str] = None,
        criterion: Optional[nn.Module] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Calculate test loss."""
        if not _torch_available:
            raise ImportError("PyTorch is required for benchmarks")
        
        if criterion is None:
            criterion = nn.CrossEntropyLoss()
        
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        device = torch.device(device)
        
        model.eval()
        total_loss = 0.0
        num_batches = 0
        
        with torch.no_grad():
            for features, labels in test_loader:
                features = features.to(device)
                labels = labels.to(device)
                
                outputs = model(features)
                loss = criterion(outputs, labels)
                total_loss += loss.item()
                num_batches += 1
        
        avg_loss = total_loss / num_batches if num_batches > 0 else 0.0
        
        return {
            "test_loss": avg_loss,
            "num_batches": num_batches,
        }
    
    def name(self) -> str:
        return "loss"


@register_benchmark("inference_time")
class InferenceTimeBenchmark(Benchmark):
    """Benchmark for measuring inference time."""
    
    def run(
        self,
        model: nn.Module,
        test_loader: DataLoader,
        device: Optional[str] = None,
        num_warmup: int = 10,
        num_runs: int = 100,
        **kwargs
    ) -> Dict[str, Any]:
        """Measure inference time."""
        if not _torch_available:
            raise ImportError("PyTorch is required for benchmarks")
        
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        device = torch.device(device)
        
        model.eval()
        
        # Warmup
        with torch.no_grad():
            for i, (features, _) in enumerate(test_loader):
                if i >= num_warmup:
                    break
                features = features.to(device)
                _ = model(features)
        
        # Measure inference time
        import time
        times = []
        
        with torch.no_grad():
            for i, (features, _) in enumerate(test_loader):
                if i >= num_runs:
                    break
                features = features.to(device)
                
                # Synchronize if CUDA
                if device.type == "cuda":
                    torch.cuda.synchronize()
                
                start_time = time.time()
                _ = model(features)
                
                if device.type == "cuda":
                    torch.cuda.synchronize()
                
                end_time = time.time()
                times.append((end_time - start_time) * 1000)  # Convert to ms
        
        if not times:
            return {
                "avg_inference_time_ms": 0.0,
                "min_inference_time_ms": 0.0,
                "max_inference_time_ms": 0.0,
            }
        
        return {
            "avg_inference_time_ms": np.mean(times),
            "min_inference_time_ms": np.min(times),
            "max_inference_time_ms": np.max(times),
            "std_inference_time_ms": np.std(times),
            "num_runs": len(times),
        }
    
    def name(self) -> str:
        return "inference_time"


def run_benchmarks(
    model: nn.Module,
    test_loader: Optional[DataLoader] = None,
    benchmark_names: Optional[List[str]] = None,
    device: Optional[str] = None,
    experiment_dir: Optional[Union[str, Path]] = None,
    config_path: Optional[Union[str, Path]] = None,
    checkpoint_path: Optional[Union[str, Path]] = None,
    split_path: Optional[Union[str, Path]] = None,
    **kwargs
) -> Dict[str, Dict[str, Any]]:
    """
    Run multiple benchmarks.
    
    Args:
        model: PyTorch model
        test_loader: Test DataLoader (required if experiment_dir is not provided)
        benchmark_names: List of benchmark names to run (None = run all)
        device: Device to run on
        experiment_dir: Path to experiment directory (alternative to test_loader)
                       Automatically finds config.yaml, best_model.pt, and split.json
        config_path: Path to config file (used with experiment_dir)
        checkpoint_path: Path to checkpoint file (used with experiment_dir, auto-found if not provided)
        split_path: Path to split file (used with experiment_dir, auto-found if not provided)
        **kwargs: Additional parameters for benchmarks
        
    Returns:
        Dictionary mapping benchmark names to their results
        
    Example:
        >>> # With test_loader
        >>> results = run_benchmarks(
        ...     model=model,
        ...     test_loader=test_loader,
        ...     benchmark_names=["accuracy", "classification_metrics"],
        ... )
        >>> print(results["accuracy"]["accuracy"])
        >>>
        >>> # With experiment directory
        >>> results = run_benchmarks(
        ...     model=model,
        ...     experiment_dir="./experiments/exp_001",
        ... )
    """
    from pathlib import Path
    
    # Якщо вказано experiment_dir, налаштовуємо test_loader
    if experiment_dir:
        from mimir_io.experiment import find_experiment_files, setup_test, ExperimentConfig
        from mimir_io.models.config import load_config
        
        exp_files = find_experiment_files(experiment_dir)
        
        if not exp_files["config"]:
            raise FileNotFoundError(
                f"Config file not found in experiment directory: {experiment_dir}. "
                f"Expected: config.yaml or config.yml"
            )
        
        # Завантажуємо конфігурацію
        config_dict = load_config(exp_files["config"])
        exp_config = ExperimentConfig(**config_dict)
        
        # Використовуємо checkpoint з папки, якщо не вказано інше
        if not checkpoint_path and exp_files["checkpoint"]:
            checkpoint_path = exp_files["checkpoint"]
        
        # Завантажуємо ваги моделі
        if checkpoint_path:
            checkpoint_path = Path(checkpoint_path)
            if device is None:
                device = "cuda" if torch.cuda.is_available() else "cpu"
            
            checkpoint = torch.load(checkpoint_path, map_location=device)
            if "model_state_dict" in checkpoint:
                model.load_state_dict(checkpoint["model_state_dict"])
            elif "state_dict" in checkpoint:
                model.load_state_dict(checkpoint["state_dict"])
            else:
                model.load_state_dict(checkpoint)
            
            model = model.to(device)
            model.eval()
        
        # Використовуємо split з папки, якщо не вказано інше
        if not split_path and exp_files["split"]:
            split_path = exp_files["split"]
        
        # Створюємо test_loader
        test_loader, _, _ = setup_test(
            file_paths=[],
            config=exp_config,
            split_path=split_path,
            use_test_split=split_path is not None,
        )
    
    if test_loader is None:
        raise ValueError("test_loader is required if experiment_dir is not provided")
    if benchmark_names is None:
        benchmark_names = list_benchmarks()
    
    results = {}
    for name in benchmark_names:
        if not has_benchmark(name):
            print(f"Warning: Benchmark '{name}' not found, skipping")
            continue
        
        benchmark = get_benchmark(name)
        try:
            result = benchmark.run(model, test_loader, device=device, **kwargs)
            results[name] = result
        except Exception as e:
            print(f"Error running benchmark '{name}': {e}")
            results[name] = {"error": str(e)}
    
    return results

