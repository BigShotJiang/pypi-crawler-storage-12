"""
Реєстри оптимізаторів та критеріїв для гнучкого налаштування тренування.

Дозволяє реєструвати оптимізатори та функції втрат без зміни коду BaseTrainer.
"""

from typing import Dict, Callable, Any, Optional, List
from functools import wraps

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    _torch_available = True
except ImportError:
    _torch_available = False
    torch = object  # type: ignore
    nn = object  # type: ignore
    optim = object  # type: ignore

# Import WarmupScheduler if available
if _torch_available:
    try:
        from mimir_io.models.warmup_scheduler import WarmupScheduler
        _warmup_available = True
    except ImportError:
        _warmup_available = False
        WarmupScheduler = None
else:
    _warmup_available = False
    WarmupScheduler = None


class OptimizerRegistry:
    """
    Реєстр оптимізаторів PyTorch.
    
    Оптимізатори реєструються через декоратор @register_optimizer
    та можуть бути отримані за ім'ям.
    """
    
    def __init__(self):
        self._optimizers: Dict[str, Callable] = {}
    
    def register(
        self,
        name: str,
        optimizer_factory: Callable,
    ) -> None:
        """
        Реєстрація фабрики оптимізатора.
        
        Args:
            name: Унікальна назва оптимізатора
            optimizer_factory: Функція, яка приймає (model.parameters(), **config)
                               та повертає оптимізатор
        """
        if not _torch_available:
            raise ImportError("PyTorch потрібен для реєстру оптимізаторів")
        
        if name in self._optimizers:
            raise ValueError(f"Оптимізатор '{name}' вже зареєстрований")
        
        self._optimizers[name] = optimizer_factory
    
    def get(self, name: str) -> Callable:
        """
        Отримати фабрику оптимізатора за ім'ям.
        
        Args:
            name: Назва оптимізатора
            
        Returns:
            Функція-фабрика оптимізатора
            
        Raises:
            KeyError: Якщо оптимізатор не знайдено
        """
        if name not in self._optimizers:
            available = ", ".join(self._optimizers.keys())
            raise KeyError(
                f"Оптимізатор '{name}' не знайдено. Доступні: {available}"
            )
        return self._optimizers[name]
    
    def create(
        self,
        name: str,
        model_parameters: Any,
        config: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """
        Створити екземпляр оптимізатора за ім'ям.
        
        Args:
            name: Назва оптимізатора
            model_parameters: Параметри моделі (model.parameters())
            config: Словник конфігурації (виключаючи 'type')
            
        Returns:
            Екземпляр оптимізатора
        """
        if config is None:
            config = {}
        
        factory = self.get(name)
        return factory(model_parameters, **config)
    
    def list(self) -> List[str]:
        """
        Список всіх зареєстрованих оптимізаторів.
        
        Returns:
            Список назв оптимізаторів
        """
        return list(self._optimizers.keys())
    
    def has(self, name: str) -> bool:
        """
        Перевірити, чи зареєстрований оптимізатор.
        
        Args:
            name: Назва оптимізатора
            
        Returns:
            True якщо зареєстрований, False інакше
        """
        return name in self._optimizers


class CriterionRegistry:
    """
    Реєстр функцій втрат (критеріїв) PyTorch.
    
    Критерії реєструються через декоратор @register_criterion
    та можуть бути отримані за ім'ям.
    """
    
    def __init__(self):
        self._criteria: Dict[str, Callable] = {}
    
    def register(
        self,
        name: str,
        criterion_factory: Callable,
    ) -> None:
        """
        Реєстрація фабрики критерію.
        
        Args:
            name: Унікальна назва критерію
            criterion_factory: Функція, яка приймає **config та повертає критерій
        """
        if not _torch_available:
            raise ImportError("PyTorch потрібен для реєстру критеріїв")
        
        if name in self._criteria:
            raise ValueError(f"Критерій '{name}' вже зареєстрований")
        
        self._criteria[name] = criterion_factory
    
    def get(self, name: str) -> Callable:
        """
        Отримати фабрику критерію за ім'ям.
        
        Args:
            name: Назва критерію
            
        Returns:
            Функція-фабрика критерію
            
        Raises:
            KeyError: Якщо критерій не знайдено
        """
        if name not in self._criteria:
            available = ", ".join(self._criteria.keys())
            raise KeyError(
                f"Критерій '{name}' не знайдено. Доступні: {available}"
            )
        return self._criteria[name]
    
    def create(
        self,
        name: str,
        config: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """
        Створити екземпляр критерію за ім'ям.
        
        Args:
            name: Назва критерію
            config: Словник конфігурації (виключаючи 'type')
            
        Returns:
            Екземпляр критерію
        """
        if config is None:
            config = {}
        
        factory = self.get(name)
        return factory(**config)
    
    def list(self) -> List[str]:
        """
        Список всіх зареєстрованих критеріїв.
        
        Returns:
            Список назв критеріїв
        """
        return list(self._criteria.keys())
    
    def has(self, name: str) -> bool:
        """
        Перевірити, чи зареєстрований критерій.
        
        Args:
            name: Назва критерію
            
        Returns:
            True якщо зареєстрований, False інакше
        """
        return name in self._criteria


class SchedulerRegistry:
    """
    Реєстр learning rate scheduler для PyTorch.
    
    Scheduler реєструються через декоратор @register_scheduler
    та можуть бути отримані за ім'ям.
    """
    
    def __init__(self):
        self._schedulers: Dict[str, Callable] = {}
    
    def register(
        self,
        name: str,
        scheduler_factory: Callable,
    ) -> None:
        """
        Реєстрація фабрики scheduler.
        
        Args:
            name: Унікальна назва scheduler
            scheduler_factory: Функція, яка приймає (optimizer, **config)
                               та повертає scheduler
        """
        if not _torch_available:
            raise ImportError("PyTorch потрібен для реєстру scheduler")
        
        if name in self._schedulers:
            raise ValueError(f"Scheduler '{name}' вже зареєстрований")
        
        self._schedulers[name] = scheduler_factory
    
    def get(self, name: str) -> Callable:
        """
        Отримати фабрику scheduler за ім'ям.
        
        Args:
            name: Назва scheduler
            
        Returns:
            Функція-фабрика scheduler
            
        Raises:
            KeyError: Якщо scheduler не знайдено
        """
        if name not in self._schedulers:
            available = ", ".join(self._schedulers.keys())
            raise KeyError(
                f"Scheduler '{name}' не знайдено. Доступні: {available}"
            )
        return self._schedulers[name]
    
    def create(
        self,
        name: str,
        optimizer: Any,
        config: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """
        Створити екземпляр scheduler за ім'ям.
        
        Args:
            name: Назва scheduler
            optimizer: Оптимізатор PyTorch
            config: Словник конфігурації (виключаючи 'type')
            
        Returns:
            Екземпляр scheduler
        """
        if config is None:
            config = {}
        
        factory = self.get(name)
        return factory(optimizer, **config)
    
    def list(self) -> List[str]:
        """
        Список всіх зареєстрованих scheduler.
        
        Returns:
            Список назв scheduler
        """
        return list(self._schedulers.keys())
    
    def has(self, name: str) -> bool:
        """
        Перевірити, чи зареєстрований scheduler.
        
        Args:
            name: Назва scheduler
            
        Returns:
            True якщо зареєстрований, False інакше
        """
        return name in self._schedulers


# Глобальні екземпляри реєстрів
_optimizer_registry = OptimizerRegistry()
_criterion_registry = CriterionRegistry()
_scheduler_registry = SchedulerRegistry()


def register_optimizer(name: Optional[str] = None) -> Callable:
    """
    Декоратор для реєстрації оптимізатора.
    
    Args:
        name: Назва оптимізатора (за замовчуванням - назва функції)
    
    Example:
        @register_optimizer("Adam")
        def adam_factory(params, lr=0.001, **kwargs):
            return optim.Adam(params, lr=lr, **kwargs)
    """
    def decorator(factory: Callable) -> Callable:
        optimizer_name = name or factory.__name__
        _optimizer_registry.register(optimizer_name, factory)
        return factory
    
    return decorator


def register_criterion(name: Optional[str] = None) -> Callable:
    """
    Декоратор для реєстрації критерію.
    
    Args:
        name: Назва критерію (за замовчуванням - назва функції)
    
    Example:
        @register_criterion("CrossEntropyLoss")
        def cross_entropy_factory(**kwargs):
            return nn.CrossEntropyLoss(**kwargs)
    """
    def decorator(factory: Callable) -> Callable:
        criterion_name = name or factory.__name__
        _criterion_registry.register(criterion_name, factory)
        return factory
    
    return decorator


def register_scheduler(name: Optional[str] = None) -> Callable:
    """
    Декоратор для реєстрації scheduler.
    
    Args:
        name: Назва scheduler (за замовчуванням - назва функції)
    
    Example:
        @register_scheduler("StepLR")
        def step_lr_factory(optimizer, step_size=30, gamma=0.1, **kwargs):
            return optim.lr_scheduler.StepLR(optimizer, step_size=step_size, gamma=gamma, **kwargs)
    """
    def decorator(factory: Callable) -> Callable:
        scheduler_name = name or factory.__name__
        _scheduler_registry.register(scheduler_name, factory)
        return factory
    
    return decorator


def get_optimizer_factory(name: str) -> Callable:
    """
    Отримати фабрику оптимізатора за ім'ям.
    
    Args:
        name: Назва оптимізатора
        
    Returns:
        Функція-фабрика оптимізатора
    """
    return _optimizer_registry.get(name)


def get_criterion_factory(name: str) -> Callable:
    """
    Отримати фабрику критерію за ім'ям.
    
    Args:
        name: Назва критерію
        
    Returns:
        Функція-фабрика критерію
    """
    return _criterion_registry.get(name)


def create_optimizer(
    name: str,
    model_parameters: Any,
    config: Optional[Dict[str, Any]] = None,
) -> Any:
    """
    Створити екземпляр оптимізатора за ім'ям.
    
    Args:
        name: Назва оптимізатора
        model_parameters: Параметри моделі (model.parameters())
        config: Словник конфігурації
        
    Returns:
        Екземпляр оптимізатора
    """
    return _optimizer_registry.create(name, model_parameters, config)


def create_criterion(
    name: str,
    config: Optional[Dict[str, Any]] = None,
) -> Any:
    """
    Створити екземпляр критерію за ім'ям.
    
    Args:
        name: Назва критерію
        config: Словник конфігурації
        
    Returns:
        Екземпляр критерію
    """
    return _criterion_registry.create(name, config)


def list_optimizers() -> List[str]:
    """
    Список всіх зареєстрованих оптимізаторів.
    
    Returns:
        Список назв оптимізаторів
    """
    return _optimizer_registry.list()


def list_criteria() -> List[str]:
    """
    Список всіх зареєстрованих критеріїв.
    
    Returns:
        Список назв критеріїв
    """
    return _criterion_registry.list()


def has_optimizer(name: str) -> bool:
    """
    Перевірити, чи зареєстрований оптимізатор.
    
    Args:
        name: Назва оптимізатора
        
    Returns:
        True якщо зареєстрований, False інакше
    """
    return _optimizer_registry.has(name)


def has_criterion(name: str) -> bool:
    """
    Перевірити, чи зареєстрований критерій.
    
    Args:
        name: Назва критерію
        
    Returns:
        True якщо зареєстрований, False інакше
    """
    return _criterion_registry.has(name)


def get_scheduler_factory(name: str) -> Callable:
    """
    Отримати фабрику scheduler за ім'ям.
    
    Args:
        name: Назва scheduler
        
    Returns:
        Функція-фабрика scheduler
    """
    return _scheduler_registry.get(name)


def create_scheduler(
    name: str,
    optimizer: Any,
    config: Optional[Dict[str, Any]] = None,
) -> Any:
    """
    Створити екземпляр scheduler за ім'ям.
    
    Args:
        name: Назва scheduler
        optimizer: Оптимізатор PyTorch
        config: Словник конфігурації
        
    Returns:
        Екземпляр scheduler
    """
    return _scheduler_registry.create(name, optimizer, config)


def list_schedulers() -> List[str]:
    """
    Список всіх зареєстрованих scheduler.
    
    Returns:
        Список назв scheduler
    """
    return _scheduler_registry.list()


def has_scheduler(name: str) -> bool:
    """
    Перевірити, чи зареєстрований scheduler.
    
    Args:
        name: Назва scheduler
        
    Returns:
        True якщо зареєстрований, False інакше
    """
    return _scheduler_registry.has(name)


# Реєстрація стандартних оптимізаторів та критеріїв
if _torch_available:
    @register_optimizer("Adam")
    def adam_factory(params, lr=0.001, **kwargs):
        """Фабрика для оптимізатора Adam."""
        return optim.Adam(params, lr=lr, **kwargs)
    
    @register_optimizer("SGD")
    def sgd_factory(params, lr=0.01, **kwargs):
        """Фабрика для оптимізатора SGD."""
        return optim.SGD(params, lr=lr, **kwargs)
    
    @register_optimizer("AdamW")
    def adamw_factory(params, lr=0.001, **kwargs):
        """Фабрика для оптимізатора AdamW."""
        return optim.AdamW(params, lr=lr, **kwargs)
    
    @register_optimizer("RMSprop")
    def rmsprop_factory(params, lr=0.01, **kwargs):
        """Фабрика для оптимізатора RMSprop."""
        return optim.RMSprop(params, lr=lr, **kwargs)
    
    @register_optimizer("Adagrad")
    def adagrad_factory(params, lr=0.01, **kwargs):
        """Фабрика для оптимізатора Adagrad."""
        return optim.Adagrad(params, lr=lr, **kwargs)
    
    @register_criterion("CrossEntropyLoss")
    def cross_entropy_factory(**kwargs):
        """Фабрика для критерію CrossEntropyLoss."""
        return nn.CrossEntropyLoss(**kwargs)
    
    @register_criterion("MSELoss")
    def mse_factory(**kwargs):
        """Фабрика для критерію MSELoss."""
        return nn.MSELoss(**kwargs)
    
    @register_criterion("BCELoss")
    def bce_factory(**kwargs):
        """Фабрика для критерію BCELoss."""
        return nn.BCELoss(**kwargs)
    
    @register_criterion("L1Loss")
    def l1_factory(**kwargs):
        """Фабрика для критерію L1Loss."""
        return nn.L1Loss(**kwargs)
    
    @register_criterion("NLLLoss")
    def nll_factory(**kwargs):
        """Фабрика для критерію NLLLoss."""
        return nn.NLLLoss(**kwargs)
    
    # Реєстрація стандартних scheduler
    @register_scheduler("StepLR")
    def step_lr_factory(optimizer, step_size=30, gamma=0.1, **kwargs):
        """Фабрика для scheduler StepLR."""
        return optim.lr_scheduler.StepLR(optimizer, step_size=step_size, gamma=gamma, **kwargs)
    
    @register_scheduler("ReduceLROnPlateau")
    def reduce_lr_on_plateau_factory(optimizer, mode="min", factor=0.1, patience=10, **kwargs):
        """Фабрика для scheduler ReduceLROnPlateau."""
        # Видаляємо monitor з kwargs, оскільки PyTorch ReduceLROnPlateau не приймає цей параметр
        # monitor використовується тільки для визначення, яку метрику передавати в step()
        scheduler_kwargs = {k: v for k, v in kwargs.items() if k != "monitor"}
        return optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode=mode, factor=factor, patience=patience, **scheduler_kwargs
        )
    
    @register_scheduler("CosineAnnealingLR")
    def cosine_annealing_lr_factory(optimizer, T_max=10, eta_min=0, **kwargs):
        """Фабрика для scheduler CosineAnnealingLR."""
        return optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=T_max, eta_min=eta_min, **kwargs
        )
    
    @register_scheduler("ExponentialLR")
    def exponential_lr_factory(optimizer, gamma=0.95, **kwargs):
        """Фабрика для scheduler ExponentialLR."""
        return optim.lr_scheduler.ExponentialLR(optimizer, gamma=gamma, **kwargs)
    
    @register_scheduler("MultiStepLR")
    def multi_step_lr_factory(optimizer, milestones=[30, 60], gamma=0.1, **kwargs):
        """Фабрика для scheduler MultiStepLR."""
        return optim.lr_scheduler.MultiStepLR(
            optimizer, milestones=milestones, gamma=gamma, **kwargs
        )
    
    # Register WarmupScheduler with different base schedulers
    if _warmup_available and WarmupScheduler is not None:
        @register_scheduler("WarmupStepLR")
        def warmup_step_lr_factory(
            optimizer,
            warmup_epochs=5,
            warmup_steps=None,
            warmup_start_lr=None,
            warmup_mode="linear",
            step_size=30,
            gamma=0.1,
            **kwargs
        ):
            """Factory for WarmupScheduler with StepLR base scheduler."""
            base_scheduler = optim.lr_scheduler.StepLR(
                optimizer, step_size=step_size, gamma=gamma, **kwargs
            )
            return WarmupScheduler(
                optimizer=optimizer,
                base_scheduler=base_scheduler,
                warmup_epochs=warmup_epochs,
                warmup_steps=warmup_steps,
                warmup_start_lr=warmup_start_lr,
                warmup_mode=warmup_mode,
            )
        
        @register_scheduler("WarmupCosineAnnealingLR")
        def warmup_cosine_annealing_lr_factory(
            optimizer,
            warmup_epochs=5,
            warmup_steps=None,
            warmup_start_lr=None,
            warmup_mode="linear",
            T_max=10,
            eta_min=0,
            **kwargs
        ):
            """Factory for WarmupScheduler with CosineAnnealingLR base scheduler."""
            base_scheduler = optim.lr_scheduler.CosineAnnealingLR(
                optimizer, T_max=T_max, eta_min=eta_min, **kwargs
            )
            return WarmupScheduler(
                optimizer=optimizer,
                base_scheduler=base_scheduler,
                warmup_epochs=warmup_epochs,
                warmup_steps=warmup_steps,
                warmup_start_lr=warmup_start_lr,
                warmup_mode=warmup_mode,
            )
        
        @register_scheduler("WarmupReduceLROnPlateau")
        def warmup_reduce_lr_on_plateau_factory(
            optimizer,
            warmup_epochs=5,
            warmup_steps=None,
            warmup_start_lr=None,
            warmup_mode="linear",
            mode="min",
            factor=0.1,
            patience=10,
            **kwargs
        ):
            """Factory for WarmupScheduler with ReduceLROnPlateau base scheduler."""
            base_scheduler = optim.lr_scheduler.ReduceLROnPlateau(
                optimizer, mode=mode, factor=factor, patience=patience, **kwargs
            )
            return WarmupScheduler(
                optimizer=optimizer,
                base_scheduler=base_scheduler,
                warmup_epochs=warmup_epochs,
                warmup_steps=warmup_steps,
                warmup_start_lr=warmup_start_lr,
                warmup_mode=warmup_mode,
            )
        
        @register_scheduler("WarmupExponentialLR")
        def warmup_exponential_lr_factory(
            optimizer,
            warmup_epochs=5,
            warmup_steps=None,
            warmup_start_lr=None,
            warmup_mode="linear",
            gamma=0.95,
            **kwargs
        ):
            """Factory for WarmupScheduler with ExponentialLR base scheduler."""
            base_scheduler = optim.lr_scheduler.ExponentialLR(
                optimizer, gamma=gamma, **kwargs
            )
            return WarmupScheduler(
                optimizer=optimizer,
                base_scheduler=base_scheduler,
                warmup_epochs=warmup_epochs,
                warmup_steps=warmup_steps,
                warmup_start_lr=warmup_start_lr,
                warmup_mode=warmup_mode,
            )

