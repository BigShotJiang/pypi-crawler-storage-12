"""
System for comparing experiment results.

Provides tools to compare multiple experiments and generate comparison reports.
"""

from typing import Dict, Any, List, Optional, Union
from pathlib import Path
from datetime import datetime

try:
    import pandas as pd
    _pandas_available = True
except ImportError:
    _pandas_available = False
    pd = None  # type: ignore

from mimir_io.models.experiment_results import ExperimentResult, ExperimentResultsManager


class ExperimentComparator:
    """
    Comparator for experiment results.
    
    Provides methods to compare multiple experiments and generate reports.
    """
    
    def __init__(self, results: Optional[List[ExperimentResult]] = None):
        """
        Initialize comparator.
        
        Args:
            results: List of experiment results to compare
        """
        self.results = results or []
    
    def add_result(self, result: ExperimentResult) -> None:
        """Add experiment result to comparison."""
        self.results.append(result)
    
    def add_results(self, results: List[ExperimentResult]) -> None:
        """Add multiple experiment results."""
        self.results.extend(results)
    
    def compare_benchmarks(
        self,
        benchmark_name: Optional[str] = None,
        metric_name: Optional[str] = None,
    ):
        """
        Compare benchmark results across experiments.
        
        Args:
            benchmark_name: Specific benchmark to compare (None = all benchmarks)
            metric_name: Specific metric to compare (None = all metrics)
            
        Returns:
            DataFrame with comparison results
        """
        if not _pandas_available:
            raise ImportError("pandas is required for comparison. Install with: pip install pandas")
        if not self.results:
            return pd.DataFrame()
        
        comparison_data = []
        
        for result in self.results:
            row = {
                "experiment_name": result.experiment_name,
                "experiment_id": result.experiment_id,
                "timestamp": result.timestamp,
            }
            
            # Add benchmark results
            if benchmark_name:
                if benchmark_name in result.benchmark_results:
                    benchmark_data = result.benchmark_results[benchmark_name]
                    if metric_name:
                        if metric_name in benchmark_data:
                            row[metric_name] = benchmark_data[metric_name]
                    else:
                        # Add all metrics from this benchmark
                        for key, value in benchmark_data.items():
                            if not key.startswith("_"):  # Skip internal metrics
                                row[f"{benchmark_name}_{key}"] = value
            else:
                # Add all benchmarks
                for bench_name, bench_data in result.benchmark_results.items():
                    if isinstance(bench_data, dict):
                        for key, value in bench_data.items():
                            if not key.startswith("_"):  # Skip internal metrics
                                row[f"{bench_name}_{key}"] = value
            
            # Add training metrics
            if result.training_metrics:
                for key, value in result.training_metrics.items():
                    if not key.startswith("_"):  # Skip internal metrics
                        row[f"training_{key}"] = value
            
            comparison_data.append(row)
        
        return pd.DataFrame(comparison_data)
    
    def compare_configs(self):
        """
        Compare experiment configurations.
        
        Returns:
            DataFrame with configuration comparison
        """
        if not _pandas_available:
            raise ImportError("pandas is required for comparison. Install with: pip install pandas")
        if not self.results:
            return pd.DataFrame()
        
        comparison_data = []
        
        for result in self.results:
            row = {
                "experiment_name": result.experiment_name,
                "experiment_id": result.experiment_id,
                "timestamp": result.timestamp,
            }
            
            # Flatten config
            self._flatten_dict(result.config, row, prefix="config")
            
            comparison_data.append(row)
        
        return pd.DataFrame(comparison_data)
    
    def _flatten_dict(self, d: Dict[str, Any], row: Dict[str, Any], prefix: str = "") -> None:
        """Flatten nested dictionary into row."""
        for key, value in d.items():
            full_key = f"{prefix}_{key}" if prefix else key
            if isinstance(value, dict):
                self._flatten_dict(value, row, prefix=full_key)
            else:
                row[full_key] = value
    
    def get_summary(self) -> Dict[str, Any]:
        """
        Get summary of all experiments.
        
        Returns:
            Dictionary with summary statistics
        """
        if not self.results:
            return {}
        
        summary = {
            "num_experiments": len(self.results),
            "experiment_names": [r.experiment_name for r in self.results],
            "date_range": {
                "earliest": min(r.timestamp for r in self.results),
                "latest": max(r.timestamp for r in self.results),
            },
            "benchmarks": {},
        }
        
        # Collect all benchmark names
        all_benchmarks = set()
        for result in self.results:
            all_benchmarks.update(result.benchmark_results.keys())
        
        # Summary for each benchmark
        for bench_name in all_benchmarks:
            bench_data = []
            for result in self.results:
                if bench_name in result.benchmark_results:
                    bench_data.append(result.benchmark_results[bench_name])
            
            if bench_data:
                summary["benchmarks"][bench_name] = {
                    "num_results": len(bench_data),
                    "available_metrics": list(bench_data[0].keys()) if bench_data else [],
                }
        
        return summary
    
    def generate_report(
        self,
        output_path: Optional[Union[str, Path]] = None,
        format: str = "markdown",
    ) -> str:
        """
        Generate comparison report.
        
        Args:
            output_path: Path to save report (None = return as string)
            format: Report format ("markdown", "html", "text")
            
        Returns:
            Report as string
        """
        if format == "markdown":
            report = self._generate_markdown_report()
        elif format == "html":
            report = self._generate_html_report()
        else:
            report = self._generate_text_report()
        
        if output_path:
            output_path = Path(output_path)
            output_path.write_text(report, encoding="utf-8")
        
        return report
    
    def _generate_markdown_report(self) -> str:
        """Generate markdown report."""
        lines = ["# Experiment Comparison Report\n"]
        lines.append(f"Generated: {datetime.now().isoformat()}\n")
        
        # Summary
        summary = self.get_summary()
        lines.append("## Summary\n")
        lines.append(f"- Number of experiments: {summary['num_experiments']}")
        lines.append(f"- Date range: {summary['date_range']['earliest']} to {summary['date_range']['latest']}")
        lines.append(f"- Experiments: {', '.join(summary['experiment_names'])}\n")
        
        # Benchmark comparison
        lines.append("## Benchmark Comparison\n")
        df = self.compare_benchmarks()
        if not df.empty:
            lines.append(df.to_markdown(index=False))
            lines.append("")
        
        # Configuration comparison
        lines.append("## Configuration Comparison\n")
        config_df = self.compare_configs()
        if not config_df.empty:
            lines.append(config_df.to_markdown(index=False))
            lines.append("")
        
        return "\n".join(lines)
    
    def _generate_html_report(self) -> str:
        """Generate HTML report."""
        html = ["<html><head><title>Experiment Comparison</title></head><body>"]
        html.append("<h1>Experiment Comparison Report</h1>")
        html.append(f"<p>Generated: {datetime.now().isoformat()}</p>")
        
        # Summary
        summary = self.get_summary()
        html.append("<h2>Summary</h2>")
        html.append(f"<ul>")
        html.append(f"<li>Number of experiments: {summary['num_experiments']}</li>")
        html.append(f"<li>Date range: {summary['date_range']['earliest']} to {summary['date_range']['latest']}</li>")
        html.append(f"<li>Experiments: {', '.join(summary['experiment_names'])}</li>")
        html.append(f"</ul>")
        
        # Benchmark comparison
        html.append("<h2>Benchmark Comparison</h2>")
        df = self.compare_benchmarks()
        if not df.empty:
            html.append(df.to_html(index=False))
        
        # Configuration comparison
        html.append("<h2>Configuration Comparison</h2>")
        config_df = self.compare_configs()
        if not config_df.empty:
            html.append(config_df.to_html(index=False))
        
        html.append("</body></html>")
        return "\n".join(html)
    
    def _generate_text_report(self) -> str:
        """Generate plain text report."""
        lines = ["Experiment Comparison Report"]
        lines.append("=" * 50)
        lines.append(f"Generated: {datetime.now().isoformat()}\n")
        
        # Summary
        summary = self.get_summary()
        lines.append("Summary:")
        lines.append(f"  Number of experiments: {summary['num_experiments']}")
        lines.append(f"  Date range: {summary['date_range']['earliest']} to {summary['date_range']['latest']}")
        lines.append(f"  Experiments: {', '.join(summary['experiment_names'])}\n")
        
        # Benchmark comparison
        lines.append("Benchmark Comparison:")
        lines.append("-" * 50)
        df = self.compare_benchmarks()
        if not df.empty:
            lines.append(df.to_string(index=False))
            lines.append("")
        
        # Configuration comparison
        lines.append("Configuration Comparison:")
        lines.append("-" * 50)
        config_df = self.compare_configs()
        if not config_df.empty:
            lines.append(config_df.to_string(index=False))
        
        return "\n".join(lines)
    
    def find_best(
        self,
        benchmark_name: str,
        metric_name: str,
        higher_is_better: bool = True,
    ) -> Optional[ExperimentResult]:
        """
        Find experiment with best metric value.
        
        Args:
            benchmark_name: Benchmark name
            metric_name: Metric name
            higher_is_better: Whether higher values are better
            
        Returns:
            Best experiment result, or None if not found
        """
        best_result = None
        best_value = None
        
        for result in self.results:
            if benchmark_name not in result.benchmark_results:
                continue
            
            benchmark_data = result.benchmark_results[benchmark_name]
            if metric_name not in benchmark_data:
                continue
            
            value = benchmark_data[metric_name]
            
            if best_value is None:
                best_value = value
                best_result = result
            elif higher_is_better and value > best_value:
                best_value = value
                best_result = result
            elif not higher_is_better and value < best_value:
                best_value = value
                best_result = result
        
        return best_result


def compare_experiments(
    experiment_ids: Optional[List[Union[str, Path]]] = None,
    experiment_dirs: Optional[List[Union[str, Path]]] = None,
    results_dir: Union[str, Path] = "./experiment_results",
) -> ExperimentComparator:
    """
    Compare multiple experiments.
    
    Args:
        experiment_ids: List of experiment IDs or paths to result files
        experiment_dirs: List of experiment directories (alternative to experiment_ids)
                        Automatically finds and loads results from each directory
        results_dir: Directory with experiment results (used with experiment_ids)
        
    Returns:
        ExperimentComparator instance
        
    Example:
        >>> # With experiment IDs
        >>> comparator = compare_experiments(
        ...     experiment_ids=["exp1_id", "exp2_id"],
        ...     results_dir="./experiment_results",
        ... )
        >>> df = comparator.compare_benchmarks("accuracy", "accuracy")
        >>> print(df)
        >>>
        >>> # With experiment directories
        >>> comparator = compare_experiments(
        ...     experiment_dirs=["./experiments/exp_001", "./experiments/exp_002"],
        ... )
    """
    from mimir_io.experiment import find_experiment_files
    
    comparator = ExperimentComparator()
    
    # Обробка experiment_dirs
    if experiment_dirs:
        for exp_dir in experiment_dirs:
            exp_dir = Path(exp_dir)
            
            # Шукаємо результати в папці експерименту
            # Спочатку шукаємо JSON файли результатів
            result_files = list(exp_dir.glob("*.json"))
            
            if result_files:
                # Завантажуємо перший знайдений JSON файл результатів
                result = ExperimentResult.load(result_files[0])
                comparator.add_result(result)
            else:
                # Якщо немає JSON файлів, спробуємо створити результат з наявних файлів
                exp_files = find_experiment_files(exp_dir)
                
                if exp_files["config"]:
                    # Завантажуємо конфігурацію та створюємо базовий результат
                    from mimir_io.models.config import load_config
                    config_dict = load_config(exp_files["config"])
                    
                    # Створюємо мінімальний результат для порівняння
                    result = ExperimentResult(
                        experiment_name=exp_dir.name,
                        config=config_dict,
                        training_metrics={},
                        benchmark_results={},
                        metadata={
                            "experiment_dir": str(exp_dir),
                            "checkpoint_path": str(exp_files["checkpoint"]) if exp_files["checkpoint"] else None,
                            "config_path": str(exp_files["config"]),
                            "split_path": str(exp_files["split"]) if exp_files["split"] else None,
                        },
                    )
                    comparator.add_result(result)
                else:
                    raise FileNotFoundError(
                        f"Could not find experiment results or config in directory: {exp_dir}"
                    )
    
    # Обробка experiment_ids (якщо вказано)
    if experiment_ids:
        manager = ExperimentResultsManager(results_dir)
        
        for exp_id in experiment_ids:
            result = manager.load_result(exp_id)
            comparator.add_result(result)
    
    if not comparator.results:
        raise ValueError("No experiments to compare. Provide either experiment_ids or experiment_dirs.")
    
    return comparator

