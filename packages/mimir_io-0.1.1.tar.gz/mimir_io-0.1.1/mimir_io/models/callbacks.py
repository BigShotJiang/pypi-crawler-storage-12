"""
Callbacks for training models.

Provides a callback system for metrics, images, and other events during training.
"""

from typing import Dict, Any, Optional, List, Callable, Union
from pathlib import Path
from abc import ABC, abstractmethod
from datetime import datetime
import warnings
import json
import csv

try:
    import torch
    import torch.nn as nn
    import numpy as np
    from torch.utils.data import DataLoader
    _torch_available = True
except ImportError:
    _torch_available = False
    torch = object  # type: ignore
    nn = object  # type: ignore
    DataLoader = object  # type: ignore
    np = object  # type: ignore


class Callback(ABC):
    """
    Base class for callbacks.
    
    All callbacks should inherit from this class.
    """
    
    def on_train_begin(self, trainer: Any) -> None:
        """Called at the beginning of training."""
        pass
    
    def on_train_end(self, trainer: Any) -> None:
        """Called at the end of training."""
        pass
    
    def on_epoch_begin(self, trainer: Any, epoch: int) -> None:
        """Called at the beginning of an epoch."""
        pass
    
    def on_epoch_end(self, trainer: Any, epoch: int, metrics: Dict[str, float]) -> None:
        """Called at the end of an epoch."""
        pass
    
    def on_batch_begin(self, trainer: Any, batch_idx: int) -> None:
        """Called at the beginning of a batch."""
        pass
    
    def on_batch_end(self, trainer: Any, batch_idx: int, loss: float) -> None:
        """Called at the end of a batch."""
        pass
    
    def on_test_begin(self, tester: Any) -> None:
        """Called at the beginning of testing."""
        pass
    
    def on_test_end(self, tester: Any, metrics: Dict[str, float]) -> None:
        """Called at the end of testing."""
        pass


class ImageMetricsCallback(Callback):
    """
    Callback for saving metrics as images.
    
    Supports various types of metrics:
    - Loss plots (train/val)
    - Confusion matrix
    - ROC curves
    - Sample predictions with visualization
    """
    
    def __init__(
        self,
        save_dir: Union[str, Path] = "./metrics_images",
        save_loss_plot: bool = True,
        save_confusion_matrix: bool = True,
        save_sample_predictions: bool = True,
        num_samples: int = 8,
        save_every_n_epochs: int = 1,
    ):
        """
        Initialize image metrics callback.
        
        Args:
            save_dir: Directory for saving images
            save_loss_plot: Whether to save loss plot
            save_confusion_matrix: Whether to save confusion matrix
            save_sample_predictions: Whether to save sample predictions
            num_samples: Number of samples for visualization
            save_every_n_epochs: Save every N epochs
        """
        if not _torch_available:
            raise ImportError("PyTorch is required for callbacks")
        
        self.save_dir = Path(save_dir)
        self.save_dir.mkdir(parents=True, exist_ok=True)
        
        self.save_loss_plot = save_loss_plot
        self.save_confusion_matrix = save_confusion_matrix
        self.save_sample_predictions = save_sample_predictions
        self.num_samples = num_samples
        self.save_every_n_epochs = save_every_n_epochs
        
        # Metrics history
        self.train_losses: List[float] = []
        self.val_losses: List[float] = []
        self.val_accuracies: List[float] = []
        self.epochs: List[int] = []
        
        # For confusion matrix
        self.all_predictions: List[torch.Tensor] = []
        self.all_labels: List[torch.Tensor] = []
    
    def on_train_begin(self, trainer: Any) -> None:
        """Initialize at the beginning of training."""
        self.train_losses.clear()
        self.val_losses.clear()
        self.val_accuracies.clear()
        self.epochs.clear()
        self.all_predictions.clear()
        self.all_labels.clear()
    
    def on_epoch_end(self, trainer: Any, epoch: int, metrics: Dict[str, float]) -> None:
        """Save metrics after epoch."""
        # Save metrics
        self.epochs.append(epoch)
        self.train_losses.append(metrics.get("train_loss", 0.0))
        
        if "val_loss" in metrics:
            self.val_losses.append(metrics["val_loss"])
        if "val_accuracy" in metrics:
            self.val_accuracies.append(metrics["val_accuracy"])
        
        # Save images every N epochs
        if epoch % self.save_every_n_epochs == 0:
            if self.save_loss_plot:
                self._save_loss_plot(epoch)
            
            if self.save_confusion_matrix and trainer.val_loader is not None:
                self._save_confusion_matrix(trainer, epoch)
            
            if self.save_sample_predictions and trainer.val_loader is not None:
                self._save_sample_predictions(trainer, epoch)
    
    def _save_loss_plot(self, epoch: int) -> None:
        """Save loss plot."""
        try:
            import matplotlib
            matplotlib.use('Agg')  # Non-interactive backend
            import matplotlib.pyplot as plt
        except ImportError:
            warnings.warn("matplotlib is not installed, skipping loss plot saving")
            return
        
        plt.figure(figsize=(12, 5))
        
        # Loss plot
        plt.subplot(1, 2, 1)
        plt.plot(self.epochs, self.train_losses, label='Train Loss', marker='o')
        if self.val_losses:
            plt.plot(self.epochs, self.val_losses, label='Val Loss', marker='s')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.title('Training and Validation Loss')
        plt.legend()
        plt.grid(True)
        
        # Accuracy plot
        if self.val_accuracies:
            plt.subplot(1, 2, 2)
            plt.plot(self.epochs, self.val_accuracies, label='Val Accuracy', marker='^', color='green')
            plt.xlabel('Epoch')
            plt.ylabel('Accuracy (%)')
            plt.title('Validation Accuracy')
            plt.legend()
            plt.grid(True)
        
        plt.tight_layout()
        plot_path = self.save_dir / f"loss_plot_epoch_{epoch + 1}.png"
        plt.savefig(plot_path, dpi=150, bbox_inches='tight')
        plt.close()
    
    def _save_confusion_matrix(self, trainer: Any, epoch: int) -> None:
        """Save confusion matrix."""
        try:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt
            from sklearn.metrics import confusion_matrix
        except ImportError:
            warnings.warn("matplotlib or sklearn is not installed, skipping confusion matrix")
            return
        
        try:
            import seaborn as sns
            use_seaborn = True
        except ImportError:
            use_seaborn = False
        
        # Collect all predictions and labels
        all_preds = []
        all_labels_list = []
        
        trainer.model.eval()
        with torch.no_grad():
            for features, labels in trainer.val_loader:
                features = features.to(trainer.device)
                labels = labels.to(trainer.device)
                
                outputs = trainer.model(features)
                _, predicted = torch.max(outputs.data, 1)
                
                all_preds.extend(predicted.cpu().numpy())
                all_labels_list.extend(labels.cpu().numpy())
        
        # Create confusion matrix
        cm = confusion_matrix(all_labels_list, all_preds)
        
        # Visualize
        plt.figure(figsize=(10, 8))
        if use_seaborn:
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=True)
        else:
            plt.imshow(cm, interpolation='nearest', cmap='Blues')
            plt.colorbar()
            # Add annotations
            for i in range(cm.shape[0]):
                for j in range(cm.shape[1]):
                    plt.text(j, i, str(cm[i, j]), ha='center', va='center')
        plt.xlabel('Predicted')
        plt.ylabel('Actual')
        plt.title(f'Confusion Matrix - Epoch {epoch + 1}')
        
        cm_path = self.save_dir / f"confusion_matrix_epoch_{epoch + 1}.png"
        plt.savefig(cm_path, dpi=150, bbox_inches='tight')
        plt.close()
    
    def _save_sample_predictions(self, trainer: Any, epoch: int) -> None:
        """Save sample predictions."""
        try:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt
        except ImportError:
            warnings.warn("matplotlib is not installed, skipping sample predictions saving")
            return
        
        trainer.model.eval()
        
        # Get one batch
        batch = next(iter(trainer.val_loader))
        features, labels = batch
        features = features.to(trainer.device)
        labels = labels.to(trainer.device)
        
        with torch.no_grad():
            outputs = trainer.model(features)
            _, predicted = torch.max(outputs.data, 1)
            probabilities = torch.softmax(outputs, dim=1)
        
        # Limit number of samples
        num_samples = min(self.num_samples, features.size(0))
        
        # Create visualization
        fig, axes = plt.subplots(2, num_samples, figsize=(2 * num_samples, 4))
        if num_samples == 1:
            axes = axes.reshape(2, 1)
        
        for i in range(num_samples):
            # Top row: input data (spectrogram)
            if features.dim() == 3:  # (batch, n_mels, time)
                spec = features[i].cpu().numpy()
                axes[0, i].imshow(spec, aspect='auto', origin='lower', cmap='viridis')
            elif features.dim() == 4:  # (batch, channels, n_mels, time)
                spec = features[i, 0].cpu().numpy()
                axes[0, i].imshow(spec, aspect='auto', origin='lower', cmap='viridis')
            
            axes[0, i].set_title(f'Input {i+1}')
            axes[0, i].axis('off')
            
            # Bottom row: predictions
            prob = probabilities[i].cpu().numpy()
            axes[1, i].bar(range(len(prob)), prob)
            axes[1, i].set_title(f'Pred: {predicted[i].item()}, True: {labels[i].item()}')
            axes[1, i].set_xlabel('Class')
            axes[1, i].set_ylabel('Probability')
            axes[1, i].set_ylim([0, 1])
        
        plt.tight_layout()
        pred_path = self.save_dir / f"predictions_epoch_{epoch + 1}.png"
        plt.savefig(pred_path, dpi=150, bbox_inches='tight')
        plt.close()


class CSVLoggerCallback(Callback):
    """
    Callback for logging metrics to CSV and/or JSON files.
    
    Automatically saves all training metrics after each epoch in structured format.
    Supports both CSV (for easy analysis) and JSON (for programmatic access).
    """
    
    def __init__(
        self,
        log_dir: Union[str, Path] = "./logs",
        filename: Optional[str] = None,
        format: str = "csv",  # "csv", "json", or "both"
        append: bool = False,
        include_timestamp: bool = True,
        extra_metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize CSV logger callback.
        
        Args:
            log_dir: Directory for saving log files
            filename: Base filename (without extension). If None, uses timestamp
            format: Output format - "csv", "json", or "both"
            append: Whether to append to existing file (CSV only)
            include_timestamp: Whether to include timestamp in each row
            extra_metadata: Additional metadata to include in each log entry
        """
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        self.format = format.lower()
        if self.format not in ["csv", "json", "both"]:
            raise ValueError(f"format must be 'csv', 'json', or 'both', got '{format}'")
        
        self.append = append
        self.include_timestamp = include_timestamp
        self.extra_metadata = extra_metadata or {}
        
        # Generate filename if not provided
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"metrics_{timestamp}"
        self.filename = filename
        
        # File paths
        self.csv_path = self.log_dir / f"{self.filename}.csv"
        self.json_path = self.log_dir / f"{self.filename}.json"
        
        # Metrics history
        self.metrics_history: List[Dict[str, Any]] = []
        
        # Track if CSV header was written
        self._csv_header_written = False
    
    def on_train_begin(self, trainer: Any) -> None:
        """Initialize at the beginning of training."""
        self.metrics_history.clear()
        self._csv_header_written = False
        
        # Write CSV header if not appending
        if self.format in ["csv", "both"] and not self.append:
            self._write_csv_header()
    
    def on_epoch_end(self, trainer: Any, epoch: int, metrics: Dict[str, float]) -> None:
        """Log metrics after each epoch."""
        # Prepare log entry
        log_entry: Dict[str, Any] = {
            "epoch": epoch,
            **metrics,
        }
        
        # Add timestamp if requested
        if self.include_timestamp:
            log_entry["timestamp"] = datetime.now().isoformat()
        
        # Add extra metadata
        if self.extra_metadata:
            log_entry.update(self.extra_metadata)
        
        # Add to history
        self.metrics_history.append(log_entry)
        
        # Save to files
        if self.format in ["csv", "both"]:
            self._write_csv_row(log_entry)
        
        if self.format in ["json", "both"]:
            self._write_json()
    
    def on_train_end(self, trainer: Any) -> None:
        """Finalize logging at the end of training."""
        # Ensure final JSON is written
        if self.format in ["json", "both"]:
            self._write_json()
    
    def on_test_end(self, tester: Any, metrics: Dict[str, float]) -> None:
        """Log test metrics."""
        log_entry: Dict[str, Any] = {
            "test": True,
            **metrics,
        }
        
        if self.include_timestamp:
            log_entry["timestamp"] = datetime.now().isoformat()
        
        if self.extra_metadata:
            log_entry.update(self.extra_metadata)
        
        self.metrics_history.append(log_entry)
        
        if self.format in ["csv", "both"]:
            self._write_csv_row(log_entry)
        
        if self.format in ["json", "both"]:
            self._write_json()
    
    def _write_csv_header(self) -> None:
        """Write CSV header."""
        if self.metrics_history:
            # Get all keys from first entry
            all_keys = list(self.metrics_history[0].keys())
        else:
            # Default keys if no data yet
            all_keys = ["epoch", "timestamp", "train_loss"]
        
        with open(self.csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=all_keys, extrasaction="ignore")
            writer.writeheader()
        self._csv_header_written = True
    
    def _write_csv_row(self, log_entry: Dict[str, Any]) -> None:
        """Write a single row to CSV."""
        # Collect all keys from all entries to ensure consistency
        all_keys = set()
        for entry in self.metrics_history:
            all_keys.update(entry.keys())
        all_keys = sorted(all_keys)
        
        # Determine file mode
        file_exists = self.csv_path.exists()
        if not self._csv_header_written:
            mode = "w"
        elif self.append and file_exists:
            mode = "a"
        else:
            mode = "w"
        
        with open(self.csv_path, mode, newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=all_keys, extrasaction="ignore")
            
            # Write header if needed
            if mode == "w" or not self._csv_header_written:
                writer.writeheader()
                self._csv_header_written = True
            
            writer.writerow(log_entry)
    
    def _write_json(self) -> None:
        """Write metrics history to JSON file."""
        with open(self.json_path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "experiment": {
                        "filename": self.filename,
                        "created_at": self.metrics_history[0]["timestamp"] if self.metrics_history and "timestamp" in self.metrics_history[0] else None,
                        "total_epochs": len(self.metrics_history),
                    },
                    "metrics": self.metrics_history,
                },
                f,
                indent=2,
                ensure_ascii=False,
            )
    
    def get_best_metric(self, metric_name: str, mode: str = "min") -> Optional[Dict[str, Any]]:
        """
        Get the best metric value from history.
        
        Args:
            metric_name: Name of the metric to find
            mode: "min" or "max" for finding best value
            
        Returns:
            Dictionary with epoch and metric value, or None if not found
        """
        if not self.metrics_history:
            return None
        
        best_entry = None
        best_value = float("inf") if mode == "min" else float("-inf")
        
        for entry in self.metrics_history:
            if metric_name in entry:
                value = entry[metric_name]
                if (mode == "min" and value < best_value) or (mode == "max" and value > best_value):
                    best_value = value
                    best_entry = entry
        
        if best_entry:
            return {
                "epoch": best_entry.get("epoch"),
                metric_name: best_value,
                "entry": best_entry,
            }
        return None


class EarlyStoppingCallback(Callback):
    """
    Callback for early stopping.
    
    Stops training if the metric does not improve for a specified number of epochs.
    """
    
    def __init__(
        self,
        monitor: str = "val_loss",
        patience: int = 5,
        min_delta: float = 0.0,
        mode: str = "min",
        restore_best_weights: bool = True,
    ):
        """
        Initialize early stopping callback.
        
        Args:
            monitor: Metric to monitor (e.g., "val_loss", "val_accuracy")
            patience: Number of epochs without improvement before stopping
            min_delta: Minimum change to consider as improvement
            mode: "min" for minimization (loss) or "max" for maximization (accuracy)
            restore_best_weights: Whether to restore best weights after stopping
        """
        self.monitor = monitor
        self.patience = patience
        self.min_delta = min_delta
        self.mode = mode
        self.restore_best_weights = restore_best_weights
        
        self.patience_counter = 0
        self.best_value = float("inf") if mode == "min" else float("-inf")
        self.best_epoch = 0
        self.best_weights = None
        self.stopped_epoch = 0
    
    def on_train_begin(self, trainer: Any) -> None:
        """Initialize at the beginning of training."""
        self.patience_counter = 0
        self.best_value = float("inf") if self.mode == "min" else float("-inf")
        self.best_epoch = 0
        self.best_weights = None
        self.stopped_epoch = 0
    
    def on_epoch_end(self, trainer: Any, epoch: int, metrics: Dict[str, float]) -> None:
        """Check early stopping conditions after epoch."""
        if self.monitor not in metrics:
            warnings.warn(f"Metric '{self.monitor}' not found in metrics, early stopping disabled")
            return
        
        current_value = metrics[self.monitor]
        
        # Determine if there is improvement
        if self.mode == "min":
            is_better = current_value < (self.best_value - self.min_delta)
        else:  # mode == "max"
            is_better = current_value > (self.best_value + self.min_delta)
        
        if is_better:
            self.best_value = current_value
            self.best_epoch = epoch
            self.patience_counter = 0
            
            # Save best weights
            if self.restore_best_weights:
                self.best_weights = trainer.model.state_dict().copy()
        else:
            self.patience_counter += 1
        
        # Check if we need to stop
        if self.patience_counter >= self.patience:
            self.stopped_epoch = epoch
            trainer.should_stop = True
            print(f"\nEarly stopping triggered at epoch {epoch + 1}")
            print(f"Best {self.monitor}: {self.best_value:.4f} at epoch {self.best_epoch + 1}")
            
            # Restore best weights
            if self.restore_best_weights and self.best_weights is not None:
                trainer.model.load_state_dict(self.best_weights)
                print("Restored best model weights")
    
    def on_train_end(self, trainer: Any) -> None:
        """Actions at the end of training."""
        if self.stopped_epoch > 0:
            print(f"Training stopped early at epoch {self.stopped_epoch + 1}")


class WarmupInfoCallback(Callback):
    """
    Callback for displaying warmup scheduler information during training.
    
    Shows progress bar and detailed information about warmup period.
    Integrates warmup info into the main training progress display.
    """
    
    def __init__(
        self,
        show_progress: bool = True,
        verbose: bool = True,
    ):
        """
        Initialize warmup info callback.
        
        Args:
            show_progress: Whether to show progress information
            verbose: Whether to print detailed warmup information
        """
        self.show_progress = show_progress
        self.verbose = verbose
        self.warmup_info = {
            "started": False,
            "finished": False,
            "mode": None,  # "epoch" or "step"
            "total": 0,
            "current": 0,
            "start_lr": 0.0,
            "target_lr": 0.0,
            "current_lr": 0.0,
        }
    
    def on_train_begin(self, trainer: Any) -> None:
        """Initialize warmup tracking at the beginning of training."""
        self.warmup_info["started"] = False
        self.warmup_info["finished"] = False
        
        # Check if warmup scheduler is used
        if hasattr(trainer, 'scheduler') and trainer.scheduler is not None:
            try:
                from mimir_io.models.warmup_scheduler import WarmupScheduler
                if isinstance(trainer.scheduler, WarmupScheduler):
                    scheduler = trainer.scheduler
                    if not scheduler.warmup_finished:
                        self.warmup_info["started"] = True
                        self.warmup_info["start_lr"] = scheduler.warmup_start_lr
                        self.warmup_info["target_lr"] = scheduler.max_lr
                        self.warmup_info["current_lr"] = scheduler.warmup_start_lr
                        
                        if scheduler.warmup_steps is not None:
                            self.warmup_info["mode"] = "step"
                            self.warmup_info["total"] = scheduler.warmup_steps
                            self.warmup_info["current"] = scheduler.current_step
                        elif scheduler.warmup_epochs is not None:
                            self.warmup_info["mode"] = "epoch"
                            self.warmup_info["total"] = scheduler.warmup_epochs
                            self.warmup_info["current"] = 0
                        
                        if self.verbose:
                            print(f"\nWarmup Started:")
                            print(f"   Mode: {self.warmup_info['mode']}-based")
                            print(f"   Total: {self.warmup_info['total']} {self.warmup_info['mode']}s")
                            print(f"   Start LR: {self.warmup_info['start_lr']:.2e}")
                            print(f"   Target LR: {self.warmup_info['target_lr']:.2e}\n")
            except ImportError:
                pass
    
    def on_epoch_begin(self, trainer: Any, epoch: int) -> None:
        """Update warmup info at the beginning of epoch."""
        if self.warmup_info["started"] and not self.warmup_info["finished"]:
            if hasattr(trainer, 'scheduler') and trainer.scheduler is not None:
                try:
                    from mimir_io.models.warmup_scheduler import WarmupScheduler
                    if isinstance(trainer.scheduler, WarmupScheduler):
                        scheduler = trainer.scheduler
                        if scheduler.warmup_finished:
                            self._finish_warmup()
                        else:
                            if self.warmup_info["mode"] == "epoch":
                                self.warmup_info["current"] = epoch + 1
                                self.warmup_info["current_lr"] = scheduler.get_last_lr()[0]
                except ImportError:
                    pass
    
    def on_batch_end(self, trainer: Any, batch_idx: int, loss: float) -> None:
        """Update warmup info at the end of batch (for step-based warmup)."""
        if self.warmup_info["started"] and not self.warmup_info["finished"]:
            if hasattr(trainer, 'scheduler') and trainer.scheduler is not None:
                try:
                    from mimir_io.models.warmup_scheduler import WarmupScheduler
                    if isinstance(trainer.scheduler, WarmupScheduler):
                        scheduler = trainer.scheduler
                        if scheduler.warmup_finished:
                            self._finish_warmup()
                        else:
                            if self.warmup_info["mode"] == "step":
                                self.warmup_info["current"] = scheduler.current_step
                                self.warmup_info["current_lr"] = scheduler.get_last_lr()[0]
                except ImportError:
                    pass
    
    def get_warmup_info_string(self) -> str:
        """Get formatted string with current warmup information."""
        if not self.warmup_info["started"] or self.warmup_info["finished"]:
            return ""
        
        progress = (self.warmup_info["current"] / self.warmup_info["total"]) * 100 if self.warmup_info["total"] > 0 else 0
        return (
            f"Warmup: {self.warmup_info['current']}/{self.warmup_info['total']} "
            f"({progress:.1f}%) | LR: {self.warmup_info['current_lr']:.2e} -> {self.warmup_info['target_lr']:.2e}"
        )
    
    def _finish_warmup(self) -> None:
        """Finish warmup and print completion message."""
        if self.warmup_info["finished"]:
            return
        
        self.warmup_info["finished"] = True
        
        if self.verbose:
            print(f"\nWarmup Completed!")
            print(f"   Final LR: {self.warmup_info['current_lr']:.2e}")
            print(f"   Transitioning to base scheduler...\n")


class TensorBoardCallback(Callback):
    """
    Callback for logging metrics to TensorBoard.
    
    Automatically logs all training metrics, learning rates, and model graphs
    to TensorBoard for real-time visualization.
    
    Each training run gets its own subdirectory, allowing easy comparison
    of multiple runs in TensorBoard.
    """
    
    def __init__(
        self,
        log_dir: Union[str, Path] = "./logs/tensorboard",
        experiment_name: Optional[str] = None,
        log_every_n_epochs: int = 1,
        log_every_n_batches: Optional[int] = None,
        write_graph: bool = True,
        auto_create_run_dir: bool = True,
    ):
        """
        Initialize TensorBoard callback.
        
        Args:
            log_dir: Base directory for TensorBoard logs
            experiment_name: Name for this run (default: auto-generated with timestamp)
            log_every_n_epochs: Log metrics every N epochs (default: 1, every epoch)
            log_every_n_batches: Log metrics every N batches (None = only at epoch end)
            write_graph: Whether to write model graph to TensorBoard
            auto_create_run_dir: If True, creates subdirectory for each run (default: True)
        """
        self.base_log_dir = Path(log_dir)
        self.experiment_name = experiment_name
        self.log_every_n_epochs = log_every_n_epochs
        self.log_every_n_batches = log_every_n_batches
        self.write_graph = write_graph
        self.auto_create_run_dir = auto_create_run_dir
        self.writer = None
        self.global_step = 0
        self.batch_step = 0
        self.run_log_dir = None  # Will be set in on_train_begin
        
        # Check if tensorboard is available
        try:
            from torch.utils.tensorboard import SummaryWriter
            self._tensorboard_available = True
            self.SummaryWriter = SummaryWriter
        except ImportError:
            self._tensorboard_available = False
            warnings.warn(
                "TensorBoard is not installed. Install with: pip install tensorboard",
                ImportWarning
            )
    
    def _get_run_name(self, trainer: Any) -> str:
        """Generate run name from experiment_name or trainer config."""
        if self.experiment_name:
            return self.experiment_name
        
        # Try to get experiment_name from trainer config
        if hasattr(trainer, 'config'):
            exp_name = trainer.config.get('experiment_name')
            if exp_name:
                return exp_name
        
        # Try to get from ExperimentConfig if available
        try:
            from mimir_io.experiment import ExperimentConfig
            if hasattr(trainer, 'config') and isinstance(trainer.config, dict):
                # Check if config has experiment_name
                exp_name = trainer.config.get('experiment_name')
                if exp_name:
                    return exp_name
        except ImportError:
            pass
        
        # Generate unique name with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"run_{timestamp}"
    
    def on_train_begin(self, trainer: Any) -> None:
        """Initialize TensorBoard writer at the beginning of training."""
        if not self._tensorboard_available:
            return
        
        # Determine run name
        run_name = self._get_run_name(trainer)
        
        # Create run-specific log directory
        if self.auto_create_run_dir:
            # Create subdirectory for this run
            safe_run_name = "".join(c if c.isalnum() or c in ('-', '_') else '_' for c in run_name)
            self.run_log_dir = self.base_log_dir / safe_run_name
        else:
            # Use base directory directly
            self.run_log_dir = self.base_log_dir
        
        self.run_log_dir.mkdir(parents=True, exist_ok=True)
        self.writer = self.SummaryWriter(log_dir=str(self.run_log_dir))
        self.global_step = 0
        self.batch_step = 0
        
        print(f"TensorBoard logging to: {self.run_log_dir}")
        print(f"  Run name: {run_name}")
        print(f"  View with: tensorboard --logdir={self.base_log_dir}")
        
        # Write model graph if requested
        if self.write_graph and hasattr(trainer, 'model'):
            try:
                # Try to get a sample input
                if trainer.train_loader is not None:
                    sample_batch = next(iter(trainer.train_loader))
                    if isinstance(sample_batch, (list, tuple)) and len(sample_batch) > 0:
                        sample_input = sample_batch[0]
                        if sample_input.shape[0] > 0:
                            # Use first sample from batch
                            sample_input = sample_input[0:1]
                            self.writer.add_graph(trainer.model, sample_input.to(trainer.device))
            except Exception as e:
                warnings.warn(f"Could not write model graph to TensorBoard: {e}")
    
    def on_epoch_end(self, trainer: Any, epoch: int, metrics: Dict[str, float]) -> None:
        """Log metrics after each epoch."""
        if not self._tensorboard_available or self.writer is None:
            return
        
        if epoch % self.log_every_n_epochs == 0:
            # Log all metrics
            for metric_name, metric_value in metrics.items():
                if isinstance(metric_value, (int, float)):
                    self.writer.add_scalar(f"metrics/{metric_name}", metric_value, epoch)
            
            # Log learning rate if available
            if hasattr(trainer, 'optimizer') and trainer.optimizer is not None:
                for i, param_group in enumerate(trainer.optimizer.param_groups):
                    lr = param_group.get('lr', None)
                    if lr is not None:
                        tag = f"learning_rate/group_{i}" if len(trainer.optimizer.param_groups) > 1 else "learning_rate"
                        self.writer.add_scalar(tag, lr, epoch)
            
            self.global_step = epoch + 1
    
    def on_batch_end(self, trainer: Any, batch_idx: int, loss: float) -> None:
        """Log batch metrics if configured."""
        if not self._tensorboard_available or self.writer is None:
            return
        
        if self.log_every_n_batches is not None:
            if batch_idx % self.log_every_n_batches == 0:
                self.writer.add_scalar("batch/train_loss", loss, self.batch_step)
                self.batch_step += 1
    
    def on_train_end(self, trainer: Any) -> None:
        """Close TensorBoard writer at the end of training."""
        if self.writer is not None:
            self.writer.close()
            self.writer = None
    
    def on_test_end(self, tester: Any, metrics: Dict[str, float]) -> None:
        """Log test metrics."""
        if not self._tensorboard_available or self.writer is None:
            return
        
        for metric_name, metric_value in metrics.items():
            if isinstance(metric_value, (int, float)):
                self.writer.add_scalar(f"test/{metric_name}", metric_value, self.global_step)


class WandBCallback(Callback):
    """
    Callback for logging metrics to Weights & Biases (W&B).
    
    Automatically logs all training metrics, hyperparameters, and system info
    to W&B for experiment tracking and visualization.
    """
    
    def __init__(
        self,
        project: Optional[str] = None,
        name: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
        log_every_n_epochs: int = 1,
        log_every_n_batches: Optional[int] = None,
        save_code: bool = True,
        tags: Optional[List[str]] = None,
    ):
        """
        Initialize WandB callback.
        
        Args:
            project: W&B project name (default: "mimir_io")
            name: Run name (default: auto-generated)
            config: Dictionary of hyperparameters to log
            log_every_n_epochs: Log metrics every N epochs (default: 1)
            log_every_n_batches: Log metrics every N batches (None = only at epoch end)
            save_code: Whether to save code to W&B
            tags: List of tags for the run
        """
        self.project = project or "mimir_io"
        self.name = name
        self.config = config or {}
        self.log_every_n_epochs = log_every_n_epochs
        self.log_every_n_batches = log_every_n_batches
        self.save_code = save_code
        self.tags = tags or []
        self.wandb = None
        self.run = None
        self.batch_step = 0
        
        # Check if wandb is available
        try:
            import wandb
            self._wandb_available = True
            self.wandb = wandb
        except ImportError:
            self._wandb_available = False
            warnings.warn(
                "Weights & Biases is not installed. Install with: pip install wandb",
                ImportWarning
            )
    
    def on_train_begin(self, trainer: Any) -> None:
        """Initialize WandB run at the beginning of training."""
        if not self._wandb_available or self.wandb is None:
            return
        
        # Prepare config
        wandb_config = self.config.copy()
        if hasattr(trainer, 'config'):
            # Merge trainer config into wandb config
            if isinstance(trainer.config, dict):
                wandb_config.update(trainer.config)
        
        # Initialize WandB run
        self.run = self.wandb.init(
            project=self.project,
            name=self.name,
            config=wandb_config,
            tags=self.tags,
            save_code=self.save_code,
        )
        
        self.batch_step = 0
        
        # Log model architecture if available
        if hasattr(trainer, 'model'):
            try:
                # Count parameters
                total_params = sum(p.numel() for p in trainer.model.parameters())
                trainable_params = sum(p.numel() for p in trainer.model.parameters() if p.requires_grad)
                
                self.run.config.update({
                    "model/total_parameters": total_params,
                    "model/trainable_parameters": trainable_params,
                })
            except Exception:
                pass
    
    def on_epoch_end(self, trainer: Any, epoch: int, metrics: Dict[str, float]) -> None:
        """Log metrics after each epoch."""
        if not self._wandb_available or self.run is None:
            return
        
        if epoch % self.log_every_n_epochs == 0:
            # Prepare metrics dict
            log_dict = {}
            
            # Add epoch
            log_dict["epoch"] = epoch
            
            # Add all metrics
            for metric_name, metric_value in metrics.items():
                if isinstance(metric_value, (int, float)):
                    log_dict[metric_name] = metric_value
            
            # Add learning rate if available
            if hasattr(trainer, 'optimizer') and trainer.optimizer is not None:
                for i, param_group in enumerate(trainer.optimizer.param_groups):
                    lr = param_group.get('lr', None)
                    if lr is not None:
                        key = f"learning_rate/group_{i}" if len(trainer.optimizer.param_groups) > 1 else "learning_rate"
                        log_dict[key] = lr
            
            # Log to WandB
            self.run.log(log_dict, step=epoch)
    
    def on_batch_end(self, trainer: Any, batch_idx: int, loss: float) -> None:
        """Log batch metrics if configured."""
        if not self._wandb_available or self.run is None:
            return
        
        if self.log_every_n_batches is not None:
            if batch_idx % self.log_every_n_batches == 0:
                self.run.log({"batch/train_loss": loss}, step=self.batch_step)
                self.batch_step += 1
    
    def on_train_end(self, trainer: Any) -> None:
        """Finish WandB run at the end of training."""
        if self.run is not None:
            self.run.finish()
            self.run = None
    
    def on_test_end(self, tester: Any, metrics: Dict[str, float]) -> None:
        """Log test metrics."""
        if not self._wandb_available or self.run is None:
            return
        
        log_dict = {}
        for metric_name, metric_value in metrics.items():
            if isinstance(metric_value, (int, float)):
                log_dict[f"test/{metric_name}"] = metric_value
        
        if log_dict:
            self.run.log(log_dict)


class CallbackManager:
    """
    Manager for handling callbacks during training.
    """
    
    def __init__(self, callbacks: Optional[List[Callback]] = None):
        """
        Initialize callback manager.
        
        Args:
            callbacks: List of callbacks
        """
        self.callbacks = callbacks or []
    
    def add_callback(self, callback: Callback) -> None:
        """Add callback."""
        self.callbacks.append(callback)
    
    def on_train_begin(self, trainer: Any) -> None:
        """Call on_train_begin for all callbacks."""
        for callback in self.callbacks:
            callback.on_train_begin(trainer)
    
    def on_train_end(self, trainer: Any) -> None:
        """Call on_train_end for all callbacks."""
        for callback in self.callbacks:
            callback.on_train_end(trainer)
    
    def on_epoch_begin(self, trainer: Any, epoch: int) -> None:
        """Call on_epoch_begin for all callbacks."""
        for callback in self.callbacks:
            callback.on_epoch_begin(trainer, epoch)
    
    def on_epoch_end(self, trainer: Any, epoch: int, metrics: Dict[str, float]) -> None:
        """Call on_epoch_end for all callbacks."""
        for callback in self.callbacks:
            callback.on_epoch_end(trainer, epoch, metrics)
    
    def on_batch_begin(self, trainer: Any, batch_idx: int) -> None:
        """Call on_batch_begin for all callbacks."""
        for callback in self.callbacks:
            callback.on_batch_begin(trainer, batch_idx)
    
    def on_batch_end(self, trainer: Any, batch_idx: int, loss: float) -> None:
        """Call on_batch_end for all callbacks."""
        for callback in self.callbacks:
            callback.on_batch_end(trainer, batch_idx, loss)
    
    def on_test_begin(self, tester: Any) -> None:
        """Call on_test_begin for all callbacks."""
        for callback in self.callbacks:
            callback.on_test_begin(tester)
    
    def on_test_end(self, tester: Any, metrics: Dict[str, float]) -> None:
        """Call on_test_end for all callbacks."""
        for callback in self.callbacks:
            callback.on_test_end(tester, metrics)

