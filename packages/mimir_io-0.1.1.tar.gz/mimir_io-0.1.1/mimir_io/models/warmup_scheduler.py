"""
Warmup Scheduler for gradual learning rate warmup.

Warmup scheduler first linearly increases learning rate from a small value
to the target value, then uses the base scheduler.
"""

from typing import Optional, Union, Dict, Any
import math

try:
    import torch
    import torch.optim as optim
    _torch_available = True
except ImportError:
    _torch_available = False
    torch = object  # type: ignore
    optim = object  # type: ignore


class WarmupScheduler:
    """
    Wrapper for scheduler with warmup period.
    
    First linearly increases learning rate from warmup_start_lr to max_lr
    over warmup_epochs (or warmup_steps), then uses the base scheduler.
    
    Args:
        optimizer: PyTorch optimizer
        base_scheduler: Base scheduler (CosineAnnealingLR, StepLR, etc.)
        warmup_epochs: Number of epochs for warmup (default)
        warmup_steps: Number of steps for warmup (alternative to warmup_epochs)
        warmup_start_lr: Initial learning rate for warmup
        warmup_mode: Warmup mode - 'linear' or 'constant'
        last_epoch: Last epoch (for resume training)
    """
    
    def __init__(
        self,
        optimizer: optim.Optimizer,
        base_scheduler: optim.lr_scheduler._LRScheduler,
        warmup_epochs: int = 0,
        warmup_steps: Optional[int] = None,
        warmup_start_lr: Optional[float] = None,
        warmup_mode: str = "linear",
        last_epoch: int = -1,
    ):
        if not _torch_available:
            raise ImportError("PyTorch is required for WarmupScheduler")
        
        self.optimizer = optimizer
        self.base_scheduler = base_scheduler
        self.warmup_mode = warmup_mode
        
        # Determine warmup in epochs or steps
        if warmup_steps is not None:
            self.warmup_steps = warmup_steps
            self.warmup_epochs = None
        else:
            self.warmup_steps = None
            self.warmup_epochs = warmup_epochs
        
        # Determine initial LR for warmup
        if warmup_start_lr is None:
            # Use 1/10 of initial LR or 1e-6, whichever is larger
            initial_lr = optimizer.param_groups[0]["lr"]
            self.warmup_start_lr = min(initial_lr / 10.0, 1e-6)
        else:
            self.warmup_start_lr = warmup_start_lr
        
        # Store initial LR for each param_group
        self.base_lrs = [group["lr"] for group in optimizer.param_groups]
        self.max_lr = max(self.base_lrs)
        
        # Counters
        self.last_epoch = last_epoch
        self.current_step = 0
        
        # Whether warmup is finished
        self.warmup_finished = False
        
        # Initialize warmup
        if self.warmup_epochs is not None and self.warmup_epochs > 0:
            self._init_warmup()
        elif self.warmup_steps is not None and self.warmup_steps > 0:
            self._init_warmup()
        else:
            self.warmup_finished = True
    
    def _init_warmup(self) -> None:
        """Initialize warmup - sets warmup_start_lr for all param_groups."""
        for param_group in self.optimizer.param_groups:
            param_group["lr"] = self.warmup_start_lr
    
    def step(self, epoch: Optional[int] = None, metric: Optional[float] = None) -> None:
        """
        Perform one scheduler step.
        
        Args:
            epoch: Epoch number (for epoch-based schedulers)
            metric: Metric value (for ReduceLROnPlateau)
        """
        if not self.warmup_finished:
            # Warmup period
            if self.warmup_steps is not None:
                # Step-based warmup
                self.current_step += 1
                if self.current_step >= self.warmup_steps:
                    self.warmup_finished = True
                    # Set base_lrs before transitioning to base scheduler
                    for param_group, base_lr in zip(self.optimizer.param_groups, self.base_lrs):
                        param_group["lr"] = base_lr
                else:
                    # Linear LR increase
                    progress = self.current_step / self.warmup_steps
                    if self.warmup_mode == "linear":
                        lr = self.warmup_start_lr + (self.max_lr - self.warmup_start_lr) * progress
                    else:  # constant
                        lr = self.warmup_start_lr
                    
                    for param_group in self.optimizer.param_groups:
                        param_group["lr"] = lr
            else:
                # Epoch-based warmup (called after epoch)
                if epoch is None:
                    self.last_epoch += 1
                    epoch = self.last_epoch
                else:
                    self.last_epoch = epoch
                
                if epoch >= self.warmup_epochs:
                    self.warmup_finished = True
                    # Set base_lrs before transitioning to base scheduler
                    for param_group, base_lr in zip(self.optimizer.param_groups, self.base_lrs):
                        param_group["lr"] = base_lr
                else:
                    # Linear LR increase
                    progress = (epoch + 1) / self.warmup_epochs
                    if self.warmup_mode == "linear":
                        lr = self.warmup_start_lr + (self.max_lr - self.warmup_start_lr) * progress
                    else:  # constant
                        lr = self.warmup_start_lr
                    
                    for param_group in self.optimizer.param_groups:
                        param_group["lr"] = lr
        else:
            # After warmup use base scheduler
            if isinstance(self.base_scheduler, optim.lr_scheduler.ReduceLROnPlateau):
                if metric is not None:
                    self.base_scheduler.step(metric)
            else:
                if epoch is not None:
                    self.base_scheduler.step(epoch)
                else:
                    self.base_scheduler.step()
    
    def get_last_lr(self) -> list:
        """Return last learning rates for all param_groups."""
        return [group["lr"] for group in self.optimizer.param_groups]
    
    def get_warmup_progress(self) -> Dict[str, Any]:
        """
        Get current warmup progress information.
        
        Returns:
            Dictionary with warmup progress details
        """
        if self.warmup_finished:
            return {
                "finished": True,
                "progress": 1.0,
                "current_lr": self.get_last_lr()[0],
                "mode": None,
            }
        
        if self.warmup_steps is not None:
            progress = min(self.current_step / self.warmup_steps, 1.0)
            mode = "step"
            current = self.current_step
            total = self.warmup_steps
        elif self.warmup_epochs is not None:
            progress = min((self.last_epoch + 1) / self.warmup_epochs, 1.0)
            mode = "epoch"
            current = self.last_epoch + 1
            total = self.warmup_epochs
        else:
            return {
                "finished": True,
                "progress": 1.0,
                "current_lr": self.get_last_lr()[0],
                "mode": None,
            }
        
        current_lr = self.get_last_lr()[0]
        
        return {
            "finished": False,
            "progress": progress,
            "current": current,
            "total": total,
            "mode": mode,
            "current_lr": current_lr,
            "start_lr": self.warmup_start_lr,
            "target_lr": self.max_lr,
            "progress_percent": progress * 100,
        }
    
    def get_warmup_info_string(self) -> str:
        """
        Get formatted string with warmup information.
        
        Returns:
            Formatted string with warmup details
        """
        info = self.get_warmup_progress()
        
        if info["finished"]:
            return f"Warmup: Completed | LR: {info['current_lr']:.2e}"
        
        mode_str = info["mode"].capitalize()
        return (
            f"Warmup: {info['current']}/{info['total']} {info['mode']}s "
            f"({info['progress_percent']:.1f}%) | "
            f"LR: {info['current_lr']:.2e} → {info['target_lr']:.2e}"
        )
    
    def state_dict(self) -> dict:
        """Save scheduler state."""
        return {
            "base_scheduler_state": self.base_scheduler.state_dict(),
            "warmup_finished": self.warmup_finished,
            "current_step": self.current_step,
            "last_epoch": self.last_epoch,
            "warmup_start_lr": self.warmup_start_lr,
            "base_lrs": self.base_lrs,
            "max_lr": self.max_lr,
        }
    
    def load_state_dict(self, state_dict: dict) -> None:
        """Load scheduler state."""
        self.base_scheduler.load_state_dict(state_dict["base_scheduler_state"])
        self.warmup_finished = state_dict.get("warmup_finished", False)
        self.current_step = state_dict.get("current_step", 0)
        self.last_epoch = state_dict.get("last_epoch", -1)
        self.warmup_start_lr = state_dict.get("warmup_start_lr", 1e-6)
        self.base_lrs = state_dict.get("base_lrs", [group["lr"] for group in self.optimizer.param_groups])
        self.max_lr = state_dict.get("max_lr", max(self.base_lrs))

