"""
Pipeline visualization.

Allows visualizing the structure of composed pipelines for better understanding
and debugging of data transformations.
"""

from typing import Optional, List, Tuple, Dict, Any
import re

try:
    from mimir_io.lens import Lens
    _lens_available = True
except ImportError:
    _lens_available = False
    Lens = object  # type: ignore

# Try to import visualization libraries
try:
    import graphviz
    _graphviz_available = True
except ImportError:
    _graphviz_available = False

try:
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
    _matplotlib_available = True
except ImportError:
    _matplotlib_available = False


def _parse_pipeline_name(name: str) -> List[str]:
    """
    Parse pipeline name into individual components.
    
    Args:
        name: Pipeline name (e.g., "resample | log_mel_spectrogram | spec_augment")
        
    Returns:
        List of component names
    """
    # Split by " | " to get components
    # Carefully handle cases where " | " might be part of parameters
    components = []
    current = ""
    depth = 0  # Bracket nesting depth
    
    i = 0
    while i < len(name):
        char = name[i]
        
        if char == '(':
            depth += 1
            current += char
        elif char == ')':
            depth -= 1
            current += char
        elif char == '|' and depth == 0 and i + 1 < len(name) and name[i+1] == ' ':
            # Found separator " | " at top level
            if current.strip():
                components.append(current.strip())
            current = ""
            i += 1  # Skip space after |
        else:
            current += char
        
        i += 1
    
    # Add last component
    if current.strip():
        components.append(current.strip())
    
    # If no separators found, return entire string as single component
    if not components:
        components = [name]
    
    return components


def _extract_lens_info(lens: Lens) -> Dict[str, Any]:
    """
    Extract information about Lens for visualization.
    
    Args:
        lens: Lens object
        
    Returns:
        Dictionary with lens information
    """
    info = {
        "name": lens._name,
        "components": _parse_pipeline_name(lens._name),
        "should_cache": getattr(lens, "_should_cache", True),
    }
    return info


def visualize_pipeline(
    pipeline: Lens,
    output_file: Optional[str] = None,
    format: str = "png",
    engine: str = "dot",
    show_cache_info: bool = True,
    style: str = "graphviz",
) -> None:
    """
    Visualize the structure of a transformation pipeline.
    
    Creates a graph showing the sequence of transformations in the pipeline.
    Each node represents one transformation, and arrows show the processing direction.
    
    Args:
        pipeline: Lens object (pipeline) to visualize
        output_file: Path to file for saving visualization (if None, displays graph)
        format: Output format ("png", "svg", "pdf", "jpg")
        engine: Graphviz engine ("dot", "neato", "fdp", "sfdp", "twopi", "circo")
        show_cache_info: Whether to show caching information (if available)
        style: Visualization style ("graphviz" or "matplotlib")
        
    Example:
        >>> from mimir_io.audio import resample, log_mel_spectrogram
        >>> from mimir_io.visualization import visualize_pipeline
        >>> 
        >>> pipeline = (
        ...     resample(16000).no_cache()
        ...     | log_mel_spectrogram(n_mels=80).cache()
        ... )
        >>> visualize_pipeline(pipeline, output_file="pipeline.png")
    """
    if not _lens_available:
        raise ImportError("Lens system is required for pipeline visualization")
    
    info = _extract_lens_info(pipeline)
    components = info["components"]
    
    if len(components) == 0:
        raise ValueError("Pipeline has no components to visualize")
    
    # Choose visualization method
    if style == "graphviz" and _graphviz_available:
        _visualize_with_graphviz(
            components=components,
            output_file=output_file,
            format=format,
            engine=engine,
            show_cache_info=show_cache_info,
            pipeline_info=info,
        )
    elif style == "matplotlib" and _matplotlib_available:
        _visualize_with_matplotlib(
            components=components,
            output_file=output_file,
            format=format,
            show_cache_info=show_cache_info,
            pipeline_info=info,
        )
    else:
        # Fallback: text visualization
        _visualize_as_text(components, show_cache_info=show_cache_info)
        
        if output_file:
            print(f"\nTo save visualization, install graphviz or matplotlib:")
            print(f"  pip install graphviz  # or")
            print(f"  pip install matplotlib")


def _visualize_with_graphviz(
    components: List[str],
    output_file: Optional[str],
    format: str,
    engine: str,
    show_cache_info: bool,
    pipeline_info: Dict[str, Any],
) -> None:
    """Visualize pipeline using graphviz."""
    # Create graph
    dot = graphviz.Digraph(comment="Pipeline Visualization", engine=engine)
    dot.attr(rankdir="LR")  # Left to right
    dot.attr("node", shape="box", style="rounded,filled", fillcolor="lightblue")
    dot.attr("edge", arrowsize="1.5", color="gray")
    
    # Add nodes
    for i, component in enumerate(components):
        # Clean component name (remove parameters in parentheses)
        clean_name = re.sub(r'\([^)]*\)', '', component).strip()
        if not clean_name:
            clean_name = component
        
        # Create label with caching information (if available)
        label = clean_name
        if show_cache_info and i < len(components) - 1:
            # For composed pipelines, it's hard to determine caching of individual components
            # So we just show the name
            pass
        
        node_id = f"node_{i}"
        dot.node(node_id, label=label)
    
    # Add edges (arrows)
    for i in range(len(components) - 1):
        dot.edge(f"node_{i}", f"node_{i+1}")
    
    # Add input and output nodes
    dot.node("input", "Input", shape="ellipse", fillcolor="lightgreen")
    dot.node("output", "Output", shape="ellipse", fillcolor="lightcoral")
    dot.edge("input", "node_0")
    dot.edge(f"node_{len(components)-1}", "output")
    
    # Save or display
    if output_file:
        dot.render(output_file, format=format, cleanup=True)
        print(f"Pipeline visualization saved to {output_file}.{format}")
    else:
        # Display graph (for Jupyter notebook)
        try:
            from IPython.display import display
            display(dot)
        except ImportError:
            # If not in Jupyter, save to temporary file
            import tempfile
            import os
            with tempfile.NamedTemporaryFile(delete=False, suffix=f".{format}") as tmp:
                dot.render(tmp.name, format=format, cleanup=True)
                print(f"Pipeline visualization saved to {tmp.name}.{format}")
                print("(Install IPython to display inline)")


def _visualize_with_matplotlib(
    components: List[str],
    output_file: Optional[str],
    format: str,
    show_cache_info: bool,
    pipeline_info: Dict[str, Any],
) -> None:
    """Visualize pipeline using matplotlib."""
    fig, ax = plt.subplots(figsize=(max(12, len(components) * 2), 6))
    ax.set_xlim(0, len(components) + 1)
    ax.set_ylim(-0.5, 0.5)
    ax.axis("off")
    
    # Node positions
    node_positions = [(i + 1, 0) for i in range(len(components))]
    
    # Add nodes
    for i, (component, (x, y)) in enumerate(zip(components, node_positions)):
        # Clean component name
        clean_name = re.sub(r'\([^)]*\)', '', component).strip()
        if not clean_name:
            clean_name = component
        
        # Limit name length
        if len(clean_name) > 30:
            clean_name = clean_name[:27] + "..."
        
        # Create rectangle for node
        bbox = FancyBboxPatch(
            (x - 0.4, y - 0.15),
            0.8,
            0.3,
            boxstyle="round,pad=0.05",
            facecolor="lightblue",
            edgecolor="black",
            linewidth=1.5,
        )
        ax.add_patch(bbox)
        
        # Add text
        ax.text(x, y, clean_name, ha="center", va="center", fontsize=10, weight="bold")
    
    # Add arrows between nodes
    for i in range(len(components) - 1):
        x1, y1 = node_positions[i]
        x2, y2 = node_positions[i + 1]
        arrow = FancyArrowPatch(
            (x1 + 0.4, y1),
            (x2 - 0.4, y2),
            arrowstyle="->",
            mutation_scale=20,
            color="gray",
            linewidth=2,
        )
        ax.add_patch(arrow)
    
    # Add Input and Output
    input_bbox = FancyBboxPatch(
        (0.1, -0.15),
        0.8,
        0.3,
        boxstyle="round,pad=0.05",
        facecolor="lightgreen",
        edgecolor="black",
        linewidth=1.5,
    )
    ax.add_patch(input_bbox)
    ax.text(0.5, 0, "Input", ha="center", va="center", fontsize=10, weight="bold")
    
    output_bbox = FancyBboxPatch(
        (len(components) + 0.1, -0.15),
        0.8,
        0.3,
        boxstyle="round,pad=0.05",
        facecolor="lightcoral",
        edgecolor="black",
        linewidth=1.5,
    )
    ax.add_patch(output_bbox)
    ax.text(len(components) + 0.5, 0, "Output", ha="center", va="center", fontsize=10, weight="bold")
    
    # Arrows to/from Input/Output
    arrow1 = FancyArrowPatch(
        (0.9, 0),
        (0.6, 0),
        arrowstyle="->",
        mutation_scale=20,
        color="gray",
        linewidth=2,
    )
    ax.add_patch(arrow1)
    
    arrow2 = FancyArrowPatch(
        (len(components) + 0.4, 0),
        (len(components) + 0.1, 0),
        arrowstyle="->",
        mutation_scale=20,
        color="gray",
        linewidth=2,
    )
    ax.add_patch(arrow2)
    
    # Title
    ax.text(
        (len(components) + 1) / 2,
        0.4,
        "Pipeline Visualization",
        ha="center",
        va="center",
        fontsize=14,
        weight="bold",
    )
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, format=format, dpi=150, bbox_inches="tight")
        print(f"Pipeline visualization saved to {output_file}")
    else:
        plt.show()
    
    plt.close()


def _visualize_as_text(
    components: List[str],
    show_cache_info: bool = True,
) -> None:
    """Text visualization of pipeline (fallback)."""
    print("\n" + "=" * 60)
    print("Pipeline Visualization (Text Format)")
    print("=" * 60)
    print("\nInput")
    print("  |")
    
    for i, component in enumerate(components):
        clean_name = re.sub(r'\([^)]*\)', '', component).strip()
        if not clean_name:
            clean_name = component
        
        print(f"  v")
        print(f"  [{clean_name}]")
        if i < len(components) - 1:
            print("  |")
    
    print("  v")
    print("Output")
    print("\n" + "=" * 60)
    print(f"Total components: {len(components)}")
    print("=" * 60 + "\n")

