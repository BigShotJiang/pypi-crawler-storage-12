"""
Testing examples for BaseTester.

Demonstrates different ways to test models using mimir_io's declarative testing API.
"""

import torch
import torch.nn as nn
from pathlib import Path
from typing import Dict, Any

from mimir_io.experiment import quick_test, setup_test, ExperimentConfig
from mimir_io.models import BaseTester, ImageMetricsCallback


# ========== Example Model ==========

class SimpleAudioClassifier(nn.Module):
    """Simple audio classifier for examples."""
    
    def __init__(self, n_mels=80, n_classes=10):
        super().__init__()
        self.fc1 = nn.Linear(n_mels, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, n_classes)
    
    def forward(self, x):
        # x shape: (batch, n_mels, time_frames)
        x = x.mean(dim=2)  # Average over time dimension
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x


# ========== CASE 1: Quick Testing (Simplest) ==========

def case1_quick_test():
    """
    Simplest way to test - minimal code.
    
    Use when:
    - You want to quickly test a trained model
    - You have a saved split from training
    - You want automatic setup and results printing
    """
    # Create model (same architecture as training)
    model = SimpleAudioClassifier(n_mels=80, n_classes=10)
    
    # Quick test using saved split
    tester = quick_test(
        model=model,
        split_path="./data/split.json",
        checkpoint_path="./checkpoints/best_model.pt",
    )
    
    # Results are automatically printed
    return tester


# ========== CASE 2: Testing with Custom Configuration ==========

def case2_test_with_config():
    """
    Testing with custom configuration.
    
    Use when:
    - You need custom batch size or other parameters
    - You want to ensure same config as training
    """
    # Create model
    model = SimpleAudioClassifier(n_mels=80, n_classes=10)
    
    # Use same config as training
    config = ExperimentConfig(
        batch_size=64,  # Larger batch for faster testing
        n_mels=80,
        sample_rate=16000,
        criterion="CrossEntropyLoss",
    )
    
    # Test with configuration
    tester = quick_test(
        model=model,
        split_path="./data/split.json",
        checkpoint_path="./checkpoints/best_model.pt",
        config=config,
    )
    
    return tester


# ========== CASE 3: Flexible Testing Setup ==========

def case3_flexible_test():
    """
    More flexible control over testing process.
    
    Use when:
    - You need access to test_loader before testing
    - You want to add custom logic or callbacks
    - You want to control the testing process
    """
    # Create model
    model = SimpleAudioClassifier(n_mels=80, n_classes=10)
    
    # Setup test
    test_loader, dataset, testing_config = setup_test(
        split_path="./data/split.json",
        use_test_split=True,
    )
    
    # Create tester
    tester = BaseTester(
        model=model,
        config=testing_config,
        test_loader=test_loader,
        checkpoint_path="./checkpoints/best_model.pt",
    )
    
    # Run test
    metrics = tester.test()
    
    # Print results
    print("\nTest Results:")
    print(f"  Test Accuracy: {metrics['test_accuracy']:.2f}%")
    print(f"  Test Loss: {metrics['test_loss']:.4f}")
    
    return tester


# ========== CASE 4: Testing with Callbacks ==========

def case4_test_with_callbacks():
    """
    Testing with callbacks for detailed metrics.
    
    Use when:
    - You want to save confusion matrix
    - You want to visualize sample predictions
    - You need custom metrics collection
    """
    # Create model
    model = SimpleAudioClassifier(n_mels=80, n_classes=10)
    
    # Setup test
    test_loader, dataset, testing_config = setup_test(
        split_path="./data/split.json",
        use_test_split=True,
    )
    
    # Create callbacks
    callbacks = [
        ImageMetricsCallback(
            save_dir="./test_metrics",
            save_confusion_matrix=True,
            save_sample_predictions=True,
            num_samples=8,
        ),
    ]
    
    # Create tester with callbacks
    tester = BaseTester(
        model=model,
        config=testing_config,
        test_loader=test_loader,
        checkpoint_path="./checkpoints/best_model.pt",
        callbacks=callbacks,
    )
    
    # Run test (callbacks will save images)
    metrics = tester.test()
    
    return tester


# ========== CASE 5: Testing on Custom Files ==========

def case5_test_custom_files():
    """
    Testing on custom files not in the original split.
    
    Use when:
    - You have new test data
    - You want to test on different distribution
    - You want to test on specific files
    """
    # Create model
    model = SimpleAudioClassifier(n_mels=80, n_classes=10)
    
    # Custom test files
    test_files = list(Path("./data/custom_test").glob("*.wav"))
    test_labels = [0, 1, 0, 1, ...]  # Your labels
    
    # Test on custom files
    tester = quick_test(
        model=model,
        file_paths=test_files,
        labels=test_labels,
        checkpoint_path="./checkpoints/best_model.pt",
        use_test_split=False,  # Use provided files
    )
    
    return tester


# ========== CASE 6: Making Predictions ==========

def case6_make_predictions():
    """
    Making predictions on test data.
    
    Use when:
    - You need individual predictions
    - You want to analyze predictions
    - You need probabilities for each class
    """
    # Create model
    model = SimpleAudioClassifier(n_mels=80, n_classes=10)
    
    # Setup test
    test_loader, dataset, testing_config = setup_test(
        split_path="./data/split.json",
        use_test_split=True,
    )
    
    # Create tester
    tester = BaseTester(
        model=model,
        config=testing_config,
        test_loader=test_loader,
        checkpoint_path="./checkpoints/best_model.pt",
    )
    
    # Get a batch
    features, labels = next(iter(test_loader))
    
    # Get predictions
    predictions = tester.predict(features)
    
    # Get predicted classes
    _, predicted_classes = torch.max(predictions, 1)
    
    # Get probabilities
    probabilities = torch.softmax(predictions, dim=1)
    
    print(f"Predicted classes: {predicted_classes[:5]}")
    print(f"True labels: {labels[:5]}")
    print(f"Probabilities shape: {probabilities.shape}")
    
    # Get all predictions
    all_predictions = tester.predict_batch(test_loader)
    print(f"Total batches: {len(all_predictions)}")
    
    return tester


# ========== CASE 7: Testing Multiple Checkpoints ==========

def case7_test_multiple_checkpoints():
    """
    Testing multiple checkpoints to find best model.
    
    Use when:
    - You want to compare different epochs
    - You want to find the best checkpoint
    - You're doing model selection
    """
    # Create model
    model = SimpleAudioClassifier(n_mels=80, n_classes=10)
    
    # Setup test
    test_loader, dataset, testing_config = setup_test(
        split_path="./data/split.json",
        use_test_split=True,
    )
    
    # Test multiple checkpoints
    checkpoint_dir = Path("./checkpoints")
    results = {}
    
    for checkpoint_path in checkpoint_dir.glob("checkpoint_epoch_*.pt"):
        tester = BaseTester(
            model=model,
            config=testing_config,
            test_loader=test_loader,
            checkpoint_path=checkpoint_path,
        )
        
        metrics = tester.test()
        epoch = checkpoint_path.stem.split("_")[-1]
        results[epoch] = metrics['test_accuracy']
    
    # Find best checkpoint
    best_epoch = max(results, key=results.get)
    print(f"\nBest checkpoint: epoch {best_epoch}")
    print(f"Best accuracy: {results[best_epoch]:.2f}%")
    
    return results


# ========== CASE 8: Testing from Config File ==========

def case8_test_from_config():
    """
    Testing from YAML configuration file.
    
    Use when:
    - You store configuration in YAML files
    - You want to reproduce exact testing setup
    - You work with registered models
    """
    from mimir_io.models.config import load_config
    from mimir_io.models.tester import BaseTester
    
    # Load configuration
    config = load_config("configs/test_config.yaml")
    
    # Create model (from config or manually)
    model = SimpleAudioClassifier(
        n_mels=config["data"]["n_mels"],
        n_classes=config["model"]["n_classes"],
    )
    
    # Setup test
    test_loader, dataset, testing_config = setup_test(
        split_path=config["data"]["split_path"],
        config=config,
        use_test_split=True,
    )
    
    # Create tester from config
    tester = BaseTester.from_config(
        config_path="configs/test_config.yaml",
        model=model,
        test_loader=test_loader,
        checkpoint_path=config["testing"]["checkpoint_path"],
    )
    
    # Run test
    metrics = tester.test()
    
    return tester


# ========== Summary ==========

"""
MAIN USE CASES FOR BaseTester:

1. Quick testing - simplest way (minimal code)
2. Testing with custom configuration - ensure same config as training
3. Flexible testing setup - more control over process
4. Testing with callbacks - save confusion matrix, visualizations
5. Testing on custom files - test on new data
6. Making predictions - get individual predictions and probabilities
7. Testing multiple checkpoints - compare different epochs
8. Testing from config file - YAML-based testing

CHOOSING A USE CASE DEPENDS ON:
- Need for control
- Need for detailed metrics
- Type of test data
- Reproducibility requirements
"""


if __name__ == "__main__":
    # Usage examples (uncomment the one you need):
    
    # Case 1: Quick test
    # case1_quick_test()
    
    # Case 2: Test with config
    # case2_test_with_config()
    
    # Case 3: Flexible test
    # case3_flexible_test()
    
    # Case 4: Test with callbacks
    # case4_test_with_callbacks()
    
    # Case 5: Test custom files
    # case5_test_custom_files()
    
    # Case 6: Make predictions
    # case6_make_predictions()
    
    # Case 7: Test multiple checkpoints
    # case7_test_multiple_checkpoints()
    
    # Case 8: Test from config
    # case8_test_from_config()
    
    print("Testing examples for BaseTester:")
    print("1. Quick testing - simplest way")
    print("2. Testing with custom configuration")
    print("3. Flexible testing setup")
    print("4. Testing with callbacks")
    print("5. Testing on custom files")
    print("6. Making predictions")
    print("7. Testing multiple checkpoints")
    print("8. Testing from config file")

