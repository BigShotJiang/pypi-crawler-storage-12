"""
Examples of using gradient clipping and mixed precision training.

Demonstrates how to use new features to improve training stability and speed.
"""

import torch.nn as nn
from pathlib import Path

from mimir_io.experiment import quick_train, ExperimentConfig, setup_experiment, BaseTrainer


# ========== Example 1: Gradient Clipping ==========

def example1_gradient_clipping():
    """
    Example of using gradient clipping for training stability.
    
    Gradient clipping helps prevent "exploding gradients" problem
    and improves training stability for deep models.
    """
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 256),
        nn.ReLU(),
        nn.Linear(256, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]  # Your labels
    
    # Configuration with gradient clipping
    config = ExperimentConfig(
        batch_size=32,
        epochs=20,
        learning_rate=0.001,
        gradient_clipping={
            "enabled": True,
            "max_norm": 1.0,  # Maximum gradient norm
            "norm_type": 2.0,  # L2 norm (default)
        },
    )
    
    # Training with gradient clipping
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        config=config,
    )
    
    return trainer


# ========== Example 2: Mixed Precision Training (AMP) ==========

def example2_mixed_precision():
    """
    Example of using mixed precision training to accelerate training.
    
    Mixed precision training uses FP16 for computations, which allows:
    - 1.5-2x faster training on GPU
    - Reduced GPU memory usage
    - Preserved accuracy thanks to automatic scaling
    """
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 256),
        nn.ReLU(),
        nn.Linear(256, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Configuration with mixed precision
    config = ExperimentConfig(
        batch_size=64,  # Can increase batch size thanks to memory savings
        epochs=20,
        learning_rate=0.001,
        mixed_precision={
            "enabled": True,
            "init_scale": 2.0**16,  # Initial scale (default)
            "growth_factor": 2.0,  # Scale growth factor
            "backoff_factor": 0.5,  # Scale backoff factor
            "growth_interval": 2000,  # Growth interval
        },
    )
    
    # Training with mixed precision
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        config=config,
    )
    
    return trainer


# ========== Example 3: Combined Gradient Clipping + AMP ==========

def example3_combined():
    """
    Example of combining gradient clipping and mixed precision training.
    
    This is an optimal configuration for:
    - Deep models (gradient clipping for stability)
    - Fast training on GPU (AMP for acceleration)
    """
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 512),
        nn.ReLU(),
        nn.Dropout(0.2),
        nn.Linear(512, 256),
        nn.ReLU(),
        nn.Dropout(0.2),
        nn.Linear(256, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Configuration with both features
    config = ExperimentConfig(
        batch_size=64,
        epochs=30,
        learning_rate=0.001,
        gradient_clipping={
            "enabled": True,
            "max_norm": 1.0,
            "norm_type": 2.0,
        },
        mixed_precision={
            "enabled": True,
        },
        scheduler={
            "enabled": True,
            "type": "ReduceLROnPlateau",
            "monitor": "val_loss",
            "factor": 0.5,
            "patience": 5,
        },
    )
    
    # Training with all optimizations
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        config=config,
    )
    
    return trainer


# ========== Example 4: Using with YAML Config ==========

def example4_yaml_config():
    """
    Example of using via YAML configuration.
    
    Create configs/advanced_training.yaml file:
    
    ```yaml
    training:
      epochs: 30
      batch_size: 64
      optimizer:
        type: Adam
        lr: 0.001
      criterion:
        type: CrossEntropyLoss
      gradient_clipping:
        enabled: true
        max_norm: 1.0
        norm_type: 2.0
      mixed_precision:
        enabled: true
        init_scale: 65536.0
        growth_factor: 2.0
        backoff_factor: 0.5
        growth_interval: 2000
      scheduler:
        enabled: true
        type: ReduceLROnPlateau
        monitor: val_loss
        factor: 0.5
        patience: 5
      early_stopping:
        enabled: true
        monitor: val_loss
        patience: 10
        min_delta: 0.001
    ```
    """
    from mimir_io.models import load_config
    
    # Завантаження конфігурації
    config = load_config("configs/advanced_training.yaml")
    
    # Створюємо модель
    model = nn.Sequential(
        nn.Linear(80, 256),
        nn.ReLU(),
        nn.Linear(256, 10),
    )
    
    # Підготовка даних
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Налаштування експерименту
    train_loader, val_loader, test_loader, dataset, training_config = setup_experiment(
        file_paths=files,
        labels=labels,
        config=config,
    )
    
    # Створюємо trainer з конфігурацією
    trainer = BaseTrainer(
        model=model,
        config=training_config,
        train_loader=train_loader,
        val_loader=val_loader,
    )
    
    # Навчання
    trainer.train()
    
    return trainer


# ========== Example 5: Resume Training with AMP ==========

def example5_resume_training():
    """
    Example of resuming training from checkpoint, including scaler state for AMP.
    """
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 256),
        nn.ReLU(),
        nn.Linear(256, 10),
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Configuration with mixed precision
    config = ExperimentConfig(
        batch_size=32,
        epochs=30,
        learning_rate=0.001,
        mixed_precision={
            "enabled": True,
        },
    )
    
    # Setup experiment
    train_loader, val_loader, test_loader, dataset, training_config = setup_experiment(
        file_paths=files,
        labels=labels,
        config=config,
    )
    
    # Create trainer
    trainer = BaseTrainer(
        model=model,
        config=training_config,
        train_loader=train_loader,
        val_loader=val_loader,
    )
    
    # Load checkpoint (including scaler state for AMP)
    checkpoint_path = "./checkpoints/best_model.pt"
    if Path(checkpoint_path).exists():
        trainer.load_checkpoint(checkpoint_path, resume_training=True)
    
    # Continue training
    trainer.train()
    
    return trainer


# ========== Comparison: Without vs With Optimizations ==========

def comparison_example():
    """
    Comparison of training without and with optimizations.
    
    Gradient clipping:
    - Prevents exploding gradients problem
    - Improves training stability
    - Especially useful for RNN/LSTM and deep networks
    
    Mixed Precision Training:
    - Accelerates training by 1.5-2x on GPU
    - Reduces GPU memory usage
    - Allows increasing batch size
    - Automatically manages scaling to preserve accuracy
    """
    pass


if __name__ == "__main__":
    # Choose an example to run:
    
    # 1. Gradient clipping
    # example1_gradient_clipping()
    
    # 2. Mixed precision training
    # example2_mixed_precision()
    
    # 3. Combined both
    # example3_combined()
    
    # 4. With YAML configuration
    # example4_yaml_config()
    
    # 5. Resume training
    # example5_resume_training()
    
    pass

