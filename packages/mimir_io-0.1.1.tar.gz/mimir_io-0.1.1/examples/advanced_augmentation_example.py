"""
Приклади використання розширених стратегій аугментації.

Демонструє:
- SpecAugment для спектрограм
- Mixup для батчів
- CutMix для батчів
- RandAugment
- Adaptive augmentation
"""

from pathlib import Path
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from mimir_io import Dataset
from mimir_io.audio import (
    resample,
    log_mel_spectrogram,
    spec_augment,
    mixup_batch,
    cutmix_batch,
    rand_augment,
    AdaptiveAugmentation,
)
from mimir_io.rayframe.image import spec_augment_frame
from mimir_io.torch_dataset import create_dataloader


# ========== 1. SpecAugment для спектрограм ==========

def spec_augment_example():
    """Приклад використання SpecAugment."""
    print("=" * 60)
    print("1. SpecAugment Example")
    print("=" * 60)
    
    dataset = Dataset(data_dir="./data")
    
    # Створюємо pipeline з SpecAugment
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
        | spec_augment(
            time_mask_param=27,  # Максимум 27 часових фреймів
            num_time_masks=2,    # 2 часові маски
            freq_mask_param=12,  # Максимум 12 частотних бінів
            num_freq_masks=2,    # 2 частотні маски
        )
    )
    
    # Застосовуємо до аудіо файлу
    audio_path = "./data/raw/audio.wav"
    if Path(audio_path).exists():
        augmented_spec = dataset.apply(mel_pipeline, audio_path)
        print(f"Augmented spectrogram shape: {augmented_spec.shape}")
        print("✓ SpecAugment applied successfully!")
    else:
        print("⚠ Audio file not found, skipping...")


# ========== 2. SpecAugment для ImageRayFrame ==========

def spec_augment_frame_example():
    """Приклад використання SpecAugment для ImageRayFrame."""
    print("\n" + "=" * 60)
    print("2. SpecAugment для ImageRayFrame Example")
    print("=" * 60)
    
    dataset = Dataset(data_dir="./data")
    
    # Завантажуємо аудіо як AudioRayFrame
    audio_path = "./data/raw/audio.wav"
    if Path(audio_path).exists():
        audio_frame = dataset.load_audio(audio_path)
        
        # Створюємо mel spectrogram
        from mimir_io.audio import mel_spectrogram
        from mimir_io.rayframe.image import mel_to_frame
        
        mel_pipeline = (
            resample(16000, orig_sample_rate=audio_frame.sample_rate)
            | mel_spectrogram(sample_rate=16000, n_mels=80)
            | mel_to_frame(sample_rate=16000)
        )
        
        mel_frame = dataset.apply(mel_pipeline, audio_frame.data)
        
        # Застосовуємо SpecAugment
        aug_lens = spec_augment_frame(
            time_mask_param=27,
            num_time_masks=2,
            freq_mask_param=12,
            num_freq_masks=2,
        )
        
        augmented_frame = aug_lens(mel_frame)
        print(f"Original frame shape: {mel_frame.data.shape}")
        print(f"Augmented frame shape: {augmented_frame.data.shape}")
        print("✓ SpecAugment для ImageRayFrame applied successfully!")
    else:
        print("⚠ Audio file not found, skipping...")


# ========== 3. Mixup для батчів ==========

def mixup_example():
    """Приклад використання Mixup під час тренування."""
    print("\n" + "=" * 60)
    print("3. Mixup Example")
    print("=" * 60)
    
    # Створюємо фейкові дані для демонстрації
    batch_size = 8
    n_mels = 80
    time_frames = 100
    
    # Фейкові батчі
    batch_x = torch.randn(batch_size, n_mels, time_frames)
    batch_y = torch.randint(0, 10, (batch_size,))  # 10 класів
    
    # Застосовуємо Mixup
    mixup_fn = mixup_batch(alpha=0.2)
    x_mixed, y_mixed, lam = mixup_fn(batch_x, batch_y)
    
    print(f"Original batch shape: {batch_x.shape}")
    print(f"Mixed batch shape: {x_mixed.shape}")
    print(f"Lambda values: {lam[:3].tolist()}...")  # Показуємо перші 3
    print(f"Original labels: {batch_y[:3].tolist()}")
    print(f"Mixed labels: {y_mixed[:3].tolist()}")
    print("✓ Mixup applied successfully!")
    
    # Приклад використання в training loop
    print("\nПриклад використання в training loop:")
    print("""
    mixup_fn = mixup_batch(alpha=0.2)
    
    for batch_x, batch_y in train_loader:
        # Застосовуємо Mixup з ймовірністю 0.5
        if torch.rand(1).item() < 0.5:
            batch_x, batch_y, lam = mixup_fn(batch_x, batch_y)
        
        # Forward pass
        outputs = model(batch_x)
        loss = criterion(outputs, batch_y)
        ...
    """)


# ========== 4. CutMix для батчів ==========

def cutmix_example():
    """Приклад використання CutMix під час тренування."""
    print("\n" + "=" * 60)
    print("4. CutMix Example")
    print("=" * 60)
    
    # Створюємо фейкові дані для демонстрації
    batch_size = 8
    n_mels = 80
    time_frames = 100
    
    batch_x = torch.randn(batch_size, n_mels, time_frames)
    batch_y = torch.randint(0, 10, (batch_size,))
    
    # Застосовуємо CutMix
    cutmix_fn = cutmix_batch(alpha=1.0)
    x_mixed, y_mixed, lam = cutmix_fn(batch_x, batch_y)
    
    print(f"Original batch shape: {batch_x.shape}")
    print(f"CutMix batch shape: {x_mixed.shape}")
    print(f"Lambda values: {lam[:3].tolist()}...")
    print("✓ CutMix applied successfully!")
    
    print("\nПриклад використання в training loop:")
    print("""
    cutmix_fn = cutmix_batch(alpha=1.0)
    
    for batch_x, batch_y in train_loader:
        # Застосовуємо CutMix з ймовірністю 0.5
        if torch.rand(1).item() < 0.5:
            batch_x, batch_y, lam = cutmix_fn(batch_x, batch_y)
        
        outputs = model(batch_x)
        loss = criterion(outputs, batch_y)
        ...
    """)


# ========== 5. RandAugment ==========

def rand_augment_example():
    """Приклад використання RandAugment."""
    print("\n" + "=" * 60)
    print("5. RandAugment Example")
    print("=" * 60)
    
    dataset = Dataset(data_dir="./data")
    
    # Створюємо pipeline з RandAugment
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
        | rand_augment(
            num_ops=2,      # 2 операції
            magnitude=9,    # Магнітуда 9 з 10
        )
    )
    
    audio_path = "./data/raw/audio.wav"
    if Path(audio_path).exists():
        augmented_spec = dataset.apply(mel_pipeline, audio_path)
        print(f"Augmented spectrogram shape: {augmented_spec.shape}")
        print("✓ RandAugment applied successfully!")
    else:
        print("⚠ Audio file not found, skipping...")


# ========== 6. Adaptive Augmentation ==========

def adaptive_augmentation_example():
    """Приклад використання Adaptive Augmentation."""
    print("\n" + "=" * 60)
    print("6. Adaptive Augmentation Example")
    print("=" * 60)
    
    # Створюємо адаптивну аугментацію
    adaptive_aug = AdaptiveAugmentation(
        initial_magnitude=0.5,
        min_magnitude=0.0,
        max_magnitude=1.0,
        adaptation_rate=0.1,
    )
    
    print(f"Initial magnitude: {adaptive_aug.get_magnitude():.2f}")
    
    # Симулюємо тренування з різними метриками
    # Epoch 1: Overfitting (великий gap)
    adaptive_aug.update(train_loss=0.5, val_loss=0.8)
    print(f"After epoch 1 (overfitting): {adaptive_aug.get_magnitude():.2f}")
    
    # Epoch 2: Продовжується overfitting
    adaptive_aug.update(train_loss=0.4, val_loss=0.75)
    print(f"After epoch 2 (overfitting): {adaptive_aug.get_magnitude():.2f}")
    
    # Epoch 3: Underfitting (малий gap)
    adaptive_aug.update(train_loss=0.7, val_loss=0.65)
    print(f"After epoch 3 (underfitting): {adaptive_aug.get_magnitude():.2f}")
    
    print("✓ Adaptive augmentation working!")
    
    print("\nПриклад використання в training loop:")
    print("""
    adaptive_aug = AdaptiveAugmentation(initial_magnitude=0.5)
    
    for epoch in range(num_epochs):
        train_loss = train_one_epoch(...)
        val_loss, val_acc = validate(...)
        
        # Оновлюємо магнітуду аугментації
        adaptive_aug.update(train_loss, val_loss, val_acc)
        
        # Використовуємо поточну магнітуду для аугментації
        magnitude = adaptive_aug.get_magnitude()
        aug_lens = rand_augment(magnitude=int(magnitude * 10))
        ...
    """)


# ========== 7. Комбінований приклад з DataLoader ==========

def combined_example():
    """Комбінований приклад з використанням у DataLoader."""
    print("\n" + "=" * 60)
    print("7. Combined Example з DataLoader")
    print("=" * 60)
    
    print("""
    # Створюємо pipeline з SpecAugment
    mel_pipeline = (
        resample(16000)
        | log_mel_spectrogram(n_mels=80)
    )
    
    # Аугментація для тренування
    train_aug = spec_augment(
        time_mask_param=27,
        num_time_masks=2,
        freq_mask_param=12,
        num_freq_masks=2,
    )
    
    # Створюємо DataLoader
    train_loader = create_dataloader(
        mimir_dataset=dataset,
        file_paths=train_files,
        transform_pipeline=mel_pipeline,
        labels=train_labels,
        batch_size=32,
        use_augmentation=True,
        augmentation_pipeline=train_aug,
    )
    
    # У training loop можна додати Mixup/CutMix
    mixup_fn = mixup_batch(alpha=0.2)
    
    for batch_x, batch_y in train_loader:
        # Застосовуємо Mixup з ймовірністю
        if torch.rand(1).item() < 0.5:
            batch_x, batch_y, lam = mixup_fn(batch_x, batch_y)
        
        outputs = model(batch_x)
        loss = criterion(outputs, batch_y)
        ...
    """)


if __name__ == "__main__":
    print("Advanced Augmentation Examples")
    print("=" * 60)
    
    # Запускаємо приклади
    spec_augment_example()
    spec_augment_frame_example()
    mixup_example()
    cutmix_example()
    rand_augment_example()
    adaptive_augmentation_example()
    combined_example()
    
    print("\n" + "=" * 60)
    print("All examples completed!")
    print("=" * 60)

