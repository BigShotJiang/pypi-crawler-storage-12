"""
Examples of using callbacks and early stopping.

Demonstrates:
- Early stopping
- ImageMetricsCallback for saving metrics as images
- Custom callbacks
"""

import torch
import torch.nn as nn
from pathlib import Path

from mimir_io import Dataset, split_dataset
from mimir_io.audio import resample, log_mel_spectrogram
from mimir_io.rayframe.audio import augment_audio_frame
from mimir_io.torch_dataset import create_dataloader
from mimir_io.models import BaseTrainer, EarlyStoppingCallback, ImageMetricsCallback, CSVLoggerCallback, Callback
from mimir_io.experiment import quick_train, ExperimentConfig


# ========== Example 1: Early Stopping via configuration ==========

def example1_early_stopping_config():
    """Early stopping via ExperimentConfig."""
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Configuration with early stopping
    config = ExperimentConfig(
        epochs=100,  # Maximum number of epochs
        early_stopping={
            "enabled": True,
            "monitor": "val_loss",  # Monitor validation loss
            "patience": 5,  # Stop after 5 epochs without improvement
            "min_delta": 0.001,  # Minimum change to consider as improvement
            "mode": "min",  # Minimize metric
            "restore_best_weights": True,  # Restore best weights
        },
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]  # Your labels
    
    # Start training
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        config=config,
    )
    
    return trainer


# ========== Example 2: Early Stopping via callback ==========

def example2_early_stopping_callback():
    """Early stopping via callback."""
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create early stopping callback
    early_stopping = EarlyStoppingCallback(
        monitor="val_loss",
        patience=5,
        min_delta=0.001,
        mode="min",
        restore_best_weights=True,
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Start training with callback
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        callbacks=[early_stopping],
    )
    
    return trainer


# ========== Example 3: ImageMetricsCallback ==========

def example3_image_metrics():
    """Using ImageMetricsCallback for saving metrics."""
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create callback for image metrics
    image_metrics = ImageMetricsCallback(
        save_dir="./metrics_images",
        save_loss_plot=True,
        save_confusion_matrix=True,
        save_sample_predictions=True,
        num_samples=8,
        save_every_n_epochs=1,  # Save every epoch
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Start training
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        callbacks=[image_metrics],
    )
    
    return trainer


# ========== Example 4: Combined callbacks ==========

def example4_combined_callbacks():
    """Combination of early stopping and image metrics."""
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create callbacks
    early_stopping = EarlyStoppingCallback(
        monitor="val_loss",
        patience=5,
        min_delta=0.001,
    )
    
    image_metrics = ImageMetricsCallback(
        save_dir="./metrics_images",
        save_every_n_epochs=2,  # Save every 2 epochs
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Start training with both callbacks
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        callbacks=[early_stopping, image_metrics],
    )
    
    return trainer


# ========== Example 5: Custom callback ==========

class CustomMetricsCallback(Callback):
    """Custom callback for additional metrics."""
    
    def __init__(self):
        self.epoch_metrics = []
    
    def on_train_begin(self, trainer):
        """Initialize at the beginning of training."""
        self.epoch_metrics.clear()
        print("Custom callback: Training started")
    
    def on_epoch_end(self, trainer, epoch, metrics):
        """Save metrics after epoch."""
        self.epoch_metrics.append({
            "epoch": epoch,
            **metrics
        })
        
        # Example: print additional information
        if "val_accuracy" in metrics:
            print(f"  Custom: Val Accuracy improved by {metrics['val_accuracy']:.2f}%")
    
    def on_train_end(self, trainer):
        """Actions at the end of training."""
        print(f"Custom callback: Training finished. Total epochs: {len(self.epoch_metrics)}")


def example5_custom_callback():
    """Using custom callback."""
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create custom callback
    custom_callback = CustomMetricsCallback()
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Start training
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        callbacks=[custom_callback],
    )
    
    return trainer


# ========== Example 6: Early stopping for accuracy ==========

def example6_early_stopping_accuracy():
    """Early stopping for maximizing accuracy."""
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Early stopping for maximizing accuracy
    early_stopping = EarlyStoppingCallback(
        monitor="val_accuracy",  # Monitor accuracy
        patience=7,
        min_delta=0.1,  # Minimum improvement 0.1%
        mode="max",  # Maximize metric
        restore_best_weights=True,
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Start training
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        callbacks=[early_stopping],
    )
    
    return trainer


# ========== Example 7: CSV Logger ==========

def example7_csv_logger():
    """Using CSVLoggerCallback for logging metrics."""
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create CSV logger callback
    csv_logger = CSVLoggerCallback(
        log_dir="./logs",
        filename="training_metrics",  # Will create training_metrics.csv and training_metrics.json
        format="both",  # Save both CSV and JSON
        include_timestamp=True,
        extra_metadata={
            "model_name": "SimpleAudioClassifier",
            "dataset": "audio_dataset_v1",
        },
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Start training
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        callbacks=[csv_logger],
    )
    
    # After training, you can access the best metric
    best_val_loss = csv_logger.get_best_metric("val_loss", mode="min")
    if best_val_loss:
        print(f"\nBest validation loss: {best_val_loss['val_loss']:.4f} at epoch {best_val_loss['epoch']}")
    
    return trainer


# ========== Example 8: CSV Logger with JSON only ==========

def example8_csv_logger_json_only():
    """Using CSVLoggerCallback with JSON format only."""
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create JSON logger (no CSV)
    json_logger = CSVLoggerCallback(
        log_dir="./logs",
        filename="experiment_results",
        format="json",  # Only JSON format
        include_timestamp=True,
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Start training
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        callbacks=[json_logger],
    )
    
    return trainer


# ========== Example 9: Combined CSV Logger with Early Stopping ==========

def example9_csv_logger_with_early_stopping():
    """Combining CSV logger with early stopping."""
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create callbacks
    csv_logger = CSVLoggerCallback(
        log_dir="./logs",
        filename="experiment_with_early_stopping",
        format="both",
    )
    
    early_stopping = EarlyStoppingCallback(
        monitor="val_loss",
        patience=5,
        min_delta=0.001,
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Start training
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        callbacks=[csv_logger, early_stopping],
    )
    
    # Check best metrics from CSV logger
    best_val_loss = csv_logger.get_best_metric("val_loss", mode="min")
    best_val_acc = csv_logger.get_best_metric("val_accuracy", mode="max")
    
    print("\n=== Training Summary ===")
    if best_val_loss:
        print(f"Best Val Loss: {best_val_loss['val_loss']:.4f} at epoch {best_val_loss['epoch']}")
    if best_val_acc:
        print(f"Best Val Accuracy: {best_val_acc['val_accuracy']:.2f}% at epoch {best_val_acc['epoch']}")
    
    return trainer


if __name__ == "__main__":
    print("Examples of using callbacks and early stopping:")
    print("1. Early stopping via configuration")
    print("2. Early stopping via callback")
    print("3. ImageMetricsCallback")
    print("4. Combined callbacks")
    print("5. Custom callback")
    print("6. Early stopping for accuracy")
    print("7. CSV Logger")
    print("8. CSV Logger (JSON only)")
    print("9. CSV Logger with Early Stopping")
    print("\nRun the desired function to test.")
