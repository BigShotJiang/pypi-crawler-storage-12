"""
Example of pipeline visualization usage.

Demonstrates how to visualize the structure of composed transformation pipelines.
"""

from mimir_io.audio import resample, log_mel_spectrogram, normalize, trim_silence
from mimir_io.audio.augment import spec_augment
from mimir_io.visualization import visualize_pipeline


def main():
    """Demonstration of pipeline visualization."""
    
    print("Creating simple pipeline...")
    simple_pipeline = (
        resample(16000, orig_sample_rate=44100).no_cache()
        | log_mel_spectrogram(sample_rate=16000, n_mels=80).cache()
    )
    
    print("Visualizing simple pipeline...")
    visualize_pipeline(
        pipeline=simple_pipeline,
        output_file="simple_pipeline.png",
        format="png",
    )
    
    print("\n" + "=" * 60)
    print("Creating complex pipeline...")
    complex_pipeline = (
        resample(16000, orig_sample_rate=44100).no_cache()
        | normalize(target_db=-20.0).no_cache()
        | trim_silence(threshold=0.01).no_cache()
        | log_mel_spectrogram(sample_rate=16000, n_mels=80).cache()
        | spec_augment(time_mask_param=27, num_time_masks=2)
    )
    
    print("Visualizing complex pipeline...")
    visualize_pipeline(
        pipeline=complex_pipeline,
        output_file="complex_pipeline.png",
        format="png",
        style="graphviz",  # or "matplotlib"
    )
    
    print("\nVisualizations saved to files:")
    print("  - simple_pipeline.png")
    print("  - complex_pipeline.png")


if __name__ == "__main__":
    main()

