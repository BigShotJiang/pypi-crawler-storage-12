"""
Examples for working with datasets organized by class directories.

Demonstrates how to work with datasets structured as:
    data_dir/
        class1/
            file1.wav
            file2.wav
        class2/
            file3.wav
        classn/
            file4.wav
"""

from pathlib import Path
from mimir_io import (
    load_from_class_directories,
    split_by_class_directories,
    split_dataset,
    Dataset,
)
from mimir_io.experiment import quick_train, ExperimentConfig
from mimir_io.torch_dataset import create_dataloader
from mimir_io.audio import resample, log_mel_spectrogram
import torch.nn as nn


# ========== CASE 1: Load and Split Class Directories ==========

def case1_load_and_split():
    """
    Simplest way - load from class directories and split automatically.
    
    Use when:
    - Your data is organized by classes
    - You want automatic train/val/test split
    - You want stratified splitting (maintains class distribution)
    """
    # Data structure:
    # data/
    #   cat/
    #     cat1.wav, cat2.wav, ...
    #   dog/
    #     dog1.wav, dog2.wav, ...
    #   bird/
    #     bird1.wav, bird2.wav, ...
    
    split = split_by_class_directories(
        data_dir="./data",
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15,
        extensions=[".wav", ".mp3"],  # Only audio files
        stratify=True,  # Maintain class distribution
        seed=42,
    )
    
    print(f"Train: {len(split.train_files)} files")
    print(f"Val: {len(split.val_files)} files")
    print(f"Test: {len(split.test_files)} files")
    print(f"Classes: {split.metadata['class_to_label']}")
    print(f"Number of classes: {split.metadata['num_classes']}")
    
    # Save split for later use
    split.save("./data/split.json")
    
    return split


# ========== CASE 2: Load Only (Manual Split) ==========

def case2_load_only():
    """
    Load files and labels, then split manually.
    
    Use when:
    - You want more control over splitting
    - You need custom split ratios
    - You want to inspect data before splitting
    """
    # Load files and labels from class directories
    file_paths, labels, class_map = load_from_class_directories(
        data_dir="./data",
        extensions=[".wav", ".mp3"],
    )
    
    print(f"Total files: {len(file_paths)}")
    print(f"Classes: {class_map}")
    print(f"Number of classes: {len(class_map)}")
    
    # Inspect class distribution
    from collections import Counter
    label_counts = Counter(labels)
    print(f"Class distribution: {label_counts}")
    
    # Now split manually with custom logic
    split = split_dataset(
        file_paths=file_paths,
        labels=labels,
        train_ratio=0.8,  # Larger training set
        val_ratio=0.1,
        test_ratio=0.1,
        stratify=True,
        seed=42,
    )
    
    return split


# ========== CASE 3: Custom Class Mapping ==========

def case3_custom_class_mapping():
    """
    Use custom class to label mapping.
    
    Use when:
    - You want specific label numbers for classes
    - You want to exclude some classes
    - You have a predefined label scheme
    """
    # Define custom mapping
    class_to_label = {
        "cat": 0,
        "dog": 1,
        "bird": 2,
        # Exclude other directories
    }
    
    split = split_by_class_directories(
        data_dir="./data",
        class_to_label=class_to_label,
        auto_label=False,  # Use provided mapping
        stratify=True,
        seed=42,
    )
    
    return split


# ========== CASE 4: Quick Training with Class Directories ==========

def case4_quick_train():
    """
    Quick training directly from class directories.
    
    Use when:
    - You want to train immediately
    - You don't need to save split separately
    - You want minimal code
    """
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 3),  # 3 classes: cat, dog, bird
    )
    
    # Load and split from class directories
    split = split_by_class_directories(
        data_dir="./data",
        extensions=[".wav", ".mp3"],
        stratify=True,
        seed=42,
    )
    
    # Get all files and labels
    all_files = split.train_files + split.val_files + (split.test_files or [])
    all_labels = split.train_labels + split.val_labels + (split.test_labels or [])
    
    # Train
    trainer = quick_train(
        model=model,
        file_paths=all_files,
        labels=all_labels,
        split_path="./data/split.json",  # Save split
    )
    
    return trainer


# ========== CASE 5: Using with Experiment Config ==========

def case5_with_experiment_config():
    """
    Using class directories with ExperimentConfig.
    
    Use when:
    - You want custom training parameters
    - You need augmentation configuration
    - You want early stopping
    """
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 256),
        nn.ReLU(),
        nn.Linear(256, 128),
        nn.ReLU(),
        nn.Linear(128, 3),  # 3 classes
    )
    
    # Load and split
    split = split_by_class_directories(
        data_dir="./data",
        extensions=[".wav", ".mp3"],
        stratify=True,
        seed=42,
    )
    
    # Configure experiment
    config = ExperimentConfig(
        batch_size=64,
        epochs=20,
        learning_rate=0.0001,
        n_mels=128,
        use_augmentation=True,
        augmentation_config={
            "time_shift_max": 2000,
            "gain_range": (0.8, 1.2),
        },
        early_stopping={
            "enabled": True,
            "monitor": "val_loss",
            "patience": 5,
        },
    )
    
    # Get all files and labels
    all_files = split.train_files + split.val_files + (split.test_files or [])
    all_labels = split.train_labels + split.val_labels + (split.test_labels or [])
    
    # Train
    trainer = quick_train(
        model=model,
        file_paths=all_files,
        labels=all_labels,
        config=config,
        split_path="./data/split.json",
    )
    
    return trainer


# ========== CASE 6: Manual DataLoader Creation ==========

def case6_manual_dataloader():
    """
    Create DataLoaders manually from class directories.
    
    Use when:
    - You need full control over DataLoader creation
    - You want custom preprocessing
    - You're not using quick_train
    """
    # Load and split
    split = split_by_class_directories(
        data_dir="./data",
        extensions=[".wav", ".mp3"],
        stratify=True,
        seed=42,
    )
    
    # Create dataset
    dataset = Dataset(data_dir="./data")
    
    # Create transform pipeline
    mel_pipeline = (
        resample(16000).no_cache()
        | log_mel_spectrogram(sample_rate=16000, n_mels=80).cache()
    )
    
    # Create DataLoaders
    train_loader = create_dataloader(
        mimir_dataset=dataset,
        file_paths=split.train_files,
        transform_pipeline=mel_pipeline,
        labels=split.train_labels,
        batch_size=32,
        shuffle=True,
        use_augmentation=True,
    )
    
    val_loader = create_dataloader(
        mimir_dataset=dataset,
        file_paths=split.val_files,
        transform_pipeline=mel_pipeline,
        labels=split.val_labels,
        batch_size=32,
        shuffle=False,
        use_augmentation=False,
    )
    
    return train_loader, val_loader


# ========== Summary ==========

"""
WORKING WITH CLASS DIRECTORIES:

1. split_by_class_directories - Simplest way (load + split)
2. load_from_class_directories - Load only, then split manually
3. Custom class mapping - Use predefined label scheme
4. Quick training - Train directly from class directories
5. With ExperimentConfig - Custom training parameters
6. Manual DataLoader - Full control over data loading

BEST PRACTICES:
- Always use stratify=True to maintain class distribution
- Save splits for reproducibility
- Use extensions parameter to filter file types
- Check class distribution before training
"""


if __name__ == "__main__":
    # Usage examples (uncomment the one you need):
    
    # Case 1: Load and split
    # case1_load_and_split()
    
    # Case 2: Load only
    # case2_load_only()
    
    # Case 3: Custom mapping
    # case3_custom_class_mapping()
    
    # Case 4: Quick train
    # case4_quick_train()
    
    # Case 5: With config
    # case5_with_experiment_config()
    
    # Case 6: Manual DataLoader
    # case6_manual_dataloader()
    
    print("Examples for working with class directories:")
    print("1. Load and split automatically")
    print("2. Load only, then split manually")
    print("3. Use custom class mapping")
    print("4. Quick training from class directories")
    print("5. Training with ExperimentConfig")
    print("6. Manual DataLoader creation")

