"""
Example of using mimir_io model management system with YAML configs.

Demonstrates:
- Registering regular PyTorch models (no base class required!)
- Using type hints for configuration
- Loading models from YAML configs
- Training models with mimir_io data pipelines
"""

import torch
import torch.nn as nn
from pathlib import Path
from typing import TypedDict, Optional

from mimir_io import Dataset, split_dataset
from mimir_io.audio import resample, log_mel_spectrogram
from mimir_io.rayframe.audio import augment_audio_frame
from mimir_io.torch_dataset import create_dataloader
from mimir_io.models import (
    register_model,
    create_model,
    load_config,
    BaseTrainer,
)


# ========== 1. Define Model with Type Hints (Option 1: TypedDict) ==========

class AudioClassifierConfig(TypedDict):
    """Configuration type for AudioClassifier."""
    n_mels: int
    n_classes: int
    hidden_dim: int


@register_model("audio_classifier", config_type=AudioClassifierConfig)
class AudioClassifier(nn.Module):
    """
    Audio classification model.
    
    Regular PyTorch model - no special base class needed!
    """
    
    def __init__(self, config: AudioClassifierConfig):
        super().__init__()
        
        n_mels = config["n_mels"]
        n_classes = config["n_classes"]
        hidden_dim = config["hidden_dim"]
        
        # Convolutional layers
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        
        # Fully connected layers
        self.fc1 = nn.Linear(64, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, n_classes)
        self.dropout = nn.Dropout(0.5)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: (batch, n_mels, time_frames)
        x = x.unsqueeze(1)  # (batch, 1, n_mels, time_frames)
        
        x = torch.relu(self.conv1(x))
        x = torch.relu(self.conv2(x))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        
        x = torch.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)
        
        return x


# ========== 2. Define Model with Direct Parameters (Option 2) ==========

@register_model("simple_classifier")
class SimpleClassifier(nn.Module):
    """
    Simple classifier with direct parameters.
    
    No config dict needed - just use regular parameters!
    """
    
    def __init__(
        self,
        n_mels: int = 80,
        n_classes: int = 10,
        hidden_dim: int = 128,
    ):
        super().__init__()
        
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(64, n_classes)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.unsqueeze(1)
        x = torch.relu(self.conv1(x))
        x = torch.relu(self.conv2(x))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x


# ========== 3. Create YAML Config ==========

def create_example_config():
    """Create example YAML config file."""
    config = {
        "model": {
            "name": "audio_classifier",
            "n_mels": 80,
            "n_classes": 10,
            "hidden_dim": 128,
        },
        "data": {
            "data_dir": "./data",
            "sample_rate": 16000,
            "n_mels": 80,
            "n_fft": 2048,
            "hop_length": 512,
        },
        "training": {
            "epochs": 10,
            "batch_size": 32,
            "save_dir": "./checkpoints",
            "optimizer": {
                "type": "Adam",
                "lr": 0.001,
            },
            "criterion": {
                "type": "CrossEntropyLoss",
            },
        },
        "augmentation": {
            "time_shift_max": 1600,
            "gain_range": [0.7, 1.3],
            "noise_snr": 20.0,
            "speed_range": [0.9, 1.1],
        },
    }
    
    # Save config
    config_path = Path("./configs/example_model.yaml")
    config_path.parent.mkdir(parents=True, exist_ok=True)
    
    from mimir_io.models.config import save_config
    save_config(config, config_path)
    print(f"Created example config at {config_path}")
    
    return config_path


# ========== 4. Load Model from Config ==========

def load_model_from_config(config_path: Path):
    """Load model from YAML config."""
    config = load_config(config_path)
    
    # Get model config
    model_config = config["model"]
    model_name = model_config["name"]
    
    # Create model (works with both config dict and kwargs)
    model = create_model(model_name, model_config)
    
    print(f"Created model: {model_name}")
    print(f"Parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    return model, config


# ========== 5. Prepare Data with Config ==========

def prepare_data_from_config(config):
    """Prepare data loaders from config."""
    data_config = config["data"]
    training_config = config["training"]
    aug_config = config.get("augmentation", {})
    
    # Initialize dataset
    mimir_dataset = Dataset(data_dir=data_config["data_dir"])
    
    # Create processing pipeline
    mel_pipeline = (
        resample(data_config["sample_rate"]).no_cache()
        | log_mel_spectrogram(
            sample_rate=data_config["sample_rate"],
            n_mels=data_config["n_mels"],
            n_fft=data_config["n_fft"],
            hop_length=data_config["hop_length"],
        ).cache()
    )
    
    # Create augmentation pipeline
    aug_pipeline = augment_audio_frame(
        time_shift_max=aug_config.get("time_shift_max", 1600),
        gain_range=tuple(aug_config.get("gain_range", [0.7, 1.3])),
        noise_snr=aug_config.get("noise_snr", 20.0),
        speed_range=tuple(aug_config.get("speed_range", [0.9, 1.1])),
    )
    
    # Get files and labels (example)
    all_files = list(Path(data_config["data_dir"]).glob("raw/**/*.wav"))
    all_labels = [0] * len(all_files)  # Replace with actual labels
    
    # Split dataset
    split = split_dataset(
        file_paths=all_files,
        labels=all_labels,
        seed=42,
    )
    
    # Create data loaders
    train_loader = create_dataloader(
        mimir_dataset=mimir_dataset,
        file_paths=split.train_files,
        transform_pipeline=mel_pipeline,
        labels=split.train_labels,
        batch_size=training_config["batch_size"],
        shuffle=True,
        num_workers=4,
        pin_memory=True,
        persistent_workers=True,
        prefetch_factor=4,
        use_augmentation=True,
        augmentation_pipeline=aug_pipeline,
    )
    
    val_loader = create_dataloader(
        mimir_dataset=mimir_dataset,
        file_paths=split.val_files,
        transform_pipeline=mel_pipeline,
        labels=split.val_labels,
        batch_size=training_config["batch_size"],
        shuffle=False,
        num_workers=4,
        pin_memory=True,
        use_augmentation=False,
    )
    
    return train_loader, val_loader


# ========== 6. Training with Config ==========

def train_from_config(config_path: Path):
    """Complete training workflow from config file."""
    
    # Load config
    config = load_config(config_path)
    
    # Create model
    model, _ = load_model_from_config(config_path)
    
    # Prepare data
    train_loader, val_loader = prepare_data_from_config(config)
    
    # Create trainer (works with any nn.Module!)
    trainer = BaseTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
    )
    
    # Train
    trainer.train()
    
    print("Training completed!")


# ========== 7. Usage Examples ==========

if __name__ == "__main__":
    # Create example config
    config_path = create_example_config()
    
    # List available models
    from mimir_io.models import list_models
    print(f"Available models: {list_models()}")
    
    # Example 1: Create model with config dict (TypedDict)
    model1, config = load_model_from_config(config_path)
    
    # Example 2: Create model with direct kwargs
    model2 = create_model(
        "simple_classifier",
        config={"n_mels": 80, "n_classes": 5, "hidden_dim": 64}
    )
    print(f"Model 2 parameters: {sum(p.numel() for p in model2.parameters()):,}")
    
    # Example 3: Create model directly (no config)
    from mimir_io.models import get_model
    ModelClass = get_model("simple_classifier")
    model3 = ModelClass(n_mels=80, n_classes=10, hidden_dim=128)
    print(f"Model 3 parameters: {sum(p.numel() for p in model3.parameters()):,}")
    
    # Example: Training (uncomment to run)
    # train_from_config(config_path)
