"""
Example of using StreamingDataset for large datasets.

Demonstrates how to use StreamingDataset for datasets that don't fit in memory,
with prefetching for optimal performance.
"""

from pathlib import Path
from mimir_io import Dataset
from mimir_io.streaming import StreamingDataset, create_streaming_dataloader, PrefetchStats
from mimir_io.audio import resample, log_mel_spectrogram
from mimir_io.rayframe.audio.augment import augment_audio_frame
from torch.utils.data import DataLoader


def example_basic_streaming():
    """Basic example of StreamingDataset."""
    
    # Initialize dataset
    dataset = Dataset(data_dir="./data")
    
    # Large list of files (can be millions)
    file_paths = list(Path("./data/raw").glob("*.wav"))  # Example: 100k+ files
    
    # Create transformation pipeline
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
    )
    
    # Create streaming dataset with prefetching
    streaming_dataset = StreamingDataset(
        mimir_dataset=dataset,
        file_paths=file_paths,
        transform_pipeline=mel_pipeline,
        prefetch_size=100,  # Prefetch 100 items ahead
        num_prefetch_workers=4,  # Use 4 threads for prefetching
        enable_prefetch=True,
    )
    
    # Create DataLoader
    loader = DataLoader(
        streaming_dataset,
        batch_size=32,
        shuffle=True,
        num_workers=4,
        pin_memory=True,
    )
    
    # Iterate over batches - data loaded on-the-fly!
    for batch_idx, batch in enumerate(loader):
        features, labels = batch
        print(f"Batch {batch_idx}: shape={features.shape}")
        
        # Check prefetch stats
        if batch_idx % 100 == 0:
            stats = streaming_dataset.get_prefetch_stats()
            print(f"Prefetch stats: {stats.total_loaded} items loaded, "
                  f"avg time: {stats.avg_load_time:.3f}s")


def example_streaming_with_augmentation():
    """StreamingDataset with augmentations."""
    
    dataset = Dataset(data_dir="./data")
    file_paths = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1] * (len(file_paths) // 4)  # Example labels
    
    # Transformation pipeline
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
    )
    
    # Augmentation pipeline
    aug_pipeline = augment_audio_frame(
        time_shift_max=1600,
        gain_range=(0.7, 1.3),
        noise_snr=20.0,
    )
    
    # Create streaming dataset with augmentations
    streaming_dataset = StreamingDataset(
        mimir_dataset=dataset,
        file_paths=file_paths,
        transform_pipeline=mel_pipeline,
        labels=labels,
        use_augmentation=True,
        augmentation_pipeline=aug_pipeline,
        prefetch_size=200,  # Larger prefetch for training
        num_prefetch_workers=4,
    )
    
    loader = DataLoader(
        streaming_dataset,
        batch_size=32,
        shuffle=True,
        num_workers=4,
    )
    
    for epoch in range(3):
        print(f"\nEpoch {epoch}")
        streaming_dataset.set_epoch(epoch)  # Reset prefetching for new epoch
        
        for batch_idx, (features, labels) in enumerate(loader):
            # Training code here
            if batch_idx % 50 == 0:
                print(f"  Batch {batch_idx}")


def example_convenience_function():
    """Using create_streaming_dataloader convenience function."""
    
    dataset = Dataset(data_dir="./data")
    file_paths = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1] * (len(file_paths) // 2)
    
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
    )
    
    # One-liner to create streaming dataloader
    loader = create_streaming_dataloader(
        mimir_dataset=dataset,
        file_paths=file_paths,
        transform_pipeline=mel_pipeline,
        labels=labels,
        batch_size=32,
        shuffle=True,
        num_workers=4,
        pin_memory=True,
        prefetch_size=100,  # Streaming-specific
        num_prefetch_workers=4,  # Streaming-specific
        enable_prefetch=True,  # Streaming-specific
    )
    
    for batch in loader:
        features, labels = batch
        # Process batch
        pass


def example_prefetch_stats():
    """Monitor prefetching performance."""
    
    dataset = Dataset(data_dir="./data")
    file_paths = list(Path("./data/raw").glob("*.wav"))
    
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
    )
    
    streaming_dataset = StreamingDataset(
        mimir_dataset=dataset,
        file_paths=file_paths,
        transform_pipeline=mel_pipeline,
        prefetch_size=50,
        num_prefetch_workers=2,
    )
    
    loader = DataLoader(streaming_dataset, batch_size=32, num_workers=2)
    
    # Monitor prefetch stats during training
    for batch_idx, batch in enumerate(loader):
        if batch_idx % 10 == 0:
            stats = streaming_dataset.get_prefetch_stats()
            print(f"Batch {batch_idx}:")
            print(f"  Total loaded: {stats.total_loaded}")
            print(f"  Queue size: {stats.prefetch_queue_size}")
            print(f"  Avg load time: {stats.avg_load_time:.3f}s")
            print(f"  Cache hits: {stats.cache_hits}")
            print(f"  Cache misses: {stats.cache_misses}")


def example_disable_prefetch():
    """Using StreamingDataset without prefetching (fallback to on-demand loading)."""
    
    dataset = Dataset(data_dir="./data")
    file_paths = list(Path("./data/raw").glob("*.wav"))
    
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
    )
    
    # Disable prefetching - loads on-demand
    streaming_dataset = StreamingDataset(
        mimir_dataset=dataset,
        file_paths=file_paths,
        transform_pipeline=mel_pipeline,
        enable_prefetch=False,  # Disable prefetching
    )
    
    loader = DataLoader(streaming_dataset, batch_size=32)
    
    for batch in loader:
        # Still memory efficient, but no prefetching
        pass


if __name__ == "__main__":
    print("=" * 60)
    print("Streaming Dataset Examples")
    print("=" * 60)
    
    print("\n1. Basic Streaming Dataset")
    print("-" * 60)
    # example_basic_streaming()
    
    print("\n2. Streaming with Augmentations")
    print("-" * 60)
    # example_streaming_with_augmentation()
    
    print("\n3. Convenience Function")
    print("-" * 60)
    # example_convenience_function()
    
    print("\n4. Prefetch Stats Monitoring")
    print("-" * 60)
    # example_prefetch_stats()
    
    print("\n5. Disable Prefetching")
    print("-" * 60)
    # example_disable_prefetch()
    
    print("\nNote: Uncomment examples to run them with your data.")

