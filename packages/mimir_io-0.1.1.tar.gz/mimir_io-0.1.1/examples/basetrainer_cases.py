"""
Main use cases for BaseTrainer.

Demonstrates different ways to use BaseTrainer for training models.
"""

import torch
import torch.nn as nn
from pathlib import Path
from typing import Dict, Any
from torch.utils.data import DataLoader

from mimir_io import Dataset, split_dataset
from mimir_io.audio import resample, log_mel_spectrogram
from mimir_io.rayframe.audio import augment_audio_frame
from mimir_io.torch_dataset import MimirTorchDataset, create_dataloader
from mimir_io.models import BaseTrainer, load_config, create_model
from mimir_io.experiment import quick_train, setup_experiment, ExperimentConfig


# ========== CASE 1: Direct usage with ready DataLoaders ==========

def case1_direct_usage():
    """
    Most basic case - when you already have ready DataLoaders.
    
    Use when:
    - You want full control over data preparation process
    - You already have configured DataLoaders
    - You use custom data preparation logic
    """
    # Prepare data manually
    mimir_dataset = Dataset(data_dir="./data")
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100).no_cache()
        | log_mel_spectrogram(sample_rate=16000, n_mels=80).cache()
    )
    
    train_files = list(Path("./data/raw").glob("*.wav"))
    train_labels = [0, 1, 0, 1, ...]  # Your labels
    
    train_dataset = MimirTorchDataset(
        mimir_dataset=mimir_dataset,
        file_paths=train_files,
        transform_pipeline=mel_pipeline,
        labels=train_labels,
    )
    
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    val_loader = DataLoader(train_dataset, batch_size=32, shuffle=False)  # Example
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Training configuration
    config = {
        "training": {
            "epochs": 10,
            "save_dir": "./checkpoints",
            "optimizer": {
                "type": "Adam",
                "lr": 0.001,
            },
            "criterion": {
                "type": "CrossEntropyLoss",
            },
        }
    }
    
    # Create trainer
    trainer = BaseTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
    )
    
    # Start training
    trainer.train()
    
    return trainer


# ========== CASE 2: Using quick_train (simplest) ==========

def case2_quick_train():
    """
    Simplest way - minimal code.
    
    Use when:
    - You want to quickly start an experiment
    - You don't need detailed control
    - You use standard mimir_io settings
    """
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Start training (everything else is automatic!)
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
    )
    
    return trainer


# ========== CASE 3: quick_train with custom configuration ==========

def case3_quick_train_custom_config():
    """
    quick_train with parameter configuration.
    
    Use when:
    - You need custom training parameters
    - You want to change batch size, learning rate, etc.
    - But still want minimal code
    """
    # Create configuration
    config = ExperimentConfig(
        batch_size=64,           # Larger batch
        epochs=20,               # More epochs
        learning_rate=0.0001,    # Different learning rate
        n_mels=128,              # More mel bins
        use_augmentation=True,   # Enable augmentations
        augmentation_config={
            "time_shift_max": 2000,
            "gain_range": (0.8, 1.2),
        },
        # Optional: Add early stopping
        # early_stopping={
        #     "enabled": True,
        #     "monitor": "val_loss",
        #     "patience": 5,
        # },
    )
    
    # Create model
    model = nn.Sequential(
        nn.Linear(config.n_mels, 256),
        nn.ReLU(),
        nn.Linear(256, 10),
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Start with configuration
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        config=config,
        precompute_cache=True,  # Precompute cache
    )
    
    return trainer


# ========== CASE 4: setup_experiment + BaseTrainer (flexible control) ==========

def case4_flexible_control():
    """
    More flexible control over the process.
    
    Use when:
    - You need access to DataLoaders before training
    - You want to add custom logic (scheduler, callbacks, etc.)
    - You want to control the data preparation process
    """
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Setup experiment (get DataLoaders and configuration)
    train_loader, val_loader, test_loader, dataset, config = setup_experiment(
        file_paths=files,
        labels=labels,
        split_path="./data/split.json",  # Save split
        precompute_cache=True,
    )
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create trainer
    trainer = BaseTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
    )
    
    # Add custom logic before training
    # For example, learning rate scheduler:
    scheduler = torch.optim.lr_scheduler.StepLR(
        trainer.optimizer, step_size=5, gamma=0.1
    )
    
    # Or use callbacks for early stopping, image metrics, etc.
    # from mimir_io.models import EarlyStoppingCallback, ImageMetricsCallback
    # callbacks = [
    #     EarlyStoppingCallback(monitor="val_loss", patience=5),
    #     ImageMetricsCallback(save_dir="./metrics"),
    # ]
    # trainer.callback_manager.callbacks.extend(callbacks)
    
    # Modify training loop (extension example)
    # Can create BaseTrainer subclass or use custom loop
    
    # Start training
    trainer.train()
    
    return trainer


# ========== CASE 5: Using with YAML configuration ==========

def case5_yaml_config():
    """
    Training from YAML configuration file.
    
    Use when:
    - You want to store configuration in a file
    - You work with registered models
    - You want to easily change parameters without code changes
    """
    # Load configuration from YAML
    config = load_config("configs/my_model.yaml")
    
    # Create model from configuration (if using model registry)
    model = create_model(
        config["model"]["name"],
        config["model"]
    )
    
    # Or create model manually
    # model = YourModel(**config["model"])
    
    # Prepare data from configuration
    mimir_dataset = Dataset(data_dir=config["data"]["data_dir"])
    mel_pipeline = (
        resample(config["data"]["sample_rate"]).no_cache()
        | log_mel_spectrogram(
            sample_rate=config["data"]["sample_rate"],
            n_mels=config["data"]["n_mels"],
        ).cache()
    )
    
    train_files = list(Path(config["data"]["data_dir"]).glob("raw/**/*.wav"))
    train_labels = [0, 1, ...]  # Your labels
    
    train_dataset = MimirTorchDataset(
        mimir_dataset=mimir_dataset,
        file_paths=train_files,
        transform_pipeline=mel_pipeline,
        labels=train_labels,
    )
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=config["training"]["batch_size"],
        shuffle=True,
    )
    
    val_loader = DataLoader(train_dataset, batch_size=32, shuffle=False)  # Example
    
    # Create trainer from configuration
    trainer = BaseTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
    )
    
    # Or use from_config
    trainer = BaseTrainer.from_config(
        config_path="configs/my_model.yaml",
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
    )
    
    # Start training
    trainer.train()
    
    return trainer


# ========== CASE 6: Extending BaseTrainer for custom logic ==========

class CustomTrainer(BaseTrainer):
    """
    Extended trainer with additional logic.
    
    Use when:
    - You need custom metrics
    - You want to add learning rate scheduler
    - You want to add early stopping (use EarlyStoppingCallback instead!)
    - You want custom logging (wandb, tensorboard, etc.)
    
    Note: For early stopping, use EarlyStoppingCallback instead of overriding train().
    This is simpler and more maintainable.
    """
    
    def __init__(self, *args, use_scheduler=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.use_scheduler = use_scheduler
        if use_scheduler:
            self.scheduler = torch.optim.lr_scheduler.StepLR(
                self.optimizer, step_size=5, gamma=0.1
            )
    
    def train_epoch(self) -> Dict[str, float]:
        """Override train_epoch to add custom metrics."""
        metrics = super().train_epoch()
        
        # Add custom metrics
        # For example, learning rate
        if self.use_scheduler:
            metrics["learning_rate"] = self.optimizer.param_groups[0]["lr"]
        
        return metrics
    
    def train(self) -> None:
        """Override train to add scheduler."""
        # Note: BaseTrainer.train() already handles callbacks and early stopping
        # This override is only for adding scheduler logic
        best_val_loss = float("inf")
        
        for epoch in range(self.epochs):
            # Set epoch for dataset
            if self.train_loader and hasattr(self.train_loader.dataset, "set_epoch"):
                self.train_loader.dataset.set_epoch(epoch)
            
            # Train
            train_metrics = self.train_epoch()
            
            # Validate
            val_metrics = self.validate()
            
            # Update scheduler
            if self.use_scheduler:
                self.scheduler.step()
            
            # Print metrics
            print(f"Epoch {epoch + 1}/{self.epochs}:")
            print(f"  Train Loss: {train_metrics['train_loss']:.4f}")
            if "learning_rate" in train_metrics:
                print(f"  LR: {train_metrics['learning_rate']:.6f}")
            if val_metrics:
                print(f"  Val Loss: {val_metrics.get('val_loss', 0):.4f}")
            
            # Save checkpoint
            val_loss = val_metrics.get("val_loss", float("inf"))
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                self.save_checkpoint(epoch, is_best=True)
            else:
                self.save_checkpoint(epoch, is_best=False)
            
            # Check for early stopping (if using callbacks)
            if hasattr(self, 'should_stop') and self.should_stop:
                break


def case6_custom_trainer():
    """
    Using custom trainer with scheduler.
    
    Use when:
    - You need custom metrics
    - You want to add learning rate scheduler
    - You want custom logging (wandb, tensorboard, etc.)
    """
    from mimir_io.experiment import setup_experiment
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Setup experiment to get DataLoaders
    train_loader, val_loader, _, _, config = setup_experiment(
        file_paths=files,
        labels=labels,
    )
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create custom trainer with scheduler
    trainer = CustomTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
        use_scheduler=True,  # Enable scheduler
    )
    
    trainer.train()
    
    return trainer


# ========== CASE 7: Training without validation ==========

def case7_no_validation():
    """
    Training only on training set.
    
    Use when:
    - You don't have a validation set
    - You want to train only on training data
    """
    from mimir_io.experiment import setup_experiment
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Setup experiment - only get train loader
    train_loader, _, _, _, config = setup_experiment(
        file_paths=files,
        labels=labels,
    )
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create trainer without val_loader
    trainer = BaseTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=None,  # No validation
    )
    
    # Trainer automatically handles absence of val_loader
    trainer.train()
    
    return trainer


# ========== CASE 8: Using with different optimizers ==========

def case8_different_optimizers():
    """
    Using different optimizers through configuration.
    
    Supported optimizers:
    - Adam
    - SGD
    """
    from mimir_io.experiment import setup_experiment
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Setup experiment
    train_loader, val_loader, _, _, _ = setup_experiment(
        file_paths=files,
        labels=labels,
    )
    
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Adam optimizer configuration
    config_adam = {
        "training": {
            "epochs": 10,
            "optimizer": {
                "type": "Adam",
                "lr": 0.001,
                "betas": [0.9, 0.999],  # Additional parameters
            },
            "criterion": {"type": "CrossEntropyLoss"},
        }
    }
    
    # SGD optimizer configuration
    config_sgd = {
        "training": {
            "epochs": 10,
            "optimizer": {
                "type": "SGD",
                "lr": 0.01,
                "momentum": 0.9,  # Additional parameters
            },
            "criterion": {"type": "CrossEntropyLoss"},
        }
    }
    
    # Trainer automatically sets up optimizer from configuration
    trainer = BaseTrainer(
        model=model,
        config=config_adam,  # or config_sgd
        train_loader=train_loader,
        val_loader=val_loader,
    )
    
    trainer.train()
    
    return trainer


# ========== CASE 9: Using with different loss criteria ==========

def case9_different_criteria():
    """
    Using different loss criteria through configuration.
    
    Supported criteria:
    - CrossEntropyLoss (for classification)
    - MSELoss (for regression)
    """
    from mimir_io.experiment import setup_experiment
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Setup experiment
    train_loader, val_loader, _, _, _ = setup_experiment(
        file_paths=files,
        labels=labels,
    )
    
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # CrossEntropyLoss for classification
    config_classification = {
        "training": {
            "epochs": 10,
            "optimizer": {"type": "Adam", "lr": 0.001},
            "criterion": {"type": "CrossEntropyLoss"},
        }
    }
    
    # MSELoss for regression
    config_regression = {
        "training": {
            "epochs": 10,
            "optimizer": {"type": "Adam", "lr": 0.001},
            "criterion": {"type": "MSELoss"},
        }
    }
    
    trainer = BaseTrainer(
        model=model,
        config=config_classification,  # or config_regression
        train_loader=train_loader,
        val_loader=val_loader,
    )
    
    trainer.train()
    
    return trainer


# ========== CASE 10: Resuming from checkpoint ==========

def case10_resume_from_checkpoint():
    """
    Resuming training from saved checkpoint.
    
    Use when:
    - Training was interrupted
    - You want to continue from a specific epoch
    - You want to use a saved model
    """
    from mimir_io.experiment import setup_experiment
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Setup experiment
    train_loader, val_loader, _, _, _ = setup_experiment(
        file_paths=files,
        labels=labels,
    )
    
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    config = {
        "training": {
            "epochs": 20,  # Total number of epochs
            "save_dir": "./checkpoints",
            "optimizer": {"type": "Adam", "lr": 0.001},
            "criterion": {"type": "CrossEntropyLoss"},
        }
    }
    
    trainer = BaseTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
    )
    
    # Load checkpoint
    checkpoint_path = "./checkpoints/checkpoint_epoch_5.pt"
    checkpoint = torch.load(checkpoint_path)
    
    # Restore model and optimizer state
    trainer.model.load_state_dict(checkpoint["model_state_dict"])
    trainer.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
    
    # Can also change starting epoch
    # trainer.epochs = config["training"]["epochs"] - checkpoint["epoch"] - 1
    
    # Continue training
    trainer.train()
    
    return trainer


# ========== Summary of main use cases ==========

"""
MAIN USE CASES FOR BaseTrainer:

1. Direct usage - when you have ready DataLoaders
2. quick_train - simplest way (minimal code)
3. quick_train + custom configuration - quick start with settings
4. setup_experiment + BaseTrainer - flexible control
5. YAML configuration - storing parameters in file
6. Extending BaseTrainer - custom logic (scheduler, callbacks)
7. Without validation - only training set
8. Different optimizers - Adam, SGD through configuration
9. Different criteria - CrossEntropyLoss, MSELoss
10. Resuming from checkpoint - continuing training

NEW FEATURES:
- Early stopping via ExperimentConfig or EarlyStoppingCallback
- ImageMetricsCallback for saving metrics as images
- Custom callbacks support

CHOOSING A USE CASE DEPENDS ON:
- Task complexity
- Need for control
- Availability of ready components
- Need for experiment reproducibility
"""


if __name__ == "__main__":
    # Usage examples (uncomment the one you need):
    
    # Case 1: Direct usage
    # case1_direct_usage()
    
    # Case 2: Simplest way
    # case2_quick_train()
    
    # Case 3: With custom configuration
    # case3_quick_train_custom_config()
    
    # Case 4: Flexible control
    # case4_flexible_control()
    
    # Case 5: YAML configuration
    # case5_yaml_config()
    
    # Case 6: Custom trainer
    # case6_custom_trainer()
    
    # Case 7: Without validation
    # case7_no_validation()
    
    # Case 8: Different optimizers
    # case8_different_optimizers()
    
    # Case 9: Different criteria
    # case9_different_criteria()
    
    # Case 10: Resuming from checkpoint
    # case10_resume_from_checkpoint()
    
    print("Main use cases for BaseTrainer:")
    print("1. Direct usage with ready DataLoaders")
    print("2. quick_train - simplest way")
    print("3. quick_train with custom configuration")
    print("4. setup_experiment + BaseTrainer - flexible control")
    print("5. YAML configuration")
    print("6. Extending BaseTrainer for custom logic")
    print("7. Training without validation")
    print("8. Different optimizers (Adam, SGD)")
    print("9. Different loss criteria (CrossEntropyLoss, MSELoss)")
    print("10. Resuming from checkpoint")

