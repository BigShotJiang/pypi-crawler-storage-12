"""
Example usage of Warmup Scheduler in mimir_io.

Demonstrates different ways to use warmup scheduler for training stabilization.
"""

import torch
import torch.nn as nn
from pathlib import Path

from mimir_io.experiment import quick_train, ExperimentConfig
from mimir_io.models import BaseTrainer, create_scheduler
from mimir_io.models.warmup_scheduler import WarmupScheduler


def example1_warmup_cosine_annealing():
    """Example 1: WarmupCosineAnnealingLR with ExperimentConfig."""
    print("=" * 60)
    print("Example 1: WarmupCosineAnnealingLR")
    print("=" * 60)
    
    # Create a simple model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create configuration with warmup scheduler
    config = ExperimentConfig(
        epochs=20,
        learning_rate=0.01,
        batch_size=32,
        scheduler={
            "enabled": True,
            "type": "WarmupCosineAnnealingLR",
            "warmup_epochs": 5,           # 5 epochs warmup
            "warmup_start_lr": 1e-6,      # Initial LR
            "warmup_mode": "linear",     # Linear increase
            "T_max": 20,                  # Full cycle 20 epochs
            "eta_min": 0.00001,           # Minimum LR
        },
    )
    
    # Example usage (requires real data)
    # files = list(Path("./data/raw").glob("*.wav"))
    # labels = [0, 1, 0, 1, ...]
    # trainer = quick_train(model=model, file_paths=files, labels=labels, config=config)
    
    print("Configuration created successfully!")
    print(f"Warmup epochs: {config.scheduler['warmup_epochs']}")
    print(f"Warmup start LR: {config.scheduler['warmup_start_lr']}")
    print(f"Max LR: {config.learning_rate}")


def example2_warmup_step_lr():
    """Example 2: WarmupStepLR with YAML config."""
    print("\n" + "=" * 60)
    print("Example 2: WarmupStepLR")
    print("=" * 60)
    
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Configuration via dict (YAML equivalent)
    config = {
        "training": {
            "epochs": 30,
            "optimizer": {
                "type": "Adam",
                "lr": 0.001,
            },
            "criterion": {
                "type": "CrossEntropyLoss",
            },
            "scheduler": {
                "enabled": True,
                "type": "WarmupStepLR",
                "warmup_epochs": 5,
                "warmup_start_lr": 1e-6,
                "warmup_mode": "linear",
                "step_size": 10,         # After warmup reduce LR every 10 epochs
                "gamma": 0.1,            # Multiplier for LR reduction
            },
        },
    }
    
    print("Configuration created successfully!")
    print("LR will be:")
    print("  - Warmup: 1e-6 -> 0.001 (5 epochs)")
    print("  - After warmup: 0.001 -> 0.0001 -> 0.00001 (every 10 epochs)")


def example3_step_based_warmup():
    """Example 3: Step-based warmup (more precise control)."""
    print("\n" + "=" * 60)
    print("Example 3: Step-based Warmup")
    print("=" * 60)
    
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Use warmup_steps instead of warmup_epochs
    config = ExperimentConfig(
        epochs=20,
        learning_rate=0.01,
        scheduler={
            "enabled": True,
            "type": "WarmupCosineAnnealingLR",
            "warmup_steps": 1000,       # Warmup based on number of batches
            "warmup_start_lr": 1e-6,
            "warmup_mode": "linear",
            "T_max": 20,
            "eta_min": 0.00001,
        },
    )
    
    print("Configuration created successfully!")
    print("Warmup will be performed based on number of batches, not epochs.")
    print("Scheduler will be called after each batch during warmup.")


def example4_direct_usage():
    """Example 4: Direct usage of WarmupScheduler."""
    print("\n" + "=" * 60)
    print("Example 4: Direct Usage of WarmupScheduler")
    print("=" * 60)
    
    # Create model and optimizer
    model = nn.Sequential(
        nn.Linear(10, 64),
        nn.ReLU(),
        nn.Linear(64, 2),
    )
    
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    
    # Create base scheduler
    base_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=10, eta_min=0.00001
    )
    
    # Wrap in WarmupScheduler
    warmup_scheduler = WarmupScheduler(
        optimizer=optimizer,
        base_scheduler=base_scheduler,
        warmup_epochs=3,
        warmup_start_lr=1e-6,
        warmup_mode="linear",
    )
    
    print("WarmupScheduler created successfully!")
    print(f"Initial LR: {warmup_scheduler.warmup_start_lr}")
    print(f"Maximum LR: {warmup_scheduler.max_lr}")
    print(f"Warmup epochs: {warmup_scheduler.warmup_epochs}")
    
    # Simulate steps
    print("\nWarmup simulation:")
    for epoch in range(5):
        warmup_scheduler.step(epoch=epoch)
        current_lr = optimizer.param_groups[0]["lr"]
        print(f"  Epoch {epoch + 1}: LR = {current_lr:.6f}, Warmup finished: {warmup_scheduler.warmup_finished}")


def example5_warmup_reduce_lr_on_plateau():
    """Example 5: WarmupReduceLROnPlateau."""
    print("\n" + "=" * 60)
    print("Example 5: WarmupReduceLROnPlateau")
    print("=" * 60)
    
    config = ExperimentConfig(
        epochs=30,
        learning_rate=0.001,
        scheduler={
            "enabled": True,
            "type": "WarmupReduceLROnPlateau",
            "warmup_epochs": 5,
            "warmup_start_lr": 1e-6,
            "warmup_mode": "linear",
            "mode": "min",              # Reduce LR when val_loss doesn't improve
            "factor": 0.5,               # Reduction factor
            "patience": 3,               # Wait 3 epochs without improvement
            "monitor": "val_loss",       # Monitor val_loss
        },
    )
    
    print("Configuration created successfully!")
    print("LR will be:")
    print("  - Warmup: 1e-6 -> 0.001 (5 epochs)")
    print("  - After warmup: reduced by 50% if val_loss doesn't improve for 3 epochs")


if __name__ == "__main__":
    print("Warmup Scheduler Usage Examples\n")
    
    example1_warmup_cosine_annealing()
    example2_warmup_step_lr()
    example3_step_based_warmup()
    example4_direct_usage()
    example5_warmup_reduce_lr_on_plateau()
    
    print("\n" + "=" * 60)
    print("All examples completed!")
    print("=" * 60)

