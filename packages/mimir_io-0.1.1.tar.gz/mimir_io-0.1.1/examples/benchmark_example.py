"""
Приклад використання бенчмарків та порівняння експериментів.

Демонструє:
1. Запуск тренування з автоматичними бенчмарками
2. Збереження результатів експериментів
3. Порівняння різних експериментів
"""

from pathlib import Path
import torch.nn as nn

from mimir_io.experiment import ExperimentConfig, quick_train, quick_test
from mimir_io.models.compare_experiments import compare_experiments, ExperimentComparator
from mimir_io.models.experiment_results import ExperimentResultsManager


def example_training_with_benchmarks():
    """Приклад тренування з автоматичними бенчмарками."""
    
    # Створюємо модель
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 64),
        nn.ReLU(),
        nn.Linear(64, 10),
    )
    
    # Налаштовуємо конфігурацію експерименту
    config = ExperimentConfig(
        experiment_name="baseline_model",
        batch_size=32,
        epochs=10,
        learning_rate=0.001,
        run_benchmarks=True,  # Увімкнути бенчмарки
        benchmark_names=["accuracy", "classification_metrics", "confusion_matrix"],  # Конкретні бенчмарки
        save_results=True,  # Зберегти результати
        results_dir="./experiment_results",
    )
    
    # Припустимо, що у нас є дані
    # files = list(Path("./data/raw").glob("*.wav"))
    # labels = [0, 1, 0, 1, ...]  # Ваші мітки
    
    # Запускаємо тренування (бенчмарки запустяться автоматично після тренування)
    # trainer = quick_train(
    #     model=model,
    #     file_paths=files,
    #     labels=labels,
    #     config=config,
    #     split_path="./data/split.json",
    # )
    
    print("Тренування завершено! Бенчмарки виконані автоматично.")


def example_testing_with_benchmarks():
    """Приклад тестування з бенчмарками."""
    
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    config = ExperimentConfig(
        experiment_name="test_run",
        run_benchmarks=True,
        benchmark_names=["accuracy", "inference_time"],  # Тест точності та швидкості
        save_results=True,
    )
    
    # Запускаємо тестування
    # tester = quick_test(
    #     model=model,
    #     split_path="./data/split.json",
    #     checkpoint_path="./checkpoints/best_model.pt",
    #     config=config,
    # )
    
    print("Тестування завершено! Бенчмарки виконані.")


def example_comparing_experiments():
    """Приклад порівняння експериментів."""
    
    # Завантажуємо менеджер результатів
    manager = ExperimentResultsManager("./experiment_results")
    
    # Отримуємо всі результати
    all_results = manager.list_results()
    
    if len(all_results) < 2:
        print("Потрібно мінімум 2 експерименти для порівняння")
        return
    
    # Створюємо компаратор
    comparator = ExperimentComparator(all_results)
    
    # Порівнюємо бенчмарки
    print("\n=== Порівняння бенчмарків ===")
    benchmark_df = comparator.compare_benchmarks("accuracy", "accuracy")
    print(benchmark_df)
    
    # Порівнюємо конфігурації
    print("\n=== Порівняння конфігурацій ===")
    config_df = comparator.compare_configs()
    print(config_df)
    
    # Генеруємо звіт
    print("\n=== Генерація звіту ===")
    report = comparator.generate_report(
        output_path="./comparison_report.md",
        format="markdown"
    )
    print("Звіт збережено у comparison_report.md")
    
    # Знаходимо найкращий експеримент
    best = comparator.find_best("accuracy", "accuracy", higher_is_better=True)
    if best:
        print(f"\nНайкращий експеримент: {best.experiment_name}")
        print(f"  ID: {best.experiment_id}")
        print(f"  Accuracy: {best.benchmark_results.get('accuracy', {}).get('accuracy', 'N/A')}")


def example_using_experiment_ids():
    """Приклад порівняння за ID експериментів."""
    
    # Порівнюємо конкретні експерименти за їх ID
    comparator = compare_experiments(
        experiment_ids=["exp1_id", "exp2_id", "exp3_id"],
        results_dir="./experiment_results",
    )
    
    # Отримуємо підсумок
    summary = comparator.get_summary()
    print("Підсумок експериментів:")
    print(f"  Кількість: {summary['num_experiments']}")
    print(f"  Діапазон дат: {summary['date_range']}")
    print(f"  Доступні бенчмарки: {list(summary['benchmarks'].keys())}")


if __name__ == "__main__":
    print("Приклади використання бенчмарків та порівняння експериментів")
    print("=" * 60)
    
    # Розкоментуйте потрібні приклади:
    # example_training_with_benchmarks()
    # example_testing_with_benchmarks()
    # example_comparing_experiments()
    # example_using_experiment_ids()

