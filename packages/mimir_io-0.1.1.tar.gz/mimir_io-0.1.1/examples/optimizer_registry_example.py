"""
Приклад використання реєстру оптимізаторів та критеріїв.

Показує, як:
1. Використовувати стандартні оптимізатори та критерії
2. Додавати власні оптимізатори та критерії через реєстр
"""

import torch
import torch.nn as nn
from mimir_io.models import (
    register_optimizer,
    register_criterion,
    create_optimizer,
    create_criterion,
    list_optimizers,
    list_criteria,
    BaseTrainer,
)

# ========== Приклад 1: Перегляд доступних оптимізаторів та критеріїв ==========

def example1_list_available():
    """Показати всі доступні оптимізатори та критерії."""
    print("Доступні оптимізатори:", list_optimizers())
    print("Доступні критерії:", list_criteria())


# ========== Приклад 2: Додавання власного оптимізатора ==========

@register_optimizer("CustomAdam")
def custom_adam_factory(params, lr=0.001, weight_decay=0.01, **kwargs):
    """
    Власна реалізація Adam з додатковими параметрами.
    
    Args:
        params: Параметри моделі (model.parameters())
        lr: Learning rate
        weight_decay: Weight decay (L2 regularization)
        **kwargs: Інші параметри для torch.optim.Adam
    """
    return torch.optim.Adam(
        params,
        lr=lr,
        weight_decay=weight_decay,
        **kwargs
    )


# ========== Приклад 3: Додавання власного критерію ==========

@register_criterion("WeightedCrossEntropy")
def weighted_cross_entropy_factory(weight=None, **kwargs):
    """
    Weighted CrossEntropyLoss для несбалансованих класів.
    
    Args:
        weight: Tensor з вагами для кожного класу
        **kwargs: Інші параметри для nn.CrossEntropyLoss
    """
    if weight is not None:
        weight = torch.tensor(weight, dtype=torch.float32)
    return nn.CrossEntropyLoss(weight=weight, **kwargs)


# ========== Приклад 4: Використання стандартних оптимізаторів ==========

def example4_use_standard():
    """Використання стандартних оптимізаторів через конфігурацію."""
    model = nn.Sequential(
        nn.Linear(10, 64),
        nn.ReLU(),
        nn.Linear(64, 2),
    )
    
    # Створення оптимізатора через реєстр
    optimizer = create_optimizer(
        name="Adam",
        model_parameters=model.parameters(),
        config={"lr": 0.001, "betas": [0.9, 0.999]}
    )
    
    # Створення критерію через реєстр
    criterion = create_criterion(
        name="CrossEntropyLoss",
        config={}
    )
    
    print(f"Оптимізатор: {type(optimizer).__name__}")
    print(f"Критерій: {type(criterion).__name__}")


# ========== Приклад 5: Використання власних оптимізаторів у BaseTrainer ==========

def example5_custom_in_trainer():
    """Використання власних оптимізаторів та критеріїв у BaseTrainer."""
    model = nn.Sequential(
        nn.Linear(10, 64),
        nn.ReLU(),
        nn.Linear(64, 2),
    )
    
    # Конфігурація з власним оптимізатором та критерієм
    config = {
        "training": {
            "epochs": 5,
            "optimizer": {
                "type": "CustomAdam",  # Використовуємо зареєстрований оптимізатор
                "lr": 0.001,
                "weight_decay": 0.01,
            },
            "criterion": {
                "type": "WeightedCrossEntropy",  # Використовуємо зареєстрований критерій
                "weight": [1.0, 2.0],  # Ваги для двох класів
            },
        }
    }
    
    # BaseTrainer автоматично використає реєстр для створення оптимізатора та критерію
    # trainer = BaseTrainer(model=model, config=config, ...)
    print("Конфігурація готова для використання з BaseTrainer")


# ========== Приклад 6: Додавання оптимізатора з іншими параметрами ==========

@register_optimizer("AdamWithScheduler")
def adam_with_scheduler_factory(params, lr=0.001, **kwargs):
    """
    Adam оптимізатор з можливістю додавання scheduler.
    """
    optimizer = torch.optim.Adam(params, lr=lr, **kwargs)
    # Можна додати scheduler тут або пізніше
    return optimizer


if __name__ == "__main__":
    print("=== Приклад 1: Список доступних ===")
    example1_list_available()
    
    print("\n=== Приклад 2-3: Реєстрація власних ===")
    print("CustomAdam та WeightedCrossEntropy зареєстровані")
    
    print("\n=== Приклад 4: Використання стандартних ===")
    example4_use_standard()
    
    print("\n=== Приклад 5: Конфігурація для BaseTrainer ===")
    example5_custom_in_trainer()
    
    print("\n=== Оновлений список ===")
    print("Оптимізатори:", list_optimizers())
    print("Критерії:", list_criteria())

