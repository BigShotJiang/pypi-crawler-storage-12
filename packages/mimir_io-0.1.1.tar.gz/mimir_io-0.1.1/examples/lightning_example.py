"""
Example of using mimir_io with PyTorch Lightning.

Demonstrates how mimir_io solves common Lightning problems:
- Automatic caching (10-100x faster after first epoch)
- Proper seed management for reproducibility
- GPU-accelerated augmentations
- Easy multiprocessing setup
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from pathlib import Path

try:
    import pytorch_lightning as pl
    from pytorch_lightning.callbacks import EarlyStopping, ModelCheckpoint
    from pytorch_lightning.loggers import TensorBoardLogger
except ImportError:
    print("PyTorch Lightning is required. Install with: pip install pytorch-lightning")
    raise

from mimir_io.lightning import MimirDataModule
from mimir_io.audio import resample, log_mel_spectrogram
from mimir_io.rayframe.audio import augment_audio_frame


# ========== 1. Simple Example ==========

def simple_example():
    """
    Simplest example - minimal code.
    
    Shows how easy it is to use mimir_io with Lightning.
    """
    # Prepare data
    all_files = list(Path("./data/raw").glob("*.wav"))
    all_labels = [0, 1, 0, 1, ...]  # Your labels
    
    # Create DataModule (everything automatic!)
    datamodule = MimirDataModule(
        file_paths=all_files,
        labels=all_labels,
        transform_pipeline=resample(16000) | log_mel_spectrogram(n_mels=80),
        batch_size=32,
        num_workers=4,
    )
    
    # Create Lightning Module
    class AudioClassifier(pl.LightningModule):
        def __init__(self):
            super().__init__()
            self.model = nn.Sequential(
                nn.Linear(80, 128),
                nn.ReLU(),
                nn.Linear(128, 10),
            )
        
        def training_step(self, batch, batch_idx):
            features, labels = batch
            outputs = self.model(features)
            loss = F.cross_entropy(outputs, labels)
            self.log("train_loss", loss)
            return loss
        
        def validation_step(self, batch, batch_idx):
            features, labels = batch
            outputs = self.model(features)
            loss = F.cross_entropy(outputs, labels)
            acc = (outputs.argmax(dim=1) == labels).float().mean()
            self.log("val_loss", loss)
            self.log("val_acc", acc)
            return loss
        
        def configure_optimizers(self):
            return torch.optim.Adam(self.parameters(), lr=0.001)
    
    # Train
    model = AudioClassifier()
    trainer = pl.Trainer(max_epochs=10)
    trainer.fit(model, datamodule)
    
    return trainer, model


# ========== 2. Advanced Example with All Features ==========

def advanced_example():
    """
    Advanced example with all mimir_io features.
    
    Shows:
    - Custom augmentation pipeline
    - Cache precomputation
    - Split saving/loading
    - All Lightning features (DDP, mixed precision, etc.)
    """
    # Prepare data
    all_files = list(Path("./data/raw").glob("*.wav"))
    all_labels = [0, 1, 0, 1, ...]  # Your labels
    
    # Create custom pipelines
    transform_pipeline = (
        resample(16000, orig_sample_rate=44100).no_cache()
        | log_mel_spectrogram(n_mels=80, n_fft=2048).cache()
    )
    
    augmentation_pipeline = augment_audio_frame(
        time_shift_max=1600,
        gain_range=(0.7, 1.3),
        noise_snr=20.0,
    )
    
    # Create DataModule with all features
    datamodule = MimirDataModule(
        file_paths=all_files,
        labels=all_labels,
        transform_pipeline=transform_pipeline,
        augmentation_pipeline=augmentation_pipeline,
        data_dir="./data",
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15,
        batch_size=64,
        num_workers=8,
        pin_memory=True,
        persistent_workers=True,  # Faster loading
        prefetch_factor=4,  # Prefetch more batches
        split_seed=42,
        stratify=True,
        split_path="./data/split.json",  # Save split for reproducibility
        use_augmentation=True,
        precompute_cache=True,  # Precompute cache before training
    )
    
    # Create Lightning Module
    class AudioModel(pl.LightningModule):
        def __init__(self, n_classes=10, lr=0.001):
            super().__init__()
            self.save_hyperparameters()
            
            self.model = nn.Sequential(
                nn.Conv2d(1, 32, kernel_size=3, padding=1),
                nn.ReLU(),
                nn.MaxPool2d(2),
                nn.Conv2d(32, 64, kernel_size=3, padding=1),
                nn.ReLU(),
                nn.MaxPool2d(2),
                nn.AdaptiveAvgPool2d((1, 1)),
                nn.Flatten(),
                nn.Linear(64, 128),
                nn.ReLU(),
                nn.Linear(128, n_classes),
            )
        
        def forward(self, x):
            # Add channel dimension if needed
            if x.dim() == 3:  # (batch, n_mels, time)
                x = x.unsqueeze(1)  # (batch, 1, n_mels, time)
            return self.model(x)
        
        def training_step(self, batch, batch_idx):
            features, labels = batch
            outputs = self(features)
            loss = F.cross_entropy(outputs, labels)
            acc = (outputs.argmax(dim=1) == labels).float().mean()
            
            self.log("train_loss", loss, on_step=True, on_epoch=True)
            self.log("train_acc", acc, on_step=True, on_epoch=True)
            return loss
        
        def validation_step(self, batch, batch_idx):
            features, labels = batch
            outputs = self(features)
            loss = F.cross_entropy(outputs, labels)
            acc = (outputs.argmax(dim=1) == labels).float().mean()
            
            self.log("val_loss", loss, on_step=False, on_epoch=True)
            self.log("val_acc", acc, on_step=False, on_epoch=True)
            return loss
        
        def test_step(self, batch, batch_idx):
            features, labels = batch
            outputs = self(features)
            loss = F.cross_entropy(outputs, labels)
            acc = (outputs.argmax(dim=1) == labels).float().mean()
            
            self.log("test_loss", loss, on_step=False, on_epoch=True)
            self.log("test_acc", acc, on_step=False, on_epoch=True)
            return loss
        
        def configure_optimizers(self):
            optimizer = torch.optim.Adam(
                self.parameters(),
                lr=self.hparams.lr,
                weight_decay=1e-4,
            )
            scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
                optimizer,
                mode="min",
                factor=0.5,
                patience=3,
            )
            return {
                "optimizer": optimizer,
                "lr_scheduler": {
                    "scheduler": scheduler,
                    "monitor": "val_loss",
                },
            }
    
    # Create model
    model = AudioModel(n_classes=10, lr=0.001)
    
    # Create trainer with all Lightning features
    trainer = pl.Trainer(
        max_epochs=50,
        accelerator="gpu",  # Use GPU
        devices=1,  # Use 1 GPU (change to 4 for DDP)
        precision=16,  # Mixed precision (FP16) - automatic!
        callbacks=[
            EarlyStopping(
                monitor="val_loss",
                patience=5,
                mode="min",
            ),
            ModelCheckpoint(
                monitor="val_loss",
                mode="min",
                save_top_k=3,
                filename="best-{epoch:02d}-{val_loss:.2f}",
            ),
        ],
        logger=TensorBoardLogger(
            save_dir="./logs",
            name="audio_classifier",
        ),
        log_every_n_steps=10,
        val_check_interval=0.5,  # Validate twice per epoch
    )
    
    # Train
    trainer.fit(model, datamodule)
    
    # Test
    trainer.test(model, datamodule)
    
    return trainer, model


# ========== 3. Comparison: Without vs With mimir_io ==========

def comparison_example():
    """
    Shows the difference between using Lightning with and without mimir_io.
    """
    print("=" * 60)
    print("WITHOUT mimir_io (typical Lightning code):")
    print("=" * 60)
    print("""
    # ~150 lines of code for DataModule:
    class AudioDataModule(pl.LightningDataModule):
        def __init__(self, ...):
            # 20+ parameters
            # Manual setup of everything
            pass
        
        def setup(self, stage):
            # Manual file loading
            # Manual dataset creation
            # NO caching!
            pass
        
        def train_dataloader(self):
            # Manual DataLoader setup
            # Manual seed configuration
            # Problems with multiprocessing
            return DataLoader(...)
    
    Problems:
    - No caching (slow!)
    - Complex seed setup
    - Problems with augmentations
    - Lots of boilerplate code
    """)
    
    print("\n" + "=" * 60)
    print("WITH mimir_io (simple code):")
    print("=" * 60)
    print("""
    # 5 lines of code!
    datamodule = MimirDataModule(
        file_paths=files,
        labels=labels,
        transform_pipeline=mel_pipeline,
    )
    
    Benefits:
    ✅ Automatic caching (fast!)
    ✅ Proper seeds (reproducible)
    ✅ GPU augmentations (fast!)
    ✅ Minimal code
    """)


# ========== 4. Distributed Training Example ==========

def distributed_example():
    """
    Example of distributed training with Lightning + mimir_io.
    
    Shows how easy it is to scale to multiple GPUs/nodes.
    """
    all_files = list(Path("./data/raw").glob("*.wav"))
    all_labels = [0, 1, 0, 1, ...]
    
    # Create DataModule
    datamodule = MimirDataModule(
        file_paths=all_files,
        labels=all_labels,
        transform_pipeline=resample(16000) | log_mel_spectrogram(n_mels=80),
        batch_size=32,
        num_workers=4,
        precompute_cache=True,  # Precompute on main process only!
    )
    
    # Create model
    class AudioModel(pl.LightningModule):
        def __init__(self):
            super().__init__()
            self.model = nn.Sequential(...)
        
        def training_step(self, batch, batch_idx):
            ...
        
        def configure_optimizers(self):
            return torch.optim.Adam(self.parameters(), lr=0.001)
    
    # Train on 4 GPUs (DDP automatically!)
    trainer = pl.Trainer(
        max_epochs=50,
        accelerator="gpu",
        devices=4,  # 4 GPUs - DDP automatically!
        strategy="ddp",  # Distributed Data Parallel
        precision=16,  # Mixed precision
    )
    
    model = AudioModel()
    trainer.fit(model, datamodule)
    
    return trainer, model


if __name__ == "__main__":
    # Run simple example
    print("Running simple example...")
    # trainer, model = simple_example()
    
    # Run advanced example
    print("\nRunning advanced example...")
    # trainer, model = advanced_example()
    
    # Show comparison
    comparison_example()
    
    print("\nDone! Check the examples above for usage patterns.")

