"""
Example showing what the split manifest file looks like.

The split.save() creates a JSON manifest file that contains:
- File paths for each split (train/val/test)
- Labels for each split (if provided)
- Metadata about how the split was created
"""

from pathlib import Path
from mimir_io import split_dataset, DatasetSplit

# Example: Create a split
all_files = [
    "./data/raw/audio1.wav",
    "./data/raw/audio2.wav",
    "./data/raw/audio3.wav",
    "./data/raw/audio4.wav",
    "./data/raw/audio5.wav",
]

all_labels = [0, 1, 0, 1, 2]

# Create split
split = split_dataset(
    file_paths=all_files,
    labels=all_labels,
    train_ratio=0.6,
    val_ratio=0.2,
    test_ratio=0.2,
    stratify=True,
    seed=42,
)

# Save manifest file
manifest_path = "./data/split_manifest.json"
split.save(manifest_path)

print(f"Manifest saved to: {manifest_path}")
print("\nManifest file contents:")
print("=" * 60)

# Show what's in the manifest
with open(manifest_path, "r") as f:
    import json
    manifest = json.load(f)
    print(json.dumps(manifest, indent=2))

print("\n" + "=" * 60)
print("\nExample manifest structure:")
print("""
{
  "train_files": [
    "./data/raw/audio1.wav",
    "./data/raw/audio3.wav",
    ...
  ],
  "val_files": [
    "./data/raw/audio2.wav",
    ...
  ],
  "test_files": [
    "./data/raw/audio4.wav",
    ...
  ],
  "train_labels": [0, 0, ...],
  "val_labels": [1, ...],
  "test_labels": [1, ...],
  "metadata": {
    "method": "stratified",
    "seed": 42,
    "shuffle": true,
    "train_ratio": 0.6,
    "val_ratio": 0.2,
    "test_ratio": 0.2
  }
}
""")

print("\nLoading manifest:")
print("=" * 60)

# Load the manifest
loaded_split = DatasetSplit.load(manifest_path)
print(f"Loaded split: {loaded_split}")
print(f"Train files: {len(loaded_split.train_files)}")
print(f"Val files: {len(loaded_split.val_files)}")
print(f"Test files: {len(loaded_split.test_files)}")
print(f"Metadata: {loaded_split.metadata}")

