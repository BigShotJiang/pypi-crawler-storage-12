"""
Example of cache optimization for training workflows.

Demonstrates how to minimize disk usage by caching only necessary transformations.
"""

from mimir_io import Dataset
from mimir_io.audio import resample, normalize, trim_silence, log_mel_spectrogram
from mimir_io.rayframe.image import mel_to_frame


def example_cache_optimization():
    """Example: Cache only final features, not intermediate steps."""
    
    dataset = Dataset(data_dir="./data")
    
    # Load audio (this is cached by default - useful for slow I/O)
    audio_frame = dataset.load_audio("./data/raw/audio.wav")
    
    # Option 1: Explicitly mark which lenses to cache
    # Only cache the expensive mel spectrogram, not cheap operations
    optimized_pipeline = (
        resample(16000, orig_sample_rate=44100).no_cache()  # Cheap operation
        | normalize(target_db=-20.0).no_cache()            # Cheap operation
        | trim_silence(threshold=0.01).no_cache()           # Cheap operation
        | log_mel_spectrogram(
            sample_rate=16000,
            n_mels=80,
            n_fft=2048,
            hop_length=512,
        ).cache()  # Expensive operation - cache this!
    )
    
    # Apply pipeline - only mel spectrogram will be cached
    mel_spec = dataset.apply(optimized_pipeline, audio_frame.data)
    
    print("Only mel spectrogram is cached, saving disk space!")
    return mel_spec


def example_cache_everything():
    """Example: Cache everything (default behavior)."""
    
    dataset = Dataset(data_dir="./data")
    audio_frame = dataset.load_audio("./data/raw/audio.wav")
    
    # Default: all steps are cached
    full_cache_pipeline = (
        resample(16000, orig_sample_rate=44100)  # Cached
        | normalize(target_db=-20.0)            # Cached
        | trim_silence(threshold=0.01)           # Cached
        | log_mel_spectrogram(n_mels=80)         # Cached
    )
    
    mel_spec = dataset.apply(full_cache_pipeline, audio_frame.data)
    
    print("All intermediate steps are cached (uses more disk space)")
    return mel_spec


def example_cache_nothing():
    """Example: Don't cache anything (useful for debugging)."""
    
    dataset = Dataset(data_dir="./data")
    audio_frame = dataset.load_audio("./data/raw/audio.wav")
    
    # Mark all steps as no_cache
    no_cache_pipeline = (
        resample(16000, orig_sample_rate=44100).no_cache()
        | normalize(target_db=-20.0).no_cache()
        | log_mel_spectrogram(n_mels=80).no_cache()
    )
    
    mel_spec = dataset.apply(no_cache_pipeline, audio_frame.data)
    
    print("Nothing is cached (useful for debugging)")
    return mel_spec


def example_selective_caching():
    """Example: Cache only specific expensive operations."""
    
    dataset = Dataset(data_dir="./data")
    audio_frame = dataset.load_audio("./data/raw/audio.wav")
    
    # Cache only expensive operations:
    # - Audio loading (slow I/O) - cached by default
    # - Mel spectrogram (expensive computation) - explicitly cached
    # - Everything else - not cached
    selective_pipeline = (
        resample(16000, orig_sample_rate=44100).no_cache()
        | normalize(target_db=-20.0).no_cache()
        | trim_silence(threshold=0.01).no_cache()
        | log_mel_spectrogram(n_mels=80).cache()  # Only this is cached
        | mel_to_frame(sample_rate=16000).no_cache()  # Cheap conversion
    )
    
    result = dataset.apply(selective_pipeline, audio_frame.data)
    
    print("Only mel spectrogram is cached")
    return result


def example_training_workflow():
    """
    Recommended workflow for training:
    - Cache audio loading (slow I/O)
    - Cache final features (expensive computation)
    - Don't cache intermediate cheap operations
    """
    
    dataset = Dataset(data_dir="./data")
    
    # Audio loading is cached automatically (slow I/O)
    audio_frame = dataset.load_audio("./data/raw/audio.wav")
    
    # Create optimized pipeline for training
    # Only cache the final mel spectrogram features
    training_pipeline = (
        resample(16000, orig_sample_rate=audio_frame.sample_rate).no_cache()
        | normalize(target_db=-20.0).no_cache()
        | trim_silence(threshold=0.01).no_cache()
        | log_mel_spectrogram(
            sample_rate=16000,
            n_mels=80,
            n_fft=2048,
            hop_length=512,
        ).cache()  # Cache final features
    )
    
    # Precompute features (only final result is cached)
    features = dataset.apply(training_pipeline, audio_frame.data)
    
    print("Training workflow: Only final features cached")
    print(f"Features shape: {features.shape}")
    
    return features


if __name__ == "__main__":
    print("=" * 60)
    print("Cache Optimization Examples")
    print("=" * 60)
    
    print("\n1. Optimized caching (recommended for training):")
    example_cache_optimization()
    
    print("\n2. Cache everything (default):")
    example_cache_everything()
    
    print("\n3. Cache nothing (debugging):")
    example_cache_nothing()
    
    print("\n4. Selective caching:")
    example_selective_caching()
    
    print("\n5. Training workflow:")
    example_training_workflow()

