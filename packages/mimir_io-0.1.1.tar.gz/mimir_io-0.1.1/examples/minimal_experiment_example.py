"""
Minimal experiment example with mimir_io.

Demonstrates how to minimize boilerplate when creating experiments.
"""

import torch.nn as nn
from pathlib import Path

from mimir_io.experiment import quick_train, ExperimentConfig, setup_experiment


# ========== Example 1: Minimal code (3 lines!) ==========

def minimal_example():
    """
    Simplest way to start training.
    
    Only 3 lines of code for a complete experiment!
    """
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]  # Your labels
    
    # Start training (everything else is automatic!)
    trainer = quick_train(model=model, file_paths=files, labels=labels)
    
    return trainer


# ========== Example 2: With custom configuration ==========

def custom_config_example():
    """
    Example with parameter configuration.
    """
    # Create configuration
    config = ExperimentConfig(
        batch_size=64,           # Larger batch
        epochs=20,                # More epochs
        learning_rate=0.0001,     # Different learning rate
        n_mels=128,               # More mel bins
        use_augmentation=True,    # Enable augmentations
    )
    
    model = nn.Sequential(
        nn.Linear(config.n_mels, 256),
        nn.ReLU(),
        nn.Linear(256, 10),
    )
    
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Start with configuration
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        config=config,
        precompute_cache=True,  # Precompute cache
    )
    
    return trainer


# ========== Example 3: More flexible control ==========

def flexible_example():
    """
    Example with more flexible control over the process.
    """
    from mimir_io.experiment import BaseTrainer
    
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Setup experiment (get DataLoaders and configuration)
    train_loader, val_loader, test_loader, dataset, config = setup_experiment(
        file_paths=files,
        labels=labels,
        split_path="./data/split.json",  # Save split
        precompute_cache=True,
    )
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create trainer
    trainer = BaseTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
    )
    
    # Can add custom logic:
    # - Learning rate scheduler
    # - Early stopping
    # - Custom callbacks
    # - Wandb/TensorBoard logging
    # etc.
    
    # Start training
    trainer.train()
    
    return trainer


# ========== Comparison: Old vs New approach ==========

def comparison():
    """
    Comparison of code amount between old and new approach.
    
    OLD APPROACH (training_example.py):
    - ~150 lines of code for data preparation
    - ~60 lines for training loop
    - Total: ~210 lines
    
    NEW APPROACH (this file):
    - 3 lines for minimal example
    - ~15 lines for custom configuration
    - Total: ~20 lines (10x less!)
    """
    pass


if __name__ == "__main__":
    # Choose one of the examples:
    
    # 1. Minimal (3 lines!)
    minimal_example()
    
    # 2. With configuration
    # custom_config_example()
    
    # 3. Flexible control
    # flexible_example()
