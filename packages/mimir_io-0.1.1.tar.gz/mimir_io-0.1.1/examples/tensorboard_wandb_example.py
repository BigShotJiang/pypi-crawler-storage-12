"""
Example usage of TensorBoard and WandB callbacks in mimir_io.

Demonstrates how to use TensorBoardCallback and WandBCallback for
real-time experiment tracking and visualization.
"""

import torch.nn as nn
from pathlib import Path

from mimir_io.experiment import quick_train, ExperimentConfig
from mimir_io.models import (
    TensorBoardCallback,
    WandBCallback,
    CSVLoggerCallback,
    EarlyStoppingCallback,
)


def example1_tensorboard_only():
    """Example 1: Using TensorBoard callback only."""
    print("=" * 60)
    print("Example 1: TensorBoard Callback")
    print("=" * 60)
    
    # Create a simple model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create configuration
    config = ExperimentConfig(
        epochs=10,
        learning_rate=0.001,
        batch_size=32,
    )
    
    # Setup TensorBoard callback
    callbacks = [
        TensorBoardCallback(
            log_dir="./logs/tensorboard",
            write_graph=True,  # Save model graph
        ),
    ]
    
    # Example usage (requires real data)
    # files = list(Path("./data/raw").glob("*.wav"))
    # labels = [0, 1, 0, 1, ...]
    # trainer = quick_train(
    #     model=model,
    #     file_paths=files,
    #     labels=labels,
    #     config=config,
    #     callbacks=callbacks,
    # )
    
    print("TensorBoard callback configured!")
    print("After training, run: tensorboard --logdir=./logs/tensorboard")
    print("Then open http://localhost:6006 in your browser")


def example2_wandb_only():
    """Example 2: Using WandB callback only."""
    print("=" * 60)
    print("Example 2: WandB Callback")
    print("=" * 60)
    
    # Create a simple model
    model = nn.Sequential(
        nn.Linear(80, 256),
        nn.ReLU(),
        nn.Linear(256, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create configuration
    config = ExperimentConfig(
        epochs=20,
        learning_rate=0.001,
        batch_size=64,
    )
    
    # Setup WandB callback
    callbacks = [
        WandBCallback(
            project="audio_classification",
            name="baseline_experiment",
            config={
                "model": "SimpleMLP",
                "batch_size": config.batch_size,
                "learning_rate": config.learning_rate,
                "epochs": config.epochs,
            },
            tags=["baseline", "mlp"],
            save_code=True,
        ),
    ]
    
    # Example usage (requires real data)
    # files = list(Path("./data/raw").glob("*.wav"))
    # labels = [0, 1, 0, 1, ...]
    # trainer = quick_train(
    #     model=model,
    #     file_paths=files,
    #     labels=labels,
    #     config=config,
    #     callbacks=callbacks,
    # )
    
    print("WandB callback configured!")
    print("Results will be synced to https://wandb.ai")


def example3_both_loggers():
    """Example 3: Using both TensorBoard and WandB."""
    print("=" * 60)
    print("Example 3: TensorBoard + WandB")
    print("=" * 60)
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create configuration
    config = ExperimentConfig(
        epochs=15,
        learning_rate=0.001,
        batch_size=32,
    )
    
    # Setup both callbacks
    callbacks = [
        TensorBoardCallback(
            log_dir="./logs/tensorboard",
            write_graph=True,
        ),
        WandBCallback(
            project="audio_classification",
            name="experiment_with_both_loggers",
            config={
                "batch_size": config.batch_size,
                "learning_rate": config.learning_rate,
            },
            tags=["comparison"],
        ),
    ]
    
    # Example usage (requires real data)
    # files = list(Path("./data/raw").glob("*.wav"))
    # labels = [0, 1, 0, 1, ...]
    # trainer = quick_train(
    #     model=model,
    #     file_paths=files,
    #     labels=labels,
    #     config=config,
    #     callbacks=callbacks,
    # )
    
    print("Both TensorBoard and WandB callbacks configured!")
    print("TensorBoard: tensorboard --logdir=./logs/tensorboard")
    print("WandB: Check https://wandb.ai")


def example4_all_callbacks():
    """Example 4: Using all available callbacks together."""
    print("=" * 60)
    print("Example 4: All Callbacks Combined")
    print("=" * 60)
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create configuration
    config = ExperimentConfig(
        epochs=20,
        learning_rate=0.001,
        batch_size=32,
        early_stopping={
            "enabled": True,
            "monitor": "val_loss",
            "patience": 5,
        },
    )
    
    # Setup all callbacks
    callbacks = [
        # TensorBoard for local visualization
        TensorBoardCallback(
            log_dir="./logs/tensorboard",
            write_graph=True,
        ),
        # WandB for cloud tracking
        WandBCallback(
            project="audio_classification",
            name="full_experiment",
            config={
                "batch_size": config.batch_size,
                "learning_rate": config.learning_rate,
            },
            tags=["full", "all_callbacks"],
        ),
        # CSV for local analysis
        CSVLoggerCallback(
            log_dir="./logs/csv",
            format="both",  # CSV and JSON
        ),
        # Early stopping
        EarlyStoppingCallback(
            monitor="val_loss",
            patience=5,
        ),
    ]
    
    # Example usage (requires real data)
    # files = list(Path("./data/raw").glob("*.wav"))
    # labels = [0, 1, 0, 1, ...]
    # trainer = quick_train(
    #     model=model,
    #     file_paths=files,
    #     labels=labels,
    #     config=config,
    #     callbacks=callbacks,
    # )
    
    print("All callbacks configured!")
    print("- TensorBoard: Local visualization")
    print("- WandB: Cloud tracking")
    print("- CSV: Local analysis")
    print("- Early Stopping: Automatic stopping")


def example5_advanced_wandb():
    """Example 5: Advanced WandB configuration."""
    print("=" * 60)
    print("Example 5: Advanced WandB Configuration")
    print("=" * 60)
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 256),
        nn.ReLU(),
        nn.Dropout(0.2),
        nn.Linear(256, 128),
        nn.ReLU(),
        nn.Dropout(0.2),
        nn.Linear(128, 10),
    )
    
    # Create configuration with scheduler
    config = ExperimentConfig(
        epochs=30,
        learning_rate=0.001,
        batch_size=64,
        scheduler={
            "enabled": True,
            "type": "ReduceLROnPlateau",
            "monitor": "val_loss",
            "factor": 0.5,
            "patience": 3,
        },
    )
    
    # Advanced WandB configuration
    callbacks = [
        WandBCallback(
            project="audio_classification",
            name="advanced_experiment_with_scheduler",
            config={
                "model": "MLP_with_dropout",
                "batch_size": config.batch_size,
                "learning_rate": config.learning_rate,
                "epochs": config.epochs,
                "scheduler": "ReduceLROnPlateau",
                "scheduler_factor": 0.5,
                "scheduler_patience": 3,
            },
            tags=["advanced", "scheduler", "dropout"],
            save_code=True,
            log_every_n_epochs=1,
            log_every_n_batches=50,  # Log every 50 batches
        ),
    ]
    
    # Example usage (requires real data)
    # files = list(Path("./data/raw").glob("*.wav"))
    # labels = [0, 1, 0, 1, ...]
    # trainer = quick_train(
    #     model=model,
    #     file_paths=files,
    #     labels=labels,
    #     config=config,
    #     callbacks=callbacks,
    # )
    
    print("Advanced WandB configuration!")
    print("- Batch-level logging enabled")
    print("- Full hyperparameter tracking")
    print("- Code saving enabled")


if __name__ == "__main__":
    print("\nTensorBoard and WandB Integration Examples\n")
    
    example1_tensorboard_only()
    print()
    
    example2_wandb_only()
    print()
    
    example3_both_loggers()
    print()
    
    example4_all_callbacks()
    print()
    
    example5_advanced_wandb()
    print()
    
    print("=" * 60)
    print("Note: These examples require:")
    print("  - pip install tensorboard  # For TensorBoard")
    print("  - pip install wandb        # For WandB")
    print("  - wandb login              # First time only for WandB")
    print("=" * 60)

