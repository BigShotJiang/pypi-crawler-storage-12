"""
Example of using mimir_io for training neural networks.

Demonstrates complete workflow from data loading to model training.
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from pathlib import Path

from mimir_io import Dataset, split_dataset, split_by_directory
from mimir_io.audio import resample, log_mel_spectrogram
from mimir_io.audio.augment import (
    time_shift,
    gain_variation,
    add_noise,
    compose_augmentations,
)
from mimir_io.rayframe.audio import augment_audio_frame
from mimir_io.torch_dataset import MimirTorchDataset, create_dataloader


# ========== 1. Data Preparation ==========

def prepare_datasets():
    """Prepare datasets for training and validation."""
    
    # Initialize mimir_io Dataset
    mimir_dataset = Dataset(data_dir="./data")
    
    # Create processing pipeline (resample + mel spectrogram)
    # Use .no_cache() on cheap operations to save disk space
    # Only cache the final mel spectrogram which is expensive to compute
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100).no_cache()  # Cheap, don't cache
        | log_mel_spectrogram(
            sample_rate=16000,
            n_mels=80,
            n_fft=2048,
            hop_length=512,
        ).cache()  # Expensive, cache this
    )
    
    # Create augmentation pipeline for training
    aug_pipeline = augment_audio_frame(
        time_shift_max=1600,  # ±100ms at 16kHz
        gain_range=(0.7, 1.3),
        noise_snr=20.0,
        speed_range=(0.9, 1.1),
    )
    
    # ===== Option 1: Split from a single list of files =====
    # If you have all files in one directory
    all_files = list(Path("./data/raw").glob("*.wav"))
    all_labels = [0, 1, 0, 1, ...]  # Labels for each file
    
    # Split into train/val/test
    split = split_dataset(
        file_paths=all_files,
        labels=all_labels,
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15,
        stratify=True,  # Maintain label distribution
        seed=42,  # For reproducibility
    )
    
    # Save split for later use
    split.save("./data/split.json")
    
    # Use split files
    train_files = split.train_files
    val_files = split.val_files
    test_files = split.test_files
    train_labels = split.train_labels
    val_labels = split.val_labels
    test_labels = split.test_labels
    
    # ===== Option 2: Load existing split =====
    # split = DatasetSplit.load("./data/split.json")
    
    # ===== Option 3: Split by directory structure =====
    # If data is already organized in train/val/test directories:
    # split = split_by_directory(
    #     data_dir="./data",
    #     train_dir="train",
    #     val_dir="val",
    #     test_dir="test",
    #     extensions=[".wav", ".mp3"],
    # )
    
    # Optional: Precompute cache for all files in parallel before training
    # This speeds up training significantly by computing expensive transformations
    # (like mel spectrograms) in parallel using multiprocessing
    # Uncomment the following lines to enable parallel precomputation:
    #
    # print("Precomputing cache for training data (parallel)...")
    # mimir_dataset.precompute_batch(
    #     mel_pipeline,
    #     train_files,
    #     num_workers=8,  # Use 8 worker processes (adjust based on your CPU)
    #     show_progress=True,
    #     desc="Precomputing training cache"
    # )
    #
    # print("Precomputing cache for validation data (parallel)...")
    # mimir_dataset.precompute_batch(
    #     mel_pipeline,
    #     val_files,
    #     num_workers=8,
    #     show_progress=True,
    #     desc="Precomputing validation cache"
    # )
    
    # Create PyTorch datasets
    train_dataset = MimirTorchDataset(
        mimir_dataset=mimir_dataset,
        file_paths=train_files,
        transform_pipeline=mel_pipeline,
        labels=train_labels,
        use_augmentation=True,  # Augmentations only for training
        augmentation_pipeline=aug_pipeline,
    )
    
    val_dataset = MimirTorchDataset(
        mimir_dataset=mimir_dataset,
        file_paths=val_files,
        transform_pipeline=mel_pipeline,
        labels=val_labels,
        use_augmentation=False,  # No augmentations for validation
    )
    
    # Optional: Create test dataset
    test_dataset = None
    if test_files:
        test_dataset = MimirTorchDataset(
            mimir_dataset=mimir_dataset,
            file_paths=test_files,
            transform_pipeline=mel_pipeline,
            labels=test_labels,
            use_augmentation=False,
        )
    
    return train_dataset, val_dataset, test_dataset


# ========== 2. Create DataLoader ==========

def create_dataloaders(train_dataset, val_dataset):
    """Create DataLoaders for training and validation."""
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=32,
        shuffle=True,
        num_workers=4,  # Parallel loading
        pin_memory=True,  # Faster transfer to GPU
        persistent_workers=True,  # Keep workers between epochs
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=32,
        shuffle=False,
        num_workers=4,
        pin_memory=True,
    )
    
    return train_loader, val_loader


# ========== 3. Alternative Method (Convenience Function) ==========

def create_dataloaders_simple():
    """Create DataLoader using convenience function."""
    
    mimir_dataset = Dataset(data_dir="./data")
    
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
    )
    
    aug_pipeline = augment_audio_frame(
        time_shift_max=1600,
        gain_range=(0.7, 1.3),
    )
    
    train_files = ["./data/raw/train/audio1.wav", ...]
    train_labels = [0, 1, ...]
    
    # Use convenience function
    train_loader = create_dataloader(
        mimir_dataset=mimir_dataset,
        file_paths=train_files,
        transform_pipeline=mel_pipeline,
        labels=train_labels,
        batch_size=32,
        shuffle=True,
        num_workers=4,
        use_augmentation=True,
        augmentation_pipeline=aug_pipeline,
    )
    
    return train_loader


# ========== 4. Simple Model Example ==========

class SimpleAudioClassifier(nn.Module):
    """Simple model for audio classification."""
    
    def __init__(self, n_mels=80, n_classes=10):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(64, n_classes)
    
    def forward(self, x):
        # x shape: (batch, n_mels, time_frames)
        # Add channel dimension
        x = x.unsqueeze(1)  # (batch, 1, n_mels, time_frames)
        
        x = torch.relu(self.conv1(x))
        x = torch.relu(self.conv2(x))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x


# ========== 5. Training ==========

def train_model():
    """Complete training loop."""
    
    # Data preparation
    train_dataset, val_dataset, test_dataset = prepare_datasets()
    train_loader, val_loader = create_dataloaders(train_dataset, val_dataset)
    
    # Create model
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = SimpleAudioClassifier(n_mels=80, n_classes=10).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    
    # Training
    num_epochs = 10
    for epoch in range(num_epochs):
        # Training
        model.train()
        train_loss = 0.0
        for batch_idx, (features, labels) in enumerate(train_loader):
            features = features.to(device)
            labels = labels.to(device)
            
            # Forward pass
            outputs = model(features)
            loss = criterion(outputs, labels)
            
            # Backward pass
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
            
            if batch_idx % 100 == 0:
                print(f"Epoch {epoch}, Batch {batch_idx}, Loss: {loss.item():.4f}")
        
        # Validation
        model.eval()
        val_loss = 0.0
        correct = 0
        total = 0
        
        with torch.no_grad():
            for features, labels in val_loader:
                features = features.to(device)
                labels = labels.to(device)
                
                outputs = model(features)
                loss = criterion(outputs, labels)
                val_loss += loss.item()
                
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
        
        print(f"Epoch {epoch}:")
        print(f"  Train Loss: {train_loss / len(train_loader):.4f}")
        print(f"  Val Loss: {val_loss / len(val_loader):.4f}")
        print(f"  Val Accuracy: {100 * correct / total:.2f}%")


# ========== 6. Benefits of Using mimir_io ==========

def benefits_explanation():
    """
    Explanation of benefits of using mimir_io for training.
    
    1. Automatic caching:
       - First epoch computes transformations and caches
       - Subsequent epochs load from cache (10-100x faster)
       - When changing hyperparameters, only recomputes changed parts
    
    2. GPU-accelerated augmentations:
       - All augmentations work on GPU
       - No need to pre-generate augmented data
       - Can perform different augmentations on each epoch
    
    3. Compressed cache:
       - WAV for audio (~2x smaller than pickle)
       - PNG for spectrograms (10-100x smaller than pickle)
       - Faster loading through smaller files
    
    4. Declarative pipelines:
       - Easy to experiment with different combinations
       - Clean, readable code
       - Easy to maintain and modify
    
    5. Support for various formats:
       - Automatic format detection (WAV, MP3, FLAC, M4A, etc.)
       - No need to convert data in advance
    """
    pass


# ========== 7. Simplified Experiment Setup (NEW!) ==========

def train_model_simplified():
    """
    Maximally simplified training example with minimal boilerplate.
    
    Uses the new experiment module to automate the entire process.
    """
    from mimir_io.experiment import quick_train, ExperimentConfig
    from pathlib import Path
    
    # 1. Prepare data
    all_files = list(Path("./data/raw").glob("*.wav"))
    all_labels = [0, 1, 0, 1, ...]  # Your labels
    
    # 2. Create model
    model = SimpleAudioClassifier(n_mels=80, n_classes=10)
    
    # 3. Start training (everything else is automatic!)
    trainer = quick_train(
        model=model,
        file_paths=all_files,
        labels=all_labels,
    )
    
    return trainer


def train_model_with_config():
    """
    Example with custom configuration.
    """
    from mimir_io.experiment import quick_train, ExperimentConfig
    from pathlib import Path
    
    # Create custom configuration
    config = ExperimentConfig(
        batch_size=64,
        epochs=20,
        learning_rate=0.0001,
        n_mels=128,
        use_augmentation=True,
        augmentation_config={
            "time_shift_max": 2000,
            "gain_range": (0.8, 1.2),
        },
    )
    
    # Prepare data
    all_files = list(Path("./data/raw").glob("*.wav"))
    all_labels = [0, 1, 0, 1, ...]
    
    # Create model
    model = SimpleAudioClassifier(n_mels=config.n_mels, n_classes=10)
    
    # Start training
    trainer = quick_train(
        model=model,
        file_paths=all_files,
        labels=all_labels,
        config=config,
        precompute_cache=True,  # Precompute cache
    )
    
    return trainer


def train_model_with_callbacks():
    """
    Example with callbacks: early stopping and image metrics.
    """
    from mimir_io.experiment import quick_train, ExperimentConfig
    from mimir_io.models import EarlyStoppingCallback, ImageMetricsCallback
    from pathlib import Path
    
    # Create configuration with early stopping
    config = ExperimentConfig(
        epochs=100,  # Maximum number of epochs
        early_stopping={
            "enabled": True,
            "monitor": "val_loss",
            "patience": 5,
            "min_delta": 0.001,
            "mode": "min",
            "restore_best_weights": True,
        },
    )
    
    # Create callbacks
    image_metrics = ImageMetricsCallback(
        save_dir="./metrics_images",
        save_loss_plot=True,
        save_confusion_matrix=True,
        save_sample_predictions=True,
        num_samples=8,
        save_every_n_epochs=1,
    )
    
    # Prepare data
    all_files = list(Path("./data/raw").glob("*.wav"))
    all_labels = [0, 1, 0, 1, ...]
    
    # Create model
    model = SimpleAudioClassifier(n_mels=80, n_classes=10)
    
    # Start training with callbacks
    trainer = quick_train(
        model=model,
        file_paths=all_files,
        labels=all_labels,
        config=config,
        callbacks=[image_metrics],  # Early stopping already in config
    )
    
    return trainer


def setup_experiment_example():
    """
    Example of using setup_experiment for more flexible control.
    """
    from mimir_io.experiment import setup_experiment, BaseTrainer
    from pathlib import Path
    
    # Prepare data
    all_files = list(Path("./data/raw").glob("*.wav"))
    all_labels = [0, 1, 0, 1, ...]
    
    # Setup experiment (creates DataLoaders and configuration)
    train_loader, val_loader, test_loader, dataset, config = setup_experiment(
        file_paths=all_files,
        labels=all_labels,
        split_path="./data/split.json",  # Save split for reuse
        precompute_cache=True,
    )
    
    # Create model
    model = SimpleAudioClassifier(n_mels=80, n_classes=10)
    
    # Create trainer manually for more control
    trainer = BaseTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
    )
    
    # Can add custom logic before training
    # for example, learning rate scheduler, early stopping, etc.
    
    # Start training
    trainer.train()
    
    return trainer


if __name__ == "__main__":
    # Variant 1: Standard way (lots of code)
    # train_model()
    
    # Variant 2: Simplified way (minimal boilerplate!)
    # train_model_simplified()
    
    # Variant 3: With custom configuration
    # train_model_with_config()
    
    # Variant 4: More flexible control
    # setup_experiment_example()
    
    # Variant 5: With callbacks (early stopping and image metrics)
    # train_model_with_callbacks()
