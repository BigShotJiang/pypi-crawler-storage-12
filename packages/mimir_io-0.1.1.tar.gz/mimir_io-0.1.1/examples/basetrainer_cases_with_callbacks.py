"""
Additional examples showing callbacks usage with BaseTrainer.

Demonstrates:
- Early stopping via callbacks
- ImageMetricsCallback usage
- Combining multiple callbacks
"""

import torch
import torch.nn as nn
from pathlib import Path

from mimir_io.models import BaseTrainer, EarlyStoppingCallback, ImageMetricsCallback
from mimir_io.experiment import quick_train, setup_experiment, ExperimentConfig


# ========== CASE 11: BaseTrainer with Early Stopping Callback ==========

def case11_early_stopping_callback():
    """
    Using BaseTrainer with EarlyStoppingCallback.
    
    Use when:
    - You want early stopping without modifying config
    - You need fine-grained control over early stopping parameters
    """
    from mimir_io import Dataset, split_dataset
    from mimir_io.audio import resample, log_mel_spectrogram
    from mimir_io.torch_dataset import create_dataloader
    
    # Prepare data
    mimir_dataset = Dataset(data_dir="./data")
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100).no_cache()
        | log_mel_spectrogram(sample_rate=16000, n_mels=80).cache()
    )
    
    train_files = list(Path("./data/raw").glob("*.wav"))
    train_labels = [0, 1, 0, 1, ...]
    
    train_loader = create_dataloader(
        mimir_dataset=mimir_dataset,
        file_paths=train_files,
        transform_pipeline=mel_pipeline,
        labels=train_labels,
        batch_size=32,
        shuffle=True,
    )
    
    val_loader = create_dataloader(
        mimir_dataset=mimir_dataset,
        file_paths=train_files[:10],  # Example
        transform_pipeline=mel_pipeline,
        labels=train_labels[:10],
        batch_size=32,
        shuffle=False,
    )
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create early stopping callback
    early_stopping = EarlyStoppingCallback(
        monitor="val_loss",
        patience=5,
        min_delta=0.001,
        mode="min",
        restore_best_weights=True,
    )
    
    # Training configuration
    config = {
        "training": {
            "epochs": 100,  # Max epochs (will stop early if needed)
            "save_dir": "./checkpoints",
            "optimizer": {
                "type": "Adam",
                "lr": 0.001,
            },
            "criterion": {
                "type": "CrossEntropyLoss",
            },
        }
    }
    
    # Create trainer with callback
    trainer = BaseTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
        callbacks=[early_stopping],
    )
    
    # Start training
    trainer.train()
    
    return trainer


# ========== CASE 12: BaseTrainer with ImageMetricsCallback ==========

def case12_image_metrics_callback():
    """
    Using BaseTrainer with ImageMetricsCallback.
    
    Use when:
    - You want to visualize training progress
    - You need confusion matrices and prediction samples
    - You want to track metrics visually
    """
    from mimir_io import Dataset
    from mimir_io.audio import resample, log_mel_spectrogram
    from mimir_io.torch_dataset import create_dataloader
    
    # Prepare data
    mimir_dataset = Dataset(data_dir="./data")
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100).no_cache()
        | log_mel_spectrogram(sample_rate=16000, n_mels=80).cache()
    )
    
    train_files = list(Path("./data/raw").glob("*.wav"))
    train_labels = [0, 1, 0, 1, ...]
    
    train_loader = create_dataloader(
        mimir_dataset=mimir_dataset,
        file_paths=train_files,
        transform_pipeline=mel_pipeline,
        labels=train_labels,
        batch_size=32,
        shuffle=True,
    )
    
    val_loader = create_dataloader(
        mimir_dataset=mimir_dataset,
        file_paths=train_files[:10],
        transform_pipeline=mel_pipeline,
        labels=train_labels[:10],
        batch_size=32,
        shuffle=False,
    )
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create image metrics callback
    image_metrics = ImageMetricsCallback(
        save_dir="./metrics_images",
        save_loss_plot=True,
        save_confusion_matrix=True,
        save_sample_predictions=True,
        num_samples=8,
        save_every_n_epochs=1,
    )
    
    # Training configuration
    config = {
        "training": {
            "epochs": 10,
            "save_dir": "./checkpoints",
            "optimizer": {"type": "Adam", "lr": 0.001},
            "criterion": {"type": "CrossEntropyLoss"},
        }
    }
    
    # Create trainer with callback
    trainer = BaseTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
        callbacks=[image_metrics],
    )
    
    # Start training
    trainer.train()
    
    return trainer


# ========== CASE 13: Combined Callbacks ==========

def case13_combined_callbacks():
    """
    Using multiple callbacks together.
    
    Use when:
    - You want both early stopping and image metrics
    - You need multiple monitoring strategies
    """
    from mimir_io import Dataset
    from mimir_io.audio import resample, log_mel_spectrogram
    from mimir_io.torch_dataset import create_dataloader
    
    # Prepare data
    mimir_dataset = Dataset(data_dir="./data")
    mel_pipeline = (
        resample(16000, orig_sample_rate=44100).no_cache()
        | log_mel_spectrogram(sample_rate=16000, n_mels=80).cache()
    )
    
    train_files = list(Path("./data/raw").glob("*.wav"))
    train_labels = [0, 1, 0, 1, ...]
    
    train_loader = create_dataloader(
        mimir_dataset=mimir_dataset,
        file_paths=train_files,
        transform_pipeline=mel_pipeline,
        labels=train_labels,
        batch_size=32,
        shuffle=True,
    )
    
    val_loader = create_dataloader(
        mimir_dataset=mimir_dataset,
        file_paths=train_files[:10],
        transform_pipeline=mel_pipeline,
        labels=train_labels[:10],
        batch_size=32,
        shuffle=False,
    )
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Create multiple callbacks
    early_stopping = EarlyStoppingCallback(
        monitor="val_loss",
        patience=5,
        min_delta=0.001,
    )
    
    image_metrics = ImageMetricsCallback(
        save_dir="./metrics_images",
        save_every_n_epochs=2,  # Save every 2 epochs
    )
    
    # Training configuration
    config = {
        "training": {
            "epochs": 100,
            "save_dir": "./checkpoints",
            "optimizer": {"type": "Adam", "lr": 0.001},
            "criterion": {"type": "CrossEntropyLoss"},
        }
    }
    
    # Create trainer with multiple callbacks
    trainer = BaseTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
        callbacks=[early_stopping, image_metrics],
    )
    
    # Start training
    trainer.train()
    
    return trainer


# ========== CASE 14: Early Stopping via Config ==========

def case14_early_stopping_config():
    """
    Using early stopping via ExperimentConfig.
    
    Use when:
    - You want to configure early stopping in config
    - You're using quick_train or setup_experiment
    """
    # Create configuration with early stopping
    config = ExperimentConfig(
        epochs=100,
        early_stopping={
            "enabled": True,
            "monitor": "val_loss",
            "patience": 5,
            "min_delta": 0.001,
            "mode": "min",
            "restore_best_weights": True,
        },
    )
    
    # Create model
    model = nn.Sequential(
        nn.Linear(80, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    )
    
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, ...]
    
    # Start training (early stopping is automatically configured)
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        config=config,
    )
    
    return trainer


if __name__ == "__main__":
    print("Additional examples with callbacks:")
    print("11. BaseTrainer with EarlyStoppingCallback")
    print("12. BaseTrainer with ImageMetricsCallback")
    print("13. Combined callbacks")
    print("14. Early stopping via ExperimentConfig")
    print("\nRun the desired function to test.")

