"""
Example of multi-GPU training with mimir_io.

This example shows how to train models on multiple GPUs using DDP (Distributed Data Parallel).
Multi-GPU training is handled automatically - no need for torchrun!
"""

from pathlib import Path
import torch
import torch.nn as nn
from mimir_io.experiment import quick_train, ExperimentConfig
from mimir_io.models.distributed import get_ddp_config


def create_model(n_mels: int = 80, n_classes: int = 10) -> nn.Module:
    """Create a simple audio classification model."""
    return nn.Sequential(
        nn.Conv2d(1, 32, kernel_size=3, padding=1),
        nn.ReLU(),
        nn.MaxPool2d(2),
        nn.Conv2d(32, 64, kernel_size=3, padding=1),
        nn.ReLU(),
        nn.MaxPool2d(2),
        nn.AdaptiveAvgPool2d(1),
        nn.Flatten(),
        nn.Linear(64, n_classes),
    )


def main():
    """
    Main training function.
    
    Multi-GPU training is handled automatically - just enable it in config!
    No need for torchrun or manual process management.
    """
    # Prepare data
    files = list(Path("./data/raw").glob("*.wav"))
    labels = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1] * (len(files) // 10 + 1)
    labels = labels[:len(files)]
    
    # Create model
    model = create_model(n_mels=80, n_classes=2)
    
    # Configure distributed training
    # Option 1: Auto-detect number of GPUs (recommended)
    ddp_config = get_ddp_config()
    
    # Option 2: Specify number of GPUs manually
    # ddp_config = get_ddp_config(num_gpus=4)
    
    # Option 3: Full configuration
    # ddp_config = {
    #     "enabled": True,
    #     "num_gpus": 4,
    #     "backend": "nccl",
    #     "find_unused_parameters": False,
    # }
    
    # Create experiment configuration with distributed training
    config = ExperimentConfig(
        batch_size=32,
        epochs=10,
        learning_rate=0.001,
        n_mels=80,
        distributed=ddp_config,  # Enable multi-GPU training
    )
    
    # Start training - multi-GPU is handled automatically!
    # If multiple GPUs are available, processes will be spawned automatically
    trainer = quick_train(
        model=model,
        file_paths=files,
        labels=labels,
        config=config,
    )
    
    print("Training completed!")
    print(f"Best model saved to: {trainer.save_dir / 'best_model.pt'}")


def manual_launch_example():
    """
    Example of manually launching distributed training.
    
    Useful if you need more control over the launch process.
    """
    from mimir_io.models.distributed import launch_distributed
    
    def train():
        """Training function that will run on each GPU."""
        files = list(Path("./data/raw").glob("*.wav"))
        labels = [0, 1] * (len(files) // 2)
        
        model = create_model(n_mels=80, n_classes=2)
        
        ddp_config = get_ddp_config()
        config = ExperimentConfig(
            batch_size=32,
            epochs=10,
            distributed=ddp_config,
        )
        
        trainer = quick_train(
            model=model,
            file_paths=files,
            labels=labels,
            config=config,
        )
        return trainer
    
    # Manually launch distributed training
    launch_distributed(train, num_gpus=4)


if __name__ == "__main__":
    # Just run normally - multi-GPU is handled automatically!
    # python multi_gpu_example.py
    
    # If you have multiple GPUs, they will be used automatically.
    # If you have 1 GPU or CPU, it will run normally.
    
    main()

