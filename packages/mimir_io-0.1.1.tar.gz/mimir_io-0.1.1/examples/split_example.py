"""
Examples of dataset splitting strategies with mimir_io.

Demonstrates different ways to split datasets into train/validation/test sets.
"""

from pathlib import Path
from mimir_io import split_dataset, split_by_directory, split_by_metadata, DatasetSplit


# ========== Example 1: Simple Random Split ==========

def example_random_split():
    """Simple random split without stratification."""
    
    # Get all audio files
    all_files = list(Path("./data/raw").glob("*.wav"))
    
    # Split randomly
    split = split_dataset(
        file_paths=all_files,
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15,
        seed=42,  # For reproducibility
    )
    
    print(f"Train: {len(split.train_files)} files")
    print(f"Val: {len(split.val_files)} files")
    print(f"Test: {len(split.test_files)} files")
    
    # Save split configuration
    split.save("./data/split.json")
    
    return split


# ========== Example 2: Stratified Split ==========

def example_stratified_split():
    """Stratified split maintaining label distribution."""
    
    # Get files and labels
    all_files = list(Path("./data/raw").glob("*.wav"))
    all_labels = [0, 1, 0, 1, 2, 0, ...]  # Your labels
    
    # Split with stratification
    split = split_dataset(
        file_paths=all_files,
        labels=all_labels,
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15,
        stratify=True,  # Maintain label distribution
        seed=42,
    )
    
    print(f"Train: {len(split.train_files)} files")
    print(f"Val: {len(split.val_files)} files")
    print(f"Test: {len(split.test_files)} files")
    
    # Check label distribution
    from collections import Counter
    print(f"Train labels: {Counter(split.train_labels)}")
    print(f"Val labels: {Counter(split.val_labels)}")
    print(f"Test labels: {Counter(split.test_labels)}")
    
    return split


# ========== Example 3: Split by Directory Structure ==========

def example_directory_split():
    """
    Split based on existing directory structure.
    
    Assumes data is already organized as:
    data/
      train/
        audio1.wav
        audio2.wav
      val/
        audio3.wav
      test/
        audio4.wav
    """
    
    split = split_by_directory(
        data_dir="./data",
        train_dir="train",
        val_dir="val",
        test_dir="test",
        extensions=[".wav", ".mp3"],  # Only include these extensions
    )
    
    print(f"Train: {len(split.train_files)} files")
    print(f"Val: {len(split.val_files)} files")
    print(f"Test: {len(split.test_files)} files")
    
    return split


# ========== Example 4: Split by Metadata ==========

def example_metadata_split():
    """
    Split based on metadata extracted from files.
    
    Useful for:
    - Speaker-based splits (stratify by speaker)
    - Time-based splits (chronological order)
    - Any custom metadata
    """
    
    def get_speaker_metadata(file_path: Path) -> dict:
        """Extract speaker ID from filename."""
        # Example: speaker1_audio1.wav -> speaker: "speaker1"
        parts = file_path.stem.split("_")
        return {"speaker": parts[0]}
    
    all_files = list(Path("./data/raw").glob("*.wav"))
    
    # Split stratifying by speaker
    split = split_by_metadata(
        file_paths=all_files,
        metadata_func=get_speaker_metadata,
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15,
        stratify_by="speaker",  # Maintain speaker distribution
        seed=42,
    )
    
    return split


# ========== Example 5: Load Saved Split ==========

def example_load_split():
    """Load a previously saved split."""
    
    split = DatasetSplit.load("./data/split.json")
    
    print(f"Train: {len(split.train_files)} files")
    print(f"Val: {len(split.val_files)} files")
    print(f"Test: {len(split.test_files)} files")
    print(f"Metadata: {split.metadata}")
    
    return split


# ========== Example 6: Custom Split Ratios ==========

def example_custom_ratios():
    """Custom split ratios (e.g., 80/10/10)."""
    
    all_files = list(Path("./data/raw").glob("*.wav"))
    
    split = split_dataset(
        file_paths=all_files,
        train_ratio=0.8,
        val_ratio=0.1,
        test_ratio=0.1,
        seed=42,
    )
    
    return split


# ========== Example 7: No Test Set ==========

def example_no_test_set():
    """Split without test set (only train/val)."""
    
    all_files = list(Path("./data/raw").glob("*.wav"))
    
    split = split_dataset(
        file_paths=all_files,
        train_ratio=0.8,
        val_ratio=0.2,
        test_ratio=0.0,  # No test set
        seed=42,
    )
    
    print(f"Train: {len(split.train_files)} files")
    print(f"Val: {len(split.val_files)} files")
    print(f"Test: {len(split.test_files)} files")  # Empty
    
    return split


if __name__ == "__main__":
    print("Example 1: Random Split")
    example_random_split()
    
    print("\nExample 2: Stratified Split")
    # example_stratified_split()  # Uncomment if you have labels
    
    print("\nExample 3: Directory-based Split")
    # example_directory_split()  # Uncomment if data is organized
    
    print("\nExample 4: Metadata-based Split")
    # example_metadata_split()  # Uncomment if you have metadata
    
    print("\nExample 5: Load Saved Split")
    # example_load_split()  # Uncomment if split.json exists

