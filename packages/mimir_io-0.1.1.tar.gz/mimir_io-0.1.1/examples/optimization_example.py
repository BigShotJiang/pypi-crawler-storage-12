"""
Приклад використання оптимізації порядку трансформацій.

Демонструє, як автоматично оптимізувати порядок трансформацій у пайплайні
для підвищення швидкості обробки.
"""

import torch
from mimir_io import Dataset
from mimir_io.audio import resample, normalize, trim_silence, log_mel_spectrogram
from mimir_io.audio.augment import spec_augment
from mimir_io.optimization import optimize_pipeline, analyze_pipeline


def example_basic_optimization():
    """Базовий приклад оптимізації пайплайну."""
    print("=== Базовий приклад оптимізації ===\n")
    
    # Створюємо пайплайн з неоптимальним порядком
    # normalize дешевший за resample, тому має йти після resample
    original_pipeline = (
        normalize(target_db=-20.0)
        | resample(16000, orig_sample_rate=44100)
        | trim_silence(threshold=0.01)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
    )
    
    print("Оригінальний пайплайн:")
    print(f"  {original_pipeline._name}\n")
    
    # Аналізуємо пайплайн
    analysis = analyze_pipeline(original_pipeline)
    print("Аналіз пайплайну:")
    print(f"  Кількість трансформацій: {analysis['total_transformations']}")
    print(f"  Розподіл типів: {analysis['type_distribution']}\n")
    
    # Оптимізуємо пайплайн
    optimized_pipeline = optimize_pipeline(original_pipeline)
    
    print("Оптимізований пайплайн:")
    print(f"  {optimized_pipeline._name}\n")
    
    # Порівняння
    print("Порівняння:")
    print("  Оригінал: normalize | resample | trim_silence | log_mel_spectrogram")
    print("  Оптимізовано: resample | normalize | trim_silence | log_mel_spectrogram")
    print("  (resample перед normalize, бо normalize дешевший)\n")


def example_automatic_optimization():
    """Приклад автоматичної оптимізації через Dataset.apply()."""
    print("=== Автоматична оптимізація (за замовчуванням) ===\n")
    
    from mimir_io import Dataset
    
    # Створюємо пайплайн - порядок не важливий
    pipeline = (
        normalize(target_db=-20.0)
        | resample(16000, orig_sample_rate=44100)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
    )
    
    print("Пайплайн (порядок не важливий):")
    print(f"  {pipeline._name}\n")
    
    # Dataset автоматично оптимізує пайплайн при застосуванні
    dataset = Dataset(data_dir="./data")
    
    print("При використанні dataset.apply() пайплайн автоматично оптимізується!")
    print("  (можна вимкнути через auto_optimize=False)\n")
    
    # Для демонстрації показуємо, що оптимізація відбувається
    # (в реальному коді це відбувається автоматично)
    print("Щоб вимкнути автоматичну оптимізацію:")
    print("  result = dataset.apply(pipeline, data, auto_optimize=False)\n")


def example_with_augmentation():
    """Приклад з аугментаціями."""
    print("=== Приклад з аугментаціями ===\n")
    
    # Пайплайн з аугментаціями
    original_pipeline = (
        resample(16000, orig_sample_rate=44100)
        | normalize(target_db=-20.0)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
        | spec_augment(time_mask_param=27, num_time_masks=2)
    )
    
    print("Оригінальний пайплайн:")
    print(f"  {original_pipeline._name}\n")
    
    # Аналізуємо
    analysis = analyze_pipeline(original_pipeline)
    print("Аналіз:")
    for trans in analysis['transformations']:
        print(f"  - {trans['name']}: тип={trans['type']}, витрати={trans['cost']}, кеш={trans['cached']}")
    print()
    
    # Оптимізуємо
    optimized_pipeline = optimize_pipeline(original_pipeline)
    
    print("Оптимізований пайплайн:")
    print(f"  {optimized_pipeline._name}\n")
    
    # Порядок має бути:
    # resample -> normalize -> log_mel_spectrogram -> spec_augment
    # (аугментації спектрограм завжди після генерації спектрограм)


def example_with_profiling():
    """Приклад з профілюванням для точнішої оптимізації."""
    print("=== Приклад з профілюванням ===\n")
    
    # Створюємо тестові дані
    sample_audio = torch.randn(1, 44100)  # 1 секунда аудіо при 44.1kHz
    
    # Пайплайн
    original_pipeline = (
        normalize(target_db=-20.0)
        | resample(16000, orig_sample_rate=44100)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
    )
    
    print("Оригінальний пайплайн:")
    print(f"  {original_pipeline._name}\n")
    
    # Оптимізуємо з профілюванням
    optimized_pipeline = optimize_pipeline(
        original_pipeline,
        sample_data=sample_audio,
        enable_profiling=True,
        target="speed"
    )
    
    print("Оптимізований пайплайн (з профілюванням):")
    print(f"  {optimized_pipeline._name}\n")
    
    print("Профілювання дозволяє виміряти реальні витрати кожної трансформації")
    print("та оптимізувати порядок на основі фактичних даних, а не лише евристики.\n")


def example_analysis_only():
    """Приклад аналізу пайплайну без оптимізації."""
    print("=== Аналіз пайплайну ===\n")
    
    pipeline = (
        resample(16000, orig_sample_rate=44100)
        | normalize(target_db=-20.0)
        | trim_silence(threshold=0.01)
        | log_mel_spectrogram(sample_rate=16000, n_mels=80)
        | spec_augment(time_mask_param=27, num_time_masks=2)
    )
    
    analysis = analyze_pipeline(pipeline)
    
    print("Детальний аналіз пайплайну:")
    print(f"  Загальна кількість трансформацій: {analysis['total_transformations']}")
    print(f"  Розподіл за типами: {analysis['type_distribution']}\n")
    
    print("Деталі трансформацій:")
    for i, trans in enumerate(analysis['transformations'], 1):
        print(f"  {i}. {trans['name']}")
        print(f"     Тип: {trans['type']}")
        print(f"     Витрати: {trans['cost']} ({'дешево' if trans['cost'] <= 2 else 'середньо' if trans['cost'] <= 3 else 'дорого'})")
        print(f"     Кешування: {'так' if trans['cached'] else 'ні'}")
        print()


if __name__ == "__main__":
    example_basic_optimization()
    print("\n" + "="*60 + "\n")
    
    example_automatic_optimization()
    print("\n" + "="*60 + "\n")
    
    example_with_augmentation()
    print("\n" + "="*60 + "\n")
    
    example_analysis_only()
    print("\n" + "="*60 + "\n")
    
    print("Примітка: Приклад з профілюванням потребує реальних даних")
    print("та може бути повільним для демонстрації.\n")

