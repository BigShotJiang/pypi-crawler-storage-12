"""Tests for audio loading lenses with multiple formats."""

import pytest
import torch
import tempfile
from pathlib import Path
import torchaudio

try:
    # Try to use soundfile backend which doesn't require torchcodec
    torchaudio.set_audio_backend("soundfile")
except Exception:
    pass  # Fall back to default backend

from mimir_io.audio.load import load_audio, load_audio_with_sr, SUPPORTED_FORMATS


def _create_test_wav_file(path: Path, sample_rate: int = 16000, duration: float = 1.0):
    """Create a test WAV file."""
    waveform = torch.randn(1, int(sample_rate * duration))
    waveform = torch.clamp(waveform, -1.0, 1.0)
    try:
        torchaudio.save(str(path), waveform, sample_rate)
    except Exception as e:
        pytest.skip(f"Cannot create test audio file: {e}")


def test_load_audio_wav(tmp_path):
    """Test loading WAV file."""
    audio_file = tmp_path / "test.wav"
    _create_test_wav_file(audio_file)
    
    lens = load_audio(audio_file)
    waveform = lens(None)
    
    assert isinstance(waveform, torch.Tensor)
    assert waveform.dim() >= 1
    assert waveform.numel() > 0


def test_load_audio_with_sr_wav(tmp_path):
    """Test loading WAV file with sample rate."""
    audio_file = tmp_path / "test.wav"
    sample_rate = 16000
    _create_test_wav_file(audio_file, sample_rate=sample_rate)
    
    lens = load_audio_with_sr(audio_file)
    waveform, sr = lens(None)
    
    assert isinstance(waveform, torch.Tensor)
    assert sr == sample_rate
    assert waveform.numel() > 0


def test_load_audio_with_backend(tmp_path):
    """Test loading audio with explicit backend."""
    audio_file = tmp_path / "test.wav"
    _create_test_wav_file(audio_file)
    
    # Try with soundfile backend
    try:
        lens = load_audio(audio_file, backend="soundfile")
        waveform = lens(None)
        assert isinstance(waveform, torch.Tensor)
    except Exception:
        # Backend might not be available, skip test
        pytest.skip("soundfile backend not available")


def test_load_audio_file_not_found():
    """Test loading non-existent file raises error."""
    lens = load_audio("nonexistent.wav")
    with pytest.raises(FileNotFoundError):
        lens(None)


def test_load_audio_unsupported_format(tmp_path):
    """Test loading unsupported format raises error."""
    # Create a file with unsupported extension
    audio_file = tmp_path / "test.xyz"
    audio_file.write_text("fake audio content")
    
    lens = load_audio(audio_file)
    with pytest.raises(ValueError, match="Unsupported audio format"):
        lens(None)


def test_supported_formats():
    """Test that SUPPORTED_FORMATS contains expected formats."""
    assert ".wav" in SUPPORTED_FORMATS
    assert ".mp3" in SUPPORTED_FORMATS
    assert ".flac" in SUPPORTED_FORMATS


@pytest.mark.skipif(
    not hasattr(torchaudio, "backend") or "sox" not in str(torchaudio.backend),
    reason="MP3 support requires sox or ffmpeg backend"
)
def test_load_audio_mp3(tmp_path):
    """Test loading MP3 file (if backend supports it)."""
    # This test will be skipped if MP3 backend is not available
    # In real scenario, you would need an actual MP3 file
    pytest.skip("MP3 test requires actual MP3 file and backend support")


@pytest.mark.skipif(
    not hasattr(torchaudio, "backend") or "soundfile" not in str(torchaudio.backend),
    reason="FLAC support requires soundfile backend"
)
def test_load_audio_flac(tmp_path):
    """Test loading FLAC file (if backend supports it)."""
    # This test will be skipped if FLAC backend is not available
    # In real scenario, you would need an actual FLAC file
    pytest.skip("FLAC test requires actual FLAC file and backend support")

