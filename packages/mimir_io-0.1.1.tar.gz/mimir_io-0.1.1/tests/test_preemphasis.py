"""Tests for pre-emphasis filter."""

import pytest
import torch
from mimir_io.audio.preemphasis import preemphasis


def test_preemphasis_basic():
    """Test basic pre-emphasis filter."""
    lens = preemphasis(coeff=0.97)
    waveform = torch.randn(16000)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.shape == waveform.shape


def test_preemphasis_empty():
    """Test pre-emphasis with empty waveform."""
    lens = preemphasis()
    waveform = torch.tensor([])
    result = lens(waveform)
    assert result.numel() == 0


def test_preemphasis_multichannel():
    """Test pre-emphasis with multi-channel audio."""
    lens = preemphasis(coeff=0.95)
    waveform = torch.randn(2, 16000)
    result = lens(waveform)
    assert result.shape == waveform.shape


def test_preemphasis_different_coeffs():
    """Test pre-emphasis with different coefficients."""
    waveform = torch.randn(16000)
    
    for coeff in [0.9, 0.95, 0.97, 0.99]:
        lens = preemphasis(coeff=coeff)
        result = lens(waveform)
        assert result.shape == waveform.shape



