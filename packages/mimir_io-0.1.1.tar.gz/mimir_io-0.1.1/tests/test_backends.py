"""Tests for backend system."""

import pytest
import torch
from mimir_io.backends import get_backend, set_backend, TorchBackend


def test_torch_backend_array():
    """Test creating arrays with torch backend."""
    backend = TorchBackend()
    data = [1, 2, 3, 4, 5]
    tensor = backend.array(data)
    assert isinstance(tensor, torch.Tensor)
    assert torch.equal(tensor, torch.tensor(data))


def test_torch_backend_shape():
    """Test getting shape from torch backend."""
    backend = TorchBackend()
    tensor = torch.tensor([[1, 2], [3, 4]])
    assert backend.shape(tensor) == (2, 2)


def test_torch_backend_dtype():
    """Test getting dtype from torch backend."""
    backend = TorchBackend()
    tensor = torch.tensor([1, 2, 3], dtype=torch.float32)
    assert backend.dtype(tensor) == torch.float32


def test_torch_backend_name():
    """Test backend name."""
    backend = TorchBackend()
    assert backend.name() == "torch"


def test_get_backend_default():
    """Test that get_backend returns torch by default."""
    backend = get_backend()
    assert isinstance(backend, TorchBackend)
    assert backend.name() == "torch"


def test_set_backend():
    """Test setting a custom backend."""
    original = get_backend()
    new_backend = TorchBackend()
    set_backend(new_backend)
    assert get_backend() is new_backend
    set_backend(original)  # Restore

