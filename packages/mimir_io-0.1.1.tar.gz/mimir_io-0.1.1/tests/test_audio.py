"""Tests for audio lenses."""

import pytest
import torch
import tempfile
from pathlib import Path
from mimir_io.audio.transform import to_tensor, normalize, trim_silence
from mimir_io.audio.resample import resample


def test_to_tensor_lens():
    """Test to_tensor lens."""
    lens = to_tensor()
    data = [1.0, 2.0, 3.0]
    result = lens(torch.tensor(data))
    assert isinstance(result, torch.Tensor)


def test_normalize_lens():
    """Test normalize lens."""
    lens = normalize(target_db=-20.0)
    # Create a simple waveform
    waveform = torch.tensor([[0.5, 0.3, 0.1, -0.2, -0.4]])
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.shape == waveform.shape


def test_normalize_empty():
    """Test normalize with empty tensor."""
    lens = normalize()
    waveform = torch.tensor([])
    result = lens(waveform)
    assert result.numel() == 0


def test_trim_silence_lens():
    """Test trim_silence lens."""
    lens = trim_silence(threshold=0.01)
    # Create waveform with silence at edges
    waveform = torch.tensor([[0.0, 0.0, 0.5, 0.3, 0.1, 0.0, 0.0]])
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    # Should trim the leading and trailing zeros
    assert result.shape[1] <= waveform.shape[1]


def test_trim_silence_all_silent():
    """Test trim_silence with all silent audio."""
    lens = trim_silence(threshold=0.01)
    waveform = torch.tensor([[0.0, 0.0, 0.0]])
    result = lens(waveform)
    assert result.shape == waveform.shape  # Should return original if all silent


def test_resample_with_explicit_sample_rate():
    """Test resample with explicit original sample rate."""
    lens = resample(target_sample_rate=16000, orig_sample_rate=44100)
    # Create a simple waveform (1 second at 44.1kHz = 44100 samples)
    waveform = torch.randn(1, 44100)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    # After resampling to 16kHz, should have ~16000 samples
    assert result.shape[1] == 16000


def test_resample_same_rate():
    """Test resample when target equals original (no-op)."""
    lens = resample(target_sample_rate=44100, orig_sample_rate=44100)
    waveform = torch.randn(1, 44100)
    result = lens(waveform)
    assert torch.equal(result, waveform)


def test_resample_with_tuple():
    """Test resample with tuple input (waveform, sample_rate)."""
    lens = resample(target_sample_rate=16000)
    waveform = torch.randn(1, 44100)
    result_waveform, result_sr = lens((waveform, 44100))
    assert isinstance(result_waveform, torch.Tensor)
    assert result_sr == 16000
    assert result_waveform.shape[1] == 16000


def test_resample_empty_waveform():
    """Test resample with empty waveform."""
    lens = resample(target_sample_rate=16000, orig_sample_rate=44100)
    waveform = torch.tensor([])
    result = lens(waveform)
    assert result.numel() == 0


def test_resample_multichannel():
    """Test resample with multichannel audio."""
    lens = resample(target_sample_rate=16000, orig_sample_rate=44100)
    # Stereo audio (2 channels)
    waveform = torch.randn(2, 44100)
    result = lens(waveform)
    assert result.shape[0] == 2  # Channels preserved
    assert result.shape[1] == 16000  # Resampled length


def test_resample_different_methods():
    """Test resample with different resampling methods."""
    waveform = torch.randn(1, 44100)
    
    # Only test methods that are actually supported by torchaudio
    for method in ["sinc_interp_kaiser", "sinc_interp_hann"]:
        lens = resample(
            target_sample_rate=16000,
            orig_sample_rate=44100,
            resampling_method=method,
        )
        result = lens(waveform)
        assert isinstance(result, torch.Tensor)
        assert result.shape[1] == 16000

