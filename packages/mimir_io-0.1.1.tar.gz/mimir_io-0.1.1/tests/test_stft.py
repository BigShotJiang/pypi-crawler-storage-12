"""Tests for STFT lenses."""

import pytest
import torch
from mimir_io.audio.stft import stft, magnitude_spectrogram, power_spectrogram


def test_stft_basic():
    """Test basic STFT computation."""
    lens = stft(n_fft=2048, hop_length=512)
    waveform = torch.randn(1, 16000)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.dim() == 2
    # Should have n_fft//2+1 frequency bins
    assert result.shape[0] == 2048 // 2 + 1


def test_stft_empty():
    """Test STFT with empty waveform."""
    lens = stft(n_fft=2048)
    waveform = torch.tensor([])
    result = lens(waveform)
    assert result.shape[0] == 2048 // 2 + 1
    assert result.shape[1] == 0


def test_magnitude_spectrogram():
    """Test magnitude spectrogram."""
    lens = magnitude_spectrogram(n_fft=2048, hop_length=512)
    waveform = torch.randn(1, 16000)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.shape[0] == 2048 // 2 + 1
    # Magnitude should be non-negative
    assert torch.all(result >= 0)


def test_power_spectrogram():
    """Test power spectrogram."""
    lens = power_spectrogram(n_fft=2048, hop_length=512)
    waveform = torch.randn(1, 16000)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.shape[0] == 2048 // 2 + 1
    # Power should be non-negative
    assert torch.all(result >= 0)


def test_stft_different_windows():
    """Test STFT with different window functions."""
    waveform = torch.randn(1, 16000)
    
    for window in ["hann", "hamming", "blackman"]:
        lens = stft(n_fft=1024, window_fn=window)
        result = lens(waveform)
        assert isinstance(result, torch.Tensor)
        assert result.shape[0] == 1024 // 2 + 1



