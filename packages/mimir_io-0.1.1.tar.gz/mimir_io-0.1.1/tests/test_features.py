"""Tests for additional audio features."""

import pytest
import torch
from mimir_io.audio.features import (
    power_to_db,
    amplitude_to_db,
    zero_crossing_rate,
    rms_energy,
)


def test_power_to_db():
    """Test power to dB conversion."""
    lens = power_to_db(ref=1.0, top_db=80.0)
    power_spec = torch.rand(80, 100)  # Power spectrogram
    result = lens(power_spec)
    assert isinstance(result, torch.Tensor)
    assert result.shape == power_spec.shape
    # dB values should be reasonable
    assert torch.all(result <= 0) or torch.all(result >= -100)


def test_power_to_db_empty():
    """Test power to dB with empty tensor."""
    lens = power_to_db()
    power_spec = torch.empty(80, 0)
    result = lens(power_spec)
    assert result.shape == power_spec.shape


def test_amplitude_to_db():
    """Test amplitude to dB conversion."""
    lens = amplitude_to_db(ref=1.0, top_db=80.0)
    magnitude_spec = torch.rand(80, 100)  # Magnitude spectrogram
    result = lens(magnitude_spec)
    assert isinstance(result, torch.Tensor)
    assert result.shape == magnitude_spec.shape


def test_zero_crossing_rate():
    """Test zero crossing rate computation."""
    lens = zero_crossing_rate(frame_length=2048, hop_length=512)
    waveform = torch.randn(16000)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.dim() == 2  # (channels, frames)
    # ZCR should be between 0 and 1
    assert torch.all(result >= 0)
    assert torch.all(result <= 1)


def test_zero_crossing_rate_empty():
    """Test zero crossing rate with empty waveform."""
    lens = zero_crossing_rate()
    waveform = torch.tensor([])
    result = lens(waveform)
    assert result.shape == (1, 0)


def test_rms_energy():
    """Test RMS energy computation."""
    lens = rms_energy(frame_length=2048, hop_length=512)
    waveform = torch.randn(16000)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.dim() == 2  # (channels, frames)
    # RMS should be non-negative
    assert torch.all(result >= 0)


def test_rms_energy_empty():
    """Test RMS energy with empty waveform."""
    lens = rms_energy()
    waveform = torch.tensor([])
    result = lens(waveform)
    assert result.shape == (1, 0)


def test_rms_energy_multichannel():
    """Test RMS energy with multi-channel audio."""
    lens = rms_energy(frame_length=2048, hop_length=512)
    waveform = torch.randn(2, 16000)
    result = lens(waveform)
    assert result.shape[0] == 2  # Channels preserved



