"""Тести для інтеграції Learning Rate Scheduler в BaseTrainer."""

import pytest
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from pathlib import Path
import tempfile
import shutil

from mimir_io.models.trainer import BaseTrainer
from mimir_io.models.optimizer_registry import (
    create_scheduler,
    list_schedulers,
    has_scheduler,
    register_scheduler,
)


@pytest.fixture
def simple_model():
    """Проста модель для тестування."""
    return nn.Sequential(
        nn.Linear(10, 5),
        nn.ReLU(),
        nn.Linear(5, 2),
    )


@pytest.fixture
def simple_data():
    """Простий датасет для тестування."""
    X = torch.randn(20, 10)
    y = torch.randint(0, 2, (20,))
    return X, y


@pytest.fixture
def train_loader(simple_data):
    """DataLoader для тренування."""
    X, y = simple_data
    dataset = TensorDataset(X, y)
    return DataLoader(dataset, batch_size=4, shuffle=False)


@pytest.fixture
def val_loader(simple_data):
    """DataLoader для валідації."""
    X, y = simple_data
    dataset = TensorDataset(X, y)
    return DataLoader(dataset, batch_size=4, shuffle=False)


@pytest.fixture
def base_config():
    """Базова конфігурація для тренування."""
    return {
        "training": {
            "epochs": 3,
            "batch_size": 4,
            "save_dir": "./test_checkpoints",
            "optimizer": {
                "type": "Adam",
                "lr": 0.001,
            },
            "criterion": {
                "type": "CrossEntropyLoss",
            },
        }
    }


class TestSchedulerRegistry:
    """Тести для реєстру scheduler."""
    
    def test_list_schedulers(self):
        """Перевірка списку доступних scheduler."""
        schedulers = list_schedulers()
        assert len(schedulers) > 0
        assert "StepLR" in schedulers
        assert "ReduceLROnPlateau" in schedulers
    
    def test_has_scheduler(self):
        """Перевірка наявності scheduler."""
        assert has_scheduler("StepLR")
        assert has_scheduler("ReduceLROnPlateau")
        assert not has_scheduler("NonExistentScheduler")
    
    def test_create_step_lr_scheduler(self, simple_model):
        """Тест створення StepLR scheduler."""
        optimizer = torch.optim.Adam(simple_model.parameters(), lr=0.001)
        scheduler = create_scheduler(
            "StepLR",
            optimizer,
            config={"step_size": 5, "gamma": 0.1}
        )
        assert scheduler is not None
        assert isinstance(scheduler, torch.optim.lr_scheduler.StepLR)
        assert scheduler.step_size == 5
        assert scheduler.gamma == 0.1
    
    def test_create_reduce_lr_on_plateau_scheduler(self, simple_model):
        """Тест створення ReduceLROnPlateau scheduler."""
        optimizer = torch.optim.Adam(simple_model.parameters(), lr=0.001)
        scheduler = create_scheduler(
            "ReduceLROnPlateau",
            optimizer,
            config={"mode": "min", "factor": 0.5, "patience": 3}
        )
        assert scheduler is not None
        assert isinstance(scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau)
    
    def test_create_cosine_annealing_scheduler(self, simple_model):
        """Тест створення CosineAnnealingLR scheduler."""
        optimizer = torch.optim.Adam(simple_model.parameters(), lr=0.001)
        scheduler = create_scheduler(
            "CosineAnnealingLR",
            optimizer,
            config={"T_max": 10, "eta_min": 0}
        )
        assert scheduler is not None
        assert isinstance(scheduler, torch.optim.lr_scheduler.CosineAnnealingLR)
    
    def test_register_custom_scheduler(self, simple_model):
        """Тест реєстрації кастомного scheduler."""
        @register_scheduler("CustomStepLR")
        def custom_step_lr_factory(optimizer, step_size=10, **kwargs):
            return torch.optim.lr_scheduler.StepLR(optimizer, step_size=step_size, **kwargs)
        
        assert has_scheduler("CustomStepLR")
        optimizer = torch.optim.Adam(simple_model.parameters(), lr=0.001)
        scheduler = create_scheduler("CustomStepLR", optimizer, config={"step_size": 10})
        assert scheduler is not None


class TestBaseTrainerWithScheduler:
    """Тести для BaseTrainer з scheduler."""
    
    def test_trainer_without_scheduler(self, simple_model, train_loader, val_loader, base_config):
        """Тест тренера без scheduler."""
        trainer = BaseTrainer(
            model=simple_model,
            config=base_config,
            train_loader=train_loader,
            val_loader=val_loader,
        )
        assert trainer.scheduler is None
    
    def test_trainer_with_step_lr_scheduler(self, simple_model, train_loader, val_loader, base_config):
        """Тест тренера з StepLR scheduler."""
        base_config["training"]["scheduler"] = {
            "enabled": True,
            "type": "StepLR",
            "step_size": 1,
            "gamma": 0.5,
        }
        
        trainer = BaseTrainer(
            model=simple_model,
            config=base_config,
            train_loader=train_loader,
            val_loader=val_loader,
        )
        
        assert trainer.scheduler is not None
        assert isinstance(trainer.scheduler, torch.optim.lr_scheduler.StepLR)
        assert trainer.scheduler.step_size == 1
        assert trainer.scheduler.gamma == 0.5
    
    def test_trainer_with_reduce_lr_on_plateau(self, simple_model, train_loader, val_loader, base_config):
        """Тест тренера з ReduceLROnPlateau scheduler."""
        base_config["training"]["scheduler"] = {
            "enabled": True,
            "type": "ReduceLROnPlateau",
            "mode": "min",
            "factor": 0.5,
            "patience": 2,
            "monitor": "val_loss",
        }
        
        trainer = BaseTrainer(
            model=simple_model,
            config=base_config,
            train_loader=train_loader,
            val_loader=val_loader,
        )
        
        assert trainer.scheduler is not None
        assert isinstance(trainer.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau)
    
    def test_scheduler_disabled(self, simple_model, train_loader, val_loader, base_config):
        """Тест, що scheduler не створюється, коли disabled."""
        base_config["training"]["scheduler"] = {
            "enabled": False,
            "type": "StepLR",
        }
        
        trainer = BaseTrainer(
            model=simple_model,
            config=base_config,
            train_loader=train_loader,
            val_loader=val_loader,
        )
        
        assert trainer.scheduler is None
    
    def test_learning_rate_in_metrics(self, simple_model, train_loader, val_loader, base_config):
        """Тест, що learning_rate додається до метрик."""
        base_config["training"]["scheduler"] = {
            "enabled": True,
            "type": "StepLR",
            "step_size": 1,
            "gamma": 0.5,
        }
        
        trainer = BaseTrainer(
            model=simple_model,
            config=base_config,
            train_loader=train_loader,
            val_loader=val_loader,
        )
        
        initial_lr = trainer.optimizer.param_groups[0]["lr"]
        metrics = trainer.train_epoch()
        
        assert "learning_rate" in metrics
        assert metrics["learning_rate"] == initial_lr
    
    def test_scheduler_step_during_training(self, simple_model, train_loader, val_loader, base_config):
        """Тест, що scheduler викликається під час тренування."""
        base_config["training"]["scheduler"] = {
            "enabled": True,
            "type": "StepLR",
            "step_size": 1,
            "gamma": 0.5,
        }
        
        trainer = BaseTrainer(
            model=simple_model,
            config=base_config,
            train_loader=train_loader,
            val_loader=val_loader,
        )
        
        initial_lr = trainer.optimizer.param_groups[0]["lr"]
        
        # Тренуємо один епох
        trainer.train_epoch()
        trainer.validate()
        
        # Перевіряємо, що learning rate змінився після step()
        # (але ми не викликаємо step() напряму, тому перевіримо після повного тренування)
        # Для тесту викличемо step() вручну
        trainer.scheduler.step()
        new_lr = trainer.optimizer.param_groups[0]["lr"]
        
        assert new_lr == initial_lr * 0.5
    
    def test_reduce_lr_on_plateau_step(self, simple_model, train_loader, val_loader, base_config):
        """Тест ReduceLROnPlateau з метрикою."""
        base_config["training"]["scheduler"] = {
            "enabled": True,
            "type": "ReduceLROnPlateau",
            "mode": "min",
            "factor": 0.5,
            "patience": 1,
            "monitor": "val_loss",
        }
        
        trainer = BaseTrainer(
            model=simple_model,
            config=base_config,
            train_loader=train_loader,
            val_loader=val_loader,
        )
        
        initial_lr = trainer.optimizer.param_groups[0]["lr"]
        
        # Симулюємо крок scheduler з метрикою
        trainer.train_epoch()
        val_metrics = trainer.validate()
        
        # Перевіряємо, що scheduler може прийняти метрику
        assert isinstance(trainer.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau)
        trainer.scheduler.step(val_metrics["val_loss"])
    
    def test_scheduler_in_checkpoint(self, simple_model, train_loader, val_loader, base_config):
        """Тест збереження scheduler state в checkpoint."""
        base_config["training"]["scheduler"] = {
            "enabled": True,
            "type": "StepLR",
            "step_size": 1,
            "gamma": 0.5,
        }
        
        with tempfile.TemporaryDirectory() as tmpdir:
            base_config["training"]["save_dir"] = tmpdir
            
            trainer = BaseTrainer(
                model=simple_model,
                config=base_config,
                train_loader=train_loader,
                val_loader=val_loader,
            )
            
            # Тренуємо один епох та зберігаємо checkpoint
            trainer.train_epoch()
            trainer.validate()
            trainer.save_checkpoint(epoch=0, is_best=True)
            
            # Перевіряємо, що checkpoint містить scheduler state
            checkpoint_path = Path(tmpdir) / "best_model.pt"
            assert checkpoint_path.exists()
            
            checkpoint = torch.load(checkpoint_path)
            assert "scheduler_state_dict" in checkpoint
    
    def test_full_training_with_scheduler(self, simple_model, train_loader, val_loader, base_config):
        """Тест повного циклу тренування з scheduler."""
        base_config["training"]["scheduler"] = {
            "enabled": True,
            "type": "StepLR",
            "step_size": 1,
            "gamma": 0.5,
        }
        # Встановлюємо 2 епохи для тесту
        base_config["training"]["epochs"] = 2
        
        with tempfile.TemporaryDirectory() as tmpdir:
            base_config["training"]["save_dir"] = tmpdir
            
            trainer = BaseTrainer(
                model=simple_model,
                config=base_config,
                train_loader=train_loader,
                val_loader=val_loader,
            )
            
            initial_lr = trainer.optimizer.param_groups[0]["lr"]
            
            # Тренуємо 2 епохи
            trainer.train()
            
            # Перевіряємо, що learning rate зменшився
            final_lr = trainer.optimizer.param_groups[0]["lr"]
            # Після 2 епох з step_size=1 та gamma=0.5, LR повинен бути initial_lr * 0.5^2
            expected_lr = initial_lr * (0.5 ** 2)
            assert abs(final_lr - expected_lr) < 1e-6
    
    def test_multiple_scheduler_types(self, simple_model, train_loader, val_loader, base_config):
        """Тест різних типів scheduler."""
        scheduler_types = [
            ("StepLR", {"step_size": 2, "gamma": 0.1}),
            ("CosineAnnealingLR", {"T_max": 5, "eta_min": 0}),
            ("ExponentialLR", {"gamma": 0.9}),
        ]
        
        for scheduler_type, scheduler_config in scheduler_types:
            config = base_config.copy()
            config["training"]["scheduler"] = {
                "enabled": True,
                "type": scheduler_type,
                **scheduler_config,
            }
            
            trainer = BaseTrainer(
                model=simple_model,
                config=config,
                train_loader=train_loader,
                val_loader=val_loader,
            )
            
            assert trainer.scheduler is not None
            metrics = trainer.train_epoch()
            assert "learning_rate" in metrics


