"""Tests for optimized cache key generation."""

import pytest
import torch
from mimir_io.lens import Lens
from mimir_io.rayframe import AudioRayFrame


def test_cache_key_string():
    """Test cache key generation for strings."""
    lens = Lens(lambda x: x, name="test")
    
    key1 = lens.cache_key("test_string")
    key2 = lens.cache_key("test_string")
    key3 = lens.cache_key("different_string")
    
    assert key1 == key2
    assert key1 != key3
    assert "test" in key1


def test_cache_key_small_tensor():
    """Test cache key generation for small tensors."""
    lens = Lens(lambda x: x, name="test")
    
    tensor1 = torch.tensor([1.0, 2.0, 3.0])
    tensor2 = torch.tensor([1.0, 2.0, 3.0])
    tensor3 = torch.tensor([1.0, 2.0, 4.0])
    
    key1 = lens.cache_key(tensor1)
    key2 = lens.cache_key(tensor2)
    key3 = lens.cache_key(tensor3)
    
    assert key1 == key2
    assert key1 != key3


def test_cache_key_large_tensor():
    """Test cache key generation for large tensors uses sampling."""
    lens = Lens(lambda x: x, name="test")
    
    # Create large tensor
    tensor1 = torch.randn(1000, 1000)
    tensor2 = torch.randn(1000, 1000)
    
    # Same shape and dtype, but different data
    key1 = lens.cache_key(tensor1)
    key2 = lens.cache_key(tensor2)
    
    # Should be different (different samples)
    assert key1 != key2
    
    # But same tensor should give same key
    key3 = lens.cache_key(tensor1)
    assert key1 == key3


def test_cache_key_tensor_shape_dtype():
    """Test that cache key includes shape and dtype for large tensors."""
    lens = Lens(lambda x: x, name="test")
    
    tensor1 = torch.randn(100, 200, dtype=torch.float32)
    tensor2 = torch.randn(100, 200, dtype=torch.float64)
    tensor3 = torch.randn(200, 100, dtype=torch.float32)
    
    key1 = lens.cache_key(tensor1)
    key2 = lens.cache_key(tensor2)
    key3 = lens.cache_key(tensor3)
    
    # All should be different (different dtype/shape)
    assert key1 != key2
    assert key1 != key3
    assert key2 != key3


def test_cache_key_audio_rayframe():
    """Test cache key generation for AudioRayFrame with source_path."""
    lens = Lens(lambda x: x, name="test")
    
    waveform1 = torch.randn(1, 16000)
    waveform2 = torch.randn(1, 16000)
    
    frame1 = AudioRayFrame(
        data=waveform1,
        sample_rate=16000,
        metadata={"source_path": "/path/to/audio1.wav"}
    )
    
    frame2 = AudioRayFrame(
        data=waveform2,
        sample_rate=16000,
        metadata={"source_path": "/path/to/audio1.wav"}  # Same path
    )
    
    frame3 = AudioRayFrame(
        data=waveform1,
        sample_rate=16000,
        metadata={"source_path": "/path/to/audio2.wav"}  # Different path
    )
    
    key1 = lens.cache_key(frame1)
    key2 = lens.cache_key(frame2)
    key3 = lens.cache_key(frame3)
    
    # Same source path should give same key (even with different data)
    assert key1 == key2
    # Different source path should give different key
    assert key1 != key3


def test_cache_key_audio_rayframe_no_source_path():
    """Test cache key generation for AudioRayFrame without source_path."""
    lens = Lens(lambda x: x, name="test")
    
    waveform = torch.randn(1, 16000)
    
    frame1 = AudioRayFrame(
        data=waveform,
        sample_rate=16000,
        metadata={}  # No source_path
    )
    
    frame2 = AudioRayFrame(
        data=waveform,
        sample_rate=16000,
        metadata={}  # No source_path
    )
    
    key1 = lens.cache_key(frame1)
    key2 = lens.cache_key(frame2)
    
    # Should still work (fallback to default method)
    assert key1 == key2


def test_cache_key_cuda_tensor():
    """Test cache key generation for CUDA tensors (should move to CPU)."""
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")
    
    lens = Lens(lambda x: x, name="test")
    
    tensor_cpu = torch.randn(100, dtype=torch.float32)
    tensor_cuda = tensor_cpu.cuda()
    
    key_cpu = lens.cache_key(tensor_cpu)
    key_cuda = lens.cache_key(tensor_cuda)
    
    # Should give same key (CUDA tensor moved to CPU)
    assert key_cpu == key_cuda


