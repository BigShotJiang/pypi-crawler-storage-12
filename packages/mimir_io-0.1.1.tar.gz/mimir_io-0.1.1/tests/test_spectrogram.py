"""Tests for spectrogram lenses."""

import pytest
import torch
from mimir_io.audio.spectrogram import mel_spectrogram, log_mel_spectrogram


def test_mel_spectrogram_basic():
    """Test basic mel spectrogram generation."""
    lens = mel_spectrogram(sample_rate=16000, n_mels=80, n_fft=2048)
    # Create a simple waveform (1 second at 16kHz)
    waveform = torch.randn(1, 16000)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.dim() == 2
    assert result.shape[0] == 80  # n_mels


def test_mel_spectrogram_empty():
    """Test mel spectrogram with empty waveform."""
    lens = mel_spectrogram(sample_rate=16000, n_mels=80)
    waveform = torch.tensor([])
    result = lens(waveform)
    assert result.shape == (80, 0)


def test_mel_spectrogram_multichannel():
    """Test mel spectrogram with multichannel audio."""
    lens = mel_spectrogram(sample_rate=16000, n_mels=64)
    # Stereo audio (2 channels)
    waveform = torch.randn(2, 16000)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.shape[0] == 64  # n_mels


def test_mel_spectrogram_custom_params():
    """Test mel spectrogram with custom parameters."""
    lens = mel_spectrogram(
        sample_rate=22050,
        n_fft=1024,
        win_length=512,
        hop_length=256,
        n_mels=128,
        f_min=80.0,
        f_max=8000.0,
    )
    waveform = torch.randn(1, 22050)
    result = lens(waveform)
    assert result.shape[0] == 128


def test_log_mel_spectrogram_basic():
    """Test basic log mel spectrogram generation."""
    lens = log_mel_spectrogram(sample_rate=16000, n_mels=80)
    waveform = torch.randn(1, 16000)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.dim() == 2
    assert result.shape[0] == 80
    # Log mel should have negative values (log of positive values)
    assert torch.all(result >= -20.0)  # Reasonable range for log


def test_log_mel_spectrogram_empty():
    """Test log mel spectrogram with empty waveform."""
    lens = log_mel_spectrogram(sample_rate=16000, n_mels=80)
    waveform = torch.tensor([])
    result = lens(waveform)
    assert result.shape == (80, 0)


def test_log_mel_spectrogram_custom_offset():
    """Test log mel spectrogram with custom log offset."""
    lens = log_mel_spectrogram(sample_rate=16000, n_mels=64, log_offset=1e-8)
    waveform = torch.randn(1, 16000)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.shape[0] == 64


def test_log_mel_vs_mel():
    """Test that log mel is indeed log of mel."""
    mel_lens = mel_spectrogram(sample_rate=16000, n_mels=80)
    log_mel_lens = log_mel_spectrogram(sample_rate=16000, n_mels=80, log_offset=1e-6)
    
    waveform = torch.randn(1, 16000)
    mel_result = mel_lens(waveform)
    log_mel_result = log_mel_lens(waveform)
    
    # Log mel should be approximately log(mel + offset)
    expected_log_mel = torch.log(mel_result + 1e-6)
    assert torch.allclose(log_mel_result, expected_log_mel, atol=1e-5)


def test_mel_spectrogram_different_windows():
    """Test mel spectrogram with different window functions."""
    waveform = torch.randn(1, 16000)
    
    for window in ["hann", "hamming", "blackman"]:
        lens = mel_spectrogram(sample_rate=16000, n_mels=64, window_fn=window)
        result = lens(waveform)
        assert isinstance(result, torch.Tensor)
        assert result.shape[0] == 64

