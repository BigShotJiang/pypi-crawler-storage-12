"""
Tests for RayFrame classes and lenses.
"""



