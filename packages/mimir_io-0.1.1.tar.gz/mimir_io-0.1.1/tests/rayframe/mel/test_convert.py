"""Tests for MelRayFrame conversion lenses."""

import pytest
import torch
from mimir_io.rayframe import MelRayFrame
from mimir_io.rayframe.mel import to_mel_frame


def test_to_mel_frame():
    """Test to_mel_frame lens."""
    mel_spec = torch.randn(80, 100)  # (n_mels, time_frames)
    
    lens = to_mel_frame(
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )
    frame = lens(mel_spec)
    
    assert isinstance(frame, MelRayFrame)
    assert frame.sample_rate == 16000
    assert frame.n_mels == 80
    assert frame.n_fft == 2048
    assert frame.hop_length == 512
    assert frame.time_frames == 100
    assert frame.channels == 1


def test_to_mel_frame_3d():
    """Test to_mel_frame with 3D tensor."""
    mel_spec = torch.randn(1, 80, 100)  # (channels, n_mels, time_frames)
    
    lens = to_mel_frame(
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )
    frame = lens(mel_spec)
    
    assert isinstance(frame, MelRayFrame)
    assert frame.channels == 1
    assert frame.time_frames == 100


def test_to_mel_frame_with_params():
    """Test to_mel_frame with all parameters."""
    mel_spec = torch.randn(80, 100)
    
    lens = to_mel_frame(
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
        win_length=1024,
        f_min=20.0,
        f_max=8000.0,
    )
    frame = lens(mel_spec)
    
    assert frame.win_length == 1024
    assert frame.f_min == 20.0
    assert frame.f_max == 8000.0



