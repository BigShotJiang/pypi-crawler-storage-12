"""Tests for MelRayFrame transformation lenses."""

import pytest
import torch
from mimir_io.rayframe import MelRayFrame
from mimir_io.rayframe.mel import (
    delta_frame,
    delta_delta_frame,
    stack_delta_features_frame,
)


def test_delta_frame():
    """Test delta_frame lens."""
    mel_spec = torch.randn(80, 100)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )
    
    lens = delta_frame(win_length=5)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, MelRayFrame)
    assert result_frame.shape == frame.shape
    assert result_frame.sample_rate == frame.sample_rate
    assert result_frame.n_mels == frame.n_mels
    assert result_frame.metadata.get("delta_features") == True


def test_delta_delta_frame():
    """Test delta_delta_frame lens."""
    mel_spec = torch.randn(80, 100)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )
    
    lens = delta_delta_frame(win_length=5)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, MelRayFrame)
    assert result_frame.shape == frame.shape
    assert result_frame.sample_rate == frame.sample_rate
    assert result_frame.metadata.get("delta_delta_features") == True


def test_stack_delta_features_frame():
    """Test stack_delta_features_frame lens."""
    mel_spec = torch.randn(80, 100)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )
    
    lens = stack_delta_features_frame(win_length=5)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, MelRayFrame)
    assert result_frame.channels == 3  # (original, delta, delta-delta)
    assert result_frame.shape[0] == 3
    assert result_frame.n_mels == frame.n_mels
    assert result_frame.sample_rate == frame.sample_rate
    assert result_frame.metadata.get("stacked_delta_features") == True


def test_delta_frame_empty():
    """Test delta_frame with empty tensor."""
    mel_spec = torch.empty(80, 0)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )
    
    lens = delta_frame(win_length=5)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, MelRayFrame)
    assert result_frame.shape == frame.shape


def test_delta_frame_invalid_win_length():
    """Test delta_frame with even win_length (should raise error)."""
    with pytest.raises(ValueError, match="must be odd"):
        delta_frame(win_length=4)


def test_delta_frame_3d():
    """Test delta_frame with 3D tensor."""
    mel_spec = torch.randn(1, 80, 100)  # (channels, n_mels, time_frames)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )
    
    lens = delta_frame(win_length=5)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, MelRayFrame)
    assert result_frame.shape == frame.shape



