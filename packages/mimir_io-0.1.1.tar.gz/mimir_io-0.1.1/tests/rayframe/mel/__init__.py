"""
Tests for MelRayFrame lenses.
"""



