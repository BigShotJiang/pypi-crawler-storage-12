"""Tests for base RayFrame classes."""

import pytest
import torch
from mimir_io.rayframe import RayFrame, AudioRayFrame, ImageRayFrame, MelRayFrame


def test_audio_rayframe_mono():
    """Test AudioRayFrame with mono audio."""
    waveform = torch.randn(16000)  # 1 second at 16kHz
    frame = AudioRayFrame(data=waveform, sample_rate=16000)

    assert frame.sample_rate == 16000
    assert frame.channels == 1
    assert frame.duration == pytest.approx(1.0, rel=1e-3)
    assert frame.num_samples == 16000
    assert len(frame.shape) == 2  # Should add channel dimension
    assert frame.shape[0] == 1  # Channel dimension


def test_audio_rayframe_stereo():
    """Test AudioRayFrame with stereo audio."""
    waveform = torch.randn(2, 16000)  # 2 channels, 1 second at 16kHz
    frame = AudioRayFrame(data=waveform, sample_rate=16000)

    assert frame.sample_rate == 16000
    assert frame.channels == 2
    assert frame.duration == pytest.approx(1.0, rel=1e-3)
    assert frame.num_samples == 16000
    assert frame.shape == (2, 16000)


def test_audio_rayframe_empty():
    """Test AudioRayFrame with empty tensor."""
    waveform = torch.tensor([])
    frame = AudioRayFrame(data=waveform, sample_rate=16000)

    assert frame.sample_rate == 16000
    assert frame.duration == 0.0
    assert frame.num_samples == 0


def test_audio_rayframe_metadata():
    """Test AudioRayFrame with metadata."""
    waveform = torch.randn(16000)
    metadata = {"source": "test.wav", "artist": "test"}
    frame = AudioRayFrame(data=waveform, sample_rate=16000, metadata=metadata)

    assert frame.metadata == metadata


def test_image_rayframe_2d():
    """Test ImageRayFrame with 2D tensor."""
    spectrogram = torch.randn(80, 100)  # (n_mels, time_frames)
    frame = ImageRayFrame(data=spectrogram)

    assert frame.channels == 1
    assert frame.height == 80
    assert frame.width == 100
    assert len(frame.shape) == 3  # Should add channel dimension
    assert frame.shape == (1, 80, 100)


def test_image_rayframe_3d():
    """Test ImageRayFrame with 3D tensor."""
    spectrogram = torch.randn(1, 80, 100)  # (channels, n_mels, time_frames)
    frame = ImageRayFrame(data=spectrogram)

    assert frame.channels == 1
    assert frame.height == 80
    assert frame.width == 100
    assert frame.shape == (1, 80, 100)


def test_image_rayframe_multichannel():
    """Test ImageRayFrame with multiple channels."""
    spectrogram = torch.randn(3, 80, 100)  # RGB-like
    frame = ImageRayFrame(data=spectrogram, channels=3)

    assert frame.channels == 3
    assert frame.height == 80
    assert frame.width == 100
    assert frame.shape == (3, 80, 100)


def test_image_rayframe_with_sample_rate():
    """Test ImageRayFrame with sample rate."""
    spectrogram = torch.randn(80, 100)
    frame = ImageRayFrame(data=spectrogram, sample_rate=16000)

    assert frame.sample_rate == 16000
    assert frame.height == 80
    assert frame.width == 100


def test_image_rayframe_empty():
    """Test ImageRayFrame with empty tensor."""
    spectrogram = torch.empty(80, 0)
    frame = ImageRayFrame(data=spectrogram)

    assert frame.height == 80
    assert frame.width == 0


def test_image_rayframe_invalid_dimensions():
    """Test ImageRayFrame with invalid dimensions."""
    tensor_1d = torch.randn(100)
    with pytest.raises(ValueError):
        ImageRayFrame(data=tensor_1d)

    tensor_4d = torch.randn(1, 1, 80, 100)
    with pytest.raises(ValueError):
        ImageRayFrame(data=tensor_4d)


def test_audio_rayframe_invalid_dimensions():
    """Test AudioRayFrame with invalid dimensions."""
    tensor_3d = torch.randn(1, 1, 16000)
    with pytest.raises(ValueError):
        AudioRayFrame(data=tensor_3d, sample_rate=16000)


def test_rayframe_to_dict():
    """Test RayFrame to_dict method."""
    waveform = torch.randn(16000)
    audio_frame = AudioRayFrame(data=waveform, sample_rate=16000)
    audio_dict = audio_frame.to_dict()

    assert "data" in audio_dict
    assert "sample_rate" in audio_dict
    assert "channels" in audio_dict
    assert "duration" in audio_dict
    assert "metadata" in audio_dict

    spectrogram = torch.randn(80, 100)
    image_frame = ImageRayFrame(data=spectrogram)
    image_dict = image_frame.to_dict()

    assert "data" in image_dict
    assert "channels" in image_dict
    assert "height" in image_dict
    assert "width" in image_dict
    assert "sample_rate" in image_dict
    assert "metadata" in image_dict


def test_rayframe_inheritance():
    """Test that RayFrame subclasses inherit from RayFrame."""
    waveform = torch.randn(16000)
    audio_frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    assert isinstance(audio_frame, RayFrame)
    assert isinstance(audio_frame, AudioRayFrame)
    
    spectrogram = torch.randn(80, 100)
    image_frame = ImageRayFrame(data=spectrogram)
    
    assert isinstance(image_frame, RayFrame)
    assert isinstance(image_frame, ImageRayFrame)
    
    mel_spec = torch.randn(80, 100)
    mel_frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )
    
    assert isinstance(mel_frame, RayFrame)
    assert isinstance(mel_frame, ImageRayFrame)
    assert isinstance(mel_frame, MelRayFrame)


def test_rayframe_common_properties():
    """Test that all RayFrame subclasses have common properties."""
    waveform = torch.randn(16000)
    audio_frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    assert hasattr(audio_frame, 'shape')
    assert hasattr(audio_frame, 'dtype')
    assert hasattr(audio_frame, 'to_dict')
    assert hasattr(audio_frame, 'metadata')
    
    spectrogram = torch.randn(80, 100)
    image_frame = ImageRayFrame(data=spectrogram)
    
    assert hasattr(image_frame, 'shape')
    assert hasattr(image_frame, 'dtype')
    assert hasattr(image_frame, 'to_dict')
    assert hasattr(image_frame, 'metadata')



