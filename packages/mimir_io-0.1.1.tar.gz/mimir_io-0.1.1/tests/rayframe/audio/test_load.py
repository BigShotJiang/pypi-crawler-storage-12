"""Tests for AudioRayFrame load lenses."""

import pytest
import torch
import tempfile
from pathlib import Path
import torchaudio

try:
    # Try to use soundfile backend which doesn't require torchcodec
    torchaudio.set_audio_backend("soundfile")
except Exception:
    pass  # Fall back to default backend

from mimir_io.rayframe import AudioRayFrame
from mimir_io.rayframe.audio import load_audio_frame, to_audio_frame


def test_load_audio_frame(tmp_path):
    """Test load_audio_frame lens."""
    # Create a temporary audio file
    audio_file = tmp_path / "test_audio.wav"
    sample_rate = 16000
    waveform = torch.randn(1, sample_rate)  # 1 second mono
    
    # Clamp to valid audio range [-1, 1]
    waveform = torch.clamp(waveform, -1.0, 1.0)
    
    try:
        torchaudio.save(str(audio_file), waveform, sample_rate)
    except ImportError:
        # Skip test if torchcodec is not available and soundfile backend doesn't work
        pytest.skip("torchcodec or soundfile backend not available")
    
    lens = load_audio_frame(audio_file)
    frame = lens(None)
    
    assert isinstance(frame, AudioRayFrame)
    assert frame.sample_rate == sample_rate
    assert frame.channels == 1
    assert frame.duration == pytest.approx(1.0, rel=1e-3)
    assert "source_path" in frame.metadata
    assert "format" in frame.metadata
    assert frame.metadata["format"] == ".wav"


def test_load_audio_frame_with_backend(tmp_path):
    """Test load_audio_frame with explicit backend."""
    audio_file = tmp_path / "test_audio.wav"
    sample_rate = 16000
    waveform = torch.randn(1, sample_rate)
    waveform = torch.clamp(waveform, -1.0, 1.0)
    
    try:
        torchaudio.save(str(audio_file), waveform, sample_rate)
    except ImportError:
        pytest.skip("torchcodec or soundfile backend not available")
    
    # Try with soundfile backend
    try:
        lens = load_audio_frame(audio_file, backend="soundfile")
        frame = lens(None)
        assert isinstance(frame, AudioRayFrame)
        assert frame.sample_rate == sample_rate
    except Exception:
        pytest.skip("soundfile backend not available")


def test_to_audio_frame():
    """Test to_audio_frame lens."""
    sample_rate = 16000
    waveform = torch.randn(16000)  # 1 second mono
    
    lens = to_audio_frame(sample_rate=sample_rate)
    frame = lens(waveform)
    
    assert isinstance(frame, AudioRayFrame)
    assert frame.sample_rate == sample_rate
    assert frame.channels == 1
    assert frame.duration == pytest.approx(1.0, rel=1e-3)


def test_to_audio_frame_stereo():
    """Test to_audio_frame with stereo audio."""
    sample_rate = 16000
    waveform = torch.randn(2, 16000)  # 1 second stereo
    
    lens = to_audio_frame(sample_rate=sample_rate)
    frame = lens(waveform)
    
    assert isinstance(frame, AudioRayFrame)
    assert frame.sample_rate == sample_rate
    assert frame.channels == 2
    assert frame.duration == pytest.approx(1.0, rel=1e-3)

