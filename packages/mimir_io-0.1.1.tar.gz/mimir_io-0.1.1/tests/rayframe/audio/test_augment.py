"""Tests for AudioRayFrame augmentation lenses."""

import pytest
import torch
from mimir_io.rayframe import AudioRayFrame
from mimir_io.rayframe.audio.augment import (
    augment_audio_frame,
    time_shift_frame,
    gain_variation_frame,
    add_noise_frame,
    speed_change_frame,
)


def test_augment_audio_frame():
    """Test composite augmentation for AudioRayFrame."""
    frame = AudioRayFrame(
        data=torch.randn(1, 16000),
        sample_rate=16000,
    )

    lens = augment_audio_frame(
        time_shift_max=1600,
        gain_range=(0.7, 1.3),
        noise_snr=20.0,
    )

    augmented_frame = lens(frame)

    assert isinstance(augmented_frame, AudioRayFrame)
    assert augmented_frame.sample_rate == frame.sample_rate
    assert augmented_frame.channels == frame.channels
    assert "augmented" in augmented_frame.metadata


def test_time_shift_frame():
    """Test time shift frame augmentation."""
    frame = AudioRayFrame(
        data=torch.randn(1, 16000),
        sample_rate=16000,
    )

    lens = time_shift_frame(max_shift_samples=1600)
    shifted_frame = lens(frame)

    assert isinstance(shifted_frame, AudioRayFrame)
    assert shifted_frame.shape == frame.shape
    assert shifted_frame.sample_rate == frame.sample_rate
    assert "time_shifted" in shifted_frame.metadata


def test_gain_variation_frame():
    """Test gain variation frame augmentation."""
    frame = AudioRayFrame(
        data=torch.randn(1, 16000),
        sample_rate=16000,
    )

    lens = gain_variation_frame(min_gain=0.7, max_gain=1.3)
    augmented_frame = lens(frame)

    assert isinstance(augmented_frame, AudioRayFrame)
    assert augmented_frame.shape == frame.shape
    assert "gain_varied" in augmented_frame.metadata


def test_add_noise_frame():
    """Test add noise frame augmentation."""
    frame = AudioRayFrame(
        data=torch.randn(1, 16000),
        sample_rate=16000,
    )

    lens = add_noise_frame(snr_db=20.0)
    noisy_frame = lens(frame)

    assert isinstance(noisy_frame, AudioRayFrame)
    assert noisy_frame.shape == frame.shape
    assert "noise_added" in noisy_frame.metadata
    # Noise should change the signal
    assert not torch.equal(noisy_frame.data, frame.data)


def test_speed_change_frame():
    """Test speed change frame augmentation."""
    frame = AudioRayFrame(
        data=torch.randn(1, 16000),
        sample_rate=16000,
    )

    lens = speed_change_frame(min_speed=0.9, max_speed=1.1)
    speed_changed_frame = lens(frame)

    assert isinstance(speed_changed_frame, AudioRayFrame)
    assert speed_changed_frame.sample_rate == frame.sample_rate
    assert "speed_changed" in speed_changed_frame.metadata


def test_augment_audio_frame_pitch():
    """Test augmentation with pitch shift."""
    frame = AudioRayFrame(
        data=torch.randn(1, 16000),
        sample_rate=16000,
    )

    lens = augment_audio_frame(pitch_range=(-2.0, 2.0))
    augmented_frame = lens(frame)

    assert isinstance(augmented_frame, AudioRayFrame)
    assert augmented_frame.shape == frame.shape


def test_augment_audio_frame_no_augs():
    """Test augmentation with no augmentations specified."""
    frame = AudioRayFrame(
        data=torch.randn(1, 16000),
        sample_rate=16000,
    )

    lens = augment_audio_frame()
    augmented_frame = lens(frame)

    assert isinstance(augmented_frame, AudioRayFrame)
    assert torch.equal(augmented_frame.data, frame.data)
    assert "augmented" in augmented_frame.metadata



