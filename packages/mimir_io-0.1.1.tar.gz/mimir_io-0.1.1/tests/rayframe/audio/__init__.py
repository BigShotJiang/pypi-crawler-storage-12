"""
Tests for AudioRayFrame lenses.
"""



