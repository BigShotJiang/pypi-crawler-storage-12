"""Tests for AudioRayFrame transformation lenses."""

import pytest
import torch
from mimir_io.rayframe import AudioRayFrame
from mimir_io.rayframe.audio import (
    resample_frame,
    normalize_frame,
    trim_silence_frame,
    preemphasis_frame,
    to_mono_frame,
)


def test_resample_frame():
    """Test resample_frame lens."""
    waveform = torch.randn(1, 44100)  # 1 second at 44.1kHz
    frame = AudioRayFrame(data=waveform, sample_rate=44100)
    
    lens = resample_frame(target_sample_rate=16000)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, AudioRayFrame)
    assert result_frame.sample_rate == 16000
    assert result_frame.shape[1] == 16000  # Resampled length
    assert "resampled_from" in result_frame.metadata


def test_resample_frame_same_rate():
    """Test resample_frame when target equals original."""
    waveform = torch.randn(1, 16000)
    frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    lens = resample_frame(target_sample_rate=16000)
    result_frame = lens(frame)
    
    assert result_frame.sample_rate == 16000
    assert torch.allclose(result_frame.data, frame.data)


def test_normalize_frame():
    """Test normalize_frame lens."""
    waveform = torch.tensor([[0.5, 0.3, 0.1, -0.2, -0.4]])
    frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    lens = normalize_frame(target_db=-20.0)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, AudioRayFrame)
    assert result_frame.sample_rate == frame.sample_rate
    assert result_frame.channels == frame.channels
    assert "normalized_to_db" in result_frame.metadata


def test_trim_silence_frame():
    """Test trim_silence_frame lens."""
    # Create waveform with silence at edges
    waveform = torch.tensor([[0.0, 0.0, 0.5, 0.3, 0.1, 0.0, 0.0]])
    frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    lens = trim_silence_frame(threshold=0.01)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, AudioRayFrame)
    assert result_frame.sample_rate == frame.sample_rate
    assert result_frame.shape[1] <= frame.shape[1]  # Should be shorter
    assert "trimmed_silence" in result_frame.metadata


def test_preemphasis_frame():
    """Test preemphasis_frame lens."""
    waveform = torch.randn(1, 16000)
    frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    lens = preemphasis_frame(coeff=0.97)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, AudioRayFrame)
    assert result_frame.sample_rate == frame.sample_rate
    assert result_frame.channels == frame.channels
    assert result_frame.shape == frame.shape
    assert "preemphasis_coeff" in result_frame.metadata


def test_to_mono_frame_average():
    """Test to_mono_frame with average method."""
    waveform = torch.randn(2, 16000)  # Stereo
    frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    lens = to_mono_frame(method="average")
    result_frame = lens(frame)
    
    assert isinstance(result_frame, AudioRayFrame)
    assert result_frame.channels == 1
    assert result_frame.sample_rate == frame.sample_rate
    assert "converted_to_mono" in result_frame.metadata


def test_to_mono_frame_select():
    """Test to_mono_frame with select method."""
    waveform = torch.randn(2, 16000)  # Stereo
    frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    lens = to_mono_frame(method="select")
    result_frame = lens(frame)
    
    assert isinstance(result_frame, AudioRayFrame)
    assert result_frame.channels == 1
    assert result_frame.sample_rate == frame.sample_rate
    assert torch.allclose(result_frame.data, frame.data[0:1])


def test_to_mono_frame_already_mono():
    """Test to_mono_frame when already mono."""
    waveform = torch.randn(1, 16000)
    frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    lens = to_mono_frame()
    result_frame = lens(frame)
    
    assert result_frame.channels == 1
    assert torch.allclose(result_frame.data, frame.data)



