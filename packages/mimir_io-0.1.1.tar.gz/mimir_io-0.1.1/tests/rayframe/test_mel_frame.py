"""Tests for MelRayFrame class."""

import pytest
import torch
from mimir_io.rayframe import RayFrame, ImageRayFrame, MelRayFrame


def test_mel_rayframe_2d():
    """Test MelRayFrame with 2D tensor."""
    mel_spec = torch.randn(80, 100)  # (n_mels, time_frames)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )

    assert frame.sample_rate == 16000
    assert frame.n_mels == 80
    assert frame.n_fft == 2048
    assert frame.hop_length == 512
    assert frame.time_frames == 100
    assert frame.channels == 1
    assert len(frame.shape) == 3  # Should add channel dimension
    assert frame.shape == (1, 80, 100)


def test_mel_rayframe_3d():
    """Test MelRayFrame with 3D tensor."""
    mel_spec = torch.randn(1, 80, 100)  # (channels, n_mels, time_frames)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )

    assert frame.channels == 1
    assert frame.n_mels == 80
    assert frame.time_frames == 100
    assert frame.shape == (1, 80, 100)


def test_mel_rayframe_multichannel():
    """Test MelRayFrame with multiple channels."""
    mel_spec = torch.randn(3, 80, 100)  # (channels, n_mels, time_frames)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )

    assert frame.channels == 3
    assert frame.n_mels == 80
    assert frame.time_frames == 100
    assert frame.shape == (3, 80, 100)


def test_mel_rayframe_duration():
    """Test MelRayFrame duration calculation."""
    mel_spec = torch.randn(80, 100)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )

    # Duration = (time_frames - 1) * hop_length / sample_rate
    expected_duration = (100 - 1) * 512 / 16000
    assert frame.duration == pytest.approx(expected_duration, rel=1e-3)


def test_mel_rayframe_time_resolution():
    """Test MelRayFrame time resolution property."""
    mel_spec = torch.randn(80, 100)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )

    expected_resolution = 512 / 16000
    assert frame.time_resolution == pytest.approx(expected_resolution, rel=1e-3)


def test_mel_rayframe_frequency_resolution():
    """Test MelRayFrame frequency resolution property."""
    mel_spec = torch.randn(80, 100)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
        f_min=0.0,
        f_max=8000.0,
    )

    expected_resolution = 8000.0 / 80
    assert frame.frequency_resolution == pytest.approx(expected_resolution, rel=1e-3)


def test_mel_rayframe_empty():
    """Test MelRayFrame with empty tensor."""
    mel_spec = torch.empty(80, 0)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )

    assert frame.time_frames == 0
    assert frame.duration == 0.0


def test_mel_rayframe_n_mels_mismatch():
    """Test MelRayFrame with mismatched n_mels."""
    mel_spec = torch.randn(80, 100)
    
    with pytest.raises(ValueError, match="n_mels"):
        MelRayFrame(
            data=mel_spec,
            sample_rate=16000,
            n_mels=64,  # Mismatch!
            n_fft=2048,
            hop_length=512,
        )


def test_mel_rayframe_invalid_dimensions():
    """Test MelRayFrame with invalid dimensions."""
    tensor_1d = torch.randn(100)
    with pytest.raises(ValueError):
        MelRayFrame(
            data=tensor_1d,
            sample_rate=16000,
            n_mels=80,
            n_fft=2048,
            hop_length=512,
        )

    tensor_4d = torch.randn(1, 1, 80, 100)
    with pytest.raises(ValueError):
        MelRayFrame(
            data=tensor_4d,
            sample_rate=16000,
            n_mels=80,
            n_fft=2048,
            hop_length=512,
        )


def test_mel_rayframe_defaults():
    """Test MelRayFrame with default values."""
    mel_spec = torch.randn(80, 100)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )

    # f_max should default to sample_rate // 2
    assert frame.f_max == 8000.0
    
    # win_length should default to n_fft
    assert frame.win_length == 2048


def test_mel_rayframe_to_dict():
    """Test MelRayFrame to_dict method."""
    mel_spec = torch.randn(80, 100)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )
    
    frame_dict = frame.to_dict()
    
    assert "data" in frame_dict
    assert "sample_rate" in frame_dict
    assert "n_mels" in frame_dict
    assert "n_fft" in frame_dict
    assert "hop_length" in frame_dict
    assert "time_frames" in frame_dict
    assert "duration" in frame_dict
    assert "f_min" in frame_dict
    assert "f_max" in frame_dict
    assert "channels" in frame_dict
    assert "metadata" in frame_dict


def test_mel_rayframe_inheritance():
    """Test that MelRayFrame inherits from ImageRayFrame and RayFrame."""
    mel_spec = torch.randn(80, 100)
    frame = MelRayFrame(
        data=mel_spec,
        sample_rate=16000,
        n_mels=80,
        n_fft=2048,
        hop_length=512,
    )
    
    assert isinstance(frame, RayFrame)
    assert isinstance(frame, ImageRayFrame)
    assert isinstance(frame, MelRayFrame)
    
    # Should have ImageRayFrame properties
    assert hasattr(frame, 'height')
    assert hasattr(frame, 'width')
    assert frame.height == 80
    assert frame.width == 100



