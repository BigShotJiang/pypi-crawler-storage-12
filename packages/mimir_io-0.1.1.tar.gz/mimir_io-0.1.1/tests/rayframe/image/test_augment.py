"""Tests for ImageRayFrame augmentation lenses."""

import pytest
import torch
from mimir_io.rayframe import ImageRayFrame
from mimir_io.rayframe.image import (
    time_mask_frame,
    frequency_mask_frame,
    spec_augment_frame,
    random_horizontal_flip,
    random_vertical_flip,
    random_rotation,
    random_crop,
    center_crop,
    color_jitter,
    random_erasing,
    normalize,
    random_affine,
)


def test_time_mask_frame():
    """Test time_mask_frame lens."""
    spectrogram = torch.randn(80, 100)  # (n_mels, time_frames)
    frame = ImageRayFrame(data=spectrogram, sample_rate=16000)
    
    lens = time_mask_frame(max_mask_size=10, num_masks=2)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape
    assert result_frame.sample_rate == frame.sample_rate
    assert result_frame.metadata.get("time_masked") == True


def test_time_mask_frame_3d():
    """Test time_mask_frame with 3D tensor."""
    spectrogram = torch.randn(1, 80, 100)  # (channels, n_mels, time_frames)
    frame = ImageRayFrame(data=spectrogram, sample_rate=16000)
    
    lens = time_mask_frame(max_mask_size=10, num_masks=1)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_time_mask_frame_empty():
    """Test time_mask_frame with empty tensor."""
    spectrogram = torch.empty(80, 0)
    frame = ImageRayFrame(data=spectrogram, sample_rate=16000)
    
    lens = time_mask_frame(max_mask_size=10)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_frequency_mask_frame():
    """Test frequency_mask_frame lens."""
    spectrogram = torch.randn(80, 100)  # (n_mels, time_frames)
    frame = ImageRayFrame(data=spectrogram, sample_rate=16000)
    
    lens = frequency_mask_frame(max_mask_size=10, num_masks=2)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape
    assert result_frame.sample_rate == frame.sample_rate
    assert result_frame.metadata.get("frequency_masked") == True


def test_frequency_mask_frame_3d():
    """Test frequency_mask_frame with 3D tensor."""
    spectrogram = torch.randn(1, 80, 100)  # (channels, n_mels, time_frames)
    frame = ImageRayFrame(data=spectrogram, sample_rate=16000)
    
    lens = frequency_mask_frame(max_mask_size=10, num_masks=1)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_frequency_mask_frame_empty():
    """Test frequency_mask_frame with empty tensor."""
    spectrogram = torch.empty(80, 0)
    frame = ImageRayFrame(data=spectrogram, sample_rate=16000)
    
    lens = frequency_mask_frame(max_mask_size=10)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_spec_augment_frame():
    """Test spec_augment_frame lens."""
    spectrogram = torch.randn(80, 100)  # (n_mels, time_frames)
    frame = ImageRayFrame(data=spectrogram, sample_rate=16000)
    
    lens = spec_augment_frame(time_mask_param=10, num_time_masks=2, freq_mask_param=5, num_freq_masks=2)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape
    assert result_frame.sample_rate == frame.sample_rate
    assert result_frame.metadata.get("spec_augmented") == True


def test_spec_augment_frame_3d():
    """Test spec_augment_frame with 3D tensor."""
    spectrogram = torch.randn(1, 80, 100)  # (channels, n_mels, time_frames)
    frame = ImageRayFrame(data=spectrogram, sample_rate=16000)
    
    lens = spec_augment_frame(time_mask_param=10, num_time_masks=1, freq_mask_param=5, num_freq_masks=1)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


# ========== Basic Image Augmentations Tests ==========

def test_random_horizontal_flip():
    """Test random_horizontal_flip lens."""
    image = torch.randn(3, 64, 64)  # (C, H, W)
    frame = ImageRayFrame(data=image)
    
    lens = random_horizontal_flip(probability=1.0, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape
    assert result_frame.metadata.get("horizontal_flipped") == True


def test_random_horizontal_flip_2d():
    """Test random_horizontal_flip with 2D tensor."""
    image = torch.randn(64, 64)  # (H, W)
    frame = ImageRayFrame(data=image)
    
    lens = random_horizontal_flip(probability=1.0, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_random_horizontal_flip_probability():
    """Test random_horizontal_flip with probability=0."""
    image = torch.randn(3, 64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = random_horizontal_flip(probability=0.0, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.metadata.get("horizontal_flipped") is None


def test_random_vertical_flip():
    """Test random_vertical_flip lens."""
    image = torch.randn(3, 64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = random_vertical_flip(probability=1.0, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape
    assert result_frame.metadata.get("vertical_flipped") == True


def test_random_vertical_flip_2d():
    """Test random_vertical_flip with 2D tensor."""
    image = torch.randn(64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = random_vertical_flip(probability=1.0, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_random_rotation():
    """Test random_rotation lens."""
    image = torch.randn(3, 64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = random_rotation(degrees=15.0, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape
    assert "rotated" in result_frame.metadata


def test_random_rotation_2d():
    """Test random_rotation with 2D tensor."""
    image = torch.randn(64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = random_rotation(degrees=15.0, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_random_rotation_zero_degrees():
    """Test random_rotation with zero degrees."""
    image = torch.randn(3, 64, 64)
    frame = ImageRayFrame(data=image)
    original_data = frame.data.clone()
    
    lens = random_rotation(degrees=0.0, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_random_crop():
    """Test random_crop lens."""
    image = torch.randn(3, 128, 128)
    frame = ImageRayFrame(data=image)
    
    lens = random_crop(size=(64, 64), seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.height == 64
    assert result_frame.width == 64
    assert result_frame.metadata.get("cropped") is not None


def test_random_crop_smaller_image():
    """Test random_crop with image smaller than target."""
    image = torch.randn(3, 32, 32)
    frame = ImageRayFrame(data=image)
    
    lens = random_crop(size=(64, 64), seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.metadata.get("padded") == True


def test_random_crop_2d():
    """Test random_crop with 2D tensor."""
    image = torch.randn(128, 128)
    frame = ImageRayFrame(data=image)
    
    lens = random_crop(size=(64, 64), seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.height == 64
    assert result_frame.width == 64


def test_center_crop():
    """Test center_crop lens."""
    image = torch.randn(3, 128, 128)
    frame = ImageRayFrame(data=image)
    
    lens = center_crop(size=(64, 64))
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.height == 64
    assert result_frame.width == 64
    assert result_frame.metadata.get("center_cropped") == True


def test_center_crop_smaller_image():
    """Test center_crop with image smaller than target."""
    image = torch.randn(3, 32, 32)
    frame = ImageRayFrame(data=image)
    
    lens = center_crop(size=(64, 64))
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.metadata.get("padded") == True


def test_color_jitter():
    """Test color_jitter lens."""
    image = torch.randn(3, 64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = color_jitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape
    assert result_frame.metadata.get("color_jittered") == True


def test_color_jitter_2d():
    """Test color_jitter with 2D tensor (grayscale)."""
    image = torch.randn(64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = color_jitter(brightness=0.2, contrast=0.2, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_color_jitter_zero_params():
    """Test color_jitter with zero parameters."""
    image = torch.randn(3, 64, 64)
    frame = ImageRayFrame(data=image)
    original_data = frame.data.clone()
    
    lens = color_jitter(brightness=0.0, contrast=0.0, saturation=0.0, hue=0.0, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_random_erasing():
    """Test random_erasing lens."""
    image = torch.randn(3, 64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = random_erasing(probability=1.0, scale=(0.02, 0.33), seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape
    assert result_frame.metadata.get("random_erased") == True


def test_random_erasing_2d():
    """Test random_erasing with 2D tensor."""
    image = torch.randn(64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = random_erasing(probability=1.0, scale=(0.02, 0.33), seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_random_erasing_probability():
    """Test random_erasing with probability=0."""
    image = torch.randn(3, 64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = random_erasing(probability=0.0, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.metadata.get("random_erased") is None


def test_normalize():
    """Test normalize lens."""
    image = torch.randn(3, 64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225))
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape
    assert result_frame.metadata.get("normalized") == True


def test_normalize_2d():
    """Test normalize with 2D tensor."""
    image = torch.randn(64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = normalize(mean=(0.5,), std=(0.5,))
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_random_affine():
    """Test random_affine lens."""
    image = torch.randn(3, 64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = random_affine(degrees=15, translate=(0.1, 0.1), scale=(0.9, 1.1), seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape
    assert result_frame.metadata.get("affine_transformed") == True


def test_random_affine_2d():
    """Test random_affine with 2D tensor."""
    image = torch.randn(64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = random_affine(degrees=15, translate=(0.1, 0.1), scale=(0.9, 1.1), seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


def test_random_affine_zero_params():
    """Test random_affine with zero parameters."""
    image = torch.randn(3, 64, 64)
    frame = ImageRayFrame(data=image)
    
    lens = random_affine(degrees=0.0, translate=(0.0, 0.0), scale=(1.0, 1.0), shear=0.0, seed=42)
    result_frame = lens(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.shape == frame.shape


# ========== GPU Tests ==========

@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_augmentations_gpu():
    """Test augmentations on GPU."""
    device = torch.device("cuda")
    image = torch.randn(3, 64, 64, device=device)
    frame = ImageRayFrame(data=image)
    
    # Test horizontal flip
    lens = random_horizontal_flip(probability=1.0, seed=42)
    result_frame = lens(frame)
    assert result_frame.data.device.type == "cuda"
    
    # Test rotation
    lens = random_rotation(degrees=15.0, seed=42)
    result_frame = lens(frame)
    assert result_frame.data.device.type == "cuda"
    
    # Test crop
    lens = random_crop(size=(32, 32), seed=42)
    result_frame = lens(frame)
    assert result_frame.data.device.type == "cuda"
    
    # Test color jitter
    lens = color_jitter(brightness=0.2, seed=42)
    result_frame = lens(frame)
    assert result_frame.data.device.type == "cuda"


# ========== Seed Reproducibility Tests ==========

def test_seed_reproducibility():
    """Test that augmentations are reproducible with same seed."""
    image = torch.randn(3, 64, 64)
    frame1 = ImageRayFrame(data=image.clone())
    frame2 = ImageRayFrame(data=image.clone())
    
    seed = 42
    
    # Horizontal flip
    lens1 = random_horizontal_flip(probability=1.0, seed=seed)
    lens2 = random_horizontal_flip(probability=1.0, seed=seed)
    result1 = lens1(frame1)
    result2 = lens2(frame2)
    assert torch.allclose(result1.data, result2.data)
    
    # Rotation
    lens1 = random_rotation(degrees=15.0, seed=seed)
    lens2 = random_rotation(degrees=15.0, seed=seed)
    result1 = lens1(frame1)
    result2 = lens2(frame2)
    assert torch.allclose(result1.data, result2.data)
    
    # Crop
    lens1 = random_crop(size=(32, 32), seed=seed)
    lens2 = random_crop(size=(32, 32), seed=seed)
    result1 = lens1(frame1)
    result2 = lens2(frame2)
    assert result1.height == result2.height
    assert result1.width == result2.width


# ========== Composition Tests ==========

def test_compose_augmentations():
    """Test composing multiple augmentations."""
    image = torch.randn(3, 128, 128)
    frame = ImageRayFrame(data=image)
    
    # Compose augmentations
    pipeline = (
        random_horizontal_flip(probability=0.5, seed=42)
        | random_rotation(degrees=15.0, seed=42)
        | random_crop(size=(64, 64), seed=42)
        | color_jitter(brightness=0.2, seed=42)
    )
    
    result_frame = pipeline(frame)
    
    assert isinstance(result_frame, ImageRayFrame)
    assert result_frame.height == 64
    assert result_frame.width == 64


# ========== Edge Cases Tests ==========

def test_augmentations_empty_tensor():
    """Test augmentations with empty tensor."""
    image = torch.empty(0, 0)
    frame = ImageRayFrame(data=image)
    
    # All augmentations should handle empty tensors gracefully
    augmentations = [
        random_horizontal_flip(probability=1.0),
        random_vertical_flip(probability=1.0),
        random_rotation(degrees=15.0),
        random_crop(size=(32, 32)),
        center_crop(size=(32, 32)),
        color_jitter(brightness=0.2),
        random_erasing(probability=1.0),
        normalize(mean=(0.5,), std=(0.5,)),
        random_affine(degrees=15),
    ]
    
    for aug in augmentations:
        result_frame = aug(frame)
        assert isinstance(result_frame, ImageRayFrame)


def test_augmentations_single_pixel():
    """Test augmentations with single pixel image."""
    image = torch.randn(3, 1, 1)
    frame = ImageRayFrame(data=image)
    
    # Most augmentations should handle single pixel
    augmentations = [
        random_horizontal_flip(probability=1.0),
        random_vertical_flip(probability=1.0),
        color_jitter(brightness=0.2),
        normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5)),
    ]
    
    for aug in augmentations:
        result_frame = aug(frame)
        assert isinstance(result_frame, ImageRayFrame)
        assert result_frame.shape == frame.shape

