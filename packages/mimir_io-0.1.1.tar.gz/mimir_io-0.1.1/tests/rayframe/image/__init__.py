"""
Tests for ImageRayFrame lenses.
"""



