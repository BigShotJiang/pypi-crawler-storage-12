"""Tests for ImageRayFrame conversion lenses."""

import pytest
import torch
from mimir_io.rayframe import ImageRayFrame
from mimir_io.rayframe.image import to_image_frame, mel_to_frame


def test_to_image_frame():
    """Test to_image_frame lens."""
    spectrogram = torch.randn(80, 100)  # (n_mels, time_frames)
    
    lens = to_image_frame(sample_rate=16000, height=80, width=100)
    frame = lens(spectrogram)
    
    assert isinstance(frame, ImageRayFrame)
    assert frame.sample_rate == 16000
    assert frame.height == 80
    assert frame.width == 100
    assert frame.channels == 1


def test_to_image_frame_3d():
    """Test to_image_frame with 3D tensor."""
    spectrogram = torch.randn(1, 80, 100)  # (channels, n_mels, time_frames)
    
    lens = to_image_frame(sample_rate=16000)
    frame = lens(spectrogram)
    
    assert isinstance(frame, ImageRayFrame)
    assert frame.channels == 1
    assert frame.height == 80
    assert frame.width == 100


def test_mel_to_frame():
    """Test mel_to_frame lens."""
    mel_spec = torch.randn(80, 100)  # (n_mels, time_frames)
    
    lens = mel_to_frame(sample_rate=16000)
    frame = lens(mel_spec)
    
    assert isinstance(frame, ImageRayFrame)
    assert frame.sample_rate == 16000
    assert frame.height == 80
    assert frame.width == 100
    assert frame.metadata.get("type") == "mel_spectrogram"


def test_mel_to_frame_3d():
    """Test mel_to_frame with 3D tensor."""
    mel_spec = torch.randn(3, 80, 100)  # (channels, n_mels, time_frames)
    
    lens = mel_to_frame(sample_rate=16000)
    frame = lens(mel_spec)
    
    assert isinstance(frame, ImageRayFrame)
    assert frame.channels == 3
    assert frame.height == 80
    assert frame.width == 100



