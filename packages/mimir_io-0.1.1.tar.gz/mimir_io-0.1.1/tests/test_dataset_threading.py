"""Tests for threading support in dataset batch operations."""

import pytest
import tempfile
from pathlib import Path
from mimir_io.dataset import Dataset
from mimir_io.lens import Lens


def _double_function(x):
    """Helper function for testing (can be pickled for multiprocessing)."""
    return x * 2


def test_apply_batch_threading():
    """Test apply_batch with threading."""
    with tempfile.TemporaryDirectory() as tmpdir:
        dataset = Dataset(Path(tmpdir))
        
        # Create a simple lens (use global function for multiprocessing compatibility)
        lens = Lens(_double_function, name="double")
        
        # Test data
        data_list = [1, 2, 3, 4, 5]
        
        # Use threading
        results = dataset.apply_batch(
            lens,
            data_list,
            num_workers=2,
            use_threads=True,
            use_cache=False
        )
        
        assert len(results) == 5
        assert results == [2, 4, 6, 8, 10]


def test_apply_batch_threading_with_cache():
    """Test apply_batch with threading and caching."""
    with tempfile.TemporaryDirectory() as tmpdir:
        dataset = Dataset(Path(tmpdir))
        
        # Create a lens that will be cached
        lens = Lens(_double_function, name="double")
        
        # Test data
        data_list = [10, 20, 30]
        
        # First run - should compute
        results1 = dataset.apply_batch(
            lens,
            data_list,
            num_workers=2,
            use_threads=True,
            use_cache=True
        )
        
        assert results1 == [20, 40, 60]
        
        # Second run - should load from cache
        results2 = dataset.apply_batch(
            lens,
            data_list,
            num_workers=2,
            use_threads=True,
            use_cache=True
        )
        
        assert results2 == [20, 40, 60]


def test_apply_batch_multiprocessing_vs_threading():
    """Test that both multiprocessing and threading work."""
    with tempfile.TemporaryDirectory() as tmpdir:
        dataset = Dataset(Path(tmpdir))
        
        lens = Lens(_double_function, name="double")
        data_list = [1, 2, 3]
        
        # Test multiprocessing (uses 'spawn' method to avoid fork() warnings)
        results_mp = dataset.apply_batch(
            lens,
            data_list,
            num_workers=2,
            use_threads=False,
            use_cache=False
        )
        
        # Test threading
        results_thread = dataset.apply_batch(
            lens,
            data_list,
            num_workers=2,
            use_threads=True,
            use_cache=False
        )
        
        # Results should be the same
        assert results_mp == results_thread
        assert results_mp == [2, 4, 6]


def test_apply_batch_threading_single_worker():
    """Test that single worker falls back to sequential."""
    with tempfile.TemporaryDirectory() as tmpdir:
        dataset = Dataset(Path(tmpdir))
        
        lens = Lens(_double_function, name="double")
        data_list = [1, 2, 3]
        
        # Single worker should use sequential processing
        results = dataset.apply_batch(
            lens,
            data_list,
            num_workers=1,
            use_threads=True,
            use_cache=False
        )
        
        assert results == [2, 4, 6]


def test_apply_batch_threading_empty_list():
    """Test threading with empty list."""
    with tempfile.TemporaryDirectory() as tmpdir:
        dataset = Dataset(Path(tmpdir))
        
        lens = Lens(_double_function, name="double")
        
        results = dataset.apply_batch(
            lens,
            [],
            num_workers=2,
            use_threads=True,
            use_cache=False
        )
        
        assert results == []

