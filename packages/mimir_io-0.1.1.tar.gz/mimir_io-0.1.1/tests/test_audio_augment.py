"""Tests for audio augmentation lenses."""

import pytest
import torch
from mimir_io.audio.augment import (
    time_shift,
    gain_variation,
    add_noise,
    time_mask,
    speed_change,
    pitch_shift,
    random_pitch_shift,
    compose_augmentations,
)


def test_time_shift():
    """Test time shift augmentation."""
    lens = time_shift(max_shift_samples=100)
    waveform = torch.randn(1, 1000)

    shifted = lens(waveform)
    assert isinstance(shifted, torch.Tensor)
    assert shifted.shape == waveform.shape


def test_time_shift_empty():
    """Test time shift with empty tensor."""
    lens = time_shift(max_shift_samples=100)
    waveform = torch.tensor([])

    shifted = lens(waveform)
    assert shifted.numel() == 0


def test_gain_variation():
    """Test gain variation augmentation."""
    lens = gain_variation(min_gain=0.5, max_gain=1.5)
    waveform = torch.randn(1, 1000)

    augmented = lens(waveform)
    assert isinstance(augmented, torch.Tensor)
    assert augmented.shape == waveform.shape


def test_gain_variation_range():
    """Test that gain variation stays within range."""
    lens = gain_variation(min_gain=0.8, max_gain=1.2)
    waveform = torch.ones(1, 1000)

    # Run multiple times to check range
    for _ in range(10):
        augmented = lens(waveform)
        max_val = augmented.max().item()
        min_val = augmented.min().item()
        assert 0.8 <= max_val <= 1.2
        assert 0.8 <= min_val <= 1.2


def test_add_noise():
    """Test noise injection augmentation."""
    lens = add_noise(snr_db=20.0)
    waveform = torch.randn(1, 1000)

    noisy = lens(waveform)
    assert isinstance(noisy, torch.Tensor)
    assert noisy.shape == waveform.shape
    # Noise should change the signal
    assert not torch.equal(noisy, waveform)


def test_add_noise_empty():
    """Test add noise with empty tensor."""
    lens = add_noise(snr_db=20.0)
    waveform = torch.tensor([])

    noisy = lens(waveform)
    assert noisy.numel() == 0


def test_time_mask():
    """Test time masking augmentation."""
    lens = time_mask(max_mask_samples=100, num_masks=2)
    waveform = torch.randn(1, 1000)

    masked = lens(waveform)
    assert isinstance(masked, torch.Tensor)
    assert masked.shape == waveform.shape


def test_time_mask_empty():
    """Test time mask with empty tensor."""
    lens = time_mask(max_mask_samples=100)
    waveform = torch.tensor([])

    masked = lens(waveform)
    assert masked.numel() == 0


def test_speed_change():
    """Test speed change augmentation."""
    lens = speed_change(sample_rate=16000, min_speed=0.9, max_speed=1.1)
    waveform = torch.randn(1, 16000)  # 1 second at 16kHz

    speed_changed = lens(waveform)
    assert isinstance(speed_changed, torch.Tensor)
    assert speed_changed.shape == waveform.shape  # Should maintain length


def test_speed_change_empty():
    """Test speed change with empty tensor."""
    lens = speed_change(sample_rate=16000)
    waveform = torch.tensor([])

    speed_changed = lens(waveform)
    assert speed_changed.numel() == 0


def test_pitch_shift():
    """Test pitch shift augmentation."""
    lens = pitch_shift(sample_rate=16000, n_steps=2.0)
    waveform = torch.randn(1, 16000)

    pitch_shifted = lens(waveform)
    assert isinstance(pitch_shifted, torch.Tensor)
    assert pitch_shifted.shape == waveform.shape


def test_pitch_shift_zero():
    """Test pitch shift with zero steps (should return original)."""
    lens = pitch_shift(sample_rate=16000, n_steps=0.0)
    waveform = torch.randn(1, 1000)

    pitch_shifted = lens(waveform)
    assert pitch_shifted.shape == waveform.shape


def test_random_pitch_shift():
    """Test random pitch shift augmentation."""
    lens = random_pitch_shift(sample_rate=16000, min_steps=-2.0, max_steps=2.0)
    waveform = torch.randn(1, 16000)

    pitch_shifted = lens(waveform)
    assert isinstance(pitch_shifted, torch.Tensor)
    assert pitch_shifted.shape == waveform.shape


def test_compose_augmentations():
    """Test composing multiple augmentations."""
    augs = compose_augmentations(
        time_shift(100),
        gain_variation(0.8, 1.2),
        add_noise(20.0),
    )

    waveform = torch.randn(1, 1000)
    augmented = augs(waveform)

    assert isinstance(augmented, torch.Tensor)
    assert augmented.shape == waveform.shape


def test_compose_augmentations_empty():
    """Test composing empty augmentations."""
    from mimir_io.lens import identity

    augs = compose_augmentations()
    waveform = torch.randn(1, 1000)
    augmented = augs(waveform)

    assert torch.equal(augmented, waveform)


def test_compose_augmentations_single():
    """Test composing single augmentation."""
    augs = compose_augmentations(time_shift(100))
    waveform = torch.randn(1, 1000)

    augmented = augs(waveform)
    assert augmented.shape == waveform.shape



