"""Tests for lens system."""

import pytest
from mimir_io.lens import Lens, compose, identity


def test_identity_lens():
    """Test that identity lens returns data unchanged."""
    lens = identity()
    data = [1, 2, 3]
    assert lens(data) == data


def test_simple_lens():
    """Test a simple lens transformation."""
    lens = Lens(lambda x: x * 2, name="double")
    assert lens(5) == 10
    assert lens(10) == 20


def test_lens_composition():
    """Test composing lenses."""
    double = Lens(lambda x: x * 2, name="double")
    add_one = Lens(lambda x: x + 1, name="add_one")

    composed = compose(double, add_one)
    assert composed(5) == 11  # (5 * 2) + 1

    # Test reverse composition
    composed2 = compose(add_one, double)
    assert composed2(5) == 12  # (5 + 1) * 2


def test_lens_operator_composition():
    """Test lens composition using | operator."""
    double = Lens(lambda x: x * 2, name="double")
    add_one = Lens(lambda x: x + 1, name="add_one")

    composed = double | add_one
    assert composed(5) == 11


def test_lens_cache_key():
    """Test that lenses generate cache keys."""
    lens = Lens(lambda x: x * 2, name="double")
    key1 = lens.cache_key(5)
    key2 = lens.cache_key(5)
    key3 = lens.cache_key(10)

    assert key1 == key2
    assert key1 != key3
    assert "double" in key1


def test_nested_composition():
    """Test composing multiple lenses."""
    double = Lens(lambda x: x * 2, name="double")
    add_one = Lens(lambda x: x + 1, name="add_one")
    square = Lens(lambda x: x ** 2, name="square")

    composed = double | add_one | square
    assert composed(3) == 49  # ((3 * 2) + 1) ** 2

