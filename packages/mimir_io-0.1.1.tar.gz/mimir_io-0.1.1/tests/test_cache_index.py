"""Tests for cache index optimization."""

import pytest
import tempfile
import time
from pathlib import Path
from mimir_io.cache_index import CacheIndex


def test_cache_index_initialization():
    """Test cache index initialization."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cache_dir = Path(tmpdir) / "cache"
        cache_dir.mkdir()
        
        index = CacheIndex(cache_dir)
        assert index.cache_dir == cache_dir
        assert index.ttl == 3600.0
        assert index.auto_refresh is True


def test_cache_index_exists_false():
    """Test cache index returns False for non-existent cache."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cache_dir = Path(tmpdir) / "cache"
        cache_dir.mkdir()
        
        index = CacheIndex(cache_dir)
        assert index.exists("nonexistent_key") is False


def test_cache_index_mark_exists():
    """Test marking cache as existing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cache_dir = Path(tmpdir) / "cache"
        cache_dir.mkdir()
        
        index = CacheIndex(cache_dir)
        index.mark_exists("test_key", ".wav")
        
        assert index.exists("test_key") is True


def test_cache_index_mark_missing():
    """Test marking cache as missing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cache_dir = Path(tmpdir) / "cache"
        cache_dir.mkdir()
        
        index = CacheIndex(cache_dir)
        index.mark_exists("test_key")
        index.mark_missing("test_key")
        
        assert index.exists("test_key") is False


def test_cache_index_filesystem_check():
    """Test cache index checks filesystem."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cache_dir = Path(tmpdir) / "cache"
        cache_dir.mkdir()
        
        index = CacheIndex(cache_dir)
        
        # Create a cache file
        cache_file = cache_dir / "test_key.wav"
        cache_file.touch()
        
        # Should find it
        assert index.exists("test_key") is True


def test_cache_index_batch_exists():
    """Test batch existence check."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cache_dir = Path(tmpdir) / "cache"
        cache_dir.mkdir()
        
        index = CacheIndex(cache_dir)
        
        # Create some cache files
        (cache_dir / "key1.wav").touch()
        (cache_dir / "key2.pkl").touch()
        
        results = index.batch_exists(["key1", "key2", "key3"])
        
        assert results["key1"] is True
        assert results["key2"] is True
        assert results["key3"] is False


def test_cache_index_ttl():
    """Test that cache index respects TTL."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cache_dir = Path(tmpdir) / "cache"
        cache_dir.mkdir()
        
        # Use very short TTL for testing
        index = CacheIndex(cache_dir, ttl=0.1, auto_refresh=True)
        
        index.mark_exists("test_key")
        assert index.exists("test_key") is True
        
        # Wait for TTL to expire
        time.sleep(0.2)
        
        # Should still work with auto_refresh
        assert index.exists("test_key") is not None


def test_cache_index_clear():
    """Test clearing the index."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cache_dir = Path(tmpdir) / "cache"
        cache_dir.mkdir()
        
        index = CacheIndex(cache_dir)
        index.mark_exists("key1")
        index.mark_exists("key2")
        
        assert len(index._index) == 2
        
        index.clear()
        assert len(index._index) == 0


def test_cache_index_refresh():
    """Test refreshing index from filesystem."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cache_dir = Path(tmpdir) / "cache"
        cache_dir.mkdir()
        
        index = CacheIndex(cache_dir)
        
        # Create files after index creation
        (cache_dir / "key1.wav").touch()
        (cache_dir / "key2.pkl").touch()
        
        # Refresh should find them
        index.refresh()
        
        assert index.exists("key1") is True
        assert index.exists("key2") is True


def test_cache_index_stats():
    """Test getting index statistics."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cache_dir = Path(tmpdir) / "cache"
        cache_dir.mkdir()
        
        index = CacheIndex(cache_dir)
        index.mark_exists("key1")
        index.mark_missing("key2")
        
        stats = index.get_stats()
        
        assert stats["total_entries"] == 2
        assert stats["existing_entries"] == 1
        assert stats["missing_entries"] == 1


