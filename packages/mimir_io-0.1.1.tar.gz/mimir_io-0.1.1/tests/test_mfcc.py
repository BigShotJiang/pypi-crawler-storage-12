"""Tests for MFCC lenses."""

import pytest
import torch
from mimir_io.audio.mfcc import mfcc, mfcc_with_delta


def test_mfcc_basic():
    """Test basic MFCC computation."""
    lens = mfcc(sample_rate=16000, n_mfcc=13)
    waveform = torch.randn(1, 16000)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.dim() == 2
    assert result.shape[0] == 13  # n_mfcc


def test_mfcc_empty():
    """Test MFCC with empty waveform."""
    lens = mfcc(sample_rate=16000, n_mfcc=13)
    waveform = torch.tensor([])
    result = lens(waveform)
    assert result.shape == (13, 0)


def test_mfcc_custom_params():
    """Test MFCC with custom parameters."""
    lens = mfcc(
        sample_rate=22050,
        n_mfcc=20,
        n_fft=1024,
        hop_length=256,
        n_mels=64,
    )
    waveform = torch.randn(1, 22050)
    result = lens(waveform)
    assert result.shape[0] == 20


def test_mfcc_with_delta():
    """Test MFCC with delta features."""
    lens = mfcc_with_delta(sample_rate=16000, n_mfcc=13)
    waveform = torch.randn(1, 16000)
    result = lens(waveform)
    assert isinstance(result, torch.Tensor)
    assert result.shape == (3, 13, result.shape[2])  # (mfcc, delta, delta-delta)


def test_mfcc_with_delta_empty():
    """Test MFCC with delta on empty waveform."""
    lens = mfcc_with_delta(sample_rate=16000, n_mfcc=13)
    waveform = torch.tensor([])
    result = lens(waveform)
    assert result.shape == (3, 13, 0)


def test_mfcc_with_delta_invalid_win_length():
    """Test MFCC with delta with invalid win_length."""
    with pytest.raises(ValueError):
        mfcc_with_delta(sample_rate=16000, n_mfcc=13, delta_win_length=4)



