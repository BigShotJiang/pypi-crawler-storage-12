"""Tests for BaseTester."""

import pytest
import torch
import torch.nn as nn
from pathlib import Path
from torch.utils.data import DataLoader, TensorDataset
from mimir_io.models.tester import BaseTester


class SimpleModel(nn.Module):
    """Simple test model."""
    
    def __init__(self, input_size=10, num_classes=2):
        super().__init__()
        self.fc = nn.Linear(input_size, num_classes)
    
    def forward(self, x):
        return self.fc(x)


@pytest.fixture
def model():
    """Create a simple test model."""
    return SimpleModel(input_size=10, num_classes=2)


@pytest.fixture
def test_data():
    """Create test data."""
    features = torch.randn(100, 10)
    labels = torch.randint(0, 2, (100,))
    return features, labels


@pytest.fixture
def test_loader(test_data):
    """Create test DataLoader."""
    features, labels = test_data
    dataset = TensorDataset(features, labels)
    return DataLoader(dataset, batch_size=32, shuffle=False)


def test_tester_initialization(model, test_loader):
    """Test BaseTester initialization."""
    tester = BaseTester(
        model=model,
        test_loader=test_loader,
    )
    
    assert tester.model == model
    assert tester.test_loader == test_loader
    assert tester.device.type in ["cpu", "cuda"]


def test_tester_with_config(model, test_loader):
    """Test BaseTester with config."""
    config = {
        "testing": {
            "criterion": {
                "type": "CrossEntropyLoss",
            }
        }
    }
    
    tester = BaseTester(
        model=model,
        config=config,
        test_loader=test_loader,
    )
    
    assert tester.criterion is not None
    assert isinstance(tester.criterion, nn.CrossEntropyLoss)


def test_tester_load_checkpoint(tmp_path, model):
    """Test loading checkpoint."""
    checkpoint_path = tmp_path / "checkpoint.pt"
    
    # Save checkpoint
    torch.save({
        "model_state_dict": model.state_dict(),
    }, checkpoint_path)
    
    tester = BaseTester(
        model=model,
        checkpoint_path=checkpoint_path,
    )
    
    assert checkpoint_path.exists()


def test_tester_load_checkpoint_state_dict(tmp_path, model):
    """Test loading checkpoint with state_dict format."""
    checkpoint_path = tmp_path / "checkpoint.pt"
    
    # Save checkpoint as state_dict
    torch.save(model.state_dict(), checkpoint_path)
    
    tester = BaseTester(
        model=model,
        checkpoint_path=checkpoint_path,
    )
    
    assert checkpoint_path.exists()


def test_tester_load_checkpoint_not_found(tmp_path, model):
    """Test that missing checkpoint raises FileNotFoundError."""
    checkpoint_path = tmp_path / "nonexistent.pt"
    
    with pytest.raises(FileNotFoundError):
        BaseTester(
            model=model,
            checkpoint_path=checkpoint_path,
        )


def test_tester_test_epoch(model, test_loader):
    """Test test_epoch() method."""
    config = {
        "testing": {
            "criterion": {
                "type": "CrossEntropyLoss",
            }
        }
    }
    
    tester = BaseTester(
        model=model,
        config=config,
        test_loader=test_loader,
    )
    
    metrics = tester.test_epoch()
    
    assert "test_loss" in metrics
    assert "test_accuracy" in metrics
    assert isinstance(metrics["test_loss"], float)
    assert isinstance(metrics["test_accuracy"], float)
    assert 0 <= metrics["test_accuracy"] <= 100


def test_tester_test_epoch_without_criterion(model, test_loader):
    """Test test_epoch() without criterion."""
    tester = BaseTester(
        model=model,
        test_loader=test_loader,
    )
    
    metrics = tester.test_epoch()
    
    assert "test_accuracy" in metrics
    assert "test_loss" not in metrics  # No criterion, no loss


def test_tester_test_full(model, test_loader):
    """Test full test() method."""
    config = {
        "testing": {
            "criterion": {
                "type": "CrossEntropyLoss",
            }
        }
    }
    
    tester = BaseTester(
        model=model,
        config=config,
        test_loader=test_loader,
    )
    
    metrics = tester.test()
    
    assert "test_loss" in metrics
    assert "test_accuracy" in metrics
    assert "_predictions" in metrics
    assert "_labels" in metrics


def test_tester_test_without_loader(model):
    """Test that test() raises ValueError without loader."""
    tester = BaseTester(model=model)
    
    with pytest.raises(ValueError, match="test_loader is not set"):
        tester.test()


def test_tester_predict(model):
    """Test predict() method."""
    tester = BaseTester(model=model)
    
    features = torch.randn(5, 10)
    predictions = tester.predict(features)
    
    assert predictions.shape == (5, 2)  # (batch_size, num_classes)


def test_tester_predict_batch(model, test_loader):
    """Test predict_batch() method."""
    tester = BaseTester(
        model=model,
        test_loader=test_loader,
    )
    
    predictions = tester.predict_batch()
    
    assert isinstance(predictions, list)
    assert len(predictions) > 0
    assert all(isinstance(p, torch.Tensor) for p in predictions)


def test_tester_predict_batch_custom_loader(model, test_loader):
    """Test predict_batch() with custom loader."""
    tester = BaseTester(model=model)
    
    predictions = tester.predict_batch(test_loader)
    
    assert isinstance(predictions, list)
    assert len(predictions) > 0


def test_tester_predict_batch_without_loader(model):
    """Test that predict_batch() raises ValueError without loader."""
    tester = BaseTester(model=model)
    
    with pytest.raises(ValueError, match="dataloader is not set"):
        tester.predict_batch()


def test_tester_from_config(tmp_path, model, test_loader):
    """Test from_config() class method."""
    import yaml
    
    config = {
        "testing": {
            "criterion": {
                "type": "CrossEntropyLoss",
            }
        }
    }
    
    config_path = tmp_path / "config.yaml"
    with open(config_path, "w") as f:
        yaml.dump(config, f)
    
    tester = BaseTester.from_config(
        config_path=config_path,
        model=model,
        test_loader=test_loader,
    )
    
    assert tester.criterion is not None
    assert isinstance(tester.criterion, nn.CrossEntropyLoss)


def test_tester_callbacks(model, test_loader):
    """Test that callbacks are called during testing."""
    from mimir_io.models.callbacks import Callback
    
    callback_calls = []
    
    class TestCallback(Callback):
        def on_test_begin(self, tester):
            callback_calls.append("begin")
        
        def on_test_end(self, tester, metrics):
            callback_calls.append("end")
        
        def on_batch_begin(self, tester, batch_idx):
            callback_calls.append(f"batch_begin_{batch_idx}")
        
        def on_batch_end(self, tester, batch_idx, loss):
            callback_calls.append(f"batch_end_{batch_idx}")
    
    tester = BaseTester(
        model=model,
        test_loader=test_loader,
        callbacks=[TestCallback()],
    )
    
    tester.test()
    
    assert "begin" in callback_calls
    assert "end" in callback_calls
    assert any("batch_begin" in call for call in callback_calls)
    assert any("batch_end" in call for call in callback_calls)


def test_tester_device_cpu(model, test_loader):
    """Test explicit CPU device."""
    tester = BaseTester(
        model=model,
        test_loader=test_loader,
        device="cpu",
    )
    
    assert tester.device.type == "cpu"


def test_tester_metrics_structure(model, test_loader):
    """Test that metrics have correct structure."""
    config = {
        "testing": {
            "criterion": {
                "type": "CrossEntropyLoss",
            }
        }
    }
    
    tester = BaseTester(
        model=model,
        config=config,
        test_loader=test_loader,
    )
    
    metrics = tester.test()
    
    # Check required metrics
    assert "test_accuracy" in metrics
    assert "test_loss" in metrics
    
    # Check detailed predictions
    assert "_predictions" in metrics
    assert "_labels" in metrics
    assert len(metrics["_predictions"]) == len(metrics["_labels"])
    
    # Check probabilities if available
    if "_probabilities" in metrics:
        assert len(metrics["_probabilities"]) == len(metrics["_labels"])

