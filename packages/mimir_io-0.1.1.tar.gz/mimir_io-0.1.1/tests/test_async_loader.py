"""Tests for async audio loader."""

import pytest
import torch
import tempfile
import asyncio
from pathlib import Path
import torchaudio

try:
    # Try to use soundfile backend
    torchaudio.set_audio_backend("soundfile")
except Exception:
    pass

from mimir_io.async_loader import AsyncAudioLoader, get_default_loader, reset_default_loader


def _create_test_wav_file(path: Path, sample_rate: int = 16000, duration: float = 1.0):
    """Helper to create a test WAV file."""
    waveform = torch.randn(1, int(sample_rate * duration))
    waveform = torch.clamp(waveform, -1.0, 1.0)
    try:
        torchaudio.save(str(path), waveform, sample_rate)
    except Exception as e:
        pytest.skip(f"Cannot create test audio file: {e}")


@pytest.mark.asyncio
async def test_async_load_audio():
    """Test async loading of a single audio file."""
    with tempfile.TemporaryDirectory() as tmpdir:
        audio_file = Path(tmpdir) / "test.wav"
        _create_test_wav_file(audio_file)
        
        loader = AsyncAudioLoader(max_workers=2)
        waveform, sample_rate = await loader.load_audio_async(audio_file)
        
        assert isinstance(waveform, torch.Tensor)
        assert sample_rate == 16000
        assert waveform.numel() > 0
        
        loader.shutdown()


@pytest.mark.asyncio
async def test_async_load_audio_batch():
    """Test async batch loading of multiple audio files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        audio_files = []
        for i in range(3):
            audio_file = Path(tmpdir) / f"test_{i}.wav"
            _create_test_wav_file(audio_file)
            audio_files.append(audio_file)
        
        loader = AsyncAudioLoader(max_workers=2)
        results = await loader.load_audio_batch_async(audio_files)
        
        assert len(results) == 3
        for waveform, sample_rate in results:
            assert isinstance(waveform, torch.Tensor)
            assert sample_rate == 16000
            assert waveform.numel() > 0
        
        loader.shutdown()


def test_sync_load_audio_batch():
    """Test synchronous batch loading."""
    with tempfile.TemporaryDirectory() as tmpdir:
        audio_files = []
        for i in range(3):
            audio_file = Path(tmpdir) / f"test_{i}.wav"
            _create_test_wav_file(audio_file)
            audio_files.append(audio_file)
        
        loader = AsyncAudioLoader(max_workers=2)
        results = loader.load_audio_batch_sync(audio_files)
        
        assert len(results) == 3
        for waveform, sample_rate in results:
            assert isinstance(waveform, torch.Tensor)
            assert sample_rate == 16000
            assert waveform.numel() > 0
        
        loader.shutdown()


def test_async_loader_context_manager():
    """Test async loader as context manager."""
    with tempfile.TemporaryDirectory() as tmpdir:
        audio_file = Path(tmpdir) / "test.wav"
        _create_test_wav_file(audio_file)
        
        with AsyncAudioLoader(max_workers=2) as loader:
            results = loader.load_audio_batch_sync([audio_file])
            assert len(results) == 1


def test_get_default_loader():
    """Test getting default loader."""
    reset_default_loader()
    
    loader1 = get_default_loader()
    loader2 = get_default_loader()
    
    # Should return same instance
    assert loader1 is loader2
    
    reset_default_loader()


def test_reset_default_loader():
    """Test resetting default loader."""
    loader1 = get_default_loader()
    reset_default_loader()
    loader2 = get_default_loader()
    
    # Should be different instances
    assert loader1 is not loader2
    
    reset_default_loader()

