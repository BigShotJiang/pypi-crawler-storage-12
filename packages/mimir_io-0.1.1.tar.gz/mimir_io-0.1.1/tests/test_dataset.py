"""Tests for dataset management."""

import pytest
import tempfile
import shutil
from pathlib import Path
from mimir_io.dataset import Dataset
from mimir_io.lens import Lens, identity


def test_dataset_initialization():
    """Test dataset directory creation."""
    with tempfile.TemporaryDirectory() as tmpdir:
        dataset = Dataset(Path(tmpdir))
        assert dataset.data_dir.exists()
        assert dataset.cache_dir.exists()
        assert dataset.raw_dir.exists()


def test_dataset_apply_without_cache():
    """Test applying a lens without caching."""
    with tempfile.TemporaryDirectory() as tmpdir:
        dataset = Dataset(Path(tmpdir))
        lens = Lens(lambda x: x * 2, name="double")
        result = dataset.apply(lens, 5, use_cache=False)
        assert result == 10


def test_dataset_apply_with_cache():
    """Test applying a lens with caching."""
    with tempfile.TemporaryDirectory() as tmpdir:
        dataset = Dataset(Path(tmpdir))
        lens = Lens(lambda x: x * 2, name="double")

        # First application - should compute
        result1 = dataset.apply(lens, 5, use_cache=True)
        assert result1 == 10

        # Second application - should load from cache
        result2 = dataset.apply(lens, 5, use_cache=True)
        assert result2 == 10

        # Verify cache file exists
        cache_key = lens.cache_key(5)
        cache_path = dataset.cache_dir / f"{cache_key}.pkl"
        assert cache_path.exists()


def test_dataset_save_and_load_raw():
    """Test saving and loading raw data."""
    with tempfile.TemporaryDirectory() as tmpdir:
        dataset = Dataset(Path(tmpdir))
        data = {"test": "data", "numbers": [1, 2, 3]}

        dataset.save_raw(data, "test_data.pkl")
        loaded = dataset.load_raw("test_data.pkl")

        assert loaded == data


def test_dataset_load_raw_not_found():
    """Test loading non-existent raw data raises error."""
    with tempfile.TemporaryDirectory() as tmpdir:
        dataset = Dataset(Path(tmpdir))
        with pytest.raises(FileNotFoundError):
            dataset.load_raw("nonexistent.pkl")

