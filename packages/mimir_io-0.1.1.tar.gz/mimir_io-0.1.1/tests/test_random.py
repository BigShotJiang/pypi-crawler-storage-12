"""Tests for random seed management."""

import pytest
import torch
from mimir_io.random import (
    set_global_seed,
    get_global_seed,
    clear_global_seed,
    seed_context,
    get_seed,
    create_generator,
)


def test_set_global_seed():
    """Test setting global seed."""
    set_global_seed(42)
    assert get_global_seed() == 42
    
    set_global_seed(100)
    assert get_global_seed() == 100


def test_clear_global_seed():
    """Test clearing global seed."""
    set_global_seed(42)
    assert get_global_seed() == 42
    
    clear_global_seed()
    assert get_global_seed() is None


def test_set_global_seed_none():
    """Test setting global seed to None."""
    set_global_seed(42)
    set_global_seed(None)
    assert get_global_seed() is None


def test_get_seed_with_explicit():
    """Test get_seed() with explicit seed."""
    set_global_seed(42)
    
    # Explicit seed should take precedence
    assert get_seed(100) == 100
    assert get_seed(200) == 200


def test_get_seed_without_explicit():
    """Test get_seed() without explicit seed."""
    set_global_seed(42)
    assert get_seed() == 42
    
    clear_global_seed()
    assert get_seed() is None


def test_get_seed_none_explicit():
    """Test get_seed() with None explicit seed."""
    set_global_seed(42)
    
    # None explicit seed should use global seed
    assert get_seed(None) == 42


def test_create_generator_with_seed():
    """Test create_generator() with explicit seed."""
    gen = create_generator(42)
    
    # Generate some random numbers
    val1 = torch.rand(1, generator=gen).item()
    
    # Create new generator with same seed
    gen2 = create_generator(42)
    val2 = torch.rand(1, generator=gen2).item()
    
    # Should produce same value
    assert val1 == val2


def test_create_generator_with_global_seed():
    """Test create_generator() using global seed."""
    set_global_seed(42)
    
    gen1 = create_generator()
    val1 = torch.rand(1, generator=gen1).item()
    
    # Reset and create new generator
    set_global_seed(42)
    gen2 = create_generator()
    val2 = torch.rand(1, generator=gen2).item()
    
    assert val1 == val2


def test_create_generator_without_seed():
    """Test create_generator() without any seed."""
    clear_global_seed()
    
    gen = create_generator()
    # Should still work, just uses random seed
    val = torch.rand(1, generator=gen).item()
    assert isinstance(val, float)


def test_seed_context():
    """Test seed_context context manager."""
    set_global_seed(100)
    
    with seed_context(42):
        assert get_global_seed() == 42
        
        # Create generator inside context
        gen = create_generator()
        val_inside = torch.rand(1, generator=gen).item()
    
    # Seed should be restored
    assert get_global_seed() == 100
    
    # Verify reproducibility with restored seed
    set_global_seed(42)
    gen2 = create_generator()
    val_outside = torch.rand(1, generator=gen2).item()
    
    # Values should match (same seed 42)
    assert val_inside == val_outside


def test_seed_context_nested():
    """Test nested seed_context."""
    set_global_seed(100)
    
    with seed_context(50):
        assert get_global_seed() == 50
        
        with seed_context(25):
            assert get_global_seed() == 25
        
        # Should restore to 50
        assert get_global_seed() == 50
    
    # Should restore to 100
    assert get_global_seed() == 100


def test_seed_context_exception():
    """Test that seed_context restores seed even on exception."""
    set_global_seed(100)
    
    try:
        with seed_context(42):
            assert get_global_seed() == 42
            raise ValueError("Test exception")
    except ValueError:
        pass
    
    # Seed should be restored
    assert get_global_seed() == 100


def test_seed_context_none():
    """Test seed_context with None seed."""
    set_global_seed(100)
    
    with seed_context(None):
        assert get_global_seed() is None
    
    # Seed should be restored
    assert get_global_seed() == 100


def test_torch_seed_setting():
    """Test that set_global_seed sets torch seeds."""
    set_global_seed(42)
    
    # Generate random tensor
    val1 = torch.rand(1).item()
    
    # Reset seed and generate again
    set_global_seed(42)
    val2 = torch.rand(1).item()
    
    # Should produce same value
    assert val1 == val2


def test_torch_cuda_seed_setting():
    """Test that set_global_seed sets CUDA seeds if available."""
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")
    
    set_global_seed(42)
    
    # Generate random tensor on CUDA
    val1 = torch.rand(1, device="cuda").item()
    
    # Reset seed and generate again
    set_global_seed(42)
    val2 = torch.rand(1, device="cuda").item()
    
    # Should produce same value
    assert val1 == val2


def test_seed_context_torch_state():
    """Test that seed_context preserves torch RNG state."""
    set_global_seed(100)
    
    # Generate some random values
    val_before = torch.rand(1).item()
    
    with seed_context(42):
        val_inside = torch.rand(1).item()
    
    # Generate again after context
    val_after = torch.rand(1).item()
    
    # Reset to same state and verify reproducibility
    set_global_seed(100)
    val_before2 = torch.rand(1).item()
    
    assert val_before == val_before2


def test_multiple_generators_same_seed():
    """Test that multiple generators with same seed produce same sequence."""
    gen1 = create_generator(42)
    gen2 = create_generator(42)
    
    vals1 = [torch.rand(1, generator=gen1).item() for _ in range(5)]
    vals2 = [torch.rand(1, generator=gen2).item() for _ in range(5)]
    
    assert vals1 == vals2


def test_generator_independence():
    """Test that generators are independent."""
    gen1 = create_generator(42)
    gen2 = create_generator(100)
    
    val1 = torch.rand(1, generator=gen1).item()
    val2 = torch.rand(1, generator=gen2).item()
    
    # Should be different (different seeds)
    assert val1 != val2

