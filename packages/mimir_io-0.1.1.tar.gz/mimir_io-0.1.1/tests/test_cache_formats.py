"""Tests for cache format handlers."""

import pytest
import tempfile
import torch
import numpy as np
from pathlib import Path
from mimir_io.cache_formats import (
    AudioWAVFormat,
    ImagePNGFormat,
    PickleFormat,
    get_cache_format,
    save_cached_data,
    load_cached_data,
    cache_exists,
)
from mimir_io.rayframe import AudioRayFrame, ImageRayFrame


@pytest.fixture
def tmp_cache_dir():
    """Create temporary cache directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


def test_audio_wav_format_can_handle():
    """Test AudioWAVFormat.can_handle()."""
    waveform = torch.randn(16000)
    audio_frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    assert AudioWAVFormat.can_handle(audio_frame) is True
    assert AudioWAVFormat.can_handle("not_audio") is False


def test_audio_wav_format_save_and_load(tmp_cache_dir):
    """Test saving and loading AudioRayFrame in WAV format."""
    pytest.importorskip("soundfile")
    
    waveform = torch.randn(16000)
    audio_frame = AudioRayFrame(
        data=waveform,
        sample_rate=16000,
        metadata={"test": "value"},
    )
    
    data_path = tmp_cache_dir / "test_audio.wav"
    meta_path = tmp_cache_dir / "test_audio.wav.meta.json"
    
    AudioWAVFormat.save(audio_frame, data_path, meta_path)
    
    assert data_path.exists()
    assert meta_path.exists()
    
    # Load and verify
    loaded_frame = AudioWAVFormat.load(data_path, meta_path)
    
    assert isinstance(loaded_frame, AudioRayFrame)
    assert loaded_frame.sample_rate == 16000
    assert loaded_frame.metadata["test"] == "value"
    assert torch.allclose(loaded_frame.data, waveform, atol=1e-5)


def test_audio_wav_format_stereo(tmp_cache_dir):
    """Test saving and loading stereo audio."""
    pytest.importorskip("soundfile")
    
    waveform = torch.randn(2, 16000)  # Stereo
    audio_frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    data_path = tmp_cache_dir / "test_stereo.wav"
    meta_path = tmp_cache_dir / "test_stereo.wav.meta.json"
    
    AudioWAVFormat.save(audio_frame, data_path, meta_path)
    loaded_frame = AudioWAVFormat.load(data_path, meta_path)
    
    # Note: stereo audio is converted to mono during save (mean of channels)
    # AudioRayFrame.__post_init__ determines channels from data shape, not metadata
    # So after loading mono data, channels will be 1
    assert loaded_frame.channels == 1  # Data is mono, so channels=1
    assert loaded_frame.sample_rate == 16000
    # Data should be (1, T) after loading (AudioRayFrame adds channel dimension)
    assert loaded_frame.data.dim() == 2
    assert loaded_frame.data.shape[0] == 1  # Single channel


def test_image_png_format_can_handle():
    """Test ImagePNGFormat.can_handle()."""
    img_tensor = torch.randn(80, 100)
    image_frame = ImageRayFrame(data=img_tensor, sample_rate=16000)
    
    assert ImagePNGFormat.can_handle(image_frame) is True
    assert ImagePNGFormat.can_handle("not_image") is False


def test_image_png_format_save_and_load(tmp_cache_dir):
    """Test saving and loading ImageRayFrame in PNG format."""
    pytest.importorskip("PIL")
    
    img_tensor = torch.randn(80, 100)
    image_frame = ImageRayFrame(
        data=img_tensor,
        sample_rate=16000,
        metadata={"test": "value"},
    )
    
    data_path = tmp_cache_dir / "test_image.png"
    meta_path = tmp_cache_dir / "test_image.png.meta.json"
    
    ImagePNGFormat.save(image_frame, data_path, meta_path)
    
    assert data_path.exists()
    assert meta_path.exists()
    
    # Load and verify
    loaded_frame = ImagePNGFormat.load(data_path, meta_path)
    
    assert isinstance(loaded_frame, ImageRayFrame)
    assert loaded_frame.sample_rate == 16000
    assert loaded_frame.metadata["test"] == "value"
    assert loaded_frame.height == 80
    assert loaded_frame.width == 100


def test_image_png_format_3d(tmp_cache_dir):
    """Test saving and loading 3D image tensor."""
    pytest.importorskip("PIL")
    
    img_tensor = torch.randn(1, 80, 100)  # (C, H, W)
    image_frame = ImageRayFrame(data=img_tensor, sample_rate=16000)
    
    data_path = tmp_cache_dir / "test_3d.png"
    meta_path = tmp_cache_dir / "test_3d.png.meta.json"
    
    ImagePNGFormat.save(image_frame, data_path, meta_path)
    loaded_frame = ImagePNGFormat.load(data_path, meta_path)
    
    assert loaded_frame.data.dim() >= 2


def test_pickle_format_can_handle():
    """Test PickleFormat.can_handle()."""
    assert PickleFormat.can_handle("anything") is True
    assert PickleFormat.can_handle(123) is True
    assert PickleFormat.can_handle([1, 2, 3]) is True


def test_pickle_format_save_and_load(tmp_cache_dir):
    """Test saving and loading with PickleFormat."""
    test_data = {"key": "value", "number": 42, "list": [1, 2, 3]}
    
    data_path = tmp_cache_dir / "test.pkl"
    meta_path = tmp_cache_dir / "test.pkl.meta.json"
    
    PickleFormat.save(test_data, data_path, meta_path)
    
    assert data_path.exists()
    
    loaded_data = PickleFormat.load(data_path, meta_path)
    
    assert loaded_data == test_data


def test_get_cache_format():
    """Test get_cache_format() function."""
    waveform = torch.randn(16000)
    audio_frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    assert get_cache_format(audio_frame) == AudioWAVFormat
    
    img_tensor = torch.randn(80, 100)
    image_frame = ImageRayFrame(data=img_tensor, sample_rate=16000)
    
    assert get_cache_format(image_frame) == ImagePNGFormat
    
    # Should fallback to PickleFormat
    assert get_cache_format("random_data") == PickleFormat


def test_save_cached_data(tmp_cache_dir):
    """Test save_cached_data() function."""
    pytest.importorskip("soundfile")
    
    waveform = torch.randn(16000)
    audio_frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    cache_path = tmp_cache_dir / "cached_audio"
    save_cached_data(audio_frame, cache_path)
    
    assert cache_path.with_suffix(".wav").exists()
    assert cache_path.with_suffix(".wav.meta.json").exists()


def test_load_cached_data(tmp_cache_dir):
    """Test load_cached_data() function."""
    pytest.importorskip("soundfile")
    
    waveform = torch.randn(16000)
    audio_frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    cache_path = tmp_cache_dir / "cached_audio"
    save_cached_data(audio_frame, cache_path)
    
    loaded_frame = load_cached_data(cache_path)
    
    assert isinstance(loaded_frame, AudioRayFrame)
    assert torch.allclose(loaded_frame.data, waveform, atol=1e-5)


def test_load_cached_data_not_found(tmp_cache_dir):
    """Test load_cached_data() raises FileNotFoundError for missing cache."""
    cache_path = tmp_cache_dir / "nonexistent"
    
    with pytest.raises(FileNotFoundError):
        load_cached_data(cache_path)


def test_cache_exists(tmp_cache_dir):
    """Test cache_exists() function."""
    pytest.importorskip("soundfile")
    
    waveform = torch.randn(16000)
    audio_frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    cache_path = tmp_cache_dir / "cached_audio"
    
    assert cache_exists(cache_path) is False
    
    save_cached_data(audio_frame, cache_path)
    
    assert cache_exists(cache_path) is True


def test_cache_formats_get_extension():
    """Test get_extension() methods."""
    assert AudioWAVFormat.get_extension() == ".wav"
    assert ImagePNGFormat.get_extension() == ".png"
    assert PickleFormat.get_extension() == ".pkl"


def test_audio_wav_format_missing_soundfile(monkeypatch):
    """Test that AudioWAVFormat raises ImportError without soundfile."""
    # Skip if soundfile is not installed (can't test missing import if it's already missing)
    try:
        import soundfile
    except ImportError:
        pytest.skip("soundfile not installed, cannot test missing import")
    
    waveform = torch.randn(16000)
    audio_frame = AudioRayFrame(data=waveform, sample_rate=16000)
    
    # Mock import to raise ImportError
    import sys
    original_import = __import__
    
    def mock_import(name, *args, **kwargs):
        if name == "soundfile":
            raise ImportError("No module named 'soundfile'")
        return original_import(name, *args, **kwargs)
    
    monkeypatch.setattr("builtins.__import__", mock_import)
    
    # Remove soundfile from sys.modules
    soundfile_backup = sys.modules.pop("soundfile", None)
    
    try:
        with pytest.raises(ImportError, match="soundfile is required"):
            AudioWAVFormat.save(audio_frame, Path("/tmp/test.wav"), Path("/tmp/test.wav.meta.json"))
    finally:
        # Restore soundfile if it was there
        if soundfile_backup is not None:
            sys.modules["soundfile"] = soundfile_backup


def test_image_png_format_missing_pillow(monkeypatch):
    """Test that ImagePNGFormat raises ImportError without Pillow."""
    # Skip if PIL is not installed (can't test missing import if it's already missing)
    try:
        from PIL import Image
    except ImportError:
        pytest.skip("PIL not installed, cannot test missing import")
    
    img_tensor = torch.randn(80, 100)
    image_frame = ImageRayFrame(data=img_tensor, sample_rate=16000)
    
    # Mock import to raise ImportError
    import sys
    original_import = __import__
    
    def mock_import(name, *args, **kwargs):
        if name == "PIL" or (isinstance(name, str) and name.startswith("PIL")):
            raise ImportError("No module named 'PIL'")
        return original_import(name, *args, **kwargs)
    
    monkeypatch.setattr("builtins.__import__", mock_import)
    
    # Remove PIL from sys.modules
    pil_backup = sys.modules.pop("PIL", None)
    pil_image_backup = sys.modules.pop("PIL.Image", None)
    
    try:
        with pytest.raises(ImportError, match="Pillow is required"):
            ImagePNGFormat.save(image_frame, Path("/tmp/test.png"), Path("/tmp/test.png.meta.json"))
    finally:
        # Restore PIL if it was there
        if pil_backup is not None:
            sys.modules["PIL"] = pil_backup
        if pil_image_backup is not None:
            sys.modules["PIL.Image"] = pil_image_backup

