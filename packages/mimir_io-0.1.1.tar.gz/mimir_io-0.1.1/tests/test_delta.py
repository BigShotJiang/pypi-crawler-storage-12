"""Tests for delta and delta-delta features."""

import pytest
import torch
from mimir_io.audio.spectrogram import delta, delta_delta, stack_delta_features


def test_delta_basic():
    """Test basic delta computation."""
    lens = delta(win_length=5)
    # Create a simple Mel spectrogram (n_mels, time_frames)
    mel_spec = torch.randn(80, 100)
    result = lens(mel_spec)
    assert isinstance(result, torch.Tensor)
    assert result.shape == mel_spec.shape


def test_delta_empty():
    """Test delta with empty spectrogram."""
    lens = delta()
    mel_spec = torch.empty(80, 0)
    result = lens(mel_spec)
    assert result.shape == mel_spec.shape


def test_delta_multichannel():
    """Test delta with multi-channel spectrogram."""
    lens = delta(win_length=5)
    # Multi-channel spectrogram (channels, n_mels, time_frames)
    mel_spec = torch.randn(1, 80, 100)
    result = lens(mel_spec)
    assert result.shape == mel_spec.shape


def test_delta_different_win_lengths():
    """Test delta with different window lengths."""
    mel_spec = torch.randn(80, 100)
    
    for win_length in [3, 5, 7, 9]:
        lens = delta(win_length=win_length)
        result = lens(mel_spec)
        assert result.shape == mel_spec.shape


def test_delta_invalid_win_length():
    """Test delta with invalid (even) win_length."""
    with pytest.raises(ValueError):
        delta(win_length=4)


def test_delta_delta_basic():
    """Test basic delta-delta computation."""
    lens = delta_delta(win_length=5)
    mel_spec = torch.randn(80, 100)
    result = lens(mel_spec)
    assert isinstance(result, torch.Tensor)
    assert result.shape == mel_spec.shape


def test_delta_delta_empty():
    """Test delta-delta with empty spectrogram."""
    lens = delta_delta()
    mel_spec = torch.empty(80, 0)
    result = lens(mel_spec)
    assert result.shape == mel_spec.shape


def test_delta_delta_is_delta_of_delta():
    """Test that delta-delta is indeed delta of delta."""
    mel_spec = torch.randn(80, 100)
    
    delta_lens = delta(win_length=5)
    delta_delta_lens = delta_delta(win_length=5)
    
    # Compute delta manually
    delta_features = delta_lens(mel_spec)
    delta_of_delta = delta_lens(delta_features)
    
    # Compare with delta_delta
    delta_delta_features = delta_delta_lens(mel_spec)
    
    assert torch.allclose(delta_delta_features, delta_of_delta, atol=1e-5)


def test_stack_delta_features_basic():
    """Test stacking delta features."""
    lens = stack_delta_features(win_length=5)
    mel_spec = torch.randn(80, 100)
    result = lens(mel_spec)
    assert isinstance(result, torch.Tensor)
    assert result.shape == (3, 80, 100)  # (original, delta, delta-delta)


def test_stack_delta_features_empty():
    """Test stacking with empty spectrogram."""
    lens = stack_delta_features()
    mel_spec = torch.empty(80, 0)
    result = lens(mel_spec)
    assert result.shape == (3, 80, 0)


def test_stack_delta_features_multichannel():
    """Test stacking with multi-channel spectrogram."""
    lens = stack_delta_features(win_length=5)
    # Multi-channel input (channels, n_mels, time_frames)
    mel_spec = torch.randn(1, 80, 100)
    result = lens(mel_spec)
    # Should stack along new dimension
    assert result.shape == (3, 1, 80, 100)


def test_stack_delta_features_content():
    """Test that stacked features contain original, delta, and delta-delta."""
    lens = stack_delta_features(win_length=5)
    mel_spec = torch.randn(80, 100)
    stacked = lens(mel_spec)
    
    # First channel should be original
    assert torch.allclose(stacked[0], mel_spec, atol=1e-5)
    
    # Second channel should be delta
    delta_lens = delta(win_length=5)
    expected_delta = delta_lens(mel_spec)
    assert torch.allclose(stacked[1], expected_delta, atol=1e-5)
    
    # Third channel should be delta-delta
    delta_delta_lens = delta_delta(win_length=5)
    expected_delta_delta = delta_delta_lens(mel_spec)
    assert torch.allclose(stacked[2], expected_delta_delta, atol=1e-5)


def test_delta_different_modes():
    """Test delta with different padding modes."""
    mel_spec = torch.randn(80, 100)
    
    for mode in ["replicate", "constant", "reflect"]:
        lens = delta(win_length=5, mode=mode)
        result = lens(mel_spec)
        assert result.shape == mel_spec.shape

