"""Tests for advanced audio augmentation lenses."""

import pytest
import torch
from mimir_io.audio.augment import (
    time_stretch,
    reverb,
    bandpass_filter,
    highpass_filter,
    lowpass_filter,
    polarity_inversion,
    clipping_distortion,
    echo,
)


def test_time_stretch():
    """Test time stretch augmentation."""
    lens = time_stretch(sample_rate=16000, min_rate=0.9, max_rate=1.1)
    waveform = torch.randn(1, 16000)

    stretched = lens(waveform)
    assert isinstance(stretched, torch.Tensor)
    assert stretched.shape == waveform.shape


def test_time_stretch_empty():
    """Test time stretch with empty tensor."""
    lens = time_stretch(sample_rate=16000)
    waveform = torch.tensor([])

    stretched = lens(waveform)
    assert stretched.numel() == 0


def test_reverb():
    """Test reverb augmentation."""
    lens = reverb(room_size=0.3, damping=0.5)
    waveform = torch.randn(1, 1000)

    reverbed = lens(waveform)
    assert isinstance(reverbed, torch.Tensor)
    assert reverbed.shape == waveform.shape


def test_reverb_custom_ir():
    """Test reverb with custom impulse response."""
    ir = torch.randn(100)
    lens = reverb(impulse_response=ir)
    waveform = torch.randn(1, 1000)

    reverbed = lens(waveform)
    assert isinstance(reverbed, torch.Tensor)
    assert reverbed.shape == waveform.shape


def test_bandpass_filter():
    """Test bandpass filter augmentation."""
    lens = bandpass_filter(sample_rate=16000, low_freq=300, high_freq=3400)
    waveform = torch.randn(1, 1000)

    filtered = lens(waveform)
    assert isinstance(filtered, torch.Tensor)
    assert filtered.shape == waveform.shape


def test_highpass_filter():
    """Test highpass filter augmentation."""
    lens = highpass_filter(sample_rate=16000, cutoff_freq=80)
    waveform = torch.randn(1, 1000)

    filtered = lens(waveform)
    assert isinstance(filtered, torch.Tensor)
    assert filtered.shape == waveform.shape


def test_lowpass_filter():
    """Test lowpass filter augmentation."""
    lens = lowpass_filter(sample_rate=16000, cutoff_freq=8000)
    waveform = torch.randn(1, 1000)

    filtered = lens(waveform)
    assert isinstance(filtered, torch.Tensor)
    assert filtered.shape == waveform.shape


def test_polarity_inversion():
    """Test polarity inversion augmentation."""
    lens = polarity_inversion()
    waveform = torch.randn(1, 1000)

    inverted = lens(waveform)
    assert isinstance(inverted, torch.Tensor)
    assert inverted.shape == waveform.shape
    # Should either be original or inverted
    assert torch.equal(inverted, waveform) or torch.equal(inverted, -waveform)


def test_clipping_distortion():
    """Test clipping distortion augmentation."""
    lens = clipping_distortion(min_threshold=0.7, max_threshold=0.95)
    waveform = torch.randn(1, 1000)

    clipped = lens(waveform)
    assert isinstance(clipped, torch.Tensor)
    assert clipped.shape == waveform.shape
    # Clipped values should be within range
    assert torch.all(torch.abs(clipped) <= 1.0 + 1e-5)


def test_echo():
    """Test echo augmentation."""
    lens = echo(sample_rate=16000, delay_ms=100, decay=0.3, num_echos=1)
    waveform = torch.randn(1, 16000)

    echoed = lens(waveform)
    assert isinstance(echoed, torch.Tensor)
    assert echoed.shape == waveform.shape
    # Echoed signal should be normalized
    assert torch.all(torch.abs(echoed) <= 1.0 + 1e-5)


def test_echo_empty():
    """Test echo with empty tensor."""
    lens = echo(sample_rate=16000)
    waveform = torch.tensor([])

    echoed = lens(waveform)
    assert echoed.numel() == 0


def test_echo_multiple():
    """Test echo with multiple echoes."""
    lens = echo(sample_rate=16000, delay_ms=50, decay=0.5, num_echos=3)
    waveform = torch.randn(1, 16000)

    echoed = lens(waveform)
    assert isinstance(echoed, torch.Tensor)
    assert echoed.shape == waveform.shape



