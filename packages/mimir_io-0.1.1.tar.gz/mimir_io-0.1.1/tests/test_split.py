"""Tests for dataset splitting utilities."""

import pytest
import tempfile
import shutil
from pathlib import Path
from mimir_io.split import (
    DatasetSplit,
    split_dataset,
    split_by_directory,
    split_by_metadata,
    load_from_class_directories,
    split_by_class_directories,
)


def test_dataset_split_initialization():
    """Test DatasetSplit initialization."""
    train_files = ["train1.wav", "train2.wav"]
    val_files = ["val1.wav"]
    test_files = ["test1.wav"]
    
    split = DatasetSplit(
        train_files=train_files,
        val_files=val_files,
        test_files=test_files,
        train_labels=[0, 1],
        val_labels=[0],
        test_labels=[1],
    )
    
    assert len(split.train_files) == 2
    assert len(split.val_files) == 1
    assert len(split.test_files) == 1
    assert split.train_labels == [0, 1]
    assert split.val_labels == [0]
    assert split.test_labels == [1]


def test_dataset_split_repr():
    """Test DatasetSplit string representation."""
    split = DatasetSplit(
        train_files=["train1.wav"],
        val_files=["val1.wav"],
        test_files=["test1.wav"],
    )
    repr_str = repr(split)
    assert "train=1" in repr_str
    assert "val=1" in repr_str
    assert "test=1" in repr_str


def test_dataset_split_save_and_load(tmp_path):
    """Test saving and loading DatasetSplit."""
    split = DatasetSplit(
        train_files=["train1.wav", "train2.wav"],
        val_files=["val1.wav"],
        test_files=["test1.wav"],
        train_labels=[0, 1],
        val_labels=[0],
        test_labels=[1],
        metadata={"seed": 42},
    )
    
    save_path = tmp_path / "split.json"
    split.save(save_path)
    
    assert save_path.exists()
    
    # Load and verify
    loaded_split = DatasetSplit.load(save_path)
    assert len(loaded_split.train_files) == 2
    assert len(loaded_split.val_files) == 1
    assert len(loaded_split.test_files) == 1
    assert loaded_split.train_labels == [0, 1]
    assert loaded_split.val_labels == [0]
    assert loaded_split.test_labels == [1]
    assert loaded_split.metadata["seed"] == 42


def test_split_dataset_basic():
    """Test basic dataset splitting."""
    file_paths = [f"file{i}.wav" for i in range(100)]
    labels = [i % 2 for i in range(100)]  # Binary labels
    
    split = split_dataset(
        file_paths=file_paths,
        labels=labels,
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15,
        seed=42,
    )
    
    assert len(split.train_files) == 70
    assert len(split.val_files) == 15
    assert len(split.test_files) == 15
    assert len(split.train_files) + len(split.val_files) + len(split.test_files) == 100


def test_split_dataset_without_labels():
    """Test splitting without labels."""
    file_paths = [f"file{i}.wav" for i in range(100)]
    
    split = split_dataset(
        file_paths=file_paths,
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15,
        seed=42,
    )
    
    assert len(split.train_files) == 70
    assert len(split.val_files) == 15
    assert len(split.test_files) == 15
    assert split.train_labels is None
    assert split.val_labels is None
    assert split.test_labels is None


def test_split_dataset_stratified():
    """Test stratified splitting."""
    file_paths = [f"file{i}.wav" for i in range(100)]
    labels = [i % 2 for i in range(100)]  # Binary labels
    
    split = split_dataset(
        file_paths=file_paths,
        labels=labels,
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15,
        stratify=True,
        seed=42,
    )
    
    # Check that all splits have roughly equal class distribution
    train_labels = split.train_labels
    val_labels = split.val_labels
    test_labels = split.test_labels
    
    assert train_labels is not None
    assert val_labels is not None
    assert test_labels is not None
    
    # Check class distribution (should be roughly 50/50 in each split)
    # Stratified split should maintain class distribution, but allow some variance
    train_class0 = sum(1 for l in train_labels if l == 0)
    train_class1 = sum(1 for l in train_labels if l == 1)
    # Allow up to 15% difference (70% of 100 = 70 files, so 15% = ~10 files)
    assert abs(train_class0 - train_class1) <= 15  # Allow reasonable difference


def test_split_dataset_invalid_ratios():
    """Test that invalid ratios raise ValueError."""
    file_paths = [f"file{i}.wav" for i in range(100)]
    
    with pytest.raises(ValueError, match="Ratios must sum to 1.0"):
        split_dataset(
            file_paths=file_paths,
            train_ratio=0.8,
            val_ratio=0.15,
            test_ratio=0.15,
        )


def test_split_dataset_stratify_without_labels():
    """Test that stratify=True without labels raises ValueError."""
    file_paths = [f"file{i}.wav" for i in range(100)]
    
    with pytest.raises(ValueError, match="stratify=True requires labels"):
        split_dataset(
            file_paths=file_paths,
            stratify=True,
        )


def test_split_dataset_reproducibility():
    """Test that splitting with same seed produces same results."""
    file_paths = [f"file{i}.wav" for i in range(100)]
    
    split1 = split_dataset(file_paths=file_paths, seed=42)
    split2 = split_dataset(file_paths=file_paths, seed=42)
    
    assert split1.train_files == split2.train_files
    assert split1.val_files == split2.val_files
    assert split1.test_files == split2.test_files


def test_split_by_directory(tmp_path):
    """Test splitting by directory structure."""
    # Create directory structure
    train_dir = tmp_path / "train"
    val_dir = tmp_path / "val"
    test_dir = tmp_path / "test"
    
    train_dir.mkdir()
    val_dir.mkdir()
    test_dir.mkdir()
    
    # Create test files
    (train_dir / "train1.wav").touch()
    (train_dir / "train2.wav").touch()
    (val_dir / "val1.wav").touch()
    (test_dir / "test1.wav").touch()
    
    split = split_by_directory(tmp_path)
    
    assert len(split.train_files) == 2
    assert len(split.val_files) == 1
    assert len(split.test_files) == 1
    assert split.metadata["method"] == "directory_based"


def test_split_by_directory_with_extensions(tmp_path):
    """Test splitting by directory with extension filter."""
    train_dir = tmp_path / "train"
    train_dir.mkdir()
    
    (train_dir / "file1.wav").touch()
    (train_dir / "file2.mp3").touch()
    (train_dir / "file3.txt").touch()
    
    split = split_by_directory(
        tmp_path,
        test_dir=None,  # No test directory
        extensions=[".wav", ".mp3"],
    )
    
    assert len(split.train_files) == 2  # Only .wav and .mp3
    assert all(f.suffix.lower() in [".wav", ".mp3"] for f in split.train_files)


def test_split_by_metadata():
    """Test splitting by metadata."""
    file_paths = [f"file{i}.wav" for i in range(100)]
    
    def get_speaker_metadata(file_path):
        """Extract speaker ID from filename."""
        return {"speaker": int(Path(file_path).stem.replace("file", "")) % 3}
    
    split = split_by_metadata(
        file_paths=file_paths,
        metadata_func=get_speaker_metadata,
        stratify_by="speaker",
        seed=42,
    )
    
    assert len(split.train_files) == 70
    assert len(split.val_files) == 15
    assert len(split.test_files) == 15


def test_load_from_class_directories(tmp_path):
    """Test loading from class directories."""
    # Create class directories
    cat_dir = tmp_path / "cat"
    dog_dir = tmp_path / "dog"
    cat_dir.mkdir()
    dog_dir.mkdir()
    
    # Create files
    (cat_dir / "cat1.wav").touch()
    (cat_dir / "cat2.wav").touch()
    (dog_dir / "dog1.wav").touch()
    (dog_dir / "dog2.wav").touch()
    
    file_paths, labels, class_map = load_from_class_directories(tmp_path)
    
    assert len(file_paths) == 4
    assert len(labels) == 4
    assert class_map == {"cat": 0, "dog": 1}
    assert labels.count(0) == 2  # 2 cats
    assert labels.count(1) == 2  # 2 dogs


def test_load_from_class_directories_with_extensions(tmp_path):
    """Test loading from class directories with extension filter."""
    cat_dir = tmp_path / "cat"
    cat_dir.mkdir()
    
    (cat_dir / "cat1.wav").touch()
    (cat_dir / "cat2.mp3").touch()
    (cat_dir / "cat3.txt").touch()
    
    file_paths, labels, class_map = load_from_class_directories(
        tmp_path,
        extensions=[".wav", ".mp3"],
    )
    
    assert len(file_paths) == 2  # Only .wav and .mp3


def test_load_from_class_directories_not_found():
    """Test that non-existent directory raises ValueError."""
    with pytest.raises(ValueError, match="Data directory does not exist"):
        load_from_class_directories("/nonexistent/path")


def test_load_from_class_directories_no_classes(tmp_path):
    """Test that directory with no class subdirectories raises ValueError."""
    tmp_path.mkdir(exist_ok=True)
    
    with pytest.raises(ValueError, match="No class directories found"):
        load_from_class_directories(tmp_path)


def test_split_by_class_directories(tmp_path):
    """Test splitting by class directories."""
    # Create class directories
    cat_dir = tmp_path / "cat"
    dog_dir = tmp_path / "dog"
    cat_dir.mkdir()
    dog_dir.mkdir()
    
    # Create multiple files per class
    for i in range(10):
        (cat_dir / f"cat{i}.wav").touch()
        (dog_dir / f"dog{i}.wav").touch()
    
    split = split_by_class_directories(
        tmp_path,
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15,
        stratify=True,
        seed=42,
    )
    
    assert len(split.train_files) == 14  # 70% of 20 files
    assert len(split.val_files) == 3
    assert len(split.test_files) == 3
    assert "class_to_label" in split.metadata
    assert split.metadata["num_classes"] == 2


def test_split_by_class_directories_no_files(tmp_path):
    """Test that empty directory raises ValueError."""
    tmp_path.mkdir(exist_ok=True)
    (tmp_path / "empty").mkdir(exist_ok=True)
    
    with pytest.raises(ValueError, match="No files found"):
        split_by_class_directories(tmp_path)

