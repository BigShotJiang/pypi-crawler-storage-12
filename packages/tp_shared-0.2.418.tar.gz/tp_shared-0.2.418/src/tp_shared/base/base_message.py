from tp_helper import BaseSchema


class BaseMessage(BaseSchema):
    version: str = "1.0"
