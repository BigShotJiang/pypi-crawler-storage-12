# This directory contains pure python modules to use when the c modules fail to import
