print('Warning: The as3lib.toplevel module is deprecated. Import as3lib instead.')
from as3lib._toplevel.Array import *
from as3lib._toplevel.Boolean import *
from as3lib._toplevel.Constants import *
from as3lib._toplevel.Date import *
from as3lib._toplevel.Errors import *
from as3lib._toplevel.Functions import *
from as3lib._toplevel.int import int as Int
from as3lib._toplevel.JSON import *
from as3lib._toplevel.Math import *
from as3lib._toplevel.Namespace import *
from as3lib._toplevel.Number import *
from as3lib._toplevel.Object import *
from as3lib._toplevel.QName import *
from as3lib._toplevel.RegExp import *
from as3lib._toplevel.String import *
from as3lib._toplevel.trace import *
from as3lib._toplevel.Types import *
from as3lib._toplevel.uint import *
from as3lib._toplevel.Vector import *
