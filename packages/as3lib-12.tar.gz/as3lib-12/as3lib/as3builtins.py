print('Warning: The as3lib.as3builtins module is deprecated. Import as3lib instead.')
from as3lib import formatToString, as3import
