from as3lib._toplevel.Object import Object


class uint(Object):...
