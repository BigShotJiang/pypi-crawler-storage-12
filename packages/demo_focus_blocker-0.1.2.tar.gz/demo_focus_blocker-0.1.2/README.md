# Demo Focus Blocker

A simple Python package to help you stay focused by blocking distracting websites during work hours.

## Installation

```bash
pip install demo-focus-blocker
