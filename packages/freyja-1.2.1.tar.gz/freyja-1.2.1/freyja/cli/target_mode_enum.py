import enum


class TargetModeEnum(enum.Enum):
    """Target mode enum for command discovery."""

    CLASS = "class"
