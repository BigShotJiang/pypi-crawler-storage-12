import logging

AppLogger: logging.Logger = logging.getLogger('freyja')
