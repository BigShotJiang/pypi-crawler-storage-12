def main() -> None:
    print("Hello from streamable-server-1113!")
