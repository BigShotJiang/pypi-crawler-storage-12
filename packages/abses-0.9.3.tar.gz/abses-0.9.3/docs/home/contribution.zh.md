# :material-human-handsup: 欢迎贡献

## 提问

- 在 [GitHub Discussions] 上提出使用问题（"如何做？"）。
- 对于不太明确的问题、想法或宣布其他用户感兴趣的项目，请使用[邮件列表]。

## 报告 bug 和代码贡献

- 在 [GitHub issues] 上报告 bug、建议功能或查看源代码。
- 如果您是 _`ABSESpy`_ 或开源开发的新手，我们建议浏览 [GitHub issues] 标签以找到您感兴趣的问题。

<!-- Links -->
  [邮件列表]: https://groups.google.com/g/absespy
  [GitHub Discussions]: https://github.com/SongshGeoLab/ABSESpy/discussions
  [GitHub issues]: https://github.com/SongshGeoLab/ABSESpy/issues

