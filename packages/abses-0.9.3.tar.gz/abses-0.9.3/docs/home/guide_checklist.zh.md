# 找到您使用 `ABSESpy` 的起点

## :thinking: `ABSESpy` 适合我吗？

要使用 `ABSESpy`，您最好具有 [Python] 的基本经验。然后，选择最符合您知识背景的描述：

[:computer: 我熟悉 ABM](../tutorial/tutorial_guide_from_ABM.md){ .md-button }
[:earth_asia: 我熟悉 SES](../tutorial/tutorial_guide_from_SES.md){ .md-button }

:hatching_chick: 如果您不熟悉 ABM 或 SES，我们建议访问我们的 [wiki 页面]以获得基本了解。

