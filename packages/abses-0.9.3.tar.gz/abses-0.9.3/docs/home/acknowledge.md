---
title: acknowledge
authors: SongshGeo
date: 2023-01-10
---

## Sponsors

- This package has been supported by the National Natural Science Foundation of China (grant no. 42041007) and the National Natural Science Foundation of China Joint Fund for Scientific Research on Yellow River (grant no. U2243601).

## Thanks to all contributors

<a href="https://github.com/SongshGeoLab/ABSESpy/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=SongshGeoLab/ABSESpy" />
</a>
