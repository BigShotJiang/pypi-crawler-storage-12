# Model from community

> [!INFO]In Progress
> As a new package, we don't have any model submission so far. You're warm welcome to submit your ABM project.

!!! Warning

    The community model is a result of contributions from `ABSESpy` users, and we do not guarantee the safety of its operation.
