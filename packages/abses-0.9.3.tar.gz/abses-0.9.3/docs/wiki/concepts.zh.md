
<div class="grid" markdown>

[:book: __涌现__](concepts/emergence.md)
{ .card }

[:book: __复杂适应系统__](concepts/complex_adaptive_systems.md)
{ .card }

[:book: __CCR 框架__](concepts/CCR.md)
{ .card }

> :book: __Huh__ ... 如果您想了解任何特定概念，[告诉我们]。

</div>

<!-- Links -->
  [告诉我们]: https://groups.google.com/g/absespy

