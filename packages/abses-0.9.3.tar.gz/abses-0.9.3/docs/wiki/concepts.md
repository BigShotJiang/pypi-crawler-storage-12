
<div class="grid" markdown>

[:book: __Emergence__](concepts/emergence.md)
{ .card }

[:book: __Complex Adaptive System__](concepts/complex_adaptive_systems.md)
{ .card }

[:book: __CCR Framework__](concepts/CCR.md)
{ .card }

> :book: __Huh__ ... If you want to know any specific concept, [tell us].

</div>


<!-- Links -->
  [tell us]: https://groups.google.com/g/absespy
