---
title: Actor (Agent)
authors: SongshGeo
date: 2023-01-10
---

:::abses.agents.actor.Actor
