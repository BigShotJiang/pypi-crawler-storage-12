---
title: nature
authors: SongshGeo
date: 2023-01-10
---

:::abses.space.nature.BaseNature
    options:
      show_root_heading: false
      heading_level: 1
