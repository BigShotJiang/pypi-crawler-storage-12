class SkeletonPrim:
    def __init__(self, names, parents, bind_transforms, rest_transforms):
        self.names = names
        self.parents = parents
        self.bind_transforms = bind_transforms
        self.rest_transforms = rest_transforms

