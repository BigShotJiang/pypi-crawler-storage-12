# Sphinx APA References

A simple Sphinx extension that allows you to have APA formatting of references in your book.