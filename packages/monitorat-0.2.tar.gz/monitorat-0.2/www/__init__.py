"""
Intentionally empty so Hatch can treat `www` as a package when building wheels.
"""
