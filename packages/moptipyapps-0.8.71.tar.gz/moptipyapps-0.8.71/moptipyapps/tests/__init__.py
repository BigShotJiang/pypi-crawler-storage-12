"""
Unit tests that you can use to check your moptipyapps based experiments.

- :mod:`moptipyapps.tests.on_binpacking2d` contains tests on the
  two-dimensional bin packing problem.
"""
