# ArteLib

Current Version: 1

Smart python lib

## Inclusions

### speak:

Functions:

say(text: str, speed: int = 180): text - required, speed - default 180

It can speeak

### web

Functions:

Web( __ name __)

It can make website (with only localhost)

## Installation

```bash
pip install artelib