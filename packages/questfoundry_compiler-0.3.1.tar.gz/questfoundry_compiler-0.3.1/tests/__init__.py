"""Tests for the spec compiler."""
