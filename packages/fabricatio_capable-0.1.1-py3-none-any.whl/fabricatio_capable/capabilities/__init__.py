"""Capabilities defined in fabricatio-capable."""
