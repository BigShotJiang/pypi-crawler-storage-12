"""Actions defined in fabricatio-capable."""
