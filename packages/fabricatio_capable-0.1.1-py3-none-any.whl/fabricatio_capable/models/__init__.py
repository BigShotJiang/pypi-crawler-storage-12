"""Models defined in fabricatio-capable."""
