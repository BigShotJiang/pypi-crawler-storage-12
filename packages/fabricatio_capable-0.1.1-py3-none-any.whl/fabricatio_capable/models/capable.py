"""This module contains the models for the capable."""
