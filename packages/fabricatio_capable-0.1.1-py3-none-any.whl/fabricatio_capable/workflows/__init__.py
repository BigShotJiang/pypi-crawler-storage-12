"""Workflows defined in fabricatio-capable."""
