from .app import CureQApp
