export PYTHONPATH=`pwd`/..
pytest "$@"
