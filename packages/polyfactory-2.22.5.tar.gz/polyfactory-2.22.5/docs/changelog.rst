=========
Changelog
=========

All commits to this project will be documented in this file.

`Release [v2.22.5] - 2025-11-15 <https://github.com/litestar-org/polyfactory/releases/tag/v2.22.5>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.22.5 <https://github.com/litestar-org/polyfactory/commits/v2.22.5>`_

`2e5c768 <https://github.com/litestar-org/polyfactory/commit/2e5c768a06d934ca4e1d0222e5a025cce8c4ea38>`_ ... `d6f4df7 <https://github.com/litestar-org/polyfactory/commit/d6f4df7071062ff07f4f578533b2b03308ea456f>`_ | `See diff for 2.22.5 <https://github.com/litestar-org/polyfactory/compare/2e5c768a06d934ca4e1d0222e5a025cce8c4ea38...d6f4df7071062ff07f4f578533b2b03308ea456f>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`af24258 <https://github.com/litestar-org/polyfactory/commit/af24258a49faecc8da44b43c3acd64b020882cb9>`_)  - Use correct field_meta for constrained union types when building field values for coverage (#770)  by `@bullfest <https://github.com/bullfest>`_ in `#770 <https://github.com/litestar-org/polyfactory/pull/770>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`d6f4df7 <https://github.com/litestar-org/polyfactory/commit/d6f4df7071062ff07f4f578533b2b03308ea456f>`_)  - Add bullfest as a contributor for code (#777)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#777 <https://github.com/litestar-org/polyfactory/pull/777>`_

`Release [v2.22.4] - 2025-11-10 <https://github.com/litestar-org/polyfactory/releases/tag/v2.22.4>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.22.4 <https://github.com/litestar-org/polyfactory/commits/v2.22.4>`_

`ad0a768 <https://github.com/litestar-org/polyfactory/commit/ad0a768f4d29f46f07c6fb64470639a1bf48b5e6>`_ ... `2e5c768 <https://github.com/litestar-org/polyfactory/commit/2e5c768a06d934ca4e1d0222e5a025cce8c4ea38>`_ | `See diff for 2.22.4 <https://github.com/litestar-org/polyfactory/compare/ad0a768f4d29f46f07c6fb64470639a1bf48b5e6...2e5c768a06d934ca4e1d0222e5a025cce8c4ea38>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`45958e4 <https://github.com/litestar-org/polyfactory/commit/45958e4e583a873eb31bdd7ff3f01d5894efab93>`_)  - Model coverage generation and __use_examples__ do not compose well (#757)  by `@arembridge <https://github.com/arembridge>`_ in `#757 <https://github.com/litestar-org/polyfactory/pull/757>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`09cc9d9 <https://github.com/litestar-org/polyfactory/commit/09cc9d9de5431fa3330dbced37b6234bafe1411f>`_)  - Fix typo in pydantic_factory.coverage doc string (#763)  by `@RasmusNygren <https://github.com/RasmusNygren>`_ in `#763 <https://github.com/litestar-org/polyfactory/pull/763>`_
* (`b8d0c6f <https://github.com/litestar-org/polyfactory/commit/b8d0c6f9398282b371070307610bf95951ec3968>`_)  - Add RasmusNygren as a contributor for doc (#766)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#766 <https://github.com/litestar-org/polyfactory/pull/766>`_
* (`213ea1c <https://github.com/litestar-org/polyfactory/commit/213ea1cdc5b4281ab51202827d72c274e4816070>`_)  - Add arembridge as a contributor for code (#767)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#767 <https://github.com/litestar-org/polyfactory/pull/767>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`0626847 <https://github.com/litestar-org/polyfactory/commit/0626847d1d80e1c52a678b0e51d5e97112237177>`_)  - Bump actions/upload-artifact from 4 to 5 (#764)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#764 <https://github.com/litestar-org/polyfactory/pull/764>`_
* (`7d67749 <https://github.com/litestar-org/polyfactory/commit/7d67749fa82c44c2930657a7ab2e19cf438bb2f9>`_)  - Bump actions/download-artifact from 5 to 6 (#765)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#765 <https://github.com/litestar-org/polyfactory/pull/765>`_
* (`2e5c768 <https://github.com/litestar-org/polyfactory/commit/2e5c768a06d934ca4e1d0222e5a025cce8c4ea38>`_)  - Prepare v2.22.4 release (#775)  by `@adhtruong <https://github.com/adhtruong>`_ in `#775 <https://github.com/litestar-org/polyfactory/pull/775>`_

`Release [v2.22.3] - 2025-10-18 <https://github.com/litestar-org/polyfactory/releases/tag/v2.22.3>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.22.3 <https://github.com/litestar-org/polyfactory/commits/v2.22.3>`_

`63eaa9f <https://github.com/litestar-org/polyfactory/commit/63eaa9f5e2806791142b559932b103fc524a5a52>`_ ... `ad0a768 <https://github.com/litestar-org/polyfactory/commit/ad0a768f4d29f46f07c6fb64470639a1bf48b5e6>`_ | `See diff for 2.22.3 <https://github.com/litestar-org/polyfactory/compare/63eaa9f5e2806791142b559932b103fc524a5a52...ad0a768f4d29f46f07c6fb64470639a1bf48b5e6>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`0358ad0 <https://github.com/litestar-org/polyfactory/commit/0358ad0950bf3816be352ca9ed34370c05e9f94e>`_)  - Pydantic Factory alias generation from version 2.11 (#718)  by `@sandre35 <https://github.com/sandre35>`_ in `#718 <https://github.com/litestar-org/polyfactory/pull/718>`_
* (`81bfbc2 <https://github.com/litestar-org/polyfactory/commit/81bfbc2519148af1ac46fad37d65be381d444ea3>`_)  - Remove association proxy default change (#747)  by `@adhtruong <https://github.com/adhtruong>`_ in `#747 <https://github.com/litestar-org/polyfactory/pull/747>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`7eec41e <https://github.com/litestar-org/polyfactory/commit/7eec41ef636a1bce2d41f12c295ddef650cbd968>`_)  - Add migration guide (#704)  by `@adhtruong <https://github.com/adhtruong>`_ in `#704 <https://github.com/litestar-org/polyfactory/pull/704>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`ae7cb36 <https://github.com/litestar-org/polyfactory/commit/ae7cb36e26546e9db60dc383da1ba6baea980d0a>`_)  - Bump actions/checkout from 4 to 5 (#740)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#740 <https://github.com/litestar-org/polyfactory/pull/740>`_
* (`0c610f1 <https://github.com/litestar-org/polyfactory/commit/0c610f10e433fdb760028d14dc8c81d29db52f40>`_)  - Bump amannn/action-semantic-pull-request from 5 to 6 (#741)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#741 <https://github.com/litestar-org/polyfactory/pull/741>`_
* (`5e605dc <https://github.com/litestar-org/polyfactory/commit/5e605dce981865c6e3af073a4da74585009cd4c3>`_)  - Bump actions/download-artifact from 4 to 5 (#739)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#739 <https://github.com/litestar-org/polyfactory/pull/739>`_
* (`62d92c9 <https://github.com/litestar-org/polyfactory/commit/62d92c90d79bdf18776d0b3046bd3c0e10555815>`_)  - Bump actions/github-script from 7 to 8 (#743)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#743 <https://github.com/litestar-org/polyfactory/pull/743>`_
* (`16d847b <https://github.com/litestar-org/polyfactory/commit/16d847b961d8c16415dc3e7a63d0d4f4b411a348>`_)  - Bump actions/setup-python from 5 to 6 (#742)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#742 <https://github.com/litestar-org/polyfactory/pull/742>`_
* (`572a47c <https://github.com/litestar-org/polyfactory/commit/572a47c391178638fd2e27aa11d6be3b0695851e>`_)  - Update CODEOWNERS (#749)  by `@adhtruong <https://github.com/adhtruong>`_ in `#749 <https://github.com/litestar-org/polyfactory/pull/749>`_
* (`1b26034 <https://github.com/litestar-org/polyfactory/commit/1b2603481ced3282647f69a28aa7c3eff0366135>`_)  - Bump github/codeql-action from 3 to 4 (#756)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#756 <https://github.com/litestar-org/polyfactory/pull/756>`_
* (`5ec0b01 <https://github.com/litestar-org/polyfactory/commit/5ec0b0134eef33beb699c5f91ba5e3a5058ce405>`_)  - Bump astral-sh/setup-uv from 6 to 7 (#755)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#755 <https://github.com/litestar-org/polyfactory/pull/755>`_
* (`c87481a <https://github.com/litestar-org/polyfactory/commit/c87481a8074bf5196a29c5c362e39746e2304087>`_)  - Remove unused script (#716)  by `@adhtruong <https://github.com/adhtruong>`_ in `#716 <https://github.com/litestar-org/polyfactory/pull/716>`_
* (`ad0a768 <https://github.com/litestar-org/polyfactory/commit/ad0a768f4d29f46f07c6fb64470639a1bf48b5e6>`_)  - Prepare v2.22.3 release (#761)  by `@adhtruong <https://github.com/adhtruong>`_ in `#761 <https://github.com/litestar-org/polyfactory/pull/761>`_

`Release [v2.22.2] - 2025-08-15 <https://github.com/litestar-org/polyfactory/releases/tag/v2.22.2>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.22.2 <https://github.com/litestar-org/polyfactory/commits/v2.22.2>`_

`a14ac7f <https://github.com/litestar-org/polyfactory/commit/a14ac7ff61769df18d509799f8d94c7581e482dd>`_ ... `63eaa9f <https://github.com/litestar-org/polyfactory/commit/63eaa9f5e2806791142b559932b103fc524a5a52>`_ | `See diff for 2.22.2 <https://github.com/litestar-org/polyfactory/compare/a14ac7ff61769df18d509799f8d94c7581e482dd...63eaa9f5e2806791142b559932b103fc524a5a52>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`6dcd191 <https://github.com/litestar-org/polyfactory/commit/6dcd19134da6b17b97ee4ee04a514db2d1f166c9>`_)  - Pydantic alias handling (#737)  by `@adhtruong <https://github.com/adhtruong>`_ in `#737 <https://github.com/litestar-org/polyfactory/pull/737>`_
* (`8e14c35 <https://github.com/litestar-org/polyfactory/commit/8e14c35ee46a8203844ec45728a8d65f7e847869>`_)  - Allow specifying forward references when as string (#735)  by `@adhtruong <https://github.com/adhtruong>`_ in `#735 <https://github.com/litestar-org/polyfactory/pull/735>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`63eaa9f <https://github.com/litestar-org/polyfactory/commit/63eaa9f5e2806791142b559932b103fc524a5a52>`_)  - Bump to v2.22.2 (#738)  by `@adhtruong <https://github.com/adhtruong>`_ in `#738 <https://github.com/litestar-org/polyfactory/pull/738>`_

`Release [v2.22.1] - 2025-07-14 <https://github.com/litestar-org/polyfactory/releases/tag/v2.22.1>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.22.1 <https://github.com/litestar-org/polyfactory/commits/v2.22.1>`_

`f270b0f <https://github.com/litestar-org/polyfactory/commit/f270b0fb46f36b32db0a1c9f9d2cea25c59b8f22>`_ ... `a14ac7f <https://github.com/litestar-org/polyfactory/commit/a14ac7ff61769df18d509799f8d94c7581e482dd>`_ | `See diff for 2.22.1 <https://github.com/litestar-org/polyfactory/compare/f270b0fb46f36b32db0a1c9f9d2cea25c59b8f22...a14ac7ff61769df18d509799f8d94c7581e482dd>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`90d372c <https://github.com/litestar-org/polyfactory/commit/90d372c495b2105341e5334398bc56a02d563f33>`_)  - Handle recursive types that use ForwardRef (#728)  by `@adhtruong <https://github.com/adhtruong>`_ in `#728 <https://github.com/litestar-org/polyfactory/pull/728>`_
* (`9fa5c66 <https://github.com/litestar-org/polyfactory/commit/9fa5c66e224a6ca25f7dbfbae908ca8149c64657>`_)  - Deprecation error not silenced when overridden (#724)  by `@adhtruong <https://github.com/adhtruong>`_ in `#724 <https://github.com/litestar-org/polyfactory/pull/724>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`a14ac7f <https://github.com/litestar-org/polyfactory/commit/a14ac7ff61769df18d509799f8d94c7581e482dd>`_)  - Bump to v2.22.1 (#732)  by `@adhtruong <https://github.com/adhtruong>`_ in `#732 <https://github.com/litestar-org/polyfactory/pull/732>`_

`Release [v2.22.0] - 2025-07-01 <https://github.com/litestar-org/polyfactory/releases/tag/v2.22.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.22.0 <https://github.com/litestar-org/polyfactory/commits/v2.22.0>`_

`203310b <https://github.com/litestar-org/polyfactory/commit/203310bfa4a8054efb59c1bda34715d4196a7954>`_ ... `f270b0f <https://github.com/litestar-org/polyfactory/commit/f270b0fb46f36b32db0a1c9f9d2cea25c59b8f22>`_ | `See diff for 2.22.0 <https://github.com/litestar-org/polyfactory/compare/203310bfa4a8054efb59c1bda34715d4196a7954...f270b0fb46f36b32db0a1c9f9d2cea25c59b8f22>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`94eb1bf <https://github.com/litestar-org/polyfactory/commit/94eb1bfc3f947a4090157bc7bdcec19e8c530dd8>`_)  - Test by adding inheritance in Child class from Parent (#706)  by `@Rub1kCube <https://github.com/Rub1kCube>`_ in `#706 <https://github.com/litestar-org/polyfactory/pull/706>`_
* (`dbcf79d <https://github.com/litestar-org/polyfactory/commit/dbcf79db38fffdcae7599b5cd2806261ab58fd79>`_)  - Generate correct collection size when annotation_types.Len is used (#712)  by `@priyankc <https://github.com/priyankc>`_ in `#712 <https://github.com/litestar-org/polyfactory/pull/712>`_
* (`216b8a5 <https://github.com/litestar-org/polyfactory/commit/216b8a50451f01a49967bcc7e028a5e0803a108c>`_)  - No blank children names (#666)  by `@iloveitaly <https://github.com/iloveitaly>`_ in `#666 <https://github.com/litestar-org/polyfactory/pull/666>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`3b541b6 <https://github.com/litestar-org/polyfactory/commit/3b541b66c1ef4d5cb3ecc3071ee3d1921257c99e>`_)  - Add marcuslimdw as a contributor for code (#699)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#699 <https://github.com/litestar-org/polyfactory/pull/699>`_
* (`a34e7d3 <https://github.com/litestar-org/polyfactory/commit/a34e7d37b727835f4f4aad19dc42c9f5009c366d>`_)  - Add Rub1kCube as a contributor for test (#708)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#708 <https://github.com/litestar-org/polyfactory/pull/708>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`5de22fa <https://github.com/litestar-org/polyfactory/commit/5de22fa1331e36fc506088af21430ba58f11fc94>`_)  - Allow usage of Pydantic models containing forward references (#698)  by `@marcuslimdw <https://github.com/marcuslimdw>`_ in `#698 <https://github.com/litestar-org/polyfactory/pull/698>`_
* (`c7a7b44 <https://github.com/litestar-org/polyfactory/commit/c7a7b4426126d0134d531fc4db34199d39c46298>`_)  - Add PEP 695 type alias support and improve type handling (#711)  by `@Rub1kCube <https://github.com/Rub1kCube>`_ in `#711 <https://github.com/litestar-org/polyfactory/pull/711>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`82baed7 <https://github.com/litestar-org/polyfactory/commit/82baed7c2c252964381a751d8639e781662655f3>`_)  - Remove _AnnotatedAlias (#693)  by `@adhtruong <https://github.com/adhtruong>`_ in `#693 <https://github.com/litestar-org/polyfactory/pull/693>`_
* (`5d97be2 <https://github.com/litestar-org/polyfactory/commit/5d97be2424f03fa098741c1f93e2be832dcd3950>`_)  - Warn on deprecated parameter usage (#689)  by `@adhtruong <https://github.com/adhtruong>`_ in `#689 <https://github.com/litestar-org/polyfactory/pull/689>`_
* (`aff32a0 <https://github.com/litestar-org/polyfactory/commit/aff32a03de6c2b2282b2a28db88d03fb67ffb150>`_)  - Bump astral-sh/setup-uv from 5 to 6 (#696)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#696 <https://github.com/litestar-org/polyfactory/pull/696>`_
* (`d03aa1b <https://github.com/litestar-org/polyfactory/commit/d03aa1bfb6221d87cf5d83ad184beaf2d4d77178>`_)  - Bump dawidd6/action-download-artifact from 9 to 10 (#709)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#709 <https://github.com/litestar-org/polyfactory/pull/709>`_
* (`0cd86d2 <https://github.com/litestar-org/polyfactory/commit/0cd86d2bf93efaddc1c994e21ead4714273182ec>`_)  - Bump dawidd6/action-download-artifact from 10 to 11 (#714)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#714 <https://github.com/litestar-org/polyfactory/pull/714>`_
* (`f270b0f <https://github.com/litestar-org/polyfactory/commit/f270b0fb46f36b32db0a1c9f9d2cea25c59b8f22>`_)  - Bump to v2.22.0 (#722)  by `@adhtruong <https://github.com/adhtruong>`_ in `#722 <https://github.com/litestar-org/polyfactory/pull/722>`_

Performance
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`0d55db8 <https://github.com/litestar-org/polyfactory/commit/0d55db8a6ac21e559f6524148de8e50323714994>`_)  - Avoid deep copy (#702)  by `@adhtruong <https://github.com/adhtruong>`_ in `#702 <https://github.com/litestar-org/polyfactory/pull/702>`_

Refactor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`6281fb2 <https://github.com/litestar-org/polyfactory/commit/6281fb223b893c2a808bcc9920856ed2c948d740>`_)  - Make type utils deterministic (#688)  by `@adhtruong <https://github.com/adhtruong>`_ in `#688 <https://github.com/litestar-org/polyfactory/pull/688>`_

`Release [v2.21.0] - 2025-04-18 <https://github.com/litestar-org/polyfactory/releases/tag/v2.21.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.21.0 <https://github.com/litestar-org/polyfactory/commits/v2.21.0>`_

`0facd26 <https://github.com/litestar-org/polyfactory/commit/0facd26ec2e8915e1769e90ffb55ccccd60aadc5>`_ ... `203310b <https://github.com/litestar-org/polyfactory/commit/203310bfa4a8054efb59c1bda34715d4196a7954>`_ | `See diff for 2.21.0 <https://github.com/litestar-org/polyfactory/compare/0facd26ec2e8915e1769e90ffb55ccccd60aadc5...203310bfa4a8054efb59c1bda34715d4196a7954>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`4ae69c8 <https://github.com/litestar-org/polyfactory/commit/4ae69c81c61e70269c004794abf3abca31700e87>`_)  - Handle pydantic v1 URL and email correctly (#685)  by `@Xdynix <https://github.com/Xdynix>`_ in `#685 <https://github.com/litestar-org/polyfactory/pull/685>`_
* (`18d8579 <https://github.com/litestar-org/polyfactory/commit/18d857966c2049f9705351f276370c7a4e38c0d5>`_)  - Make type alias detection work with typing_extensions 4.13 (#684)  by `@airwoodix <https://github.com/airwoodix>`_ in `#684 <https://github.com/litestar-org/polyfactory/pull/684>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`9940230 <https://github.com/litestar-org/polyfactory/commit/9940230d3b1958f6f0b14e3157dcdd137af40cea>`_)  - Document overriding SQLA column mapping (#671)  by `@adhtruong <https://github.com/adhtruong>`_ in `#671 <https://github.com/litestar-org/polyfactory/pull/671>`_
* (`cc789b5 <https://github.com/litestar-org/polyfactory/commit/cc789b55298e6e160f8d14877c7ea5859d72ee4d>`_)  - Support new type and annotated mapping (#680)  by `@adhtruong <https://github.com/adhtruong>`_ in `#680 <https://github.com/litestar-org/polyfactory/pull/680>`_
* (`36395d9 <https://github.com/litestar-org/polyfactory/commit/36395d94a3a325c3f7db51fc71f0ef9c2edb3f3d>`_)  - Issue 678 use pydantic field examples (#679)  by `@stardust85 <https://github.com/stardust85>`_ in `#679 <https://github.com/litestar-org/polyfactory/pull/679>`_
* (`02fed72 <https://github.com/litestar-org/polyfactory/commit/02fed7258c5b522891a0b8cdbd0491d21bc9bd95>`_)  - Add release command (#687)  by `@adhtruong <https://github.com/adhtruong>`_ in `#687 <https://github.com/litestar-org/polyfactory/pull/687>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`e0c6941 <https://github.com/litestar-org/polyfactory/commit/e0c6941d3fdf89038484bfe62b80485b897ca439>`_)  - Remove sonar (#672)  by `@adhtruong <https://github.com/adhtruong>`_ in `#672 <https://github.com/litestar-org/polyfactory/pull/672>`_
* (`203310b <https://github.com/litestar-org/polyfactory/commit/203310bfa4a8054efb59c1bda34715d4196a7954>`_)  - Bump to v2.21.0 (#692)  by `@adhtruong <https://github.com/adhtruong>`_ in `#692 <https://github.com/litestar-org/polyfactory/pull/692>`_

Refactor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`00aa862 <https://github.com/litestar-org/polyfactory/commit/00aa862cf96174b4fb845e95afeb0e440f1679ee>`_)  - Deprecate FieldMeta.random (#663)  by `@adhtruong <https://github.com/adhtruong>`_ in `#663 <https://github.com/litestar-org/polyfactory/pull/663>`_
* (`ade1115 <https://github.com/litestar-org/polyfactory/commit/ade1115b20bb61da698cb2e1561b38a8de20fca3>`_)  - Migrate to typos (#675)  by `@adhtruong <https://github.com/adhtruong>`_ in `#675 <https://github.com/litestar-org/polyfactory/pull/675>`_

Ci
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`c42bf6d <https://github.com/litestar-org/polyfactory/commit/c42bf6dd4aaa2b3625b7dc7d2873bbd5b0a7a70d>`_)  - Add toml formatter (#682)  by `@adhtruong <https://github.com/adhtruong>`_ in `#682 <https://github.com/litestar-org/polyfactory/pull/682>`_

`Release [v2.20.0] - 2025-03-21 <https://github.com/litestar-org/polyfactory/releases/tag/v2.20.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.20.0 <https://github.com/litestar-org/polyfactory/commits/v2.20.0>`_

`de78949 <https://github.com/litestar-org/polyfactory/commit/de789499f8b16b49c9fae5954cfba8ad868fff58>`_ ... `0facd26 <https://github.com/litestar-org/polyfactory/commit/0facd26ec2e8915e1769e90ffb55ccccd60aadc5>`_ | `See diff for 2.20.0 <https://github.com/litestar-org/polyfactory/compare/de789499f8b16b49c9fae5954cfba8ad868fff58...0facd26ec2e8915e1769e90ffb55ccccd60aadc5>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`64fa119 <https://github.com/litestar-org/polyfactory/commit/64fa119f7caa2d8c616e3dc2c50ae9c232616351>`_)  - Allow non-hashable type args (#643)  by `@adhtruong <https://github.com/adhtruong>`_ in `#643 <https://github.com/litestar-org/polyfactory/pull/643>`_
* (`703aa2e <https://github.com/litestar-org/polyfactory/commit/703aa2ef2d2b2489b0c817f6f0d9e75714e1069b>`_)  - Dont allow faker version less then 5.0.0 (#646)  by `@T0nd0Tara <https://github.com/T0nd0Tara>`_ in `#646 <https://github.com/litestar-org/polyfactory/pull/646>`_
* (`e4a27ca <https://github.com/litestar-org/polyfactory/commit/e4a27cab597f60f142210eaca66a3f97188810f0>`_)  - Added a generate function to support SQL Numeric field (#636)  by `@nisemenov <https://github.com/nisemenov>`_ in `#636 <https://github.com/litestar-org/polyfactory/pull/636>`_
* (`da6ad4d <https://github.com/litestar-org/polyfactory/commit/da6ad4d213aec4447e9b3b257ab5fed392f445ae>`_)  - Ignore dataclass types in pydantic field parsing (#660)  by `@adhtruong <https://github.com/adhtruong>`_ in `#660 <https://github.com/litestar-org/polyfactory/pull/660>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`3c1e68f <https://github.com/litestar-org/polyfactory/commit/3c1e68ffbfa59d0ed9b9cc41d9b9a17654b841e4>`_)  - Add nisemenov as a contributor for code, and doc (#633)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#633 <https://github.com/litestar-org/polyfactory/pull/633>`_
* (`beab66c <https://github.com/litestar-org/polyfactory/commit/beab66cf39a8bf67e3a1ac41cde30ee27ee08be1>`_)  - Add iloveitaly as a contributor for code, and doc (#662)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#662 <https://github.com/litestar-org/polyfactory/pull/662>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`8c1fe02 <https://github.com/litestar-org/polyfactory/commit/8c1fe0293a525fdd20aaadbbf09f8a31dffcdaf8>`_)  - Described an ability to use async data in factory fields; refactored factories/base and some tests (#641)  by `@nisemenov <https://github.com/nisemenov>`_ in `#641 <https://github.com/litestar-org/polyfactory/pull/641>`_
* (`ba7cd3f <https://github.com/litestar-org/polyfactory/commit/ba7cd3f382140523d61b35c9ed572c74d8c1ef9f>`_)  - Simplify pytest plugin (#652)  by `@adhtruong <https://github.com/adhtruong>`_ in `#652 <https://github.com/litestar-org/polyfactory/pull/652>`_
* (`b98ae5d <https://github.com/litestar-org/polyfactory/commit/b98ae5d1c50d24748903e65a8d3b1674f1043f2c>`_)  - Improve create factory typing (#657)  by `@adhtruong <https://github.com/adhtruong>`_ in `#657 <https://github.com/litestar-org/polyfactory/pull/657>`_
* (`33c72e7 <https://github.com/litestar-org/polyfactory/commit/33c72e7bcd1388756a2235e4d75b74fe0de16d27>`_)  - Add_providers to easily add new type provider (#659)  by `@iloveitaly <https://github.com/iloveitaly>`_ in `#659 <https://github.com/litestar-org/polyfactory/pull/659>`_
* (`0b5df15 <https://github.com/litestar-org/polyfactory/commit/0b5df15bd324a7ac2079947dd600e899f2b10798>`_)  - Improve random range (#653)  by `@adhtruong <https://github.com/adhtruong>`_ in `#653 <https://github.com/litestar-org/polyfactory/pull/653>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`f5cb818 <https://github.com/litestar-org/polyfactory/commit/f5cb818314bf4887f2caab2c3961d1dd886b68cc>`_)  - Bump dawidd6/action-download-artifact from 7 to 9 (#651)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#651 <https://github.com/litestar-org/polyfactory/pull/651>`_
* (`1c56f09 <https://github.com/litestar-org/polyfactory/commit/1c56f09692214cefcfcd3bc29ba9b74fc18a940f>`_)  - Bump codecov/codecov-action from 4 to 5 (#620)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#620 <https://github.com/litestar-org/polyfactory/pull/620>`_
* (`516dd6d <https://github.com/litestar-org/polyfactory/commit/516dd6d280ee35afda068c7ecaa0d672daf971d1>`_)  - Improve test imports (#661)  by `@adhtruong <https://github.com/adhtruong>`_ in `#661 <https://github.com/litestar-org/polyfactory/pull/661>`_
* (`0facd26 <https://github.com/litestar-org/polyfactory/commit/0facd26ec2e8915e1769e90ffb55ccccd60aadc5>`_)  - Prep 2.20.0 release (#669)  by `@adhtruong <https://github.com/adhtruong>`_ in `#669 <https://github.com/litestar-org/polyfactory/pull/669>`_

Build
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`34182d4 <https://github.com/litestar-org/polyfactory/commit/34182d439d5d5f1f1964a961c028859e3b404851>`_)  - Update dependencies and ignores (#648)  by `@adhtruong <https://github.com/adhtruong>`_ in `#648 <https://github.com/litestar-org/polyfactory/pull/648>`_
* (`396b555 <https://github.com/litestar-org/polyfactory/commit/396b5559ec2a2bbf7818dd15a75b556c18849183>`_)  - Update pyright (#665)  by `@adhtruong <https://github.com/adhtruong>`_ in `#665 <https://github.com/litestar-org/polyfactory/pull/665>`_

`Release [v2.19.0] - 2025-01-29 <https://github.com/litestar-org/polyfactory/releases/tag/v2.19.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.19.0 <https://github.com/litestar-org/polyfactory/commits/v2.19.0>`_

`0290580 <https://github.com/litestar-org/polyfactory/commit/029058005ff9681f5b9f3e2adf2030dfb40d21d5>`_ ... `de78949 <https://github.com/litestar-org/polyfactory/commit/de789499f8b16b49c9fae5954cfba8ad868fff58>`_ | `See diff for 2.19.0 <https://github.com/litestar-org/polyfactory/compare/029058005ff9681f5b9f3e2adf2030dfb40d21d5...de789499f8b16b49c9fae5954cfba8ad868fff58>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`e1c5b8c <https://github.com/litestar-org/polyfactory/commit/e1c5b8c9f2c63604a3856937e772b4081c77ca90>`_)  - Lock PDM version to support 3.8 (#609)  by `@adhtruong <https://github.com/adhtruong>`_ in `#609 <https://github.com/litestar-org/polyfactory/pull/609>`_
* (`f526601 <https://github.com/litestar-org/polyfactory/commit/f526601b080479963d431d36545c129be47ad161>`_)  - Pydantic 2.10 compatibility (#613)  by `@adhtruong <https://github.com/adhtruong>`_ in `#613 <https://github.com/litestar-org/polyfactory/pull/613>`_
* (`1e0c847 <https://github.com/litestar-org/polyfactory/commit/1e0c847deb762a8305edaf03a6e0a2a1e86a266e>`_)  - Update security alert (#615)  by `@adhtruong <https://github.com/adhtruong>`_ in `#615 <https://github.com/litestar-org/polyfactory/pull/615>`_
* (`135bbc0 <https://github.com/litestar-org/polyfactory/commit/135bbc03370212729350fd098b5d0a1cb227f388>`_)  - Ensure ABC are not considered a factory type (#628)  by `@adhtruong <https://github.com/adhtruong>`_ in `#628 <https://github.com/litestar-org/polyfactory/pull/628>`_
* (`137bfb9 <https://github.com/litestar-org/polyfactory/commit/137bfb9cb4f50b4b4397949bbf80b86a52483029>`_)  - Added an async context manager in SQLAASyncPersistence (#630)  by `@nisemenov <https://github.com/nisemenov>`_ in `#630 <https://github.com/litestar-org/polyfactory/pull/630>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`42999fa <https://github.com/litestar-org/polyfactory/commit/42999fa015d70bae78ad67f7af160b6be2c2a90e>`_)  - Added __set_association_proxy__ attribute (#629)  by `@nisemenov <https://github.com/nisemenov>`_ in `#629 <https://github.com/litestar-org/polyfactory/pull/629>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`d6a886a <https://github.com/litestar-org/polyfactory/commit/d6a886a4f3b33c77774e14ec190531128ce504c2>`_)  - Bump astral-sh/setup-uv from 4 to 5 (#622)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#622 <https://github.com/litestar-org/polyfactory/pull/622>`_
* (`9db2ee7 <https://github.com/litestar-org/polyfactory/commit/9db2ee726592c8b24b853e5f1d9c22df016be5c3>`_)  - Bump dawidd6/action-download-artifact from 3 to 7 (#619)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#619 <https://github.com/litestar-org/polyfactory/pull/619>`_
* (`de78949 <https://github.com/litestar-org/polyfactory/commit/de789499f8b16b49c9fae5954cfba8ad868fff58>`_)  - Prep 2.19.0 release (#637)  by `@adhtruong <https://github.com/adhtruong>`_ in `#637 <https://github.com/litestar-org/polyfactory/pull/637>`_

Refactor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`a7dda85 <https://github.com/litestar-org/polyfactory/commit/a7dda85319bcefa0df4aef9fc75e6c0813cd7596>`_)  - Update Pydantic imports (#625)  by `@adhtruong <https://github.com/adhtruong>`_ in `#625 <https://github.com/litestar-org/polyfactory/pull/625>`_

Build
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`9ee5852 <https://github.com/litestar-org/polyfactory/commit/9ee585214ea916751e48e36ac52dad6169d82519>`_)  - Update pre-commit dependencies (#614)  by `@adhtruong <https://github.com/adhtruong>`_ in `#614 <https://github.com/litestar-org/polyfactory/pull/614>`_
* (`9fa4ad9 <https://github.com/litestar-org/polyfactory/commit/9fa4ad913dcbef60440f1c5022581ef352c7cceb>`_)  - Migrate to uv (#612)  by `@adhtruong <https://github.com/adhtruong>`_ in `#612 <https://github.com/litestar-org/polyfactory/pull/612>`_
* (`d374de5 <https://github.com/litestar-org/polyfactory/commit/d374de52a6524a0eb3126483f6ea25812df59566>`_)  - Support 3.13 (#599)  by `@adhtruong <https://github.com/adhtruong>`_ in `#599 <https://github.com/litestar-org/polyfactory/pull/599>`_
* (`d2ef554 <https://github.com/litestar-org/polyfactory/commit/d2ef5549a20da966a992f96145d2a46bd4f3d570>`_)  - Change deprecated action (#626)  by `@adhtruong <https://github.com/adhtruong>`_ in `#626 <https://github.com/litestar-org/polyfactory/pull/626>`_

`Release [v2.18.1] - 2024-11-26 <https://github.com/litestar-org/polyfactory/releases/tag/v2.18.1>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.18.1 <https://github.com/litestar-org/polyfactory/commits/v2.18.1>`_

`f7b5d8b <https://github.com/litestar-org/polyfactory/commit/f7b5d8bb9410d40dc6073d9ca7f2cdec878bc419>`_ ... `0290580 <https://github.com/litestar-org/polyfactory/commit/029058005ff9681f5b9f3e2adf2030dfb40d21d5>`_ | `See diff for 2.18.1 <https://github.com/litestar-org/polyfactory/compare/f7b5d8bb9410d40dc6073d9ca7f2cdec878bc419...029058005ff9681f5b9f3e2adf2030dfb40d21d5>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`660183b <https://github.com/litestar-org/polyfactory/commit/660183b5f90d4969576baa2be19a9cf70b3d0d1c>`_)  - Handle nullable SQLA constraints (#602)  by `@adhtruong <https://github.com/adhtruong>`_ in `#602 <https://github.com/litestar-org/polyfactory/pull/602>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`0290580 <https://github.com/litestar-org/polyfactory/commit/029058005ff9681f5b9f3e2adf2030dfb40d21d5>`_)  - Bump release version (#608)  by `@adhtruong <https://github.com/adhtruong>`_ in `#608 <https://github.com/litestar-org/polyfactory/pull/608>`_

`Release [v2.18.0] - 2024-11-06 <https://github.com/litestar-org/polyfactory/releases/tag/v2.18.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.18.0 <https://github.com/litestar-org/polyfactory/commits/v2.18.0>`_

`37a9894 <https://github.com/litestar-org/polyfactory/commit/37a9894a52c1188a927c8c9cb5b4485b73d062c3>`_ ... `f7b5d8b <https://github.com/litestar-org/polyfactory/commit/f7b5d8bb9410d40dc6073d9ca7f2cdec878bc419>`_ | `See diff for 2.18.0 <https://github.com/litestar-org/polyfactory/compare/37a9894a52c1188a927c8c9cb5b4485b73d062c3...f7b5d8bb9410d40dc6073d9ca7f2cdec878bc419>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`c027bbd <https://github.com/litestar-org/polyfactory/commit/c027bbd1c1ff990e02c19cac7d67851c17853469>`_)  - Update docs preview upload (#597)  by `@adhtruong <https://github.com/adhtruong>`_ in `#597 <https://github.com/litestar-org/polyfactory/pull/597>`_
* (`8d8f6a9 <https://github.com/litestar-org/polyfactory/commit/8d8f6a9b4b2ae525dc41539a88418aabdee1efd1>`_)  - Add SQLA async to test dependencies (#595)  by `@adhtruong <https://github.com/adhtruong>`_ in `#595 <https://github.com/litestar-org/polyfactory/pull/595>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`6abb845 <https://github.com/litestar-org/polyfactory/commit/6abb845ddcc673db3fac253a5084f4726f4f4263>`_)  - Handle SQLA column constraints (#594)  by `@adhtruong <https://github.com/adhtruong>`_ in `#594 <https://github.com/litestar-org/polyfactory/pull/594>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`f7b5d8b <https://github.com/litestar-org/polyfactory/commit/f7b5d8bb9410d40dc6073d9ca7f2cdec878bc419>`_)  - Bump minor version  by `@vkcku <https://github.com/vkcku>`_

`Release [v2.17.0] - 2024-09-22 <https://github.com/litestar-org/polyfactory/releases/tag/v2.17.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.17.0 <https://github.com/litestar-org/polyfactory/commits/v2.17.0>`_

`67c5720 <https://github.com/litestar-org/polyfactory/commit/67c57208de5ce993bdb2c7888864ac4e71964511>`_ ... `37a9894 <https://github.com/litestar-org/polyfactory/commit/37a9894a52c1188a927c8c9cb5b4485b73d062c3>`_ | `See diff for 2.17.0 <https://github.com/litestar-org/polyfactory/compare/67c57208de5ce993bdb2c7888864ac4e71964511...37a9894a52c1188a927c8c9cb5b4485b73d062c3>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`24701eb <https://github.com/litestar-org/polyfactory/commit/24701eb593493f7c038709b1327dbf6dd8942e87>`_)  - Constrained 0 length lists (#570)  by `@marcozzxx810 <https://github.com/marcozzxx810>`_ in `#570 <https://github.com/litestar-org/polyfactory/pull/570>`_
* (`6f5b78c <https://github.com/litestar-org/polyfactory/commit/6f5b78cc5ef3f0fb1037d17d06837af54aac586d>`_)  - Use provider map for any in coverage (#574)  by `@adhtruong <https://github.com/adhtruong>`_ in `#574 <https://github.com/litestar-org/polyfactory/pull/574>`_
* (`4aaf656 <https://github.com/litestar-org/polyfactory/commit/4aaf656baa5b612fa3b63c6047b653b9b785f60d>`_)  - Tuple randomized length (#573)  by `@adhtruong <https://github.com/adhtruong>`_ in `#573 <https://github.com/litestar-org/polyfactory/pull/573>`_
* (`9a83ad6 <https://github.com/litestar-org/polyfactory/commit/9a83ad6354d675b42eb514f9354e845490608ba6>`_)  - Adjust min/max items to valid lengths for Set[Enum] fields (#567)  by `@adrianeboyd <https://github.com/adrianeboyd>`_ in `#567 <https://github.com/litestar-org/polyfactory/pull/567>`_
* (`135d7fe <https://github.com/litestar-org/polyfactory/commit/135d7fea8d939a1fa8c87838d2b705db8968dccd>`_)  - Handle Optional type recursive models (#584)  by `@adhtruong <https://github.com/adhtruong>`_ in `#584 <https://github.com/litestar-org/polyfactory/pull/584>`_
* (`6440faa <https://github.com/litestar-org/polyfactory/commit/6440faa24abfc34c2d10e31797224f5aec2d43c0>`_)  - Handle recursive collections (#587)  by `@adhtruong <https://github.com/adhtruong>`_ in `#587 <https://github.com/litestar-org/polyfactory/pull/587>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`841831d <https://github.com/litestar-org/polyfactory/commit/841831d12f59a0825e490e71fdbc32744c433565>`_)  - Swap word with its antonym to match the context (#575)  by `@UncleGoogle <https://github.com/UncleGoogle>`_ in `#575 <https://github.com/litestar-org/polyfactory/pull/575>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`c0c2704 <https://github.com/litestar-org/polyfactory/commit/c0c27049afc9dd60395d5dd087f47ee700e1a6a7>`_)  - Enhance register_fixture return type annotation (#581)  by `@giulioindev <https://github.com/giulioindev>`_ in `#581 <https://github.com/litestar-org/polyfactory/pull/581>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`37a9894 <https://github.com/litestar-org/polyfactory/commit/37a9894a52c1188a927c8c9cb5b4485b73d062c3>`_)  - Bump release version (#588)  by `@adhtruong <https://github.com/adhtruong>`_ in `#588 <https://github.com/litestar-org/polyfactory/pull/588>`_

Build
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`d75b1d2 <https://github.com/litestar-org/polyfactory/commit/d75b1d2eee3c042b3bf1ea7b8c2b0b6a744df75d>`_)  - Update pre-commit dependencies (#571)  by `@adhtruong <https://github.com/adhtruong>`_ in `#571 <https://github.com/litestar-org/polyfactory/pull/571>`_

`Release [v2.16.2] - 2024-07-09 <https://github.com/litestar-org/polyfactory/releases/tag/v2.16.2>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.16.2 <https://github.com/litestar-org/polyfactory/commits/v2.16.2>`_

`23281ee <https://github.com/litestar-org/polyfactory/commit/23281eed6c596a7defdc022e8d595cb3f4d2f169>`_ ... `67c5720 <https://github.com/litestar-org/polyfactory/commit/67c57208de5ce993bdb2c7888864ac4e71964511>`_ | `See diff for 2.16.2 <https://github.com/litestar-org/polyfactory/compare/23281eed6c596a7defdc022e8d595cb3f4d2f169...67c57208de5ce993bdb2c7888864ac4e71964511>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`3bb97e0 <https://github.com/litestar-org/polyfactory/commit/3bb97e0672d7fadb8532a882e62922b135c81fec>`_)  - Nested model in collection build context (#564)  by `@sam-or <https://github.com/sam-or>`_ in `#564 <https://github.com/litestar-org/polyfactory/pull/564>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`67c5720 <https://github.com/litestar-org/polyfactory/commit/67c57208de5ce993bdb2c7888864ac4e71964511>`_)  - Bump patch version  by `@vkcku <https://github.com/vkcku>`_

`Release [v2.16.1] - 2024-07-08 <https://github.com/litestar-org/polyfactory/releases/tag/v2.16.1>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.16.1 <https://github.com/litestar-org/polyfactory/commits/v2.16.1>`_

`4928f07 <https://github.com/litestar-org/polyfactory/commit/4928f0735ad58adc63f093062b4938dfc5003ea9>`_ ... `23281ee <https://github.com/litestar-org/polyfactory/commit/23281eed6c596a7defdc022e8d595cb3f4d2f169>`_ | `See diff for 2.16.1 <https://github.com/litestar-org/polyfactory/compare/4928f0735ad58adc63f093062b4938dfc5003ea9...23281eed6c596a7defdc022e8d595cb3f4d2f169>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`86869c2 <https://github.com/litestar-org/polyfactory/commit/86869c231255f9269420039b35b3b2f3572a0255>`_)  - Use provider map for generating value for 'Any' (#522)  by `@vkcku <https://github.com/vkcku>`_ in `#522 <https://github.com/litestar-org/polyfactory/pull/522>`_
* (`cbe6dfc <https://github.com/litestar-org/polyfactory/commit/cbe6dfce14b1778cf2434a93addeb6936ce3c61b>`_)  - Pydantic factory_use_construct is not propagated to the nested (#549)  in `#549 <https://github.com/litestar-org/polyfactory/pull/549>`_
* (`b09bf64 <https://github.com/litestar-org/polyfactory/commit/b09bf64e56ac9bf32ba77b835abbc43ededabd9f>`_)  - Send correct field_meta to avoid over nesting (#527)  by `@Vegemash <https://github.com/Vegemash>`_ in `#527 <https://github.com/litestar-org/polyfactory/pull/527>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`740fd34 <https://github.com/litestar-org/polyfactory/commit/740fd345685df6b313f8a4e12e041129b4dcd2e1>`_)  - Link to GitHub repo (#547)  by `@Alc-Was-Taken <https://github.com/Alc-Was-Taken>`_ in `#547 <https://github.com/litestar-org/polyfactory/pull/547>`_
* (`c34e72e <https://github.com/litestar-org/polyfactory/commit/c34e72e96d0530293739442a48a679dc85ec33fa>`_)  - Add Reskov as a contributor for code (#556)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#556 <https://github.com/litestar-org/polyfactory/pull/556>`_
* (`3320989 <https://github.com/litestar-org/polyfactory/commit/3320989ed73265861ec11d09be5c57ed8f06c03f>`_)  - Add Vegemash as a contributor for code (#562)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#562 <https://github.com/litestar-org/polyfactory/pull/562>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`f8e9318 <https://github.com/litestar-org/polyfactory/commit/f8e93188b447b6c28ee4466da3a128f2edafc5bd>`_)  - Migrate formatting to ruff (#554)  by `@adhtruong <https://github.com/adhtruong>`_ in `#554 <https://github.com/litestar-org/polyfactory/pull/554>`_
* (`36a9cc1 <https://github.com/litestar-org/polyfactory/commit/36a9cc15d91d6a64e6aecf76757c10b11bc7a87c>`_)  - Bump pydantic (#561)  by `@Vegemash <https://github.com/Vegemash>`_ in `#561 <https://github.com/litestar-org/polyfactory/pull/561>`_
* (`23281ee <https://github.com/litestar-org/polyfactory/commit/23281eed6c596a7defdc022e8d595cb3f4d2f169>`_)  - Bump patch version  by `@vkcku <https://github.com/vkcku>`_

`Release [v2.16.0] - 2024-05-13 <https://github.com/litestar-org/polyfactory/releases/tag/v2.16.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.16.0 <https://github.com/litestar-org/polyfactory/commits/v2.16.0>`_

`1d1c7f9 <https://github.com/litestar-org/polyfactory/commit/1d1c7f9d02f9c7a8eb977dc0624bf5a045d55ddc>`_ ... `4928f07 <https://github.com/litestar-org/polyfactory/commit/4928f0735ad58adc63f093062b4938dfc5003ea9>`_ | `See diff for 2.16.0 <https://github.com/litestar-org/polyfactory/compare/1d1c7f9d02f9c7a8eb977dc0624bf5a045d55ddc...4928f0735ad58adc63f093062b4938dfc5003ea9>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`719495e <https://github.com/litestar-org/polyfactory/commit/719495e6dca5c6938975b6bc0456205d28e2c90d>`_)  - Ignore non-columns types (#510)  by `@adhtruong <https://github.com/adhtruong>`_ in `#510 <https://github.com/litestar-org/polyfactory/pull/510>`_
* (`bb04b4e <https://github.com/litestar-org/polyfactory/commit/bb04b4e81764289ba5a138c0b82faa73bb4e5257>`_)  - Favour SA mapped type over impl type (#513)  by `@adhtruong <https://github.com/adhtruong>`_ in `#513 <https://github.com/litestar-org/polyfactory/pull/513>`_
* (`0032b5e <https://github.com/litestar-org/polyfactory/commit/0032b5e962906239ecd4c4bd7276dc0d9e9f142d>`_)  - Add footer to changelog generation  by `@JacobCoffee <https://github.com/JacobCoffee>`_
* (`5fd7d6c <https://github.com/litestar-org/polyfactory/commit/5fd7d6c2bedb3c602e009618137c6ab215172625>`_)  - Resolve mypy issues (#540)  by `@adhtruong <https://github.com/adhtruong>`_ in `#540 <https://github.com/litestar-org/polyfactory/pull/540>`_
* (`9e6edab <https://github.com/litestar-org/polyfactory/commit/9e6edabd4ee5242c54f3ddb66e539a415da86901>`_)  - Fix json type error and pg dialect default value e… (#542)  by `@wangxin688 <https://github.com/wangxin688>`_ in `#542 <https://github.com/litestar-org/polyfactory/pull/542>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`01d1dbe <https://github.com/litestar-org/polyfactory/commit/01d1dbeb46cc722b075dba85cfd6bcb94505e65d>`_)  - Apply organization theme (#533)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#533 <https://github.com/litestar-org/polyfactory/pull/533>`_
* (`5a0a5be <https://github.com/litestar-org/polyfactory/commit/5a0a5bed4ddb679868d9365a5ffbcc6c3fed686c>`_)  - Polyfactory landing page (#535)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#535 <https://github.com/litestar-org/polyfactory/pull/535>`_
* (`2f781ee <https://github.com/litestar-org/polyfactory/commit/2f781eee7f06436661874a4e469c601bb0de6cd4>`_)  - Add wangxin688 as a contributor for code (#544)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#544 <https://github.com/litestar-org/polyfactory/pull/544>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`1792c19 <https://github.com/litestar-org/polyfactory/commit/1792c19fc100b16b610902c19c90b2031420c57e>`_)  - Support nested type in pg.array types and others (#530)  by `@wangxin688 <https://github.com/wangxin688>`_ in `#530 <https://github.com/litestar-org/polyfactory/pull/530>`_
* (`013135c <https://github.com/litestar-org/polyfactory/commit/013135c17387e451d88a7b73157ad08333649112>`_)  - Refresh object in async_session after commit to db (#541)  by `@wangxin688 <https://github.com/wangxin688>`_ in `#541 <https://github.com/litestar-org/polyfactory/pull/541>`_
* (`e4695a7 <https://github.com/litestar-org/polyfactory/commit/e4695a7d16e1a63b7cce036ca653d839ea0104fb>`_)  - Copy mutable args (#529)  by `@adhtruong <https://github.com/adhtruong>`_ in `#529 <https://github.com/litestar-org/polyfactory/pull/529>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`fac9fba <https://github.com/litestar-org/polyfactory/commit/fac9fbad94f0a82a062bfdac11b2da19f906e32f>`_)  - Upgrade dependencies (#517)  by `@adhtruong <https://github.com/adhtruong>`_ in `#517 <https://github.com/litestar-org/polyfactory/pull/517>`_
* (`3da64f6 <https://github.com/litestar-org/polyfactory/commit/3da64f615056c8d2f11c6bfc55c86877a89c2414>`_)  - Update changelog.rst (#537)  by `@impaktor <https://github.com/impaktor>`_ in `#537 <https://github.com/litestar-org/polyfactory/pull/537>`_
* (`3e2d22c <https://github.com/litestar-org/polyfactory/commit/3e2d22c5bafc5ed984338be54c3eace3cacc720f>`_)  - Update maintainer emails (#545)  by `@vkcku <https://github.com/vkcku>`_ in `#545 <https://github.com/litestar-org/polyfactory/pull/545>`_

Ci
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`6507c6d <https://github.com/litestar-org/polyfactory/commit/6507c6d86094dbcf678083e3ce7d06a5b4dd2f60>`_)  - Add codecov coverage, fix badges (#536)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#536 <https://github.com/litestar-org/polyfactory/pull/536>`_

`Release [v2.15.0] - 2024-03-02 <https://github.com/litestar-org/polyfactory/releases/tag/v2.15.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.15.0 <https://github.com/litestar-org/polyfactory/commits/v2.15.0>`_

`b44c68b <https://github.com/litestar-org/polyfactory/commit/b44c68b0c1d8c253f828edbbfc88c3f39ec2fdca>`_ ... `1d1c7f9 <https://github.com/litestar-org/polyfactory/commit/1d1c7f9d02f9c7a8eb977dc0624bf5a045d55ddc>`_ | `See diff for 2.15.0 <https://github.com/litestar-org/polyfactory/compare/b44c68b0c1d8c253f828edbbfc88c3f39ec2fdca...1d1c7f9d02f9c7a8eb977dc0624bf5a045d55ddc>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`c4e3d91 <https://github.com/litestar-org/polyfactory/commit/c4e3d919368d158f839a6ea6278a28007fb7f5dc>`_)  - Prefer ``sqlalchemy.type.impl`` if it exists (#502)  by `@cofin <https://github.com/cofin>`_ in `#502 <https://github.com/litestar-org/polyfactory/pull/502>`_
* (`0f8f9e8 <https://github.com/litestar-org/polyfactory/commit/0f8f9e8d0dbd6156ef55d2d61dc6831c4e59c0b0>`_)  - Handle constrained unions properly (#499)  by `@vkcku <https://github.com/vkcku>`_ in `#499 <https://github.com/litestar-org/polyfactory/pull/499>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`61c8892 <https://github.com/litestar-org/polyfactory/commit/61c889229f40e9a454b4dbbaff3e620940ea99ad>`_)  - Fix typo on use_defaults (#497)  by `@TimDumol <https://github.com/TimDumol>`_ in `#497 <https://github.com/litestar-org/polyfactory/pull/497>`_
* (`9e34fa7 <https://github.com/litestar-org/polyfactory/commit/9e34fa7aa36acd104e61222dac1507bc1efeefd7>`_)  - Add TimDumol as a contributor for doc (#498)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#498 <https://github.com/litestar-org/polyfactory/pull/498>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`46ecdc6 <https://github.com/litestar-org/polyfactory/commit/46ecdc67f998464d82cf834ff048376283e29ac8>`_)  - Support Pydantic v1 and v2 simultaneously (#492)  by `@vkcku <https://github.com/vkcku>`_ in `#492 <https://github.com/litestar-org/polyfactory/pull/492>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`1078230 <https://github.com/litestar-org/polyfactory/commit/10782304e0d835a5583e7360a4712fae76749c4a>`_)  - Bump pdm-project/setup-pdm from 3 to 4 (#496)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#496 <https://github.com/litestar-org/polyfactory/pull/496>`_
* (`1d1c7f9 <https://github.com/litestar-org/polyfactory/commit/1d1c7f9d02f9c7a8eb977dc0624bf5a045d55ddc>`_)  - Release v2.15.0  by `@vkcku <https://github.com/vkcku>`_

Refactor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`2acfdc6 <https://github.com/litestar-org/polyfactory/commit/2acfdc6ab96f3ecb504c9c89960198fc8a1effd9>`_)  - Change order of imports for pydantic v1 (#509)  by `@vkcku <https://github.com/vkcku>`_ in `#509 <https://github.com/litestar-org/polyfactory/pull/509>`_

Testing
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`1ae2d52 <https://github.com/litestar-org/polyfactory/commit/1ae2d528b018ac4d6773b423f3ab8af8d91f4f7b>`_)  - Refactor the tests to move tests to correct places (#495)  by `@vkcku <https://github.com/vkcku>`_ in `#495 <https://github.com/litestar-org/polyfactory/pull/495>`_

`Release [v2.14.1] - 2024-01-20 <https://github.com/litestar-org/polyfactory/releases/tag/v2.14.1>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.14.1 <https://github.com/litestar-org/polyfactory/commits/v2.14.1>`_

`83f2992 <https://github.com/litestar-org/polyfactory/commit/83f299231d631e5a361a515616b0d88daa1d3fd7>`_ ... `b44c68b <https://github.com/litestar-org/polyfactory/commit/b44c68b0c1d8c253f828edbbfc88c3f39ec2fdca>`_ | `See diff for 2.14.1 <https://github.com/litestar-org/polyfactory/compare/83f299231d631e5a361a515616b0d88daa1d3fd7...b44c68b0c1d8c253f828edbbfc88c3f39ec2fdca>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`fa50e20 <https://github.com/litestar-org/polyfactory/commit/fa50e20a333b0778119c4256558e05088b26b5c4>`_)  - Handle unions properly (#491)  by `@vkcku <https://github.com/vkcku>`_ in `#491 <https://github.com/litestar-org/polyfactory/pull/491>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`b44c68b <https://github.com/litestar-org/polyfactory/commit/b44c68b0c1d8c253f828edbbfc88c3f39ec2fdca>`_)  - Bump patch version  by `@vkcku <https://github.com/vkcku>`_

`Release [v2.14.0] - 2024-01-19 <https://github.com/litestar-org/polyfactory/releases/tag/v2.14.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.14.0 <https://github.com/litestar-org/polyfactory/commits/v2.14.0>`_

`8dc8e1a <https://github.com/litestar-org/polyfactory/commit/8dc8e1a4594a75ad9a16e1b6f5041b6044fc4f51>`_ ... `83f2992 <https://github.com/litestar-org/polyfactory/commit/83f299231d631e5a361a515616b0d88daa1d3fd7>`_ | `See diff for 2.14.0 <https://github.com/litestar-org/polyfactory/compare/8dc8e1a4594a75ad9a16e1b6f5041b6044fc4f51...83f299231d631e5a361a515616b0d88daa1d3fd7>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`fb4e50a <https://github.com/litestar-org/polyfactory/commit/fb4e50acaa0796ed7164457c6c767c3351530a81>`_)  - Add min version to typing-extensions (#471)  by `@hsorsky <https://github.com/hsorsky>`_ in `#471 <https://github.com/litestar-org/polyfactory/pull/471>`_
* (`40538c9 <https://github.com/litestar-org/polyfactory/commit/40538c9a0a4e9ec72b6a8864fc4e6f1293715603>`_)  - Set as default type for factory only if model is defined (#479)  by `@vkcku <https://github.com/vkcku>`_ in `#479 <https://github.com/litestar-org/polyfactory/pull/479>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`c22633c <https://github.com/litestar-org/polyfactory/commit/c22633ccf76e0fa58bc53795dfedb78a6abfb807>`_)  - Add hsorsky as a contributor for infra (#477)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#477 <https://github.com/litestar-org/polyfactory/pull/477>`_
* (`b9c2127 <https://github.com/litestar-org/polyfactory/commit/b9c212799a3144aa81b43a93f663d20e4d3036ab>`_)  - Fix broken uri (#485)  by `@wer153 <https://github.com/wer153>`_ in `#485 <https://github.com/litestar-org/polyfactory/pull/485>`_
* (`8f96365 <https://github.com/litestar-org/polyfactory/commit/8f963653a949ae8e5b768473bb654a989b4416fe>`_)  - Add wer153 as a contributor for doc (#486)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#486 <https://github.com/litestar-org/polyfactory/pull/486>`_
* (`7ec9eb0 <https://github.com/litestar-org/polyfactory/commit/7ec9eb010a1fae8db5807ae4f1934771909e3a38>`_)  - Fix code block (#484)  by `@wer153 <https://github.com/wer153>`_ in `#484 <https://github.com/litestar-org/polyfactory/pull/484>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`b33e662 <https://github.com/litestar-org/polyfactory/commit/b33e6621ee6add4fdd2e327834401830f6771d4b>`_)  - Allow use of the default value based on configuration (#472)  by `@vkcku <https://github.com/vkcku>`_ in `#472 <https://github.com/litestar-org/polyfactory/pull/472>`_
* (`80bd012 <https://github.com/litestar-org/polyfactory/commit/80bd012fbfb3d22e087dafd68173e633ec727175>`_)  - Add recursion guard (#468)  by `@adhtruong <https://github.com/adhtruong>`_ in `#468 <https://github.com/litestar-org/polyfactory/pull/468>`_
* (`c7556e8 <https://github.com/litestar-org/polyfactory/commit/c7556e8e5eafaebfdc0dded747ae4e8a144b7cc7>`_)  - Pass on factory config (#483)  by `@adhtruong <https://github.com/adhtruong>`_ in `#483 <https://github.com/litestar-org/polyfactory/pull/483>`_
* (`94ad561 <https://github.com/litestar-org/polyfactory/commit/94ad5611772e2bed977b693a030f517b3567a6ea>`_)  - Support type alias (#487)  by `@adhtruong <https://github.com/adhtruong>`_ in `#487 <https://github.com/litestar-org/polyfactory/pull/487>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`bb433a4 <https://github.com/litestar-org/polyfactory/commit/bb433a4291ede8147858585ebf0cff9c7cc53eb1>`_)  - Update pre commit (#478)  by `@vkcku <https://github.com/vkcku>`_ in `#478 <https://github.com/litestar-org/polyfactory/pull/478>`_
* (`2b57706 <https://github.com/litestar-org/polyfactory/commit/2b57706fbd4b9120d5a31643e51098cac65df1da>`_)  - Bump actions/cache from 3 to 4 (#488)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#488 <https://github.com/litestar-org/polyfactory/pull/488>`_
* (`83f2992 <https://github.com/litestar-org/polyfactory/commit/83f299231d631e5a361a515616b0d88daa1d3fd7>`_)  - Bump minor version  by `@vkcku <https://github.com/vkcku>`_

`Release [v2.13.0] - 2023-12-19 <https://github.com/litestar-org/polyfactory/releases/tag/v2.13.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.13.0 <https://github.com/litestar-org/polyfactory/commits/v2.13.0>`_

`fe05c4e <https://github.com/litestar-org/polyfactory/commit/fe05c4e60a50d8f043e4d1dbee5ea0a0c4d9abd8>`_ ... `8dc8e1a <https://github.com/litestar-org/polyfactory/commit/8dc8e1a4594a75ad9a16e1b6f5041b6044fc4f51>`_ | `See diff for 2.13.0 <https://github.com/litestar-org/polyfactory/compare/fe05c4e60a50d8f043e4d1dbee5ea0a0c4d9abd8...8dc8e1a4594a75ad9a16e1b6f5041b6044fc4f51>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`b479e4a <https://github.com/litestar-org/polyfactory/commit/b479e4af4617d108cbd90890cbda4408ee51ba4a>`_)  - Flatten_annotation behaviour for Optional (#440)  by `@sam-or <https://github.com/sam-or>`_ in `#440 <https://github.com/litestar-org/polyfactory/pull/440>`_
* (`6961eaa <https://github.com/litestar-org/polyfactory/commit/6961eaa3b65fc63b716e854bd2eb28b5bc96e029>`_)  - Don't blindly suppress ValueError (#450)  by `@vkcku <https://github.com/vkcku>`_ in `#450 <https://github.com/litestar-org/polyfactory/pull/450>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`623d8c9 <https://github.com/litestar-org/polyfactory/commit/623d8c97c2a178cc9721fa7b562ce2aee3eddea2>`_)  - Optional ``__model__`` type (#452)  by `@Mityuha <https://github.com/Mityuha>`_ in `#452 <https://github.com/litestar-org/polyfactory/pull/452>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`1407f07 <https://github.com/litestar-org/polyfactory/commit/1407f07fed3223a11f89b8b9d0019d581f08c1d3>`_)  - Bump actions/github-script from 6 to 7 (#438)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#438 <https://github.com/litestar-org/polyfactory/pull/438>`_
* (`1a0da0d <https://github.com/litestar-org/polyfactory/commit/1a0da0df63d694525ecd19ef990495f5765ba1ba>`_)  - Bump actions/setup-python from 4 to 5 (#448)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#448 <https://github.com/litestar-org/polyfactory/pull/448>`_
* (`231d311 <https://github.com/litestar-org/polyfactory/commit/231d311643b6f3bc022d7de44f58866f1edcb217>`_)  - Bump github/codeql-action from 2 to 3 (#458)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#458 <https://github.com/litestar-org/polyfactory/pull/458>`_
* (`2695880 <https://github.com/litestar-org/polyfactory/commit/2695880a444406c21942b80ad9472ab0212dd98c>`_)  - Bump dawidd6/action-download-artifact from 2 to 3 (#459)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#459 <https://github.com/litestar-org/polyfactory/pull/459>`_
* (`fe342e4 <https://github.com/litestar-org/polyfactory/commit/fe342e49f35df85db27f42444cdb7e74fae090da>`_)  - Bump actions/upload-artifact from 3 to 4 (#461)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#461 <https://github.com/litestar-org/polyfactory/pull/461>`_
* (`a371d7f <https://github.com/litestar-org/polyfactory/commit/a371d7fb0ac0ec323aabe85dca9bb63e41cbd36a>`_)  - Bump actions/download-artifact from 3 to 4 (#462)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#462 <https://github.com/litestar-org/polyfactory/pull/462>`_
* (`0e2f824 <https://github.com/litestar-org/polyfactory/commit/0e2f824e72a5f682c91f1ed0a2862d36c5661e45>`_)  - Bump dependencies (#465)  by `@vkcku <https://github.com/vkcku>`_ in `#465 <https://github.com/litestar-org/polyfactory/pull/465>`_
* (`8dc8e1a <https://github.com/litestar-org/polyfactory/commit/8dc8e1a4594a75ad9a16e1b6f5041b6044fc4f51>`_)  - Bump minor version  by `@vkcku <https://github.com/vkcku>`_

`Release [v2.12.0] - 2023-11-13 <https://github.com/litestar-org/polyfactory/releases/tag/v2.12.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.12.0 <https://github.com/litestar-org/polyfactory/commits/v2.12.0>`_

`b7b88a8 <https://github.com/litestar-org/polyfactory/commit/b7b88a8a86d735c36df60b2e2af3a6322008152f>`_ ... `fe05c4e <https://github.com/litestar-org/polyfactory/commit/fe05c4e60a50d8f043e4d1dbee5ea0a0c4d9abd8>`_ | `See diff for 2.12.0 <https://github.com/litestar-org/polyfactory/compare/b7b88a8a86d735c36df60b2e2af3a6322008152f...fe05c4e60a50d8f043e4d1dbee5ea0a0c4d9abd8>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`70d49fd <https://github.com/litestar-org/polyfactory/commit/70d49fdf6cde700a403a807d26d0d3ea5c86cd44>`_)  - Handle cases where 'init=False' for dataclasses and attrs models (#433)  by `@vkcku <https://github.com/vkcku>`_ in `#433 <https://github.com/litestar-org/polyfactory/pull/433>`_
* (`6b7512d <https://github.com/litestar-org/polyfactory/commit/6b7512d7b3d0c1b9b90dbc94e1667b40aba5bf87>`_)  - Correctly handle collections with constrained items   (#436)  by `@vkcku <https://github.com/vkcku>`_ in `#436 <https://github.com/litestar-org/polyfactory/pull/436>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`2bad951 <https://github.com/litestar-org/polyfactory/commit/2bad951dc90c6acfb7f88efab0222873ba903191>`_)  - Add g0di as a contributor for code, doc, and test (#432)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#432 <https://github.com/litestar-org/polyfactory/pull/432>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`155f4a4 <https://github.com/litestar-org/polyfactory/commit/155f4a44d14290dce18edd2c5999f38915c3039b>`_)  - Autofill ``model`` argument when calling ``create_factory`` with receiving factory ``__model__`` (#429)  by `@g0di <https://github.com/g0di>`_ in `#429 <https://github.com/litestar-org/polyfactory/pull/429>`_
* (`b1e8b5e <https://github.com/litestar-org/polyfactory/commit/b1e8b5ec02fdfb37c179cf6e37bb0772e61de1aa>`_)  - Model type coverage batch generation (#390)  by `@sam-or <https://github.com/sam-or>`_ in `#390 <https://github.com/litestar-org/polyfactory/pull/390>`_

`Release [v2.11.0] - 2023-10-23 <https://github.com/litestar-org/polyfactory/releases/tag/v2.11.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.11.0 <https://github.com/litestar-org/polyfactory/commits/v2.11.0>`_

`63aa272 <https://github.com/litestar-org/polyfactory/commit/63aa2729df553f49ed137e8e33c6a1a80387ca2b>`_ ... `b7b88a8 <https://github.com/litestar-org/polyfactory/commit/b7b88a8a86d735c36df60b2e2af3a6322008152f>`_ | `See diff for 2.11.0 <https://github.com/litestar-org/polyfactory/compare/63aa2729df553f49ed137e8e33c6a1a80387ca2b...b7b88a8a86d735c36df60b2e2af3a6322008152f>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`caaee0f <https://github.com/litestar-org/polyfactory/commit/caaee0f4ca372bc29763979be56f8c13ed7fec28>`_)  - Handle Required and NonRequired annotations (#422)  by `@vkcku <https://github.com/vkcku>`_ in `#422 <https://github.com/litestar-org/polyfactory/pull/422>`_
* (`5d64bde <https://github.com/litestar-org/polyfactory/commit/5d64bde08134fb30be60a3596a268c23dcd1837e>`_)  - Respect override of optional nested model fields (#420)  by `@julioolvr <https://github.com/julioolvr>`_ in `#420 <https://github.com/litestar-org/polyfactory/pull/420>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`e819c2f <https://github.com/litestar-org/polyfactory/commit/e819c2fe9451f92e6e175fe9c261aaf34c97eda8>`_)  - Add johnraz as a contributor for code, doc, and test (#413)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#413 <https://github.com/litestar-org/polyfactory/pull/413>`_
* (`0631d80 <https://github.com/litestar-org/polyfactory/commit/0631d808c4d984ad70cac199be2312b77a12fcb0>`_)  - Update installation (#414)  by `@adhtruong <https://github.com/adhtruong>`_ in `#414 <https://github.com/litestar-org/polyfactory/pull/414>`_
* (`11f234c <https://github.com/litestar-org/polyfactory/commit/11f234c030d1d2546ffbeb062ed736753bc7417c>`_)  - Reorder docs and add docs on factories as fields (#418)  by `@adhtruong <https://github.com/adhtruong>`_ in `#418 <https://github.com/litestar-org/polyfactory/pull/418>`_
* (`a0465c6 <https://github.com/litestar-org/polyfactory/commit/a0465c6aba403263835551dae314975631e26248>`_)  - Add julioolvr as a contributor for code, and test (#425)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#425 <https://github.com/litestar-org/polyfactory/pull/425>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`5fefa41 <https://github.com/litestar-org/polyfactory/commit/5fefa4142940019ebd20703663a6888766cc49ad>`_)  - Check if fields declared on the factory belong to the model (#405)  by `@johnraz <https://github.com/johnraz>`_ in `#405 <https://github.com/litestar-org/polyfactory/pull/405>`_
* (`e1f7a47 <https://github.com/litestar-org/polyfactory/commit/e1f7a47c6e3c979f8f43ce6ee612f417d2f3c03b>`_)  - Support annotation with Constraints (#411)  by `@vkcku <https://github.com/vkcku>`_ in `#411 <https://github.com/litestar-org/polyfactory/pull/411>`_
* (`0717951 <https://github.com/litestar-org/polyfactory/commit/07179513fc4e27b7466f5627cf252be535b81b61>`_)  - Deprecate FieldMeta collection params (#417)  by `@adhtruong <https://github.com/adhtruong>`_ in `#417 <https://github.com/litestar-org/polyfactory/pull/417>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`b7b88a8 <https://github.com/litestar-org/polyfactory/commit/b7b88a8a86d735c36df60b2e2af3a6322008152f>`_)  - Prepare for releasing v2.11 (#427)  by `@vkcku <https://github.com/vkcku>`_ in `#427 <https://github.com/litestar-org/polyfactory/pull/427>`_

`Release [v2.10.0] - 2023-10-16 <https://github.com/litestar-org/polyfactory/releases/tag/v2.10.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.10.0 <https://github.com/litestar-org/polyfactory/commits/v2.10.0>`_

`f2c6fe1 <https://github.com/litestar-org/polyfactory/commit/f2c6fe19eb632b04b0efa20b909df96e6d9c6c68>`_ ... `63aa272 <https://github.com/litestar-org/polyfactory/commit/63aa2729df553f49ed137e8e33c6a1a80387ca2b>`_ | `See diff for 2.10.0 <https://github.com/litestar-org/polyfactory/compare/f2c6fe19eb632b04b0efa20b909df96e6d9c6c68...63aa2729df553f49ed137e8e33c6a1a80387ca2b>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`8c88293 <https://github.com/litestar-org/polyfactory/commit/8c88293e71045fb94c2e5657ab2b8062cb84dbd2>`_)  - Properly resolve dataclass forward references (#383)  by `@vkcku <https://github.com/vkcku>`_ in `#383 <https://github.com/litestar-org/polyfactory/pull/383>`_
* (`0064240 <https://github.com/litestar-org/polyfactory/commit/00642404e0a1a61052cbf9c1c901d6aee241ff70>`_)  - Update makefile (#399)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#399 <https://github.com/litestar-org/polyfactory/pull/399>`_
* (`89cd351 <https://github.com/litestar-org/polyfactory/commit/89cd35186a6dd7fd6b86e32e83caa2fad36ee194>`_)  - Decouple the handling of collection length configuration from ``FieldMeta`` (#407)  by `@vkcku <https://github.com/vkcku>`_ in `#407 <https://github.com/litestar-org/polyfactory/pull/407>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`c1edfd5 <https://github.com/litestar-org/polyfactory/commit/c1edfd5b135d9042caa02a4dd4d50b276a0ca829>`_)  - Install all dependencies for docs build (#404)  by `@adhtruong <https://github.com/adhtruong>`_ in `#404 <https://github.com/litestar-org/polyfactory/pull/404>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`cabe03c <https://github.com/litestar-org/polyfactory/commit/cabe03c29cae8ac09c9d51e7f355d324e6740bd9>`_)  - Support sqlalchemy 1.4 (#385)  by `@adhtruong <https://github.com/adhtruong>`_ in `#385 <https://github.com/litestar-org/polyfactory/pull/385>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`63aa272 <https://github.com/litestar-org/polyfactory/commit/63aa2729df553f49ed137e8e33c6a1a80387ca2b>`_)  - Prepare for releasing v2.10 (#410)  by `@vkcku <https://github.com/vkcku>`_ in `#410 <https://github.com/litestar-org/polyfactory/pull/410>`_

Refactor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`79360f1 <https://github.com/litestar-org/polyfactory/commit/79360f18340da6ab67808a4a177349b206432bc9>`_)  - Move creation of pydantic provider map (#396)  by `@vkcku <https://github.com/vkcku>`_ in `#396 <https://github.com/litestar-org/polyfactory/pull/396>`_
* (`f555636 <https://github.com/litestar-org/polyfactory/commit/f555636bee6aa0ebf2c4f2c05cdb24a2e143ff75>`_)  - Refactor the msgspec factory to use the fields API (#409)  by `@vkcku <https://github.com/vkcku>`_ in `#409 <https://github.com/litestar-org/polyfactory/pull/409>`_

Ci
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`8ef78b8 <https://github.com/litestar-org/polyfactory/commit/8ef78b8c3eb9d18a9f88b05f02e86378bc3769bf>`_)  - Fix alternative version installation (#389)  by `@adhtruong <https://github.com/adhtruong>`_ in `#389 <https://github.com/litestar-org/polyfactory/pull/389>`_

Infra
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`eddb978 <https://github.com/litestar-org/polyfactory/commit/eddb9789b45836c3619d97d03b85c90f66ed1099>`_)  - Migrate to pdm and full ruff (#384)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#384 <https://github.com/litestar-org/polyfactory/pull/384>`_

`Release [v2.9.0] - 2023-09-19 <https://github.com/litestar-org/polyfactory/releases/tag/v2.9.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.9.0 <https://github.com/litestar-org/polyfactory/commits/v2.9.0>`_

`ebf30ff <https://github.com/litestar-org/polyfactory/commit/ebf30ff6e05807ee6073f1fb04667f17498424d5>`_ ... `f2c6fe1 <https://github.com/litestar-org/polyfactory/commit/f2c6fe19eb632b04b0efa20b909df96e6d9c6c68>`_ | `See diff for 2.9.0 <https://github.com/litestar-org/polyfactory/compare/ebf30ff6e05807ee6073f1fb04667f17498424d5...f2c6fe19eb632b04b0efa20b909df96e6d9c6c68>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`2a20513 <https://github.com/litestar-org/polyfactory/commit/2a20513621e1c7c7c1f53c66ad43880b4695ea07>`_)  - Properly type hint create_factory (#360)  by `@vkcku <https://github.com/vkcku>`_ in `#360 <https://github.com/litestar-org/polyfactory/pull/360>`_
* (`6cc7b03 <https://github.com/litestar-org/polyfactory/commit/6cc7b03067463e1b4d8a8a007b78a44265e6de36>`_)  - ``AttrsFactory`` fixes (#370)  by `@vkcku <https://github.com/vkcku>`_ in `#370 <https://github.com/litestar-org/polyfactory/pull/370>`_
* (`8e41372 <https://github.com/litestar-org/polyfactory/commit/8e41372f0fc1ae7abfbd41c074e8bb5246f3e188>`_)  - Update fixture size handling (#373)  by `@adhtruong <https://github.com/adhtruong>`_ in `#373 <https://github.com/litestar-org/polyfactory/pull/373>`_
* (`87a6749 <https://github.com/litestar-org/polyfactory/commit/87a67493d839a5a61ea2df2b31eb909a60426a58>`_)  - Dataclass field type not used correctly (#371)  by `@anthonyjgraff <https://github.com/anthonyjgraff>`_ in `#371 <https://github.com/litestar-org/polyfactory/pull/371>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`6f4b712 <https://github.com/litestar-org/polyfactory/commit/6f4b7127091967bbcbcd561611309d926eb1dcbe>`_)  - Add adhtruong as a contributor for doc, test, and code (#375)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#375 <https://github.com/litestar-org/polyfactory/pull/375>`_
* (`64c4e6c <https://github.com/litestar-org/polyfactory/commit/64c4e6cfadd8bdbd6b2fa6af812448c3ba537fb6>`_)  - Add anthonyjgraff as a contributor for code (#374)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#374 <https://github.com/litestar-org/polyfactory/pull/374>`_
* (`f2c6fe1 <https://github.com/litestar-org/polyfactory/commit/f2c6fe19eb632b04b0efa20b909df96e6d9c6c68>`_)  - Add guacs as a contributor for infra, code, and 2 more (#380)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#380 <https://github.com/litestar-org/polyfactory/pull/380>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`c76ffc9 <https://github.com/litestar-org/polyfactory/commit/c76ffc9e181128d26b448622792f9876bd6f3bac>`_)  - Implement SQLA factory (#369)  by `@adhtruong <https://github.com/adhtruong>`_ in `#369 <https://github.com/litestar-org/polyfactory/pull/369>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`fc0bf61 <https://github.com/litestar-org/polyfactory/commit/fc0bf6131af6d4480da6e9b0102f1df67180d92a>`_)  - Update maintainers  by `@provinzkraut <https://github.com/provinzkraut>`_
* (`f67f36e <https://github.com/litestar-org/polyfactory/commit/f67f36e45f67a80bfe63e7df88310f97196e6830>`_)  - Ignore .all-contributorsrc for in .pre-commit (#377)  by `@adhtruong <https://github.com/adhtruong>`_ in `#377 <https://github.com/litestar-org/polyfactory/pull/377>`_
* (`66e9db1 <https://github.com/litestar-org/polyfactory/commit/66e9db170958d89648df64593e02d43196493f42>`_)  - Fix all-contributors config  by `@JacobCoffee <https://github.com/JacobCoffee>`_

Testing
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`ec177ec <https://github.com/litestar-org/polyfactory/commit/ec177ec2d0e12bddb37af285982b0b453e2cbd06>`_)  - Make ``pytest`` configuration stricter (#363)  by `@sobolevn <https://github.com/sobolevn>`_ in `#363 <https://github.com/litestar-org/polyfactory/pull/363>`_
* (`95d24cb <https://github.com/litestar-org/polyfactory/commit/95d24cb193e2e6fbfa87c642266f0ae907e3ccdd>`_)  - Skip variable length dict test for odmantic (#372)  by `@vkcku <https://github.com/vkcku>`_ in `#372 <https://github.com/litestar-org/polyfactory/pull/372>`_

Infra
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`adccaf0 <https://github.com/litestar-org/polyfactory/commit/adccaf0a5d6261e088b1bd58f54efdd2c1b54147>`_)  - Enable publishing with PyPI trusted publishers (#368)  by `@provinzkraut <https://github.com/provinzkraut>`_ in `#368 <https://github.com/litestar-org/polyfactory/pull/368>`_

`Release [v2.8.2] - 2023-09-15 <https://github.com/litestar-org/polyfactory/releases/tag/v2.8.2>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.8.2 <https://github.com/litestar-org/polyfactory/commits/v2.8.2>`_

`7af5469 <https://github.com/litestar-org/polyfactory/commit/7af5469440fb2450fdfb68403985f1b67d6e4a92>`_ ... `ebf30ff <https://github.com/litestar-org/polyfactory/commit/ebf30ff6e05807ee6073f1fb04667f17498424d5>`_ | `See diff for 2.8.2 <https://github.com/litestar-org/polyfactory/compare/7af5469440fb2450fdfb68403985f1b67d6e4a92...ebf30ff6e05807ee6073f1fb04667f17498424d5>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`f639c26 <https://github.com/litestar-org/polyfactory/commit/f639c26b630788c3dbcb9c7186d22f20eb59796b>`_)  - Properly set annotation in union with nested Annotated (#355)  by `@vkcku <https://github.com/vkcku>`_ in `#355 <https://github.com/litestar-org/polyfactory/pull/355>`_
* (`ebf30ff <https://github.com/litestar-org/polyfactory/commit/ebf30ff6e05807ee6073f1fb04667f17498424d5>`_)  - Add minimum version constraint to attrs (#359)  by `@vkcku <https://github.com/vkcku>`_ in `#359 <https://github.com/litestar-org/polyfactory/pull/359>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`091ee36 <https://github.com/litestar-org/polyfactory/commit/091ee36f6ee7e51f73fe6bebabb1bda442faed35>`_)  - Change the comment length in "Handling custom types" docs (#361)  by `@sobolevn <https://github.com/sobolevn>`_ in `#361 <https://github.com/litestar-org/polyfactory/pull/361>`_

`Release [v2.8.1] - 2023-09-10 <https://github.com/litestar-org/polyfactory/releases/tag/v2.8.1>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.8.1 <https://github.com/litestar-org/polyfactory/commits/v2.8.1>`_

`7b46b57 <https://github.com/litestar-org/polyfactory/commit/7b46b572a71b347ac650658fe066641e631cedd6>`_ ... `7af5469 <https://github.com/litestar-org/polyfactory/commit/7af5469440fb2450fdfb68403985f1b67d6e4a92>`_ | `See diff for 2.8.1 <https://github.com/litestar-org/polyfactory/compare/7b46b572a71b347ac650658fe066641e631cedd6...7af5469440fb2450fdfb68403985f1b67d6e4a92>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`3dba4be <https://github.com/litestar-org/polyfactory/commit/3dba4be756d1d4e2b132f1650949bc9e0cdaa3ec>`_)  - Use full Python version for venv cache (#352)  by `@vkcku <https://github.com/vkcku>`_ in `#352 <https://github.com/litestar-org/polyfactory/pull/352>`_
* (`257852a <https://github.com/litestar-org/polyfactory/commit/257852af883c7a34e7a8be4494139f36825be08b>`_)  - Add missing factories to builtin registration (#351)  by `@vkcku <https://github.com/vkcku>`_ in `#351 <https://github.com/litestar-org/polyfactory/pull/351>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`e4daf5f <https://github.com/litestar-org/polyfactory/commit/e4daf5f6e4f7e17cad6bb75d8ff81fbb3145958a>`_)  - Add adhtruong as a contributor for code (#346)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#346 <https://github.com/litestar-org/polyfactory/pull/346>`_
* (`9ffe596 <https://github.com/litestar-org/polyfactory/commit/9ffe596836271a86ae2a8d0fdb06b2b94d287f54>`_)  - Expose all options (#350)  by `@adhtruong <https://github.com/adhtruong>`_ in `#350 <https://github.com/litestar-org/polyfactory/pull/350>`_
* (`7a5a1c9 <https://github.com/litestar-org/polyfactory/commit/7a5a1c9a228feaf29ce8211a130daf354725a5ee>`_)  - Add adhtruong as a contributor for doc (#353)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#353 <https://github.com/litestar-org/polyfactory/pull/353>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`4f2e5d8 <https://github.com/litestar-org/polyfactory/commit/4f2e5d84d7b2c837a21295f886c9bc04f4ed3534>`_)  - Updated dependencies  by `@Goldziher <https://github.com/Goldziher>`_
* (`161c0f6 <https://github.com/litestar-org/polyfactory/commit/161c0f69344105a827ee4701e91da159b70b1c08>`_)  - Bump actions/checkout from 3 to 4 (#349)  by `@dependabot[bot] <https://github.com/dependabot[bot]>`_ in `#349 <https://github.com/litestar-org/polyfactory/pull/349>`_
* (`7af5469 <https://github.com/litestar-org/polyfactory/commit/7af5469440fb2450fdfb68403985f1b67d6e4a92>`_)  - Prepare v2.8.1 (#354)  by `@vkcku <https://github.com/vkcku>`_ in `#354 <https://github.com/litestar-org/polyfactory/pull/354>`_

`Release [v2.8.0] - 2023-08-26 <https://github.com/litestar-org/polyfactory/releases/tag/v2.8.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.8.0 <https://github.com/litestar-org/polyfactory/commits/v2.8.0>`_

`710d3ce <https://github.com/litestar-org/polyfactory/commit/710d3ce48e72e36b7e4fabc3a739dd0afc34d317>`_ ... `7b46b57 <https://github.com/litestar-org/polyfactory/commit/7b46b572a71b347ac650658fe066641e631cedd6>`_ | `See diff for 2.8.0 <https://github.com/litestar-org/polyfactory/compare/710d3ce48e72e36b7e4fabc3a739dd0afc34d317...7b46b572a71b347ac650658fe066641e631cedd6>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`3ec7de8 <https://github.com/litestar-org/polyfactory/commit/3ec7de8693efa8a0d16abda0d7a17d4cf5d840ee>`_)  - Ensure no override of Faker instance (#331)  by `@vkcku <https://github.com/vkcku>`_ in `#331 <https://github.com/litestar-org/polyfactory/pull/331>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`ea41bbe <https://github.com/litestar-org/polyfactory/commit/ea41bbe6097813de9354e75fff33c785f5c54de2>`_)  - Add 185504a9 as a contributor for code (#339)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#339 <https://github.com/litestar-org/polyfactory/pull/339>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`510fabd <https://github.com/litestar-org/polyfactory/commit/510fabdffec6b3f0147a136b8cdd50c0337d09a9>`_)  - Support constraints for mapping types (#337)  by `@vkcku <https://github.com/vkcku>`_ in `#337 <https://github.com/litestar-org/polyfactory/pull/337>`_
* (`0228d3d <https://github.com/litestar-org/polyfactory/commit/0228d3dd81015bb3dfc1add6f3f4b7d1b5f2b6a1>`_)  - Add pydantic's AwareDatetime to the mock map (#333)  by `@185504a9 <https://github.com/185504a9>`_ in `#333 <https://github.com/litestar-org/polyfactory/pull/333>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`bf04fa6 <https://github.com/litestar-org/polyfactory/commit/bf04fa625e3457d81059d754d10e36642a160e8a>`_)  - Updated dependencies (#338)  by `@Goldziher <https://github.com/Goldziher>`_ in `#338 <https://github.com/litestar-org/polyfactory/pull/338>`_

`Release [v2.7.2] - 2023-08-09 <https://github.com/litestar-org/polyfactory/releases/tag/v2.7.2>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.7.2 <https://github.com/litestar-org/polyfactory/commits/v2.7.2>`_

`04a504b <https://github.com/litestar-org/polyfactory/commit/04a504b7db5713d5e6027c230313ff383bcba252>`_ ... `710d3ce <https://github.com/litestar-org/polyfactory/commit/710d3ce48e72e36b7e4fabc3a739dd0afc34d317>`_ | `See diff for 2.7.2 <https://github.com/litestar-org/polyfactory/compare/04a504b7db5713d5e6027c230313ff383bcba252...710d3ce48e72e36b7e4fabc3a739dd0afc34d317>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`725835e <https://github.com/litestar-org/polyfactory/commit/725835edf8f3c4a4e6e6741ba4f4deeb24192a11>`_)  - Fix pydantic core import (#329)  by `@vkcku <https://github.com/vkcku>`_ in `#329 <https://github.com/litestar-org/polyfactory/pull/329>`_

`Release [v2.7.1] - 2023-08-08 <https://github.com/litestar-org/polyfactory/releases/tag/v2.7.1>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.7.1 <https://github.com/litestar-org/polyfactory/commits/v2.7.1>`_

`3e45f8f <https://github.com/litestar-org/polyfactory/commit/3e45f8f331d12ae395779567f5127b1bc18af23e>`_ ... `04a504b <https://github.com/litestar-org/polyfactory/commit/04a504b7db5713d5e6027c230313ff383bcba252>`_ | `See diff for 2.7.1 <https://github.com/litestar-org/polyfactory/compare/3e45f8f331d12ae395779567f5127b1bc18af23e...04a504b7db5713d5e6027c230313ff383bcba252>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`2733497 <https://github.com/litestar-org/polyfactory/commit/2733497369a065cf7c50006921967b93a02e0434>`_)  - Add support for Json type in Pydantic factory (#315)  by `@vkcku <https://github.com/vkcku>`_ in `#315 <https://github.com/litestar-org/polyfactory/pull/315>`_
* (`3aeaa0c <https://github.com/litestar-org/polyfactory/commit/3aeaa0cb290225e912ddda3d242b280839e04582>`_)  - Constrained strings not deterministic with seed because urandom not seedable (#319)  by `@klimantje <https://github.com/klimantje>`_ in `#319 <https://github.com/litestar-org/polyfactory/pull/319>`_
* (`61f1e2e <https://github.com/litestar-org/polyfactory/commit/61f1e2e0d857ffd111ab8c8d7cfbab6f67230ae1>`_)  - Random seed configuration (#321)  by `@vkcku <https://github.com/vkcku>`_ in `#321 <https://github.com/litestar-org/polyfactory/pull/321>`_
* (`2400fbe <https://github.com/litestar-org/polyfactory/commit/2400fbeb756deb5cdc32c666f2e27df31dff9387>`_)  - Include pydantic Field constraints when using Optional type (#323)  by `@tcrasset <https://github.com/tcrasset>`_ in `#323 <https://github.com/litestar-org/polyfactory/pull/323>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`8ff7e0f <https://github.com/litestar-org/polyfactory/commit/8ff7e0fbc3552869b7fcbcb1c8b71cfdf6c46dda>`_)  - Add klimantje as a contributor for code (#320)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#320 <https://github.com/litestar-org/polyfactory/pull/320>`_
* (`9def5b1 <https://github.com/litestar-org/polyfactory/commit/9def5b1f2a95470659db0bd2b80d742b6195c2da>`_)  - Add tcrasset as a contributor for code (#324)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#324 <https://github.com/litestar-org/polyfactory/pull/324>`_

Infra
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`5543e66 <https://github.com/litestar-org/polyfactory/commit/5543e66b1296cf3db8b1f66f0722fa05114ba266>`_)  - Fix health files (#322)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#322 <https://github.com/litestar-org/polyfactory/pull/322>`_

Meta
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`5abe4b3 <https://github.com/litestar-org/polyfactory/commit/5abe4b3df7dd9d3623d33332e8b6143b3806ccde>`_)  - Update issue template config  by `@JacobCoffee <https://github.com/JacobCoffee>`_

`Release [v2.7.0] - 2023-07-28 <https://github.com/litestar-org/polyfactory/releases/tag/v2.7.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.7.0 <https://github.com/litestar-org/polyfactory/commits/v2.7.0>`_

`e703593 <https://github.com/litestar-org/polyfactory/commit/e703593658e94b6aed938fbff161936f916d0e02>`_ ... `3e45f8f <https://github.com/litestar-org/polyfactory/commit/3e45f8f331d12ae395779567f5127b1bc18af23e>`_ | `See diff for 2.7.0 <https://github.com/litestar-org/polyfactory/compare/e703593658e94b6aed938fbff161936f916d0e02...3e45f8f331d12ae395779567f5127b1bc18af23e>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`0bfa3b4 <https://github.com/litestar-org/polyfactory/commit/0bfa3b497ecfe45c21e1d700e1c2aa8ec41db391>`_)  - Add litestar rename news link  by `@JacobCoffee <https://github.com/JacobCoffee>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`96c61ae <https://github.com/litestar-org/polyfactory/commit/96c61aeabe02cb135bfa5225c0dbe6459df41a8c>`_)  - Implementation of Attrs Factory (#313)  by `@vkcku <https://github.com/vkcku>`_ in `#313 <https://github.com/litestar-org/polyfactory/pull/313>`_

Infra
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`d385561 <https://github.com/litestar-org/polyfactory/commit/d38556127f40f009a8baf22e1ea5cb5f12603dd0>`_)  - Update codeowners (#311)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#311 <https://github.com/litestar-org/polyfactory/pull/311>`_

`Release [v2.6.3] - 2023-07-21 <https://github.com/litestar-org/polyfactory/releases/tag/v2.6.3>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.6.3 <https://github.com/litestar-org/polyfactory/commits/v2.6.3>`_

`86585d0 <https://github.com/litestar-org/polyfactory/commit/86585d064393017c448918d88e00853d370274e1>`_ ... `e703593 <https://github.com/litestar-org/polyfactory/commit/e703593658e94b6aed938fbff161936f916d0e02>`_ | `See diff for 2.6.3 <https://github.com/litestar-org/polyfactory/compare/86585d064393017c448918d88e00853d370274e1...e703593658e94b6aed938fbff161936f916d0e02>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`7405901 <https://github.com/litestar-org/polyfactory/commit/7405901e0e861abcb3256d0f09f22180880ed4e0>`_)  - Remove stray badge (#306)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#306 <https://github.com/litestar-org/polyfactory/pull/306>`_
* (`b1f8f6e <https://github.com/litestar-org/polyfactory/commit/b1f8f6e7e05f8741a79d166fbeac862a002236d5>`_)  - Remove stray character from README  by `@JacobCoffee <https://github.com/JacobCoffee>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`c936389 <https://github.com/litestar-org/polyfactory/commit/c9363893b50f1763ee08ccb421856c470f2d9fff>`_)  - Update poetry dependencies (#308)  by `@Goldziher <https://github.com/Goldziher>`_ in `#308 <https://github.com/litestar-org/polyfactory/pull/308>`_
* (`09f896c <https://github.com/litestar-org/polyfactory/commit/09f896c4d47e9232fe1870fd40f1eef73ddc4f5e>`_)  - Fix CONTRIBUTING.rst (#310)  by `@provinzkraut <https://github.com/provinzkraut>`_ in `#310 <https://github.com/litestar-org/polyfactory/pull/310>`_
* (`3fadfb7 <https://github.com/litestar-org/polyfactory/commit/3fadfb712b5f967ecb27719ba7f92b20788b108b>`_)  - Fix annotated field resolution (#309)  by `@Goldziher <https://github.com/Goldziher>`_ in `#309 <https://github.com/litestar-org/polyfactory/pull/309>`_

`Release [v2.6.2] - 2023-07-14 <https://github.com/litestar-org/polyfactory/releases/tag/v2.6.2>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.6.2 <https://github.com/litestar-org/polyfactory/commits/v2.6.2>`_

`d331ae0 <https://github.com/litestar-org/polyfactory/commit/d331ae03a9e11733d5b2b14b4ad190f7281d663a>`_ ... `86585d0 <https://github.com/litestar-org/polyfactory/commit/86585d064393017c448918d88e00853d370274e1>`_ | `See diff for 2.6.2 <https://github.com/litestar-org/polyfactory/compare/d331ae03a9e11733d5b2b14b4ad190f7281d663a...86585d064393017c448918d88e00853d370274e1>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`a2be35a <https://github.com/litestar-org/polyfactory/commit/a2be35a535babbb5b6ed407e8f108f7aa9371067>`_)  - Switch to using faker.seed_instance (#305)  by `@Goldziher <https://github.com/Goldziher>`_ in `#305 <https://github.com/litestar-org/polyfactory/pull/305>`_
* (`86585d0 <https://github.com/litestar-org/polyfactory/commit/86585d064393017c448918d88e00853d370274e1>`_)  - 2.6.2  by `@Goldziher <https://github.com/Goldziher>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`f54f9f3 <https://github.com/litestar-org/polyfactory/commit/f54f9f3c0b849a2d06bf4a5332da80ccdc31d1a9>`_)  - Add passing test for issue 300 (#301)  by `@Goldziher <https://github.com/Goldziher>`_ in `#301 <https://github.com/litestar-org/polyfactory/pull/301>`_

`Release [v2.6.1] - 2023-07-10 <https://github.com/litestar-org/polyfactory/releases/tag/v2.6.1>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.6.1 <https://github.com/litestar-org/polyfactory/commits/v2.6.1>`_

`79e8145 <https://github.com/litestar-org/polyfactory/commit/79e81458edd3faeacac5b5e4f1b1cece196f326f>`_ ... `d331ae0 <https://github.com/litestar-org/polyfactory/commit/d331ae03a9e11733d5b2b14b4ad190f7281d663a>`_ | `See diff for 2.6.1 <https://github.com/litestar-org/polyfactory/compare/79e81458edd3faeacac5b5e4f1b1cece196f326f...d331ae03a9e11733d5b2b14b4ad190f7281d663a>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`7761834 <https://github.com/litestar-org/polyfactory/commit/776183494c4a0480b2ea5f168378eeffc30906b5>`_)  - Add abdulhaq-e as a contributor for code (#297)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#297 <https://github.com/litestar-org/polyfactory/pull/297>`_

`Release [v2.6.0] - 2023-07-09 <https://github.com/litestar-org/polyfactory/releases/tag/v2.6.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.6.0 <https://github.com/litestar-org/polyfactory/commits/v2.6.0>`_

`2b050bb <https://github.com/litestar-org/polyfactory/commit/2b050bb53552ec3dab944a8386b38e8fc104045d>`_ ... `79e8145 <https://github.com/litestar-org/polyfactory/commit/79e81458edd3faeacac5b5e4f1b1cece196f326f>`_ | `See diff for 2.6.0 <https://github.com/litestar-org/polyfactory/compare/2b050bb53552ec3dab944a8386b38e8fc104045d...79e81458edd3faeacac5b5e4f1b1cece196f326f>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`16cbc99 <https://github.com/litestar-org/polyfactory/commit/16cbc9938f3c6e1ce84953e074689869a649270b>`_)  - Fix pre-commit issues  by `@Goldziher <https://github.com/Goldziher>`_
* (`956472c <https://github.com/litestar-org/polyfactory/commit/956472cd5bba38af012684ed75133bc63d28d562>`_)  - Apply sourcery  by `@Goldziher <https://github.com/Goldziher>`_
* (`5cdfed3 <https://github.com/litestar-org/polyfactory/commit/5cdfed316621d9f53d364966e150daf9dadacb8a>`_)  - Updated dependencies  by `@Goldziher <https://github.com/Goldziher>`_

`Release [v2.5.0] - 2023-06-30 <https://github.com/litestar-org/polyfactory/releases/tag/v2.5.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.5.0 <https://github.com/litestar-org/polyfactory/commits/v2.5.0>`_

`79e50df <https://github.com/litestar-org/polyfactory/commit/79e50dfdbabca2c58eee54347edab3fc0e269bc3>`_ ... `2b050bb <https://github.com/litestar-org/polyfactory/commit/2b050bb53552ec3dab944a8386b38e8fc104045d>`_ | `See diff for 2.5.0 <https://github.com/litestar-org/polyfactory/compare/79e50dfdbabca2c58eee54347edab3fc0e269bc3...2b050bb53552ec3dab944a8386b38e8fc104045d>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`35e10da <https://github.com/litestar-org/polyfactory/commit/35e10daf2f2c00de3fcedf857b180741bef22302>`_)  - All contributors (#263)  by `@Goldziher <https://github.com/Goldziher>`_ in `#263 <https://github.com/litestar-org/polyfactory/pull/263>`_
* (`d592836 <https://github.com/litestar-org/polyfactory/commit/d592836295fd53f7d5604ffe671553a897613673>`_)  - Support overriding base factories locally (v2) (#267)  by `@gsakkis <https://github.com/gsakkis>`_ in `#267 <https://github.com/litestar-org/polyfactory/pull/267>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`2b8ae48 <https://github.com/litestar-org/polyfactory/commit/2b8ae487feef83143995a4765c70e53d90f270f3>`_)  - Add peterschutt as a contributor for maintenance, doc, and test (#264)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#264 <https://github.com/litestar-org/polyfactory/pull/264>`_
* (`a53c598 <https://github.com/litestar-org/polyfactory/commit/a53c598407aac551638a0f39d9a1173370e42ff6>`_)  - Update pypi image, update readme (#266)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#266 <https://github.com/litestar-org/polyfactory/pull/266>`_
* (`d0c8bfa <https://github.com/litestar-org/polyfactory/commit/d0c8bfab21f9ed0d918d51069b36359337294762>`_)  - Add mdczaplicki as a contributor for test, and code (#274)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#274 <https://github.com/litestar-org/polyfactory/pull/274>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`a7220f3 <https://github.com/litestar-org/polyfactory/commit/a7220f31428307b0a635216e3d9d1154b988eb91>`_)  - Add ``sourcery-ai`` config (#271)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#271 <https://github.com/litestar-org/polyfactory/pull/271>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`946cf08 <https://github.com/litestar-org/polyfactory/commit/946cf08dd5401929a0d8aaeb6eee8a6607e4ac11>`_)  - Updated deps  by `@Goldziher <https://github.com/Goldziher>`_
* (`e932f89 <https://github.com/litestar-org/polyfactory/commit/e932f8920e786e372e185e5c068543587a4b6861>`_)  - Applied sourcery (#281)  by `@Goldziher <https://github.com/Goldziher>`_ in `#281 <https://github.com/litestar-org/polyfactory/pull/281>`_
* (`0c0ed22 <https://github.com/litestar-org/polyfactory/commit/0c0ed221c68b3e19951f6861cf65c4e2bd8f265e>`_)  - Adjust to pydantic v2 (#284)  by `@Goldziher <https://github.com/Goldziher>`_ in `#284 <https://github.com/litestar-org/polyfactory/pull/284>`_

Release
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`2b050bb <https://github.com/litestar-org/polyfactory/commit/2b050bb53552ec3dab944a8386b38e8fc104045d>`_)  - Update README for v2.5.0 and pydantic v2 (#285)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#285 <https://github.com/litestar-org/polyfactory/pull/285>`_

`Release [v2.4.0] - 2023-06-25 <https://github.com/litestar-org/polyfactory/releases/tag/v2.4.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.4.0 <https://github.com/litestar-org/polyfactory/commits/v2.4.0>`_

`5013069 <https://github.com/litestar-org/polyfactory/commit/5013069b9a1d6adbdd5b1ee27bf5e4a73c00fac0>`_ ... `79e50df <https://github.com/litestar-org/polyfactory/commit/79e50dfdbabca2c58eee54347edab3fc0e269bc3>`_ | `See diff for 2.4.0 <https://github.com/litestar-org/polyfactory/compare/5013069b9a1d6adbdd5b1ee27bf5e4a73c00fac0...79e50dfdbabca2c58eee54347edab3fc0e269bc3>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`26073c4 <https://github.com/litestar-org/polyfactory/commit/26073c4db7b50a4dc90f60e3714b86c6db8a1def>`_)  - Support overriding base factories locally (#238)  by `@Goldziher <https://github.com/Goldziher>`_ in `#238 <https://github.com/litestar-org/polyfactory/pull/238>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`d625936 <https://github.com/litestar-org/polyfactory/commit/d62593698118fbfa9350b5ad0b7147ad257a0f2a>`_)  - Add Simske as a contributor for code (#242)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#242 <https://github.com/litestar-org/polyfactory/pull/242>`_
* (`2b93de6 <https://github.com/litestar-org/polyfactory/commit/2b93de6800a87b97c531162cafaec4b8dd3c2eea>`_)  - Add danielkatzan as a contributor for doc (#261)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#261 <https://github.com/litestar-org/polyfactory/pull/261>`_
* (`1511c9e <https://github.com/litestar-org/polyfactory/commit/1511c9eca5f6b97aea7a1eaadf4aac9166309069>`_)  - Add gegnew as a contributor for code (#262)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#262 <https://github.com/litestar-org/polyfactory/pull/262>`_
* (`d355511 <https://github.com/litestar-org/polyfactory/commit/d35551182759797996494ead26f054f56f77fc65>`_)  - Add roeeyn as a contributor for doc (#260)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#260 <https://github.com/litestar-org/polyfactory/pull/260>`_
* (`c686ddd <https://github.com/litestar-org/polyfactory/commit/c686ddd2a4e935b40c3f93a3c6b84ef69a04cbdf>`_)  - Add gigelu as a contributor for doc (#259)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#259 <https://github.com/litestar-org/polyfactory/pull/259>`_
* (`9101134 <https://github.com/litestar-org/polyfactory/commit/910113431cc96e01cab2a3707a05cf13b9e4579f>`_)  - Add ReznikovRoman as a contributor for code (#258)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#258 <https://github.com/litestar-org/polyfactory/pull/258>`_
* (`1e4df30 <https://github.com/litestar-org/polyfactory/commit/1e4df304212a6d3291a148aee70e3011771432f7>`_)  - Add anthonyh209 as a contributor for code (#257)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#257 <https://github.com/litestar-org/polyfactory/pull/257>`_
* (`c6657e7 <https://github.com/litestar-org/polyfactory/commit/c6657e7fdfcbcac78a9b9c032b8b5c49904cc82e>`_)  - Add avihai-yosef as a contributor for code (#256)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#256 <https://github.com/litestar-org/polyfactory/pull/256>`_
* (`97cdad2 <https://github.com/litestar-org/polyfactory/commit/97cdad2b88de1c0dc2ce9a8205e4dce4151a1d76>`_)  - Add Iipin as a contributor for code (#254)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#254 <https://github.com/litestar-org/polyfactory/pull/254>`_
* (`9156cca <https://github.com/litestar-org/polyfactory/commit/9156cca1399a27c0cd9e3d1fb9e449e6f0f9a35f>`_)  - Add thorin-schiffer as a contributor for code (#253)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#253 <https://github.com/litestar-org/polyfactory/pull/253>`_
* (`02c1daa <https://github.com/litestar-org/polyfactory/commit/02c1daa2a0bc7c90d522de62f37c15203dca7d45>`_)  - Add lyz-code as a contributor for code (#252)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#252 <https://github.com/litestar-org/polyfactory/pull/252>`_
* (`e883d58 <https://github.com/litestar-org/polyfactory/commit/e883d58cf0eaebe694b5a54e30dfce73759031fc>`_)  - Add DaanRademaker as a contributor for code (#251)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#251 <https://github.com/litestar-org/polyfactory/pull/251>`_
* (`cd2e558 <https://github.com/litestar-org/polyfactory/commit/cd2e5582ca01dc1375ae7bb4f3d9e057cff91d8a>`_)  - Add nguyent as a contributor for code (#250)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#250 <https://github.com/litestar-org/polyfactory/pull/250>`_
* (`af594e3 <https://github.com/litestar-org/polyfactory/commit/af594e319db5420e0a76e7919743309987bd9d46>`_)  - Add EltonChou as a contributor for code (#249)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#249 <https://github.com/litestar-org/polyfactory/pull/249>`_
* (`bac2622 <https://github.com/litestar-org/polyfactory/commit/bac262255b656f7ec8ad2f0202f83dd3a59910de>`_)  - Add Butch78 as a contributor for code (#248)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#248 <https://github.com/litestar-org/polyfactory/pull/248>`_
* (`13e80a7 <https://github.com/litestar-org/polyfactory/commit/13e80a7b4c8cea8395c09443d561e372105f1b80>`_)  - Add lindycoder as a contributor for code (#247)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#247 <https://github.com/litestar-org/polyfactory/pull/247>`_
* (`3940de4 <https://github.com/litestar-org/polyfactory/commit/3940de43ce54d86385cf412007a7c261a5bb0590>`_)  - Add peterschutt as a contributor for code (#246)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#246 <https://github.com/litestar-org/polyfactory/pull/246>`_
* (`e598c7d <https://github.com/litestar-org/polyfactory/commit/e598c7ddcdcdef07a1cca448f898c3f8bb176cd8>`_)  - Add phbernardes as a contributor for code (#245)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#245 <https://github.com/litestar-org/polyfactory/pull/245>`_
* (`24a7766 <https://github.com/litestar-org/polyfactory/commit/24a7766a0f6888dc6548366f7af7535cb7d36fab>`_)  - Add mciszczon as a contributor for code (#244)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#244 <https://github.com/litestar-org/polyfactory/pull/244>`_
* (`b8cfe1a <https://github.com/litestar-org/polyfactory/commit/b8cfe1a3f581bf07b32a8102b9c975e88594cd6b>`_)  - Add sondrelg as a contributor for code (#243)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#243 <https://github.com/litestar-org/polyfactory/pull/243>`_

Fix
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`773b364 <https://github.com/litestar-org/polyfactory/commit/773b36460720cebd8afb246b63c0d8f09ea3faf4>`_)  - URL constraints and strict pydantic v2 values (#241)  by `@Goldziher <https://github.com/Goldziher>`_ in `#241 <https://github.com/litestar-org/polyfactory/pull/241>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`00dce8a <https://github.com/litestar-org/polyfactory/commit/00dce8a662eaf53aa38acf47ef8586855cc891fe>`_)  - Reformat readme  by `@Goldziher <https://github.com/Goldziher>`_

`Release [v2.3.3] - 2023-06-22 <https://github.com/litestar-org/polyfactory/releases/tag/v2.3.3>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.3.3 <https://github.com/litestar-org/polyfactory/commits/v2.3.3>`_

`aef7acb <https://github.com/litestar-org/polyfactory/commit/aef7acbc3c1222d351fad8bcb0a9517e1508165b>`_ ... `5013069 <https://github.com/litestar-org/polyfactory/commit/5013069b9a1d6adbdd5b1ee27bf5e4a73c00fac0>`_ | `See diff for 2.3.3 <https://github.com/litestar-org/polyfactory/compare/aef7acbc3c1222d351fad8bcb0a9517e1508165b...5013069b9a1d6adbdd5b1ee27bf5e4a73c00fac0>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`b9ea84d <https://github.com/litestar-org/polyfactory/commit/b9ea84d924942ee39d00871d4f4369a8b7a7a813>`_)  - Add VSHUMILIN97 as a contributor for code (#237)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#237 <https://github.com/litestar-org/polyfactory/pull/237>`_

`Release [v2.3.2] - 2023-06-18 <https://github.com/litestar-org/polyfactory/releases/tag/v2.3.2>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.3.2 <https://github.com/litestar-org/polyfactory/commits/v2.3.2>`_

`36c2f2f <https://github.com/litestar-org/polyfactory/commit/36c2f2f77a546b7992ab9f95a4904b1717d86e91>`_ ... `aef7acb <https://github.com/litestar-org/polyfactory/commit/aef7acbc3c1222d351fad8bcb0a9517e1508165b>`_ | `See diff for 2.3.2 <https://github.com/litestar-org/polyfactory/compare/36c2f2f77a546b7992ab9f95a4904b1717d86e91...aef7acbc3c1222d351fad8bcb0a9517e1508165b>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`5bd544f <https://github.com/litestar-org/polyfactory/commit/5bd544f41ca07cac7d45c493d6a5262d648a79ab>`_)  - Fix constant constraints (#233)  by `@Goldziher <https://github.com/Goldziher>`_ in `#233 <https://github.com/litestar-org/polyfactory/pull/233>`_

`Release [v2.1.2] - 2023-05-28 <https://github.com/litestar-org/polyfactory/releases/tag/v2.1.2>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.1.2 <https://github.com/litestar-org/polyfactory/commits/v2.1.2>`_

`f2ba049 <https://github.com/litestar-org/polyfactory/commit/f2ba049b06a0bb74a14c36cc5ef885c0fc8452ab>`_ ... `2e2f11a <https://github.com/litestar-org/polyfactory/commit/2e2f11a8489c09b113a67462221adc3c1450b97b>`_ | `See diff for 2.1.2 <https://github.com/litestar-org/polyfactory/compare/f2ba049b06a0bb74a14c36cc5ef885c0fc8452ab...2e2f11a8489c09b113a67462221adc3c1450b97b>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`9670d27 <https://github.com/litestar-org/polyfactory/commit/9670d27391f75f9f562f0663c2a0b2497d44e990>`_)  - Return the correct types in the provider map (#224)  by `@vkcku <https://github.com/vkcku>`_ in `#224 <https://github.com/litestar-org/polyfactory/pull/224>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`02a4c97 <https://github.com/litestar-org/polyfactory/commit/02a4c971ae56758bd625ff54a151a9b4e421a9fa>`_)  - Add guacs as a contributor for code (#221)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#221 <https://github.com/litestar-org/polyfactory/pull/221>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`d753504 <https://github.com/litestar-org/polyfactory/commit/d753504ada2efc91b7f7ea94ad5cc10b5ae3322e>`_)  - Remove typeddict imports from typing extensions  by `@Goldziher <https://github.com/Goldziher>`_
* (`2e2f11a <https://github.com/litestar-org/polyfactory/commit/2e2f11a8489c09b113a67462221adc3c1450b97b>`_)  - Resolve pydantic test issues  by `@Goldziher <https://github.com/Goldziher>`_

`Release [v2.1.0] - 2023-05-06 <https://github.com/litestar-org/polyfactory/releases/tag/v2.1.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.1.0 <https://github.com/litestar-org/polyfactory/commits/v2.1.0>`_

`d671ac2 <https://github.com/litestar-org/polyfactory/commit/d671ac2470b03411345bf4e57f0531cfa3c4c6f6>`_ ... `47d234b <https://github.com/litestar-org/polyfactory/commit/47d234bc2f36519fc5f5527766272d1e526734f4>`_ | `See diff for 2.1.0 <https://github.com/litestar-org/polyfactory/compare/d671ac2470b03411345bf4e57f0531cfa3c4c6f6...47d234bc2f36519fc5f5527766272d1e526734f4>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`1d5c645 <https://github.com/litestar-org/polyfactory/commit/1d5c645291d6134d0f7f3f8b90a4db206a429a39>`_)  - Fix README.md formatting (#197)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#197 <https://github.com/litestar-org/polyfactory/pull/197>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`f767011 <https://github.com/litestar-org/polyfactory/commit/f767011835432c55c93429c298262e736d7182ac>`_)  - Add sygutss as a contributor for bug (#201)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#201 <https://github.com/litestar-org/polyfactory/pull/201>`_
* (`36ff02e <https://github.com/litestar-org/polyfactory/commit/36ff02e23a22868a0276a0614ce96015ca89b9af>`_)  - Add chrisbeardy as a contributor for doc (#207)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#207 <https://github.com/litestar-org/polyfactory/pull/207>`_

Enhancement
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`a62c976 <https://github.com/litestar-org/polyfactory/commit/a62c97672ddfcfc6c7616e6cb6e6bab7efe25b87>`_)  - PostGenerated classmethods (#204)  by `@gsakkis <https://github.com/gsakkis>`_ in `#204 <https://github.com/litestar-org/polyfactory/pull/204>`_

Fix
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`af36991 <https://github.com/litestar-org/polyfactory/commit/af369911b8523d796fe6be5822aeea77e2b95eeb>`_)  - Random union types for dict (#200)  by `@sygutss <https://github.com/sygutss>`_ in `#200 <https://github.com/litestar-org/polyfactory/pull/200>`_

`Release [v2.0.1] - 2023-04-28 <https://github.com/litestar-org/polyfactory/releases/tag/v2.0.1>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.0.1 <https://github.com/litestar-org/polyfactory/commits/v2.0.1>`_

`1f8d94c <https://github.com/litestar-org/polyfactory/commit/1f8d94c522556d39b35b1ea0e79155b8e50ac152>`_ ... `d671ac2 <https://github.com/litestar-org/polyfactory/commit/d671ac2470b03411345bf4e57f0531cfa3c4c6f6>`_ | `See diff for 2.0.1 <https://github.com/litestar-org/polyfactory/compare/1f8d94c522556d39b35b1ea0e79155b8e50ac152...d671ac2470b03411345bf4e57f0531cfa3c4c6f6>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`60cdb30 <https://github.com/litestar-org/polyfactory/commit/60cdb30832068ad1643d71632c10490eb7b161e9>`_)  - Add mdczaplicki as a contributor for code (#185)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#185 <https://github.com/litestar-org/polyfactory/pull/185>`_
* (`8b5d903 <https://github.com/litestar-org/polyfactory/commit/8b5d90370a53743b63222cec8d210018568f2ffe>`_)  - Add przybylop as a contributor for code (#187)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#187 <https://github.com/litestar-org/polyfactory/pull/187>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`16f562f <https://github.com/litestar-org/polyfactory/commit/16f562f0bdf92d991deba79ce3e75d16df776896>`_)  - Update maintainers (#194)  by `@JacobCoffee <https://github.com/JacobCoffee>`_ in `#194 <https://github.com/litestar-org/polyfactory/pull/194>`_
* (`d671ac2 <https://github.com/litestar-org/polyfactory/commit/d671ac2470b03411345bf4e57f0531cfa3c4c6f6>`_)  - Bump release version  by `@JacobCoffee <https://github.com/JacobCoffee>`_

`Release [v2.0.0] - 2023-04-16 <https://github.com/litestar-org/polyfactory/releases/tag/v2.0.0>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.0.0 <https://github.com/litestar-org/polyfactory/commits/v2.0.0>`_

`cb71cd0 <https://github.com/litestar-org/polyfactory/commit/cb71cd0d7391cbedeaf5bd3275473fec7ef9347e>`_ ... `1f8d94c <https://github.com/litestar-org/polyfactory/commit/1f8d94c522556d39b35b1ea0e79155b8e50ac152>`_ | `See diff for 2.0.0 <https://github.com/litestar-org/polyfactory/compare/cb71cd0d7391cbedeaf5bd3275473fec7ef9347e...1f8d94c522556d39b35b1ea0e79155b8e50ac152>`_

Bug Fixes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`8097da7 <https://github.com/litestar-org/polyfactory/commit/8097da790a1d4b8c108f268b197ae0ad0c718723>`_)  - Update all-contrib placement  by `@JacobCoffee <https://github.com/JacobCoffee>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`0814bb8 <https://github.com/litestar-org/polyfactory/commit/0814bb8c10607aa4ade7fb9575ab65d8f04bc3d5>`_)  - Add JacobCoffee as a contributor for doc (#170)Co-authored-by: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#170 <https://github.com/litestar-org/polyfactory/pull/170>`_
* (`60511c9 <https://github.com/litestar-org/polyfactory/commit/60511c970f1d548b0a498f2d20b358c6798d046c>`_)  - Add Goldziher as a contributor for infra, test, and code (#171)Co-authored-by: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#171 <https://github.com/litestar-org/polyfactory/pull/171>`_
* (`3853048 <https://github.com/litestar-org/polyfactory/commit/385304873a79f394a74c4dca4048212b224d1adf>`_)  - Add provinzkraut as a contributor for code, test, and 6 more (#173)  by `@allcontributors[bot] <https://github.com/allcontributors[bot]>`_ in `#173 <https://github.com/litestar-org/polyfactory/pull/173>`_

`Release [v2.0.0alpha1] - 2023-04-11 <https://github.com/litestar-org/polyfactory/releases/tag/v2.0.0alpha1>`_
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* `See All commits in v2.0.0alpha1 <https://github.com/litestar-org/polyfactory/commits/v2.0.0alpha1>`_

Docs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`5f111e4 <https://github.com/litestar-org/polyfactory/commit/5f111e45295f63265a1f293aa3b2ab9989bcac7e>`_)  - Added Create Factory Method  by `@Butch78 <https://github.com/Butch78>`_
* (`b1f83b3 <https://github.com/litestar-org/polyfactory/commit/b1f83b3fdd785ab4df2e7e03e353b9e04acdac30>`_)  - Improved Inheritance  by `@Butch78 <https://github.com/Butch78>`_
* (`5293860 <https://github.com/litestar-org/polyfactory/commit/52938600016fe16efef8daac23841fb106d8d472>`_)  - Improved notes  by `@Butch78 <https://github.com/Butch78>`_

Documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`7ae2678 <https://github.com/litestar-org/polyfactory/commit/7ae26782508642faab7a100dff3160fd02bacaed>`_)  - Explain how to subclass ModelFactory to create your custom extensions  by `@lyz-code <https://github.com/lyz-code>`_
* (`218522f <https://github.com/litestar-org/polyfactory/commit/218522f689b5b208f9f7cd6d3763d6a82cc6c442>`_)  - Reorder changes in CHANGELOG (#91)  by `@ReznikovRoman <https://github.com/ReznikovRoman>`_ in `#91 <https://github.com/litestar-org/polyfactory/pull/91>`_

Features
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`4c2b931 <https://github.com/litestar-org/polyfactory/commit/4c2b93166ced4b7507290dd71a77c1f83631db69>`_)  - 2023 Branding  by `@JacobCoffee <https://github.com/JacobCoffee>`_

Miscellaneous Tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* (`25570f5 <https://github.com/litestar-org/polyfactory/commit/25570f5929dd644173a90148216c6669cfd0b79f>`_)  - Update polyfactory banner logo  by `@JacobCoffee <https://github.com/JacobCoffee>`_

Polyfactory Changelog
