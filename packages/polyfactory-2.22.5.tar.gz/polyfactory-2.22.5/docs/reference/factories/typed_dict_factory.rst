typed_dict_factory
==================

.. automodule:: polyfactory.factories.typed_dict_factory
