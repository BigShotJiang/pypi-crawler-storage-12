base_factory
============

.. automodule:: polyfactory.factories.base
