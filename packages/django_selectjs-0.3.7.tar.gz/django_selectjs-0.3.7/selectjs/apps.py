from django.apps import AppConfig


class SelectJSConfig(AppConfig):
    name = 'selectjs'
