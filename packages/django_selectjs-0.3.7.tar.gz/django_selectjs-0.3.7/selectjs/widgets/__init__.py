from .model_many_to_many_search_select import ModelM2MSearchSelectWidget
from .model_search_select import ModelSearchSelectWidget

__all__ = [
    "ModelSearchSelectWidget",
    "ModelM2MSearchSelectWidget",
]
