"""Claude Collector - Extract Claude Code conversations for training datasets"""
__version__ = "0.1.0"
