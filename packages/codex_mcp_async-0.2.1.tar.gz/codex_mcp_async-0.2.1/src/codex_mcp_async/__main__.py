"""
Entry point for codex-mcp-async package when run with python -m
"""

from .server import main

if __name__ == "__main__":
    main()