from django.apps import AppConfig


class UtilsConfig(AppConfig):
    name = "tawala.utils"
