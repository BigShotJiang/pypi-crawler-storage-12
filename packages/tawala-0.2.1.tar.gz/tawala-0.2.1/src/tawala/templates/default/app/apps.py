from django.apps import AppConfig


class TheSparkPlayhouseConfig(AppConfig):
    name = "app"
    verbose_name = "The Spark Playhouse"
