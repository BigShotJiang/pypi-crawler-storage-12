from django.apps import AppConfig


class ScriptsConfig(AppConfig):
    name = "scripts"
