#!/bin/bash
echo "Running MCP Memory Service with UV..."
python uv_wrapper.py "$@"
