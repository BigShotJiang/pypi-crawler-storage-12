#!/bin/bash

wget -qO docs/openapi.yml https://bucket.pdfdancer.com/api-doc/development-0.0.yml && echo success