def test_basic_image_positioning():
    pass
