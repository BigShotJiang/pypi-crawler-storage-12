#!/bin/sh


isort src/ tests/ && black src/ tests/ && flake8 src/
