===========
console url
===========

Server remote console URL

Compute v2

.. autoprogram-cliff:: openstack.compute.v2
   :command: console url *
