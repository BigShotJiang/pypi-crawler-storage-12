=================
consistency group
=================

Block Storage v2, v3

.. autoprogram-cliff:: openstack.volume.v3
   :command: consistency group add volume

.. autoprogram-cliff:: openstack.volume.v3
   :command: consistency group create

.. autoprogram-cliff:: openstack.volume.v3
   :command: consistency group delete

.. autoprogram-cliff:: openstack.volume.v3
   :command: consistency group list

.. autoprogram-cliff:: openstack.volume.v3
   :command: consistency group remove volume

.. autoprogram-cliff:: openstack.volume.v3
   :command: consistency group set

.. autoprogram-cliff:: openstack.volume.v3
   :command: consistency group show
