===============
ip availability
===============

Network v2

.. autoprogram-cliff:: openstack.network.v2
   :command: ip availability *
