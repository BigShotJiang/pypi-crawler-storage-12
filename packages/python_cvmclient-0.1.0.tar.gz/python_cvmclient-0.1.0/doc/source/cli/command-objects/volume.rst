======
volume
======

Block Storage v2, v3

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume create

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume delete

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume list

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume migrate

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume set

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume show

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume unset

Block Storage v3

.. autoprogram-cliff:: openstack.volume.v3
    :command: volume summary

.. autoprogram-cliff:: openstack.volume.v3
    :command: volume revert
