===================
federation protocol
===================

A **federation protocol** is used by the Identity service's OS-FEDERATION
extension. It is used by **identity providers** and **mappings**. Applicable to
Identity v3.

.. autoprogram-cliff:: openstack.identity.v3
   :command: federation protocol *
