=============
address group
=============

An **address group** is a group of IPv4 or IPv6 address blocks which could be
referenced as a remote source or destination when creating a security group
rule.

Network v2

.. autoprogram-cliff:: openstack.network.v2
   :command: address group *
