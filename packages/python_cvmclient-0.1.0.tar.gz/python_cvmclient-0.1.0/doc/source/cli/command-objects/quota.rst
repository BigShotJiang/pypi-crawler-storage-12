=====
quota
=====

Resource quotas appear in multiple APIs, OpenStackClient presents them as a
single object with multiple properties.

Block Storage v1, v3; Compute v2; Network v2

.. autoprogram-cliff:: openstack.common
   :command: quota *
