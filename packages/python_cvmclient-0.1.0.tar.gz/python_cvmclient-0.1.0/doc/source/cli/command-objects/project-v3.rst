=====================
project (Identity v3)
=====================

.. autoprogram-cliff:: openstack.identity.v3
   :command: project *
