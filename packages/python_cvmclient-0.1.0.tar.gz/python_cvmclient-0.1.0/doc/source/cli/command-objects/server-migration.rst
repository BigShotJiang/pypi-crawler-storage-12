================
server migration
================

A server migration provides a way to move an instance from one
host to another. There are four types of migration operation
supported: live migration, cold migration, resize and evacuation.

Compute v2

.. autoprogram-cliff:: openstack.compute.v2
   :command: server migration *
