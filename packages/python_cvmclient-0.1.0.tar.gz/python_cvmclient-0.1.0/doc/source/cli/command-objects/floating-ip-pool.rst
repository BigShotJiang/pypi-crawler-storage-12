================
floating ip pool
================

Network v2

.. autoprogram-cliff:: openstack.network.v2
   :command: floating ip pool *
