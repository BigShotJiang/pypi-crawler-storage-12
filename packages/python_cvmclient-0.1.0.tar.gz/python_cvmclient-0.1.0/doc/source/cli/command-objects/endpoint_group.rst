==============
endpoint group
==============

A **endpoint group** is used to create groups of endpoints that then
can be used to filter the endpoints that are available to a project.
Applicable to Identity v3

.. autoprogram-cliff:: openstack.identity.v3
   :command: endpoint group *
