=========
extension
=========

Many OpenStack server APIs include API extensions that enable
additional functionality.


.. autoprogram-cliff:: openstack.common
   :command: extension *
