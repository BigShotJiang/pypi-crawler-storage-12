=============
image metadef
=============

Image v2

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef namespace create

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef namespace delete

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef namespace list

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef namespace set

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef namespace show

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef resource type list

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef object create

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef object show

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef object list

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef object delete

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef object update

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef object property show

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef property create

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef property list

.. autoprogram-cliff:: openstack.image.v2
   :command: image metadef property show
