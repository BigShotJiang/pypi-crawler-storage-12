======================
application credential
======================

Identity v3

With application credentials, a user can grant their applications limited
access to their cloud resources. Once created, users can authenticate with an
application credential by using the ``v3applicationcredential`` auth type.


.. autoprogram-cliff:: openstack.identity.v3
   :command: application credential *
