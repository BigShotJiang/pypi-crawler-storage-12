=====
limit
=====

Identity v3

Limits are used to specify project-specific limits thresholds of resources.

.. autoprogram-cliff:: openstack.identity.v3
   :command: limit *
