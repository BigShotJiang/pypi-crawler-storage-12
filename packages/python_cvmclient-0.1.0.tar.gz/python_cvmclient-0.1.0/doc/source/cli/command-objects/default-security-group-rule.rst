===========================
default security group rule
===========================

A **default security group rule** specifies the template of the security group
rules which will be used by neutron to create rules in every new security group.

Network v2

.. autoprogram-cliff:: openstack.network.v2
   :command: default security group rule *
