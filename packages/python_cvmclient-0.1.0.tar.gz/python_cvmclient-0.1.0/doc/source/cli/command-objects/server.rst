======
server
======

Compute v2

.. autoprogram-cliff:: openstack.compute.v2
   :command: server add *

.. autoprogram-cliff:: openstack.compute.v2
   :command: server create

.. autoprogram-cliff:: openstack.compute.v2
   :command: server evacuate

.. autoprogram-cliff:: openstack.compute.v2
   :command: server delete

.. autoprogram-cliff:: openstack.compute.v2
   :command: server dump create

.. autoprogram-cliff:: openstack.compute.v2
   :command: server list

.. autoprogram-cliff:: openstack.compute.v2
   :command: server lock

.. autoprogram-cliff:: openstack.compute.v2
   :command: server migrate*

.. autoprogram-cliff:: openstack.compute.v2
   :command: server pause

.. autoprogram-cliff:: openstack.compute.v2
   :command: server reboot

.. autoprogram-cliff:: openstack.compute.v2
   :command: server rebuild

.. autoprogram-cliff:: openstack.compute.v2
   :command: server remove *

.. autoprogram-cliff:: openstack.compute.v2
   :command: server rescue

.. autoprogram-cliff:: openstack.compute.v2
   :command: server resize*

.. autoprogram-cliff:: openstack.compute.v2
   :command: server restore

.. autoprogram-cliff:: openstack.compute.v2
   :command: server resume

.. autoprogram-cliff:: openstack.compute.v2
   :command: server set

.. autoprogram-cliff:: openstack.compute.v2
   :command: server shelve

.. autoprogram-cliff:: openstack.compute.v2
   :command: server show

.. autoprogram-cliff:: openstack.compute.v2
   :command: server ssh

.. autoprogram-cliff:: openstack.compute.v2
   :command: server start

.. autoprogram-cliff:: openstack.compute.v2
   :command: server stop

.. autoprogram-cliff:: openstack.compute.v2
   :command: server suspend

.. autoprogram-cliff:: openstack.compute.v2
   :command: server unlock

.. autoprogram-cliff:: openstack.compute.v2
   :command: server unpause

.. autoprogram-cliff:: openstack.compute.v2
   :command: server unrescue

.. autoprogram-cliff:: openstack.compute.v2
   :command: server unset

.. autoprogram-cliff:: openstack.compute.v2
   :command: server unshelve
