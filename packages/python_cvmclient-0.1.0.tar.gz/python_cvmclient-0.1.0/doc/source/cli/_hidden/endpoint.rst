========
endpoint
========

.. NOTE(efried): This page is hidden from the main TOC; it's here so links in
   the wild redirect somewhere sane, because previously identity v2 and v3 were
   combined in a single page.

.. toctree::
   :maxdepth: 2

   ../command-objects/endpoint-v2
   ../command-objects/endpoint-v3
