.. _plugin-commands:

===============
Plugin Commands
===============

.. toctree::
   :maxdepth: 1

   aodh
   barbican
   cyborg
   designate
   gnocchi
   heat
   ironic
   ironic-inspector
   magnum
   manila
   mistral
   neutron
   octavia
   placement
   trove
   watcher
   zaqar
   zun
