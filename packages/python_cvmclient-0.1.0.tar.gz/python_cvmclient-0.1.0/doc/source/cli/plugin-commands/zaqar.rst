zaqar
-----

.. autoprogram-cliff:: openstack.messaging.v2
