# qualityvision

Face and Hand tracking using Mediapipe and OpenCV.

## Installation
```bash
pip install qualityvision
