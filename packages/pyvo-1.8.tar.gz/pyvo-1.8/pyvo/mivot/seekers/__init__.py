"""
``seekers`` package contains utilities for retrieving
components of VOTales or of Mivot blocks
"""