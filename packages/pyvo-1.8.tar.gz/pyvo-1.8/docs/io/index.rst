****************
IO (``pyvo.io``)
****************

This module contains submodules which handle datastructures related to the
virtual observatory.

.. toctree::
  :maxdepth: 1

  vosi
  uws
