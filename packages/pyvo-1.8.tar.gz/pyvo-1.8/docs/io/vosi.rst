***********************
VOSI (``pyvo.io.vosi``)
***********************

Reference/API
=============

.. automodapi:: pyvo.io.vosi.endpoint

.. automodapi:: pyvo.io.vosi.voresource

.. automodapi:: pyvo.io.vosi.vodataservice

.. automodapi:: pyvo.io.vosi.tapregext

.. automodapi:: pyvo.io.vosi.availability
