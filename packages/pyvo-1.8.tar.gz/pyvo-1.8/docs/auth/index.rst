.. _pyvo-auth:

******************
Auth (`pyvo.auth`)
******************

This module contains submodules which help handle auth when
communicating with virtual observatory services.

Reference/API
=============

.. automodapi:: pyvo.auth
    :no-inheritance-diagram:
