"""Resource-Aware Data systems Tracker (radT) for automatically tracking and training machine learning software."""

__version__ = "0.2.21"

from .radt import cli
