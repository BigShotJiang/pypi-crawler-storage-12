"""
Exceptions personnalisées pour la bibliothèque Ondes Bot
"""


class LunRBotException(Exception):
    """Classe de base pour toutes les exceptions de la bibliothèque"""
    pass


class AuthenticationError(LunRBotException):
    """Erreur d'authentification"""
    pass


class EncryptionError(LunRBotException):
    """Erreur de chiffrement/déchiffrement"""
    pass


class WebSocketError(LunRBotException):
    """Erreur de connexion WebSocket"""
    pass


class APIError(LunRBotException):
    """Erreur lors d'un appel API"""
    pass


class MessageSendError(LunRBotException):
    """Erreur lors de l'envoi d'un message"""
    pass
