__version__ = "0.0.1"
# TSA-Core: Time as Code
