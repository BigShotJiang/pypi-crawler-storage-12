# TSA-Core — Temporal State Abstraction for AI

**`pip install tsa-core`**

The missing temporal layer: diffs, trajectories, decay for agents.

→ `tsa.diff("24h")` → `tsa.trajectory("BTC")`

Open-core. Launching Q1 2026.

https://tsacore.ai  
https://github.com/tsa-core/tsa-core