.. currentmodule:: xarray

Tutorial
========

.. autosummary::
   :toctree: ../generated/

   tutorial.open_dataset
   tutorial.load_dataset
   tutorial.open_datatree
   tutorial.load_datatree
