
## Manual overrides folder
This folder is used to override the manual assets. Every file in this folder will replace the [original ones](https://github.com/Stoupy51/StewBeet/tree/main/python_package/stewbeet/plugins/ingame_manual/assets) as long as the file name is the same.<br>
For instance, if you want to replace the `shaped_3x3.png` file, you need to create a `shaped_3x3.png` file in this folder.<br>

