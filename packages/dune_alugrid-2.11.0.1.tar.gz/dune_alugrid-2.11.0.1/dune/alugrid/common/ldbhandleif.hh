#ifndef DUNE_ALUGRID_LBHANDLIF_HH
#define DUNE_ALUGRID_LBHANDLIF_HH
// remove at some point....
struct LoadBalanceHandleWithReserveAndCompress {};
#endif
