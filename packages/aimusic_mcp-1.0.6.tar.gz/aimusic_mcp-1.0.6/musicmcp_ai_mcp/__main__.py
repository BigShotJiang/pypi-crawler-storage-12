from musicmcp_ai_mcp import main

main()
