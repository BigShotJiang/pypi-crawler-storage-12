"""Entry point for running the module with python -m mssql_mcp_server."""
from . import main

if __name__ == "__main__":
    main()