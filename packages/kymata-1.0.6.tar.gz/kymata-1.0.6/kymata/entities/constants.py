"""
Oft-used constant values, such as strings, which will never ever change.
"""
HEMI_LEFT = "left"
HEMI_RIGHT = "right"
