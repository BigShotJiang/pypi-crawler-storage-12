log_message = "%(asctime)s | %(levelname).2s | %(filename)s:%(lineno)d | \t%(message)s"
date_format = "%Y-%m-%d %H:%M:%S"
