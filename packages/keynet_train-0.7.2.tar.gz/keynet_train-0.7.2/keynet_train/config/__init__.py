"""Configuration module for keynet-train."""

from keynet_train.config.settings import TrainConfig

__all__ = ["TrainConfig"]
