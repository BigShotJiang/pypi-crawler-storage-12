This module extends the functionality of Sales to allow you to see the
price history of a product from a sale order line and set one of these
old prices in the sale order line.
