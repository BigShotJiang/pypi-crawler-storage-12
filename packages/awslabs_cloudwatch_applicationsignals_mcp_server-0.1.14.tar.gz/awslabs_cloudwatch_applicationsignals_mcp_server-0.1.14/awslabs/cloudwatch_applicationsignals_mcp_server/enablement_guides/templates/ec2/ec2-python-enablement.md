Placeholder content just to verify the tool can fetch the file.
