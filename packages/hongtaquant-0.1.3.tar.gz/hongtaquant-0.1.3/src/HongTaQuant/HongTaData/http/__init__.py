"""HTTP客户端模块"""

from HongTaQuant.HongTaData.http.client import HistoricalClient

__all__ = ["HistoricalClient"]