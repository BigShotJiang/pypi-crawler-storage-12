"""数据模型模块"""

from HongTaQuant.HongTaData.models.market_data import HSStockData, Quote

__all__ = ["HSStockData", "Quote"]
