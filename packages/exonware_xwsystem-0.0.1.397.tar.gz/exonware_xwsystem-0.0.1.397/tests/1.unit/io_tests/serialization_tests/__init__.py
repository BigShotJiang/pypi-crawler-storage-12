"""Unit tests for io.serialization sub-package."""

