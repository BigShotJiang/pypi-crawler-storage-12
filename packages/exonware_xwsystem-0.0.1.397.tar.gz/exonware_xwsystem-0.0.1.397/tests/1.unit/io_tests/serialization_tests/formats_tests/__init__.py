"""Unit tests for serialization formats."""

