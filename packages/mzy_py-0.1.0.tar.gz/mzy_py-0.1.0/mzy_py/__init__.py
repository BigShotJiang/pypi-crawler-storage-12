from .core import add, multiply  # 从core.py导出函数
from .utils import print_info

__version__ = "0.1.0"  # 版本号（重要，上传时不能重复）
__author__ = "马子延"