def mzy():
    print("I LOVE WeiJinHe")

def print_My_name():
    print("My name is Mzy, I am a student in BPU.")