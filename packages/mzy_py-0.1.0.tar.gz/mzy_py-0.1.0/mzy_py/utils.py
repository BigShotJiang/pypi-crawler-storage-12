def print_mzy():
    """打印包信息"""
    print("这是我的第一个开源pip包！")