module_overrides = "plugins.kubernetes"

toplevel = "global_aliases_for_metaflow_package"
