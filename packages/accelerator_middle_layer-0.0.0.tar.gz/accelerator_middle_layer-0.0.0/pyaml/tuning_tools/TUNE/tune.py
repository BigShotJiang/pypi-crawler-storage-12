class tune_correction():
    """tune correction help"""

    def run():
        """run tune correction"""

    def get_tune():
        """measure tune"""