# PyRosetta distributed

Meta package to install dependencies needed for `pyrosetta.distributed` framework. Note that you still need to install version of PyRosetta with serialization support. Please visit https://www.pyrosetta.org so find various ways to do so.