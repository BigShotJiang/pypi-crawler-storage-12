"""
Cross-App Access module for Okta AI SDK
"""

from .client import CrossAppAccessClient

__all__ = ["CrossAppAccessClient"]

