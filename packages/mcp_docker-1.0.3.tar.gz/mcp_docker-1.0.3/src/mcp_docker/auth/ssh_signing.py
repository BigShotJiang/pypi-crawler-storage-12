"""SSH key loading and signing utilities.

This module provides utilities for loading SSH private keys and creating signatures
using the cryptography library. Supports Ed25519, RSA, and ECDSA keys.

SECURITY: Uses cryptography library's OpenSSH format (battle-tested) for public
keys, making them compatible with standard SSH tooling and load_ssh_public_key().
"""

from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, rsa
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.primitives.asymmetric.types import PrivateKeyTypes

from mcp_docker.auth.ssh_wire import create_ssh_signature

# Type alias for supported SSH private key types
SSHPrivateKey = ed25519.Ed25519PrivateKey | rsa.RSAPrivateKey | ec.EllipticCurvePrivateKey


def load_private_key_from_file(
    key_path: str | Path,
) -> tuple[str, SSHPrivateKey]:
    """Load SSH private key from file.

    Supports Ed25519, RSA, and ECDSA keys in OpenSSH or PEM format.

    Args:
        key_path: Path to private key file

    Returns:
        Tuple of (key_type, private_key)
        key_type is "ssh-ed25519", "ssh-rsa", or "ecdsa-sha2-nistp256" etc.

    Raises:
        ValueError: If key format is unsupported
    """
    key_path = Path(key_path)

    with key_path.open("rb") as f:
        key_data = f.read()

    # Try to load as OpenSSH format first, then PEM
    loaded_key: PrivateKeyTypes
    try:
        loaded_key = serialization.load_ssh_private_key(key_data, password=None)
    except Exception:
        # Try PEM format
        loaded_key = serialization.load_pem_private_key(key_data, password=None)

    # Determine key type and narrow to SSHPrivateKey
    private_key: SSHPrivateKey
    if isinstance(loaded_key, ed25519.Ed25519PrivateKey):
        key_type = "ssh-ed25519"
        private_key = loaded_key
    elif isinstance(loaded_key, rsa.RSAPrivateKey):
        key_type = "ssh-rsa"
        private_key = loaded_key
    elif isinstance(loaded_key, ec.EllipticCurvePrivateKey):
        # Determine ECDSA curve
        curve = loaded_key.curve
        if isinstance(curve, ec.SECP256R1):
            key_type = "ecdsa-sha2-nistp256"
        elif isinstance(curve, ec.SECP384R1):
            key_type = "ecdsa-sha2-nistp384"
        elif isinstance(curve, ec.SECP521R1):
            key_type = "ecdsa-sha2-nistp521"
        else:
            raise ValueError(f"Unsupported ECDSA curve: {type(curve)}")
        private_key = loaded_key
    else:
        raise ValueError(f"Unsupported key type: {type(loaded_key)}")

    return key_type, private_key


def sign_message_ed25519(private_key: ed25519.Ed25519PrivateKey, message: bytes) -> bytes:
    """Sign message with Ed25519 private key.

    Args:
        private_key: Ed25519 private key
        message: Message to sign

    Returns:
        SSH wire format signature
    """
    # Sign the message
    signature_data = private_key.sign(message)

    # Create SSH wire format signature
    return create_ssh_signature("ssh-ed25519", signature_data)


def sign_message_rsa(
    private_key: rsa.RSAPrivateKey,
    message: bytes,
    algorithm: str = "rsa-sha2-512",
) -> bytes:
    """Sign message with RSA private key using secure hash algorithm.

    Only supports modern RSA signature algorithms using SHA-256 or SHA-512.
    Legacy ssh-rsa with SHA-1 is not supported due to security concerns.

    Args:
        private_key: RSA private key
        message: Message to sign
        algorithm: Signature algorithm to use. One of:
            - "rsa-sha2-512" (default, recommended - uses SHA-512)
            - "rsa-sha2-256" (uses SHA-256)

    Returns:
        SSH wire format signature

    Raises:
        ValueError: If algorithm is not supported

    Note:
        Defaults to rsa-sha2-512 for maximum security.
    """
    # Select hash algorithm based on requested signature type (secure algorithms only)
    hash_algo: hashes.SHA512 | hashes.SHA256
    if algorithm == "rsa-sha2-512":
        hash_algo = hashes.SHA512()
    elif algorithm == "rsa-sha2-256":
        hash_algo = hashes.SHA256()
    else:
        raise ValueError(
            f"Unsupported RSA signature algorithm: {algorithm}. "
            "Only 'rsa-sha2-512' and 'rsa-sha2-256' are supported. "
            "Legacy 'ssh-rsa' (SHA-1) is not supported for security reasons."
        )

    # Sign with PKCS1v15 padding and secure hash algorithm
    signature_data = private_key.sign(message, asym_padding.PKCS1v15(), hash_algo)

    # Create SSH wire format signature with the specified algorithm
    return create_ssh_signature(algorithm, signature_data)


def sign_message_ecdsa(private_key: ec.EllipticCurvePrivateKey, message: bytes) -> bytes:
    """Sign message with ECDSA private key.

    Args:
        private_key: ECDSA private key
        message: Message to sign

    Returns:
        SSH wire format signature
    """
    # Determine curve and hash algorithm
    curve = private_key.curve
    hash_algo: hashes.SHA256 | hashes.SHA384 | hashes.SHA512
    if isinstance(curve, ec.SECP256R1):
        key_type = "ecdsa-sha2-nistp256"
        hash_algo = hashes.SHA256()
    elif isinstance(curve, ec.SECP384R1):
        key_type = "ecdsa-sha2-nistp384"
        hash_algo = hashes.SHA384()
    elif isinstance(curve, ec.SECP521R1):
        key_type = "ecdsa-sha2-nistp521"
        hash_algo = hashes.SHA512()
    else:
        raise ValueError(f"Unsupported ECDSA curve: {type(curve)}")

    # Sign the message
    signature_data = private_key.sign(message, ec.ECDSA(hash_algo))

    # Create SSH wire format signature
    return create_ssh_signature(key_type, signature_data)


def sign_message(
    private_key: SSHPrivateKey,
    message: bytes,
    rsa_algorithm: str = "rsa-sha2-512",
) -> bytes:
    """Sign message with private key (auto-detect key type).

    Args:
        private_key: SSH private key
        message: Message to sign
        rsa_algorithm: RSA signature algorithm (only used for RSA keys).
            One of "rsa-sha2-512" (default) or "rsa-sha2-256".
            Legacy "ssh-rsa" (SHA-1) is not supported for security reasons.

    Returns:
        SSH wire format signature

    Raises:
        ValueError: If key type or algorithm is unsupported

    Note:
        For RSA keys, defaults to rsa-sha2-512 for maximum security.
        Ed25519 and ECDSA keys use their built-in hash algorithms.
    """
    if isinstance(private_key, ed25519.Ed25519PrivateKey):
        return sign_message_ed25519(private_key, message)
    if isinstance(private_key, rsa.RSAPrivateKey):
        return sign_message_rsa(private_key, message, algorithm=rsa_algorithm)
    if isinstance(private_key, ec.EllipticCurvePrivateKey):
        return sign_message_ecdsa(private_key, message)
    raise ValueError(f"Unsupported key type: {type(private_key)}")


def get_public_key_string(
    private_key: SSHPrivateKey,
) -> tuple[str, str]:
    """Get public key in OpenSSH format from private key.

    SECURITY: Uses cryptography library's OpenSSH format (battle-tested) instead
    of custom SSH wire format encoding. This format is compatible with
    load_ssh_public_key() and matches standard SSH tooling (ssh-keygen, ssh-add).

    Args:
        private_key: SSH private key

    Returns:
        Tuple of (key_type, public_key_base64) in OpenSSH format.
        Example: ("ssh-rsa", "AAAAB3NzaC1yc2EAAAADAQABAAABAQC...")

    Raises:
        ValueError: If key type is unsupported
    """
    # SECURITY: Use cryptography library's OpenSSH format (battle-tested)
    # instead of custom SSH wire format encoding. This format is compatible
    # with load_ssh_public_key() and matches standard SSH tooling.

    # Get public key from private key
    public_key = private_key.public_key()

    # Use OpenSSH format: "ssh-rsa AAAAB3Nza..." or "ssh-ed25519 AAAAC3Nza..."
    openssh_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.OpenSSH,
        format=serialization.PublicFormat.OpenSSH,
    )

    # Parse the OpenSSH format: "key_type base64_data"
    openssh_str = openssh_bytes.decode("utf-8")
    parts = openssh_str.split(None, 1)  # Split on first whitespace

    # OpenSSH format must have exactly 2 parts: key_type and base64_data
    expected_parts = 2
    if len(parts) != expected_parts:
        raise ValueError(f"Invalid OpenSSH format: {openssh_str}")

    key_type, public_key_b64 = parts
    return key_type, public_key_b64
