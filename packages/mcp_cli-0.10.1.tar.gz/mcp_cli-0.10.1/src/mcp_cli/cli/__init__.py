# mcp_cli/cli/__init__.py
"""
mcp_cli.cli

Holds the CLI-facing registry and subcommands under cli/commands.
"""
