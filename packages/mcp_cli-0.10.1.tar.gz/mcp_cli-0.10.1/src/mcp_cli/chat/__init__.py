# mcp_cli/chat/__init__.py
from mcp_cli.chat.chat_handler import handle_chat_mode

__all__ = ["handle_chat_mode"]
