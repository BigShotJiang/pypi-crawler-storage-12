"""CumulusCI Azure DevOps CLI package"""
