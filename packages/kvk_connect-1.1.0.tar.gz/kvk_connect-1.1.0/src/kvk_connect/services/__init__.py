# mappers package initialization
from .record_service import KVKRecordService

__all__ = ["KVKRecordService"]
