#
# Copyright (c) 2025, Speechmatics / Cantab Research Ltd
#


"""Speechmatics Python SDKs."""

__version__ = "0.1.1"

__all__ = [
    "__version__",
]
