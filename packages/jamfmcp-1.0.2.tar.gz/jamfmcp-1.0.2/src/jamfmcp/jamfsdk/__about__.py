__title__ = "jamfsdk"
__version__ = "0.2.0"
