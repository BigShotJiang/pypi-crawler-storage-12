__title__ = "JamfMCP"
__version__ = "1.0.2"
__description__ = "An async MCP server for Jamf Pro integration providing computer health analysis"
