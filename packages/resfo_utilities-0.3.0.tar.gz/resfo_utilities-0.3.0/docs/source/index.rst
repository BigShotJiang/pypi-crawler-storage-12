======================================================================
resfo-utilities: A library for working with reservoir simulator output
======================================================================


.. toctree::
   :maxdepth: 2

   self
   glossary
   api_reference
