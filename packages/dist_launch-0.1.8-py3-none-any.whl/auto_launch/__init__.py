"""
Auto Launch - One-click launch tool for distributed training
"""
__version__ = '0.1.0'

