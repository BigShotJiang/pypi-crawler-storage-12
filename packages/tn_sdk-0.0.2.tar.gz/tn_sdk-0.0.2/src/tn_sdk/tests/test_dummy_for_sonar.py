def test_dummy_test__different_input__returns_not_equal():
    assert round(1.8) != -1
