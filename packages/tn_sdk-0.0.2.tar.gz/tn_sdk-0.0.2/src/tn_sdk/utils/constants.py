SANDBOX_API_URL = "https://sandbox.tripninja.io"
PRODUCTION_API_URL = "https://api.tripninja.io"
DEFAULT_COMPRESSION_LEVEL = 6
