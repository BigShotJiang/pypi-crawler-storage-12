"""Mapillary data downloader."""

from importlib.metadata import version

__version__ = version("mapillary_downloader")
