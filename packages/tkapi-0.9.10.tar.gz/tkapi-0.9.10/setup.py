# This file is kept for backward compatibility.
# All package metadata is now in pyproject.toml.
from setuptools import setup

setup()
