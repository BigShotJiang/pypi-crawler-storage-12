---
name: Question 🤔
about: Usage question or discussion about garak.
labels: "question"
---

<!--
  To make it easier for us to help you, please include as much useful information as possible.

  Useful Links:
  - Wiki: https://docs.garak.ai/garak
  - Code reference: https://reference.garak.ai/

  Before opening a new issue, please search existing issues https://github.com/NVIDIA/garak/issues
-->

## Summary

## Relevant information

<!-- Provide as much useful information as you can -->
