garak.detectors.snowball
========================

.. automodule:: garak.detectors.snowball
   :members:
   :undoc-members:
   :show-inheritance:
