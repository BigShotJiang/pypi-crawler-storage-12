garak.generators.openai
=======================

.. automodule:: garak.generators.openai
   :members:
   :undoc-members:
   :show-inheritance:
