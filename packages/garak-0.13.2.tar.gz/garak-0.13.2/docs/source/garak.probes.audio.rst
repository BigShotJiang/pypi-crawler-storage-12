garak.probes.audio
==================

.. automodule:: garak.probes.audio
   :members:
   :undoc-members:
   :show-inheritance:

   .. show-asr::