garak.detectors.fileformats
===========================

.. automodule:: garak.detectors.fileformats
   :members:
   :undoc-members:
   :show-inheritance:
