garak.detectors.packagehallucination
====================================

.. automodule:: garak.detectors.packagehallucination
   :members:
   :undoc-members:
   :show-inheritance:
