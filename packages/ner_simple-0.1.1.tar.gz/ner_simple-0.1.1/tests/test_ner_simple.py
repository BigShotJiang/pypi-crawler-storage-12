def test_run_ner_import():
    from ner_simple import run_ner
    assert callable(run_ner)