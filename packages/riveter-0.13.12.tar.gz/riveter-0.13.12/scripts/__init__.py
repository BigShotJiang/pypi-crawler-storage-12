"""Scripts package for Riveter release workflow."""
