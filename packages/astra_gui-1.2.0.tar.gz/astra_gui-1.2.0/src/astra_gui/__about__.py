# SPDX-FileCopyrightText: 2025-present Faria22 <fariafelipe22@hotmail.com>
#
# SPDX-License-Identifier: MIT
"""Package metadata."""
__version__ = '1.2.0'
