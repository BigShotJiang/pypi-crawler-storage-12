"""Module for defining font styles used in the Astra GUI application."""

bold_font = ('Helvetica', 10, 'bold')
title_font = ('Helvetica', 18, 'bold', 'italic')
back_button_font = ('Helvetica', 18)
