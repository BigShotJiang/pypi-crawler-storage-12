from .main import *
main()
