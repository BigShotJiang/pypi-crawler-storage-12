from enum import Enum
from typing import Literal


class BeaverTailsType(Enum):
    BEAVERTAILS = "beaver_tails_safety_dataset"
