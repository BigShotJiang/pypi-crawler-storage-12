from .template import FairnessTemplate
from .types import FairnessType
