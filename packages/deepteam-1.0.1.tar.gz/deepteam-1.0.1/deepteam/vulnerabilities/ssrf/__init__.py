from .types import SSRFType
from .template import SSRFTemplate
