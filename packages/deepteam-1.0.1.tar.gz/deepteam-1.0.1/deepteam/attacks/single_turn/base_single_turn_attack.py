from deepteam.attacks.base_attack import BaseAttack


class BaseSingleTurnAttack(BaseAttack):
    pass
