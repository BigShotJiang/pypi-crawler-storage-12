# fhir-client
A simple client to interact, with FHIR servers. Can be used to ad, load, update and delete data on a FHIR server
