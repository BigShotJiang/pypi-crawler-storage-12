import pyproject_installer


def test_version():
    assert pyproject_installer.__version__
