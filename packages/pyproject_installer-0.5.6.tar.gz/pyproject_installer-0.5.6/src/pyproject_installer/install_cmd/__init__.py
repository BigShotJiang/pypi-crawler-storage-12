from ._install import install_wheel

__all__ = [
    "install_wheel",
]
