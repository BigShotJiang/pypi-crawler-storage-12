from enum import Enum

class DecisionMode(Enum):
    DECISION_API = 'API'
    BUCKETING = 'BUCKETING'
