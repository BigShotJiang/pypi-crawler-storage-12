## cdf 

### Improved

- [alpha] The `cdf data upload` command can now upload an asset
hierarchy. It does this by first uploading root assets, then one level
deep, two level deep, and so on.

## templates

No changes.