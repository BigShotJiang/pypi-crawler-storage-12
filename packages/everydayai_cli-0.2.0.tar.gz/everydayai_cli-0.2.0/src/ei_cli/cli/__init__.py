"""CLI package for commands and app."""
