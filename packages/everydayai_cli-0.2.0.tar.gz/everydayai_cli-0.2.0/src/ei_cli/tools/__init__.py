"""
EI CLI tools package.

Contains all available tools for the CLI.
"""
