"""
EverydayAI CLI (ei-cli) - Personal AI toolkit for regular people.

Created by Keith Williams - Director of Enterprise AI @ NJIT
"""

__version__ = "0.1.1"
__author__ = "Keith Williams"
__email__ = "kaw393939@gmail.com"
