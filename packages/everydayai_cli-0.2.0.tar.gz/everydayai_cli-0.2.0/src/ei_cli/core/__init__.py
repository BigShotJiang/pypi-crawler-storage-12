"""Core package for error handling, logging, plugins."""
