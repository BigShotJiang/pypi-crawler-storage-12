The following is an incomplete list of people outside the core team who have
contributed to Synapse. It is no longer maintained: more recent contributions
are listed in the `changelog <CHANGES.md>`_.

----

Turned to Dust <dwinslow86 at gmail.com>
 * ArchLinux installation instructions

Brabo <brabo at riseup.net>
 * Installation instruction fixes

Ivan Shapovalov <intelfx100 at gmail.com>
 * contrib/systemd: a sample systemd unit file and a logger configuration

Eric Myhre <hash at exultant.us>
 * Fix bug where ``media_store_path`` config option was ignored by v0 content
   repository API.

Muthu Subramanian <muthu.subramanian.karunanidhi at ericsson.com>
 * Add SAML2 support for registration and login.

Steven Hammerton <steven.hammerton at openmarket.com>
 * Add CAS support for registration and login.

Mads Robin Christensen <mads at v42 dot dk>
 * CentOS 7 installation instructions.

Florent Violleau <floviolleau at gmail dot com>
 * Add Raspberry Pi installation instructions and general troubleshooting items

Niklas Riekenbrauck <nikriek at gmail dot.com>
 * Add JWT support for registration and login

Christoph Witzany <christoph at web.crofting.com>
 * Add LDAP support for authentication

Pierre Jaury <pierre at jaury.eu>
 * Docker packaging

Serban Constantin <serban.constantin at gmail dot com>
 * Small bug fix

Joseph Weston <joseph at weston.cloud>
 * Add admin API for querying HS version

Benjamin Saunders <ben.e.saunders at gmail dot com>
 * Documentation improvements

Werner Sembach <werner.sembach at fau dot de>
 * Automatically remove a group/community when it is empty
