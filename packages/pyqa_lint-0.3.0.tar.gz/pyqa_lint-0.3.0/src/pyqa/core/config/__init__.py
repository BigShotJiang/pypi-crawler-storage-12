# SPDX-License-Identifier: MIT
# Copyright (c) 2025 Blackcat Informatics® Inc.
"""Core configuration helpers."""

from __future__ import annotations

__all__ = []
