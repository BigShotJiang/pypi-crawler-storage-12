<!-- SPDX-License-Identifier: MIT -->

<!-- Copyright (c) 2025 Blackcat Informatics® Inc. -->

# Config Defaults

## Overview

This document describes the pyqa.config.defaults module.

## Patterns

Summaries of key patterns and responsibilities belong here.

## DI Seams

Document dependency inversion touchpoints and service registration expectations.

## Extension Points

Outline supported extension seams and guidance for contributors.
