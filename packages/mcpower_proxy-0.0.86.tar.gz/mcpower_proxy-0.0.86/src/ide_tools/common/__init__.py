"""
Common IDE Tools

Shared logic for all IDE integrations.
"""
