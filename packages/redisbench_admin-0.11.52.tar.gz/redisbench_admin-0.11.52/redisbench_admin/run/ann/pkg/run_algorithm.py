from ann_benchmarks.runner import run_from_cmdline

run_from_cmdline()
