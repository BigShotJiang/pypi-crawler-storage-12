NAME_DB_INFO = 'db_info.json'
