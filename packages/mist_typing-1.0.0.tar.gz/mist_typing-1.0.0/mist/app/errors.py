class DependencyError(RuntimeError):
    """
    Error that is raised when a dependency is missing.
    """
    pass
