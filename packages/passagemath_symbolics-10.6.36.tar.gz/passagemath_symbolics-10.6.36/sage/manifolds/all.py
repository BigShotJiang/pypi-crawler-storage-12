# sage_setup: distribution = sagemath-symbolics
from sage.misc.lazy_import import lazy_import

lazy_import('sage.manifolds.manifold', 'Manifold')
lazy_import('sage.manifolds.differentiable.examples.euclidean', 'EuclideanSpace')
lazy_import('sage.manifolds', 'catalog', 'manifolds')
del lazy_import
