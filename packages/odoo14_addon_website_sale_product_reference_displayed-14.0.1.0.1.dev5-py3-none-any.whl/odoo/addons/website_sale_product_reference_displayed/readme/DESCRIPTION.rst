This module extends the ``website_sale`` views to display the product's full
display name, with its product reference included.

The Internal Reference is also shown explicitly in the product details and automatically updated when the chosen variant changes.
