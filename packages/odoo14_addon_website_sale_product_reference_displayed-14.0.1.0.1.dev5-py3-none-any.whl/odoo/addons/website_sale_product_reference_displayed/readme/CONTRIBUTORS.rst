* `Tecnativa <https://www.tecnativa.com>`_:

  * David Vidal
  * Carlos Roca
* `PyTech <https://www.pytech.it>`_:

  * Simone Rubino <simone.rubino@pytech.it>
