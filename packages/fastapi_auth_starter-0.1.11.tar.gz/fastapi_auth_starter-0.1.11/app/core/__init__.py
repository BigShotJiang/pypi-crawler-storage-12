"""
Core application configuration and utilities
"""

