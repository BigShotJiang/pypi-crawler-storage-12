# Agent Instructions for tonie-podcast-sync

## Project Overview
tonie-podcast-sync is a Python package that syncs podcast episodes to creative tonies (Toniebox). It downloads podcast episodes and uploads them to Tonie Cloud, which then syncs to physical Tonie figurines.
