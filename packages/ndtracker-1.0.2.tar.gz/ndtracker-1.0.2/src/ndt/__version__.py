"""Version information for ndt."""

__version__ = "1.0.2"
