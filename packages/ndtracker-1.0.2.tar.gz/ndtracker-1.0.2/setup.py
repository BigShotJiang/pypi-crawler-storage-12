"""Fallback setup.py for older pip versions."""
from setuptools import setup

setup()
