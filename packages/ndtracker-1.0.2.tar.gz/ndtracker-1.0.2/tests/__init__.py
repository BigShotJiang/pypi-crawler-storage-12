"""Test suite for neural dimensionality tracker."""
