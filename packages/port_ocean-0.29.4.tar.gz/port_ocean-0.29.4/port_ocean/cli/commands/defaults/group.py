from port_ocean.cli.commands.main import cli_start


@cli_start.group("defaults")
def defaults() -> None:
    pass
