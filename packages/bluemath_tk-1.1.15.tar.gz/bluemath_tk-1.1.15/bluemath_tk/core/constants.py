EARTH_RADIUS = 6378.135  # Earth radius in km
EARTH_RADIUS_NM = EARTH_RADIUS / 1.852  # Earth radius in nautical miles
