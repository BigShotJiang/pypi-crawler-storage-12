"""Surrogate models for SpotOptim."""

from .kriging import Kriging

__all__ = ["Kriging"]
