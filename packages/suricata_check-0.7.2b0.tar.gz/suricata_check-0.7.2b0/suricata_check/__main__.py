"""Main entrypoint for module referncing which can be used as a proxy for `suricata_check.suricata_check:main`."""

from suricata_check.suricata_check import main

if __name__ == "__main__":
    main()
