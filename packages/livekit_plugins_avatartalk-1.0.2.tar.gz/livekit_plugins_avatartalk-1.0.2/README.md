# AvatarTalk virtual avatar plugin for LiveKit Agents

Support for the [AvatarTalk](https://avatartalk.ai/) virtual avatar.

See [https://docs.livekit.io/agents/integrations/avatar/avatartalk/](https://docs.livekit.io/agents/integrations/avatar/avatartalk/) for more information.

