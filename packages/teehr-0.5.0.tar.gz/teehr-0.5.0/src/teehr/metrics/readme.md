Contains query code, numerics, etc.
Not intended to be called directly.