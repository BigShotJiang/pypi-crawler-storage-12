Visualizations and summaries, etc.
Not intended to be called directly.