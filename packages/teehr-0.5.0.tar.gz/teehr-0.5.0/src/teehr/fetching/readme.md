Code for fetching external data and importing various sources (parquet, csv, etc.)
Not intended to be called directly.