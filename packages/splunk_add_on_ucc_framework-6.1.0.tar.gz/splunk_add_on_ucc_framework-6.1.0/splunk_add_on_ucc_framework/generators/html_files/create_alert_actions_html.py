#
# Copyright 2025 Splunk Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from splunk_add_on_ucc_framework.generators.file_generator import FileGenerator
from splunk_add_on_ucc_framework.commands.modular_alert_builder import (
    arf_consts as ac,
    normalize,
)
from typing import Any, Optional
from os import linesep
from re import search
from splunk_add_on_ucc_framework.global_config import GlobalConfig


class AlertActionsHtml(FileGenerator):
    __description__ = (
        "Generates `alert_name.html` file based on alerts configuration present in globalConfig,"
        " in `default/data/ui/alerts` folder."
    )

    def __init__(
        self, global_config: GlobalConfig, input_dir: str, output_dir: str
    ) -> None:
        super().__init__(global_config, input_dir, output_dir)
        if global_config.has_alerts():
            self._html_home = "alert_html_skeleton.template"
            envs = normalize.normalize(
                global_config.alerts,
                global_config.namespace,
            )
            schema_content = envs["schema.content"]
            self._alert_settings = schema_content["modular_alerts"]

    def generate(self) -> Optional[list[dict[str, str]]]:
        if not self._global_config.has_alerts():
            return None

        alert_details: list[Any] = []
        for self.alert in self._alert_settings:
            self.set_template_and_render(
                template_file_path=["html_templates"],
                file_name="mod_alert.html.template",
            )
            rendered_content = self._template.render(
                mod_alert=self.alert, home_page=self._html_home
            )
            text = linesep.join(
                [s for s in rendered_content.splitlines() if not search(r"^\s*$", s)]
            )
            file_name = f"{self.alert[ac.SHORT_NAME] + '.html'}"
            file_path = self.get_file_output_path(
                [
                    "default",
                    "data",
                    "ui",
                    "alerts",
                    file_name,
                ]
            )
            alert_details.append(
                {"file_name": file_name, "file_path": file_path, "content": text}
            )
        return alert_details
