from typer import Typer


app = Typer(no_args_is_help=True)
