constants
=========


.. note:: Mapping of type annotations into concrete types.
    This is used to normalize Python <= 3.9 annotations.

.. automodule:: polyfactory.constants
    :members:
