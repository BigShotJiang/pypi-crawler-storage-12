odmantic_odm_factory
====================

.. automodule:: polyfactory.factories.odmantic_odm_factory
    :members:
