"""Constants used by pyTibber"""

from http import HTTPStatus
from typing import Final

__version__ = "0.33.0"

API_ENDPOINT: Final = "https://api.tibber.com/v1-beta/gql"
DATA_API_ENDPOINT: Final = "https://data-api.tibber.com"
USERINFO_ENDPOINT: Final = "https://thewall.tibber.com/connect/userinfo"
DEFAULT_TIMEOUT: Final = 10
DEMO_TOKEN: Final = "3A77EECF61BD445F47241A5A36202185C35AF3AF58609E19B53F3A8872AD7BE1-1"

RESOLUTION_HOURLY: Final = "HOURLY"
RESOLUTION_DAILY: Final = "DAILY"
RESOLUTION_WEEKLY: Final = "WEEKLY"
RESOLUTION_MONTHLY: Final = "MONTHLY"
RESOLUTION_ANNUAL: Final = "ANNUAL"

API_ERR_CODE_UNKNOWN: Final = "UNKNOWN"
API_ERR_CODE_UNAUTH: Final = "UNAUTHENTICATED"
HTTP_CODES_RETRIABLE: Final = [
    HTTPStatus.TOO_MANY_REQUESTS,
    HTTPStatus.PRECONDITION_REQUIRED,
]
HTTP_CODES_FATAL: Final = [HTTPStatus.BAD_REQUEST]
