# Copyright 2025 Semantiva authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Data boundary abstractions for pipeline I/O.

Source and sink processor types for interfacing external data systems
with payload-based pipeline nodes.
"""

from .data_io import DataSource, DataSink, PayloadSource, PayloadSink

__all__ = [
    "DataSource",
    "PayloadSource",
    "DataSink",
    "PayloadSink",
]
