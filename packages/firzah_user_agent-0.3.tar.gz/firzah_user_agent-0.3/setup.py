from setuptools import setup, find_packages

setup(
    name='firzah_user_agent',
    version='0.3',
    packages=find_packages(),
    install_requires=[
        # Add dependencies here.
        # e.g. 'numpy>=1.11.1'
    ],
)
