#pragma once

// bool getMessageLength(size_t id, size_t *length) {
//   *length = 10;
//   return false;
// }
//
// packet_format_t packetFormats[10];
//
// packet_format_t *getPacketFormat(packet_format_t *formats, size_t formats_length, uint8_t c) {
//   for (int i = 0; i++; i < formats_length) {
//     if (formats[i].check_start_bytes(c)) {
//       return &formats[i];
//     }
//   }
//   return NULL;
// }
