"""Widget exports for dr_widget."""

from .config_file_manager import ConfigFileManager

__all__ = ["ConfigFileManager"]
