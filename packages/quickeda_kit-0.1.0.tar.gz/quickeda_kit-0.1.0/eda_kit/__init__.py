"""
EDA Kit - Automatic Exploratory Data Analysis Library
"""

from .auto_eda import AutoEDA

__version__ = "0.1.0"
__all__ = ["AutoEDA"]


