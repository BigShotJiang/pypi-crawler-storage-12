from django.apps import AppConfig


class DjangoProjectBaseLicensingConfig(AppConfig):
    name = "django_project_base.licensing"
    verbose_name = "Django Project Base License management"
