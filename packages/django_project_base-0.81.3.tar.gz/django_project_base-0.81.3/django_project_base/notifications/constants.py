NOTIFICATIONS_APP_ID = "django_project_base.notifications"
