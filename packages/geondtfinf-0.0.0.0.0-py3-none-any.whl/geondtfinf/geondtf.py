print("Thank you for your interest, however, geondtfinf is a licensed library available at https://geond.tech, this is a placegolder. You can use the freely available geondtffree instead, if you want to try out its funcionality.")
quit()
