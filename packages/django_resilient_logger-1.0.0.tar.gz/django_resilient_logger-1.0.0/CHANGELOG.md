<!-- DOCTOC SKIP -->
# Changelog

## [1.0.0](https://github.com/City-of-Helsinki/django-resilient-logger/compare/v0.3.7...v1.0.0) (2025-11-12)


### Features

* Add source_pk as audit event extra ([425c621](https://github.com/City-of-Helsinki/django-resilient-logger/commit/425c621b9aae00155e85ec23ecdeb988884a904d))


### Dependencies

* Update python and django version support ([f7fe1af](https://github.com/City-of-Helsinki/django-resilient-logger/commit/f7fe1afe65e16020a83d401cb6eeb2a8e04033fc))


### Documentation

* Update README to include AUDIT_LOG_ENV ([7ae721a](https://github.com/City-of-Helsinki/django-resilient-logger/commit/7ae721a26e44378490213fd4f161857c9278ebcf))
