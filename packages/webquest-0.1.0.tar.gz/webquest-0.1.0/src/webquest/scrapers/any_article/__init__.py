from webquest.scrapers.any_article.schemas import AnyArticleRequest, AnyArticleResponse
from webquest.scrapers.any_article.scraper import AnyArticle

__all__ = ["AnyArticleRequest", "AnyArticleResponse", "AnyArticle"]
