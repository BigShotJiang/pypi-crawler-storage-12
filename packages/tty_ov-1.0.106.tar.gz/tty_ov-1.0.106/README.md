# tty_ov

![PyPI - Python Version](https://img.shields.io/pypi/pyversions/tty_ov)
![PyPI - Implementation](https://img.shields.io/pypi/implementation/tty_ov)
![PyPI - Wheel](https://img.shields.io/pypi/wheel/tty_ov)
![PyPI - Version](https://img.shields.io/pypi/v/tty_ov?label=pypi%20package:%20tty_ov)
![PyPI - Downloads](https://img.shields.io/pypi/dm/tty_ov)
![PyPI - License](https://img.shields.io/pypi/l/tty_ov)
![Execution status](https://github.com/Hanra-s-work/tty_ov/actions/workflows/python-package.yml/badge.svg)
![GitHub Workflow Status (with event)](https://img.shields.io/github/actions/workflow/status/Hanra-s-work/tty_ov/python-package.yml)
![GitHub repo size](https://img.shields.io/github/repo-size/Hanra-s-work/tty_ov)
![GitHub Repo stars](https://img.shields.io/github/stars/Hanra-s-work/tty_ov)
![GitHub commit activity (branch)](https://img.shields.io/github/commit-activity/m/Hanra-s-work/tty_ov)
![GitHub last commit (branch)](https://img.shields.io/github/last-commit/Hanra-s-work/tty_ov/main)

[![Static Badge](https://img.shields.io/badge/Buy_me_a_tea-Hanra-%235F7FFF?style=flat-square&logo=buymeacoffee&label=Buy%20me%20a%20coffee&labelColor=%235F7FFF&color=%23FFDD00&link=https%3A%2F%2Fwww.buymeacoffee.com%2Fhanra)](https://www.buymeacoffee.com/hanra)

 A tiny terminal (just the functions I need) cross-platform implemented in python.
This terminal currently supports piping and argument input as well as being used like a normal terminal.

## Description

This is an inner lib intended for a project, more details and a better structured readme will be implemented later on.
