class BarkNotificatorException(Exception):
    pass
