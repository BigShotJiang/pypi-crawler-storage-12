# Brewse

An interactive TUI (Terminal User Interface) browser for Homebrew packages. Brewse provides a fast, user-friendly way to search, view, and install or uninstall Homebrew packages.

## Installation

### Using Homebrew (recommended)

```bash
brew install jonasjancarik/brewse/brewse
```

## Usage

Launch Brewse in one of two ways:

1. Interactive search mode:
```bash
brewse
```

2. Direct search mode:
```bash
brewse <search-term>
```

### Command-line Options

```bash
brewse --help            # Show all available options
brewse --version         # Show version number
brewse --refresh         # Force refresh of cached package data
brewse --clear-cache     # Clear all cached data and exit
```

## Cache

Brewse caches package data in `~/.cache/brewse/` to improve performance. Cache entries expire after 24 hours.

## Alternative Installation Methods

### Using pip

```bash
pip install brewse
```

### Using pipx or uvx

Run in an isolated environment with pipx:

```bash
pipx install brewse
```

Or run instantly without installation using uvx:

```bash
uvx brewse
```

**Note:** uvx requires [uv](https://docs.astral.sh/uv/) to be installed first:

```bash
brew install uv
```

## Development & Releases

### Release Process

Brewse uses automated releases with GitHub Actions:

1. **Update version** in `pyproject.toml` and `src/brewse/__init__.py`
2. **Build and publish to PyPI:**
   ```bash
   uv build
   uv publish
   ```
3. **Create a GitHub release:**
   ```bash
   gh release create v0.1.3 --generate-notes
   ```

The GitHub Action will automatically:
- Download the tarball from PyPI
- Calculate the SHA256 hash
- Update the Homebrew tap formula
- Push changes to the `homebrew-brewse` repository

See [.github/AUTOMATION_SETUP.md](.github/AUTOMATION_SETUP.md) for setup details. (Useful if you want to fork this repo, obviously you will need to change the GitHub username.)

### Manual Tap Update

If needed, you can manually update the Homebrew tap:

```bash
cd ~/homebrew-brewse
./update-formula.sh 0.1.3
```

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
