"""Brewse - An interactive TUI browser for Homebrew packages."""

__version__ = "0.2.0"
