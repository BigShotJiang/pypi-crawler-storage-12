"""Common fixtures and utilities for CLI tests."""


# All fixtures for remote/config/commands have been removed
# as part of refactoring to OCI/ORAS architecture.
# Only parser tests remain, which do not require fixtures.
