# aa_prepflow/cli.py
from .AAPrepflow import AAPrepflowPanel, AAPrepflowTimeSeries, AAPrepflowCrossSection, AAPrepflowBase

def lab():
    aa_preflow = AAPrepflowBase()
    aa_preflow.flow_lab()
# Definisikan atau impor fungsi/objek 'lab' yang akan dieksekusi di sini
# Misalnya, jika 'lab' adalah fungsi, pastikan fungsi tersebut ada di sini atau diimpor di atas.
# (Berdasarkan setup.py, 'lab' diimpor dari AAPrepflow.py)
# Jika 'lab' sudah diimpor, file ini sudah cukup.
# Jika 'lab' adalah class atau fungsi yang memanggil main app, biarkan saja.