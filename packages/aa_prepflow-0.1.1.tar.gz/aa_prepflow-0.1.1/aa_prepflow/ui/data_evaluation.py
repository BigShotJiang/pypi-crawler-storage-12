# Notebook Title: AA Prepflow - Data Evaluation UI
# Author: Advanced Analytics Team
# Date: 2025-11-13
# Purpose: Komponen UI untuk evaluasi dan visualisasi data (distribusi & signifikansi)

from __future__ import annotations

import gradio as gr


def call_data_evaluation():
    """Bangun tab UI evaluasi data dan kembalikan komponen-komponen kuncinya."""
    with gr.TabItem("📊 Evaluasi & Visualisasi"):
        gr.Markdown("Pilih kolom numerik untuk melihat perbandingan distribusinya.")
        eval_col_dd = gr.Dropdown(label="Pilih Kolom untuk Evaluasi")
        eval_cat_dd = gr.Dropdown(
            label="Pilih Kategori untuk Evaluasi",
            visible=False,
        )

        with gr.Tabs(elem_classes="level-3-tabs"):
            with gr.TabItem("Chart Distribusi"):
                plot_output = gr.Plot()
            with gr.TabItem("Plot Strategy") as plot_tab:
                strategy_plot_output = gr.Plot()

        with gr.Tabs(elem_classes="level-3-tabs"):
            with gr.TabItem("Descriptive Statistik"):
                with gr.Row():
                    summary_stats_before = gr.DataFrame(
                        label="Summary Data",
                        scale=1,
                        pinned_columns=1,
                    )
            with gr.TabItem("Uji Statistik") as uji_statistik_tab:
                stats_output = gr.DataFrame(label="Perbandingan Statistik")
                interpretation_output = gr.Markdown()
            with gr.TabItem("Signifikansi Test"):
                df_signifikansi_test = gr.DataFrame(
                    label="Nilai Signifikan berdasarkan P Value",
                    pinned_columns=1,
                )

    return (
        eval_col_dd,
        eval_cat_dd,
        plot_output,
        stats_output,
        interpretation_output,
        strategy_plot_output,
        summary_stats_before,
        df_signifikansi_test,
        plot_tab,
        uji_statistik_tab,
    )


# ===================================================================
# Ringkasan Hasil / Summary Update (data_evaluation UI)
# ===================================================================
# - Menambahkan metadata notebook-style di bagian atas modul UI.
# - Menstandarkan penamaan fungsi (snake_case) dan menambah docstring singkat.
# - Struktur return tetap sama agar kompatibel dengan pemanggilan existing.