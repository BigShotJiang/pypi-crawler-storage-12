from setuptools import setup, find_packages

with open("README.md", "r") as f:
    description = f.read()

setup(
    name='aa_prepflow',
    version='0.1.1',
    packages=find_packages(),
    install_requires=[
        # Core Data Handling
        'pandas',
        'numpy',
        'scipy',
        
        # Machine Learning & Stats Modeling
        'scikit-learn',
        'statsmodels',
        
        # UI & Visualization
        'gradio',
        'ydata-profiling',
        'plotly',
        'matplotlib',
        'seaborn',
    ],
    entry_points={
        "console_scripts":[
            # Arahkan ke aa_prepflow/cli.py
            "aa_prepflow_lab = aa_prepflow.cli:lab" 
        ],
    },
    long_description=description,
    long_description_content_type="text/markdown"
)