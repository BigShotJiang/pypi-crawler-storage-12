"""Models.

This module provides:

- `Model`: Converting Python classes into Ramifice Models.
- `model`: Decorator for converting Python classes into Ramifice models.
"""
