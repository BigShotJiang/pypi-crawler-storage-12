# Pygeist Client

[![Tests](https://github.com/mateogall0/pygeist_client/actions/workflows/tests.yml/badge.svg)](https://github.com/mateogall0/pygeist_client/actions/workflows/tests.yml)

Zeitgeist client abstraction for Python
