# CLI module initialization
from .main import main

__all__ = ['main']
