def greetings():
    print("hello world")
    return "greetings complete"