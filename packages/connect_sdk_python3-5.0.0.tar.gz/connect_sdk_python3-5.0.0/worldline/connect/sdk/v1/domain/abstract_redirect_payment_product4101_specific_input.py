# -*- coding: utf-8 -*-
#
# This class was auto-generated from the API references found at
# https://apireference.connect.worldline-solutions.com/
#
from worldline.connect.sdk.domain.data_object import DataObject


class AbstractRedirectPaymentProduct4101SpecificInput(DataObject):

    def to_dictionary(self) -> dict:
        dictionary = super(AbstractRedirectPaymentProduct4101SpecificInput, self).to_dictionary()
        return dictionary

    def from_dictionary(self, dictionary: dict) -> 'AbstractRedirectPaymentProduct4101SpecificInput':
        super(AbstractRedirectPaymentProduct4101SpecificInput, self).from_dictionary(dictionary)
        return self
