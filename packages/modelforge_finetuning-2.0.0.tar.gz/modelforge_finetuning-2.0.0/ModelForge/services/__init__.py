"""
Service layer for ModelForge.
Provides business logic separated from HTTP routing.
"""
