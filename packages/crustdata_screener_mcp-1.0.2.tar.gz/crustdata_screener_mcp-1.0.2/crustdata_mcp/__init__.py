"""CrustData MCP Server Package"""
__version__ = "1.0.2"