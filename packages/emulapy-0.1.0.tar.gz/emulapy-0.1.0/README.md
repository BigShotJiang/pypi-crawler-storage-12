# emulapy

Minimal framework to create retro emulators in pure Python.

## Installation

```bash
pip install emulapy

# exemple
from emulapy import CPU, Memory, PPU, APU

mem = Memory()
cpu = CPU(mem)
ppu = PPU()
apu = APU()
cpu.reset()
opcode = cpu.step()


---

### **12. `LICENSE`**
```text
MIT License

Copyright (c) 2025 Lethudu70

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software...