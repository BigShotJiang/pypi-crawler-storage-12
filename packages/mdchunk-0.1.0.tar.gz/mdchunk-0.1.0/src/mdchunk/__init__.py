def hello() -> str:
    return "Hello from mdchunk!"
