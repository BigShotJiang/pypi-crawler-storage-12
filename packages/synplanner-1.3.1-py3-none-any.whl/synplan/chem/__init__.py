from CGRtools.files import SMILESRead

smiles_parser = SMILESRead.create_parser(ignore=True)
