class Test:
    abstract = True


test = Test()
