value = 0
value += 1
