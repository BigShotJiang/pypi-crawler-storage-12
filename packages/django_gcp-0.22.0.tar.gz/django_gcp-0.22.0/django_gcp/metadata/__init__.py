from .metadata import ENDPOINTS, CloudRunMetadata

__all__ = ["ENDPOINTS", "CloudRunMetadata"]
