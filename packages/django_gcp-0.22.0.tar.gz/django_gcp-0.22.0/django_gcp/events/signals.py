from django.dispatch import Signal

event_received = Signal()
