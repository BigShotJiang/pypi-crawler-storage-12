This module extends the Stock Valuation functionality to support grouping 
by Reference, filtering by Inventory Adjustments moves and filtering by 
Date and allow you to obtain a more detailed Inventory Valuation.