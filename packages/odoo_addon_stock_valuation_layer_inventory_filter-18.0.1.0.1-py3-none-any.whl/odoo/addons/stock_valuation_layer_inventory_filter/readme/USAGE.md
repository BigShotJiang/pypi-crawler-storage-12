To use this module, you need to:

1. Go to Inventory > Operations > Adjustments > Physical Inventory
2. Adjust multiple lines, select them and click "Apply"
3. Fill in the description of the Inventory Adjustment you are making
4. Go to Inventory > Reporting > Valuation
5. Filter by Inventory and group by Reference
