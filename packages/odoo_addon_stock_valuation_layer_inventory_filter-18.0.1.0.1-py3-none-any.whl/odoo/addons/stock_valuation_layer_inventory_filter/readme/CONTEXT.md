This module has been developed because when making inventory adjustments with
description, they cannot be filtered in the Inventory Valuation.

This will be useful if you want to check the difference in Total Value for each inventory adjustment.
