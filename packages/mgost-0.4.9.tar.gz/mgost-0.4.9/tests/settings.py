from unittest import TestCase


class SimpleTestCase(TestCase):
    def test_running(self):
        pass
