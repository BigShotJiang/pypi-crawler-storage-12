from .settings import MGostInfo, Settings
