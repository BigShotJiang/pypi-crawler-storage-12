"""A subpackage containing any translations from deprecated code to new code for deprecations that haven't been phased
out yet. See https://github.com/octue/octue-sdk-python/issues/415.
"""
