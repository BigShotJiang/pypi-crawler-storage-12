import os

TWINED_SERVICES_TOPIC_NAME = os.environ.get("TWINED_SERVICES_TOPIC_NAME", "main.octue.twined.services")
