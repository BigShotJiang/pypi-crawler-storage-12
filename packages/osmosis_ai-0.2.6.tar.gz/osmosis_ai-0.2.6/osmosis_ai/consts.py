# package metadata
package_name = "osmosis-ai"
PACKAGE_VERSION = "0.2.6"
