# ❄🔥 Frostfire

**Frostfire** is a compact library of Python functions.

☠️ Disclaimer

The code is indifferent.
