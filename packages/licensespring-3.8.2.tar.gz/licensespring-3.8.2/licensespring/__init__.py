version = "3.8.2"
app_version = None
