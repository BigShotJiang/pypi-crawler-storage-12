# sprintsolo-sally-db-client

Internal Prisma Python client published by the central backend repo.

Usage:

```bash
pip install sprintsolo-sally-db-client --index-url <your-private-pypi>
```
