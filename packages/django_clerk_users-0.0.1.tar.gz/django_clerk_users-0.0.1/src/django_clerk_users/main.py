def hello_world():
    return "Hello from django-clerk-users!"
