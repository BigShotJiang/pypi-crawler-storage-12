"""
Utility functions for text processing.

This module provides utilities for tokenization and text manipulation.
"""

from dalla.utils.tokenize import simple_word_tokenize

__all__ = ["simple_word_tokenize"]
