"""
Author: Sally Choker
Summary:
- The script is designed for deduplication analysis in text datasets. It processes CSV files to identify and count duplicate entries, calculates scores for duplication, and handles the removal of duplicates based on quality scores and predefined criteria.
- Steps include:
  - Counting occurrences of duplicates across CSV files in a given directory.
  - Calculating scores for duplicates to identify the most prevalent ones.
  - Isolating duplicates per dataset and appending quality scores for further analysis.
  - Removing duplicates from datasets based on quality and duplication scores, consolidating the cleaned datasets in a specified location.
- The script is structured in a modular fashion with separate functions for each step of the process, culminating in the removal of identified duplicates.

"""

import argparse
import csv
import json
import os
import shutil
from collections import Counter


def step_1_calculate_counts(input_directory, output_dir):
    all_rows = []

    # Step 1: Find all CSV files in the specified directory
    for filename in os.listdir(input_directory):
        if filename.endswith(".csv") and "Duplicate_pair" in filename:
            filepath = os.path.join(input_directory, filename)
            # Step 2: For each CSV file, read its content
            with open(filepath, newline="", encoding="utf-8") as csvfile:
                csvreader = csv.reader(csvfile)
                for row in csvreader:
                    all_rows.append(row)

    # Step 3: Group all the read rows, sort them, and count the occurrences
    # Assuming the file path is in the first column
    all_rows.sort(key=lambda x: x[0])  # Sort by the first column
    pair_counts = Counter((row[0], row[1]) for row in all_rows)

    # Step 4: Write the unique pairs with their counts to a new CSV file
    output_csv_path = os.path.join(output_dir, "Duplicates_with_counts.csv")
    with open(output_csv_path, "w", newline="", encoding="utf-8") as csvfile:
        csvwriter = csv.writer(csvfile)
        # Write the header for the new CSV
        csvwriter.writerow(["File Path", "Duplicate file path index", "Count"])

        # Write the rows with the count of occurrences for each unique pair
        for pair, count in pair_counts.items():
            file_path, number = pair
            csvwriter.writerow([file_path, number, count])

    return output_csv_path


def step_2_calculate_scores(input_Duplicates_with_counts_csv_path, output_directory):
    # Store the sum of counts for each unique filename
    total_counts = {}

    # First pass: calculate the total counts per filename
    input_csv_file = input_Duplicates_with_counts_csv_path
    with open(input_csv_file, newline="") as file:
        reader = csv.reader(file)
        next(reader, None)  # Skip the header
        for row in reader:
            filename = row[0]
            try:
                count = int(row[2])
            except ValueError as e:
                print(f"Error in file {input_csv_file}: {e}")
            if filename in total_counts:
                total_counts[filename] += count
            else:
                total_counts[filename] = count

    # Second pass: read again to write new files with scores
    output_file_name = os.path.join(output_directory, "Duplicates_with_counts_and_scores.csv")
    with (
        open(input_csv_file, newline="") as file,
        open(output_file_name, mode="w", newline="") as outfile,
    ):
        reader = csv.reader(file)
        writer = csv.writer(outfile)

        # Write the header with the new 'score' column
        next(reader)
        writer.writerow(["File name", "Duplicate file name", "Count", "Score"])

        # Write the data with the calculated score
        for row in reader:
            filename = row[0]
            count = int(row[2])
            # Calculate the score
            score = round((count / total_counts[filename]) * 100, 2)
            # Append the score to the row and write it to the new file
            writer.writerow(row + [score])

    return output_file_name


def extract_data_from_path(path):
    """directories are formatted as /media/root/d1/SallyData/Train/dataset_name/Vert/filename.txt"""
    parts = path.split("/")
    dataset_name = parts[-3]
    filename = parts[-1]
    return dataset_name, filename


def step_3_get_dedup_per_dataset(dedup_file_path, duplicates_with_counts_scores_path, output_dir):
    txt_file_path = dedup_file_path
    csv_output_directory = output_dir
    input_csv_path = duplicates_with_counts_scores_path

    with open(txt_file_path) as f:
        txt_content = f.readlines()

    writer = None
    output_file = None
    current_output_dataset = None

    with open(input_csv_path) as file:
        reader = csv.reader(file)
        next(reader)
        for row in reader:
            original_path, index, count, score = row  # Updated here to include the count
            dataset_name, filename = extract_data_from_path(original_path)
            duplicate_dataset_name, duplicate_filename = extract_data_from_path(
                txt_content[int(index) - 1].strip()
            )

            # Check if current dataset name matches the output file's dataset name
            if dataset_name != current_output_dataset:
                # Close existing output file if it exists
                if output_file:
                    output_file.close()

                # Determine the mode for opening the output file
                output_filename = os.path.join(csv_output_directory, f"{dataset_name}_dup.csv")
                file_mode = "a" if os.path.exists(output_filename) else "w"
                output_file = open(output_filename, file_mode, newline="")
                writer = csv.writer(output_file)

                if file_mode == "w":
                    writer.writerow(
                        [
                            "dataset name",
                            "filename",
                            "duplicate dataset name",
                            "duplicate filename",
                            "count",
                            "score",
                        ]
                    )

                current_output_dataset = dataset_name

            writer.writerow(
                [dataset_name, filename, duplicate_dataset_name, duplicate_filename, count, score]
            )  # Include count here

        # Close the output file after processing current csv_file
        if output_file:
            output_file.close()
            writer = None
            current_output_dataset = None


def step_4_process_dedup(output_dir):
    """Takes dedups/per datasets, appends in a new csv file only ones with score more than 90."""

    duplicates_score_80_path = os.path.join(output_dir, "duplicates_score_80.csv")

    # Check if the output file already exists, if so, remove it to start fresh
    if os.path.exists(duplicates_score_80_path):
        os.remove(duplicates_score_80_path)

    for filename in os.listdir(output_dir):
        if filename.endswith("_dup.csv"):
            with open(os.path.join(output_dir, filename), encoding="utf-8") as infile:
                reader = csv.reader(infile)
                header = next(reader)

                with open(duplicates_score_80_path, "a", newline="", encoding="utf-8") as outfile:
                    writer = csv.writer(outfile)

                    # Write the header if the file is empty
                    if outfile.tell() == 0:
                        writer.writerow(header)

                    for row in reader:
                        try:
                            score = float(row[-1])  # Assuming score is in the last column
                        except ValueError:
                            continue  # Skip rows where score is not a number

                        if score >= 80:
                            writer.writerow(row)

    return duplicates_score_80_path


def step_5_add_quality_score(duplicates_score_80, output_dir):
    """add the quality score for each file and its duplicate"""
    """ Important make sure the first part of  _quality files are names as same as the _dup files  """

    # Part 1: Process _quality files
    quality_scores = {}  # Dictionary to hold the quality scores from _quality files

    for file in os.listdir(output_dir):
        if file.endswith("_quality.csv"):
            dataset_name = file.split("_quality.csv")[0]
            quality_scores[dataset_name] = {}
            with open(os.path.join(output_dir, file)) as f:
                reader = csv.reader(f)
                next(reader)  # Skip the header
                for row in reader:
                    filename, quality_score = row[:2]
                    quality_scores[dataset_name][filename] = quality_score

    # Part 2: Process duplicates_score_80 file and create new file with QS and QS_d
    duplicates_score_80_quality_path = os.path.join(output_dir, "duplicates_score_80_quality.csv")

    with (
        open(duplicates_score_80) as infile,
        open(duplicates_score_80_quality_path, "w", newline="") as outfile,
    ):
        reader = csv.reader(infile)
        writer = csv.writer(outfile)

        header = next(reader)
        writer.writerow(header + ["QS", "QS_d"])  # Append new columns to the header

        for row in reader:
            dataset_name, filename, dup_dataset_name, dup_filename, *rest = row
            QS = quality_scores.get(dataset_name, {}).get(filename, -1)
            QS_d = quality_scores.get(dup_dataset_name, {}).get(dup_filename, -1)
            writer.writerow(row + [QS, QS_d])

    return duplicates_score_80_quality_path


def step_6_generate_files_remove(duplicates_score_80_quality_path, output_dir):
    """Generates a csv file of files that need to be removed from each dataset"""
    output_csv_path = os.path.join(output_dir, "duplicate_filename_to_remove.csv")

    with (
        open(duplicates_score_80_quality_path) as infile,
        open(output_csv_path, "w", newline="") as outfile,
    ):
        reader = csv.reader(infile)
        writer = csv.writer(outfile)

        # Write the header for the new file
        writer.writerow(["Dataset Name", "Filename", "Quality Score"])

        # Skip the header in the input file
        next(reader)

        for row in reader:
            dataset_name, filename, dup_dataset_name, dup_filename, _, _, QS, QS_d = row
            QS, QS_d = float(QS), float(QS_d)

            if dataset_name == dup_dataset_name and filename == dup_filename:
                continue
            if dataset_name != dup_dataset_name and "DDH_Corpus_2023_vert" in [
                dataset_name,
                dup_dataset_name,
            ]:
                # If one of the dataset names is 'DDH' and the names are different, remove the non-DDH file
                if dataset_name == "DDH":
                    writer.writerow([dup_dataset_name, dup_filename, QS_d])
                else:
                    writer.writerow([dataset_name, filename, QS])
                continue  # Skip to the next row

            if QS_d > QS:
                # Remove 'filename' if QS is smaller
                writer.writerow([dataset_name, filename, QS])
            elif QS_d < QS:
                # Remove 'dup_filename' if QS_d is smaller
                writer.writerow([dup_dataset_name, dup_filename, QS_d])
            elif QS_d == QS:
                writer.writerow([dataset_name, filename, QS])

        return output_csv_path


def step_7_remove_duplicates(dup_filename_to_remove_path, dir_remove_dup, dataset_paths):
    with open(dup_filename_to_remove_path, newline="", encoding="utf-8") as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # Skip the header

        for row in reader:
            dataset_name, filename, _ = row

            if dataset_name != "DDH_Corpus_2023_vert":
                # Construct the source file path
                source_file_path = os.path.join(dataset_paths[dataset_name], filename)
                if not os.path.exists(source_file_path):
                    continue

                # Construct the destination file path
                dest_file_path = os.path.join(dir_remove_dup, filename)

                # Move the file
                if os.path.exists(dest_file_path):
                    os.remove(dest_file_path)
                shutil.move(source_file_path, dir_remove_dup)


def main(args):
    dedup_dir = args.dedup_dir
    output_dir = args.output_dir
    unique_dedup_path_txt = args.unique_dedup_path_txt
    destination_dir_remove_dup = args.destination_dir_remove_dup

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Paths for different datasets
    with open(args.dataset_paths_json) as f:
        dataset_paths = json.load(f)

    # Start processing

    Duplicates_with_counts_path = step_1_calculate_counts(
        dedup_dir, output_dir
    )  # return duplicates with counts.csv (input to step2)
    Duplicates_with_counts_and_scores_path = step_2_calculate_scores(
        Duplicates_with_counts_path, output_dir
    )  # return duplicates with counts and scores.csv (input to step3)
    step_3_get_dedup_per_dataset(
        unique_dedup_path_txt, Duplicates_with_counts_and_scores_path, output_dir
    )  # return the duplicates per/dataset
    Duplicates_score_80_path = step_4_process_dedup(
        output_dir
    )  # this takes the duplicates per dataset with score>80
    Duplicates_score_80_quality_path = step_5_add_quality_score(
        Duplicates_score_80_path, output_dir
    )  # appends the quality score for each file
    Dup_files_to_remove_path = step_6_generate_files_remove(
        Duplicates_score_80_quality_path, output_dir
    )
    step_7_remove_duplicates(Dup_files_to_remove_path, destination_dir_remove_dup, dataset_paths)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Deduplication analysis in text datasets.")
    parser.add_argument(
        "--dedup_dir", help="Directory containing deduplication files", required=True
    )
    parser.add_argument("--output_dir", help="Output directory for analysis results", required=True)
    parser.add_argument(
        "--unique_dedup_path_txt",
        help="Path to the text file with unique deduplication identifiers",
        required=True,
    )
    parser.add_argument(
        "--destination_dir_remove_dup", help="Directory to move duplicates to", required=True
    )
    parser.add_argument(
        "--dataset_paths_json", help="Path to the JSON file with dataset paths", required=True
    )

    args = parser.parse_args()
    main(args)
