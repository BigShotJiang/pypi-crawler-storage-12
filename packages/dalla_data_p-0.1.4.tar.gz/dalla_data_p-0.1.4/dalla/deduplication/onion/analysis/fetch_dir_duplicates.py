"""
Author: Sally Choker
Summary: This script processes CSV files to collect a set of unique file paths and line numbers,
combines them with unique paths from a specified TXT file, and writes all unique paths to an
output text file.
It's designed to find and document duplicates by collating and deduplicating file paths from both CSV
and TXT sources.
The script reads paths and line numbers from CSVs, fetches corresponding paths from a TXT file,
and consolidates them into a single set, outputting the result to a new file.

"""

import argparse
import csv
import os


# Function to read unique paths from the TXT file given a list of line numbers
def get_paths_from_txt(file_path, line_numbers):
    unique_paths = set()
    with open(file_path) as f:
        for i, line in enumerate(f, 1):
            if i in line_numbers:
                unique_paths.add(line.strip())  # Remove the newline character
    return unique_paths


# Function to process the CSV files and create a set of unique paths
def process_csv_files(csv_directory, txt_file_path):
    unique_csv_paths = set()
    line_numbers = set()

    # Iterate over every CSV file in the directory
    for filename in os.listdir(csv_directory):
        if filename.endswith(".csv"):
            full_path = os.path.join(csv_directory, filename)
            with open(full_path) as csv_file:
                csv_reader = csv.reader(csv_file)
                for row in csv_reader:
                    csv_path = row[0].strip('"')
                    line_number = int(row[1])
                    # Add the path from the CSV and the line number to their respective sets
                    unique_csv_paths.add(csv_path)
                    line_numbers.add(line_number)

    # Get unique paths from the TXT file based on the collected line numbers
    unique_txt_paths = get_paths_from_txt(txt_file_path, line_numbers)

    # Combine both sets of unique paths
    all_unique_paths = unique_csv_paths.union(unique_txt_paths)

    return all_unique_paths


# Function to write the set of unique paths to a text file
def write_paths_to_txt(paths_set, output_file_path):
    with open(output_file_path, "a") as f:
        for path in paths_set:
            f.write(f"{path}\n")


def main():
    parser = argparse.ArgumentParser(
        description="Process CSV files to collect and deduplicate file paths."
    )
    parser.add_argument("-c", "--csv-dir", required=True, help="Directory containing CSV files")
    parser.add_argument("-t", "--txt-file", required=True, help="Path to the TXT file")
    parser.add_argument("-o", "--output-file", required=True, help="Path to output the result")

    args = parser.parse_args()

    # Process the CSV files and get all unique paths
    all_unique_paths = process_csv_files(args.csv_dir, args.txt_file)

    # Write the set of all unique paths to a text file
    write_paths_to_txt(all_unique_paths, args.output_file)

    print("All unique paths have been saved to the output file.")


if __name__ == "__main__":
    main()
