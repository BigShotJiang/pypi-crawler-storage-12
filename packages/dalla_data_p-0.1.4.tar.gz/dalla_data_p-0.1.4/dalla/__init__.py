"""
Dalla Data Processing - Unified Arabic Data Processing Pipeline

A comprehensive toolkit for processing Arabic text data with support for:
- Deduplication
- Stemming and morphological analysis
- Quality checking
- Readability scoring
"""

__version__ = "0.1.0"
__author__ = "Hadi et al."

# Import core utilities (with graceful failure)
try:
    from dalla.core.dataset import DatasetManager

    _has_dataset = True
except ImportError:
    _has_dataset = False
    DatasetManager = None

# Import tokenizer utility
try:
    from dalla.utils.tokenize import simple_word_tokenize

    _has_tokenize = True
except ImportError:
    _has_tokenize = False
    simple_word_tokenize = None

__all__ = ["DatasetManager", "simple_word_tokenize", "__version__"]
