"""Tests for dataset utilities."""

from datasets import Dataset

from dalla.core.dataset import DatasetManager


def test_dataset_manager_creation():
    """Test that DatasetManager can be instantiated."""
    dm = DatasetManager()
    assert dm is not None


def test_get_size_single_dataset():
    """Test getting size of a single dataset."""
    data = [{"text": "hello"}, {"text": "world"}]
    dataset = Dataset.from_list(data)

    size = DatasetManager.get_size(dataset)
    assert size == 2


def test_get_column_names():
    """Test getting column names from dataset."""
    data = [{"text": "hello", "label": 1}]
    dataset = Dataset.from_list(data)

    columns = DatasetManager.get_column_names(dataset)
    assert "text" in columns
    assert "label" in columns


def test_add_column():
    """Test adding a column to dataset."""
    data = [{"text": "hello"}, {"text": "world"}]
    dataset = Dataset.from_list(data)

    new_data = [1, 2]
    result = DatasetManager.add_column(dataset, "id", new_data)

    assert "id" in result.column_names
    assert result[0]["id"] == 1
    assert result[1]["id"] == 2


def test_filter_dataset():
    """Test filtering a dataset."""
    data = [
        {"text": "hello", "score": 0.9},
        {"text": "world", "score": 0.3},
        {"text": "test", "score": 0.7},
    ]
    dataset = Dataset.from_list(data)

    def filter_fn(example):
        return example["score"] > 0.5

    filtered = DatasetManager.filter_dataset(dataset, filter_fn)
    assert len(filtered) == 2
