"""Tests for quality checking module."""

from datasets import Dataset

from dalla.quality import QualityChecker, check_quality


def test_quality_checker_initialization():
    """Test that QualityChecker can be initialized."""
    checker = QualityChecker(timeout=60)
    assert checker is not None
    assert checker.timeout == 60


def test_is_arabic():
    """Test Arabic word detection."""
    assert QualityChecker.is_arabic("مرحبا")
    assert QualityChecker.is_arabic("العربية")
    assert not QualityChecker.is_arabic("hello")
    assert not QualityChecker.is_arabic("123")


def test_check_quality_basic():
    """Test basic quality checking on a small dataset."""
    # Create a simple test dataset
    data = [
        {"text": "مرحبا بك في العالم"},
        {"text": "هذا نص عربي جيد"},
        {"text": ""},  # Empty text
    ]
    _dataset = Dataset.from_list(data)  # noqa: F841

    # Run quality check (this will actually process with CAMEL Tools)
    # Using timeout=60 for faster testing
    checker = QualityChecker(timeout=60)

    # Process first example
    result1 = checker.check_text_quality(data[0]["text"])
    assert "quality_score" in result1
    assert "arabic_error_percent" in result1
    assert "foreign_error_percent" in result1

    # Process empty text
    result_empty = checker.check_text_quality("")
    assert result_empty["error_code"] == -1


def test_check_quality_with_dataset():
    """Test quality checking with HF dataset (placeholder test)."""
    # This is a minimal test - full testing requires CAMEL Tools to be installed
    data = [
        {"text": "مرحبا"},
        {"text": "العربية"},
    ]
    _dataset = Dataset.from_list(data)  # noqa: F841

    # Note: This will only work if camel-tools is installed
    # For now, just verify the function signature is correct
    assert callable(check_quality)
