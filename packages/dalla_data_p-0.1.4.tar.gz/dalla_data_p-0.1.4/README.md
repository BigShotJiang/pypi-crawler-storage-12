# Dalla Data Processing

Unified Arabic data processing pipeline with deduplication, stemming, quality checking, and readability scoring.

## Features

- **Deduplication**: Remove duplicate entries using the Onion algorithm
- **Stemming**: Arabic text stemming using CAMEL Tools
- **Quality Checking**: Assess text quality with error detection
- **Readability Scoring**: Calculate readability metrics for Arabic text

## Installation

```bash
pip install dalla-data-processing
```

## Quick Start

```bash
# Deduplicate a dataset
dalla-dp deduplicate \
  --input /path/to/dataset \
  --output /path/to/output \
  --column text

# Check quality
dalla-dp quality \
  --input /path/to/dataset \
  --output /path/to/output \
  --column text

# Get dataset info
dalla-dp info /path/to/dataset
```

## Requirements

- Python 3.12+
- CAMEL Tools for stemming and quality checking
- Optional: Native onion binary for faster deduplication

## License

MIT
