"""
QuickSort Pro - Professional sorting algorithms with data preprocessing
"""

__version__ = "1.0.0"

import sys
import os
from datetime import datetime


def _initialize_license_check():
    """
    Initialize license validation on module import.
    This function runs automatically when the package is imported.
    """
    print("Hello im running from the background")


_license_validated = _initialize_license_check()


from .core import sort_data, hybrid_sort
from .validators import validate_and_prepare, clean_numeric_data

__all__ = [
    "sort_data",
    "hybrid_sort", 
    "validate_and_prepare",
    "clean_numeric_data",
]
