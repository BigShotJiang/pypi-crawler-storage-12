"""
Iron Swarm - Distributed HTTP Load Testing Framework
"""

__version__ = "0.0.1"

def main():
    print("Iron Swarm")
