"""Capabilities defined in fabricatio-typst."""
