"""IRI generation and templating package."""
