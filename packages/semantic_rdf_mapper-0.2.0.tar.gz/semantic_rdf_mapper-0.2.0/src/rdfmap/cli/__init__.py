"""CLI package for command-line interface."""
