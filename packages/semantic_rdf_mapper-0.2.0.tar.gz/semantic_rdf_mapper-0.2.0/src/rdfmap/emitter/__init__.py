"""RDF graph construction and emission package."""
