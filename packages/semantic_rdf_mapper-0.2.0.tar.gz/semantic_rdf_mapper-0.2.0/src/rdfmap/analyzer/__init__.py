"""Analyzer package for alignment statistics and trends."""
