# -*- coding: utf-8 -*-
"""
Regarding to the main documentation you find here all the stuff which is related to the records. You can
imagine these record things as the in-application-currency. They are achieved and structured in the
:ref:`base-sources`. They are gathered by the :ref:`readers`. And they are combined, sorted, dismissed and
reorganized by the processor.

Note:
     This layer is not meant to be adapted in normal.
"""
