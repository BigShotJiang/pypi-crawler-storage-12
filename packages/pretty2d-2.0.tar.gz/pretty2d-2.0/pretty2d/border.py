from enum import Enum
class Border(Enum):
    DEFAULT = 1
    TABULAR = 2
    TABULAR_ROUNDED = 3
    TABULAR_DOUBLE = 4
    NO_BORDER = 5