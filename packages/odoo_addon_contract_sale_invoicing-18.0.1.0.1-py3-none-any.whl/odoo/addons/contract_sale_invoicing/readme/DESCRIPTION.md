This modules allows to include on the same invoice than the recurring
invoice contract, all the pending to invoice sales orders that you have
with the same analytic account.
