# DigitalOcean Gradient AI Platform Agent Development Kit

The Gradient Agent Development Kit (ADK) is a SDK to build, test, deploy, and monitor AI agent workflows.

## License

Licensed under the Apache License 2.0. See [LICENSE](./LICENSE)