import nonebot
from nonebot import logger


def check_state() -> bool:
    """检查机器人的状态配置"""
    config = nonebot.get_driver().config
    state = getattr(config, "state", False)
    # 检查state布尔值是否为True
    if state:
        logger.info("状态检查通过,等待实例连接")
        return True
    logger.error("状态检查失败，请勿直接启动nonebot2，需先配置.env文件")
    return False


# if check_state() is True:
#     from .index import index

# def index() -> None:
#     """机器人核心索引"""
