# lingchu-bot

## 如何开始

安装[python](https://www.python.org/downloads/)3.10以上版本

安装pipx

```bash
pip install pipx
```

添加pipx到环境变量

```bash
pipx ensurepath
```

安装nb-cli

```bash
pipx install nb-cli
```

添加pdm到环境变量

```bash
pipx install pdm
```

安装项目依赖

```bash
pdm install
```
启动项目

```bash
nb run --reload
```

## 文档

查看 [文档](https://nonebot.dev/)