from powl.main import import_event_log, discover, view, view_net, save_visualization, save_visualization_net, convert_to_petri_net, convert_to_bpmn, discover_from_partially_ordered_log, import_ocel, discover_petri_net_from_ocel, discover_from_dfg

__name__ = 'powl'
__version__ = '2.1.1'