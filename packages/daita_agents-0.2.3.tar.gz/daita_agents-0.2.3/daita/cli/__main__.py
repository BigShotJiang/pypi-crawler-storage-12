"""
Main entry point for python -m daita.cli
"""
from .main import main

if __name__ == '__main__':
    main()