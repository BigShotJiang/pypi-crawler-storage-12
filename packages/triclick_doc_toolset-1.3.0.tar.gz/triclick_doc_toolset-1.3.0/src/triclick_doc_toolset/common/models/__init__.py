"""Common data models for the triclick document toolset."""

from .table import TableItem

__all__ = ['TableItem']