def main() -> None:
    print("Hello from jusflaudio!")
