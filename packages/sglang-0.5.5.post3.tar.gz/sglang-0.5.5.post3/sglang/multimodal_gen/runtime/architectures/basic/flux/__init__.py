# Copied and adapted from: https://github.com/hao-ai-lab/FastVideo
