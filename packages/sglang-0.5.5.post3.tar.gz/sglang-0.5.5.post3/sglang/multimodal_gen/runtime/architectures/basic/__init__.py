# Copied and adapted from: https://github.com/hao-ai-lab/FastVideo

# SPDX-License-Identifier: Apache-2.0
"""
Basic inference pipelines for sglang.multimodal_gen.

This package contains basic pipelines for video and image generation.
"""
