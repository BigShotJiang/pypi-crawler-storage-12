# wire-memory

Wire for communicating over memory.
