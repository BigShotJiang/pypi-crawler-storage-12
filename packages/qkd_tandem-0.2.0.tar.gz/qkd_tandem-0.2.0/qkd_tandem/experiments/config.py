DEFAULTS = {
    "n_bits": 192,
    "attack_rate": 0.3,
    "qber_abort": 0.11,
    "ks_trigger": 0.15,
    "seed": 42
}

