
from .config import CONFIG 
__all__ = ["CONFIG"]