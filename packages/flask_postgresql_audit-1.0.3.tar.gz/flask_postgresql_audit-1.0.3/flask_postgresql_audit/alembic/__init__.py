# ruff: noqa: F401
from .setup import register_triggers, setup_db
