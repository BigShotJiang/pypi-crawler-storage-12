"""Cache backend implementations (in-memory and Redis)."""
