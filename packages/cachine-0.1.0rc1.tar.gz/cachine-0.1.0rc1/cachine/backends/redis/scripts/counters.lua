-- Placeholder Lua script for atomic counters with ttl_on_create.
-- Implement INCRBY + set EXPIRE on create.

