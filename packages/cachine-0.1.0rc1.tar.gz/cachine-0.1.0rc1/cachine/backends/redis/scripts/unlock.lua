-- Placeholder Lua script for safe unlock by token.
-- Check token value then DEL if matches.

