-- Placeholder Lua script for invalidate by tags.
-- Resolve tag->keys sets and DEL keys atomically.

