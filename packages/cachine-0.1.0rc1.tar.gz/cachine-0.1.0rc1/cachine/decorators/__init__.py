from .cached import cached

__all__ = ["cached"]
