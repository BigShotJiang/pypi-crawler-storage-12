"""Core abstractions and shared types for caches."""
