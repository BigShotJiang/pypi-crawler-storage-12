"""Documents module.

The DOCUMENTS module contains related code to handle document ingesting,
representating, loading, chunking and general manipulation of them.
"""
