"""
Prompt models and related utilities.

This package contains models for representing and working with prompts in the Agentle framework.
"""
