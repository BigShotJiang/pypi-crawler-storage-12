STEP_DECORATORS_DESC = [
    ("ob_highlighter", ".highlight.highlight_decorator.OBHighlighterStepDecorator")
]
