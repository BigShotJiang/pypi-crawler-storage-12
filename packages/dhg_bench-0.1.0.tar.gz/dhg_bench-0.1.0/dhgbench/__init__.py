from .main import main

__all__ = ["main"]
__version__ = "0.1.0"
