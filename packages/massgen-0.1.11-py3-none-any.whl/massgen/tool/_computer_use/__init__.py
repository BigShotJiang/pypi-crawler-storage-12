# -*- coding: utf-8 -*-
"""
Computer use tool module for OpenAI computer-use-preview integration.
"""

from .computer_use_tool import computer_use

__all__ = ["computer_use"]
