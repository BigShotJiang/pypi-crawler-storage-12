"""Tests for drop-jump analysis."""
