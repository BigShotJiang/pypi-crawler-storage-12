#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
File name: 
Author:         "SYSNET s.r.o."<rjaeger@sysnet.cz>
Created:    
Version:        1.0.0
Description:
"""
