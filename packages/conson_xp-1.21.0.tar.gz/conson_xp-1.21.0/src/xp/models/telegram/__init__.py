"""Telegram models for console bus communication."""
