"""
Test suite for Interpals Python Library.
"""

