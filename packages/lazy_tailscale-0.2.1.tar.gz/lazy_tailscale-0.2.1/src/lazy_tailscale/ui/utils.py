def clear_screen():
    print("\033[2J\033[H", end="")
