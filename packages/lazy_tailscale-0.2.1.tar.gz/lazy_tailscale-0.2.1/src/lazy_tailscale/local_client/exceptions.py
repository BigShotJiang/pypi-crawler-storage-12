class ConnectionFailedError(Exception):
    pass


class NotConnectedError(Exception):
    pass
