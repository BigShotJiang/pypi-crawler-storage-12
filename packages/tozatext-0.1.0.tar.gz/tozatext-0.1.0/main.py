def main():
    print("Hello from tozatext!")





if __name__ == "__main__":
    main()
