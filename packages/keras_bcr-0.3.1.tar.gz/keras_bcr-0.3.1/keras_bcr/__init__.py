__version__ = '0.3.1'

from .bcr import BatchCorrRegularizer
from .bcr import batch_corr
