"""Setup script for backwards compatibility.

Modern installations should use pyproject.toml, but this file
is provided for compatibility with older tools.
"""

from setuptools import setup

setup()
