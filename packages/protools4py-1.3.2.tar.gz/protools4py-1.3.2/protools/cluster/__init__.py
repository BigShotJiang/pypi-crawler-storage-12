"""
A package for clustering biological sequences using multiple tools.
"""