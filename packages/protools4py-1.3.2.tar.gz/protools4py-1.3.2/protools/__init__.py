"""
Protein tool collections
"""