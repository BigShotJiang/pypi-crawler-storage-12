# Copyright (C) Unitary Foundation
#
# This source code is licensed under the GPL license (v3) found in the
# LICENSE file in the root directory of this source tree.

"""Run experiments without error mitigation using the same interface as error
mitigation."""

from mitiq.raw.raw import execute
