# MARVEL Schedule Maker

A utility for creating observation schedules for the MARVEL telescope.

## Installation

```bash
pip install marvel-schedule-maker
```

## Usage

Run the schedule maker:

```bash
marvel-schedule-maker
```
