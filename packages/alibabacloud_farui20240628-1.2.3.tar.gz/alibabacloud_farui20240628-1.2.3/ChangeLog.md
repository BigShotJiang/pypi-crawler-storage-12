2025-07-04 Version: 1.2.2
- Update API RunLegalAdviceConsultation: add request parameters extra.
- Update API RunLegalAdviceConsultation: add response parameters Body.contents.
- Update API RunLegalAdviceConsultation: add response parameters Body.extra.


2025-05-06 Version: 1.2.1
- Update API RunSearchCaseFullText: add request parameters referLevel.
- Update API RunSearchCaseFullText: add response parameters Body.data.caseLevel.
- Update API RunSearchCaseFullText: add response parameters Body.data.caseResult.$.mode.
- Update API RunSearchCaseFullText: add response parameters Body.data.caseResult.$.caseDomain.basicCase.
- Update API RunSearchCaseFullText: add response parameters Body.data.caseResult.$.caseDomain.caseCause.
- Update API RunSearchCaseFullText: add response parameters Body.data.caseResult.$.caseDomain.judgReason.
- Update API RunSearchCaseFullText: add response parameters Body.data.caseResult.$.caseDomain.refereeGist.


2024-12-26 Version: 1.2.0
- Support API RunSearchCaseFullText.
- Support API RunSearchLawQuery.


2024-12-26 Version: 1.1.2
- Update API CreateTextFile: add param regionId.
- Update API RunContractResultGeneration: add param regionId.
- Update API RunContractRuleGeneration: add param regionId.
- Update API RunLegalAdviceConsultation: add param regionId.


2024-10-23 Version: 1.1.1
- Update API RunContractResultGeneration: update response param.


2024-07-10 Version: 1.1.0
- Support API RunContractResultGeneration.
- Support API RunContractRuleGeneration.


2024-07-10 Version: 1.0.0
- Generated python 2024-06-28 for FaRui.

