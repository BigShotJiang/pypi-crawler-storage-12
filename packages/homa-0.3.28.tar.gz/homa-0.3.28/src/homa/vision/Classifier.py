from .Model import Model


class Classifier(Model):
    pass
