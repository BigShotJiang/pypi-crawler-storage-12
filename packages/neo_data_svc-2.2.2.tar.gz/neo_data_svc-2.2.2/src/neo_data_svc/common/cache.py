import hashlib
import json
from functools import wraps

import redis.asyncio as redis

from .system import get_v

_r = None
_c = None


async def NDS_CACHE_INIT(config):
    global _r
    global _c

    _c = config
    _r = redis.from_url(get_v("CacheURL", "redis://"),
                        encoding="utf-8", decode_responses=True)


async def _get(key: str):
    if _r is None:
        return None

    try:
        data = await _r.get(key)
        return json.loads(data) if data else None
    except Exception:
        return None


async def _set(key: str, value):
    global _c

    if _r is None or _c is None:
        return

    try:
        await _r.set(key, json.dumps(value), ex=int(get_v("CacheExpire", 120)))
    except Exception:
        return


def NDS_CACHE(f):
    @wraps(f)
    async def wrapper(*args, **kwargs):
        try:
            key = f"{f.__name__}:{hashlib.md5(
                json.dumps([args, kwargs], sort_keys=True, default=str).encode())
                .hexdigest()}"
        except (TypeError, ValueError):
            return await f(*args, **kwargs)

        cached = await _get(key)
        if cached is not None:
            return {"data": cached, "cached": True}

        result = await f(*args, **kwargs)
        await _set(key, result)
        return result
    return wrapper
