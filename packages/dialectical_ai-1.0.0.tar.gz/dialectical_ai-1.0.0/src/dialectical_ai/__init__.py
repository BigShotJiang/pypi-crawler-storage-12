"""
Dialectical AI SDK - Public API

This package provides the public API for the Dialectical AI SDK.
Only the client and models are exposed - internal implementation details are kept private.

Example usage:
    from dialectical_ai import DAIClient, AgentRequest, ContextRequest, MessageRequest
    
    client = DAIClient(api_key="dai_your_api_key")
    agent = client.agents.create(AgentRequest(name="Assistant", model="gpt-4o"))
"""
# Import from local modules (self-contained public API)
from .client import DAIClient
from .models import (
    # Request models (what users send)
    AgentRequest,
    UserCreate,
    ContextRequest,
    KnowledgeRequest,
    MessageRequest,
    ToolConfigRequest,
    CronRequest,
    # Response models (what users receive)
    AgentResponse,
    UserResponse,
    ContextResponse,
    KnowledgeResponse,
    MessageResponse,
    ToolConfigResponse,
    CronResponse,
    UsageSummary,
)

__version__ = "1.0.0"
__all__ = [
    # Client
    "DAIClient",
    # Request models
    "AgentRequest",
    "UserCreate",
    "ContextRequest",
    "KnowledgeRequest",
    "MessageRequest",
    "ToolConfigRequest",
    "CronRequest",
    # Response models
    "AgentResponse",
    "UserResponse",
    "ContextResponse",
    "KnowledgeResponse",
    "MessageResponse",
    "ToolConfigResponse",
    "CronResponse",
    "UsageSummary",
]

