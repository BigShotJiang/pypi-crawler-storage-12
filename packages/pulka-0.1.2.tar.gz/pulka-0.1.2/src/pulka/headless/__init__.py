"""Headless execution surface for Pulka.

The ``__init__`` ensures tooling that inspects imports can resolve the
``pulka.headless`` package explicitly.
"""

__all__ = []
