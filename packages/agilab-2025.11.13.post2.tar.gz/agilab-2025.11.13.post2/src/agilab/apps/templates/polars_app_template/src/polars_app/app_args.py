"""Compatibility shim re-exporting :mod:`polars_app.polars_app_args`."""

from .polars_app_args import *  # noqa: F401,F403
