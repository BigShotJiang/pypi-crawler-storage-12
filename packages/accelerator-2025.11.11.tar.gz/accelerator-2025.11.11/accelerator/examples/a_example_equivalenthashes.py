description = 'equivalent_hashes example method'

# equivalent_hashes = {'<verifier>': ('<hash>',)}


def synthesis():
	pass
