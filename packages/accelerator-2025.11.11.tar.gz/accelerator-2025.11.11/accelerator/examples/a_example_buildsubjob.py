from accelerator.subjobs import build

description = 'launch a subjob'


def synthesis():
	build('example_returnhelloworld')
