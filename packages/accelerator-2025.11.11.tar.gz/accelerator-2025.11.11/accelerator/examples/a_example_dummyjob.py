from datetime import datetime

description = "This is a dummy job used by the Urd examples."

options = dict(timestamp=datetime)

jobs = ('previous',)


def synthesis():
	pass
