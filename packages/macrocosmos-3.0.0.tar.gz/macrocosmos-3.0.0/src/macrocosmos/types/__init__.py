from ._exceptions import MacrocosmosError

__all__ = [
    "MacrocosmosError",
]
