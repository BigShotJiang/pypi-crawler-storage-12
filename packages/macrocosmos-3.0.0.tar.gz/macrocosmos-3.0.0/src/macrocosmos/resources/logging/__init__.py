"""Logging resources for the Macrocosmos platform."""
