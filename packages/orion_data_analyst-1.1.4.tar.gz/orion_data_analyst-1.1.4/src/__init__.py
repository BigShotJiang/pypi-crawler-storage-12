"""Orion - AI-Powered Data Analysis Agent"""

__version__ = "1.1.4"

