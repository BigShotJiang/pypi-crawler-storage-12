# demo-pipewire-filtertools - Loopback Demo

Creates capture and playback nodes that pass the audio through.
