# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

from ._create_argparser import main

__all__ = ["main"]
