# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

from .cli._create_argparser import main


main()
