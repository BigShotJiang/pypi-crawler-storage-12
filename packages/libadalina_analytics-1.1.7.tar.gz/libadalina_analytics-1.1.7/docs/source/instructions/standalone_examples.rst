Standalone examples
===================

These examples can be run on a Python 3.10 environment with *libadalina-analytics* installed that
supports Apache Sedona.

.. toctree::

   /libadalina-examples/standalone/relocation_algorithm.ipynb
   /libadalina-examples/standalone/clustering_algorithm.ipynb
   /libadalina-examples/standalone/flows_distribution_algorithm.ipynb