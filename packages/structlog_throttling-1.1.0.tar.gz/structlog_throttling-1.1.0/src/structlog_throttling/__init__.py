__title__ = "structlog-throttling"
__author__ = "Tomás Farías Santana"
__copyright__ = "Copyright (c) 2025 Tomás Farías Santana"
