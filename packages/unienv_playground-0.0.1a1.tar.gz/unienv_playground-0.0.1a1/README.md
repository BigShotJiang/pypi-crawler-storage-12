# Mujoco Playground Adaptor for UniEnvPy

## Installation

```bash
pip install unienv_playground
```

