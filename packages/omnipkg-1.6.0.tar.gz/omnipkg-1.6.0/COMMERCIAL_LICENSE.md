omnipkg Commercial License
===========================

This commercial license is intended for companies or individuals who wish to use omnipkg
in a closed-source product, without complying with the AGPLv3 requirements.

By obtaining a commercial license, you are granted permission to:
 - Use omnipkg in proprietary or SaaS applications
 - Avoid the obligation to release your source code
 - Receive priority support and custom features (optional)

To inquire about commercial terms and pricing, please contact:

📧  omnipkg@proton.me

This license does NOT affect the open-source AGPLv3 version, which remains freely available.
