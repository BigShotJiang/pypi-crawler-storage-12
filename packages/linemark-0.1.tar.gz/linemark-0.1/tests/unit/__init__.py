"""Unit tests for linemark package."""
