"""Ports layer: Protocol definitions for external dependencies."""
