"""Domain layer: Pure business logic and entities."""
