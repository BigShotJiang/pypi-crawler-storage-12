class SSHConnectionException(Exception):
    pass


class PingTimeOutException(Exception):
    pass


class ExitNodeActivationException(Exception):
    pass
