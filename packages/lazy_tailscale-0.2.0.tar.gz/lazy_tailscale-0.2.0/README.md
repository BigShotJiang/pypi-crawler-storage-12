
## Active Development
This app is under active development and considered alpha software. Expect bugs and incomplete features.



## Development
`source .env && uv run textual run --dev -c lazytailscale --port 7342`
`uv run textual console --port 7342 -x SYSTEM -x DEBUG -x INFO`





```
```


```
