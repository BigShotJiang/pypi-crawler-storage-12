"""
version
"""

__version__ = "25.7.6"
__solver_version__ = "release-25.7"
