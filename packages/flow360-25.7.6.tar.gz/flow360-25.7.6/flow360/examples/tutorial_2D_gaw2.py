"""
tutorial2DGaw2 meshing example
"""

from .base_test_case import BaseTestCase


class Tutorial2DGAW2(BaseTestCase):
    name = "tutorial2DGaw2"

    class url:
        geometry = "https://simcloud-public-1.s3.amazonaws.com/tutorials/2d_multielement/2D_GAW2_geometry.csm"
