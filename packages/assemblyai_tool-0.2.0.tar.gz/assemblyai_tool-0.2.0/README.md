# `aait`

This is a simple CLI wrapper around the [AssemblyAI Python SDK].

[AssemblyAI Python SDK]: https://github.com/AssemblyAI/assemblyai-python-sdk
