"""Top-level projection module."""
