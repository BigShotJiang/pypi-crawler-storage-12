"""Main entry point for Riveter CLI when run as python -m riveter."""

from .cli_fast import main

if __name__ == "__main__":
    main()
