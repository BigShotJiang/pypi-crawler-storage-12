"""WOT-PDF Template system."""
