# Free Online Tools

- [WireGuard config generator](https://upvpn.app/wireguard-config-generator/)
- [Wireguard key genereator](https://upvpn.app/wireguard-key-generator/)
- [Domain age checker](https://upvpn.app/tools/domain-age-checker/)