def serverlessVPN():
  return "https://upvpn.app"
