"""Fleet MCP Clean - Clean architecture fleet management for Claude Code agents."""

__version__ = "0.1.0"
