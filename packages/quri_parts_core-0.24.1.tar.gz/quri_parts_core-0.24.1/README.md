# QURI Parts Core

QURI Parts Core is a core component of QURI Parts, a platform-independent library for quantum computing.

## Documentation

[QURI Parts Documentation](https://quri-parts.qunasys.com)

## Installation

```
pip install quri-parts-core
```

## License

Apache License 2.0
