"""CUDA tests for gmtorch."""
