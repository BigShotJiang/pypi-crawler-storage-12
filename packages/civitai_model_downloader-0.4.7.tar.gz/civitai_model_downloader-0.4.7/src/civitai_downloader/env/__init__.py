from civitai_downloader.env.jupyter import JupyterEnvironmentDetector

__all__=['JupyterEnvironmentDetector']