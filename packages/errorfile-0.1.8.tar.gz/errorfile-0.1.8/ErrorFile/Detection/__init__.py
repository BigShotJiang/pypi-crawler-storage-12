# -*- coding: utf-8 -*-
from .FileInspector import FileInspector

__all__ = ["FileInspector"]
