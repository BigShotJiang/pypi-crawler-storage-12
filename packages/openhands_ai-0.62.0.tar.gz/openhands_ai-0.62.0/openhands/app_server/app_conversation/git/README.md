This directory contains files used in git configuration.
