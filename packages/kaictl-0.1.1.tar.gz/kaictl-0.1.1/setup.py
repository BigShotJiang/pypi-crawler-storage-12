#!/usr/bin/env python3
"""
Minimal setup.py - Configuration is in pyproject.toml
This file exists only for backward compatibility and local development.
"""

from setuptools import setup, find_packages

if __name__ == "__main__":
    setup()