class GDB:
  """allows GDB Type hints"""
