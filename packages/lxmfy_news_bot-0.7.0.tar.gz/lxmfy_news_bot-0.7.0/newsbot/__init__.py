from .bot import NewsBot
from .feed import FeedManager

__version__ = "0.1.0"

__all__ = ["FeedManager", "NewsBot"]
