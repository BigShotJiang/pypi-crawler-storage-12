"""Sibyl CLI package metadata (formerly Parallel Developer)."""

__all__ = ["__version__"]

__version__ = "0.2.2"
