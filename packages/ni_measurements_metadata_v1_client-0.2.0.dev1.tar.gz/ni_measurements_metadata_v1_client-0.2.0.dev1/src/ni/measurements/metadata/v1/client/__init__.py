"""Public API for accessing the NI Metadata Store Service."""

from ni.measurements.metadata.v1.client._client import MetadataStoreClient

__all__ = ["MetadataStoreClient"]
