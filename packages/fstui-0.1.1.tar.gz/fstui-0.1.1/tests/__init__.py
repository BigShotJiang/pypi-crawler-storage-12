"""Test suite for FSTUI."""
