"""
Third-party code with different licenses.

This directory contains code from external projects that use licenses
other than the main project license (MIT). Each subdirectory has its
own LICENSE file.
"""
