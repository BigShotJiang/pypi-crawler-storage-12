# Loce Zap Python SDK

Official Python SDK for the Loce Zap multi-session WhatsApp API. The public surface mirrors the JavaScript snippet you shared: instantiate `LoceZap(api_key)` and call camelCase helpers such as `connect`, `send_message_text`, `listSessions`, `delete_message`, etc.

## Installation

```bash
pip install loce-zap
```

During development in this repo:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -e .
```

## Quick start

```python
import LoceZap

zap = LoceZap("your_api_key")

qr = zap.connect("WhatsApp Support", "https://example.com/webhook", webhook_messages=True)
print(qr.qrCode)

zap.send_message_text("my-session-id", "5564999999999", "Hello 👋")
zap.send_message_image("my-session-id", "5564999999999", "https://files.loce.io/promo.png", caption="New feature!")
zap.send_message_document("my-session-id", "5564999999999", "https://files.loce.io/contract.pdf", file_name="Contract.pdf")
zap.send_message_location("my-session-id", "5564999999999", latitude=-16.7033, longitude=-49.263)

zap.delete_message("my-session-id", "65b3...", "5564999999999")
zap.edit_message("my-session-id", "65b3...", "5564999999999", "Updated message")
```

> Numbers must be in E.164 format without the `+` (DDI + number, 6–15 digits). Use the group JID (`xxxxx@g.us`) for groups.

### Async client

```python
import asyncio
import LoceZap

async def main():
    zap = LoceZap.AsyncLoceZap("your_api_key")
    await zap.connect("Store Session", "https://example.com/webhook")
    await zap.send_message_text("store-session", "5564999999999", "Order received!")
    await zap.close()

asyncio.run(main())
```

## High-level API

| Method | Description |
| --- | --- |
| `connect(session_name, webhook_url, webhook_messages=True, *, sync_full_history=False, days_history=7)` | Creates/updates a session and returns status + QR Code info. |
| `disconnect(session_id)` | Closes the WhatsApp session. |
| `listSessions()` | Returns `{ sessions: [...] }` from the backend. |
| `send_message_text(session_id, to, text, *, external_id=None, quote_id=None)` | Plain text message. |
| `send_message_image(session_id, to, image_url, *, caption=None, external_id=None, quote_id=None)` | Sends an image by URL. |
| `sendMessageAudio(session_id, to, audio_url, *, external_id=None, quote_id=None)` | Audio/PTT. |
| `send_message_document(session_id, to, file_url, *, file_name=None, caption=None, mimetype=None, external_id=None, quote_id=None)` | PDFs/documents. |
| `send_message_location(session_id, to, *, latitude, longitude, external_id=None, quote_id=None)` | Location payload. |
| `sendMessageVideo(session_id, to, video_url, *, caption=None, mimetype=None, gif_playback=None, external_id=None, quote_id=None)` | Video/GIF. |
| `sendMessageSticker(session_id, to, sticker_url, *, external_id=None, quote_id=None)` | Sticker message. |
| `delete_message(session_id, message_id, to)` | Requests deletion of a previously sent message. |
| `edit_message(session_id, message_id, to, text)` | Edits a previously sent message. |

All responses are `APIResponse`, which works like a dict but also allows attribute access (`resp.messageId`).

## Configuration

Constructor signature: `LoceZap(api_key, base_url=..., timeout=..., max_retries=..., backoff_factor=..., default_headers=None)`. Only `api_key` is mandatory.

## Webhooks

Use the built-in verifier to validate the HMAC signature sent by Loce Zap:

```python
from LoceZap import WebhookVerifier, WebhookSignatureError

signature = request.headers.get("x-locezap-signature")
try:
    WebhookVerifier.verify_signature(signature_header=signature, body=request.data, secret="your_api_key")
except WebhookSignatureError:
    abort(400, "Invalid signature")
```

## Build & publish

```bash
python3 -m build
python3 -m twine upload dist/*            # or --repository testpypi
```

## License

MIT.
