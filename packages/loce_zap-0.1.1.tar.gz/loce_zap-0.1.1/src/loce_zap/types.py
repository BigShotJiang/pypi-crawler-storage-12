from __future__ import annotations

from typing import List

from typing_extensions import NotRequired, TypedDict


class Session(TypedDict, total=False):
    _id: str
    id: str
    user: str
    name: str
    wppId: str
    phone: str
    webhookUrl: str
    webhookMessages: bool
    syncFullHistory: bool
    daysHistory: int
    autoRejectCalls: bool
    queueName: str
    createdAt: str
    updatedAt: str


class SessionConnectResponse(TypedDict, total=False):
    sessionId: str
    message: str
    status: str
    qrCode: NotRequired[str]
    expiresAt: NotRequired[str]


class SessionDisconnectResponse(TypedDict, total=False):
    sessionId: str
    success: bool
    message: NotRequired[str]


class SessionUpdateResponse(TypedDict, total=False):
    message: str
    session: Session


class SessionListResponse(TypedDict):
    sessions: List[Session]


class SendMessageResponse(TypedDict, total=False):
    message: str
    success: bool
    messageId: str


class DeleteOredit_messageResponse(TypedDict, total=False):
    success: bool
    message: str
    messageId: str


class WebhookEnvelope(TypedDict, total=False):
    api_key: str
    sessionId: str
    type: str
    payload: dict
