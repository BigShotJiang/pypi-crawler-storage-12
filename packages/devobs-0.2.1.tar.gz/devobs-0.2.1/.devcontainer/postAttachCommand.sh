#!/usr/bin/env bash

# Convenience alias for this project
echo 'alias devobs="cargo run --"' >> ~/.bashrc

make install
