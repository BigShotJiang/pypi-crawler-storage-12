# devobs

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![codecov](https://codecov.io/gh/lasuillard-s/devobs/graph/badge.svg?token=VlANvU6qUC)](https://codecov.io/gh/lasuillard-s/devobs)
[![PyPI - Version](https://img.shields.io/pypi/v/devobs)](https://pypi.org/project/devobs/)

CLI for obsessed developers.
