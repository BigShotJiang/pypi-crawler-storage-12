from __decryptor__ import decrypt_stream_url

embed = "https://streameeeeee.site/embed-1/v3/e-1/j48684YbFqZQ?z="

decrypt_stream_url(embed)
