# flake8: noqa

# import apis into api package
from wink_sdk_extranet_booking.api.analytics_api import AnalyticsApi
from wink_sdk_extranet_booking.api.calendar_sync_api import CalendarSyncApi
from wink_sdk_extranet_booking.api.consumer_booking_api import ConsumerBookingApi
from wink_sdk_extranet_booking.api.property_booking_api import PropertyBookingApi
from wink_sdk_extranet_booking.api.review_api import ReviewApi
from wink_sdk_extranet_booking.api.test_booking_api import TestBookingApi

