"""Configuration module for signal mappings."""
