"""Config for xtb parallelisation."""

OMP_NUM_THREADS: int = 1
OMP_STACKSIZE: str = "1G"
OMP_MAX_ACTIVE_LEVELS: int = 1
