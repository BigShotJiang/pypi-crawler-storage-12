import pygenpdf_json


pygenpdf_json.render_json_file("invoice.json", "invoice.pdf")
pygenpdf_json.render_json_file("layout_test.json", "layout_test.pdf")
pygenpdf_json.render_json_file("table_test.json", "table_test.pdf")
