"""
PIVTOOLs Core - Shared utilities for PIVTOOLs packages
"""

__version__ = "0.1.0"