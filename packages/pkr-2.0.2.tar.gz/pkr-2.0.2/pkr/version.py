# Copyright© 1986-2024 Altair Engineering Inc.

"""pkr version"""

import importlib.metadata

__version__ = importlib.metadata.version("pkr")
