# GLiNER2

::: sieves.engines.gliner_.GliNER
