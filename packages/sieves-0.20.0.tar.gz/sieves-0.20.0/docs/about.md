# About

For any feedback, feature requests, contributions etc. use our [GitHub issue tracker](https://github.com/MantisAI/sieves/issues).

`sieves` is maintained by [Mantis](https://mantisnlp.com), an AI consultancy. We help our clients to solve business problems related to 
natural human language and speech. If that's something you're interested in - [drop us a line](https://mantisnlp.com/contact/#cta)!  