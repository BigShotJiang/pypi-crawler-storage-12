"""Sample app for testing."""
