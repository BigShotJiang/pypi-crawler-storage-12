# This app has no models, so no migrations are needed
