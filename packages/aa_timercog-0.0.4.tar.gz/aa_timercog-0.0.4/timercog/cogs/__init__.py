"""
Timer Cog - Discord cogs module
"""
