# Import everything from the real gem package
from gem import *

# currently released version information
__version__ = "0.1.2"
