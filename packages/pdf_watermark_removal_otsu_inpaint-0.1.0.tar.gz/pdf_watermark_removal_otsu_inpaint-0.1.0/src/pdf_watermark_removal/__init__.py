"""PDF Watermark Removal using Otsu Threshold and OpenCV Inpaint."""

__version__ = "0.1.0"
