# Copyright (C) 2025 Intel Corporation
# SPDX-License-Identifier: MIT
"""Const for DMA module."""

DMA_COALESCING = ["DMACoalescing"]
