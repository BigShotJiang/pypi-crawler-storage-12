# Copyright (C) 2025 Intel Corporation
# SPDX-License-Identifier: MIT
"""Module for basic static API."""
