# Copyright (C) 2025 Intel Corporation
# SPDX-License-Identifier: MIT
"""Module for network adapter owner's features."""
