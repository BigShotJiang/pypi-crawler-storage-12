"""Collection base classes for schematic elements."""

from .base import BaseCollection

__all__ = ["BaseCollection"]
