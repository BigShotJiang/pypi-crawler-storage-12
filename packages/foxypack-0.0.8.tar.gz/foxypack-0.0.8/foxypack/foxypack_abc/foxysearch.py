from abc import ABC


class FoxySearch(ABC):
    pass
