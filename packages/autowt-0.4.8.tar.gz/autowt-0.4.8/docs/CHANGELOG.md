<!-- CHANGELOG_INSERT -->

## Unreleased

### Added

- Interactive switch TUI: Running `autowt switch` with no arguments opens an interactive interface that shows existing worktrees (sorted by creation time), branches without worktrees, and allows creating new branches inline. The most recently created worktree is auto-selected.
