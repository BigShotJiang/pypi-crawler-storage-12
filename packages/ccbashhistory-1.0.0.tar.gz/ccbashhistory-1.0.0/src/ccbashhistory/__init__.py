"""ccbashhistory - Extract and analyze bash commands from Claude Code session history."""

__version__ = "1.0.0"
