"""
Sources
"""

NAME = "Shadow4 \u23F5 Sources"

DESCRIPTION = "Sources."

BACKGROUND = "#b9d47a"

ICON = "icons/source.png"

PRIORITY = 4.0
