#!/usr/bin/env python
# -*- encoding: utf8 -*-

dirMap = {'cn':'cn_baostock',
            'bn':'bn',
            'BN':'bn',
            'us':'yf'}
