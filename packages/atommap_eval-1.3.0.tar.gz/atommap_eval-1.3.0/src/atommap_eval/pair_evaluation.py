from concurrent.futures import ProcessPoolExecutor, TimeoutError, as_completed
from typing import List, Optional, Tuple, Union
from functools import partial
import time
import multiprocessing as mp

from .data_models import ReactionPair
from .evaluator import are_atom_maps_equivalent



def _unpack_pair(pair: Union[Tuple[str, str], "ReactionPair"]) -> Tuple[str, str]:
    """Extract (gt, pred) from a tuple or a ReactionPair."""
    if isinstance(pair, tuple):
        return pair
    elif hasattr(pair, "ground_truth") and hasattr(pair, "prediction"):
        return pair.ground_truth, pair.prediction
    else:
        raise TypeError(f"Unsupported pair type: {type(pair)}")


def _safe_equivalence_check(gt: str, pred: str, canonicalize: bool = False) -> bool:
    """Safely call are_atom_maps_equivalent in a subprocess."""
    return are_atom_maps_equivalent(gt_smi=gt, pred_smi=pred, canonicalize=canonicalize)


def _run_with_hard_timeout(func, args=(), timeout: float = 1.0):
    """
    [dev]
    Run func(*args) with a hard timeout (kills process if over time). 
    Extremely slow, with timeout = 1 makes most of the evaluations timeout.
    """
    ctx = mp.get_context("spawn")
    with ctx.Pool(1) as pool:
        res = pool.apply_async(func, args)
        try:
            return res.get(timeout=timeout)
        except mp.context.TimeoutError:
            pool.terminate()
            return None


def evaluate_pairs_batched(
    pairs: List[Union[Tuple[str, str], "ReactionPair"]],
    canonicalize: bool = False,
    num_workers: Optional[int] = None,
    batch_size: int = 1000,
    timeout: float = 1.0,
) -> List[Tuple[Optional[bool], str]]:
    """
    Evaluate atom-map equivalence for many (gt, pred) pairs using batches, timeouts, and parallelism.

    Args:
        pairs: list of (gt_smiles, pred_smiles) tuples or ReactionPair objects
        canonicalize: whether to canonicalize before comparison
        num_workers: number of parallel workers (defaults to os.cpu_count())
        batch_size: number of reactions to process per batch
        timeout: per-reaction timeout in seconds

    Returns:
        List[Tuple[Optional[bool], str]]:
            Each element is (equivalent, status)
            where status is in {"ok", "timeout", "invalid_input", "error:<type>"}
    """
    results_all: List[Tuple[Optional[bool], str]] = []
    total_start = time.perf_counter()

    print(f"Starting evaluation of {len(pairs)} pairs with {num_workers or 'default'} workers...", flush=True)

    with ProcessPoolExecutor(max_workers=num_workers) as executor:
        for start in range(0, len(pairs), batch_size):
            end = min(start + batch_size, len(pairs))
            print(f"Submitting batch {start}-{end} / {len(pairs)}...", flush=True)

            batch = pairs[start:end]
            futures = []

            for pair in batch:
                gt, pred = _unpack_pair(pair)
                if not isinstance(gt, str) or not isinstance(pred, str) or not gt.strip() or not pred.strip():
                    results_all.append((None, "invalid_input"))
                    continue
                futures.append(executor.submit(_safe_equivalence_check, gt, pred, canonicalize))

            # collect results
            for future in as_completed(futures):
                start_t = time.perf_counter()
                try:
                    equivalent = future.result(timeout=timeout)
                    status = "ok"
                except TimeoutError:
                    equivalent, status = None, "timeout"
                except Exception as e:
                    equivalent, status = None, f"error:{type(e).__name__}"
                elapsed = time.perf_counter() - start_t
                results_all.append((equivalent, status))
                if elapsed > 10: 
                    print(f"[WARN]  Slow reaction took {elapsed:.1f}s", flush=True)

    total_elapsed = time.perf_counter() - total_start
    print(f"[DONE] Processed {len(pairs)} pairs in {total_elapsed:.2f}s using {num_workers or 'default'} workers.")
    return results_all
