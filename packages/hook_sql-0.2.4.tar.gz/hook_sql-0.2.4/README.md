# hook-sql

SQL dependency analysis and validation tools using SQLGlot.

## Installation

```bash
pip install hook-sql
```

## Usage

TODO: Add usage examples

## Development

```bash
make bootstrap
make test
```
