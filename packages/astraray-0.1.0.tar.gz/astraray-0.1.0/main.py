def main():
    print("Hello from astraray!")


if __name__ == "__main__":
    main()
