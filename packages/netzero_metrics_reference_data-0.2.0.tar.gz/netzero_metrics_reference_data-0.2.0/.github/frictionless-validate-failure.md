---
title: Frictionless validate failure on {{ date | date() }}
labels: bug
---