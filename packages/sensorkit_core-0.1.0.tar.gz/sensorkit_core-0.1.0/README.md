# sensorkit-core

Placeholder package reserved for future SensorKit backend.
