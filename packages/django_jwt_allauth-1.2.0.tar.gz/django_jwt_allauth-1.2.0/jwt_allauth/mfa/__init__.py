default_app_config = "jwt_allauth.apps.JWTAllauthConfig"
