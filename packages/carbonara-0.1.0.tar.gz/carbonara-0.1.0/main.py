def main():
    print("Hello from carbonara!")


if __name__ == "__main__":
    main()
