def saluta(nome: str) -> str:
    return f"Ciao {nome}!!"
