# mio-package

Esempio di package Python.

## Installazione

pip install mio-package

## Utilizzo

```python
from mio_package import saluta
print(saluta("Antonio"))

