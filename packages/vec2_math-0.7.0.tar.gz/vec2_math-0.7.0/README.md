# vec2_math

Common vector operations in 2D. This is a collection of straightforward vector math I use often. The functions take iterable arguments so they can be called with numpy arrays, but will always return vectors as `tuple[float, float]`.
