from nbprint import Context


class ExampleResearchReferencesContext(Context): ...
