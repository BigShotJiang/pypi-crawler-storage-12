from ._version import get_versions

AUTHOR = 'SatNOGS project'
EMAIL = 'dev@satnogs.org'
VERSION = get_versions()['version']

del get_versions
