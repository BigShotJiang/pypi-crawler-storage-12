"""SatNOGS Client module main function"""
import sys

import satnogsclient

if __name__ == '__main__':
    sys.exit(satnogsclient.main())
