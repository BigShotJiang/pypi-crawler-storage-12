Pre-compiled binaries
---------------------

`Pre-compiled binaries <https://aubio.org/download>`_
are available for
`macOS <https://aubio.org/download#osx>`_,
`iOS <https://aubio.org/download#ios>`_,
and
`windows <https://aubio.org/download#win>`_

For Windows, aubio is also available from `vcpkg
<https://vcpkg.readthedocs.io/en/latest/examples/installing-and-using-packages/>`_.

To use aubio in a macOS or iOS application, see :ref:`xcode-frameworks-label`.

