.. _android:

Android build
-------------

To compile aubio for android, you will need to get the `Android Native
Development Toolkit (NDK) <https://developer.android.com/ndk/>`_, prepare a
standalone toolchain, and tell waf to use the NDK toolchain. An example script
to complete these tasks is available in ``scripts/build_android``.
