.. currentmodule:: aubio
.. default-domain:: py

Digital filters
---------------

.. autoclass:: digital_filter
  :members:
