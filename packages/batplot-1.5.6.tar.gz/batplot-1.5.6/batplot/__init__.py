"""batplot: Interactive plotting for battery data visualization."""

__version__ = "1.5.6"

__all__ = ["__version__"]
