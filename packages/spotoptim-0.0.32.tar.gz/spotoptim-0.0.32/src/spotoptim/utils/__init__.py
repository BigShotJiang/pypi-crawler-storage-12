"""Utility functions for spotoptim."""

from .mapping import map_lr

__all__ = ["map_lr"]
