"""Neural network models for spotoptim."""

from .linear_regressor import LinearRegressor

__all__ = ["LinearRegressor"]
