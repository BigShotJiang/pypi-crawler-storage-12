<p align="center">
  <img src="examples/logo.png" width="200" height="200" alt="Siberia" />
</p>

# Volk
Python WSGI server

### Install
```bash
pip install volk 
```

- `HTTP/1.0` *TODO*