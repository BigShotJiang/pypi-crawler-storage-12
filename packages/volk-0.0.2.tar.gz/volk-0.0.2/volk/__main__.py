from volk import Volk


def volk_cli():
    volk = Volk()
    volk.serve()


if __name__ == "__main__":
    volk_cli()
