from volk.volk import Volk
from volk.wsgi import WSGIApplication
