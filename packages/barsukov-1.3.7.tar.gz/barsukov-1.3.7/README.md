# Barsukov

Barsukov is a Python library for experiment automation.

## For Developers

To push to PyPi, commit to main on Github Desktop, click the history tab, right click and create tag, format the tag v\*.\*.\* and push to the repository (ctrl+p).

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install barsukov.

```bash
pip install barsukov
```
Dependencies: pytz, dill, numpy, scipy, matplotlib, pyvisa, IPython, PyQt5, pyqtgraph
## Usage

```python
#
#
#
#
#
#
#
```

## Contributing

-
-
-

## License

[MIT](https://choosealicense.com/licenses/mit/)
