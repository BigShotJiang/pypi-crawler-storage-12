# 作者：Xiaoqiang
# 微信公众号：XiaoqiangClub
# 创建时间：2025-11-12T01:58:39.018Z
# 文件描述：此文件已废弃，请勿使用。请直接调用 xqcsendmessage.api 中的函数。
# 文件路径：xqcsendmessage/client.py

# 此文件已废弃，请勿使用。
# 请直接调用 xqcsendmessage.api 中的函数。
# 例如：
# from xqcsendmessage.api import send_email, send_dingtalk, send_wecom_webhook, send_wecom_app
# from xqcsendmessage.api import send_email_async, send_dingtalk_async, send_wecom_webhook_async, send_wecom_app_async

raise DeprecationWarning(
    "xqcsendmessage/client.py 模块已废弃，请直接使用 xqcsendmessage.api 中的函数。"
)
