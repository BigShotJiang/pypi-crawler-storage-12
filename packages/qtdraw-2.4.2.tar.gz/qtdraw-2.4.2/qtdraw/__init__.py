"""
QtDraw
"""

from pathlib import Path

__version__ = "2.4.2"
__date__ = "2021 -"
__author__ = "Hiroaki Kusunose"
__top_dir__ = Path(__file__).parent / ".."
