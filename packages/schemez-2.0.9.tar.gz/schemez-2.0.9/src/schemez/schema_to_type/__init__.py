"""Schema to Type."""

from schemez.schema_to_type.main_impl import json_schema_to_pydantic_class
# from schemez.schema_to_type.marvin_impl import schema_to_type as marvin_schema_to_type

__all__ = ["json_schema_to_pydantic_class"]
