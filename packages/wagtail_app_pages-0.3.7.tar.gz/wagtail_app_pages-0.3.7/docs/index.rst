Welcome to Wagtail App Pages's documentation!
=============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   usage
   examples
   caveats
   contributing
   authors
   history
   modules

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
