=======
History
=======

0.3.7
-------------------

* target wagtail>=6.0,<=7.2

0.3.6
-------------------

* target wagtail>=6.0,<=6.4

0.3.5
-------------------

* correct dependancy issue

0.3.4
-------------------

* target wagtail<=5.0,>=5.2

0.3.3
-------------------

* fix requirements

0.3.2
-------------------

* Wagtail support for 5.0, dropping support for 3

0.3.1
-------------------

* Wagtail support up to 4.2

0.3.0
-------------------

* Release targeting exclusively Wagtail 3x and 4x versions

0.2.21
-------------------

* Wagtail support up to 4.0

0.2.20
-------------------

* Wagtail 2.14 support
* Wagtail 2.15 support

0.2.19
-------------------

* Wagtail 2.12 support
* Wagtail 2.13 support

0.2.17
-------------------

* Wagtail 2.11 support

0.2.16 (2020-09-08)
-------------------

* Wagtail 2.10 support

0.2.15 (2020-06-17)
-------------------

* Wagtail 2.9 support

0.2.14 (2020-02-03)
-------------------

* Wagtail 2.8 support

0.2.13 (2019-11-13)
-------------------

* Wagtail 2.7 support

0.2.12 (2019-10-01)
-------------------

* Re-integrating multi-site fix

0.2.11 (2019-09-11)
-------------------

* Correctly update wagtail 2.6 support in setup.py

0.2.10 (2019-09-02)
-------------------

* Wagtail 2.6 support

0.2.9 (2019-08-12)
------------------

* fix issue regarding url resolving in multi-site scenarios

0.2.8 (2019-06-03)
------------------

* Wagtail 2.5 support

0.2.7 (2019-01-21)
------------------

* Wagtail 2.4 support

0.2.6 (2018-11-06)
------------------

* update requirements

0.2.5 (2018-08-06)
------------------

* ensure that parent page will also be available as "page" in the context

0.2.4 (2018-07-26
-----------------

* Support for app page revisions

0.2.3 (2018-05-29)
------------------

* Django 1.11 LTS support (issue #1)

0.2.2 (2018-04-19)
------------------

* add context processor to provide parent_page to context

0.2.1 (2018-04-10)
------------------

* fix templatetags missing in dist

0.2.0 (2018-03-30)
------------------

* change to beta

0.1.0 (2018-03-15)
------------------

* First release on PyPI.
