# -*- coding: utf-8 -*-

"""Top-level package for Wagtail App Pages."""

__author__ = """Marco Westerhof"""
__email__ = 'westerhof.marco@gmail.com'
__version__ = '0.3.7'
