from django.apps import AppConfig


class AppPagesConfig(AppConfig):
    name = 'wagtail_app_pages'
