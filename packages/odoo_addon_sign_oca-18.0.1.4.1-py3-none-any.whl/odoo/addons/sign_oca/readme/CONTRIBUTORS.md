- Enric Tobella (www.dixmit.com)
- [Tecnativa](https://www.tecnativa.com):
  - Víctor Martínez

- [Kencove](https://www.kencove.com):
  - Mohamed Alkobrosli
