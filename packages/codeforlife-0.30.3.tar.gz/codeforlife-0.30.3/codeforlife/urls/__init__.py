"""
© Ocado Group
Created on 16/09/2024 at 15:23:05(+01:00).
"""

from .handlers import handler400, handler403, handler404, handler500
from .patterns import UrlPatterns, get_urlpatterns
