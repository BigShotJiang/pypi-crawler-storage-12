# This is a placeholder for init; Define to prevent a plugin
# loader to print an error string on 'missing init' like this ...
# def init():
#   pass

def init():
    pass

# EOF