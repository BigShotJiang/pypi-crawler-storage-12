class ExecutorError(Exception):
    """自定义异常"""

    pass
