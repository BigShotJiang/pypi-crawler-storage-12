class LunaError(Exception):
    """Base exception for all exceptions in the Luna SDK."""
