class BaseLunaQuantumError(Exception):
    """Base class for all Luna Quantum errors."""
