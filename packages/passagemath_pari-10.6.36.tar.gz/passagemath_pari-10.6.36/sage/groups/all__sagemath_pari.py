# sage_setup: distribution = sagemath-pari

from sage.groups.pari_group import PariGroup
