# sage_setup: distribution = sagemath-pari
from cypari2 import PariError
from cypari2.gen import Gen as pari_gen

from sage.libs.pari import pari
