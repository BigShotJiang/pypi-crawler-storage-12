"""Setup script for fayda-python-sdk

This file is kept for backward compatibility. The package is configured via pyproject.toml.
"""

from setuptools import setup

setup()

