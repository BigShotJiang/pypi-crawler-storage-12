# prefect-bitbucket

<p align="center">
    <a href="https://pypi.python.org/pypi/prefect-bitbucket/" alt="PyPI version">
        <img alt="PyPI" src="https://img.shields.io/pypi/v/prefect-bitbucket?color=0052FF&labelColor=090422"></a>
    <a href="https://pepy.tech/badge/prefect-bitbucket/" alt="Downloads">
        <img src="https://img.shields.io/pypi/dm/prefect-bitbucket?color=0052FF&labelColor=090422" /></a>
</p>

See the docs at [https://docs.prefect.io/integrations/prefect-bitbucket](https://docs.prefect.io) for more information.
