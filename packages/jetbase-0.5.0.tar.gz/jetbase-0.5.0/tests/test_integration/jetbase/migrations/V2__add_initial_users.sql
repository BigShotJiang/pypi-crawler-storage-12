-- Add initial users
INSERT INTO users (name) VALUES 
    ('bob'),
    ('mike'),
    ('jack');