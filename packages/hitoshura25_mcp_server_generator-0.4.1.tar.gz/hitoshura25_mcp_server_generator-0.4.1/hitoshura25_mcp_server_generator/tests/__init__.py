"""
Tests for mcp_server_generator package.
"""
