export const RECCE_SUPPORT_CALENDAR_URL = "https://cal.com/team/recce/chat";
