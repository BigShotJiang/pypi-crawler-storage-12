# Exceptions

Custom exception types and error-handling helpers.
