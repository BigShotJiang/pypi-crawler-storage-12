# textrpp_py


Python dependency bundle for the `textrpp` R package. This package is intentionally minimal: it exists to let `pip` install the heavy Python dependencies in a single step.


Install via:


```bash
pip install textrpp_py
```