window.addEventListener('load', autoInitFileForms);
