from typing import Type, TYPE_CHECKING, TypeVar


T = TypeVar("T")


def with_typehint(baseclass: Type[T]) -> Type[T]:
    """
    Useful function to make mixins with baseclass typehint

    ```
    class ReadonlyMixin(with_typehint(BaseAdmin))):
        ...
    ```
    """
    if TYPE_CHECKING:
        return baseclass  # pragma: no cover

    return object
