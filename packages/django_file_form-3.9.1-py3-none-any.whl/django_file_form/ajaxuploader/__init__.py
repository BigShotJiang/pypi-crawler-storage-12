# placeholder package for django_file_form.ajaxuploader
# You should not add django_file_form.ajaxuploader to INSTALLED_APPS
