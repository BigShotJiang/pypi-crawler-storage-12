# Progress Example

## Quickstart

Run the MCP server:

```bash
python examples/progress/server.py
```

Run the progress example:

```bash
python examples/progress/progress.py
```
