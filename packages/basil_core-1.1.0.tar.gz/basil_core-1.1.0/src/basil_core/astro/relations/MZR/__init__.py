from basil_core.astro.relations.MZR.MZR import Madau_Fragos_MZR
from basil_core.astro.relations.MZR.MZR import Ma2015_MZR
from basil_core.astro.relations.MZR.MZR import Nakajima2023_MZR
from basil_core.astro.relations.MZR.MZR import Solar_MZR
