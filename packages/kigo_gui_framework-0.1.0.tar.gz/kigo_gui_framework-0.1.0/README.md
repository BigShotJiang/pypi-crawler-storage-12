# Kigo

Kigo is a simple Python GUI library built on top of Tkinter. It provides an easy-to-use API for creating GUI applications without installing any external dependencies.

## Features
- App window management
- Widgets: Label, Button, TextBox, Dropdown
- Simple and Pythonic API

## Installation
```bash
python -m 
pip install kigo. Kigo is also available on GitHub