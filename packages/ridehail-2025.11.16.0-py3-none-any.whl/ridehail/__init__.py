"""Ridehail simulation package."""

__version__ = "2025.11.16.0"
