#!/usr/bin/env python
"""Runtime entry point."""

from lithi.app import app

if __name__ == "__main__":
    app()
