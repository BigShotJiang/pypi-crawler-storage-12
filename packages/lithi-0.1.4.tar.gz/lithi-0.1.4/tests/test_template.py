"""Template for unit tests."""


def test_template() -> None:
    """Template unit test."""
    assert True
