"""bizlog package."""

from .settings import Settings

appConfig: Settings = Settings()

__all__ = ["appConfig"]
