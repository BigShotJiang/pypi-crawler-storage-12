def hello_msg(msg: str) -> str:
    return f"Hello, {msg}"
