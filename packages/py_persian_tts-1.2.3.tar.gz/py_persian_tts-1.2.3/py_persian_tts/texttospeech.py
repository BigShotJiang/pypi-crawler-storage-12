import os
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC

class TextToSpeech:
    def __init__(self, download_dir="downloads", headless=True, language="fa-IR"):
        self.download_dir = os.path.abspath(download_dir)
        os.makedirs(self.download_dir, exist_ok=True)
        self.language = language


        chrome_options = Options()
        prefs = {
            "download.default_directory": self.download_dir,
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "safebrowsing.enabled": True
        }
        chrome_options.add_experimental_option("prefs", prefs)
        if headless:
            chrome_options.add_argument("--headless=new")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")

        # ران کردن WebDriver
        self.driver = webdriver.Chrome(options=chrome_options)
        self.driver.get("https://fa.text-to-speech.online/")
        self.wait = WebDriverWait(self.driver, 25)

        # تنظیم زبان فارسی
        locale_select = Select(self.wait.until(
            EC.presence_of_element_located((By.ID, "locale"))
        ))
        locale_select.select_by_value(self.language)
        print(f"✅ زبان تنظیم شد: {self.language}")

    def speak(self, text, gender="male"):
        """
        تولید صدا با متن داده شده.
        gender: "female" یا "male"
        """

        # پاکسازی فایل‌های MP3 قدیمی
        for f in os.listdir(self.download_dir):
            if f.endswith(".mp3"):
                os.remove(os.path.join(self.download_dir, f))

        # وارد کردن متن
        textarea = self.wait.until(EC.presence_of_element_located((By.ID, "text")))
        textarea.clear()
        textarea.send_keys(text)
        print("✔ متن وارد شد.")

        # تنظیم جنسیت صدا
        gender_map = {
            "female": "fa-IR-DilaraNeural",
            "male": "fa-IR-FaridNeural"
        }

        voice_select = Select(self.wait.until(
            EC.presence_of_element_located((By.ID, "voice"))
        ))
        voice_select.select_by_value(gender_map.get(gender.lower(), "fa-IR-DilaraNeural"))
        print(f"✅ جنسیت صدا تنظیم شد: {gender}")

        # کلیک روی دکمه دانلود
        download_btn = self.wait.until(EC.element_to_be_clickable((By.ID, "download")))
        self.driver.execute_script("arguments[0].click();", download_btn)
        print("⏳ در حال تولید صوت... صبر کن...")

        # انتظار برای دانلود فایل جدید MP3
        filename = None
        for _ in range(60):
            files = os.listdir(self.download_dir)
            mp3s = [f for f in files if f.endswith(".mp3")]
            if mp3s:
                filename = mp3s[0]
                break
            time.sleep(1)

        if filename:
            file_path = os.path.join(self.download_dir, filename)
            print("🎉 فایل دانلود شد →", file_path)
            return file_path
        else:
            print("❌ فایل MP3 پیدا نشد.")
            return None

    def close(self):
        self.driver.quit()
        print("🔒 مرورگر بسته شد.")