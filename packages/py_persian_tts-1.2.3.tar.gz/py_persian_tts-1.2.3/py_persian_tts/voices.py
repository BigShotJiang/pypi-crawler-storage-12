# persian_tts/voices.py

VOICES = {
    "woman1": "🌼 شیوا",
    "woman2": "🌷 مهتاب",
    "woman3": "🌺 نگار",
    "woman4": "🌹 ریما",
    "man1":   "🌠 راد",
    "man2":   "🌠 پیام",
    "man3":   "🚀 بهمن",
    "man4":   "🚀 برنا",
    "man5":   "🦁 کیان",
    "man6":   "💧 نیما",
    "man7":   "⚡️ آریا",
    "boy1":   "🌟 آرش"
}

def list_voices():
    """بازگرداندن لیست کل شخصیت‌ها"""
    return list(VOICES.keys())
