# PersianTTS

یک کتابخانه فارسی برای تبدیل متن به صدا با شخصیت‌های مختلف.

این کتابخانه به شما امکان می‌دهد متن فارسی را با صدای شخصیت‌های متفاوت به فایل صوتی تبدیل کنید و آن را ذخیره نمایید.

---

## نصب

برای نصب کتابخانه، ابتدا اطمینان حاصل کنید که Python 3.8 یا بالاتر دارید و سپس از pip استفاده کنید:


---
## لیست شخصیت‌ها (Voices)
| کلید شخصیت | نام شخصیت |
| ---------- | --------- |
| woman1     | 🌼 شیوا   |
| woman2     | 🌷 مهتاب  |
| woman3     | 🌺 نگار   |
| woman4     | 🌹 ریما   |
| man1       | 🌠 راد    |
| man2       | 🌠 پیام   |
| man3       | 🚀 بهمن   |
| man4       | 🚀 برنا   |
| man5       | 🚀 برنا-1 |
| man6       | 🦁 کیان   |
| man7       | 💧 نیما   |
| man8       | ⚡️ آریا   |
| boy1       | 🌟 آرش    |



```python
from py_persian_tts import PersianTTS, list_voices
import asyncio

async def main():
    tts = PersianTTS(default_voice="man1")
    
    # نمایش شخصیت‌ها
    print("شخصیت‌ها:", list_voices())
    
    # تبدیل متن به صدا (نسخه async)
    await tts.speak_async("سلام این یک تست است.", voice="man2", filename="tewst.wav")
    print("عملیات با موفقیت انجام شد")



# اجرای تابع async
if __name__ == "__main__":
    asyncio.run(main())

import asyncio
from py_persian_tts import PersianTTS

async def main():
    tts = PersianTTS(default_voice="man1", rate_limit=0.5)  # هر 2 ثانیه یک درخواست

    texts = [
        "سلام این یک تست است",
        "این هم متن دوم برای تست صف TTS.",
        
    ]

    tasks = []
    for i, text in enumerate(texts):
        filename = f"tts_queue_{i+1}.wav"
        # اضافه کردن هر متن به صف و گرفتن Future
        tasks.append(tts.speak_async(text, filename=filename))

    # اجرای همه و گرفتن مسیر فایل‌ها
    results = await asyncio.gather(*tasks)
    for path in results:
        print("فایل صوتی ذخیره شد:", path)

    # پایان کار و توقف پردازش صف
    await tts.shutdown()

# اجرای مثال
asyncio.run(main())
```

## ⚠️ هشدار مهم درباره کلاس `TextToSpeech`

کلاس `TextToSpeech` در این کتابخانه **با استفاده از Selenium پیاده‌سازی شده است** و برای کارکرد صحیح نیاز دارد:

1. **Google Chrome** نصب شده باشد.  
2. **ChromeDriver** مناسب با نسخه کروم روی سیستم شما موجود باشد.

---

### 🔹 ChromeDriver چیست؟

**ChromeDriver** یک برنامه‌ی کمکی است که به Selenium اجازه می‌دهد با مرورگر Google Chrome تعامل کند.  
به عبارت دیگر، Selenium خودش مرورگر را اجرا نمی‌کند؛ ChromeDriver رابط بین کد پایتون شما و مرورگر کروم است.  
بدون ChromeDriver، کلاس `TextToSpeech` نمی‌تواند سایت [fa.text-to-speech.online](https://fa.text-to-speech.online/) را کنترل کرده و فایل صوتی تولید کند.

---

### 🔹 نکات مهم:

- اگر ChromeDriver یا گوگل کروم نصب نباشد، هنگام فراخوانی کلاس `TextToSpeech` با خطا مواجه می‌شوید.
- توصیه می‌شود از [WebDriver Manager](https://pypi.org/project/webdriver-manager/) برای مدیریت خودکار ChromeDriver استفاده کنید تا نسخه مناسب به صورت خودکار دانلود شود.
- مسیر پیش‌فرض دانلود فایل‌های صوتی، پوشه‌ی `downloads` در مسیر پروژه است.
- این روش **نیاز به اینترنت دارد**، زیرا متن به وب‌سایت TTS ارسال می‌شود.

---

### 🔹 نصب ChromeDriver

1. ابتدا مطمئن شوید Google Chrome روی سیستم شما نصب است.
2. نسخه مرورگر خود را بررسی کنید (مثلاً Chrome → Help → About Google Chrome).  
3. ChromeDriver مناسب همان نسخه را از لینک زیر دانلود کنید:  
   [https://chromedriver.chromium.org/downloads](https://chromedriver.chromium.org/downloads)
4. فایل ChromeDriver دانلود شده را در مسیر PATH سیستم یا یک مسیر دلخواه قرار دهید.  
5. حالا کلاس `TextToSpeech` بدون مشکل کار خواهد کرد.

---

### 🔹 مثال استفاده از کلاس

```python
from  py_persian_tts import TextToSpeech


tts = TextToSpeech()


file_path = tts.speak("سلام دنیا", gender="male")


tts.close()



```

```bash
pip install --upgrade  py-persian-tts 