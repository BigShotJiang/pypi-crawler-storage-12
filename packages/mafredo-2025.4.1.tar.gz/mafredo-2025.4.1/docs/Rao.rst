RAO
======================


.. autoclass:: mafredo.Rao
