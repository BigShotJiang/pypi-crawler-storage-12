Examples
=========

It is often easier to copy-paste an example than to read the docs.
