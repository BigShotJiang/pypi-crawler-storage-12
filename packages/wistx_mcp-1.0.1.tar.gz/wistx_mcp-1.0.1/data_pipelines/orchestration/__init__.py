"""Pipeline orchestration module."""

