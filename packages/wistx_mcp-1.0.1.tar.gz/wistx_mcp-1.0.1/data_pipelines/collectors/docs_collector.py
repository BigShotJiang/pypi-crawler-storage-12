"""Documentation collector."""

# TODO: Implement docs collector

