"""Configuration module for data pipelines."""

from data_pipelines.config.compliance_urls import COMPLIANCE_URLS

__all__ = ["COMPLIANCE_URLS"]

