"""Internal admin endpoints."""

from api.routers.internal import webhooks

__all__ = ["webhooks"]

