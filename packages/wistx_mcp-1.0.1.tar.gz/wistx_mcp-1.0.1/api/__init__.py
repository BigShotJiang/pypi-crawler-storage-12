"""WISTX API - Main FastAPI application."""

__version__ = "0.1.0"

