"""
Tidewave for Python (Django, Flask, and FastAPI)
"""

__version__ = "0.1.0"
