.. _dataset_info:

.. module:: mlip.data.dataset_info

Dataset Info
============

.. autoclass:: DatasetInfo

    .. automethod:: __init__

.. autofunction:: compute_dataset_info_from_graphs
