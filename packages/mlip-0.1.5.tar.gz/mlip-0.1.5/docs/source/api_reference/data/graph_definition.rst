.. _graph_definition:

.. module:: mlip.typing.graph_definition

Graph Definition
================

.. autoclass:: GraphNodes

.. autoclass:: GraphEdges

.. autoclass:: GraphGlobals
