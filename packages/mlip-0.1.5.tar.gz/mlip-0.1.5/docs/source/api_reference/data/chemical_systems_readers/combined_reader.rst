.. _combined_reader:

.. module:: mlip.data.chemical_systems_readers.combined_reader

Combined Reader
===============

.. autoclass:: CombinedReader

    .. automethod:: __init__

    .. automethod:: load
