.. _dataset_configs:

.. module:: mlip.data.configs

Dataset Configs
===============

.. autoclass:: ChemicalSystemsReaderConfig

.. autoclass:: GraphDatasetBuilderConfig
