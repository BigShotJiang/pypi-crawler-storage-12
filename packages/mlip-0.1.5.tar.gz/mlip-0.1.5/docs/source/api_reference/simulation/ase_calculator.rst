.. _ase_calculator:

MLIP ASE Calculator
===================

.. module:: mlip.simulation.ase.mlip_ase_calculator

    .. autoclass:: MLIPForceFieldASECalculator

            .. automethod:: __init__

            .. automethod:: calculate


.. module:: mlip.utils.no_pbc_cell

    .. autofunction:: get_no_pbc_cell
