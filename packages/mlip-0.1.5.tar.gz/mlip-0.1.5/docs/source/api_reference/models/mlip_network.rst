.. _mlip_network:

MLIP Network: Base Class
========================

.. module:: mlip.models.mlip_network

    .. autoclass:: MLIPNetwork

        .. automethod:: __call__
