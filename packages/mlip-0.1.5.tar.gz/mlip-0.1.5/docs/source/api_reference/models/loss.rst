.. _loss:

.. module:: mlip.models.loss

Loss
====

.. autoclass:: Loss

    .. automethod:: __call__

.. autoclass:: WeightedEFSLoss

    .. automethod:: __init__

    .. automethod:: __call__

.. autoclass:: MSELoss

    .. automethod:: __init__

    .. automethod:: __call__

.. autoclass:: HuberLoss

    .. automethod:: __init__

    .. automethod:: __call__
