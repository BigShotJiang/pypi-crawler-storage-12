"""I/O subpackage for saving and loading Pastas models."""

# ruff: noqa: F401
from .base import dump, load
