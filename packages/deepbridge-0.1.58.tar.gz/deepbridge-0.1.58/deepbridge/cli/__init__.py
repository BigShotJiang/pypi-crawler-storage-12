"""
Command Line Interface for DeepBridge.
"""

from deepbridge.cli.commands import app

__all__ = ["app"]