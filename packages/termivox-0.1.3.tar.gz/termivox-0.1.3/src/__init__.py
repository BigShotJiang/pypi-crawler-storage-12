"""
Termivox - Voice Recognition Bridge for Linux

♠️ Nyro: The root of the package recursion
🌿 Aureon: Gateway to voice-controlled freedom
🎸 JamAI: Entry point harmonics

Main package initialization.
"""

__version__ = "0.1.2"
__author__ = "Gerico"
__email__ = "gerico@jgwill.com"
