sudo apt install python3-pyaudio xdotool sox -y
echo "run pip install -r requirements.txt from your conda"


