"""LangChain integration."""

from typing import Any

from toonverter.core.exceptions import ConversionError
from toonverter.core.types import DecodeOptions, EncodeOptions
from toonverter.decoders import decode
from toonverter.encoders import encode


# Optional dependency
try:
    from langchain.schema import Document

    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False
    Document = Any  # type: ignore


def langchain_to_toon(document: "Document", options: EncodeOptions | None = None) -> str:
    """Convert LangChain Document to TOON format.

    Args:
        document: LangChain Document instance
        options: Encoding options

    Returns:
        TOON format string

    Raises:
        ImportError: If langchain is not installed
        ConversionError: If conversion fails

    Examples:
        >>> from langchain.schema import Document
        >>> doc = Document(page_content="Hello", metadata={"source": "test.txt"})
        >>> toon_str = langchain_to_toon(doc)
    """
    if not LANGCHAIN_AVAILABLE:
        msg = "langchain is required. Install with: pip install toon-converter[integrations]"
        raise ImportError(msg)

    try:
        data = {"page_content": document.page_content, "metadata": document.metadata}
        return encode(data, options)
    except Exception as e:
        msg = f"Failed to convert LangChain Document to TOON: {e}"
        raise ConversionError(msg) from e


def toon_to_langchain(toon_str: str, options: DecodeOptions | None = None) -> "Document":
    """Convert TOON format to LangChain Document.

    Args:
        toon_str: TOON format string
        options: Decoding options

    Returns:
        LangChain Document instance

    Raises:
        ImportError: If langchain is not installed
        ConversionError: If conversion fails

    Examples:
        >>> toon_str = "{page_content:Hello,metadata:{source:test.txt}}"
        >>> doc = toon_to_langchain(toon_str)
    """
    if not LANGCHAIN_AVAILABLE:
        msg = "langchain is required. Install with: pip install toon-converter[integrations]"
        raise ImportError(msg)

    try:
        data = decode(toon_str, options)
        if isinstance(data, dict):
            page_content = data.get("page_content", "")
            metadata = data.get("metadata", {})
            return Document(page_content=page_content, metadata=metadata)
        msg = "TOON data must be a dictionary with page_content and metadata"
        raise ConversionError(msg)
    except Exception as e:
        msg = f"Failed to convert TOON to LangChain Document: {e}"
        raise ConversionError(msg) from e
