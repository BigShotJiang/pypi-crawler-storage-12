"""Version information for TOON Converter."""

__version__ = "1.0.0"
__author__ = "TOON Converter Contributors"
__license__ = "MIT"
