from setuptools import setup

# NOTE: setup configuration is defined in pyproject.toml
setup()
