# Namespace package for directive modules. Each module should expose `setup(app)`.
