AttenuationOneAirMassMag: float = 0.28
AttenuationOneAirMass: float = 0.77268
MagnitudeOneWattPerSquareMetre: float = -18.9
