"""
Rerank configuration module
"""
from .base import BaseRerankConfig

__all__ = ["BaseRerankConfig"]

