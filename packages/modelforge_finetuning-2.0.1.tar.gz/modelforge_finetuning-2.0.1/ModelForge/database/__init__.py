"""
Database module for ModelForge.
Provides SQLAlchemy-based database access with connection pooling.
"""
