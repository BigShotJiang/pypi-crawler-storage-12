import flaskteroids.cache.inmemory as inmemory


def get_cache():
    return inmemory
