"""Initializes the Pirate Weather library."""

# ruff: noqa: F401

from pirateweather.api import load_forecast, manual
