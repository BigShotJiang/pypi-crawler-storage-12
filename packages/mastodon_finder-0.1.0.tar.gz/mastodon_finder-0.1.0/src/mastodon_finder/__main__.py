# mastodon_finder/__main__.py

from __future__ import annotations

from mastodon_finder.finder import main

if __name__ == "__main__":
    main()
