# Python-Ort

Python-Ort is a pydantic based library to serialize OSS Review Toolkit generated reports using the default models.
