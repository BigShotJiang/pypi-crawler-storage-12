*********
exovetter
*********

``exovetter`` is a Python package for exoplanet vetting.

.. toctree::
  :maxdepth: 2

  install
  vetters
  vetters_low_level
  utils
