Licenses
========

For package license, see ``LICENSE.rst`` in the root directory.

This directory holds credit information for the package,
works the package is derived from, and/or datasets.
