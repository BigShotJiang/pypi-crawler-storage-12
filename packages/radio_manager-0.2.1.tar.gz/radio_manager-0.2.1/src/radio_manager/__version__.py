"""Version information for radio-manager."""

__version__ = "0.2.1"
