__version__ = "1.5.0"

__all__ = ["__version__", "CVectorBus"]

from can_cvector.cvector import CVectorBus
