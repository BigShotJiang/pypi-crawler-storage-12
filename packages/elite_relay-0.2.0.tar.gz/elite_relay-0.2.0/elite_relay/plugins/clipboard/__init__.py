from .plugin import ClipboardPlugin
