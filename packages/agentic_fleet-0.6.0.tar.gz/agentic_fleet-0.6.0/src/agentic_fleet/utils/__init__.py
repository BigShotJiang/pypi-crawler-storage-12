"""Utilities package: compiler, config loader, logging, and tool registry."""
