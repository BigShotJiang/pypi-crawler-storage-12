"""DSPy module package: signatures and supervisor wrappers."""
