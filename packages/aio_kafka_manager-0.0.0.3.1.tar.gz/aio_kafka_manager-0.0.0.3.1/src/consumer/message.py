from pydantic import BaseModel
from typing import Any, Optional


class KafkaMessage(BaseModel):
    data: Any
    topic: Optional[str]
    partition: Optional[int]
    offset: Optional[int]
    consumer_id: Optional[str]
    instance_index: Optional[int]
