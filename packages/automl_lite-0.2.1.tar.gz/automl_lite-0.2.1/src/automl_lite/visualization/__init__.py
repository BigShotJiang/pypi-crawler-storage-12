"""Visualization and reporting for AutoML Lite."""

from .reporter import ReportGenerator

__all__ = ["ReportGenerator"] 