"""Model selection and management for AutoML Lite."""

from .selector import ModelSelector

__all__ = ["ModelSelector"] 