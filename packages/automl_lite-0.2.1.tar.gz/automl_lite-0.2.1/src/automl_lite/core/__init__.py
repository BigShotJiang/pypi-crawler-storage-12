"""Core AutoML functionality."""

from .automl import AutoMLite

__all__ = ["AutoMLite"] 