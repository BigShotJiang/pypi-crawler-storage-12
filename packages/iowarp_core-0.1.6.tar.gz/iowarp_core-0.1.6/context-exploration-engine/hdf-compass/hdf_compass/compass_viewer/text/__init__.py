from __future__ import absolute_import, division, print_function, unicode_literals

from .frame import TextFrame, XmlFrame

import logging
log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())
