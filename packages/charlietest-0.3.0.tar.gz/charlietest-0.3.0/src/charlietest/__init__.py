"""brain_test 包：演示 src 布局与简单导出。"""

__all__ = ["greet"]
__version__ = "0.1.0"

def greet(name: str) -> str:
    return f"Hello, {name}!"

