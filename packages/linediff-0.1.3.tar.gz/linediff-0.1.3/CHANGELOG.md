# Changelog
All notable changes to this project will be documented here.

## [0.1.3] - 2025-11-15

- TODO: describe the changes for 0.1.3

## [0.1.2] - 2025-11-15

- TODO: describe the changes for 0.1.2

## [0.1.1] - 2025-11-15

- TODO: describe the changes for 0.1.1
