
# versapy

### The python module versapy is the main part of the [Versapy](https://github.com/Soli-64/VersaPy) project.

## <u> About </u>

#### This module manages backend server using FastAPI, Uvicorn and Sokectio. <br/> It reads configs, and bundle the app using PyWebVIew. <br/> The Building functionnality is only available on Windows for now. 

## <u> Usage </u>

#### This module is auto-installed in your project by the cli [create-versapy](https://github.com/Soli-64/VersaPy/tree/main/cli) while creating your versapy app. <br/> See the [github repo](https://github.com/Soli-64/VersaPy) for more infos and exemples.