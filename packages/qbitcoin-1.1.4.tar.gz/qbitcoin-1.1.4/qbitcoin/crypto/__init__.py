# coding=utf-8
# Python hash signature library (quantum resistant)
