Public Key (897 bytes) 
    ↓ 
SHA-256 Hash (32 bytes)
    ↓
RIPEMD-160 Hash (20 bytes)
    ↓
Add Address Type Prefix (0x01) → 21 bytes total
    ↓
Calculate Checksum (double SHA-256, first 4 bytes)
    ↓
Final Binary Address (25 bytes total)
    ↓
Convert to Hex and add 'Q' prefix

this is the  process of how addres in gentig i qbitcoin 