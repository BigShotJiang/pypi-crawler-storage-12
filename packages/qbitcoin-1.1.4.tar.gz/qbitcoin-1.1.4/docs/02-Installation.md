7# Installation Guide

This guide will walk you through installing Qbitcoin on different operating systems.

##  using pip 
''' bash 
pip install qbitcoin
'''
then install depends 
run smart installer 
python -m qbitcoin.smart_installer
