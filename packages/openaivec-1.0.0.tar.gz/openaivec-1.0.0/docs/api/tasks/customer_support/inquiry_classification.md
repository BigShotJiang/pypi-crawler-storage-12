# Inquiry Classification

::: openaivec.task.customer_support.inquiry_classification
