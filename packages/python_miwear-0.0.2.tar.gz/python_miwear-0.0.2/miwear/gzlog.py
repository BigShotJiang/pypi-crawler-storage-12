#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
#
# Copyright (C) 2025 Junbo Zheng. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import os
import gzip
import argparse
import sys
import re

try:
    from miwear import __version__
except ImportError:
    __version__ = "0.0.1"


def is_gz_not_targz(filename):
    return filename.endswith(".gz") and not filename.endswith(".tar.gz")


def extract_number(filename):
    """从文件名中提取数字，用于排序"""
    # 匹配文件名中的所有数字
    numbers = re.findall(r"\d+", filename)
    if numbers:
        # 返回最后一个数字（假设数字在扩展名之前）
        return int(numbers[-1])
    # 如果没有数字，返回一个很大的数，让它们排在后面
    return float("inf")


def natural_sort_key(filename):
    """自然排序键，支持数字在文件名任意位置"""
    filename = os.path.basename(filename)
    # 将数字部分和非数字部分分开
    parts = re.split(r"(\d+)", filename)
    # 将数字部分转换为整数，非数字部分保持原样
    return [int(part) if part.isdigit() else part.lower() for part in parts]


def get_sorted_gz_files(directory):
    """获取目录中所有.gz文件并按自然顺序排序"""
    gz_files = []

    for root, dirs, files in os.walk(directory):
        for file in files:
            if is_gz_not_targz(file):
                gz_files.append(os.path.join(root, file))

    # 使用自然排序
    gz_files.sort(key=natural_sort_key)
    return gz_files


def run(directory, log_file, output_file):
    # 获取排序后的.gz文件列表
    gz_files = get_sorted_gz_files(directory)

    if not gz_files:
        print(f"在目录 {directory} 中没有找到.gz文件")
        return

    print("找到以下文件并按顺序处理:")
    for i, file_path in enumerate(gz_files, 1):
        print(f"{i}. {os.path.basename(file_path)}")

    with open(output_file, "wb") as merged_file:
        # 按顺序处理每个.gz文件
        for gz_file_path in gz_files:
            try:
                with gzip.open(gz_file_path, "rb") as f_in:
                    decompressed_data = f_in.read()
                merged_file.write(decompressed_data)
                print(f"文件 {os.path.basename(gz_file_path)} 解压并合并成功......")
            except Exception as e:
                print(f"处理文件 {gz_file_path} 时出错: {e}")

        # 合并日志文件
        if os.path.isfile(log_file):
            try:
                with open(log_file, "rb") as tmp_log:
                    merged_file.write(tmp_log.read())
                print(f"文件 {log_file} 已合并...")
            except Exception as e:
                print(f"合并日志文件 {log_file} 时出错: {e}")
        else:
            print(f"日志文件 {log_file} 不存在，跳过")

    print(f"成功完成！所有文件已按顺序合并到 {output_file} ...")


def main():
    parser = argparse.ArgumentParser(
        description="both .gz file and the log file will be unzip and merged"
    )
    parser.add_argument(
        "--version", action="store_true", help="Show miwear_gzlog version and exit."
    )

    parser.add_argument(
        "--log_file",
        type=str,
        default="tmp.log",
        help="specify the log file to be merged, tmp.log is used by default",
    )
    parser.add_argument(
        "--output_file",
        type=str,
        default="output.log",
        help="specify the name of the output file, output.log is used by default",
    )
    parser.add_argument(
        "--path",
        type=str,
        default=".",
        help="specify the directory to search, current directory by default",
    )

    args = parser.parse_args()
    if args.version:
        print(f"miwear_gzlog version: {__version__}")
        sys.exit(0)

    run(args.path, args.log_file, args.output_file)


if __name__ == "__main__":
    main()
