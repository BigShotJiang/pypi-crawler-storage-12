"""Operations-focused prompt templates."""

