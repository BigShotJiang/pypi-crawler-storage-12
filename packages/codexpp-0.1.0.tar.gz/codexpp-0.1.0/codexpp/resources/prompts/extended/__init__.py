"""Extended prompt templates."""

