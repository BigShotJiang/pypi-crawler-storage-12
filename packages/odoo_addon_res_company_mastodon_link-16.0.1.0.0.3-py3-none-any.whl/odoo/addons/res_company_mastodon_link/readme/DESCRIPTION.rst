This module adds a new "Mastodon URL" field, at company level.

Mastodon is a decentralized social network developed in Open Source.
More information at https://joinmastodon.org/.
