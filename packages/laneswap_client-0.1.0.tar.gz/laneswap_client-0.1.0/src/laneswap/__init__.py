"""
LaneSwap Client - Effortless LaneSwap Monitor integration for Python services.

This library reduces LaneSwap integration from 50+ lines of boilerplate
to just 5-10 lines with a simple decorator-based API.

Basic usage:
    >>> from laneswap import LaneSwap
    >>> from flask import Flask
    >>>
    >>> app = Flask(__name__)
    >>> laneswap = LaneSwap(app)
    >>>
    >>> @laneswap.health_check
    ... def check_database():
    ...     return {"database": "connected"}
    >>>
    >>> @laneswap.on_shutdown
    ... def cleanup():
    ...     db.close()

For more examples, see:
    - https://github.com/laneswap/laneswap-client/tree/main/examples
    - https://laneswap-client.readthedocs.io
"""

from .core import LaneSwap
from .health import HealthCheckRegistry, build_health_response
from .utils import get_logger, get_port, get_service_name, setup_logging

__version__ = "0.1.0"
__all__ = [
    "LaneSwap",
    "HealthCheckRegistry",
    "build_health_response",
    "get_logger",
    "get_port",
    "get_service_name",
    "setup_logging",
]
