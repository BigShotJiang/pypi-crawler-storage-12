"""
Framework integrations for LaneSwap client.

This package provides integrations for popular Python web frameworks:
- Flask
- FastAPI
- Django (future)
"""

__all__ = ["setup_flask_integration", "setup_fastapi_integration"]
