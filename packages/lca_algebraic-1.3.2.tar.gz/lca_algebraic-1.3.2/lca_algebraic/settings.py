# This module holds global settings
class Settings:
    cache_enabled = True
    units_enabled = False
