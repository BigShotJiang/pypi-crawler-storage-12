"""
Version information for PAB CLI
"""

__version__ = "0.2.2"
