"""Analysis tools for NEB calculations, including pathway analysis."""
