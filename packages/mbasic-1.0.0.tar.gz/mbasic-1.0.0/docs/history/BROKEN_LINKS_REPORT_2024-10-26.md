Found 135 markdown files

Total links found: 429
Broken links: 25

================================================================================
BROKEN LINKS:
================================================================================

In: common/getting-started.md
  [Curses UI] -> ui/curses/editing.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/common/ui/curses/editing.md)
  [Tkinter UI] -> ui/tk/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/common/ui/tk/index.md)
  [CLI] -> ui/cli/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/common/ui/cli/index.md)
  [Variables and Data Types] -> language/data-types.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/common/language/data-types.md)
  [IF-THEN-ELSE] -> language/statements/if-then.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/common/language/statements/if-then.md)
  [Hello World Example] -> examples/hello-world.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/common/examples/hello-world.md)
  [Loop Examples] -> examples/loops.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/common/examples/loops.md)

In: common/language/appendices/ascii-codes.md
  [Character Set] -> ../character-set.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/common/language/character-set.md)

In: common/language/functions/peek.md
  [RANDOMIZE] -> randomize.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/common/language/functions/randomize.md)

In: common/language/operators.md
  [Data Types] -> data-types.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/common/language/data-types.md)

In: mbasic/architecture.md
  [Not Implemented] -> not-implemented.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/mbasic/not-implemented.md)
  [Language Reference] -> ../language/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/language/index.md)

In: mbasic/compatibility.md
  [Language Reference] -> ../language/statements/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/language/statements/index.md)

In: mbasic/features.md
  [Language Reference] -> ../language/statements/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/language/statements/index.md)

In: mbasic/getting-started.md
  [Language Reference] -> ../language/statements/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/language/statements/index.md)
  [Language Reference] -> ../language/statements/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/language/statements/index.md)

In: ui/curses/files.md
  [BASIC Language Reference] -> ../../language/statements/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/language/statements/index.md)

In: ui/curses/getting-started.md
  [Getting Started with BASIC] -> ../../getting-started.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/getting-started.md)
  [BASIC Statements] -> ../../language/statements/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/language/statements/index.md)

In: ui/curses/help-navigation.md
  [this] -> link
    (resolved to: /home/wohl/cl/mbasic/docs/help/ui/curses/link)
  [Getting Started] -> ../../getting-started.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/getting-started.md)
  [Statements] -> ../../language/statements/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/language/statements/index.md)
  [Functions] -> ../../language/functions/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/language/functions/index.md)

In: ui/curses/running.md
  [BASIC Language Reference] -> ../../language/statements/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/language/statements/index.md)
  [BASIC Statements] -> ../../language/statements/index.md
    (resolved to: /home/wohl/cl/mbasic/docs/help/language/statements/index.md)

================================================================================
MISSING FILES (unique):
================================================================================
  /home/wohl/cl/mbasic/docs/help/common/examples/hello-world.md
  /home/wohl/cl/mbasic/docs/help/common/examples/loops.md
  /home/wohl/cl/mbasic/docs/help/common/language/character-set.md
  /home/wohl/cl/mbasic/docs/help/common/language/data-types.md
  /home/wohl/cl/mbasic/docs/help/common/language/functions/randomize.md
  /home/wohl/cl/mbasic/docs/help/common/language/statements/if-then.md
  /home/wohl/cl/mbasic/docs/help/common/ui/cli/index.md
  /home/wohl/cl/mbasic/docs/help/common/ui/curses/editing.md
  /home/wohl/cl/mbasic/docs/help/common/ui/tk/index.md
  /home/wohl/cl/mbasic/docs/help/getting-started.md
  /home/wohl/cl/mbasic/docs/help/language/functions/index.md
  /home/wohl/cl/mbasic/docs/help/language/index.md
  /home/wohl/cl/mbasic/docs/help/language/statements/index.md
  /home/wohl/cl/mbasic/docs/help/mbasic/not-implemented.md
  /home/wohl/cl/mbasic/docs/help/ui/curses/link

Total missing files: 15
