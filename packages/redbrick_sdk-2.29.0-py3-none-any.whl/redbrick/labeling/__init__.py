"""Module for interacting with labeling stages."""

from .public import LabelingImpl
