Subcommands
===========

In these examples, we show how :func:`tyro.cli` can be used to create CLI
interfaces with subcommands.
