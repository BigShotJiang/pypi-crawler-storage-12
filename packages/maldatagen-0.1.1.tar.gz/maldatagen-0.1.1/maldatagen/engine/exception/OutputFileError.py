class OutputFileError(Exception):
    pass