class DirectoryCreationError(OSError):
    """Custom exception for directory creation errors."""
