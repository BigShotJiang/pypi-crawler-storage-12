class InvalidParameterError(Exception):
    pass