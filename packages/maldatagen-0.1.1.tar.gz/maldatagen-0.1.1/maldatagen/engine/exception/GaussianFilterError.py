class GaussianFilterError(Exception):
    pass