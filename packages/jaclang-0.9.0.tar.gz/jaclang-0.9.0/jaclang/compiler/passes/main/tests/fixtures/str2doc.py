def foo():
    """This is a test function."""
    return "Hello, World!"
