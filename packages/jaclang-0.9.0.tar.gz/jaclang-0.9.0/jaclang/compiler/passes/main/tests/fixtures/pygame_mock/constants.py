CONST_VALUE: int = 0


class CL:
    CONST_VALUE2: str = "h"
