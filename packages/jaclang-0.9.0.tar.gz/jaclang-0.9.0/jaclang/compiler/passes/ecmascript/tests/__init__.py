"""Tests for ECMAScript AST generation."""
