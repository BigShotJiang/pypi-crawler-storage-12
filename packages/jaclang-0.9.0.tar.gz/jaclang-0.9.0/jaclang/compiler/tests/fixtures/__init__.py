"""Various fixtures for testing."""
