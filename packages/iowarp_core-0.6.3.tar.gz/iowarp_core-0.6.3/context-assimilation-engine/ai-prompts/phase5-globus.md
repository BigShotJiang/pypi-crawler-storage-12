@CLAUDE.md

Based on glo.cc, let's build a globus assimilator.

This assimilator will only support local filesystem or another globus as its destination.

Look at the existing code to see how to accomplish this.


