@CLAUDE.md Let's change the blocking strategy for wait, mutex, and corwlock.

Let's have 4 queues instead of 2. Store them in an array. 

T
