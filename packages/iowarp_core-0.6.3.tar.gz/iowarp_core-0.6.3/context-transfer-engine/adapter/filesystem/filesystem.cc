#include "filesystem_mdm.h"

namespace wrp::cae {

// Define global pointer variable in source file
HSHM_DEFINE_GLOBAL_PTR_VAR_CC(MetadataManager, g_fs_metadata_manager);

} // namespace wrp::cae