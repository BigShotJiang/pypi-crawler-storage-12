# For pyside6-deploy and the debugger.
from src.avoc.main import main

if __name__ == "__main__":
    main()
