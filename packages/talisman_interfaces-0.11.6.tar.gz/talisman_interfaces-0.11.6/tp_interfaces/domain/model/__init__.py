__all__ = [
    'DomainModel'
]

from ._model import DomainModel
