# ij
Idea Junction - Connect of vague ideas and evolve them to fully functional systems
