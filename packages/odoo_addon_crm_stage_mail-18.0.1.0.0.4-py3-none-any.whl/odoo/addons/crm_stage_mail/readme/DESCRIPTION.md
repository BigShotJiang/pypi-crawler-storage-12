This module allows you to specify an email template for each stage so
that when you change stages, an email is sent using that template.
