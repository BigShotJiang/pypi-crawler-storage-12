- Define a template (Welcome Demo, for example) in a stage (Qualified,
  for example).
- Change a lead to the stage defined in the previous point.
- An email will be sent to the lead's partner.
