# This file is deprecated and will be removed in a future release

from ..Tools.Subdivision import suggest_subdivisions  # noqa: F401
