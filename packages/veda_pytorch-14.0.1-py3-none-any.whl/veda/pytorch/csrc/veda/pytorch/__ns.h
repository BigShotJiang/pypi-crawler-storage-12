#ifndef __VEDA_PYTORCH_NS
#define __VEDA_PYTORCH_NS
namespace veda {
	namespace pytorch {
#else
#undef __VEDA_PYTORCH_NS
	}
}
#endif