def autoload(): # nothing special to do
	pass