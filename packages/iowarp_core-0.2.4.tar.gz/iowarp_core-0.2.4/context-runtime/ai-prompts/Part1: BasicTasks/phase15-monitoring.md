@CLAUDE.md We want to have lightweight models to estimate the time it will take to execute a task.
This can help with load balancing decisions.

