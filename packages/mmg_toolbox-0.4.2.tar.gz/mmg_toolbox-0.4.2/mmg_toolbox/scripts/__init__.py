"""
mmg Scripts
"""

from .scripts import create_script, create_notebook

__all__ = ['create_script','create_notebook']

