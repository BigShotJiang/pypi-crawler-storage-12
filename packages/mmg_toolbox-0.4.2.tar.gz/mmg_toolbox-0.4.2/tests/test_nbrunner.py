"""
Test nbrunner
"""

# from mmg_toolbox.utils.nb_runner import process_template, view_jupyter_notebook
#
#
# template = '/dls_sw/i06/scripts/gda-zocalo/notebooks/xas_notebook.ipynb'
# nx_file = '/dls/i10-1/data/2025/cm40624-2/i10-1-26825.nxs'
# out = None #'/scratch/grp66007/'
#
# ipynb, html = process_template(template, nx_file, out)
#
# view_jupyter_notebook(html)

