"""ZSXQ MCP Server - MCP server for publishing content to Zhishixingqiu (知识星球)"""

__version__ = "0.2.0"
