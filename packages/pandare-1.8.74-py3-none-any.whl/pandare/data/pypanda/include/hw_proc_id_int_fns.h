
target_ulong get_id(CPUState *cpu);

bool id_is_initialized(void);

