"""Version information for Neuron CLI"""

__version__ = "1.0.25"  # SAN CLI (SPACE Agent Neuron CLI) - Phase 7: Auto-Update Complete
__author__ = "Kai Gartner (https://linkedin.com/in/kaigartner)"
__license__ = "Commercial - All Rights Reserved"
