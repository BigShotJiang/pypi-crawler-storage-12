"""Hardware detection module"""

from .detector import HardwareDetector

__all__ = ["HardwareDetector"]
