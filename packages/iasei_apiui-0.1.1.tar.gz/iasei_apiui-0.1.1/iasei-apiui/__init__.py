default_app_config = "django_vue_swagger.apps.VueSwaggerConfig"
