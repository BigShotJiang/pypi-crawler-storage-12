"""Initalization of the mcp_this package."""

from .mcp_server import render_template  # noqa: F401
