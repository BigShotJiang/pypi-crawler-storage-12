from bluer_objects.README.consts import assets_url

assets2_fire = assets_url(
    suffix="fire",
    volume=2,
)
