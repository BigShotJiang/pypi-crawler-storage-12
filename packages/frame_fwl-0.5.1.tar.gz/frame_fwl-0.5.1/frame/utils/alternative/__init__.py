'''
WARNING: This module modifies Python builtins.
Use only when extreme precision is required.
May break compatibility with other libraries.


Modules:
    - alt_math - alternative math
'''