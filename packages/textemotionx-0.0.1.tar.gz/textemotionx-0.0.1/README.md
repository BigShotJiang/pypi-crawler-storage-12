# TextEmotionX

A simple python package to detect emotions from text.
