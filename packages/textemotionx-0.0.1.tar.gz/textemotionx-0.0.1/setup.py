from setuptools import setup, find_packages

setup(
    name="textemotionx",
    version="0.0.1",
    packages=find_packages(),
    install_requires=[],
    author="Shawn Mendes",
    description="A simple emotion analysis tool",
)
