"""Version information for the OpenAI SSE plugin."""

__version__ = "0.1.0"
