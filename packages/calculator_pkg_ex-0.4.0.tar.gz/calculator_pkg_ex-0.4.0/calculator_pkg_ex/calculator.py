class Calculator:
    def __init__(self):
        print("hello!")
    def add(self, a, b):
        return a + b
    def subtract(self, a, b):
        return a - b
    def multiple(self, a, b):
        return a * b
    def divide(self, a, b):
        return a / b
