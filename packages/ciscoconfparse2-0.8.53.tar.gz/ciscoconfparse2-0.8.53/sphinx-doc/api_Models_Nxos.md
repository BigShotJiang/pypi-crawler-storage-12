(models-nxos)=

# ciscoconfparse2.models_nxos

```{eval-rst}
.. autoclass:: ciscoconfparse2.models_nxos.NXOSCfgLine
   :members:
   :undoc-members:
   :inherited-members:
```

```{eval-rst}
.. autoclass:: ciscoconfparse2.models_nxos.NXOSIntfLine
   :members:
   :undoc-members:
   :inherited-members:
```
