(ccp-abc)=

# ccp_abc functions

```{eval-rst}
.. autofunction:: ciscoconfparse2.ccp_abc.get_brace_termination
```

# ciscoconfparse2.ccp_abc

```{eval-rst}
.. autoclass:: ciscoconfparse2.ccp_abc.BaseCfgLine
   :members:
   :undoc-members:
   :inherited-members:
```
