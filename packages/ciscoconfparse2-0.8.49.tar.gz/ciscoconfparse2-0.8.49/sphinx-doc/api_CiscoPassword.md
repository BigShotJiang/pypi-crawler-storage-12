(cisco-password)=

# ciscoconfparse2.CiscoPassword

```{eval-rst}
.. autoclass:: ciscoconfparse2.CiscoPassword
   :members:
   :undoc-members:
   :inherited-members:
```
