# {{ name }}

## getting started

```bash
cd /path/to/{{ name }}
make setup
```