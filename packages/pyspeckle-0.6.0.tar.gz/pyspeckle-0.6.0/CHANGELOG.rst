Changelog
=========

0.6.0
------
* jupyterlite support
* modernize packaging
* modernize github actions
* use pyproject.toml only
* improve docstrings
* use ruff for linting
* add requirements-dev.txt
* use venv for reproducibility

0.5.1
------
* attempt to fix images on pypi.org

0.5.0
------
* drop 'v' from version tags
* add testing
* add conda support
* add github automated testing
* improve CITATION.cff
* create zenodo DOI
* add github automated version updates

v0.4.1
------
* add slice_plot() for 3D speckle
* create pure python packaging
* include wheel file
* package as python3 only

v0.4.0
------
* 3D speckle generation
* flake8 testing
* add pypi badge
* automate notebook testing

v0.3.2
------
* add badges for colab and binder
* sphinx-book-theme for docs
* cite SPIE paper
* improve README.rst

v0.3.1
------
* improve api generation using automodapi

v0.3.0
------
* use sphinx for documentation
* implement create_gaussian_1D()
* improve documentation

v0.2.0
------
*  rename functions and doc files

v0.1.0
------
*  initial checkin
