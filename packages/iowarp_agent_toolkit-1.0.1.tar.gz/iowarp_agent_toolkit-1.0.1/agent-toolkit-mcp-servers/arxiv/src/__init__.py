"""
ArXiv MCP Server
A Model Context Protocol server for fetching research papers from ArXiv.
"""
