"""
Plot MCP Server Package
"""

__version__ = "0.1.0"
__author__ = "IoWarp Scientific MCPs"
