"""Tests for lmod-mcp."""
