git\_autograder.answers package
===============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   git_autograder.answers.rules

Submodules
----------

git\_autograder.answers.answers module
--------------------------------------

.. automodule:: git_autograder.answers.answers
   :members:
   :show-inheritance:
   :undoc-members:

git\_autograder.answers.answers\_parser module
----------------------------------------------

.. automodule:: git_autograder.answers.answers_parser
   :members:
   :show-inheritance:
   :undoc-members:

git\_autograder.answers.answers\_record module
----------------------------------------------

.. automodule:: git_autograder.answers.answers_record
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: git_autograder.answers
   :members:
   :show-inheritance:
   :undoc-members:
