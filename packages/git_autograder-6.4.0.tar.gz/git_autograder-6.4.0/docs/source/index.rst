git-autograder documentation
============================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   :glob:

   git_autograder*

