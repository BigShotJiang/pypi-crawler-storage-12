# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.

__version__ = "1.9.0"
