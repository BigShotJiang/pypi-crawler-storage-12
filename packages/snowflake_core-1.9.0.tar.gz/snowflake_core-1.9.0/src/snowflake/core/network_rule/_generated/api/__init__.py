from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from snowflake.core.network_rule._generated.api.network_rule_api import NetworkRuleApi

__all__ = [
    "NetworkRuleApi",
]
