from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from snowflake.core.network_policy._generated.api.network_policy_api import NetworkPolicyApi

__all__ = [
    "NetworkPolicyApi",
]
