from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from snowflake.core.cortex.search_service._generated.api.cortex_search_service_api import CortexSearchServiceApi

__all__ = [
    "CortexSearchServiceApi",
]
