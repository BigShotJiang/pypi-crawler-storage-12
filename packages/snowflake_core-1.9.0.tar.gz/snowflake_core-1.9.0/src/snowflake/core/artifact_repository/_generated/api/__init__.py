from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from snowflake.core.artifact_repository._generated.api.artifact_repository_api import ArtifactRepositoryApi

__all__ = [
    "ArtifactRepositoryApi",
]
