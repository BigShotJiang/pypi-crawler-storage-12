from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from snowflake.core.catalog_integration._generated.api.catalog_integration_api import CatalogIntegrationApi

__all__ = [
    "CatalogIntegrationApi",
]
