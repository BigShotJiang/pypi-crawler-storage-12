"""Templates command."""

from .command import templates_command

__all__ = ["templates_command"]
