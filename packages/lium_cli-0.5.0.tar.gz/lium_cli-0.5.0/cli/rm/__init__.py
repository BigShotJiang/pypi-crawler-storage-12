"""Remove (rm) command."""

from .command import rm_command

__all__ = ["rm_command"]
