"""Rsync command."""

from .command import rsync_command

__all__ = ["rsync_command"]
