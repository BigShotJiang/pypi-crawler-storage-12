# -*- coding: utf-8 -*-
"""
因子计算模块
"""
from .technical import BasicFactors

__all__ = ['BasicFactors']

