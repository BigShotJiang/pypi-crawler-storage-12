from .geondpt import (
	Paraboloid,
	ParaConv2d,
)
from .pytorch import (
	GeoNDSGD,
)

