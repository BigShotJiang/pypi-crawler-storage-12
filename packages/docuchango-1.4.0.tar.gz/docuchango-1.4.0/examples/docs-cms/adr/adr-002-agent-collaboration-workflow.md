---
id: adr-002
title: Define Agent Collaboration Workflow with docs-cms
status: Accepted
date: 2025-10-27
deciders: Project Team and AI Agents
tags: [architecture, ai-agents, workflow, collaboration]
project_id: example-project
doc_uuid: 7c9e6679-7425-40de-944b-e07fc1f90ae7
---
