MORE_THAN_HALF = "more_than_half"
NEARLY_EVERYDAY = "nearly_everyday"
NOT_AT_ALL = "not_at_all"
SEVERAL_DAYS = "several_days"
