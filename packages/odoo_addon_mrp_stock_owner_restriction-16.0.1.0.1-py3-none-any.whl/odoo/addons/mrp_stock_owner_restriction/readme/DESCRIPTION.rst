This module adapts the functionality of stock_owner_restriction in the manufacturing
order.
