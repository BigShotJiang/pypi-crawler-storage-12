An unbuild order not linked to a manufacturing order will not utilize the functionality of the stock_owner_restriction module.
