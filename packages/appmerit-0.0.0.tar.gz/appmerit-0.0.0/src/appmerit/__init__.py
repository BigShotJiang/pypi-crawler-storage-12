def main() -> None:
    print("Hello from appmerit!")
