
Integration Tests: Timing Results
#################################


Comparison against baseline (last 10 entries)
=============================================


`View chart 1 <https://charts.mongodb.com/charts-project-0-gvldi/embed/charts?id=706f9e2a-90f6-42b5-8974-dc957c3171ed>`_

.. raw:: html

	<iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="100%" height="480" src="https://charts.mongodb.com/charts-project-0-gvldi/embed/charts?id=706f9e2a-90f6-42b5-8974-dc957c3171ed&maxDataAge=3600&theme=light&autoRefresh=true"></iframe>

Elapsed time (last 10 entries)
==============================


`View chart 2 <https://charts.mongodb.com/charts-project-0-gvldi/embed/charts?id=6644da54-276c-4aa7-8eb7-ef1a23a5f07d>`_

.. raw:: html

	<iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="100%" height="480" src="https://charts.mongodb.com/charts-project-0-gvldi/embed/charts?id=6644da54-276c-4aa7-8eb7-ef1a23a5f07d&maxDataAge=3600&theme=light&autoRefresh=true"></iframe>

Historical results
==================


`View chart 3  <https://charts.mongodb.com/charts-project-0-gvldi/embed/charts?id=bba0cbbd-6171-4bcf-8c31-5fda3c7bec89>`_

.. raw:: html

	<iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="100%" height="480" src="https://charts.mongodb.com/charts-project-0-gvldi/embed/charts?id=bba0cbbd-6171-4bcf-8c31-5fda3c7bec89&maxDataAge=3600&theme=light&autoRefresh=true"></iframe>

