# walutomat-py

A Python library for the Walutomat.pl API.

## Installation

```bash
pip install walutomat-py
```

## Usage

```python
# To be implemented
```

## Contributing

Contributions are welcome! Please open an issue or submit a pull request.

## License

This project is licensed under the MIT License.
