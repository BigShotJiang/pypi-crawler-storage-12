__title__ = "brachinus"
__author__ = "Juan Bindez"
__license__ = "GPLv2 License"
__js__ = None
__js_url__ = None

from brachinus.version import __version__
from brachinus.__main__ import AES256
from brachinus.__main__ import encrypt_file_with_password, decrypt_file_with_password