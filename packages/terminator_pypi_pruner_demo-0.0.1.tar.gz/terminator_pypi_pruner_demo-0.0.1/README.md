# terminator-pypi-pruner-demo

This package only exists so we can test Terminator's PyPI cleanup workflow.
