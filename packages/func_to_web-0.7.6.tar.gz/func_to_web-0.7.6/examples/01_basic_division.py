from func_to_web import run


def divide(a: int, b: int):
    """Simple division of two numbers"""
    return a / b

run(divide)