from .StickersDownloader import TelegramStickerDownloader

__version__ = "1.0.0"
__all__ = ["TelegramStickerDownloader"]
