import os
import aiohttp
import asyncio
from rlottie_python import LottieAnimation
from urllib.parse import urlparse
from typing import List
from rich.progress import Progress, BarColumn, TextColumn, TimeRemainingColumn
from rich.console import Console
from rich.prompt import Prompt, Confirm

console = Console()

class TelegramStickerDownloader:
    def __init__(self, token: str, sticker_pack_link: str):
        self.token = token
        self.sticker_pack_link = sticker_pack_link
        self.sticker_set = self._extract_sticker_set()
        self.tgs_dir = f"tgs/{self.sticker_set}_Stickers"
        self.gif_dir = f"{self.sticker_set}_GIFs"
        os.makedirs(self.tgs_dir, exist_ok=True)
        os.makedirs(self.gif_dir, exist_ok=True)

    def _extract_sticker_set(self):
        parsed = urlparse(self.sticker_pack_link)
        return parsed.path.split('/')[-1]

    @staticmethod
    async def retry_request(func, *args, retries=3, delay=2, **kwargs):
        for attempt in range(1, retries + 1):
            try:
                return await func(*args, **kwargs)
            except aiohttp.ClientResponseError as e:
                if e.status == 403:
                    console.print(f"[red]⚠ Attempt {attempt}: Access denied (403). Check VPN.[/red]")
                else:
                    console.print(f"[red]⚠ Attempt {attempt}: {e}[/red]")
            except (aiohttp.ClientConnectorError, asyncio.TimeoutError) as e:
                console.print(f"[red]⚠ Attempt {attempt}: Network error: {e}[/red]")

            if attempt < retries:
                await asyncio.sleep(delay)
        raise Exception(f"[red]Failed after {retries} attempts[/red]")

    
    async def fetch_sticker_set_info(self, session: aiohttp.ClientSession):
        async def inner():
            url = f"https://api.telegram.org/bot{self.token}/getStickerSet?name={self.sticker_set}"
            async with session.get(url, timeout=10) as resp:
                if resp.status == 403:
                    raise aiohttp.ClientResponseError(
                        request_info=resp.request_info,
                        history=resp.history,
                        status=403,
                        message="Forbidden",
                        headers=resp.headers
                    )
                res = await resp.json()
                if not res.get("ok"):
                    raise Exception("Failed to get sticker set info")
                return res["result"]["stickers"]
        return await TelegramStickerDownloader.retry_request(inner)

    async def download_file(self, session: aiohttp.ClientSession, file_id: str, save_path: str):
        async def inner():
            url = f"https://api.telegram.org/bot{self.token}/getFile?file_id={file_id}"
            async with session.get(url, timeout=10) as resp:
                if resp.status == 403:
                    raise aiohttp.ClientResponseError(
                        request_info=resp.request_info,
                        history=resp.history,
                        status=403,
                        message="Forbidden",
                        headers=resp.headers
                    )

                res = await resp.json()
                if not res.get("ok"):
                    raise Exception(f"Failed to get file info for {file_id}")
                file_path = res["result"]["file_path"]

            download_url = f"https://api.telegram.org/file/bot{self.token}/{file_path}"
            async with session.get(download_url, timeout=10) as r:
                content = await r.read()
                with open(save_path, "wb") as f:
                    f.write(content)
        return await TelegramStickerDownloader.retry_request(inner)

    async def convert_tgs_to_gif(self, tgs_path: str, gif_path: str):
        try:
            anim = LottieAnimation.from_tgs(tgs_path)
            anim.save_animation(gif_path)
        except Exception as e:
            console.print(f"[yellow]⚠ Failed to convert {tgs_path}: {e}[/yellow]")

    async def process_sticker(self, session: aiohttp.ClientSession, sticker, progress, progress_task):
        file_name = f"{sticker['emoji']}_{sticker['file_unique_id']}.tgs"
        tgs_path = os.path.join(self.tgs_dir, file_name)
        gif_path = os.path.join(self.gif_dir, file_name.replace(".tgs", ".gif"))

        if os.path.exists(tgs_path) and os.path.exists(gif_path):
            progress.update(progress_task, advance=1)
            console.print(f"[green]✔ Skipped (already exists): {file_name}[/green]")
            return

        if not os.path.exists(tgs_path):
            try:
                await self.download_file(session, sticker["file_id"], tgs_path)
                console.print(f"[cyan]⬇ Downloaded: {file_name}[/cyan]")
            except Exception as e:
                console.print(f"[red]⚠ Failed to convert {tgs_path}: {e}[/red]")
                progress.update(progress_task, advance=1)
                return
        else:
            console.print(f"[green]✔ Already downloaded: {file_name}[/green]")

        if not os.path.exists(gif_path):
            await self.convert_tgs_to_gif(tgs_path, gif_path)
            console.print(f"[magenta]🎨 Converted to GIF: {file_name.replace('.tgs', '.gif')}[/magenta]")
        else:
            console.print(f"[green]✔ Already converted: {file_name.replace('.tgs', '.gif')}[/green]")

        progress.update(progress_task, advance=1)

    async def run(self, selected_indexes: List[int] = None):
        async with aiohttp.ClientSession() as session:
            try:
                stickers = await self.fetch_sticker_set_info(session)
            except Exception as e:
                console.print(e)
                return

            if selected_indexes is not None:
                stickers = [stickers[i] for i in selected_indexes if 0 <= i < len(stickers)]

            console.print(f"[bold blue]Sticker pack:[/bold blue] {self.sticker_set}, [bold green]Total stickers:[/bold green] {len(stickers)}\n")

            with Progress(
                TextColumn("[progress.description]{task.description}"),
                BarColumn(bar_width=None, complete_style="green"),
                "[progress.percentage]{task.percentage:>3.0f}%",
                TimeRemainingColumn(),
                console=console
            ) as progress:
                task = progress.add_task("[yellow]Processing stickers...[/yellow]", total=len(stickers))
                tasks = [self.process_sticker(session, s, progress, task) for s in stickers]
                await asyncio.gather(*tasks)

            console.print(f"\n[bold green]✅ All done![/bold green] Stickers downloaded & converted!")
            