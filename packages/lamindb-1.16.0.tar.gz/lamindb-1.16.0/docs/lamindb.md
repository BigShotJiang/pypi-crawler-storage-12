# `lamindb`

```{eval-rst}
.. automodule:: lamindb
```
