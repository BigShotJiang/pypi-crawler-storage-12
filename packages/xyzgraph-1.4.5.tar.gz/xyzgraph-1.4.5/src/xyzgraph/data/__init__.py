"""
Reference data for van der Waals radii
"""