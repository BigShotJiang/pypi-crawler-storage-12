"""MCP server for ingestion pipeline administration."""
