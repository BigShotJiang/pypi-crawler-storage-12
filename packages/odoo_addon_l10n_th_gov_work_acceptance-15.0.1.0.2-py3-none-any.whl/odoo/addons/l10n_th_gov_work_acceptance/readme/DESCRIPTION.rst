This module contain process related to purchase's work acceptance, including,

* WA acceptance is required if purchase request is selected.
* Add Committee tab to WA document, and if any, pull committee from purchase request created from purchase request
* Work Acceptance Evaluation with criterias
* Work Acceptance Late Fines, on the last acceptance.
