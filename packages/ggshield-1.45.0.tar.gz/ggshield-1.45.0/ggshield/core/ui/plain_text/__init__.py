from .plain_text_ggshield_ui import PlainTextGGShieldUI


__all__ = ["PlainTextGGShieldUI"]
