void *tf_alloc (size_t n    /* number of elements */, 
			  size_t size /* size of one element */);

float *tf_floatalloc (size_t n /* number of elements */);

int *tf_intalloc (size_t n /* number of elements */);

	  