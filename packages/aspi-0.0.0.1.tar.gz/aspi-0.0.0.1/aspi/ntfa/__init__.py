from ntfacfun import *
from .ntfa import *
from .readwrite import *
