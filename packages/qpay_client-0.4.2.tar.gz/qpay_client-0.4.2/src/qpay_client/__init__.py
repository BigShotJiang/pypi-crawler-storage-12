"""
Python client for the QPay API.

See the README.md for more information.
"""
