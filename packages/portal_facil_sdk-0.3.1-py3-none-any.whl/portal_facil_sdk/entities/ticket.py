class Ticket:
    
    def __init__(self, id: str, protocolo: str):
        self.id = id
        self.protocolo = protocolo