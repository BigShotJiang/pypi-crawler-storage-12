# Release Notes

### November 2025; version 0.0.1.

#### Project start

The original version is a cut-down and rebranded version of bitformat.

Its main job is to reserve the name on PyPI.

