"""Lokalise MCP - Translation key sync tool."""

from .server import mcp, main

__version__ = "0.1.0"
__all__ = ["mcp", "main"]
