
import sys
import os


print('启动路径',sys.argv,os.path.basename(sys.argv[0]))

print(os.path.basename('/sss/startup_file'))
print(os.path.isfile(r'D:\PyObject\小工具\toPYD\test'))