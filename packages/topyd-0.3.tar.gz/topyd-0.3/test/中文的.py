
import test_file3

啊呀=''

print(啊呀)