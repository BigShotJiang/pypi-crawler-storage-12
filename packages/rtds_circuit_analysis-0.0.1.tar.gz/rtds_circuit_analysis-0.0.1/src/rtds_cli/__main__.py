if __name__ == "__main__":
    from rtds_cli.app import app
    app()
