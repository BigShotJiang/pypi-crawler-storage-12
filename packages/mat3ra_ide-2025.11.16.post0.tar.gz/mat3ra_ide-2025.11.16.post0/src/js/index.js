import { ComputedEntityMixin } from "./compute";
import { getDefaultComputeConfig } from "./default";

export { ComputedEntityMixin, getDefaultComputeConfig };
