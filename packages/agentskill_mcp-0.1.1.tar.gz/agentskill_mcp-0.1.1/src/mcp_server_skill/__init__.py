"""MCP Server for Claude Skills - Progressive Disclosure Implementation."""

__version__ = "0.1.0"
