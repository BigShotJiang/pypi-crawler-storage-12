"""Module to hold the TaxReturn resource."""

from fintoc.mixins import ResourceMixin


class TaxReturn(ResourceMixin):
    """Represents a Fintoc Tax Return."""
