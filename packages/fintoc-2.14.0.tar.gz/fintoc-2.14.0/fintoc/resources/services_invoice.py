"""Module to hold the ServicesInvoice resource."""

from fintoc.mixins import ResourceMixin


class ServicesInvoice(ResourceMixin):
    """Represents a Fintoc Services Invoice."""
