# pylint: disable=duplicate-code
"""Module to hold the Movement resource."""

from fintoc.mixins import ResourceMixin


class Movement(ResourceMixin):
    """Represents a Fintoc Movement."""
