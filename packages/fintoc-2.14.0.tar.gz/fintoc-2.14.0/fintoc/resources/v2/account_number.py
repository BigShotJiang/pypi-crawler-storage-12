"""Module to hold the AccountNumber resource."""

from fintoc.mixins import ResourceMixin


class AccountNumber(ResourceMixin):
    """Represents a Fintoc AccountNumber."""
