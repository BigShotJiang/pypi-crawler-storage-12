"""Module to hold the Institution resource."""

from fintoc.mixins import ResourceMixin


class Institution(ResourceMixin):
    """Represents a Fintoc Institution."""
