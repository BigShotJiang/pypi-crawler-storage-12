"""Module to hold the Subscription resource."""

from fintoc.mixins import ResourceMixin


class Subscription(ResourceMixin):
    """Represents a Fintoc Subscription."""
