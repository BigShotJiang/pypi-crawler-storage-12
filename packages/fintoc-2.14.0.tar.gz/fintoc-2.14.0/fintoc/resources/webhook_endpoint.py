"""Module to hold the WebhookEndpoint resource."""

from fintoc.mixins import ResourceMixin


class WebhookEndpoint(ResourceMixin):
    """Represents a Fintoc Webhook Endpoint."""
