"""Module to hold the PaymentLink resource."""

from fintoc.mixins import ResourceMixin


class PaymentLink(ResourceMixin):
    """Represents a Fintoc PaymentLink."""
