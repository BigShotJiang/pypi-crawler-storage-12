"""Module to hold the CheckoutSession resource."""

from fintoc.mixins import ResourceMixin


class CheckoutSession(ResourceMixin):
    """Represents a Fintoc CheckoutSession."""
