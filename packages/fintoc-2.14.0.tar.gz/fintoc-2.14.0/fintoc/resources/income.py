"""Module to hold the Income resource."""

from fintoc.mixins import ResourceMixin


class Income(ResourceMixin):
    """Represents a Fintoc Income."""
