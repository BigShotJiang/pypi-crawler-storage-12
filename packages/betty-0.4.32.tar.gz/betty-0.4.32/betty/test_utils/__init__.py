"""
Provide utilities for testing Betty or other software that depends on Betty.
"""
