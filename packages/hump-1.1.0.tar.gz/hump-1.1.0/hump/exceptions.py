class HttpException(Exception):
    pass


class HttpParserError(HttpException):
    pass
