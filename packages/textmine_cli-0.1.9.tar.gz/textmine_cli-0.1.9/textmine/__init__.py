__version__ = "0.1.9"
__author__ = "textmine.net"
__description__ = "Retro terminal client for textmine.net - 1980s-style chat network"
