"""Testing utilities for generating contract-aligned datasets."""

from .datasets import generate_contract_dataset

__all__ = ["generate_contract_dataset"]
