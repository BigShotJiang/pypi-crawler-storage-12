# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShareTypesAttributionSingleChannel4KLatency:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'max': 'int',
        'min': 'int'
    }

    attribute_map = {
        'max': 'max',
        'min': 'min'
    }

    def __init__(self, max=None, min=None):
        r"""ShareTypesAttributionSingleChannel4KLatency

        The model defined in huaweicloud sdk

        :param max: 最大值
        :type max: int
        :param min: 最小值
        :type min: int
        """
        
        

        self._max = None
        self._min = None
        self.discriminator = None

        if max is not None:
            self.max = max
        if min is not None:
            self.min = min

    @property
    def max(self):
        r"""Gets the max of this ShareTypesAttributionSingleChannel4KLatency.

        最大值

        :return: The max of this ShareTypesAttributionSingleChannel4KLatency.
        :rtype: int
        """
        return self._max

    @max.setter
    def max(self, max):
        r"""Sets the max of this ShareTypesAttributionSingleChannel4KLatency.

        最大值

        :param max: The max of this ShareTypesAttributionSingleChannel4KLatency.
        :type max: int
        """
        self._max = max

    @property
    def min(self):
        r"""Gets the min of this ShareTypesAttributionSingleChannel4KLatency.

        最小值

        :return: The min of this ShareTypesAttributionSingleChannel4KLatency.
        :rtype: int
        """
        return self._min

    @min.setter
    def min(self, min):
        r"""Sets the min of this ShareTypesAttributionSingleChannel4KLatency.

        最小值

        :param min: The min of this ShareTypesAttributionSingleChannel4KLatency.
        :type min: int
        """
        self._min = min

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShareTypesAttributionSingleChannel4KLatency):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
