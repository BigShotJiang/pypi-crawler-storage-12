z = 48000000
for x in range(8):
    z = z / 2
    print(z)

