




class RangeType:
    pass



class InputType:
    pass



class GolType:
    pass



class BackgroundType:
    pass





class FadeType:
    pass






class FontType:
    pass



class SwitchBoardType:
    pass