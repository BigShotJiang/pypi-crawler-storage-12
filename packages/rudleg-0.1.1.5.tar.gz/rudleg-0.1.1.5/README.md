NOTHING920 - ready to start
940 - re-load your project
999 - update lib
524 - your problems
521 - problem and bugs in own library
455 - prohibited use local danger functions
422 - prohibited create second config
425 - prohibited to use privat objects
434 - should use config products
201 - new created config
202 - new reloaded config
203 - new file created
204 - has builded successfully
205 - run successfully
206 - switched flag
266 - hass desktoped