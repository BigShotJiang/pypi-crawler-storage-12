### This project is about creating and visualising virus simulation models 

---
## Installing and using python simulation

1. Install the package
`pip install virus-simulation==1.1.0`
2. Launch it `python -m virus_simulation`