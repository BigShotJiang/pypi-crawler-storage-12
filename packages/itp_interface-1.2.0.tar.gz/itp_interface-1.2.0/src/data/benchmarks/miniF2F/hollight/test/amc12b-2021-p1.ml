let amc12b-2021-p1 = `(FINITE {x:int | real_of_int (abs x) < &3 * pi}) ==> (CARD {x:int | real_of_int (abs x) < &3 * pi} = 19)`;;
