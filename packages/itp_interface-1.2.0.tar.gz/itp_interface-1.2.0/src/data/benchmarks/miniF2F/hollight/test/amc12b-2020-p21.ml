let amc12b-2020-p21 = `FINITE {n | n > 0 /\ &(n + 1000) / &70 = floor (sqrt (&n))} ==> CARD {n | n > 0 /\ &(n + 1000) / &70 = floor (sqrt (&n))} = 6`;;
