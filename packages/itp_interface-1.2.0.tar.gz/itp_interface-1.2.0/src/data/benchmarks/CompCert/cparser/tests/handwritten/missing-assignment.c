int main (void)
{
  int x = 10, y 8;
}
