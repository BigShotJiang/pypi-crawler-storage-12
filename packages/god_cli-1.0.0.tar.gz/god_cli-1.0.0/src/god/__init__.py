"""GOD — Global Operations Deity. Professional Grade CLI."""

__all__ = ["version", "__version__"]

version = "1.0.0"
__version__ = version
