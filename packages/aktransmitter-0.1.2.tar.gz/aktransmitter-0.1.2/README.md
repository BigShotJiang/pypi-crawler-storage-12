# transmitter

A lightweight file-based transmitter for Python.

## Usage

```python
from transmitter import transmit

transmit("data.txt", "Hello", 0.1)
