from setuptools import setup, find_packages

setup(
    name="aktransmitter",
    version="0.1.2",
    description="A simple file-based data transmitter",
    author="Akshay Ajit Bhawar",
    packages=find_packages(),
    python_requires=">=3.6",
)
