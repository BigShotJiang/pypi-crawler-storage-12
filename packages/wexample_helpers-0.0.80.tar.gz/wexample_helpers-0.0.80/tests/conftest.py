from __future__ import annotations

# Empty conftest for now; no special collection behavior is needed.
