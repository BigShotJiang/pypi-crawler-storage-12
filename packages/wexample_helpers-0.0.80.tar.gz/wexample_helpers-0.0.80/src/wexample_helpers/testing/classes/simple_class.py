from __future__ import annotations


class SimpleClass:
    def __init__(self, name="default") -> None:
        self.name = name
