from __future__ import annotations


class BaseMixin:
    """Base mixin with common properties."""

    version: str = "0.0.0"
