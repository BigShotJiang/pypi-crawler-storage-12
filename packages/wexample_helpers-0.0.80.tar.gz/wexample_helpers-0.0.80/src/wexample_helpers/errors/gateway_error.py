from __future__ import annotations


class GatewayError(Exception):
    """Base exception for gateway errors."""
