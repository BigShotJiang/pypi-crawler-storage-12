from __future__ import annotations

DEFAULT_VERSION_NUMBER: str = "0.0.1"
