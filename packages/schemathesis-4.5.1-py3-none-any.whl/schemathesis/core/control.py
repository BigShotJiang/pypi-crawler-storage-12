class SkipTest(BaseException):
    """Raised when the current test should be skipped and the executor then continues normally."""
