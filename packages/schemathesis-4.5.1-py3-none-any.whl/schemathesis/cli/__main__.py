if __name__ == "__main__":
    import schemathesis.cli

    schemathesis.cli.schemathesis()
