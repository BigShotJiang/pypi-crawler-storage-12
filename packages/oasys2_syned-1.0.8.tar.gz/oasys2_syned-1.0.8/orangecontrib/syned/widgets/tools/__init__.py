"""
=========
Associate
=========

Widgets for association rules.

"""

# Category description for the widget registry

NAME = "Syned \u23F5 Tools"

DESCRIPTION = "Widgets for Syned"

BACKGROUND = "#dec0a0"

ICON = "icons/util.png"

PRIORITY = 2.2
