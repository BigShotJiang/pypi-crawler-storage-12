import asyncio

from langchain_core.messages import messages_to_dict
from langgraph.checkpoint.memory import MemorySaver
from rich import print

from universal_mcp.agents.llm import load_chat_model
from universal_mcp.agents.storm.agent import StormAgent
from universal_mcp.agents.storm.nodes import agent_node


async def main():
    """Entry point for the agent."""
    memory = MemorySaver()
    # llm = load_chat_model("azure:gpt-5-chat")
    agent = StormAgent(memory=memory)

    try:
        result = await asyncio.wait_for(
            agent.invoke("I'm Ruzo. What is weather like in my city", thread_id=1),
            timeout=12,
        )
        messages = messages_to_dict(result["messages"])
        print(messages)  # noqa: T201
    except TimeoutError:
        print("Agent invocation timed out after 15 seconds.")

    # try:
    #     result2 = await asyncio.wait_for(agent.invoke("What was temperature?", thread_id=1), timeout=30)
    #     messages = messages_to_dict(result2["messages"])
    #     print(messages)  # noqa: T201
    # except TimeoutError:
    #     print("Agent invocation timed out after 15 seconds.")

    # Check state
    state = await agent.get_state(thread_id=1)
    print(state)


if __name__ == "__main__":
    asyncio.run(main())
