from functools import partial

from langgraph.graph import END, StateGraph

from universal_mcp.agents.base import BaseAgent
from universal_mcp.agents.llm import load_chat_model

from .nodes import agent_node, cleanup_node, entry_node
from .state import StormState

DEVELOPER_PROMPT = """
You are {name}, a helpful assistant.

Adhere to the following instructions strictly:
{instructions}
"""


class StormAgent(BaseAgent):
    """
    A simple agent that can be configured to do anything.
    """

    def __init__(self, **kwargs):
        super().__init__(
            name="StormAgent",
            instructions="",
            model="gemini:gemini-2.5-flash",
            **kwargs,
        )
        self.llm = load_chat_model(self.model)

    def _build_system_message(self):
        return DEVELOPER_PROMPT.format(name=self.name, instructions=self.instructions)

    async def _build_graph(self) -> StateGraph:
        graph = StateGraph(StormState)

        agent_node_subgraph = agent_node(self.llm, self._build_system_message(), self.memory)
        # Add nodes
        graph.add_node("entry", entry_node)
        graph.add_node("agent", agent_node_subgraph)
        graph.add_node("cleanup", cleanup_node)

        # Define graph flow
        graph.set_entry_point("entry")
        graph.add_edge("entry", "agent")
        graph.add_edge("agent", "cleanup")
        graph.add_edge("cleanup", END)

        return graph.compile(checkpointer=self.memory)
