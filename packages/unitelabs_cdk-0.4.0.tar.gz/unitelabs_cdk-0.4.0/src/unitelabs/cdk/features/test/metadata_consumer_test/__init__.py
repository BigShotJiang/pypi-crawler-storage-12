from .metadata_consumer_test import MetadataConsumerTest

__all__ = ["MetadataConsumerTest"]
