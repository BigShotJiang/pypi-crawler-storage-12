# td0update-darshan

A **tiny** reinforcement-learning helper with one well-tested function: **TD(0) value update**.

## Install (after you publish)
```bash
pip install td0update-darshan
