"""physical_properties - subpackage for calculating physical properties like velocities from either LVM data or models."""
