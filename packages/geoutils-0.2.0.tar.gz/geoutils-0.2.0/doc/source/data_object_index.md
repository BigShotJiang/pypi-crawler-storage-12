(data-object-index)=
# Geospatial data objects

Prefer to learn by running examples? Explore our example galleries on {ref}`examples-io`, {ref}`examples-handling` and {ref}`examples-analysis`.

```{toctree}
:maxdepth: 2

raster_class
vector_class
pointcloud_class
```
