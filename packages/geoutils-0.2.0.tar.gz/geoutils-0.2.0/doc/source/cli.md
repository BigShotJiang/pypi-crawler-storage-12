(cli)=
# Command line interface

This page lists all command line interface (CLI) functionalities of GeoUtils.
These commands can be run directly from a terminal, without having to launch a Python console.

## geoviewer.py

```{eval-rst}
.. argparse::
    :filename: geoviewer.py
    :func: getparser
    :prog: geoviewer.py
```
