(authors)=
# Authors

© 2025 **GeoUtils developers**.

**GeoUtils** is licensed under permissive Apache 2 license (See [LICENSE file](license.md) or below).

All contributors listed in this document are part of the **GeoUtils developers**, and their
contributions are subject to the project's copyright under the terms of the
[Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0).

Please refer to [AUTHORS file](https://github.com/GlacioHack/geoutils/blob/main/AUTHORS.md) for the complete and detailed list of authors and their contributions.
