(core-index)=
# Fundamentals

Prefer to learn by running examples? Explore our example galleries on {ref}`examples-io`, {ref}`examples-handling` and {ref}`examples-analysis`.

```{toctree}
:maxdepth: 2

core_composition
core_match_ref
core_py_ops
core_array_funcs
core_lazy_load
core_parsing
core_inheritance
```
