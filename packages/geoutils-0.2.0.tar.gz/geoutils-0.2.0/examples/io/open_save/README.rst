Open and save from files
------------------------
