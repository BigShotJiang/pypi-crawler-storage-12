.. _examples-io:

Input/output
============

Examples about **opening**, **creating**, **loading** or **saving** geospatial data.

With :class:`Rasters<geoutils.Raster>`, data is only loaded when necessary (see :ref:`core-lazy-load`).
