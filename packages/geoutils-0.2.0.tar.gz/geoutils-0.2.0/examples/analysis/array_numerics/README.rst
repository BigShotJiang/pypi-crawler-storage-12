Raster numerics
---------------
