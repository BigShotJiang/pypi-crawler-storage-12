Distance estimation
-------------------
