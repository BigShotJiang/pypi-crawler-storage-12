<!-- Feel free to remove check-list items that aren't relevant to your change -->

 - [ ] Resolves #xxx,
 - [ ] Tests added, otherwise issue #xxx opened,
 - [ ] Fully documented, including `api/*.md` for new API.
 - [ ] New optional dependencies or Python version support added to both `dev-environment.yml` and `setup.cfg`,
 - [ ] If contributor workflow (test, doc, linting) or Python version support changed, update `CONTRIBUTING.md`.
