"""This file now only serves for backward-compatibility for routines explicitly calling python setup.py"""

from setuptools import setup

setup()
