class ImproperlyConfigured(Exception):
    pass


class DataError(Exception):
    pass
