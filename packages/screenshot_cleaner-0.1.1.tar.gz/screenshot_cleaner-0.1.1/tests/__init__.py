"""Test suite for screenshot_cleaner."""
