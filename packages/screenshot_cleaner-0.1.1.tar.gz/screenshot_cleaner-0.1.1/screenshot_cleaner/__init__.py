"""Screenshot Cleaner - A CLI tool for cleaning up old macOS screenshots."""

__version__ = "0.1.1"
