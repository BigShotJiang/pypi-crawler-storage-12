"""Core business logic for screenshot cleaning."""
