---
hide:
  - navigation
  - toc
---

<button id="__notebook-edit" class="source-link" title="Edit notebook page">:material-notebook-edit:</button>
<button id="__notebook-py-gist" class="source-link" title="Load Python code from source">:material-language-python:</button>
<button id="__notebook-md-gist" class="source-link" title="Load page from Markdown source">:material-language-markdown:</button>
<h1>Notebook</h1>

---

<div id="__notebook-render"></div>

<div id="__notebook-source" class="notebook hidden">
<pre id="__notebook-input"></pre>
<button id="__notebook-submit" title="Submit">Submit</button>
<button id="__notebook-cancel" title="Cancel">Cancel</button>
</div>

<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
