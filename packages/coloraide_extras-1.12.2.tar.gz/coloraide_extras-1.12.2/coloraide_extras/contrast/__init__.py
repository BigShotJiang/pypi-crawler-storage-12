"""Contrast algorithms."""
