"""ColorAide Extra."""
from .__meta__ import __version_info__, __version__  # noqa: F401
