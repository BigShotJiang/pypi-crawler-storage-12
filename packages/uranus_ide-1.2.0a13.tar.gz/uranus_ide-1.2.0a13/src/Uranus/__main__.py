# src/Uranus/__main__.py

from Uranus.core import main

if __name__ == "__main__":
    main()