# Martina
Codi Python que fa funcionar la Martina, el nostre robot familiar

Taulell de Trello https://trello.com/b/3mHrU0Km
