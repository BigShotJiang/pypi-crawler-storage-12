"""Tests for Remote Shell MCP Server."""

