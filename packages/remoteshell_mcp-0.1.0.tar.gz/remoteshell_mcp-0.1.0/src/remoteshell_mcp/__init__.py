"""Remote Shell MCP Server - SSH connection management and remote command execution."""

__version__ = "0.1.0"

