from setuptools import setup


def main():
    setup(test_suite='tests.settings.run')


if __name__ == "__main__":
    main()
