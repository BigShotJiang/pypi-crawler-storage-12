from django.apps import AppConfig


class AldrynForms(AppConfig):
    name = 'aldryn_forms'
    verbose_name = 'Aldryn forms'
    default_auto_field = "django.db.models.BigAutoField"
