from django.apps import AppConfig


class CottonBS5Config(AppConfig):
    name = "cotton_bs5"
