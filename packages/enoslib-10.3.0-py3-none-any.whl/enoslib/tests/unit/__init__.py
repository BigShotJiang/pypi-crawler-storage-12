import unittest


class EnosTest(unittest.TestCase):
    pass
