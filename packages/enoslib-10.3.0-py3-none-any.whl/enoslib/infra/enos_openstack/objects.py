from enoslib.objects import DefaultNetwork


class OSNetwork(DefaultNetwork):
    pass
