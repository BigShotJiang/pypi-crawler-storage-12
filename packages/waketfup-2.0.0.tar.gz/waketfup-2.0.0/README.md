Usage:
```
pip install waketfup
```
`waketfup --range 9-12,13-18`

Credits to https://towardsdatascience.com/how-to-keep-windows-from-sleeping-570d2042b338 
<br/>
Credits to https://pypi.org/project/keepmeup/
