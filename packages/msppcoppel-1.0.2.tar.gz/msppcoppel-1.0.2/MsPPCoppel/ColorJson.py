from pygments import highlight, lexers, formatters


def ColorsJson(formatted_json):
    """
    """
    # return highlight(unicode(formatted_json, 'UTF-8'), lexers.javascript() , formatters.TerminalFormatter())
    pass
