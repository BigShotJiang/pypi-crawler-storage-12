"""hecstac version."""

__version__ = "0.5.2"
