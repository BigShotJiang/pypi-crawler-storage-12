{% extends "autosummary_core/class.rst" %}
