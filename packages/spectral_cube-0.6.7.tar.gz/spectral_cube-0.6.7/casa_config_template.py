import os
here = os.path.dirname(os.path.abspath('.'))
datapath=[os.path.join(here, '.casa', 'data')]
measurespath=datapath[0]
measures_auto_update=True
data_auto_update=True
