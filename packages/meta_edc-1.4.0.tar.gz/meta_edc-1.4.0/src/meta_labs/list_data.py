model_data = {
    "edc_lab.consignee": [
        {
            "name": "The META Trial",
            "contact_name": "Sokoine Kivuyo",
            "address": "NIMR Tanzania",
            "postal_code": "-",
            "city": "Dar es Salaam",
            "state": "",
            "country": "Tanzania",
            "telephone": "+255763244779",
            "mobile": "+255763244779",
            "fax": "",
            "email": "sokoinele@yahoo.co.uk",
        }
    ]
}
