# spectro-api

> This is spectros api for IOS / mobile status
> You must have status presence online(green)# spectroapi

## Install

```bash
pip install spectro-api
```

```
from discord.ext import commands
from spectro_api import api as pfps

bot = commands.Bot(command_prefix=";")

bot.add_cog(pfps(bot))
bot.run("token")
```

Use:
- ;pfps random
- ;pfps anime
- ;pfps egirl

# Categories
- all
- anime
- egirl

This will will be free (no rate limits)



