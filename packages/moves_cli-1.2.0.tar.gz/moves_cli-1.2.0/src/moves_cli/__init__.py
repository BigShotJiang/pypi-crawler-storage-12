def main() -> None:
    print("Hello from moves-cli!")
