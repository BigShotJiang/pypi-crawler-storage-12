# TODO： 设定一些风控场景，用于测试风控管理器是否能正常工作，并且通过 RiskSignal 对象获取对应的风控内容
# scene 1: 正常情况，所有的风控检查都通过。
# scene 2: 
# scene 2: 
# scene 3: 
# scene 4: 
# scene 5: 
# scene 6: 
