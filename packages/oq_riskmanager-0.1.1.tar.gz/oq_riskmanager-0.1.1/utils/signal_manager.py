

class SignalManager:
    def __init__(self) -> None:
        print(f"Mock SignalManager class 初始化")