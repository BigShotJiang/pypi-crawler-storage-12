import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import time

class Stats:
    __slots__ = (
        "volume",
        "count",
        "profit_count",
        "loss_count",
        "win_rate",
        "profit_value",
        "loss_value",
        "net_pnl",  # 价差净收益
        "base_funding_fee",
        "hedge_funding_fee",
        "funding_pnl",
        "leg_count",
        "leg_volume",
        "leg_pnl",
        "total_pnl",  # net_pnl + funding_pnl + leg_pnl
        "fee",
        "rebate",
    )

    def __init__(self):
        self.volume = 0.0
        self.count = 0
        self.profit_count = 0
        self.loss_count = 0
        self.win_rate = 0.0
        self.profit_value = 0.0
        self.loss_value = 0.0
        self.net_pnl = 0.0
        self.base_funding_fee = 0.0
        self.hedge_funding_fee = 0.0
        self.funding_pnl = 0.0
        self.leg_count = 0
        self.leg_volume = 0.0
        self.leg_pnl = 0.0
        self.total_pnl = 0.0
        self.fee = 0.0
        self.rebate = 0.0


class Statistics:
    def __init__(self):
        self.now_balance = 10000
        self.max_balance = 10000
        self.today_start_balance = 10000

        self.start_balance = 10000
        self.start_time = int(time.time() * 1000)

        self.fee_rate = 0.0006

        self.symbol_stats = {symbol: Stats() for symbol in ['BTC_USDT']}

        self.total_stats = Stats()
