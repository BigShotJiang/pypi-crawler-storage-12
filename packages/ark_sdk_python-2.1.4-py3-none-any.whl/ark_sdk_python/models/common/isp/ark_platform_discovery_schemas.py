from ark_sdk_python.models import ArkHttpUrlString, ArkModel


class IdentityEndpointResponse(ArkModel):
    endpoint: ArkHttpUrlString
