from enum import Enum


class ArkConnectorType(str, Enum):
    DPA_CONNECTOR = 'DPAConnector'
