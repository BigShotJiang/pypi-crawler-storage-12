from ark_sdk_python.models.common.connections.connection_data.ark_ssh_connection_data import ArkSSHConnectionData
from ark_sdk_python.models.common.connections.connection_data.ark_winrm_connection_data import ArkWinRMConnectionData

__all__ = ['ArkSSHConnectionData', 'ArkWinRMConnectionData']
