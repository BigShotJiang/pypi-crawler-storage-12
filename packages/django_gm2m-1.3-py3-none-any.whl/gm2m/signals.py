from django.core.signals import Signal

deleting = Signal()
