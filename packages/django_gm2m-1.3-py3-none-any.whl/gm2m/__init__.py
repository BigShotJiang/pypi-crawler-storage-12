from .version import __version__, __version_info__

from .fields import GM2MField

default_app_config = 'gm2m.apps.GM2MConfig'
