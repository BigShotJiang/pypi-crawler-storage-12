=====================================================
Propagated Noise Absorption (:mod:`qiskit_addon_pna`)
=====================================================

.. automodule:: qiskit_addon_pna
   :no-members:
   :no-inherited-members:
   :no-special-members:

.. currentmodule:: qiskit_addon_pna

.. autofunction:: generate_noise_mitigating_observable
