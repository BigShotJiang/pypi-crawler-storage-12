"""Update command."""

from .command import update_command

__all__ = ["update_command"]
