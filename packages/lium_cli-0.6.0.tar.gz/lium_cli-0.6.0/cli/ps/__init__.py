"""Pods (ps) command."""

from .command import ps_command

__all__ = ["ps_command"]
