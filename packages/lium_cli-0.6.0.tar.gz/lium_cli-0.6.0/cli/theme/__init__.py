"""Theme command."""

from .command import theme_command

__all__ = ["theme_command"]
