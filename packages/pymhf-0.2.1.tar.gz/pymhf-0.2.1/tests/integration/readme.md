This is a collection of tests which will run on real programs.
All the executables are built on the CI.