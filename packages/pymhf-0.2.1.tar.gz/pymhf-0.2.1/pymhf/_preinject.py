# This file contains a number of things to import or set before anything else is injected.
# For the most part this imports stuff so that the import cache is primed so that any subsequent imports do
# not overwrite the existing data.
import pymhf.core._internal  # noqa
