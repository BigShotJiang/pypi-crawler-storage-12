API docs
========

.. toctree::
   :maxdepth: 1

   pymhf
