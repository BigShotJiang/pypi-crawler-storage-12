#!/usr/bin/env python3
"""AgentKit CLI 入口点"""

from .cli import app

if __name__ == "__main__":
    app()