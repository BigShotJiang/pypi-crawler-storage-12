"""Dialog screens for the terminal TUI."""

from par_term_emu_tui_rust.dialogs.config_edit_dialog import ConfigEditDialog

__all__ = ["ConfigEditDialog"]
