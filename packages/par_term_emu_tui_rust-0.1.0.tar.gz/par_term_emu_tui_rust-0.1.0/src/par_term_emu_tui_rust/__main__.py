"""
Command-line entry point for the TUI demo.
"""

from par_term_emu_tui_rust.app import main

if __name__ == "__main__":
    main()
