"""Unit tests for caching layer."""
