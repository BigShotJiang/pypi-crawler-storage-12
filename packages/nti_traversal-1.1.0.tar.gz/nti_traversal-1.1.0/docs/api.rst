===========
 Reference
===========

.. testsetup::

    import zope.component
    from zope.traversing.interfaces import IPathAdapter
    from zope.traversing.namespace import adapter
    from zope.location.interfaces import LocationError

Traversal
=========

.. automodule:: nti.traversal.traversal


Location
========

.. automodule:: nti.traversal.location
