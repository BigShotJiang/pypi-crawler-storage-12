=========
 Changes
=========


1.1.0 (2025-11-14)
==================

- Add support for Python 3.14.
- Remove support for Python < 3.12.
- Move ``zope.container`` to the new "zodb" extra.


1.0.0 (2024-11-11)
==================

- Drop support for Python < 3.10.
- Use native namespace packages.


0.0.1 (2020-01-02)
==================

- Add support for Python 3.
