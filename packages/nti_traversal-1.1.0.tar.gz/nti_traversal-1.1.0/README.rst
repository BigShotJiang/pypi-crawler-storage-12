===============
 nti.traversal
===============

.. image:: https://travis-ci.org/NextThought/nti.traversal.svg?branch=master
    :target: https://travis-ci.org/NextThought/nti.traversal

.. image:: https://coveralls.io/repos/github/NextThought/nti.traversal/badge.svg?branch=master
    :target: https://coveralls.io/github/NextThought/nti.traversal?branch=master

.. image:: https://readthedocs.org/projects/ntitraversal/badge/?version=latest
   :target: https://ntitraversal.readthedocs.io/en/latest/?badge=latest
   :alt: Documentation Status

Support for `resource tree traversal
<https://pyramid.readthedocs.io/en/latest/narr/muchadoabouttraversal.html>`_
using `zope.traversing <https://zopetraversing.readthedocs.io>`_.
