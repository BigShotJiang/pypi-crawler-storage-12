import MHTDocument  # noqa: F401
import objc
from PyObjCTools import AppHelper

objc.setVerbose(1)

AppHelper.runEventLoop()
