if __name__ == "__main__":
    from circuitydatabase.cli import app
    app()
