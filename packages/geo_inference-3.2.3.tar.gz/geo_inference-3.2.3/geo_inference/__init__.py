"""Geo-inference: Extract features from high-resolution geospatial imagery using foundation models"""

__author__ = "Victor Alhassan"
__version__ = "3.2.3"
