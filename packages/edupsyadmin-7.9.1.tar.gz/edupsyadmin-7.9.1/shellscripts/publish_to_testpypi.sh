# Configure uv to use AWS CodeArtifact
export UV_PUBLISH_URL="https://test.pypi.org/legacy/"
