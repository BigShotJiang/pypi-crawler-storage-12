"""MCP Cookie Cutter - Intelligent MCP server generator from OpenAPI/Swagger specs."""

__version__ = "0.1.0"
__author__ = "MCP Cookie Cutter Contributors"
__description__ = "Intelligent MCP server generator from OpenAPI/Swagger specs"
