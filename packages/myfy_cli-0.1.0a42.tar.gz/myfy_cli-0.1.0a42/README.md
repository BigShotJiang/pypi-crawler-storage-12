# myfy-cli

CLI tools for the myfy framework.

Commands:
- `myfy run` - Start development server
- `myfy routes` - List all routes
- `myfy modules` - Show loaded modules
- `myfy doctor` - Validate configuration

See the [main README](../../README.md) for documentation.
