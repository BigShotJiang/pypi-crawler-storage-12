import os

NT_AUTH = os.getenv("NT_AUTH", default="")
