from .df2tables import *
__version__ = "0.2.1"
__author__ = "Tomasz Slugocki"
__license__ = "MIT"

