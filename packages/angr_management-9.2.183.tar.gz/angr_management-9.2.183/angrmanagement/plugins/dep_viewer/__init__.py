from __future__ import annotations

from .dep_plugin import DependencyViewer

__all__ = [
    "DependencyViewer",
]
