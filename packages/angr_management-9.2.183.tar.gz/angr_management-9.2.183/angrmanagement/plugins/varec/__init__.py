from __future__ import annotations

from .varec import VaRec

__all__ = ["VaRec"]
