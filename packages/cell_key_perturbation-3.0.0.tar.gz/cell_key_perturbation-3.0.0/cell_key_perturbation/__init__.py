"""This package creates frequency tables from microdata, and applies cell key perturbation to alter the final values""" 

__version__ = "3.0.0"


