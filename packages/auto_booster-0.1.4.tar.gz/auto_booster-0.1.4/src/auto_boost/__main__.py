"""Allow `python -m auto_boost` to run the CLI."""

from .cli import main


if __name__ == "__main__":
    main()
