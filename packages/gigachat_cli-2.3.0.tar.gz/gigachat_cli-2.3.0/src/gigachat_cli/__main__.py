from gigachat_cli.main import Main


def main():
    """
    Основная функция запуска приложения GigaChat CLI
    """
    app = Main()
    app.run()


if __name__ == "__main__":
    main()
