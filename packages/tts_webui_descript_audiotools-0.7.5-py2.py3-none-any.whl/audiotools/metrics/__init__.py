"""
Functions for comparing AudioSignal objects to one another.
"""  # fmt: skip
from . import distance
from . import quality
from . import spectral
