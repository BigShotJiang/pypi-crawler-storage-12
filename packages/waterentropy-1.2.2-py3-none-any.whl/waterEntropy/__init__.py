"""calculate water entropy near heterogeneous interfaces"""

# Add imports here
# from waterEntropy.neighbours.force_torque import *

__version__ = "1.2.2"
