"""waterEntropy: calculate water entropy near heterogeneous interfaces"""
