from importlib.metadata import version

version = version("alphaimpute2")
