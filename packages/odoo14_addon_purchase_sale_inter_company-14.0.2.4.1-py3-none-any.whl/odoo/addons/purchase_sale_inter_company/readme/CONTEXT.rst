Imagine you have company A and company B in the same Odoo database:


Company A purchases goods from company B.

Company A will create a purchase order with company B as supplier.

This module automates the creation of the sale order in company B with company A as customer.

Receipt picking(s) created from Company A purchase are synced with quantities delivered in picking(s) by Company B sale.
