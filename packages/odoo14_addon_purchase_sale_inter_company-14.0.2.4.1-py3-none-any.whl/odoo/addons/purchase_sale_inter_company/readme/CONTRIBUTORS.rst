* Odoo S.A.
* Chafique Delli <chafique.delli@akretion.com>
* Alexis de Lattre <alexis.delattre@akretion.com>
* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Dauden
  * Jairo Llopis
* Mourad EL HADJ MIMOUNE <mourad.elhadj.mimoune@akretion.com>
* `PyTech SRL <info@pytech.it>`_:

  * Alessandro Uffreduzzi <alessandro.uffreduzzi@pytech.it>

* Ooops404 <info@ooops404.com>

  * Francesco Foresti <francesco.foresti@ooops404.com>
  * Eduard Brahas <eduardbrhas@outlook.it>
