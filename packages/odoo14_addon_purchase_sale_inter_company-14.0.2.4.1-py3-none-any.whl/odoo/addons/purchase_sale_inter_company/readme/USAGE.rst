Create a purchase with Company A, setting Company B as vendor > confirm PO > a SO for Company B with customer Company A is created automatically.


Validate SO for Company B > validate delivery picking > in PO for Company A, receipt picking is validated with quantities from Company B delivery picking.

If backorders have been created from delivery picking, they will be synchronized to receipt picking.
