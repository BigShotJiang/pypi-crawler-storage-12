* `AKRETION <https://akretion.com/pt-BR/>`_:

  * Raphaël Valyi <raphael.valyi@akretion.com.br>
  * Renato Lima <renato.lima@akretion.com.br>

* `KMEE <https://kmee.com.br>`_:

  * Gabriel Cardoso de Faria <gabriel.cardoso@kmee.com.br>
  * Luis Felipe Mileo <mileo@kmee.com.br>
  * Renan Hiroki Bastos <hirokibastos@gmail.com>
  * Felipe Zago Rodrigues <felipe.zago@kmee.com.br>

* `ESCODOO <https://escodoo.com.br>`_:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>

* `ENGENERE <https://engenere.one>`_:

  * Antônio S. Pereira Neto <neto@engenere.one>
