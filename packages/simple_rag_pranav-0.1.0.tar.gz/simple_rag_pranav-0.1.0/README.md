# SimpleRAG

SimpleRAG is a lightweight, plug-and-play Retrieval-Augmented Generation (RAG) library using OpenAI and Sentence Transformers.

## Installation

```bash
pip install simple-rag-pranav
