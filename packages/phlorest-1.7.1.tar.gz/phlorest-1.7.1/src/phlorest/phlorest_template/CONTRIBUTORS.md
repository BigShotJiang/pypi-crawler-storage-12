# Contributors

Name                           | GitHub user     | Description        | Role
---                            | ---             | ---                | ---
Simon J. Greenhill             | @SimonGreenhill | maintainer         | Editor
Robert Forkel                  | @xrotwang       | maintainer         | Editor
