from .global_lang_val import Lang_tag, Lang_tag_language

LANG_TAG = Lang_tag(language=Lang_tag_language.en)

LANG_MAP: dict[str, str] = {}
