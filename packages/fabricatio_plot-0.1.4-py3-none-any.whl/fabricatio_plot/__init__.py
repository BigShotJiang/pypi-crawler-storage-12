"""An extension of fabricatio, which brings up the capability to plot dataframe with matplotlib."""
