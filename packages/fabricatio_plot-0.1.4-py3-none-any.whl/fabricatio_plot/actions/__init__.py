"""Actions defined in fabricatio-plot."""
