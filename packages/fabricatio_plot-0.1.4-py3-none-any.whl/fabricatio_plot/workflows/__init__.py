"""Workflows defined in fabricatio-plot."""
