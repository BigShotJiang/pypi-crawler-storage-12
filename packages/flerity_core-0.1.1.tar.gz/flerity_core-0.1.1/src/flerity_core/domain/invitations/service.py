"""Service layer for invitation codes domain."""
from uuid import UUID

from flerity_core.domain.invitations.repository import InvitationsRepository
from flerity_core.domain.invitations.schemas import (
    InvitationCodeCreate,
    InvitationCodeOut,
    InvitationCodeStats,
    InvitationCodeUsageOut,
)
from flerity_core.utils.codes import generate_invitation_code
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker


class InvitationsService:
    """Service for invitation codes business logic."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]):
        self.session_factory = session_factory

    async def create_invitation_code(
        self,
        data: InvitationCodeCreate,
        created_by: UUID | None = None,
    ) -> InvitationCodeOut:
        """Create new invitation code with auto-generated code."""
        async with self.session_factory() as session:
            repository = InvitationsRepository(session)

            # Generate unique code
            code = generate_invitation_code()

            # Set default metadata based on type
            metadata = data.metadata or self._get_default_metadata(data.type)

            result = await repository.create_invitation_code(
                code=code,
                type=data.type,
                max_uses=data.max_uses,
                expires_at=data.expires_at,
                created_by=created_by,
                metadata=metadata,
            )
            await session.commit()
            return result

    async def validate_invitation_code(self, code: str) -> InvitationCodeOut:
        """Validate invitation code for usage."""
        async with self.session_factory() as session:
            repository = InvitationsRepository(session)
            return await repository.validate_invitation_code(code)

    async def use_invitation_code(
        self,
        code: str,
        user_id: UUID,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> InvitationCodeUsageOut:
        """Use invitation code and apply benefits."""
        async with self.session_factory() as session:
            repository = InvitationsRepository(session)
            result = await repository.use_invitation_code(
                code=code,
                user_id=user_id,
                ip_address=ip_address,
                user_agent=user_agent,
            )
            await session.commit()
            return result

    async def list_invitation_codes(
        self,
        limit: int = 20,
        offset: int = 0,
        active_only: bool = False,
    ) -> list[InvitationCodeOut]:
        """List invitation codes (admin only)."""
        async with self.session_factory() as session:
            repository = InvitationsRepository(session)
            return await repository.list_invitation_codes(
                limit=limit,
                offset=offset,
                active_only=active_only,
            )

    async def get_invitation_code_stats(self) -> InvitationCodeStats:
        """Get invitation code statistics."""
        async with self.session_factory() as session:
            repository = InvitationsRepository(session)
            return await repository.get_invitation_code_stats()

    def _get_default_metadata(self, code_type: str) -> dict:
        """Get default metadata based on invitation code type."""
        metadata_map = {
            "free": {
                "trial_days": 0,
                "features": ["basic"]
            },
            "premium": {
                "trial_days": 30,
                "features": ["premium", "ai_unlimited"]
            },
            "trial": {
                "trial_days": 7,
                "features": ["premium"]
            }
        }
        return metadata_map.get(code_type, {})
