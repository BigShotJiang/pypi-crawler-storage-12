"""Domain layer - Business logic and entities."""
