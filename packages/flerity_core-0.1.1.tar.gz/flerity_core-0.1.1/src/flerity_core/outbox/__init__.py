"""Outbox pattern - Transactional event publishing."""
