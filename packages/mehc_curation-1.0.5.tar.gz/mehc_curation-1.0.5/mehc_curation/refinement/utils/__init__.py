"""Refinement utility functions and classes."""

__all__ = []

