from uv_lock_report.cli import main

if __name__ == "__main__":
    main()
