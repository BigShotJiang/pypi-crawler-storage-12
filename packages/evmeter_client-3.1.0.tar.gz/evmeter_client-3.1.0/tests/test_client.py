"""Placeholder for evmeter_client tests."""


def test_placeholder():
    """A placeholder test."""
    assert True
