Please see the following [file](https://github.com/claimed-framework/component-library/blob/master/VULNERABILITIES.md) for SECURITY related content
