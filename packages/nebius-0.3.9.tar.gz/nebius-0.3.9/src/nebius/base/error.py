class SDKError(Exception):
    """Base class for all SDK errors."""

    pass
