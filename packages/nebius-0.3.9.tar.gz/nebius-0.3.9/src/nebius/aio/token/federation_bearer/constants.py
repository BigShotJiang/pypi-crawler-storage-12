AUTH_ENDPOINT = "/oauth2/authorize"
TOKEN_ENDPOINT = "/oauth2/token"  # noqa: S105
