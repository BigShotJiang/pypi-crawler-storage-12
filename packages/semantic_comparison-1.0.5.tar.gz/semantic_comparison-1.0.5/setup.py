from setuptools import setup, find_packages

setup(
    name = 'semantic_comparison',
    version = '1.0.5',
    author = 'OPENSAPI',
    packages=find_packages(),
    install_requires=[],
    url = 'https://github.com/sapiens-technology/SemanticComparison',
    license = 'Proprietary Software'
)
