::: mkdocs-typer2
    :module: omega_prime.cli
    :name: omega-prime
    :pretty: true