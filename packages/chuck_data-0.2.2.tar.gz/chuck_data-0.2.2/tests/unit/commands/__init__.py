"""
Test package for command handlers in src/commands.

This package contains unit tests for all command handlers.
"""
