"""Entry point for the render-engine PostgreSQL parser package."""

from render_engine_pg.cli.sql_cli import main

if __name__ == "__main__":
    main()
