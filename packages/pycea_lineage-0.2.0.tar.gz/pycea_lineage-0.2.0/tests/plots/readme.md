Folder for storing plots and figures.
