from siga_mcp.dynamic_constants import constantes_md

def docs() -> str:
    return constantes_md