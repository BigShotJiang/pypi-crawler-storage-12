Para poder generar el archivo de exportación confirming AEF, hay que
definir un modo de pago que use el tipo de pago "Confirming AEF". Para
ello, vaya a Facturación / Contabilidad \> Configuración \> Modos de
pago, y escoja el tipo de pago a realizar (Transferencia o cheque). La
modalidad de remesa es un campo opcional que deberá consultar con la
entidad bancaria para definir el valor correcto (1: Estándar, 2: Pronto
Pago, 3: Otros); en algunos casos es posible dejarlo vacío y en otros
únicamente aceptan uno.

El nº de contrato de Confirming será el valor asignado en el campo
Contrato AEF Confirming dentro del modo de pago creado anteriormente
