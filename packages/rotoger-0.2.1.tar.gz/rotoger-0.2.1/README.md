# rotoger

### environment variables
ROTOGER_LOG_PATH = "./logs"
ROTGER_MAX_BYTES = 10 * 1024 * 1024  # 10 MB
ROTOGER_BACKUP_COUNT = 5
