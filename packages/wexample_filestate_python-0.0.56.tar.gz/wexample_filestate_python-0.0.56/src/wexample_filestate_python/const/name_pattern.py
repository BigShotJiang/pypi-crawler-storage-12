from __future__ import annotations

# filestate: python-constant-sort
NAME_PATTERN_PYTHON_NOT_PYCACHE = "^(?!__pycache__$).+$"
