from __future__ import annotations

from pathlib import Path

PYTHON_FILE_PYTEST_COVERAGE_JSON: Path = Path("coverage.json")
PYTHON_FILE_EXTENSION = "py"
