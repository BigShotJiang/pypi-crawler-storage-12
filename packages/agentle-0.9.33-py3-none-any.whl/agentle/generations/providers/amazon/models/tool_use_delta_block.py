from typing import TypedDict


class ToolUseDeltaBlock(TypedDict):
    input: str  # JSON string representing partial input
