"""minchoc package."""
from __future__ import annotations

import django_stubs_ext

django_stubs_ext.monkeypatch()
__version__ = '0.1.0'
