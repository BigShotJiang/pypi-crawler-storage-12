This is what a typical directory of recipes would look like.  it could be hosted locally in a directory tree, on github, whatever.

Currently it lives in the starbash python blob, but eventually the 'master' set of recipes will live in a different repo.  In fact, different orgs could provide their own recipe repos.

FIXME:
For the time being we also have a few python scripts - until they are refactored a bit so they can live in the http tree.