selectolax.lexbor module
========================

.. automodule:: selectolax.lexbor

LexborHTMLParser
----------------

.. autoclass:: LexborHTMLParser
    :members:


LexborNode
----------

.. autoclass:: LexborNode
    :members:

Selector
--------

.. autoclass:: LexborSelector
    :members:
