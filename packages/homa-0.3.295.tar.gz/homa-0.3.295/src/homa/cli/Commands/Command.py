class Command:
    pass
