def invoke(base, *args, **kwargs):
    return base()(*args, **kwargs)
