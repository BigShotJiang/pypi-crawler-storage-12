import torch


class SoftActorCriticRepository:
    log_probability: None | torch.Tensor = None
