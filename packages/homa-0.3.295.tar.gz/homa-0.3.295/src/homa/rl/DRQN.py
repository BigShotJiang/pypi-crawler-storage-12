from .DQN import DQN


class DRQN(DQN):
    pass
