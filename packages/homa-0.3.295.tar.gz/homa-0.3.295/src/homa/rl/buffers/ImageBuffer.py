from .Buffer import Buffer


class ImageBuffer(Buffer):
    pass
