from .apb4_cpuif import APB4Cpuif
from .apb4_cpuif_flat import APB4CpuifFlat

__all__ = ["APB4Cpuif", "APB4CpuifFlat"]
