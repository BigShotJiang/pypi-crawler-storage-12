Addrmap/Regfile Properties
==========================

.. note:: Any properties not explicitly listed here are either implicitly
    supported, or are not relevant to the busdecoder exporter and are ignored.


errextbus
---------
|NO|

sharedextbus
------------
|NO|


--------------------------------------------------------------------------------

Addrmap Properties
==================

bigendian/littleendian
----------------------
|NO|

rsvdset
-------
|NO|
