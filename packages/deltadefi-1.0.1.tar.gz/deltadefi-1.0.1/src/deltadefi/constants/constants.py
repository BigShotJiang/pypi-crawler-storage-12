from typing import Literal

TradingPair = Literal["ADAUSDM"]
TradingSide = Literal["buy", "sell"]
TradingType = Literal["limit", "market"]
TimeInForce = Literal["GTC"]
