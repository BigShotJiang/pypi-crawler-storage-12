"""Internal package (no public API)."""

__all__: list[str] = []
