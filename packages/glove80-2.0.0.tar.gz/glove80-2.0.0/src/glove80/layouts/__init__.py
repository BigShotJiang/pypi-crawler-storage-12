"""Packaged metadata assets for shipped Glove80 layouts."""

from .builder import LayoutBuilder

__all__ = ["LayoutBuilder"]
