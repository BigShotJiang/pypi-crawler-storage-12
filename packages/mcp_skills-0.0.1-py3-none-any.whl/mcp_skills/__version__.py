#
# BSD 3-Clause License

"""MCP Skills."""

__version__ = "0.0.1"
