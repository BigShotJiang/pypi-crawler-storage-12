"""
FBA Finance Library - Core Module
Multi-source financial data aggregator with anti-rate-limiting
"""

__version__ = "0.1.1"
__author__ = "Fausto Bandini"

from .client import FinanceClient
from .models import Quote, HistoricalData, QuoteType
from .config import Config

# yfinance compatibility layer - allows: import fba_finance as yf
from .yfinance_compat import Ticker, download

# Screener module - get top tickers by market/sector
from .screener import (
    get_top_tickers,
    get_sector_tickers,
    get_market_tickers,
    get_available_sectors,
    get_ticker_count_by_market,
    get_ticker_count_by_sector,
)

__all__ = [
    # Core API
    "FinanceClient", 
    "Quote", 
    "HistoricalData", 
    "QuoteType", 
    "Config",
    # yfinance compatibility
    "Ticker",
    "download",
    # Screener
    "get_top_tickers",
    "get_sector_tickers",
    "get_market_tickers",
    "get_available_sectors",
    "get_ticker_count_by_market",
    "get_ticker_count_by_sector",
]
