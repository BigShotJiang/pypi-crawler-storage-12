"""Tests for proselint."""
