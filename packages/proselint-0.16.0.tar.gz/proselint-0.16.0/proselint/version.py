"""Proselint version number."""

from importlib.metadata import version

__version__ = version("proselint")
