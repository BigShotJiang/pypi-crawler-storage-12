__all__ = [
    "use_tailwind",
]


from ._index import use_tailwind
