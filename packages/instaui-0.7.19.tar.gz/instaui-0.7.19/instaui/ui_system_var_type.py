from typing import Literal


TSize = Literal["1", "2", "3", "4", "5", "6", "7", "8", "9"]
TWeight = Literal["light", "regular", "medium", "bold"]
TAlign = Literal["left", "center", "right"]
