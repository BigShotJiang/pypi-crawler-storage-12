from __future__ import annotations
from instaui.components.element import Element


class Form(Element):
    def __init__(self):
        super().__init__("form")
