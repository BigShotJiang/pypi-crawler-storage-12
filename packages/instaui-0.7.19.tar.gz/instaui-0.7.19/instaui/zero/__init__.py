from .scope import ZeroCaller as scope

__all__ = ["scope"]
