from typing import Literal


TFlush = Literal["pre", "post", "sync"]
