__all__ = ["mermaid"]

from instaui_mermaid import Mermaid as mermaid  # type: ignore
