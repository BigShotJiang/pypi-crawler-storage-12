__all__ = ["code"]

from instaui_shiki import shiki as code  # type: ignore
