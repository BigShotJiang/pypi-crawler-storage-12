
# Biblioteca cliente de sistema de almacenamiento basado en memoria

Biblioteca cliente para el sistema de almacenamiento en memoria "ESS v1". El cliente es capaz de cargar en datos memoria de forma local, enviar datos al sistema de almacenamiento en memoria y descargar datos del sistema de almacenamiento. 

UTILIZAR EN SISTEMA OPERATIVO LINUX.

## Authors

- [@juliocsp03](https://www.github.com/juliocsp03)


## License

[MIT](https://choosealicense.com/licenses/mit/)

