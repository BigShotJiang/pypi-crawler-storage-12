from .__version__ import __version__

__author__ = "Ryan R. <pwnfo@proton.me>"
__description__ = (
    f"Customizable wordlist generator with advanced pattern.\nDeveloped by {__author__}"
)
__name__ = "fuse"
__url__ = "https://github.com/pwnfo/fuse"
