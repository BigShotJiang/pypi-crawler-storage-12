===================
Statistical Summary
===================

This module provides functions to compute statistics summaries of Land Suitability Analysis results.

.. currentmodule:: lsapy.stats

.. autosummary::
   :toctree: generated/

   stats_summary
   spatial_stats_summary
