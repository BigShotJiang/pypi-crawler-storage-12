==========
Deprecated
==========

.. warning::

   The functions listed on this page are deprecated and will be removed in future versions of LSAPy.
   Users are advised to transition to the recommended alternatives as specified in the documentation for each function.

.. currentmodule:: lsapy
.. autosummary::
   :toctree: generated/

   SuitabilityFunction

.. autosummary::
   :toctree: generated/

   functions.boolean
   functions.discrete
   functions.logistic
   functions.sigmoid
   functions.vetharaniam2022_eq3
   functions.vetharaniam2022_eq5
   functions.vetharaniam2024_eq8
   functions.vetharaniam2024_eq10
