=====
Utils
=====

Utility functions for LSAPy.

.. currentmodule:: lsapy

.. autosummary::
   :toctree: generated/

   utils.open_data
