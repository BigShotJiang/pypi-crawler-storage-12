# LSAPy Branding

## Colours

Hexadecimal code of colors used in *LSAPy* logos.

| Color | Light | Dark |
| ------ | :--------: | :---------: |
| Green | #91a646ff | #6f8036ff |
| Yellow | #f2c12eff | #cca327ff |
| Orange | #e58004ff | #bf6b03ff |
| Blue | #7aadccff | #638da6ff |
| Red | #d91818ff | #b21414ff |
| Sand | #f2e6cdff | #ccc2adff |
| *Text* | #ffffffff | #364d5aff |

## Typeface

Primary : Arial - Bold Condensed.
