"""CLI package for rompy-oceanum oceanum integration."""

# Make the main CLI group available at package level
from .main import cli as main

__all__ = ["main"]
