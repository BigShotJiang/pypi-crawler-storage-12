from collections.abc import Iterable
from typing import Any, Callable, Optional

from dmp_af.conf import Config
from dmp_af.integrations.af_callbacks import prepare_custom_af_callbacks
from dmp_af.integrations.mcd import prepare_mcd_callbacks


def merge_dicts_by_key(*dicts: dict) -> dict:
    merged_dict: dict[str, list[Any]] = dict()

    for d in dicts:
        for key, value in d.items():
            merged_dict.setdefault(key, [])
            if isinstance(value, Iterable):
                merged_dict[key].extend(list(value))
            else:
                merged_dict[key].append(value)
    return merged_dict


def collect_af_custom_callbacks(
    config: Config,
) -> tuple[dict[str, list[Optional[Callable[..., Any]]]], dict[str, list[Optional[Callable[..., Any]]]]]:
    mcd_dag_callbacks, mcd_task_callbacks = prepare_mcd_callbacks(config)
    airflow_dag_callbacks, airflow_task_callbacks = prepare_custom_af_callbacks(config)

    dag_callbacks = merge_dicts_by_key(mcd_dag_callbacks, airflow_dag_callbacks)
    task_callbacks = merge_dicts_by_key(mcd_task_callbacks, airflow_task_callbacks)

    return dag_callbacks, task_callbacks
