from pythra import Colors


app_black = Colors.hex("#2c2c2c")
app_white = Colors.hex("#EDEDED")