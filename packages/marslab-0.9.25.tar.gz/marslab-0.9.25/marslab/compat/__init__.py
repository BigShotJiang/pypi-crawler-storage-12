"""
constants and functions intended specifically for compatibility with
the behavior of applications outside of this project _other than_
data / metadata format converters.
"""

# TODO: alias mcam, pcam, zcam
