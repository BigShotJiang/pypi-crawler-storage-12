from pathlib import Path

test_data_path = Path(__file__).parent
