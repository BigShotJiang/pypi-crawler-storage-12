from _from_dataclass import from_dataclass

__all__ = ["from_dataclass"]
__version__ = "0.1.2"