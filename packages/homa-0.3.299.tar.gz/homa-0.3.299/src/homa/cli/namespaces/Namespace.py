class Namespace:
    pass
