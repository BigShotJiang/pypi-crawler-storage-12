from .HasLabels import HasLabels
from .HasLogits import HasLogits
from .HasProbabilities import HasProbabilities
from .ReportsAccuracy import ReportsAccuracy
from .ReportsMetrics import ReportsMetrics
from .Trainable import Trainable
