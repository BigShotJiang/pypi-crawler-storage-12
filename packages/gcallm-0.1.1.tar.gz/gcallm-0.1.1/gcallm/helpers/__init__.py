"""Helper utilities for gcallm."""
