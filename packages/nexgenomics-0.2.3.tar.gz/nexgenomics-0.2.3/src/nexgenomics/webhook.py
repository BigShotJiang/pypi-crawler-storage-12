


def ping(name:str) -> str:
    """Just say hello, mostly to be sure the library installed.
    """
    return f"Hello, {name}"
