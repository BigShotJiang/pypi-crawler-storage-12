


def main():
    print ("NexGenomics CLI")
