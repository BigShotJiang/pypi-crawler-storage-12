
import unittest
from nexgenomics import threads
from nexgenomics import agents

class TestAgents(unittest.TestCase):
    def test_get_agents(self):
        print (agents.get_agents())




