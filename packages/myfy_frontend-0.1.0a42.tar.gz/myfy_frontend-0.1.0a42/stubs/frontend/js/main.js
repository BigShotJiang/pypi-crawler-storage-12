/**
 * Main JavaScript entry point
 *
 * Add your app-specific JavaScript here.
 */

console.log('myfy frontend loaded!')

// Example: Form validation, API calls, etc.
