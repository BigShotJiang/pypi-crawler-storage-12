"""Version information for myfy-frontend package."""

__version__ = "0.1.0a42"
