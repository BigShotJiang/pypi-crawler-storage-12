<div align="center">

# pureyak

Yet Another Kit: Python utilities built purely on the standard library

[![GitHub](https://img.shields.io/badge/github-code-blue?label=GitHub)](https://github.com/oyghen/pureyak)
[![PyPI](https://img.shields.io/pypi/v/pureyak?label=PyPI)](https://pypi.org/project/pureyak)
[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://github.com/oyghen/pureyak/blob/main/LICENSE)
[![CI](https://github.com/oyghen/pureyak/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/oyghen/pureyak/actions/workflows/ci.yml)

</div>

```shell
pip install pureyak
```
