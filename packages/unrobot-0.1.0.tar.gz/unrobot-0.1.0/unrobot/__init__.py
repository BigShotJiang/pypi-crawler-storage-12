__version__ = "0.1.0"
__author__ = 'Churros98'
__credits__ = 'Churros98'
