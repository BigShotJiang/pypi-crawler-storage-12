from .read_instance import read_instance as read_instance
from .read_solution import read_solution as read_solution
