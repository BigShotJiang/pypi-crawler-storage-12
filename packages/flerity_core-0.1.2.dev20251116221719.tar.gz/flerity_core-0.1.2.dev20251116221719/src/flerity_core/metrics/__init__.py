"""Metrics layer - Performance and business metrics."""
