"""Integration service for managing external provider connections."""
import uuid
from datetime import datetime, timedelta
from typing import Any
from uuid import UUID

import httpx
import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from ...config import config
from ...db.uow import async_uow_factory
from ...utils.clock import utcnow
from ...utils.domain_logger import get_domain_logger
from ...utils.errors import BadRequest, Conflict, NotFound
from ...utils.logging import get_safe_logger
from ...utils.redis_client import get_redis_client
from ...utils.request_tracking import RequestTracker
from ...utils.tracing import trace_async
from .repository import IntegrationRepository, WhatsAppPairingRepository
from .schemas import (
    IntegrationAccountCreate,
    IntegrationAccountOut,
    IntegrationAccountUpdate,
    IntegrationStatus,
    IntegrationType,
    WhatsAppPairingSessionCreate,
    WhatsAppPairingSessionOut,
    integrations_accounts_table,
)

logger = get_safe_logger(__name__)
domain_logger = get_domain_logger(__name__)


class IntegrationService:
    """Service for managing user integrations with external providers."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]):
        self.session_factory = session_factory

    @trace_async
    async def get_user_integrations(self, user_id: UUID) -> list[IntegrationAccountOut]:
        """Get user integration status."""
        async with async_uow_factory(self.session_factory, user_id=str(user_id))() as uow:
            repository = IntegrationRepository(uow.session)
            result: list[IntegrationAccountOut] = await repository.list_by_user(user_id)
            return result

    @trace_async
    async def get_integration(self, user_id: UUID, provider: IntegrationType) -> IntegrationAccountOut | None:
        """Get specific integration by provider."""
        async with async_uow_factory(self.session_factory, user_id=str(user_id))() as uow:
            repository = IntegrationRepository(uow.session)
            result: IntegrationAccountOut | None = await repository.get_by_user_provider(user_id, provider)
            return result

    @trace_async
    async def create_integration(
        self, user_id: UUID, provider: IntegrationType, external_user_id: str | None = None,
        meta: dict[str, Any] | None = None
    ) -> IntegrationAccountOut:
        """Create new integration."""
        try:
            async with async_uow_factory(self.session_factory, user_id=str(user_id))() as uow:
                repository = IntegrationRepository(uow.session)

                # Check if already exists
                existing = await repository.get_by_user_provider(user_id, provider)
                if existing:
                    raise Conflict(f"Integration {provider} already exists")

                create_data = IntegrationAccountCreate(
                    user_id=user_id,
                    provider=provider,
                    external_user_id=external_user_id,
                    status="connected",
                    meta=meta or {},
                    connected_at=utcnow()
                )

                result: IntegrationAccountOut = await repository.create(create_data)
                return result
        except Conflict:
            raise
        except Exception as e:
            logger.error("Failed to create integration", extra={
                "user_id": str(user_id), "provider": provider, "error": str(e)
            })
            raise BadRequest("Failed to create integration")

    @trace_async
    async def update_integration(
        self, user_id: UUID, provider: IntegrationType,
        status: IntegrationStatus | None = None, meta: dict[str, Any] | None = None
    ) -> IntegrationAccountOut | None:
        """Update integration."""
        try:
            async with async_uow_factory(self.session_factory, user_id=str(user_id))() as uow:
                repository = IntegrationRepository(uow.session)

                update_data = IntegrationAccountUpdate(
                    status=status,
                    meta=meta,
                    external_user_id=""
                )

                result: IntegrationAccountOut | None = await repository.update(user_id, provider, update_data)
                return result
        except Exception as e:
            logger.error("Failed to update integration", extra={
                "user_id": str(user_id), "provider": provider, "error": str(e)
            })
            raise BadRequest("Failed to update integration")

    @trace_async
    async def connect_integration(
        self, user_id: UUID, provider: IntegrationType,
        external_user_id: str, meta: dict[str, Any] | None = None
    ) -> IntegrationAccountOut:
        """Connect integration with external provider."""
        with RequestTracker(user_id=user_id, operation="connect_integration") as tracker:
            try:
                tracking_context = domain_logger.operation_start("connect_integration", user_id=str(user_id), provider=provider, external_user_id=external_user_id, has_meta=meta is not None)

                update_data = IntegrationAccountUpdate(
                    external_user_id=external_user_id,
                    status="connected",
                    meta=meta or {},
                    connected_at=utcnow()
                )

                async with async_uow_factory(self.session_factory, user_id=str(user_id))() as uow:
                    repository = IntegrationRepository(uow.session)

                    result: IntegrationAccountOut | None = await repository.update(user_id, provider, update_data)
                    if not result:
                        raise NotFound(f"Integration {provider} not found")

                    await uow.commit()
                    
                    domain_logger.operation_success(tracking_context, {
                        "user_id": str(user_id),
                        "provider": provider,
                        "external_user_id": external_user_id,
                        "integration_id": str(result.id)
                    })
                    domain_logger.business_event("integration_connected", {
                        "user_id": str(user_id),
                        "provider": provider,
                        "external_user_id": external_user_id,
                        "integration_id": str(result.id)
                    })
                    tracker.log_success(
                        provider=provider,
                        external_user_id=external_user_id,
                        integration_id=str(result.id)
                    )
                    
                    return result
            except NotFound:
                error_id = tracker.log_error(NotFound(f"Integration {provider} not found"), context={
                    "user_id": str(user_id),
                    "provider": provider
                })
                domain_logger.operation_error(tracking_context, f"Integration {provider} not found", {
                    "error_id": error_id,
                    "user_id": str(user_id),
                    "provider": provider
                })
                raise
            except Exception as e:
                error_id = tracker.log_error(e, context={
                    "user_id": str(user_id),
                    "provider": provider,
                    "external_user_id": external_user_id
                })
                domain_logger.operation_error(tracking_context, str(e), {
                    "error_id": error_id,
                    "user_id": str(user_id),
                    "provider": provider
                })
                raise BadRequest(f"Failed to connect integration (Error ID: {error_id})")

    @trace_async
    async def disconnect_integration(
        self, user_id: UUID, provider: IntegrationType, reason: str | None = None, locale: str = "en-US"
    ) -> IntegrationAccountOut | None:
        """Disconnect integration."""
        with RequestTracker(user_id=user_id, operation="disconnect_integration") as tracker:
            try:
                tracking_context = domain_logger.operation_start("disconnect_integration", user_id=str(user_id), provider=provider, reason=reason)

                async with async_uow_factory(self.session_factory, user_id=str(user_id))() as uow:
                    repository = IntegrationRepository(uow.session)

                    existing = await repository.get_by_user_provider(user_id, provider)
                    if not existing:
                        raise NotFound(f"Integration {provider} not found")

                    if existing.status == "disconnected":
                        domain_logger.operation_success(tracking_context, {
                            "user_id": str(user_id),
                            "provider": provider,
                            "already_disconnected": True
                        })
                        tracker.log_success(provider=provider, already_disconnected=True)
                        existing_result: IntegrationAccountOut = existing
                        return existing_result

                    # Clear auth data for security and update status
                    cleared_meta = {
                        "disconnected_at": utcnow().isoformat(),
                        "reason": reason or "user_requested"
                    }

                    update_data = IntegrationAccountUpdate(
                        status="disconnected",
                        meta=cleared_meta,
                        external_user_id=""
                    )

                    result: IntegrationAccountOut | None = await repository.update(user_id, provider, update_data)
                    await uow.commit()
                    
                    domain_logger.operation_success(tracking_context, {
                        "user_id": str(user_id),
                        "provider": provider,
                        "reason": reason,
                        "integration_id": str(result.id) if result else None
                    })
                    domain_logger.business_event("integration_disconnected", {
                        "user_id": str(user_id),
                        "provider": provider,
                        "reason": reason or "user_requested",
                        "integration_id": str(result.id) if result else None
                    })
                    tracker.log_success(
                        provider=provider,
                        reason=reason,
                        integration_id=str(result.id) if result else None
                    )
                    
                    return result
            except NotFound:
                error_id = tracker.log_error(NotFound(f"Integration {provider} not found"), context={
                    "user_id": str(user_id),
                    "provider": provider
                })
                domain_logger.operation_error(tracking_context, f"Integration {provider} not found", {
                    "error_id": error_id,
                    "user_id": str(user_id),
                    "provider": provider
                })
                raise
            except Exception as e:
                error_id = tracker.log_error(e, context={
                    "user_id": str(user_id),
                    "provider": provider,
                    "reason": reason
                })
                domain_logger.operation_error(tracking_context, str(e), {
                    "error_id": error_id,
                    "user_id": str(user_id),
                    "provider": provider
                })
                raise BadRequest(f"Failed to disconnect integration (Error ID: {error_id})")

    @trace_async
    async def delete_integration(self, user_id: UUID, provider: IntegrationType) -> None:
        """Delete integration."""
        with RequestTracker(user_id=user_id, operation="delete_integration") as tracker:
            try:
                tracking_context = domain_logger.operation_start("delete_integration", user_id=str(user_id), 
                                            context={"provider": provider})
                
                async with async_uow_factory(self.session_factory, user_id=str(user_id))() as uow:
                    repository = IntegrationRepository(uow.session)
                    await repository.delete(user_id, provider)
                
                domain_logger.operation_success(tracking_context, user_id=str(user_id))
                domain_logger.business_event("integration_deleted", user_id=str(user_id), 
                                           context={"provider": provider})
                
                tracker.log_success()
                
            except Exception as e:
                error_id = tracker.log_error(e, context={"user_id": str(user_id), "provider": provider})
                domain_logger.operation_error(tracking_context, error_id=error_id, user_id=str(user_id))
                logger.error("Failed to delete integration", extra={
                    "user_id": str(user_id), "provider": provider, "error": str(e)
                })
                raise BadRequest("Failed to delete integration")

    @trace_async
    async def integration_exists(self, user_id: UUID, provider: IntegrationType) -> bool:
        """Check if integration exists."""
        with RequestTracker(user_id=user_id, operation="integration_exists") as tracker:
            try:
                tracking_context = domain_logger.operation_start("integration_exists", user_id=str(user_id), 
                                            context={"provider": provider})
                
                async with async_uow_factory(self.session_factory, user_id=str(user_id))() as uow:
                    repository = IntegrationRepository(uow.session)
                    result: bool = await repository.exists(user_id, provider)
                
                domain_logger.operation_success(tracking_context, user_id=str(user_id), 
                                              context={"exists": result})
                
                tracker.log_success(result_id=str(result))
                return result
                
            except Exception as e:
                error_id = tracker.log_error(e, context={"user_id": str(user_id), "provider": provider})
                domain_logger.operation_error(tracking_context, error_id=error_id, user_id=str(user_id))
                raise BadRequest("Failed to check integration existence")

    @trace_async
    async def generate_instagram_auth_url(self, user_id: UUID) -> dict[str, str]:
        """Generate Instagram OAuth authorization URL."""
        with RequestTracker(user_id=user_id, operation="generate_instagram_auth_url") as tracker:
            try:
                tracking_context = domain_logger.operation_start("generate_instagram_auth_url", user_id=str(user_id))
                
                if not config.META_APP_ID or not config.META_APP_SECRET:
                    error_id = tracker.log_error(BadRequest("Instagram integration not configured"), context={
                        "user_id": str(user_id)
                    })
                    domain_logger.operation_error(tracking_context, error_id=error_id, 
                                                user_id=str(user_id))
                    raise BadRequest("Instagram integration not configured")

                # Generate state for CSRF protection
                state = str(uuid.uuid4())

                # Store state data in Redis
                state_data = {
                    "user_id": str(user_id),
                    "timestamp": utcnow().isoformat()
                }

                redis_client = get_redis_client()
                key = f"instagram_oauth_state:{state}"

                try:
                    await redis_client.set(key, state_data, ex=3600)  # 1 hour expiration
                    logger.info("Instagram OAuth state stored", extra={
                        "user_id": str(user_id), "state": state
                    })
                except Exception as e:
                    error_id = tracker.log_error(e, context={
                        "user_id": str(user_id), "state": state
                    })
                    domain_logger.operation_error(tracking_context, error_id=error_id,
                                                user_id=str(user_id))
                    logger.error("Failed to store Instagram OAuth state", extra={
                        "user_id": str(user_id), "error": str(e)
                    })
                    raise BadRequest("Failed to initialize OAuth flow")

                # Use webhook.flerity.com for all environments
                redirect_uri = "https://webhook.flerity.com/integrations/instagram/callback"

                # Instagram OAuth scopes
                scopes = ["instagram_business_basic", "instagram_business_manage_messages"]

                # Build authorization URL
                auth_url = (
                    f"https://www.instagram.com/oauth/authorize"
                    f"?client_id={config.META_APP_ID}"
                    f"&redirect_uri={redirect_uri}"
                    f"&scope={','.join(scopes)}"
                    f"&response_type=code"
                    f"&state={state}"
                )

                result = {"authorization_url": auth_url, "state": state}
                
                domain_logger.operation_success(tracking_context, user_id=str(user_id))
                domain_logger.business_event("instagram_auth_url_generated", user_id=str(user_id), 
                                           context={"state": state})
                
                tracker.log_success(result_id=state)
                return result
                
            except BadRequest:
                raise
            except Exception as e:
                error_id = tracker.log_error(e, context={"user_id": str(user_id)})
                domain_logger.operation_error(tracking_context, error_id=error_id,
                                            user_id=str(user_id))
                raise BadRequest("Failed to generate Instagram auth URL")

    @trace_async
    async def process_instagram_webhook(self, payload: dict[str, Any]) -> None:
        """Process Instagram webhook messages, edits, reactions."""
        with RequestTracker(operation="process_instagram_webhook") as tracker:
            try:
                tracking_context = domain_logger.operation_start("process_instagram_webhook", 
                                            context={"entry_count": len(payload.get("entry", []))})
                
                logger.debug("Processing Instagram webhook", extra={
                    "has_payload": bool(payload),
                    "entry_count": len(payload.get("entry", []))
                })

                for entry in payload.get("entry", []):
                    # Handle both 'changes' (old format) and 'messaging' (new format)
                    changes = entry.get("changes", [])
                    messaging = entry.get("messaging", [])

                    # Process changes format
                    for change in changes:
                        field = change.get("field")

                        # Só processa mensagens, edições, reações e visualizações
                        if field not in ["messages", "message_edit", "message_reactions", "messaging_seen"]:
                            logger.debug("Skipping non-message field", extra={"field": field})
                            continue

                        value = change.get("value", {})
                        await self._process_instagram_event(value, field)

                    # Process messaging format
                    for message_event in messaging:
                        # Determinar o tipo de evento baseado nos campos presentes
                        if "message" in message_event:
                            await self._process_instagram_event(message_event, "messages")
                        elif "read" in message_event:
                            await self._process_instagram_event(message_event, "messaging_seen")
                        elif "reaction" in message_event:
                            await self._process_instagram_event(message_event, "message_reactions")
                        elif "message_edit" in message_event:
                            await self._process_instagram_event(message_event, "message_edit")
                        else:
                            logger.warning("Unknown Instagram event type", extra={
                                "event": message_event
                            })

                domain_logger.operation_success(tracking_context, 
                                              context={"entries_processed": len(payload.get("entry", []))})
                domain_logger.business_event("instagram_webhook_processed", 
                                           context={"entries_count": len(payload.get("entry", []))})
                
                tracker.log_success()
                
            except Exception as e:
                error_id = tracker.log_error(e, context={"payload_keys": list(payload.keys()) if payload else []})
                domain_logger.operation_error(tracking_context, error_id=error_id)
                raise

    async def _process_instagram_event(self, value: dict[str, Any], field: str) -> None:
        """Process individual Instagram event."""
        sender_id = value.get("sender", {}).get("id")
        recipient_id = value.get("recipient", {}).get("id")
        message = value.get("message", {})
        is_echo = message.get("is_echo", False)

        logger.debug("Instagram event received", extra={
            "field": field,
            "has_sender": bool(sender_id),
            "has_recipient": bool(recipient_id),
            "is_echo": is_echo
        })

        if not sender_id or not recipient_id:
            logger.warning("Missing sender or recipient", extra={
                "has_sender": bool(sender_id),
                "has_recipient": bool(recipient_id)
            })
            return

        # Determine our user ID based on echo status
        if is_echo:
            # Echo message: sender is our user, recipient is external contact
            our_instagram_id = sender_id
            contact_instagram_id = recipient_id
            logger.debug("Echo message detected", extra={
                "has_our_user": bool(our_instagram_id),
                "has_contact": bool(contact_instagram_id)
            })
        else:
            # Regular message: recipient is our user, sender is external contact
            our_instagram_id = recipient_id
            contact_instagram_id = sender_id

        try:
            # 1. Encontrar nosso usuário pela integração Instagram
            our_user_id = await self._find_user_by_instagram_id(our_instagram_id)

            if not our_user_id:
                logger.warning("No user found for Instagram ID")
                return

            # 2. Buscar ou criar thread (com retry para cache invalidation)
            max_retries = 2
            for attempt in range(max_retries):
                try:
                    async with async_uow_factory(self.session_factory, user_id=str(our_user_id))() as uow:
                        thread = await self._get_or_create_instagram_thread(
                            uow.session, our_user_id, contact_instagram_id
                        )

                        # 3. Processar mensagem baseada no tipo
                        await self._save_instagram_message(
                            uow.session, thread["id"], field, value
                        )

                        # 4. Sempre atualizar last_activity da thread (mesmo para eventos não salvos)
                        from flerity_core.domain.threads.schemas import threads_table
                        update_stmt = sa.update(threads_table).where(
                            threads_table.c.id == thread["id"]
                        ).values(last_activity=utcnow())
                        await uow.session.execute(update_stmt)

                        await uow.commit()
                        break  # Success, exit retry loop

                except sa.exc.NotSupportedError as e:
                    if "InvalidCachedStatementError" in str(e) and attempt < max_retries - 1:
                        logger.warning("Database cache invalidated, retrying", extra={
                            "attempt": attempt + 1,
                            "error": str(e)
                        })
                        continue
                    else:
                        raise
                except Exception:
                    raise

            logger.info("Instagram message processed", extra={
                "user_id": str(our_user_id),
                "thread_id": str(thread["id"]),
                "field": field,
                "sender_id": sender_id,
                "is_echo": is_echo
            })

        except Exception as e:
            logger.error("Failed to process Instagram message", extra={
                "error": str(e),
                "sender_id": sender_id,
                "recipient_id": recipient_id,
                "field": field
            })
            raise

    async def _find_user_by_instagram_id(self, instagram_id: str) -> UUID | None:
        """Find our user by their Instagram external_user_id."""

        async with async_uow_factory(self.session_factory)() as uow:
            # First, let's see all Instagram integrations
            debug_stmt = sa.select(
                integrations_accounts_table.c.user_id,
                integrations_accounts_table.c.external_user_id,
                integrations_accounts_table.c.status,
                integrations_accounts_table.c.provider
            ).where(integrations_accounts_table.c.provider == "instagram")

            debug_result = await uow.session.execute(debug_stmt)
            debug_rows = debug_result.fetchall()
            for row in debug_rows:
                pass  # Debug loop

            # Now the actual lookup
            stmt = sa.select(integrations_accounts_table.c.user_id).where(
                integrations_accounts_table.c.provider == "instagram",
                integrations_accounts_table.c.external_user_id == instagram_id,
                integrations_accounts_table.c.status == "connected"
            )
            result = await uow.session.execute(stmt)
            row = result.fetchone()
            found_user = row[0] if row else None  # Already a UUID object, no conversion needed
            return found_user

    @trace_async
    async def _get_instagram_access_token(self, user_id: UUID) -> dict[str, Any] | None:
        """Get Instagram access token for user."""
        async with async_uow_factory(self.session_factory, user_id=str(user_id))() as uow:
            stmt = sa.select(
                integrations_accounts_table.c.meta,
                integrations_accounts_table.c.connected_at
            ).where(
                integrations_accounts_table.c.user_id == user_id,
                integrations_accounts_table.c.provider == "instagram",
                integrations_accounts_table.c.status == "connected"
            )
            result = await uow.session.execute(stmt)
            row = result.fetchone()

            if not row:
                return None

            meta = row[0] or {}
            access_token = meta.get("access_token")

            if not access_token:
                return None

            return {
                "access_token": access_token,
                "connected_at": row[1],
                "meta": meta
            }

    @trace_async
    async def _refresh_instagram_token(self, current_token: str) -> str | None:
        """Refresh Instagram access token."""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    "https://graph.instagram.com/refresh_access_token",
                    params={
                        "grant_type": "ig_refresh_token",
                        "access_token": current_token
                    },
                    timeout=30.0
                )

                if response.status_code == 200:
                    data = response.json()
                    return data.get("access_token")
                else:
                    logger.warning("Failed to refresh Instagram token", extra={
                        "status_code": response.status_code,
                        "response_length": len(response.text)
                    })
                    return None

        except Exception as e:
            logger.error("Error refreshing Instagram token", extra={"error": str(e)})
            return None

    @trace_async
    async def _get_instagram_user_info(self, user_instagram_id: str, access_token: str) -> dict[str, Any] | None:
        """Get Instagram user information via Graph API."""
        try:
            url = f"https://graph.instagram.com/v24.0/{user_instagram_id}?access_token={access_token}"

            async with httpx.AsyncClient() as client:
                response = await client.get(url, timeout=30.0)

                if response.status_code == 200:
                    return response.json()
                else:
                    logger.warning("Failed to get Instagram user info", extra={
                        "status_code": response.status_code,
                        "response_length": len(response.text)
                    })
                    return None

        except Exception as e:
            logger.error("Error getting Instagram user info", extra={
                "error": str(e)
            })
            return None

    @trace_async
    async def get_instagram_username(self, user_id: UUID, contact_instagram_id: str) -> dict[str, str]:
        """Get real Instagram username and profile pic for contact."""
        try:
            # 1. Get access token
            token_info = await self._get_instagram_access_token(user_id)
            if not token_info:
                return {
                    "name": f"Instagram User {contact_instagram_id}",
                    "profile_pic": None
                }

            access_token = token_info["access_token"]
            connected_at = token_info["connected_at"]

            # 2. Check if token needs refresh (> 50 days)
            if connected_at and connected_at < utcnow() - timedelta(days=50):
                logger.info("Refreshing Instagram token", extra={"user_id": str(user_id)})
                new_token = await self._refresh_instagram_token(access_token)

                if new_token:
                    # Update token in database
                    async with async_uow_factory(self.session_factory, user_id=str(user_id))() as uow:
                        new_meta = token_info["meta"].copy()
                        new_meta["access_token"] = new_token

                        stmt = sa.update(integrations_accounts_table).where(
                            integrations_accounts_table.c.user_id == user_id,
                            integrations_accounts_table.c.provider == "instagram"
                        ).values(
                            meta=new_meta,
                            connected_at=utcnow()
                        )
                        await uow.session.execute(stmt)
                        await uow.commit()

                    access_token = new_token
                else:
                    logger.warning("Failed to refresh token, using old one", extra={"user_id": str(user_id)})

            # 3. Get user info from Graph API
            user_info = await self._get_instagram_user_info(contact_instagram_id, access_token)

            if user_info:
                # Prefer name over username, fallback to generic
                name = user_info.get("name") or user_info.get("username") or f"Instagram User {contact_instagram_id}"
                username = user_info.get("username") or f"user_{contact_instagram_id}"
                profile_pic = user_info.get("profile_pic")
                return {
                    "name": name,
                    "username": username,
                    "profile_pic": profile_pic
                }
            else:
                return {
                    "name": f"Instagram User {contact_instagram_id}",
                    "username": f"user_{contact_instagram_id}",
                    "profile_pic": None
                }

        except Exception as e:
            logger.error("Error getting Instagram username", extra={
                "user_id": str(user_id),
                "contact_id": contact_instagram_id,
                "error": str(e)
            })
            return {
                "name": f"Instagram User {contact_instagram_id}",
                "username": f"user_{contact_instagram_id}",
                "profile_pic": None
            }

    async def _get_or_create_instagram_thread(self, session, user_id: UUID, contact_instagram_id: str) -> dict:
        """Get existing thread or create new one for Instagram contact."""
        from flerity_core.domain.threads.schemas import threads_table

        # Buscar thread existente usando contact_id (Instagram ID é imutável)
        stmt = sa.select(threads_table).where(
            threads_table.c.user_id == user_id,
            threads_table.c.channel == "instagram",
            threads_table.c.contact_id == contact_instagram_id
        )
        result = await session.execute(stmt)
        row = result.fetchone()

        if row:
            existing_thread = dict(row._mapping)

            # Se thread existe mas tem nome genérico, tentar buscar nome real
            if existing_thread['contact_name'].startswith('Instagram User'):
                user_data = await self.get_instagram_username(user_id, contact_instagram_id)

                # Atualizar thread com nome real se conseguiu buscar
                if not user_data["name"].startswith('Instagram User'):
                    update_stmt = sa.update(threads_table).where(
                        threads_table.c.id == existing_thread['id']
                    ).values(
                        contact_name=user_data["name"],
                        contact_handle=user_data["username"],
                        contact_profile_pic=user_data["profile_pic"]
                    )
                    await session.execute(update_stmt)
                    existing_thread['contact_name'] = user_data["name"]
                    existing_thread['contact_handle'] = user_data["username"]
                    existing_thread['contact_profile_pic'] = user_data["profile_pic"]

            return existing_thread

        # Buscar nome real do usuário antes de criar thread
        user_data = await self.get_instagram_username(user_id, contact_instagram_id)

        # Criar nova thread com nome real
        thread_data = {
            "user_id": user_id,
            "channel": "instagram",
            "contact_id": contact_instagram_id,
            "contact_handle": user_data["username"],
            "contact_name": user_data["name"],
            "contact_profile_pic": user_data["profile_pic"],
            "last_activity": utcnow()
        }

        stmt = sa.insert(threads_table).values(**thread_data).returning(threads_table)
        result = await session.execute(stmt)
        row = result.fetchone()
        new_thread = dict(row._mapping)

        # Ativar assistência por padrão para novas threads
        try:
            from flerity_core.domain.threads.tracking.repository import ThreadTrackingRepository
            from flerity_core.domain.threads.tracking.schemas import (
                ThreadTrackingConfigurationCreate,
            )

            tracking_repo = ThreadTrackingRepository(session)
            tracking_config = ThreadTrackingConfigurationCreate(
                thread_id=new_thread['id'],
                is_active=True
            )
            await tracking_repo.create(tracking_config, user_id)

            logger.info("Thread tracking auto-enabled for new thread", extra={
                "thread_id": str(new_thread['id']),
                "user_id": str(user_id),
                "channel": "instagram",
                "contact_id": contact_instagram_id
            })
        except Exception as e:
            # Não falhar a criação da thread se o tracking falhar
            logger.warning("Failed to auto-enable tracking for new thread", extra={
                "thread_id": str(new_thread['id']),
                "user_id": str(user_id),
                "error": str(e)
            })

        return new_thread

    async def _save_instagram_message(self, session, thread_id: UUID, field: str, value: dict[str, Any]) -> None:
        """Save Instagram message/edit/reaction to messages table."""

        from flerity_core.domain.threads.schemas import messages_table


        # Determinar se é mensagem enviada ou recebida
        is_echo = value.get("message", {}).get("is_echo", False)
        sender_type = "user" if is_echo else "contact"

        # Extrair dados baseado no tipo
        message_data = {
            "thread_id": thread_id,
            "sender": sender_type,  # "user" para enviadas, "contact" para recebidas
            "timestamp": utcnow(),
            "metadata": {
                "instagram_user_id": value.get("sender", {}).get("id"),
                "field_type": field,
                "is_echo": is_echo,
                "raw_payload": value
            }
        }

        if field == "messages":
            message = value.get("message", {})
            message_data["text"] = message.get("text")
            message_data["metadata"]["instagram_message_id"] = message.get("mid")

        elif field == "message_edit":
            edit = value.get("message_edit", {})
            message_data["text"] = f"[EDITADO] {edit.get('text', '')}"
            message_data["metadata"]["instagram_message_id"] = edit.get("mid")
            message_data["metadata"]["edit_number"] = edit.get("num_edit")

        elif field == "message_reactions":
            reaction = value.get("reaction", {})
            emoji = reaction.get("emoji", "")
            message_data["text"] = emoji
            message_data["metadata"]["instagram_message_id"] = reaction.get("mid")
            message_data["metadata"]["reaction_type"] = reaction.get("reaction")

        elif field == "messaging_seen":
            read = value.get("read", {})
            message_data["text"] = "seen"
            message_data["metadata"]["last_read_message_id"] = read.get("mid")
            message_data["metadata"]["read_timestamp"] = value.get("timestamp")


        # Inserir mensagem (sempre, mesmo se null - filtraremos na API)
        stmt = sa.insert(messages_table).values(**message_data)
        await session.execute(stmt)

        # Verificar se a mensagem foi inserida
        verify_stmt = sa.select(sa.func.count()).select_from(messages_table).where(
            messages_table.c.thread_id == thread_id
        )
        count_result = await session.execute(verify_stmt)
        count_result.scalar()



class WhatsAppPairingService:
    """Service for WhatsApp pairing sessions."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]):
        self.session_factory = session_factory

    @trace_async
    async def create_pairing_session(
        self, user_id: UUID, session_code: str, expires_at: datetime
    ) -> WhatsAppPairingSessionOut:
        """Create new pairing session."""
        try:
            async with async_uow_factory(self.session_factory, user_id=str(user_id))() as uow:
                repository = WhatsAppPairingRepository(uow.session)

                session_data = WhatsAppPairingSessionCreate(
                    user_id=user_id,
                    session_code=session_code,
                    expires_at=expires_at,
                    status="issued"
                )

                result: WhatsAppPairingSessionOut = await repository.create_session(session_data)
                return result
        except Exception as e:
            logger.error("Failed to create pairing session", extra={
                "user_id": str(user_id), "session_code": session_code, "error": str(e)
            })
            raise BadRequest("Failed to create pairing session")

    @trace_async
    async def get_session_by_code(self, session_code: str, user_id: UUID | None = None) -> WhatsAppPairingSessionOut | None:
        """Get pairing session by code."""
        # Use system context for session lookup by code
        async with async_uow_factory(self.session_factory, user_id=str(user_id) if user_id else None)() as uow:
            repository = WhatsAppPairingRepository(uow.session)
            result: WhatsAppPairingSessionOut | None = await repository.get_by_code(session_code)
            return result

    @trace_async
    async def get_user_sessions(self, user_id: UUID) -> list[WhatsAppPairingSessionOut]:
        """Get WhatsApp pairing sessions for user."""
        async with async_uow_factory(self.session_factory, user_id=str(user_id))() as uow:
            repository = WhatsAppPairingRepository(uow.session)
            result: list[WhatsAppPairingSessionOut] = await repository.get_by_user(user_id)
            return result

    @trace_async
    async def consume_pairing_code(self, session_code: str) -> WhatsAppPairingSessionOut:
        """Consume WhatsApp pairing code."""
        try:
            # Use system context for consuming pairing codes
            async with async_uow_factory(self.session_factory, user_id=None)() as uow:
                repository = WhatsAppPairingRepository(uow.session)

                session = await repository.get_by_code(session_code)
                if not session:
                    raise NotFound("Pairing session not found")

                if session.status != "issued":
                    raise BadRequest(f"Pairing session is {session.status}")

                # Update session status
                result: WhatsAppPairingSessionOut = await repository.update_status(session.id, "consumed")
                return result
        except (NotFound, BadRequest):
            raise
        except Exception as e:
            logger.error("Failed to consume pairing code", extra={
                "session_code": session_code, "error": str(e)
            })
            raise BadRequest("Failed to consume pairing code")

    @trace_async
    async def expire_old_sessions(self) -> int:
        """Expire old pairing sessions."""
        try:
            # Use system context for cleanup operations
            async with async_uow_factory(self.session_factory, user_id=None)() as uow:
                repository = WhatsAppPairingRepository(uow.session)
                result: int = await repository.expire_old_sessions()
                return result
        except Exception as e:
            logger.error("Failed to expire old sessions", extra={"error": str(e)})
            raise BadRequest("Failed to expire sessions")


def create_integration_service(session_factory: async_sessionmaker[AsyncSession]) -> IntegrationService:
    """Factory function for IntegrationService."""
    return IntegrationService(session_factory)


def create_whatsapp_pairing_service(session_factory: async_sessionmaker[AsyncSession]) -> WhatsAppPairingService:
    """Factory function for WhatsAppPairingService."""
    return WhatsAppPairingService(session_factory)
