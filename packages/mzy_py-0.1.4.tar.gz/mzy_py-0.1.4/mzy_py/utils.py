def print_info():
    """打印包信息"""
    print("这是我的第一个开源pip包！")


def plus_mzy(a, b):
    """两个数相加"""
    return a + b

def minus_mzy(a, b):
    """两个数相减"""
    return a - b

def print_my_name_mzy() -> str:
    """Return personal intro."""
    print("My name is Mzy, I am a student in BPU.")
