import{c as e}from"./index-Cp0jSp7c.js";const t=[["path",{d:"M14.5 2v17.5c0 1.4-1.1 2.5-2.5 2.5c-1.4 0-2.5-1.1-2.5-2.5V2",key:"125lnx"}],["path",{d:"M8.5 2h7",key:"csnxdl"}],["path",{d:"M14.5 16h-5",key:"1ox875"}]],o=e("test-tube",t);export{o as T};
//# sourceMappingURL=test-tube-d7I2egXk.js.map
