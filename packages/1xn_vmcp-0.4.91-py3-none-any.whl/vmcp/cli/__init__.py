"""vMCP CLI - Command Line Interface for Virtual MCP."""

from vmcp.cli.main import app

__all__ = ['app']
