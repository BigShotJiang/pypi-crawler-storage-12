# Flint

A BLAZING FAST Cloud Development Kit with a chance of meatballs.

To generate actual code from the protobuf files run `python3 bufbodge.py` to fix python imports (make sure you have buf installed and authed)