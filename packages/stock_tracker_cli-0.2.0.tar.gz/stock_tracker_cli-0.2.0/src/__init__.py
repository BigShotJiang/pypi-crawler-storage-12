"""Stock Tracker CLI - A tool to track stock portfolios and get AI-powered analysis."""

__version__ = "0.2.0"
