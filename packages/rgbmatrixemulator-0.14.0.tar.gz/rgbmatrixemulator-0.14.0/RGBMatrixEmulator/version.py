#!/usr/bin/env python

# package version
__version__ = "0.14.0"
"""Installed version of RGBMatrixEmulator."""
