from dataclasses import dataclass
from .account_assets import AccountAssets

@dataclass
class Account(AccountAssets):
  ...