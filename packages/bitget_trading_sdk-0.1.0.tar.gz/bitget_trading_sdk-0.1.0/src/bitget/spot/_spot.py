from dataclasses import dataclass
from .account import Account

@dataclass
class Spot(Account):
  ...