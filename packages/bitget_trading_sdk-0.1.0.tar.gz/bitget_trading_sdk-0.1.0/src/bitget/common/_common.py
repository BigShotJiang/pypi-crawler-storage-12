from dataclasses import dataclass
from .assets import Assets

@dataclass
class Common(Assets):
  ...