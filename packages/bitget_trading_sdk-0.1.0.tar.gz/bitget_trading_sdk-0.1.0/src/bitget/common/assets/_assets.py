from dataclasses import dataclass
from .assets_overview import AssetsOverview

@dataclass
class Assets(AssetsOverview):
  ...