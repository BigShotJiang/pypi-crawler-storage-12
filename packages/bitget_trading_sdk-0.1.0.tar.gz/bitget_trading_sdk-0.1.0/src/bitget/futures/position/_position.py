from dataclasses import dataclass
from .all_positions import AllPositions

@dataclass
class Position(AllPositions):
  ...