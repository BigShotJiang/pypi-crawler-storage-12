from typing_extensions import Literal

ProductType = Literal['USDT-FUTURES', 'USDC-FUTURES', 'COIN-FUTURES']