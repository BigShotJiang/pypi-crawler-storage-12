from dataclasses import dataclass
from .subaccount_assets import SubaccountAssets

@dataclass
class Account(SubaccountAssets):
  ...