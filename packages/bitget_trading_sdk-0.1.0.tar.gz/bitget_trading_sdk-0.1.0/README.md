# Bitget

> The unofficial, fully-typed async Python SDK for Bitget, by Tribulnation.
