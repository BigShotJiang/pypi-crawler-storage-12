"""Test suite for tanabesugano package."""
