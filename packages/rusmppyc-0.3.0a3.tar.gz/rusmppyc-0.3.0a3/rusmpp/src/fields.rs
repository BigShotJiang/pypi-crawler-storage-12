//! `SMPP` Fields.

pub use rusmpp_core::fields::*;
