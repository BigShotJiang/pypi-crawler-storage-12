class Formats:
    JSON = 'JSON'
    EXCEL = 'EXCEL'
    CSV = 'CSV'
    JSON_AND_EXCEL = ['JSON', 'EXCEL']
    JSON_AND_CSV = ['JSON', 'CSV']
