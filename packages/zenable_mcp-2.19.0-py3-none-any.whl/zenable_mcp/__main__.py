"""Allow zenable_mcp to be run as a module with python -m zenable_mcp."""

from zenable_mcp import main

if __name__ == "__main__":
    main()
