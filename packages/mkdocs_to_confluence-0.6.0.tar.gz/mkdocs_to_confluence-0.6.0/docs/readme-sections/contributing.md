---
title: Contributing for README
---

Contributions are welcome! See the [Contributing Guide](https://jmanteau.github.io/mkdocs-to-confluence/contributing/) for details.

**Quick start:**

```bash
git clone https://github.com/jmanteau/mkdocs-to-confluence.git
cd mkdocs-to-confluence
make py-setup
make py-test
```
