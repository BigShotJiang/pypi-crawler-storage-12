"""Vendored dependencies for mkdocs-to-confluence.

This package contains third-party libraries that are bundled with
mkdocs-to-confluence to avoid external dependency issues.
"""
