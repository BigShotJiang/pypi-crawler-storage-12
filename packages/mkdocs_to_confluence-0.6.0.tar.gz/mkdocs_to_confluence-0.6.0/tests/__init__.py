"""Tests for mkdocs-with-confluence."""
