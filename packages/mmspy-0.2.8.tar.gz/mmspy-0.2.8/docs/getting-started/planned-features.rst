Planned features
================

*This page is still under construction*

There are many planned features to this packages, which will be
gradually added in a couple of days as of this release (June 23rd, 2025). 
