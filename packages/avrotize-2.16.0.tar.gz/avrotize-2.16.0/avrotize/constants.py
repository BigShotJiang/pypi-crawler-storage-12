"""Constants for the avrotize package."""

AVRO_VERSION = '1.12.0'
JACKSON_VERSION = '2.18.2'
JDK_VERSION = '21'