"""
PyMPDATA 1D advection-diffusion example with error analysis for different initial parameters.

demo.ipynb:
.. include:: ./demo.ipynb.badges.md
"""
