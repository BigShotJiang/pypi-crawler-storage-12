"""
This example demonstrates the use of the Double-Pass Donor-Cell option in `PyMPDATA.options`.

demo.ipynb:
.. include:: ./demo.ipynb.badges.md
"""
