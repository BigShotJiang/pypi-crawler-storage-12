# Quber Workflow

Shared Claude Code workflow for Quber projects (Jira + GitHub automation).

[![PyPI](https://img.shields.io/pypi/v/quber-workflow)](https://pypi.org/project/quber-workflow/)
[![Python](https://img.shields.io/pypi/pyversions/quber-workflow)](https://pypi.org/project/quber-workflow/)
[![License](https://img.shields.io/github/license/xmandeng/quber-workflow)](LICENSE)

## Overview

`quber-workflow` provides a standardized Claude Code workflow across all Quber projects, including:

- **Jira Workflow Agent** - Automated Jira issue management
- **GitHub Workflow Agent** - Automated PR and branch workflows
- **Skills** - Bash scripts for Jira and GitHub operations
- **GitHub Actions** - Automated Jira status transitions
- **Documentation** - Workflow specs and PR evidence guidelines

## Features

-  **Deny-by-default permissions** - Enforces proper agent delegation
-  **Git worktree workflow** - Prevents branch pollution
-  **Jira automation** - Status transitions on branch/PR events
-  **PR evidence requirements** - Embedded quality standards
-  **Context-efficient** - 95%+ reduction vs MCP servers

## Installation

```bash
# Using pip
pip install quber-workflow

# Using uv (recommended)
uv pip install quber-workflow
```

## Usage

### Initialize New Project

```bash
# Navigate to your project directory
cd my-quber-project

# Initialize workflow
quber-workflow init \
  --project=my-project \
  --package=my_project \
  --repo=username/my-project \
  --jira-key=QUE
```

This creates:

- `.claude/agents/` - jira-workflow and github-workflow agents
- `.claude/skills/` - jira-operations and github-operations skills
- `.claude/settings.json` - deny-based permissions
- `.github/workflows/jira-transition.yml` - Jira automation
- `docs/` - workflow specifications and guidelines

### Update Existing Project

```bash
# Update workflow files to latest version
quber-workflow update
```

### Migrate Existing Project

```bash
# Migrate with automatic backup
quber-workflow migrate
```

## Environment Variables

Set these for Jira and GitHub operations:

```bash
# GitHub (for gh CLI)
export GH_TOKEN="ghp_..."
# or
export GITHUB_PERSONAL_ACCESS_TOKEN="ghp_..."

# Jira (for REST API)
export ATLASSIAN_SITE_NAME="yoursite.atlassian.net"
export ATLASSIAN_USER_EMAIL="your.email@example.com"
export ATLASSIAN_API_TOKEN="your-api-token"
```

## GitHub Secrets

Configure these secrets for GitHub Actions:

- `JIRA_BASE_URL` - Your Jira site URL
- `JIRA_USER_EMAIL` - Jira account email
- `JIRA_API_TOKEN` - Jira API token

## Architecture

### Agent-Based Workflow

```
Main Claude Agent (quber-analyst)
     > jira-workflow agent (via Task tool)
        > jira-operations skill (bash scripts)
            > Jira REST API
     > github-workflow agent (via Task tool)
         > github-operations skill (bash scripts)
             > gh CLI / GitHub API
```

### Why This Approach?

- **Minimal context overhead** - ~100 tokens vs 46k with MCP servers
- **On-demand loading** - Skills load only when agents are invoked
- **No external dependencies** - Just bash, curl, jq, and gh CLI
- **Easy debugging** - Scripts are visible and testable
- **Full control** - Auditable code in your repository

## Documentation

- [GitHub Workflow Spec](src/quber_workflow/templates/docs/GITHUB_WORKFLOW_SPEC.md) - PR and commit standards
- [Issues Spec](src/quber_workflow/templates/docs/ISSUES_SPEC.md) - Jira ticket specifications
- [PR Evidence Guidelines](src/quber_workflow/templates/docs/PR_EVIDENCE_GUIDELINES.md) - Evidence requirements
- [PR Evidence Checklist](src/quber_workflow/templates/docs/PR_EVIDENCE_CHECKLIST.md) - Quick reference

## Development

### Setup

```bash
# Clone repository
git clone https://github.com/xmandeng/quber-workflow.git
cd quber-workflow

# Install dependencies
uv sync

# Run tests
uv run pytest

# Type checking
uv run mypy src/

# Linting
uv run ruff check src/
```

### Build and Publish

```bash
# Build package
uv build

# Publish to Test PyPI
uv publish \
  --publish-url https://test.pypi.org/legacy/ \
  --username __token__ \
  --password $TEST_PYPI_TOKEN

# Publish to Production PyPI
uv publish --username __token__ --password $PYPI_TOKEN
```

## Requirements

- Python >= 3.9
- `gh` CLI (for GitHub operations)
- `jq` (for JSON parsing)
- `curl` (for Jira REST API)

## Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Related Projects

- [quber-analyst](https://github.com/xmandeng/quber-analyst) - Financial document analyzer
- [quber-excel](https://github.com/xmandeng/quber-excel) - Excel parser with spatial fidelity

## Links

- **PyPI:** <https://pypi.org/project/quber-workflow/>
- **Test PyPI:** <https://test.pypi.org/project/quber-workflow/>
- **Repository:** <https://github.com/xmandeng/quber-workflow>
- **Issues:** <https://github.com/xmandeng/quber-workflow/issues>
