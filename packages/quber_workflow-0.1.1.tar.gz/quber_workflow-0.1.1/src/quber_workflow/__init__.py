"""Quber Workflow - Shared Claude Code workflow for Quber projects."""

from .version import __version__

__all__ = ['__version__']
