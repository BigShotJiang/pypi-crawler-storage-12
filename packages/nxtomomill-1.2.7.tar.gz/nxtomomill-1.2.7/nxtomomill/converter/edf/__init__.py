"""module to convert from spec-EDF to `NXtomo <https://manual.nexusformat.org/classes/applications/NXtomo.html>`_"""
