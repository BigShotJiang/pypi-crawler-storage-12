"""dedicated module to handle input and output"""

from .config import *  # noqa F401,F403
