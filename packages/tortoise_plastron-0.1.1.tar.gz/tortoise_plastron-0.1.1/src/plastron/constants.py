COLORS = {
    "green": "green",
    "yellow": "yellow",
    "red": "red",
}
