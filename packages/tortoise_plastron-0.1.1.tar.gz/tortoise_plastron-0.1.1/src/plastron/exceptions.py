from asyncclick import UsageError


class ConfigError(UsageError):
    pass
