# CHANGELOG

<!-- version list -->

## v0.1.1 (2025-11-11)

### Bug Fixes

- Wrong release version for pypi
  ([`d3ccdeb`](https://github.com/blockanalitica/plastron/commit/d3ccdebff6e7b43cd52538ad982d534c0901b79d))


## v0.1.0 (2025-11-11)

### Chores

- Updated build badge in readme
  ([`3af0c30`](https://github.com/blockanalitica/plastron/commit/3af0c30da7dbb57db48dd1095f573c194e6ba357))

- Updated readme
  ([`d803ca0`](https://github.com/blockanalitica/plastron/commit/d803ca0295d836b899cfb345a35fe81120918990))

### Features

- Added RenameTable operation ([#5](https://github.com/blockanalitica/plastron/pull/5),
  [`b3c50a0`](https://github.com/blockanalitica/plastron/commit/b3c50a047e81648a213f5568d3b2e3f2c481c938))


## v0.0.1 (2025-10-17)

- Initial Release
