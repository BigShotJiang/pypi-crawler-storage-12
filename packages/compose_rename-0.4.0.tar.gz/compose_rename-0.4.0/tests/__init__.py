# Tests for compose-rename

