"""Bottleneck blocks for vendored MEDNet."""

