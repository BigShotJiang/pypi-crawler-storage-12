"""Attention layers for the vendored MEDNet package."""

