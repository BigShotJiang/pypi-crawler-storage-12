"""Utilities (losses, metrics, normalization) for vendored MEDNet."""

