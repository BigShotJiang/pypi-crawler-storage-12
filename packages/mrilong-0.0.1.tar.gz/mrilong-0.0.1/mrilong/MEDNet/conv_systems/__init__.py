"""Convolutional building blocks for vendored MEDNet."""

