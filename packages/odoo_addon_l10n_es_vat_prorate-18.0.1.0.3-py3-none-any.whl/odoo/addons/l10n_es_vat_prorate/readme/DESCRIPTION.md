El módulo nos divide los IVA según la prorrata de la compañía.
