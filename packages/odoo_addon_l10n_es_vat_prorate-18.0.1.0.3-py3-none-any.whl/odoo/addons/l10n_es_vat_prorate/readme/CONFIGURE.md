Para configurar la prorrata general:

- Acceda a la compañía y marque que aplica prorrata.
- Defina el porcentaje de prorrata (se aplica por fechas).

Los impuestos de las facturas de proveedor se dividirán según la
prorrata activa.


Para configurar la prorrata especial:

- Acceda a la compañía y marque que aplica prorrata de IVA especial.
- Marque el valor por defecto de la prorrata especial.

En las líneas de factura aparecerá un nuevo campo editable, con el valor por defecto configurado,
que permitirá definir que líneas serán prorrateadas.
