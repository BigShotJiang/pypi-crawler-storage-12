#   example01.py
#
#   file to demonstrate the use of spScriptTest3Py
#
#
import sys

from spScriptTest3Py import ScriptTest3

print("running Python executable from path", sys.executable)

