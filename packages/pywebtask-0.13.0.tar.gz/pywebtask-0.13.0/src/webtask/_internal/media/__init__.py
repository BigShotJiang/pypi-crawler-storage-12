"""Media handling - images, screenshots, etc."""

from .image import Image

__all__ = ["Image"]
