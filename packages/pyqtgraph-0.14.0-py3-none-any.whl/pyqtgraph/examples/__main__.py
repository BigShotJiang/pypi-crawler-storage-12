

if __name__ == '__main__':
    from .ExampleApp import main as run
    run()
