from gooddata_api_client.paths.api_v1_entities_user_groups.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_user_groups.post import ApiForpost


class ApiV1EntitiesUserGroups(
    ApiForget,
    ApiForpost,
):
    pass
