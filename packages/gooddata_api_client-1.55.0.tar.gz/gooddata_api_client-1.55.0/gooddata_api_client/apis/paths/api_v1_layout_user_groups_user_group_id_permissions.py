from gooddata_api_client.paths.api_v1_layout_user_groups_user_group_id_permissions.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_user_groups_user_group_id_permissions.put import ApiForput


class ApiV1LayoutUserGroupsUserGroupIdPermissions(
    ApiForget,
    ApiForput,
):
    pass
