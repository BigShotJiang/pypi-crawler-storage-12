from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_visualization_objects.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_visualization_objects.post import ApiForpost


class ApiV1EntitiesWorkspacesWorkspaceIdVisualizationObjects(
    ApiForget,
    ApiForpost,
):
    pass
