from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_dashboard_plugins.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_dashboard_plugins.post import ApiForpost


class ApiV1EntitiesWorkspacesWorkspaceIdDashboardPlugins(
    ApiForget,
    ApiForpost,
):
    pass
