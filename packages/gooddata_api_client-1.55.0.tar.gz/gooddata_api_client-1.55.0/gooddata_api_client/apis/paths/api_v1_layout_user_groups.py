from gooddata_api_client.paths.api_v1_layout_user_groups.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_user_groups.put import ApiForput


class ApiV1LayoutUserGroups(
    ApiForget,
    ApiForput,
):
    pass
