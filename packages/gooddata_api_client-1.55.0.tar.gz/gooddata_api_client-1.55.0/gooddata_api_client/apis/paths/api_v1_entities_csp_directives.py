from gooddata_api_client.paths.api_v1_entities_csp_directives.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_csp_directives.post import ApiForpost


class ApiV1EntitiesCspDirectives(
    ApiForget,
    ApiForpost,
):
    pass
