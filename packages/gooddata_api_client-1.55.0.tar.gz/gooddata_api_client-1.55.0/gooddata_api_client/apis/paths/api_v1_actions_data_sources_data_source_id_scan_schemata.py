from gooddata_api_client.paths.api_v1_actions_data_sources_data_source_id_scan_schemata.get import ApiForget


class ApiV1ActionsDataSourcesDataSourceIdScanSchemata(
    ApiForget,
):
    pass
