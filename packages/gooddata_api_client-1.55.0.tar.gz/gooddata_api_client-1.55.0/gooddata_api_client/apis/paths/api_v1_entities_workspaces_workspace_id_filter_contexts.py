from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_filter_contexts.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_filter_contexts.post import ApiForpost


class ApiV1EntitiesWorkspacesWorkspaceIdFilterContexts(
    ApiForget,
    ApiForpost,
):
    pass
