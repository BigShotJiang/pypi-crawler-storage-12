from gooddata_api_client.paths.api_v1_entities_users_user_id_user_settings_id.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_users_user_id_user_settings_id.put import ApiForput
from gooddata_api_client.paths.api_v1_entities_users_user_id_user_settings_id.delete import ApiFordelete


class ApiV1EntitiesUsersUserIdUserSettingsId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
