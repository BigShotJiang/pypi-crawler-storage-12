from gooddata_api_client.paths.api_v1_entities_entitlements.get import ApiForget


class ApiV1EntitiesEntitlements(
    ApiForget,
):
    pass
