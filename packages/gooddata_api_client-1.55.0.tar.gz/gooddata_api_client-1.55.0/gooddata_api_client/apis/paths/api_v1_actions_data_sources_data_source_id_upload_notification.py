from gooddata_api_client.paths.api_v1_actions_data_sources_data_source_id_upload_notification.post import ApiForpost


class ApiV1ActionsDataSourcesDataSourceIdUploadNotification(
    ApiForpost,
):
    pass
