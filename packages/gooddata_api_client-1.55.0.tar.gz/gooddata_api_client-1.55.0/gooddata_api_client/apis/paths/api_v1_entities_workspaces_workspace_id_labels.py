from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_labels.get import ApiForget


class ApiV1EntitiesWorkspacesWorkspaceIdLabels(
    ApiForget,
):
    pass
