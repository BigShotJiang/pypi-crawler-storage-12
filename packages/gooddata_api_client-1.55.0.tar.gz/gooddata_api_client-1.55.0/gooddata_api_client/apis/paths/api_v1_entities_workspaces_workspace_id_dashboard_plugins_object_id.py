from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_dashboard_plugins_object_id.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_dashboard_plugins_object_id.put import ApiForput
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_dashboard_plugins_object_id.delete import ApiFordelete
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_dashboard_plugins_object_id.patch import ApiForpatch


class ApiV1EntitiesWorkspacesWorkspaceIdDashboardPluginsObjectId(
    ApiForget,
    ApiForput,
    ApiFordelete,
    ApiForpatch,
):
    pass
