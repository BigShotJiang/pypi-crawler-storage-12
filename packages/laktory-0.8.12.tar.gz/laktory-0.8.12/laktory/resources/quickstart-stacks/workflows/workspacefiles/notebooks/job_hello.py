# Databricks notebook source
print("Hello Laktory!")
