This addon implements Spanish localization for Cooperator Module

Features:

- Add Tax identification on subscription request
- Add Tax identification on subscription request website form
