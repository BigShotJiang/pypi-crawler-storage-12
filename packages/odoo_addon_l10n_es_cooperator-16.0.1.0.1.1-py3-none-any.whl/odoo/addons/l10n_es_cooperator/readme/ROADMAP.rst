Move this feature to cooperator module
- Change property_cooperator_account to not accept deprecated account
