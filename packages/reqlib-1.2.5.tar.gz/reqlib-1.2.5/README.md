# reqlib

مكتبة Python خفيفة للتعامل مع HTTP و HTML و JSON، تدعم جميع أنواع
الطلبات، رفع الملفات، تحليل الردود، واستخراج البيانات من الصفحات بسهولة.

------------------------------------------------------------------------

## 🚀 التثبيت

``` bash
pip install request
```

## 📡 الطلبات الأساسية

``` python
from request import get, post, put, delete, head, options, patch

res = get("https://httpbin.org/get", params={"q": "test"})
print(res.status)
print(res.text)
```

## 📦 رفع ملفات

``` python
res = post("https://httpbin.org/post", files={"file": "test.txt"})
print(res.json())
```

## 🍪 الكوكيز والهيدر

``` python
res = get("https://httpbin.org/cookies", cookies={"session": "abc123"})
print(res.cookies)
```

## 🔁 إعادة التوجيه

``` python
res = get("https://httpbin.org/redirect/2")
print(res.redirect_chain)
```

## 🧠 تحليل الرد

``` python
print(res.ok)
print(res.status)
print(res.headers)
print(res.cookies_dict)
print(res.url_parts)
print(res.query_params)
```

## 🧬 JSON و HTML

``` python
print(res.is_json)
print(res.json())
print(res.html)
print(res.title)
print(res.links)
print(res.assets)
print(res.meta)
```

## 🔍 استخراج عناصر HTML

``` python
res.search_attr("input", "data-token")
res.gethtml("input", "value")
res.gethtml("input", ["name", "value", "data-token"])
res.gethtml(["input", "textarea"], ["name", "value"])
```

## 🧪 تحليل السكربتات

``` python
print(res.js)
print(res.jsonhtml)
print(res.get_script_vars())
```

## 🔐 التعامل مع البروكسي

``` python
res = get("http://httpbin.org/ip", proxies={
    "http": "http://127.0.0.1:8080",
    "https": "http://127.0.0.1:8080"
})
```

SOCKS5 غير مدعوم مباشرة.

## 🧵 تحليل النموذج

``` python
print(res.form_fields)
print(res.get_hidden_inputs)
```

## 🧠 أدوات إضافية

``` python
res.is_redirect
res.headers_lower
res.get_cookie("session")
res.get_header("Content-Type")
res.json_path("data.user.email")
res.find_tag("input", name="csrf_token")
```

## 🌀 دعم أوامر curl

``` python
res = curl("curl -X POST https://httpbin.org/post -d 'name=mhmd'")
print(res.json())
```

------------------------------------------------------------------------

# 🤔 لماذا تستخدم reqlib بدلًا من requests؟

## ✅ جدول مقارنة reqlib vs requests

  الميزة                           **reqlib**                 **requests**
  -------------------------------- -------------------------- ------------------------
  **سهولة الاستخدام**              ✔️ أبسط -- واجهة مباشرة    ✔️ سهل لكن أضخم
  **الحجم**                        صغير جدًا                  أكبر
  **التعامل مع HTML**              ✔️ مدمج                    ❌ يحتاج BeautifulSoup
  **استخراج البيانات من الصفحة**   ✔️ جاهز                    ❌ غير موجود
  **تحليل السكربتات**              ✔️ موجود                   ❌ غير موجود
  **تحليل النماذج**                ✔️ تلقائي                  ❌ غير موجود
  **curl**                         ✔️ يدعم تشغيل أوامر curl   ❌ لا يدعم
  **multipart**                    ✔️ مدعوم                   ✔️ مدعوم
  **الكوكيز**                      ✔️ سهل                     ✔️ قوي
  **البروكسي**                     ✔️ HTTP(S) فقط             ✔️ يدعم SOCKS
  **إعادة التوجيه**                ✔️ مع redirect_chain       ✔️ مدعوم
  **قراءة JSON**                   ✔️ json(), json_path       ✔️ json()
  **بدون kwargs**                  ✔️ نعم                     ❌ يستخدم بكثرة
  **مرونة التخصيص**                ✔️ عالية                   ✔️ عالية
  **المجتمع**                      جديد                       كبير

------------------------------------------------------------------------

## ✨ متى تستخدم reqlib؟

-   إذا كنت تبني أدوات scraping أو تحليل صفحات HTML.
-   إذا تريد مكتبة خفيفة وسهلة بدون تعقيد.
-   إذا تفضل واجهة واضحة وصريحة.
-   إذا تحتاج استخراج عناصر HTML بدون مكتبات خارجية.
-   إذا تبني أدوات مخصصة فوق مكتبة قابلة للتوسعة.

## 📚 الترخيص

MIT License

## ✨ المؤلف

mhmd --- مكتبة مصممة لتكون واضحة، قوية، وسهلة الاستخدام للمبرمجين
المحترفين.
