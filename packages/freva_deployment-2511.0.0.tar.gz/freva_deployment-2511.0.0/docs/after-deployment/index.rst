After successful deployment
============================
After all services are set up and running and the core library can be used
you will most likely want to configure the system and make and make old freva
plugins work within the new system. The chapter provides a glimpse of what's todo
after the system is working.

.. toctree::
   :maxdepth: 2

   AfterDeployment
   TransitionService
   TransitionPlugins
   LegalNotes
