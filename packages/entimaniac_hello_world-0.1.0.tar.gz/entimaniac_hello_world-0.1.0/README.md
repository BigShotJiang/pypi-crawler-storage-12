# entimaniac_hello_world
The goal of this project is to explore creating and publishing python packages to the central python package repository


This project exposes a basic function that takes in a single parameter (name) and returns a string "Hello {name}".

The project is then versioned, built and deployed via a GitHub actions to pypi.org
