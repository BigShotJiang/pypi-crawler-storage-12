"""A simple package that provides a hello world function."""

__version__ = "0.1.0"

from .hello import hello

__all__ = ["hello"]

