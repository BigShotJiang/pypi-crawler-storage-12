# solo/__init__.py
