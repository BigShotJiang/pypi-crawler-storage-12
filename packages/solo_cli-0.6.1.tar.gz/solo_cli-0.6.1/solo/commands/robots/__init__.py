"""
Robotics framework handlers for Solo CLI
""" 