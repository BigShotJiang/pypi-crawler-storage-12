"""
LeRobot utilities package for Solo CLI
Handles port detection, calibration, teleoperation setup, and data recording
"""

