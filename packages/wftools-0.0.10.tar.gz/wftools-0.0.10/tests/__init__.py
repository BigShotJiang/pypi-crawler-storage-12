# pip install wftools  -i https://pypi.python.org/simple -U

# 1、pip freeze > allpackages.txt
# 2、pip uninstall -r allpackages.txt -y
# 3、pip install --upgrade python-office