#!/usr/bin/env python3

# With the setup.cfg usage, this file is now optional

from setuptools import setup; setup()
