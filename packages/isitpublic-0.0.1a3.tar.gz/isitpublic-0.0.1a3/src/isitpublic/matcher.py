"""
Pattern matching utilities for public domain indicators.

This module provides basic pattern matching functionality used by the validator.
"""

from __future__ import annotations
