from .autotag import register_auto_tags
from .taggable import is_taggable

__all__ = ["register_auto_tags", "is_taggable"]
