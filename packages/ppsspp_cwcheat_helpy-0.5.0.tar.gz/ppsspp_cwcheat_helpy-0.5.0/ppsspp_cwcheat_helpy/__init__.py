__app_name__ = "ppsspp-cwcheat-helpy"
__version__ = "0.5.0"

__all__ = ["__app_name__", "__version__"]
