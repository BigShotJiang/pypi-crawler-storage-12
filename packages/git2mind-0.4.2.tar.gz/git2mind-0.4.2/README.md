# git2mind is now tria

This package has been renamed. Use `pip install tria` instead.

New package: https://pypi.org/project/tria/
