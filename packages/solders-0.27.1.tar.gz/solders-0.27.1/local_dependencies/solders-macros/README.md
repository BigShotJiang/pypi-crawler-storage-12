# solders-macros

A collection of attribute macros to reduce boilerplate in the [solders](https://github.com/kevinheavey/solders) project.
