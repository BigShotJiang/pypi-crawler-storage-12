需要显示安装全能包指定路径
pip install quannengbao[byted] --extra-index-url https://bytedpypi.byted.org/simple