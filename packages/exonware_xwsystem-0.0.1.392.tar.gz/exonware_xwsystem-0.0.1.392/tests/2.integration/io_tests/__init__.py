"""Integration tests for io module."""

