"""Unit tests for text-based serialization formats."""

