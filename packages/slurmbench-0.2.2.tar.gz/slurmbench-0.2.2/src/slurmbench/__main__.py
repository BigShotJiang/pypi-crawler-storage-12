"""PlasBin-flow benchmarking framework entry point."""

from slurmbench.app import APP


def main() -> None:
    """Execute the main."""
    APP()


if __name__ == "__main__":
    main()
