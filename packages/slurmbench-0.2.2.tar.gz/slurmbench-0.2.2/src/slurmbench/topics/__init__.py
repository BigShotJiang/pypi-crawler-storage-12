"""Interface for all the topics."""
