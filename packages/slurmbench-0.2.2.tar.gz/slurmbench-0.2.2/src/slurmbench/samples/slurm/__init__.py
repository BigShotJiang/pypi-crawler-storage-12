"""Samples slurm logics."""
