"""Topic application prelude."""

# Due to typer usage:
# ruff: noqa: PLC0414

from slurmbench.topic.app import Topic as Topic
