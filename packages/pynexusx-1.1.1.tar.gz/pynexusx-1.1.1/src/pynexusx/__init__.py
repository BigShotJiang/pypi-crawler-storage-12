"""
Pisystem CLI
------------
A small Python CLI to update all outdated packages,
powered by Kaedeek.
"""
__version__ = "1.1.1"
__author__ = "kaede"