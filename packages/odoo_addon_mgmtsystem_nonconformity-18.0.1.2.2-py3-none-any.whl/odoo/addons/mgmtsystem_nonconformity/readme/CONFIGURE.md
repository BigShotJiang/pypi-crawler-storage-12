Users must be added to the appropriate groups within Odoo as follows:

- Creators: Settings \> Users \> Groups \> Management System / User