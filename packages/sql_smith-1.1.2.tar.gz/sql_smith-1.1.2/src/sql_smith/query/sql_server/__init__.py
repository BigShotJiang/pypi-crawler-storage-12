from .delete_query import DeleteQuery
from .select_query import SelectQuery


__all__ = ["SelectQuery", "DeleteQuery"]
