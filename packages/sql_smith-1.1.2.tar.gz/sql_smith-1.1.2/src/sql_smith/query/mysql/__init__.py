from .insert_query import InsertQuery
from .select_query import SelectQuery


__all__ = ["InsertQuery", "SelectQuery"]
