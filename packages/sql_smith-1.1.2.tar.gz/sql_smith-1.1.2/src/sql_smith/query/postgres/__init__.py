from .insert_query import InsertQuery
from .update_query import UpdateQuery


__all__ = ["InsertQuery", "UpdateQuery"]
