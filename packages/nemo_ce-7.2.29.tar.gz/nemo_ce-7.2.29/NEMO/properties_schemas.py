# This can be extended in settings.py
TOOL_PROPERTIES_JSON_SCHEMA = {
    "type": "object",
    "properties": {},
    "additionalProperties": True,
}
