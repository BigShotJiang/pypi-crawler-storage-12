"""
FVM: A Formal Verification Methodology for ASIC and FPGA designs
"""
from fvm.framework import FvmFramework
