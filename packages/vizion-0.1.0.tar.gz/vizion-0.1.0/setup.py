from setuptools import setup, find_packages

setup(
    name="vizion",
    version="0.1.0",
    description="Smart EDA and model recommendation helper",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Milind Chaudhari",
    author_email="codewithmilind@gmail.com",
    url="https://github.com/CodeWithMilind/vizion",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "numpy",
        "matplotlib",
        "seaborn",
        "scikit-learn"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ],
    python_requires='>=3.8',
)
