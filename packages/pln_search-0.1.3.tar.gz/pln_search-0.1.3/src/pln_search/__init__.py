"""PLN Search - CLI tool for searching the PLN Directory API."""

__version__ = "0.1.0"
