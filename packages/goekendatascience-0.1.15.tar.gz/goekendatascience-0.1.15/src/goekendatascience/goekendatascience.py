import os
import pandas as pd
import requests
import datetime
from datetime import date

class TickerDataFetch:

    def __init__(self):
        self.todays_date = str(date.today())
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.output_folder = os.path.join(self.script_dir, "Historical Data")

    def folder_scan(self):
        os.makedirs(self.output_folder, exist_ok=True)
        self.List = os.listdir(self.output_folder)
        self.namelist = {}
        for item in self.List:
            ticker_name = item.split('.')[0].split()[0]
            ticker_date = item.split('.')[0].split()[1]
            self.namelist[ticker_name] = ticker_date

    def fetch_historical_data(self, ticker, AV_keys):
        key_success = 0
        for i in AV_keys:
            if key_success == 0:
                url = f'https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={ticker}&outputsize=full&apikey={i}'
                r = requests.get(url)
                data = r.json()     
                if "Information" in data and "rate limit" in data["Information"].lower():
                    print('Alpha Vangtage key',i,'failed. Error:', str(data),'trying next key')
                else:
                    try:
                        historical_data = pd.DataFrame(data[list(data.keys())[1]]).transpose()
                        key_success = 1
                    except:
                        print(str(data))
                        key_success = 0
                
        if key_success == 1:
            print('Successfully fetched data for',ticker)
            historical_data.columns = ['O', 'H', 'L', 'C', 'V']
            os.makedirs(self.output_folder, exist_ok=True)
            csv_path = os.path.join(self.output_folder, f"{ticker} {self.todays_date}.csv")
            historical_data.to_csv(csv_path, index=True)
            print(f"Saved CSV to: {csv_path}")
        else:
            print("Failed to fetch data")

    def update_tickers (self,tickers,AV_key): 
        self.folder_scan()
        for ticker in tickers:
            if ticker in self.namelist:
                if self.namelist[ticker] == self.todays_date:
                    print(ticker,"data found for",self.todays_date)
                else:
                    os.remove(os.path.join(self.output_folder, f"{ticker} {self.namelist[ticker]}.csv"))
                    self.fetch_historical_data(ticker,AV_key)
                    print(ticker,"data found for",self.namelist[ticker],". Updating data for",self.todays_date)
            else:
                self.fetch_historical_data(ticker,AV_key)
                print(ticker,"data not found",{ticker},". Updating data for",self.todays_date)
        for ticker in self.namelist:
            if ticker in tickers:
                pass
            else:
                os.remove(os.path.join(self.output_folder, f"{ticker} {self.namelist[ticker]}.csv"))
                print("Removed",ticker,".")
        self.folder_scan()

    def import_tickers(self):
        ticker_data = {}
        self.folder_scan()
        for ticker in self.namelist:
            data = pd.read_csv(os.path.join(self.output_folder, f"{ticker} {self.namelist[ticker]}.csv"))
            print(data.columns[0])
            ticker_data[ticker] = data
        return ticker_data

class DataManipulation:
    def __init__(self):
        pass

    def shift_cells(self):
        pass
