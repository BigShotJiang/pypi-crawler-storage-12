This is the French localization for the Cooperators module.

Features:

- Add French legal form of companies on partner and on Subscription Request
- Remove IBAN field from required field of subscription request
