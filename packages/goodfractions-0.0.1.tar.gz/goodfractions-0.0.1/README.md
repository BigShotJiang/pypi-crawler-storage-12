# goodfractions
A python repository that implements fractions improving the python default fractions module
