"""Top-level package for sirio."""

__author__ = """sirio"""
__email__ = 'pasquale.rombola@cerved.com'
__version__ = '0.1.0'
