from .data_report import DataReport

__version__= "1.7.1"