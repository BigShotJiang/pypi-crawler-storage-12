"""Shared components across all MCP services"""
