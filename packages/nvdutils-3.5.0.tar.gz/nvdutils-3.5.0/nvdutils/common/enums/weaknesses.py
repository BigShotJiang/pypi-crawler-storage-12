from enum import Enum


class WeaknessType(Enum):
    Primary = 1
    Secondary = 2

