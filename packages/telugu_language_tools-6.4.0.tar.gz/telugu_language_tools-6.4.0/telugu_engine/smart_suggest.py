"""
Smart Suggestion System with Adaptive Learning
===============================================

Integrates:
1. Base transliteration (from transliterator.py)
2. ML-based scoring (from smart_loader.py)
3. Adaptive learning (from adaptive_learner.py)

This provides intelligent suggestions that improve over time.

Usage:
    from telugu_engine.smart_suggest import SmartSuggester

    suggester = SmartSuggester()

    # Get suggestions
    results = suggester.suggest("hello", limit=5)
    # Returns: [('హలో', 0.95), ('హెల్లో', 0.82), ...]

    # User picks one
    suggester.record_user_choice("hello", "హలో")

    # Next time, that choice ranks higher!
"""

from typing import List, Tuple, Optional, Dict
from .transliterator import eng_to_telugu
from .suggest import suggestions as get_variants
from .adaptive_learner import AdaptiveLearner, get_learner
import warnings


class SmartSuggester:
    """
    Intelligent suggestion system that learns from user feedback.
    """

    def __init__(self, use_ml: bool = True, use_learning: bool = True,
                 data_dir: Optional[str] = None):
        """
        Initialize smart suggester.

        Args:
            use_ml: Use ML-based scoring (if available)
            use_learning: Use adaptive learning from user feedback
            data_dir: Directory for learning data
        """
        self.use_ml = use_ml
        self.use_learning = use_learning

        # Initialize ML backend
        self.ml_available = False
        self.ml_scorer = None
        if use_ml:
            try:
                from .smart_loader import init_model, score_candidate, backend_name
                if init_model():
                    self.ml_available = True
                    self.ml_scorer = score_candidate
                    self.ml_backend = backend_name()
                    print(f"Smart suggester: Using ML backend '{self.ml_backend}'")
            except Exception as e:
                warnings.warn(f"ML backend not available: {e}")

        # Initialize adaptive learner
        self.learner = None
        if use_learning:
            try:
                if data_dir:
                    self.learner = AdaptiveLearner(data_dir)
                else:
                    self.learner = get_learner()
            except Exception as e:
                warnings.warn(f"Adaptive learner not available: {e}")

    def suggest(self, text: str, limit: int = 5,
                return_scores: bool = True) -> List[Tuple[str, float]]:
        """
        Get smart suggestions for input text.

        Args:
            text: Input text (English/Roman)
            limit: Maximum number of suggestions
            return_scores: Return scores along with suggestions

        Returns:
            List of (suggestion, score) tuples if return_scores=True,
            otherwise just list of suggestions
        """
        # Step 1: Get base transliteration + variants
        candidates = self._get_candidates(text, limit * 3)  # Get more candidates

        if not candidates:
            # Fallback to direct transliteration
            direct = eng_to_telugu(text)
            return [(direct, 1.0)] if return_scores else [direct]

        # Step 2: Score with ML (if available)
        base_scores = []
        if self.ml_available and self.ml_scorer:
            base_scores = self._score_with_ml(text, candidates)
        else:
            # Use simple heuristic scores
            base_scores = self._heuristic_scores(candidates)

        # Step 3: Re-rank with learned preferences
        if self.learner:
            ranked = self.learner.rerank_suggestions(text, candidates, base_scores)
        else:
            ranked = list(zip(candidates, base_scores))
            ranked.sort(key=lambda x: x[1], reverse=True)

        # Step 4: Limit and return
        result = ranked[:limit]

        if return_scores:
            return result
        else:
            return [item[0] for item in result]

    def _get_candidates(self, text: str, limit: int) -> List[str]:
        """Generate candidate suggestions using variant generator."""
        try:
            # Use the existing suggestion system
            candidates = get_variants(text, limit=limit)
            return candidates if candidates else [eng_to_telugu(text)]
        except Exception:
            # Fallback
            return [eng_to_telugu(text)]

    def _score_with_ml(self, input_text: str, candidates: List[str]) -> List[float]:
        """Score candidates using ML model."""
        scores = []
        for candidate in candidates:
            try:
                score = self.ml_scorer(input_text, candidate)
                scores.append(score)
            except Exception:
                scores.append(0.0)
        return scores

    def _heuristic_scores(self, candidates: List[str]) -> List[float]:
        """Simple heuristic scoring when ML not available."""
        # Prefer shorter candidates (usually more accurate)
        max_len = max(len(c) for c in candidates) if candidates else 1
        scores = []
        for candidate in candidates:
            # Score based on inverse length (shorter = better)
            score = 1.0 - (len(candidate) / (max_len + 1))
            scores.append(score)
        return scores

    def record_user_choice(self, input_text: str, chosen: str):
        """
        Record that the user chose this suggestion.

        This improves future suggestions through learning.

        Args:
            input_text: The input text
            chosen: The suggestion the user picked
        """
        if self.learner:
            self.learner.record_feedback(input_text, chosen, picked=True)

    def record_rejection(self, input_text: str, rejected: str):
        """
        Record that the user rejected this suggestion.

        Args:
            input_text: The input text
            rejected: The suggestion the user rejected
        """
        if self.learner:
            self.learner.record_feedback(input_text, rejected, picked=False)

    def get_learning_stats(self) -> Dict:
        """Get statistics about the adaptive learning."""
        if self.learner:
            return self.learner.get_statistics()
        return {}

    def export_training_data(self, output_file: str) -> int:
        """
        Export collected feedback for model retraining.

        Args:
            output_file: Path to save training data

        Returns:
            Number of samples exported
        """
        if self.learner:
            return self.learner.export_training_data(output_file)
        return 0

    def trigger_background_training(self, min_samples: int = 100) -> bool:
        """
        Trigger background model retraining if enough data collected.

        Args:
            min_samples: Minimum samples needed to trigger training

        Returns:
            True if training started, False otherwise
        """
        if self.learner:
            return self.learner.train_from_feedback(min_samples)
        return False


# Global instance
_global_suggester = None

def get_suggester() -> SmartSuggester:
    """Get global smart suggester instance."""
    global _global_suggester
    if _global_suggester is None:
        _global_suggester = SmartSuggester()
    return _global_suggester


# Convenience functions
def smart_suggest(text: str, limit: int = 5) -> List[Tuple[str, float]]:
    """Get smart suggestions with scores."""
    suggester = get_suggester()
    return suggester.suggest(text, limit=limit)


def record_choice(input_text: str, chosen: str):
    """Record user's choice to improve future suggestions."""
    suggester = get_suggester()
    suggester.record_user_choice(input_text, chosen)


__all__ = [
    'SmartSuggester',
    'get_suggester',
    'smart_suggest',
    'record_choice',
]


# Example usage and testing
if __name__ == "__main__":
    print("="*70)
    print("  SMART SUGGESTION SYSTEM WITH ADAPTIVE LEARNING")
    print("="*70 + "\n")

    suggester = SmartSuggester(use_ml=False, use_learning=True)

    # Test 1: Initial suggestions
    print("1. Initial suggestions for 'hello':")
    suggestions = suggester.suggest("hello", limit=5)
    for i, (text, score) in enumerate(suggestions, 1):
        print(f"   {i}. {text:15} (score: {score:.3f})")
    print()

    # Test 2: Simulate user picking option 2
    print("2. User picks:", suggestions[1][0])
    suggester.record_user_choice("hello", suggestions[1][0])
    print()

    # Test 3: Get suggestions again - picked one should rank higher
    print("3. Suggestions after learning:")
    suggestions_after = suggester.suggest("hello", limit=5)
    for i, (text, score) in enumerate(suggestions_after, 1):
        marker = " ← LEARNED!" if text == suggestions[1][0] else ""
        print(f"   {i}. {text:15} (score: {score:.3f}){marker}")
    print()

    # Test 4: Show learning stats
    print("4. Learning Statistics:")
    stats = suggester.get_learning_stats()
    for key, value in stats.items():
        print(f"   {key}: {value}")

    print("\n" + "="*70)
    print("💡 TIP: The more you use it, the smarter it gets!")
    print("="*70)
