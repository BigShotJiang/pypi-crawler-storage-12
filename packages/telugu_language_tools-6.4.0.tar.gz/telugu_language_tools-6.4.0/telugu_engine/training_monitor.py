"""
Training Monitor API - Simple interface to check training status
=================================================================

This module provides a simple API for users to check if ML training
is happening while they use the Telugu library.

Usage:
    from telugu_engine.training_monitor import is_training, get_training_status

    # Quick check
    if is_training():
        print("Training is active!")

    # Detailed status
    status = get_training_status()
    print(status)
"""

import os
import time
from typing import Dict, Optional


def is_training() -> bool:
    """
    Check if training is currently active.

    Returns:
        bool: True if training is active, False otherwise

    Example:
        >>> from telugu_engine.training_monitor import is_training
        >>> if is_training():
        ...     print("Training is happening now!")
    """
    try:
        from .adaptive_learner import AdaptiveLearner
        learner = AdaptiveLearner()
        return learner._training_in_progress
    except:
        return False


def get_training_status() -> Dict:
    """
    Get detailed training status.

    Returns:
        dict: Status information including:
            - is_training: bool - Whether training is active
            - feedback_count: int - Number of feedback samples
            - last_updated: str - When training last ran
            - data_dir: str - Where training data is stored
            - threshold: int - Feedback threshold for auto-training

    Example:
        >>> from telugu_engine.training_monitor import get_training_status
        >>> status = get_training_status()
        >>> print(f"Training: {status['is_training']}")
        >>> print(f"Feedback: {status['feedback_count']}")
    """
    status = {
        'is_training': False,
        'feedback_count': 0,
        'last_updated': None,
        'data_dir': None,
        'threshold': 100,
        'will_train_soon': False,
        'error': None
    }

    try:
        from .adaptive_learner import AdaptiveLearner

        learner = AdaptiveLearner()

        status['is_training'] = learner._training_in_progress
        status['feedback_count'] = learner.stats.get('total_feedback', 0)
        status['last_updated'] = learner.stats.get('last_updated', None)
        status['data_dir'] = learner.data_dir

        # Check if close to threshold
        if status['feedback_count'] >= status['threshold'] * 0.8:
            status['will_train_soon'] = True

    except Exception as e:
        status['error'] = str(e)

    return status


def wait_for_training_completion(timeout: int = 300, check_interval: int = 1) -> bool:
    """
    Wait for training to complete.

    Args:
        timeout: Maximum time to wait in seconds (default: 5 minutes)
        check_interval: How often to check in seconds (default: 1)

    Returns:
        bool: True if training completed, False if timeout

    Example:
        >>> from telugu_engine.training_monitor import wait_for_training_completion
        >>> if wait_for_training_completion(timeout=60):
        ...     print("Training finished!")
    """
    start_time = time.time()

    while time.time() - start_time < timeout:
        if not is_training():
            return True
        time.sleep(check_interval)

    return False  # Timeout


def get_training_progress() -> Optional[Dict]:
    """
    Get training progress if training is active.

    Returns:
        dict or None: Progress information if training is active, None otherwise
            - is_training: bool
            - progress_text: str - Human readable progress
            - feedback_count: int

    Example:
        >>> from telugu_engine.training_monitor import get_training_progress
        >>> progress = get_training_progress()
        >>> if progress:
        ...     print(progress['progress_text'])
    """
    if not is_training():
        return None

    status = get_training_status()

    return {
        'is_training': True,
        'progress_text': f"Training in progress ({status['feedback_count']} samples)",
        'feedback_count': status['feedback_count']
    }


def check_training_data_size() -> Dict:
    """
    Check the size of collected training data.

    Returns:
        dict: Information about training data
            - data_dir: str
            - exists: bool
            - feedback_file_size: int (bytes)
            - preferences_file_size: int (bytes)
            - last_modified: float (timestamp)

    Example:
        >>> from telugu_engine.training_monitor import check_training_data_size
        >>> data = check_training_data_size()
        >>> print(f"Feedback size: {data['feedback_file_size']} bytes")
    """
    result = {
        'data_dir': None,
        'exists': False,
        'feedback_file_size': 0,
        'preferences_file_size': 0,
        'last_modified': None
    }

    try:
        from .adaptive_learner import AdaptiveLearner

        learner = AdaptiveLearner()
        data_dir = learner.data_dir

        result['data_dir'] = data_dir
        result['exists'] = os.path.exists(data_dir)

        if result['exists']:
            # Check feedback file
            feedback_file = os.path.join(data_dir, 'feedback.jsonl')
            if os.path.exists(feedback_file):
                result['feedback_file_size'] = os.path.getsize(feedback_file)
                result['last_modified'] = os.path.getmtime(feedback_file)

            # Check preferences file
            prefs_file = os.path.join(data_dir, 'preferences.pkl')
            if os.path.exists(prefs_file):
                result['preferences_file_size'] = os.path.getsize(prefs_file)

    except:
        pass

    return result


def enable_training_notifications(callback):
    """
    Register a callback to be notified when training starts/stops.

    Args:
        callback: Function to call with training status (bool)

    Example:
        >>> def on_training_change(is_active):
        ...     if is_active:
        ...         print("Training started!")
        ...     else:
        ...         print("Training stopped!")
        >>>
        >>> enable_training_notifications(on_training_change)

    Note:
        This requires background monitoring to be implemented.
        Currently returns NotImplementedError.
    """
    raise NotImplementedError(
        "Training notifications require background monitoring. "
        "Use is_training() in your own loop instead."
    )


def get_training_history() -> Dict:
    """
    Get training history summary.

    Returns:
        dict: Training history
            - total_training_runs: int (estimated from file modifications)
            - last_training: str (timestamp)
            - total_feedback: int

    Example:
        >>> from telugu_engine.training_monitor import get_training_history
        >>> history = get_training_history()
        >>> print(f"Total feedback: {history['total_feedback']}")
    """
    history = {
        'total_training_runs': 0,
        'last_training': None,
        'total_feedback': 0
    }

    try:
        from .adaptive_learner import AdaptiveLearner

        learner = AdaptiveLearner()
        history['total_feedback'] = learner.stats.get('total_feedback', 0)
        history['last_training'] = learner.stats.get('last_updated', None)

        # Estimate training runs (rough approximation)
        if history['total_feedback'] > 0:
            history['total_training_runs'] = history['total_feedback'] // 100

    except:
        pass

    return history


# Convenience aliases
training_active = is_training
get_status = get_training_status


__all__ = [
    'is_training',
    'get_training_status',
    'wait_for_training_completion',
    'get_training_progress',
    'check_training_data_size',
    'get_training_history',
    'training_active',
    'get_status',
]
