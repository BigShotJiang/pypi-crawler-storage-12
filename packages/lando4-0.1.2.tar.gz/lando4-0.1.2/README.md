# Lando

A personal Python package containing my Colab example codes.

## Installation
```bash
pip install lando
```

## Usage
```python
import lando

print(lando.ex1)
# or dynamically
print(lando.get("ex2"))
```
