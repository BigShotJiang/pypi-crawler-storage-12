"""Integration tests for Jira MCP Server."""
