"""Contract tests for Jira MCP Server."""
