_instruments = ("langchain_core >= 0.1.0",)
_supports_metrics = False
