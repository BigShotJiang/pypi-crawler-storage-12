"""Integration tests for LeapOCR SDK."""
