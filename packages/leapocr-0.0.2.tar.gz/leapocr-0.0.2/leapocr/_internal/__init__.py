"""Internal utilities for LeapOCR SDK."""
