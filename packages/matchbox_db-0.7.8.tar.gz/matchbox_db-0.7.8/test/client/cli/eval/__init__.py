"""Eval CLI tests package."""
