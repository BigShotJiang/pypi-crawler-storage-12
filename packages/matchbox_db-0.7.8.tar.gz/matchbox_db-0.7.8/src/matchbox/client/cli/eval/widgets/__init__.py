"""UI widgets for entity resolution evaluation tool."""
