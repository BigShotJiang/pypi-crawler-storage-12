"""Entry point for python -m simplerpyc.server."""

from simplerpyc.server.server import main

if __name__ == "__main__":
    main()
