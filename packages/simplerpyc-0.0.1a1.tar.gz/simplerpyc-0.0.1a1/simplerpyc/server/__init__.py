"""Server module for simplerpyc."""
