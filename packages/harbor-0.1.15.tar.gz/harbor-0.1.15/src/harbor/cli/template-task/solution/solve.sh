#!/bin/bash

# Use this file to solve the task.