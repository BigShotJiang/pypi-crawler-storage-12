# Execute as "python -m cantools"

from . import _main as main

main()
