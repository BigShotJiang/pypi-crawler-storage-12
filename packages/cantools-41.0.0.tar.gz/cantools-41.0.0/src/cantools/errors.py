class Error(Exception):
    """Base exception for all exception in the package.

    """
