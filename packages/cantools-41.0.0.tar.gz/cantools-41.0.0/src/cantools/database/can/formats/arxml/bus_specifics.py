class AutosarBusSpecifics:
    """This class collects the AUTOSAR specific information of a CAN bus

    """
    def __init__(self):
        pass
