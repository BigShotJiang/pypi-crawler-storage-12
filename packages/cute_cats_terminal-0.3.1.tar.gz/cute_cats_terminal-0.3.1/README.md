# cute-cats-terminal

Print colorful and cute cats to the terminal.
