emoji1 = """
≽^•⩊•^≼
"""

emoji2 = """
ฅ^•ﻌ•^ฅ
"""

emoji3 = """
ᓚ₍ ^. .^₎
"""

emoji4 = """
/ᐠ - ˕ -マ
"""

emoji5 = """
≽^• ˕ • ྀི≼
"""

emoji6 = """
=^◕⩊◕^=
"""

EMOJI_DICT = {
    "playful cat": emoji1,
    "waving cat": emoji2,
    "sleepy cat": emoji3,
    "shy cat": emoji4,
    "blushing cat": emoji5,
    "curious cat": emoji6,
}
