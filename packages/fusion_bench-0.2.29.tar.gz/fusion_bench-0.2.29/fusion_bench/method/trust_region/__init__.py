# flake8: noqa F401
from .clip_task_arithmetic import TaskArithmeticWithTrustRegionForCLIP
