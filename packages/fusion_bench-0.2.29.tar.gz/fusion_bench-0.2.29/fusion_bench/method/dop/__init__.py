from .dop import ContinualDOPForCLIP
