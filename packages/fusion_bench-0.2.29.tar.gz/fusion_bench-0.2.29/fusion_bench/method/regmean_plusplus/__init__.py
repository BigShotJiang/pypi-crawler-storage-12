# flake8: noqa F401
from .clip_regmean_plusplus import RegMeanAlgorithmForCLIPPlusPlus
from .regmean_plusplus import RegMeanAlgorithmPlusPlus
