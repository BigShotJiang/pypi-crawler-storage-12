from fusion_bench.dataset.clip_dataset import CLIPDataset
