classnames = ["negative", "positive"]

templates = [lambda c: f"a {c} review of a movie."]
