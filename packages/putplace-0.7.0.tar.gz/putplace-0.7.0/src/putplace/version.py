"""Version information for putplace.

IMPORTANT: Keep this version in sync with pyproject.toml!
"""

__version__ = "0.7.0"
