"""Models for all API interactions."""
