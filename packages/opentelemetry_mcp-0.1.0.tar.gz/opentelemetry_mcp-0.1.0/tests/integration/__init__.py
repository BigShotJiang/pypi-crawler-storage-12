"""Integration tests using VCR recordings against real backends."""
