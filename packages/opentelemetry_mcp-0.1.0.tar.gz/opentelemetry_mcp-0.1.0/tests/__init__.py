"""Tests for Opentelemetry MCP Server."""
