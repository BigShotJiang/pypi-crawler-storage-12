# Release Pipeline Setup Guide

This guide explains how to set up the automated release pipeline for maintainers. This is a **one-time setup** that enables automatic PyPI publishing without API tokens.

## Overview

The release pipeline uses:
- **Commitizen** - Automated version management and changelog generation
- **PyPI Trusted Publishing (OIDC)** - Secure, tokenless publishing
- **GitHub Actions** - Workflow automation

## Prerequisites

- GitHub repository admin access
- PyPI account with project ownership
- Personal Access Token (PAT) or GitHub App

## Setup Steps

### 1. Create GitHub Personal Access Token

The workflow needs permission to push commits, tags, and create releases.

**Option A: Personal Access Token (Easier)**

1. Go to GitHub Settings → Developer settings → Personal access tokens → Fine-grained tokens
2. Click "Generate new token"
3. Configure:
   - **Token name**: `opentelemetry-mcp-releases`
   - **Repository access**: Only select repositories → `opentelemetry-mcp-server`
   - **Permissions**:
     - Repository permissions:
       - **Contents**: Read and write
       - **Metadata**: Read (auto-selected)
4. Click "Generate token"
5. **Copy the token immediately** (you won't see it again!)

**Option B: GitHub App (More Secure)**

For organizations, using a GitHub App is more secure:
1. Create a GitHub App with `contents: write` permission
2. Install app on the repository
3. Generate private key
4. Store private key and app ID in secrets

### 2. Add GitHub Secret

1. Go to repository **Settings → Secrets and variables → Actions**
2. Click "New repository secret"
3. Configure:
   - **Name**: `GH_ACCESS_TOKEN`
   - **Secret**: Paste the PAT from step 1
4. Click "Add secret"

### 3. Configure PyPI Trusted Publisher

This eliminates the need for API tokens!

**For Production PyPI:**

1. Go to [https://pypi.org/](https://pypi.org/)
2. Log in to your account
3. Navigate to your project: [https://pypi.org/manage/project/opentelemetry-mcp/](https://pypi.org/manage/project/opentelemetry-mcp/)
4. Go to **Publishing** section
5. Scroll to **"Add a new publisher"**
6. Select **"GitHub"** as the publisher
7. Fill in the form:
   - **Owner**: `traceloop` (or your GitHub org/username)
   - **Repository name**: `opentelemetry-mcp-server`
   - **Workflow name**: `release.yml`
   - **Environment name**: Leave blank (or use `release` if you add environment protection)
8. Click "Add"

You should see the trusted publisher listed. The workflow can now publish without any API tokens!

**For TestPyPI (Recommended for Testing):**

Follow the same steps on [https://test.pypi.org/](https://test.pypi.org/) to test the pipeline safely:

1. Create account on TestPyPI if needed
2. Create the project (or it will be created automatically on first upload)
3. Configure trusted publisher with same settings
4. Modify `.github/workflows/release.yml` to use TestPyPI temporarily:
   ```yaml
   - name: Publish to TestPyPI
     uses: pypa/gh-action-pypi-publish@release/v1
     with:
       repository-url: https://test.pypi.org/legacy/
   ```

### 4. Verify Setup

**Test Commitizen locally:**

```bash
# Install Commitizen
pip install commitizen

# Test version bump (dry run - doesn't change anything)
cz bump --dry-run

# Should output something like:
# bump: version 0.1.0 → 0.2.0
```

**Check for conventional commits:**

```bash
# View recent commits
git log --oneline main -10

# Look for: feat:, fix:, docs:, etc.
```

If commits don't follow the convention, the next release might not bump the version correctly.

### 5. Test the Release Workflow

**Test on TestPyPI first (Recommended):**

1. Configure TestPyPI trusted publisher (step 3)
2. Modify `release.yml` to use TestPyPI URL
3. Go to **Actions** tab
4. Select "Release" workflow
5. Click "Run workflow" → select `main` branch → "Run workflow"
6. Monitor the workflow execution
7. Check [test.pypi.org](https://test.pypi.org/project/opentelemetry-mcp/) for your package
8. Test installation:
   ```bash
   pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ opentelemetry-mcp
   ```

**Once TestPyPI works:**

1. Revert `release.yml` to use production PyPI
2. Commit and push changes
3. Trigger release workflow for production

## How to Release (After Setup)

Once setup is complete, releasing is simple:

### 1. Ensure Commits Follow Convention

All commits since the last release should follow Conventional Commits:

```bash
git log --oneline v0.1.0..HEAD

# Good:
feat: add search_spans tool
fix: correct token calculation

# Bad:
Updated files
Fixed bug
```

### 2. Trigger Release Workflow

1. Go to **Actions** tab in GitHub
2. Select "Release" workflow
3. Click "Run workflow"
4. Ensure `main` branch is selected
5. Click "Run workflow" button

### 3. Monitor Execution

The workflow will:
1. **Bump version** (1-2 minutes)
   - Analyze commits
   - Determine version bump
   - Update version files
   - Generate changelog
   - Create tag and push

2. **Build and publish** (1-2 minutes)
   - Build package with UV
   - Publish to PyPI via OIDC
   - Create GitHub Release

3. **Verify** (1 minute)
   - Test installation from PyPI
   - Confirm version

Total time: ~3-5 minutes

### 4. Verify Release

**Check GitHub:**
- New tag created (e.g., `v0.2.0`)
- GitHub Release created with changelog
- Commit pushed with version bump

**Check PyPI:**
- Visit [pypi.org/project/opentelemetry-mcp/](https://pypi.org/project/opentelemetry-mcp/)
- New version should be listed
- Check package details are correct

**Test Installation:**
```bash
pip install --upgrade opentelemetry-mcp
python -c "import opentelemetry_mcp; print(opentelemetry_mcp.__version__)"
```

## Troubleshooting

### Issue: Workflow fails with "Not a valid commit"

**Cause**: No commits since last release that trigger version bump (only docs/test/chore commits)

**Solution**: Either:
- Make a commit that triggers version bump (feat/fix)
- Or wait for more changes before releasing

### Issue: PyPI publish fails with authentication error

**Cause**: Trusted Publisher not configured correctly

**Solution**:
1. Go to PyPI project settings
2. Verify trusted publisher exists
3. Check owner/repo/workflow names match exactly
4. Ensure workflow file is named exactly `release.yml`

### Issue: Git push fails in bump-version job

**Cause**: `GH_ACCESS_TOKEN` missing or has insufficient permissions

**Solution**:
1. Check secret exists: Settings → Secrets → Actions
2. Verify PAT has `contents: write` permission
3. Ensure PAT isn't expired
4. Try regenerating the token

### Issue: Version didn't bump as expected

**Cause**: Commit messages don't follow Conventional Commits

**Solution**:
- Review commits: `git log --oneline v0.1.0..HEAD`
- Ensure commit types are correct (feat, fix, etc.)
- For next release, follow the convention
- Can manually specify bump: `cz bump --increment MINOR`

### Issue: Package not found on PyPI after publish

**Cause**: Package name already taken or PyPI indexing delay

**Solution**:
- Wait 5-10 minutes for PyPI to index
- Check if package name is available on PyPI
- Verify no errors in publish step of workflow

## Security Notes

### Trusted Publishing Benefits

- **No API tokens stored** - Zero credential management
- **Short-lived tokens** - Automatically expire after use
- **Audit trail** - Every publish tied to GitHub Actions run
- **Attestations** - Automatic digital signatures for supply chain security

### PAT Security

- Use fine-grained tokens (not classic)
- Limit to specific repository
- Minimum required permissions
- Set expiration (e.g., 1 year)
- Rotate periodically

### Secrets Management

- Never commit secrets to repository
- Use GitHub Secrets (encrypted at rest)
- Limit access to repository admins
- Audit secret usage regularly

## Maintenance

### Updating Commitizen

```bash
pip install --upgrade commitizen
```

### Updating GitHub Actions

Workflows use:
- `actions/checkout@v4` - Update to latest v4.x
- `actions/setup-python@v5` - Update to latest v5.x
- `astral-sh/setup-uv@v3` - Update to latest v3.x
- `pypa/gh-action-pypi-publish@release/v1` - Use `release/v1` (auto-updates)

Dependabot can manage these automatically.

### Rotating PAT

1. Generate new PAT with same permissions
2. Update `GH_ACCESS_TOKEN` secret
3. Delete old PAT from GitHub settings

## Additional Resources

### Documentation

- **Commitizen**: [https://commitizen-tools.github.io/commitizen/](https://commitizen-tools.github.io/commitizen/)
- **Conventional Commits**: [https://www.conventionalcommits.org/](https://www.conventionalcommits.org/)
- **PyPI Trusted Publishing**: [https://docs.pypi.org/trusted-publishers/](https://docs.pypi.org/trusted-publishers/)
- **GitHub OIDC**: [https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/about-security-hardening-with-openid-connect](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/about-security-hardening-with-openid-connect)

### Example Projects

- **OpenLLMetry**: [https://github.com/traceloop/openllmetry](https://github.com/traceloop/openllmetry) (uses the same pattern)

### Support

For issues with the release pipeline:
1. Check workflow logs in Actions tab
2. Review this setup guide
3. Check troubleshooting section
4. Open issue in repository

## Checklist

Use this checklist for initial setup:

- [ ] Created Personal Access Token with `contents: write`
- [ ] Added `GH_ACCESS_TOKEN` to repository secrets
- [ ] Configured PyPI Trusted Publisher
- [ ] (Optional) Configured TestPyPI Trusted Publisher
- [ ] Tested Commitizen locally: `cz bump --dry-run`
- [ ] Verified workflow file exists: `.github/workflows/release.yml`
- [ ] Ran test release on TestPyPI successfully
- [ ] Verified package installs from TestPyPI
- [ ] Switched to production PyPI
- [ ] Documented process in `CONTRIBUTING.md`
- [ ] Shared setup guide with team
- [ ] Set up monitoring for failed workflows

Setup complete! 🎉

You can now trigger releases via the GitHub Actions UI, and the system will handle versioning, changelog generation, and publishing automatically.
