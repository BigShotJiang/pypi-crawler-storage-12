"""OpenTelemetry MCP Server - Query OpenTelemetry traces from LLM applications."""

__version__ = "0.1.0"
