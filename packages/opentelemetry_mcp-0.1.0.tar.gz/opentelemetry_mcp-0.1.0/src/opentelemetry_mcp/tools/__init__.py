"""MCP tools for querying OpenTelemetry traces."""

__all__ = []
