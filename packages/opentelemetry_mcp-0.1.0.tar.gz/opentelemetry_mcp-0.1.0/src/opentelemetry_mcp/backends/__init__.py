"""Backend implementations for different OpenTelemetry trace storage systems."""

from opentelemetry_mcp.backends.base import BaseBackend

__all__ = ["BaseBackend"]
