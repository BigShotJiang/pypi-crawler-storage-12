from .rpc import register, call_rpc
from .json_rpc import call_json