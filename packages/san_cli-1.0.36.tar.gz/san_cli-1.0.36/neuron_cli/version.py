"""Version information for Neuron CLI"""

__version__ = "1.0.36"  # SAN CLI (SPACE Agent Neuron CLI) - Add list_installed method to MarketplaceManager
__author__ = "Kai Gartner (https://linkedin.com/in/kaigartner)"
__license__ = "Commercial - All Rights Reserved"
