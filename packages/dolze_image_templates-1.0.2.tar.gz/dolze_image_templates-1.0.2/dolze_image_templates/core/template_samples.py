"""
Template sample URLs configuration.

This module contains the mapping of template names to their sample image URLs.
Add your S3 URLs here as they become available.
"""

# Template name to S3 URL mapping
# Template name to S3 URL mapping
TEMPLATE_SAMPLE_URLS = {
    "annual_report": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/annual_report.png",
    "contact_us": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/contact_us.png",
    "creative_marketing_agency": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/creative_marketing_agency.png",
    "faq_template": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/faq_template.png",
    "financial_education": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/financial_education.png",
    "flash_sale": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/flash_sale.png",
    "hiring_announcement": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/hiring_announcement.png",
    "job_opening": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/job_opening.png",
    "job_search_promotion": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/job_search_promotion.png",
    "launch_announcement": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/launch_announcement.png",
    "myth_vs_fact": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/myth_vs_fact.png",
    "partnership_announcement": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/partnership_announcement.png",
    "pricing_plans": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/pricing_plans.png",
    "product_promotion_v2": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/product_promotion_v2.png",
    "product_promotion": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/product_promotion.png",
    "service_promotion": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/service_promotion.png",
    "services_showcase": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/services_showcase.png",
    "smart_investment": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/smart_investment.png",
    "social_media_tips": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/social_media_tips.png",
    "strategy_cards": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/strategy_cards.png",
    "testimonial_card": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/testimonial_card.png",
    "we_are_hiring": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/we_are_hiring.png",
    "why_us_reasons": "https://dolze-docs-uat.s3.ap-south-1.amazonaws.com/post_templates/why_us_reasons.png",
}


def get_sample_url(template_name: str) -> str:
    """
    Get the sample URL for a template.

    Args:
        template_name: Name of the template

    Returns:
        str: The sample URL if exists, empty string otherwise
    """
    return TEMPLATE_SAMPLE_URLS.get(template_name, "")
