# ahorcadoZzz

## Descripción 🚀

Proyecto realizado con python y que implementa una interfaz gráfica haciendo uso de tkinter.
En este magnífico ahorcado podrás jugar con palabras relacionadas con la informatica (si no te duermes antes Zzz)

## Ejemplos de Uso 🔧

```python
import AHORCADOZzz as zzz

zzz.init()
```

>This repository is licensed under
>[Creativecommons Org Licenses By Sa 4](http://creativecommons.org/licenses/by-sa/4.0/)