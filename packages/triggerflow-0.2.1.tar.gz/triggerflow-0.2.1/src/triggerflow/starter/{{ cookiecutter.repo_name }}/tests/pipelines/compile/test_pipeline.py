"""
This is a boilerplate test file for pipeline 'compile'
generated using Kedro 1.0.0
Please add your pipeline tests here.

Kedro recommends using `pytest` framework, more info about it can be found
in the official documentation:
https://docs.pytest.org/en/latest/getting-started.html
"""
