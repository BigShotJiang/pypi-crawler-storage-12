Annotations
===========

.. container:: regression

   .. lua:data:: annotated_object
      :global:
      :private:
      :protected:
      :package:
      :abstract:
      :virtual:
      :async:

      Description

   .. lua:data:: custom_annotated_object
      :annotation: custom annotation
