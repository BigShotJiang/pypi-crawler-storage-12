--- Description
--- !doctype module
--- @class autodoc
autodoc = {}

--- Description.
function autodoc.bark() end
