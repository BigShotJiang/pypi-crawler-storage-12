project = "Test"
copyright = "test"
author = "test"

extensions = ["sphinx_lua_ls"]
lua_ls_backend = "luals"
lua_ls_project_root = "lua"
