--- @namespace autodoc

--- Description
local autodoc = {}

--- Description.
function autodoc.foo() end

--- Description.
function autodoc.bar() end

--- Description.
function autodoc.baz() end

function autodoc.undoc() end

return autodoc
