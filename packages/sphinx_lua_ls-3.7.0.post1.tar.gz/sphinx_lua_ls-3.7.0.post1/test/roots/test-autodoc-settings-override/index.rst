Test autodoc
============

.. container:: regression

   .. lua:autoobject:: autodoc

   .. lua:autoobject:: autodoc
      :exclude-members: +foo
      :no-undoc-members:
