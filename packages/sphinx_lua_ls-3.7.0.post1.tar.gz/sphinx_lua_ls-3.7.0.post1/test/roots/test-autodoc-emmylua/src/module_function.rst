Module function
===============

.. container:: regression

   .. lua:autoobject:: module_function
