Incongruent export
==================

.. container:: regression

   .. lua:autoobject:: incongruent_export
      :members:

   .. lua:autoobject:: incongruent_export_2
      :members:
