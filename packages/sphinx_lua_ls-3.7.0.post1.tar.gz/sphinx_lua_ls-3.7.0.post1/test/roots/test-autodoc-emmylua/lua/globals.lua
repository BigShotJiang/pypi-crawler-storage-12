--- @meta

--- Description
local globals = {}

--- Description
function globals.foo() end

--- Description
--- @class GlobalsClass

--- Description
--- @type integer
GLOBAL_FOO = 1

return globals
