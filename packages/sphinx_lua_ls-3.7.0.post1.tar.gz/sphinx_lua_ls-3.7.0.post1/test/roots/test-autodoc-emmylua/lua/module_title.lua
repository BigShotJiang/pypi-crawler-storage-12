--- @meta

--- Description
local module_title = {}

--- Description.
function module_title.foo() end

return module_title
