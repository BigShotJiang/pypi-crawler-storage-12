#!/usr/bin/env python
#
# LeanCheck for Python.  Init module.
#
# (C) 2023-2025  Rudy Matela
# Distributed under the LGPL v2.1 or later (see the file LICENSE)

from leancheck.core import *
