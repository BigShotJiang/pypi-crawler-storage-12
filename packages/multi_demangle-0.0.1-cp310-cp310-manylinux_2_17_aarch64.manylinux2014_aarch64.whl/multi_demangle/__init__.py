from .multi_demangle import *

__doc__ = multi_demangle.__doc__
if hasattr(multi_demangle, "__all__"):
    __all__ = multi_demangle.__all__