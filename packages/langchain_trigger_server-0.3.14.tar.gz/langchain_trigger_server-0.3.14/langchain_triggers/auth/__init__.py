"""Authentication utilities for trigger webhooks."""

__all__ = []
