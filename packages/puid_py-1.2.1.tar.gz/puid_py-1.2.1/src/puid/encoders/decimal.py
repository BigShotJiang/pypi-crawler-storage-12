def decimal():
    zero = ord("0")

    return lambda n: n + zero
