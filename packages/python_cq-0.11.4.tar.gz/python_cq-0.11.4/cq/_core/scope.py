from enum import StrEnum


class CQScope(StrEnum):
    TRANSACTION = "__cq_transaction__"
