"""
Market Hours Management - Trading hours and holidays for global exchanges
"""
from datetime import datetime, time, timedelta
from typing import Optional, Dict, List, Tuple
from zoneinfo import ZoneInfo
from dataclasses import dataclass
from enum import Enum


class MarketState(Enum):
    """Market state enumeration"""
    CLOSED = "CLOSED"
    PRE_MARKET = "PRE_MARKET"
    OPEN = "OPEN"
    POST_MARKET = "POST_MARKET"


@dataclass
class TradingSession:
    """Trading session with open and close times"""
    open_time: time
    close_time: time
    timezone: str
    
    def is_within(self, dt: datetime) -> bool:
        """Check if datetime is within this session"""
        local_dt = dt.astimezone(ZoneInfo(self.timezone))
        current_time = local_dt.time()
        return self.open_time <= current_time < self.close_time


@dataclass
class ExchangeInfo:
    """Exchange information with trading hours"""
    name: str
    code: str
    timezone: str
    regular_hours: TradingSession
    pre_market: Optional[TradingSession] = None
    post_market: Optional[TradingSession] = None
    trading_days: List[int] = None  # 0=Monday, 4=Friday
    
    def __post_init__(self):
        if self.trading_days is None:
            self.trading_days = [0, 1, 2, 3, 4]  # Monday to Friday


# Exchange definitions
EXCHANGES: Dict[str, ExchangeInfo] = {
    # United States
    "NYSE": ExchangeInfo(
        name="New York Stock Exchange",
        code="NYSE",
        timezone="America/New_York",
        regular_hours=TradingSession(time(9, 30), time(16, 0), "America/New_York"),
        pre_market=TradingSession(time(4, 0), time(9, 30), "America/New_York"),
        post_market=TradingSession(time(16, 0), time(20, 0), "America/New_York"),
    ),
    "NASDAQ": ExchangeInfo(
        name="NASDAQ Stock Market",
        code="NASDAQ",
        timezone="America/New_York",
        regular_hours=TradingSession(time(9, 30), time(16, 0), "America/New_York"),
        pre_market=TradingSession(time(4, 0), time(9, 30), "America/New_York"),
        post_market=TradingSession(time(16, 0), time(20, 0), "America/New_York"),
    ),
    
    # United Kingdom
    "LSE": ExchangeInfo(
        name="London Stock Exchange",
        code="LSE",
        timezone="Europe/London",
        regular_hours=TradingSession(time(8, 0), time(16, 30), "Europe/London"),
    ),
    
    # Europe
    "XETRA": ExchangeInfo(
        name="Deutsche Börse XETRA",
        code="XETRA",
        timezone="Europe/Berlin",
        regular_hours=TradingSession(time(9, 0), time(17, 30), "Europe/Berlin"),
    ),
    "EURONEXT": ExchangeInfo(
        name="Euronext Paris",
        code="EURONEXT",
        timezone="Europe/Paris",
        regular_hours=TradingSession(time(9, 0), time(17, 30), "Europe/Paris"),
    ),
    "BME": ExchangeInfo(
        name="Bolsa de Madrid",
        code="BME",
        timezone="Europe/Madrid",
        regular_hours=TradingSession(time(9, 0), time(17, 30), "Europe/Madrid"),
    ),
    "SIX": ExchangeInfo(
        name="SIX Swiss Exchange",
        code="SIX",
        timezone="Europe/Zurich",
        regular_hours=TradingSession(time(9, 0), time(17, 30), "Europe/Zurich"),
    ),
    "BIT": ExchangeInfo(
        name="Borsa Italiana",
        code="BIT",
        timezone="Europe/Rome",
        regular_hours=TradingSession(time(9, 0), time(17, 30), "Europe/Rome"),
    ),
    
    # Asia
    "TSE": ExchangeInfo(
        name="Tokyo Stock Exchange",
        code="TSE",
        timezone="Asia/Tokyo",
        regular_hours=TradingSession(time(9, 0), time(15, 0), "Asia/Tokyo"),
    ),
    "HKEX": ExchangeInfo(
        name="Hong Kong Stock Exchange",
        code="HKEX",
        timezone="Asia/Hong_Kong",
        regular_hours=TradingSession(time(9, 30), time(16, 0), "Asia/Hong_Kong"),
    ),
    "SSE": ExchangeInfo(
        name="Shanghai Stock Exchange",
        code="SSE",
        timezone="Asia/Shanghai",
        regular_hours=TradingSession(time(9, 30), time(15, 0), "Asia/Shanghai"),
    ),
    "NSE": ExchangeInfo(
        name="National Stock Exchange of India",
        code="NSE",
        timezone="Asia/Kolkata",
        regular_hours=TradingSession(time(9, 15), time(15, 30), "Asia/Kolkata"),
    ),
    "KRX": ExchangeInfo(
        name="Korea Exchange",
        code="KRX",
        timezone="Asia/Seoul",
        regular_hours=TradingSession(time(9, 0), time(15, 30), "Asia/Seoul"),
    ),
    
    # Australia
    "ASX": ExchangeInfo(
        name="Australian Securities Exchange",
        code="ASX",
        timezone="Australia/Sydney",
        regular_hours=TradingSession(time(10, 0), time(16, 0), "Australia/Sydney"),
    ),
    
    # Canada
    "TSX": ExchangeInfo(
        name="Toronto Stock Exchange",
        code="TSX",
        timezone="America/Toronto",
        regular_hours=TradingSession(time(9, 30), time(16, 0), "America/Toronto"),
    ),
}


# Market holidays by exchange (year 2025)
MARKET_HOLIDAYS_2025: Dict[str, List[datetime]] = {
    "NYSE": [
        datetime(2025, 1, 1),   # New Year's Day
        datetime(2025, 1, 20),  # Martin Luther King Jr. Day
        datetime(2025, 2, 17),  # Presidents' Day
        datetime(2025, 4, 18),  # Good Friday
        datetime(2025, 5, 26),  # Memorial Day
        datetime(2025, 6, 19),  # Juneteenth
        datetime(2025, 7, 4),   # Independence Day
        datetime(2025, 9, 1),   # Labor Day
        datetime(2025, 11, 27), # Thanksgiving
        datetime(2025, 12, 25), # Christmas
    ],
    "NASDAQ": [
        datetime(2025, 1, 1),   # New Year's Day
        datetime(2025, 1, 20),  # Martin Luther King Jr. Day
        datetime(2025, 2, 17),  # Presidents' Day
        datetime(2025, 4, 18),  # Good Friday
        datetime(2025, 5, 26),  # Memorial Day
        datetime(2025, 6, 19),  # Juneteenth
        datetime(2025, 7, 4),   # Independence Day
        datetime(2025, 9, 1),   # Labor Day
        datetime(2025, 11, 27), # Thanksgiving
        datetime(2025, 12, 25), # Christmas
    ],
    "LSE": [
        datetime(2025, 1, 1),   # New Year's Day
        datetime(2025, 4, 18),  # Good Friday
        datetime(2025, 4, 21),  # Easter Monday
        datetime(2025, 5, 5),   # Early May Bank Holiday
        datetime(2025, 5, 26),  # Spring Bank Holiday
        datetime(2025, 8, 25),  # Summer Bank Holiday
        datetime(2025, 12, 25), # Christmas Day
        datetime(2025, 12, 26), # Boxing Day
    ],
    "XETRA": [
        datetime(2025, 1, 1),   # New Year's Day
        datetime(2025, 4, 18),  # Good Friday
        datetime(2025, 4, 21),  # Easter Monday
        datetime(2025, 5, 1),   # Labour Day
        datetime(2025, 12, 24), # Christmas Eve
        datetime(2025, 12, 25), # Christmas Day
        datetime(2025, 12, 26), # Boxing Day
        datetime(2025, 12, 31), # New Year's Eve
    ],
    "EURONEXT": [
        datetime(2025, 1, 1),   # New Year's Day
        datetime(2025, 4, 18),  # Good Friday
        datetime(2025, 4, 21),  # Easter Monday
        datetime(2025, 5, 1),   # Labour Day
        datetime(2025, 12, 25), # Christmas Day
        datetime(2025, 12, 26), # Boxing Day
    ],
    "TSE": [
        datetime(2025, 1, 1),   # New Year's Day
        datetime(2025, 1, 2),   # Bank Holiday
        datetime(2025, 1, 3),   # Bank Holiday
        datetime(2025, 1, 13),  # Coming of Age Day
        datetime(2025, 2, 11),  # National Foundation Day
        datetime(2025, 2, 23),  # Emperor's Birthday
        datetime(2025, 3, 20),  # Vernal Equinox Day
        datetime(2025, 4, 29),  # Showa Day
        datetime(2025, 5, 3),   # Constitution Day
        datetime(2025, 5, 4),   # Greenery Day
        datetime(2025, 5, 5),   # Children's Day
        datetime(2025, 7, 21),  # Marine Day
        datetime(2025, 8, 11),  # Mountain Day
        datetime(2025, 9, 15),  # Respect for the Aged Day
        datetime(2025, 9, 23),  # Autumnal Equinox Day
        datetime(2025, 10, 13), # Sports Day
        datetime(2025, 11, 3),  # Culture Day
        datetime(2025, 11, 23), # Labour Thanksgiving Day
        datetime(2025, 12, 31), # New Year's Eve
    ],
    "HKEX": [
        datetime(2025, 1, 1),   # New Year's Day
        datetime(2025, 1, 29),  # Lunar New Year
        datetime(2025, 1, 30),  # Lunar New Year
        datetime(2025, 1, 31),  # Lunar New Year
        datetime(2025, 4, 4),   # Ching Ming Festival
        datetime(2025, 4, 18),  # Good Friday
        datetime(2025, 4, 21),  # Easter Monday
        datetime(2025, 5, 1),   # Labour Day
        datetime(2025, 5, 5),   # Buddha's Birthday
        datetime(2025, 6, 2),   # Dragon Boat Festival
        datetime(2025, 7, 1),   # Hong Kong SAR Establishment Day
        datetime(2025, 9, 12),  # Day after Mid-Autumn Festival
        datetime(2025, 10, 1),  # National Day
        datetime(2025, 10, 11), # Chung Yeung Festival
        datetime(2025, 12, 25), # Christmas Day
        datetime(2025, 12, 26), # Boxing Day
    ],
}

# Copy US holidays to other markets
MARKET_HOLIDAYS_2025["BME"] = MARKET_HOLIDAYS_2025["EURONEXT"]
MARKET_HOLIDAYS_2025["SIX"] = MARKET_HOLIDAYS_2025["XETRA"]
MARKET_HOLIDAYS_2025["BIT"] = MARKET_HOLIDAYS_2025["EURONEXT"]
MARKET_HOLIDAYS_2025["SSE"] = MARKET_HOLIDAYS_2025["HKEX"]
MARKET_HOLIDAYS_2025["NSE"] = [
    datetime(2025, 1, 26),  # Republic Day
    datetime(2025, 3, 14),  # Holi
    datetime(2025, 3, 31),  # Ram Navami
    datetime(2025, 4, 18),  # Good Friday
    datetime(2025, 8, 15),  # Independence Day
    datetime(2025, 10, 2),  # Gandhi Jayanti
    datetime(2025, 10, 24), # Diwali
    datetime(2025, 11, 5),  # Guru Nanak Jayanti
    datetime(2025, 12, 25), # Christmas
]
MARKET_HOLIDAYS_2025["KRX"] = [
    datetime(2025, 1, 1),   # New Year
    datetime(2025, 1, 28),  # Lunar New Year
    datetime(2025, 1, 29),  # Lunar New Year
    datetime(2025, 1, 30),  # Lunar New Year
    datetime(2025, 3, 1),   # Independence Movement Day
    datetime(2025, 5, 5),   # Children's Day
    datetime(2025, 6, 6),   # Memorial Day
    datetime(2025, 8, 15),  # Liberation Day
    datetime(2025, 9, 8),   # Chuseok
    datetime(2025, 9, 9),   # Chuseok
    datetime(2025, 9, 10),  # Chuseok
    datetime(2025, 10, 3),  # National Foundation Day
    datetime(2025, 10, 9),  # Hangeul Day
    datetime(2025, 12, 25), # Christmas
]
MARKET_HOLIDAYS_2025["ASX"] = [
    datetime(2025, 1, 1),   # New Year's Day
    datetime(2025, 1, 27),  # Australia Day
    datetime(2025, 4, 18),  # Good Friday
    datetime(2025, 4, 21),  # Easter Monday
    datetime(2025, 4, 25),  # ANZAC Day
    datetime(2025, 6, 9),   # Queen's Birthday
    datetime(2025, 12, 25), # Christmas Day
    datetime(2025, 12, 26), # Boxing Day
]
MARKET_HOLIDAYS_2025["TSX"] = MARKET_HOLIDAYS_2025["NYSE"]


class MarketHours:
    """Market hours management for global exchanges"""
    
    def __init__(self, exchange_code: str = "NYSE"):
        """
        Initialize market hours for a specific exchange
        
        Args:
            exchange_code: Exchange code (NYSE, NASDAQ, LSE, etc.)
        """
        if exchange_code not in EXCHANGES:
            raise ValueError(f"Unknown exchange: {exchange_code}. "
                           f"Available: {list(EXCHANGES.keys())}")
        
        self.exchange_code = exchange_code
        self.exchange = EXCHANGES[exchange_code]
        self.holidays = MARKET_HOLIDAYS_2025.get(exchange_code, [])
    
    def is_holiday(self, dt: Optional[datetime] = None) -> bool:
        """
        Check if date is a market holiday
        
        Args:
            dt: Datetime to check (default: now in exchange timezone)
            
        Returns:
            True if holiday, False otherwise
        """
        if dt is None:
            dt = datetime.now(ZoneInfo(self.exchange.timezone))
        
        # Convert to exchange timezone and get date
        local_dt = dt.astimezone(ZoneInfo(self.exchange.timezone))
        check_date = local_dt.date()
        
        # Check against holidays
        for holiday in self.holidays:
            if holiday.date() == check_date:
                return True
        
        return False
    
    def is_trading_day(self, dt: Optional[datetime] = None) -> bool:
        """
        Check if date is a trading day (not weekend, not holiday)
        
        Args:
            dt: Datetime to check (default: now in exchange timezone)
            
        Returns:
            True if trading day, False otherwise
        """
        if dt is None:
            dt = datetime.now(ZoneInfo(self.exchange.timezone))
        
        local_dt = dt.astimezone(ZoneInfo(self.exchange.timezone))
        
        # Check weekend
        if local_dt.weekday() not in self.exchange.trading_days:
            return False
        
        # Check holiday
        if self.is_holiday(dt):
            return False
        
        return True
    
    def get_market_state(self, dt: Optional[datetime] = None) -> MarketState:
        """
        Get current market state
        
        Args:
            dt: Datetime to check (default: now in exchange timezone)
            
        Returns:
            MarketState enum (CLOSED, PRE_MARKET, OPEN, POST_MARKET)
        """
        if dt is None:
            dt = datetime.now(ZoneInfo(self.exchange.timezone))
        
        # Check if trading day
        if not self.is_trading_day(dt):
            return MarketState.CLOSED
        
        # Check regular hours
        if self.exchange.regular_hours.is_within(dt):
            return MarketState.OPEN
        
        # Check pre-market
        if self.exchange.pre_market and self.exchange.pre_market.is_within(dt):
            return MarketState.PRE_MARKET
        
        # Check post-market
        if self.exchange.post_market and self.exchange.post_market.is_within(dt):
            return MarketState.POST_MARKET
        
        return MarketState.CLOSED
    
    def is_market_open(self, dt: Optional[datetime] = None) -> bool:
        """
        Check if market is currently open (regular hours)
        
        Args:
            dt: Datetime to check (default: now)
            
        Returns:
            True if market is open, False otherwise
        """
        return self.get_market_state(dt) == MarketState.OPEN
    
    def next_market_open(self, dt: Optional[datetime] = None) -> datetime:
        """
        Get next market opening datetime
        
        Args:
            dt: Starting datetime (default: now in exchange timezone)
            
        Returns:
            Datetime of next market open
        """
        if dt is None:
            dt = datetime.now(ZoneInfo(self.exchange.timezone))
        
        local_dt = dt.astimezone(ZoneInfo(self.exchange.timezone))
        
        # Start from next minute
        check_dt = local_dt.replace(second=0, microsecond=0) + timedelta(minutes=1)
        
        # Search for next open (max 30 days)
        for _ in range(30 * 24 * 60):  # 30 days in minutes
            if self.is_trading_day(check_dt):
                # Create datetime with market open time
                open_dt = check_dt.replace(
                    hour=self.exchange.regular_hours.open_time.hour,
                    minute=self.exchange.regular_hours.open_time.minute,
                    second=0,
                    microsecond=0
                )
                
                if open_dt > local_dt:
                    return open_dt
            
            # Move to next day
            check_dt = (check_dt + timedelta(days=1)).replace(hour=0, minute=0)
        
        raise RuntimeError("Could not find next market open within 30 days")
    
    def next_market_close(self, dt: Optional[datetime] = None) -> datetime:
        """
        Get next market closing datetime
        
        Args:
            dt: Starting datetime (default: now in exchange timezone)
            
        Returns:
            Datetime of next market close
        """
        if dt is None:
            dt = datetime.now(ZoneInfo(self.exchange.timezone))
        
        local_dt = dt.astimezone(ZoneInfo(self.exchange.timezone))
        
        # If market is open today, return today's close
        if self.is_trading_day(local_dt):
            close_dt = local_dt.replace(
                hour=self.exchange.regular_hours.close_time.hour,
                minute=self.exchange.regular_hours.close_time.minute,
                second=0,
                microsecond=0
            )
            
            if close_dt > local_dt:
                return close_dt
        
        # Otherwise find next trading day and return its close
        next_open = self.next_market_open(local_dt)
        return next_open.replace(
            hour=self.exchange.regular_hours.close_time.hour,
            minute=self.exchange.regular_hours.close_time.minute
        )
    
    def get_trading_hours(self) -> Tuple[time, time]:
        """
        Get regular trading hours for this exchange
        
        Returns:
            Tuple of (open_time, close_time)
        """
        return (self.exchange.regular_hours.open_time, 
                self.exchange.regular_hours.close_time)
    
    def get_ttl_for_market_state(self, state: Optional[MarketState] = None) -> int:
        """
        Get recommended cache TTL based on market state
        
        Args:
            state: Market state (default: current state)
            
        Returns:
            TTL in seconds
        """
        if state is None:
            state = self.get_market_state()
        
        if state == MarketState.OPEN:
            return 60  # 1 minute during trading
        elif state in (MarketState.PRE_MARKET, MarketState.POST_MARKET):
            return 300  # 5 minutes during extended hours
        else:  # CLOSED
            return 3600  # 1 hour when closed


# Convenience functions for common exchanges

def is_market_open(exchange: str = "NYSE", dt: Optional[datetime] = None) -> bool:
    """
    Quick check if a market is open
    
    Args:
        exchange: Exchange code (default: NYSE)
        dt: Datetime to check (default: now)
        
    Returns:
        True if market is open
        
    Example:
        >>> from fba_finance.market_hours import is_market_open
        >>> if is_market_open("NYSE"):
        ...     print("NYSE is open for trading")
    """
    mh = MarketHours(exchange)
    return mh.is_market_open(dt)


def get_market_state(exchange: str = "NYSE", dt: Optional[datetime] = None) -> MarketState:
    """
    Get market state
    
    Args:
        exchange: Exchange code (default: NYSE)
        dt: Datetime to check (default: now)
        
    Returns:
        MarketState enum
        
    Example:
        >>> from fba_finance.market_hours import get_market_state, MarketState
        >>> state = get_market_state("LSE")
        >>> if state == MarketState.OPEN:
        ...     print("London market is open")
    """
    mh = MarketHours(exchange)
    return mh.get_market_state(dt)


def next_market_open(exchange: str = "NYSE", dt: Optional[datetime] = None) -> datetime:
    """
    Get next market opening time
    
    Args:
        exchange: Exchange code (default: NYSE)
        dt: Starting datetime (default: now)
        
    Returns:
        Datetime of next market open
        
    Example:
        >>> from fba_finance.market_hours import next_market_open
        >>> next_open = next_market_open("NASDAQ")
        >>> print(f"NASDAQ opens at: {next_open}")
    """
    mh = MarketHours(exchange)
    return mh.next_market_open(dt)


def get_all_exchanges() -> List[str]:
    """
    Get list of all supported exchange codes
    
    Returns:
        List of exchange codes
        
    Example:
        >>> from fba_finance.market_hours import get_all_exchanges
        >>> exchanges = get_all_exchanges()
        >>> print(f"Supported exchanges: {exchanges}")
    """
    return list(EXCHANGES.keys())


def get_exchange_info(exchange: str) -> Dict:
    """
    Get exchange information
    
    Args:
        exchange: Exchange code
        
    Returns:
        Dictionary with exchange details
        
    Example:
        >>> from fba_finance.market_hours import get_exchange_info
        >>> info = get_exchange_info("TSE")
        >>> print(f"Timezone: {info['timezone']}")
    """
    if exchange not in EXCHANGES:
        raise ValueError(f"Unknown exchange: {exchange}")
    
    ex = EXCHANGES[exchange]
    return {
        "name": ex.name,
        "code": ex.code,
        "timezone": ex.timezone,
        "regular_hours": {
            "open": ex.regular_hours.open_time.strftime("%H:%M"),
            "close": ex.regular_hours.close_time.strftime("%H:%M"),
        },
        "has_pre_market": ex.pre_market is not None,
        "has_post_market": ex.post_market is not None,
        "trading_days": ex.trading_days,
    }
