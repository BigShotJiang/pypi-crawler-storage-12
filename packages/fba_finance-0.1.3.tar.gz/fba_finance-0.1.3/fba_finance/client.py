"""
Main client interface for FBA Finance
"""
from typing import List, Optional, Dict
from datetime import datetime, timedelta

from .aggregator import ProviderAggregator
from .models import Quote, HistoricalData, ProviderStatus
from .config import Config


class FinanceClient:
    """
    Main client for accessing financial data from multiple sources.
    
    Features:
    - Automatic fallback between providers
    - Built-in caching
    - Rate limiting
    - Support for all major markets
    
    Example:
        >>> client = FinanceClient()
        >>> quote = client.get_quote("AAPL")
        >>> print(quote.price)
    """
    
    def __init__(self,
                 use_cache: bool = True,
                 use_rate_limiting: bool = True,
                 provider_priority: Optional[List[str]] = None):
        """
        Initialize the finance client
        
        Args:
            use_cache: Enable caching (default: True)
            use_rate_limiting: Enable rate limiting (default: True)
            provider_priority: Custom provider priority order (optional)
        """
        self.aggregator = ProviderAggregator(
            use_cache=use_cache,
            use_rate_limiting=use_rate_limiting,
            provider_priority=provider_priority
        )
    
    def get_quote(self, symbol: str, provider: Optional[str] = None) -> Optional[Quote]:
        """
        Get real-time (or near-real-time) quote for a symbol
        
        Args:
            symbol: Ticker symbol (e.g., "AAPL", "MSFT", "BTC-USD")
            provider: Force specific provider (optional)
        
        Returns:
            Quote object with current price and metadata
        
        Example:
            >>> quote = client.get_quote("AAPL")
            >>> print(f"{quote.symbol}: ${quote.price}")
        """
        return self.aggregator.get_quote(symbol, force_provider=provider)
    
    def get_quotes(self, symbols: List[str], provider: Optional[str] = None) -> Dict[str, Quote]:
        """
        Get quotes for multiple symbols (batch operation)
        
        Args:
            symbols: List of ticker symbols
            provider: Force specific provider (optional)
        
        Returns:
            Dictionary mapping symbols to Quote objects
        
        Example:
            >>> quotes = client.get_quotes(["AAPL", "MSFT", "GOOGL"])
            >>> for symbol, quote in quotes.items():
            ...     print(f"{symbol}: ${quote.price}")
        """
        return self.aggregator.get_multiple_quotes(symbols, force_provider=provider)
    
    def get_historical(self,
                      symbol: str,
                      start: Optional[datetime] = None,
                      end: Optional[datetime] = None,
                      period: Optional[str] = None,
                      interval: str = "1d",
                      provider: Optional[str] = None) -> Optional[HistoricalData]:
        """
        Get historical OHLCV data
        
        Args:
            symbol: Ticker symbol
            start: Start date (optional if period is specified)
            end: End date (optional, defaults to now)
            period: Period string like "1mo", "3mo", "1y", "5y" (alternative to start/end)
            interval: Data interval - "1m", "5m", "15m", "30m", "1h", "1d", "1wk", "1mo"
            provider: Force specific provider (optional)
        
        Returns:
            HistoricalData object with pandas DataFrame
        
        Example:
            >>> # Get 1 year of daily data
            >>> data = client.get_historical("AAPL", period="1y", interval="1d")
            >>> print(data.data.head())
            
            >>> # Get specific date range
            >>> from datetime import datetime, timedelta
            >>> end = datetime.now()
            >>> start = end - timedelta(days=30)
            >>> data = client.get_historical("AAPL", start=start, end=end)
        """
        # Handle period shorthand
        if period and not start:
            end = end or datetime.now()
            period_map = {
                "1d": 1, "5d": 5,
                "1mo": 30, "3mo": 90, "6mo": 180,
                "1y": 365, "2y": 730, "5y": 1825, "10y": 3650
            }
            days = period_map.get(period, 365)
            start = end - timedelta(days=days)
        
        if not start:
            start = datetime.now() - timedelta(days=365)
        
        if not end:
            end = datetime.now()
        
        return self.aggregator.get_historical(
            symbol, start, end, interval, force_provider=provider
        )
    
    def get_provider_status(self) -> List[ProviderStatus]:
        """
        Get status of all data providers
        
        Returns:
            List of ProviderStatus objects
        
        Example:
            >>> statuses = client.get_provider_status()
            >>> for status in statuses:
            ...     print(f"{status.name}: {'✓' if status.available else '✗'}")
        """
        return self.aggregator.get_provider_status()
    
    def get_available_providers(self) -> List[str]:
        """
        Get list of available provider names
        
        Returns:
            List of provider names that are currently available
        """
        return self.aggregator.get_available_providers()
    
    def clear_cache(self):
        """Clear all cached data"""
        self.aggregator.clear_cache()
    
    # Convenience methods
    
    def get_current_price(self, symbol: str) -> Optional[float]:
        """
        Get just the current price (convenience method)
        
        Args:
            symbol: Ticker symbol
        
        Returns:
            Current price as float, or None if unavailable
        """
        quote = self.get_quote(symbol)
        return quote.price if quote else None
    
    def get_day_change(self, symbol: str) -> Optional[tuple]:
        """
        Get day change and change percent
        
        Args:
            symbol: Ticker symbol
        
        Returns:
            Tuple of (change, change_percent) or None
        """
        quote = self.get_quote(symbol)
        if quote:
            return (quote.change, quote.change_percent)
        return None
    
    # ========================================================================
    # Extended APIs - Calendar, Recommendations, Financials
    # ========================================================================
    
    def get_calendar(self, symbol: str, provider: Optional[str] = None) -> Dict:
        """
        Get upcoming events calendar (earnings, dividends).
        
        Args:
            symbol: Ticker symbol
            provider: Force specific provider (optional)
        
        Returns:
            Dictionary with upcoming events
        
        Example:
            >>> calendar = client.get_calendar("AAPL")
            >>> print(calendar.get('Earnings Date'))
        """
        return self.aggregator.get_calendar(symbol, force_provider=provider)
    
    def get_recommendations(self, symbol: str, provider: Optional[str] = None):
        """
        Get analyst recommendations history.
        
        Args:
            symbol: Ticker symbol
            provider: Force specific provider (optional)
        
        Returns:
            pd.DataFrame: Analyst recommendations
        
        Example:
            >>> recs = client.get_recommendations("AAPL")
            >>> print(recs.head())
        """
        return self.aggregator.get_recommendations(symbol, force_provider=provider)
    
    def get_financials(self,
                      symbol: str,
                      statement: str = 'income',
                      frequency: str = 'annual',
                      provider: Optional[str] = None):
        """
        Get financial statements.
        
        Args:
            symbol: Ticker symbol
            statement: Statement type - 'income', 'balance', 'cashflow'
            frequency: 'annual' or 'quarterly'
            provider: Force specific provider (optional)
        
        Returns:
            pd.DataFrame: Financial statement data
        
        Example:
            >>> financials = client.get_financials("AAPL", "income", "annual")
            >>> print(financials.loc['Total Revenue'])
        """
        return self.aggregator.get_financials(
            symbol,
            statement=statement,
            frequency=frequency,
            force_provider=provider
        )
