class NoJobRunError(Exception):
    """Raised if the job has no job runs (attempts) created yet"""
