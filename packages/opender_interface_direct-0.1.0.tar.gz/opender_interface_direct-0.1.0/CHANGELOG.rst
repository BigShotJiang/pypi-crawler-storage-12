
Changelog
=========
1.0.1 (2023-12-5)
------------------
NOT BACKWARD COMPATIBLE!!!
* Added a CombinedTimePlots class to combine multiple time charts
* Changed the method of accessing voltage regulator information


1.0.0 (2023-10)
------------------
* First release
