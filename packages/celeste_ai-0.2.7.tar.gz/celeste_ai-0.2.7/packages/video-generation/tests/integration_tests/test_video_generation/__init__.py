"""Integration tests for video generation."""
