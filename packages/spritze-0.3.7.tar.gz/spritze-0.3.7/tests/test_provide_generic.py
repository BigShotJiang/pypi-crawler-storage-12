from functools import partial
from typing import Annotated, Generic, TypeVar

import pytest

from spritze import Container, Depends, aresolve, init, inject, provider, resolve

T = TypeVar("T")


class A(Generic[T]):
    def __init__(self, value: T) -> None:
        self.value: T = value


class B(A[int]):
    pass


class C(A[str]):
    pass


def test_provide_generic():
    """Test providers with generic types."""

    def b_factory() -> A[int]:
        return B(100)

    class ContainerFixture(Container):
        b_provider: object = provider(b_factory, provide_as=A[int])

        c_str: object = provider(partial(C, "c"), provide_as=A[str])

    init(ContainerFixture)

    @inject
    def func_b(b: Annotated[A[int], Depends()]) -> None:
        assert b.value == 100

    func_b()

    b = resolve(A[int])
    assert b.value == 100

    @inject
    def func_c(c: Annotated[A[str], Depends()]) -> None:
        assert c.value == "c"

    func_c()

    c = resolve(A[str])
    assert c.value == "c"


@pytest.mark.asyncio
async def test_provide_generic_async():
    """Test async providers with generic types."""

    async def async_b_factory() -> A[int]:
        return B(200)

    async def async_c_factory() -> A[str]:
        return C("c")

    class ContainerFixture(Container):
        b_async: object = provider(async_b_factory, provide_as=A[int])
        c_str: object = provider(async_c_factory, provide_as=A[str])

    init(ContainerFixture)

    @inject
    async def func_b_async(b: Annotated[A[int], Depends()]) -> None:
        assert b.value == 200

    await func_b_async()

    b_async = await aresolve(A[int])
    assert b_async.value == 200

    @inject
    async def func_c_async(c: Annotated[A[str], Depends()]) -> None:
        assert c.value == "c"

    await func_c_async()

    c_async = await aresolve(A[str])
    assert c_async.value == "c"
