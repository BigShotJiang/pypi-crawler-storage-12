{
    "name": "Sale Blanket Order Template",
    "summary": """
        Setup sale blanket order template.
    """,
    "author": "Mint System GmbH",
    "website": "https://www.mint-system.ch/",
    "category": "Sale",
    "version": "16.0.1.0.0",
    "license": "AGPL-3",
    "depends": ["sale_blanket_order_notes", "sale_order_template_notes"],
    "data": ["views/sale_blanket_order.xml"],
    "installable": True,
    "application": False,
    "auto_install": False,
    "images": ["images/screen.png"],
}
