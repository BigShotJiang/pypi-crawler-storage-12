"""Stop pytest warning about module already imported: PYTEST_DONT_REWRITE"""

__version__ = "3.0.1"
