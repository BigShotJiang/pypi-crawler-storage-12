class FormattedString(str):
    """Wrapper class for things that have already been formatted"""
