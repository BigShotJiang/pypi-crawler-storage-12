### Describe the problem

Tell us about the problem you're having.

### Steps to reproduce

Tell us how to reproduce it.

### System configuration

* Django version:
* Python version:
* Django-Constance version:
