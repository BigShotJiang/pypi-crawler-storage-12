import django.dispatch

config_updated = django.dispatch.Signal()
