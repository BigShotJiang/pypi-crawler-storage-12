from django.contrib import admin

from cheeseshop.apps.catalog.models import Brand

admin.site.register(Brand)
