"""iron_gql: Typed GraphQL client generator for Python."""

from iron_gql.generator import generate_gql_package

__all__ = [
    "generate_gql_package",
]
