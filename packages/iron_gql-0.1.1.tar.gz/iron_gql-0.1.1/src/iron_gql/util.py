def capitalize_first(name: str) -> str:
    return name[0].upper() + name[1:]
