"""Benchmark of differential operators using JAX."""
