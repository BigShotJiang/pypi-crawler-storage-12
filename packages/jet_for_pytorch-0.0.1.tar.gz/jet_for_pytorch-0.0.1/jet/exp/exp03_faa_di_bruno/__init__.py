"""Produce the Faà di Bruno formulaFa in LaTeX."""
