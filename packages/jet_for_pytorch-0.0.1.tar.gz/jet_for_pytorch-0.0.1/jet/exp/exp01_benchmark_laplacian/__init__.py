"""Benchmarks different Laplacian implementations."""
