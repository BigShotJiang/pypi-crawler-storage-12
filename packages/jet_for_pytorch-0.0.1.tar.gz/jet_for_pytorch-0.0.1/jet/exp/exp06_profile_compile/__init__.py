"""Contains profiling scripts to measure the impact of JIT compilation."""
