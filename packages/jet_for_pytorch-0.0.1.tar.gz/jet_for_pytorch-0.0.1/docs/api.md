## Function transformations

### ::: jet.jet

### ::: jet.vmap.traceable_vmap

### ::: jet.simplify.simplify

## PDE Operators

#### ::: jet.laplacian.Laplacian

#### ::: jet.bilaplacian.Bilaplacian
