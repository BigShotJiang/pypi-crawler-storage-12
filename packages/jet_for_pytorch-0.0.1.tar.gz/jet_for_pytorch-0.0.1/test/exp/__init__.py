"""Contains tests for `jet.exp`."""
