# 04: Agent Execution Methods

This example extends *Example 03* to demonstrate executing agents in different processes using a `concurrent.futures.Executor` and an external message exchange.
