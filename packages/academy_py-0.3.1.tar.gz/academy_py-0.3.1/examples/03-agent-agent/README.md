# 03: Agent to Agent Interaction

Trivial text processing pipeline where one agent invokes actions on other agents.
