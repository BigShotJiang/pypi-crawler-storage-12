# 01: Actor Client

Simple example of launching a stateful actor and invoking actions from a user program.
