# 02: Agent Loops

Example of an agent with a control loop for autonomous behavior.
