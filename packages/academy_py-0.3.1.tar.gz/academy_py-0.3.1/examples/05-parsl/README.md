# 03: Parsl Agent

A Agent that delegates actions to a [Parsl]('https://parsl-project.org).

To run this example, install parsl:
```bash
pip install parsl
```
