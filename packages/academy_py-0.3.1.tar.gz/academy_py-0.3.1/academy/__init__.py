from __future__ import annotations

import importlib.metadata as importlib_metadata

__version__ = importlib_metadata.version('academy-py')
