from __future__ import annotations

import uuid

CLIENT_ID = str(uuid.uuid1())
