# Guides, Integrations, and Tutorials

!!! note

    More coming soon!

The best way to get started with Academy basics is the [Tutorial](tutorial.md)

## Guides

[HPC Integration Patterns](hpc.md)
