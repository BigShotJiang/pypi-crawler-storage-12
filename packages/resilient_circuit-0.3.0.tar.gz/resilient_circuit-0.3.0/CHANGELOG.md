# Changelog
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.2.0] - 2025-11-10
### Added
- Complete rewrite of documentation with new examples
- Integration with Highway Workflow Engine
- Enhanced API for better developer experience
- Comprehensive usage examples and best practices
