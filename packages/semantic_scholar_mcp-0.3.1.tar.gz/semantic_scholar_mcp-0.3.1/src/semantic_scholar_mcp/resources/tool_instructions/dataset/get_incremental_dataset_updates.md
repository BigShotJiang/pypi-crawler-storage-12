### Next Steps
- Examine update windows to schedule data refreshes.
- Ask for change summaries between the releases.
- Decide whether a full or incremental download is needed.
