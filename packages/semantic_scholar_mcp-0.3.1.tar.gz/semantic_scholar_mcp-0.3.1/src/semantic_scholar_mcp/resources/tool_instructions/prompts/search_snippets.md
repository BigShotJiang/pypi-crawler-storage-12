### Next Steps
- Read snippet contexts to judge relevance quickly.
- Ask for full paper details on the most compelling snippets.
- Consider refining keywords if noise remains high.
