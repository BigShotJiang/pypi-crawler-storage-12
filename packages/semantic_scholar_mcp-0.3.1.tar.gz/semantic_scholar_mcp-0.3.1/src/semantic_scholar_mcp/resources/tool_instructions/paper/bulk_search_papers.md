### Next Steps
- Inspect aggregated hits and decide which query succeeded.
- Ask for focused summaries of the best-performing results.
- Iterate on the weaker queries with refined keywords.
