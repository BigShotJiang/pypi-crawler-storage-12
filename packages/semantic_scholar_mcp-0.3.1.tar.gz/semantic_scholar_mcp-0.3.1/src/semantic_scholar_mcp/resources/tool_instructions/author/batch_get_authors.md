### Next Steps
- Confirm that each requested author profile is included.
- Ask for a comparative overview across these researchers.
- Plan next queries such as `get_author_papers` per person.
