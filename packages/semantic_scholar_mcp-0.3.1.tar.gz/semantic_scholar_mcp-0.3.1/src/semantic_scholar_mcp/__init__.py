"""Semantic Scholar MCP server package."""

__version__ = "0.3.1"

from .server import main

__all__ = ["__version__", "main"]
