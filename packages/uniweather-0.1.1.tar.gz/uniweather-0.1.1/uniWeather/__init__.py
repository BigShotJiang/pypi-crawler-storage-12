"""
uniWeather Python Client

A Python client for the uniWeather Cloud API providing access to IoT sensor data.

Example (Async):
    from uniWeather import uniWeatherCloud
    
    async def main():
        client = uniWeatherCloud(base_url="https://api.uniweather.io")
        await client.connect(token="your-api-key")
        
        devices = await client.my_devices()
        for device in devices:
            channels = await client.get_channels(device)
            print(f"{device.device_id}: {channels}")
        
        data = await client.data(
            devices[0],
            channels="all",
            from_date="2025-05-05",
            to_date="2025-05-07"
        )
        
        df = data.to_dataframe()
        print(df)
        
        await client.close()

Example (Sync):
    from uniWeather import uniWeatherCloudSync
    
    with uniWeatherCloudSync() as client:
        client.connect(token="your-api-key")
        
        devices = client.my_devices()
        data = client.data(devices[0], channels="all")
        
        df = data.to_dataframe()
        print(df)
"""

__version__ = "0.1.1"

from .client import uniWeatherCloud, uniWeatherCloudSync
from .models import (
    Device,
    DeviceInfo,
    Channel,
    TimeSeriesEntry,
    DataQueryResponse
)
from .exceptions import (
    UniWeatherError,
    AuthenticationError,
    NotFoundError,
    APIError,
    ConnectionError
)

__all__ = [
    'uniWeatherCloud',
    'uniWeatherCloudSync',
    'Device',
    'DeviceInfo',
    'Channel',
    'TimeSeriesEntry',
    'DataQueryResponse',
    'UniWeatherError',
    'AuthenticationError',
    'NotFoundError',
    'APIError',
    'ConnectionError',
]
