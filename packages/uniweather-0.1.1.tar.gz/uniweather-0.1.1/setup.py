import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="uniweather",
    version="0.1.1",
    author="ResearchConcepts io GmbH",
    author_email="support@uniweather.io",
    description="Python client for the uniWeather Cloud API - Access IoT sensor data",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your_username/uniWeather",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering",
    ],
    python_requires=">=3.8",
    install_requires=[
        "httpx>=0.24.0",
        "certifi>=2023.0.0",
    ],
    extras_require={
        "pandas": ["pandas>=1.0.0"],
        "dev": ["pytest>=7.0", "pytest-asyncio>=0.21.0"],
    },
) 