"""Tests for pdf2md-ocr."""
