# Agents samples

This directory intentionally contains only one sample.

The full set of Agent samples can be found in the [samples folder](https://github.com/Azure/azure-sdk-for-python/tree/main/sdk/ai/azure-ai-agents/samples) of the `azure-ai-agents` package.

See also `azure-ai-agents` package [README.md](https://github.com/Azure/azure-sdk-for-python/tree/main/sdk/ai/azure-ai-agents).

