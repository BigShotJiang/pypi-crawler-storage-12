# Testing overview & how-to

Tests included herein consist of component tests whose mocks are obtained using [vcrpy](https://pypi.org/project/vcrpy/).

The infrastructure and test workspace setup is the same as in the gooddata-sdk package. Please check out [gooddata-sdk testing overview](../../gooddata-sdk/tests/overview.md)
to learn more the essentials.
