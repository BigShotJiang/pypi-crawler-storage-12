from __future__ import annotations


class DuplicateValueError(ValueError):
    pass


class MaxRetriesError(RuntimeError):
    pass
