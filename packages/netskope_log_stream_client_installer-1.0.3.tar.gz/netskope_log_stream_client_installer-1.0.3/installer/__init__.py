"""Netskope Log Stream Client Installer Package."""

__version__ = "1.0.3"
__author__ = "Netskope"
__email__ = "support@netskope.com"
