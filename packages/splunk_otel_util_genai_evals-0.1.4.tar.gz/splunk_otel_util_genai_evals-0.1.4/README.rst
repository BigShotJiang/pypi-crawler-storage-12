OpenTelemetry Util GenAI Evaluations
====================================

This package provides the base evaluation manager and builtin evaluators for
``opentelemetry-util-genai``. It is loaded dynamically by the core GenAI
telemetry utilities via the completion callback plugin mechanism.
