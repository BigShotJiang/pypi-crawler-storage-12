"""Rendering module initialization."""
