function out = module_function(a, b)
% Docstring for module_function.

arguments
  a (1,:) double % First parameter
  b char = 'test' 
    % Second parameter
end

end
