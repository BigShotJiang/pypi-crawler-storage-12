function hidden_function()
end
