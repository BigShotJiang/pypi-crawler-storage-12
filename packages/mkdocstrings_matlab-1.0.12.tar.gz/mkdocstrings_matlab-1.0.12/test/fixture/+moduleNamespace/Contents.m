%{
This is the namespace documentation.
%}
