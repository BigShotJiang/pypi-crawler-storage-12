"""Tests suite for `mkdocstrings_handlers`."""
