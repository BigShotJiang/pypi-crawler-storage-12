function print_hello()
    % Print hello.
    %
    % Examples:
    %     >>> print("hello")
    %     % hello
    fprintf("hello\n")
end
