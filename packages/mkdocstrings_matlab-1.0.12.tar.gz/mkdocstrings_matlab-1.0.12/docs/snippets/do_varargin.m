function do_varargin(varargin)
% Do something.
%
% Name-Value pairs:
%     whatever: Some value.
end
