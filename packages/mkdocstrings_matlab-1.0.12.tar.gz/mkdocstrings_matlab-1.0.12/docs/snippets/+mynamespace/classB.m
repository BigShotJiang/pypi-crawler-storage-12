classdef classB
    % Docstring of class B.
    properties
        prop_b   % Docstring of the property.
    end
    methods
        function obj = method_b(inputArg1)
            % Docstring of the method.
        end
    end
end
