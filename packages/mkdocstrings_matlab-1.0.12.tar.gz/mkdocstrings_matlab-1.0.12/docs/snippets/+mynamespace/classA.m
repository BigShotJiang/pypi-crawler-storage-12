classdef classA
    % Docstring of class A.

    methods
        function obj = method_a(inputArg1)
            % Docstring of the method.
        end
    end
end
