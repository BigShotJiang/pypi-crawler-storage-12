classdef ClassWithoutDocstring
    methods
        function obj = method_without_docstring(obj)
        end

        function obj = method_with_docstring(obj)
            % Hello
        end
    end
end
