classdef (Abstract) BaseClass
% Base class docstring.
    methods
        function obj = from_base(obj, input)
            % Base method docstring
        end
    end
end
