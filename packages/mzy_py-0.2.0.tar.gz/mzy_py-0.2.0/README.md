# My Open Source Package
一个简单的开源Python工具包。

## 安装
```bash
pip install mzy-py