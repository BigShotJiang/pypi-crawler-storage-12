def print_info():
    """打印包信息"""
    print("这是我的第一个开源pip包！")


def plus_mzy(a, b):
    """两个数相加"""
    return a + b

def minus_mzy(a, b):
    """两个数相减"""
    return a - b

def print_my_name_mzy() -> str:
    """Return personal intro."""
    print("My name is Mzy, I am a student in BPU.")

def liujinglun() -> str:
    """Return liujinglun's intro."""
    print("He is a bitch enjoy suck everybody's dick. ")

def FuJunYi() -> str:
    """Return mzy's name."""
    print("FuJunYi is a good boy.")


def LiuziHao() -> str:
    """Return mzy's name."""
    print("LiuziHao is one of my best friend.")