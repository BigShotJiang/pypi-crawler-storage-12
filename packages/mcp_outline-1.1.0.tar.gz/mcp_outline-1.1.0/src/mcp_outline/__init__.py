# MCP Outline package
"""
MCP server for document outlines
"""
