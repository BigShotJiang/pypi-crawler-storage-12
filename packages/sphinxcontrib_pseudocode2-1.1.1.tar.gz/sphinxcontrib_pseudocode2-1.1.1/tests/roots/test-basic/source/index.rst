Coverage test page
==================

.. pcode::
   :linenos:
   :comment-delimiter: //

   \PRINT 'hello coverage'

.. pcode::
   :no-end:
   :caption-count: 5
   :title-prefix: "TestTitle"

   \PRINT 'another block'
