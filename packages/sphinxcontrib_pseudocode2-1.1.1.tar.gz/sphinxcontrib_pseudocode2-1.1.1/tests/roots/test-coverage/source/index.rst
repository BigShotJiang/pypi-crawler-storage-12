Coverage test page
==================

.. pcode::
   :linenos:
   :no-scopelines:
   :comment-delimiter: //

   \PRINT 'hello coverage'

.. pcode::
   :no-end:
   :scopelines:
   :no-linenos:
   :caption-count: 5
   :title-prefix: "TestTitle"

   \PRINT 'another block'

.. pcode::
   :no-linenos:
   :caption-count: 100
   :title-prefix: "XXX"

   \PRINT 'the third block'
