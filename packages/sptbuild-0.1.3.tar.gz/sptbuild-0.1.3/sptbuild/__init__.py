"""SPT Build Tool - Build and release tool for SPT client plugins."""

__version__ = "0.1.3"
