#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 14 14:02:49 2022

@author: dpicard
"""

import pyqtgraph.examples
pyqtgraph.examples.run()