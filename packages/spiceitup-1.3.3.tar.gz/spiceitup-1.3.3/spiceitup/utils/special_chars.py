#!/usr/bin/env python3
# -*- coding: utf-8 -*-

for i in range(3000):
    print(i, chr(i)) # lambda is 955