"""This module contains all uncertainty explanation benchmark games."""

from .benchmark import AdultCensus

__all__ = ["AdultCensus"]
