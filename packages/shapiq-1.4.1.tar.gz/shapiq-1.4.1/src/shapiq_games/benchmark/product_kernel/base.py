"""This module contains the base ProductKernelSHAPIQ xai game."""
