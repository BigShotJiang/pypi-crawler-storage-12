"""This module contains the ProductKernelSHAPIQ explanation benchmark games."""
