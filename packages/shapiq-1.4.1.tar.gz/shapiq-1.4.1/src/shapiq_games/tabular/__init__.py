"""Cooperative games for tabular data."""
