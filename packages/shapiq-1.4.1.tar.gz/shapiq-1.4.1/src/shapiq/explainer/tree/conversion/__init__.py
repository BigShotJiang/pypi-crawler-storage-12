"""Conversion functions to parse tree-based machine learning models into shapiq explainer format."""
