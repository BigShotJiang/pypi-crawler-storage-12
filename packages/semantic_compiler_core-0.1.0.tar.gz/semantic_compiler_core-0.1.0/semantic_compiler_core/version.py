"""Version information for semantic-compiler-core."""

__version__ = "0.1.0"

