"""
Semantic Compiler: Natural Language → SIR → RLang → IR + Proof
"""

__version__ = "0.0.1"

import logging

logger = logging.getLogger("semantic_compiler")

if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("[%(levelname)s] %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

# Import SemanticCompiler only if available (may not be in core package)
try:
    from .semantic_agent import SemanticCompiler
    __all__ = ['SemanticCompiler', 'logger']
except ImportError:
    # LLM-related modules not available (e.g., in semantic-compiler-core package)
    __all__ = ['logger']

