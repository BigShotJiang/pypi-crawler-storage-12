def test_hello() -> None:
    msg = "Hello, ToyMM!"
    assert msg == "Hello, ToyMM!"
