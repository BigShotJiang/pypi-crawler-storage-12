# -*- coding: utf-8 -*-


from typing import Tuple


class CollisionBoxComponentClient(object):
    def GetSize(self):
        # type: () -> Tuple[float, float]
        """
        获取实体的包围盒
        """
        pass

