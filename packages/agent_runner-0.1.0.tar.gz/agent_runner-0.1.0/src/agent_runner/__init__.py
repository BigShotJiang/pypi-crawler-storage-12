"""
agent-runner: open-sourcing soon...
"""

__version__ = "0.1.0"
__author__ = "Kamryn Ohly"
__email__ = "kamryn@arcada.dev"
