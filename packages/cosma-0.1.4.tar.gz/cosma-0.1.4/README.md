# cosma

Core packages for cosma.

## Running

To start the backend:

```py
uvx cosma serve
```

To start the TUI:
```py
uvx cosma
```
