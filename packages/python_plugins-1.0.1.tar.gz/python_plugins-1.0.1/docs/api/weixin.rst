==========
weixin
==========

.. autoclass:: python_plugins.weixin.wechat.Wechat
   :members:


