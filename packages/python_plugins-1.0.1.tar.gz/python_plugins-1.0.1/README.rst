python-plugins
=====================

python-plugins is a collection of Python plugins, functions and classes.

License
-------

python-plugins is distributed under the terms of the `MIT <https://opensource.org/licenses/MIT>`_.


Installation
------------

Install and update using pip:

.. code-block:: console

    $ pip install -U python-plugins

