from .hash import hash_file, hash_text
