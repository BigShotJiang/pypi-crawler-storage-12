v1.0.1
------

Released 2025-11-15

- tkinter_calculator

v1.0.0
------

Released 2025-11-07

- ospath.walk.remove
- crypto
- email
- weixin.wechat
- sqlalchemy mixins

v0.1.0
------

Released 2024-08-27

- Init release
- set sphinx_rtd_theme as html_theme of docs
