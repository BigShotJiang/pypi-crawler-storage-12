def test_import_PM_JPL():
    import PMJPL
