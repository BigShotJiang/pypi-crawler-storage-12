"""
FastAPI Auth Starter Application
Main application package
"""

