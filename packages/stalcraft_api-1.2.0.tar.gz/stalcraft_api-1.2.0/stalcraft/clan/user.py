from pathlib import Path
from typing import Any

from stalcraft import schemas
from stalcraft.clan import Clan


class UserClan(Clan):
    def members(self) -> Any | list[schemas.ClanMember]:
        """
        Returns list of members in the given clan.

        ! Can be used ONLY when using user access token and that user has at least one character in that clan.
        """

        response = self._api.request_get(
            Path(self.region, "clan", self.clan_id, "members")
        )

        return response if self.json else [schemas.ClanMember.model_validate(member) for member in response]
