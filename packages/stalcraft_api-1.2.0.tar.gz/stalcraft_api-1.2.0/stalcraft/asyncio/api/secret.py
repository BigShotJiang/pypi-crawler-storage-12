from stalcraft.api import SecretApi
from stalcraft.asyncio.api.base import AsyncBaseApi


class AsyncSecretApi(AsyncBaseApi, SecretApi):
    pass
