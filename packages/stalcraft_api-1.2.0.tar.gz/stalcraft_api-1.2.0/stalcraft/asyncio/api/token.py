from stalcraft.api import TokenApi
from stalcraft.asyncio.api.base import AsyncBaseApi


class AsyncTokenApi(AsyncBaseApi, TokenApi):
    pass
