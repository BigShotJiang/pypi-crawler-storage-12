from pathlib import Path
from typing import Any, List, Optional

from stalcraft import Region
from stalcraft import exceptions as exc
from stalcraft import schemas
from stalcraft.api import TokenApi
from stalcraft.clan import UserClan
from stalcraft.client.base import BaseClient
from stalcraft.defaults import Default


class UserClient(BaseClient):
    def __init__(
        self,
        token: Optional[str] = None,
        base_url: str = Default.BASE_URL,
        json: bool = Default.JSON
    ):
        """
        User Client for working with the API.

        Args:
            token: User access token.
            base_url (optional): API base url. Defaults to PRODUCTION.
            json (optional): Raw response format. Defaults to False.
        """

        self._token = token

        super().__init__(base_url, json)

    def _get_api(self):
        if self._token:
            return TokenApi(self._token, self._base_url)

        raise exc.MissingCredentials("No token provided.")

    def clan(
        self,
        clan_id: str,
        region: Region = Default.REGION
    ) -> UserClan:
        """
        Factory method for working with clans.

        Args:
            clan_id: Clan ID. For example "647d6c53-b3d7-4d30-8d08-de874eb1d845".
            region: Stalcraft server region.
        """

        return UserClan(self._api, clan_id, region, self.json)

    def characters(
        self,
        region: Region = Default.REGION
    ) -> Any | List[schemas.Character]:
        """
        Returns list of characters created by the user by which used access token was provided.

        Args:
            region: Stalcraft server region.
        """

        response = self._api.request_get(
            Path(region, "characters")
        )

        return response if self.json else [schemas.Character.model_validate(character) for character in response]

    def friends(
        self,
        character: str,
        region: Region = Default.REGION
    ) -> Any | List[str]:
        """
        Returns list of character names who are friend with specified character.

        Args:
            character: Character name.
            region: Stalcraft server region.
        """

        response = self._api.request_get(
            Path(region, "friends", character)
        )

        return response
