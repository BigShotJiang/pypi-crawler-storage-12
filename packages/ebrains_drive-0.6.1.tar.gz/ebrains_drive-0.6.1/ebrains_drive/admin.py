class SeafileAdmin(object):
    def lists_users(self, maxcount=100):
        pass

    def list_user_repos(self, username):
        pass
