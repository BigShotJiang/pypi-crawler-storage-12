from .invoke import Invoke

class Advanced(
    Invoke
):
    pass