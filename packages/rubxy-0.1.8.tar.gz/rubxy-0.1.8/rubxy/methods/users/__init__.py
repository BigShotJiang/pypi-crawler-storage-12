from .get_me import getMe

class Users(
    getMe
):
    pass