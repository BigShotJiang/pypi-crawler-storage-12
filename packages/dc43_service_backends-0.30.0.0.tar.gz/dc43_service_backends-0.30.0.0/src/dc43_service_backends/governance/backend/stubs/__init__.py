"""Filesystem-backed sample implementations of the DQ governance interface."""

from .filesystem import StubDQClient

__all__ = ["StubDQClient"]
