Bibliography
============

.. raw:: latex

    \begingroup
    \def\section#1#2{}
    \def\chapter#1#2{}
    \begin{thebibliography}{1234}

.. bibliography::

.. raw:: latex

    \end{thebibliography}
    \endgroup