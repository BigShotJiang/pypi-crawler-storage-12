"""
Test suite for uraster package
"""