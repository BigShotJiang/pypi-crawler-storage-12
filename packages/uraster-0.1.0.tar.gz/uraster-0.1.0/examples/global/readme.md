These examples demonstate case studies that cover the whole globe.

In general, only the vector mesh may include mesh cells that cross the international date line.

If the vector mesh file crosses the date line, the filename includes the suffix `_dateline` before the file extension, e.g., `global_mesh_dateline.geojson`.


