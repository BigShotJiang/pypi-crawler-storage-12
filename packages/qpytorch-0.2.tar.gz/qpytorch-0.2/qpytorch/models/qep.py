#!/usr/bin/env python3

from ..module import Module


class QEP(Module):
    pass
