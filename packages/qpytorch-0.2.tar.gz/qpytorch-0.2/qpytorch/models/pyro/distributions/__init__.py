#!/usr/bin/env python3

from ....distributions.qexponential import QExponential

__all__ = ["QExponential"]
