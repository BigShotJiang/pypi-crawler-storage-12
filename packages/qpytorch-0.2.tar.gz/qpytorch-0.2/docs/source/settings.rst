.. role:: hidden
    :class: hidden-section

qpytorch.settings
===================================

QPyTorch settings are ported from GPyTorch.

.. currentmodule:: qpytorch.settings

.. automodule:: qpytorch.settings
   :members:
