.. role:: hidden
    :class: hidden-section

qpytorch.Module
===================================

QPyTorch Module is ported from GPyTorch.

.. currentmodule:: qpytorch.Module


.. autoclass:: qpytorch.Module
   :members:
