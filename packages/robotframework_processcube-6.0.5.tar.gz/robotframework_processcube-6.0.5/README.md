# Robot Framework für Anbindung der ProcessCube®-Engine

Der [ProcessCube®](https://www.5minds.de/processcube/) ist ein BPMN-Engine
der mittels [Python](http://processcube.io/docs/engine/clients/python/) 
angebunden werden kann. Die Beispiel sind unter [Developer-Seite](http://processcube.io/) 
zu finden.

Die entsprechenden Keywords für das Robot Framework und deren Beschreibung befinden sich
hier [Verwendung des Robot Framework mit der 5Minds-Engine](https://processcube.io/docs/solutions/robotframework_processcube).
