from .field import field

mutation = field

__all__ = ["mutation"]
