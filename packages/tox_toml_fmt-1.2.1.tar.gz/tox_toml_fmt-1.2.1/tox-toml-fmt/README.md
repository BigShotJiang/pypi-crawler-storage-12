# tox-toml-fmt

[![PyPI](https://img.shields.io/pypi/v/tox-toml-fmt?style=flat-square)](https://pypi.org/project/tox-toml-fmt)
[![PyPI - Implementation](https://img.shields.io/pypi/implementation/tox-toml-fmt?style=flat-square)](https://pypi.org/project/tox-toml-fmt)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/tox-toml-fmt?style=flat-square)](https://pypi.org/project/tox-toml-fmt)
[![Downloads](https://static.pepy.tech/badge/tox-toml-fmt/month)](https://pepy.tech/project/tox-toml-fmt)
[![PyPI - License](https://img.shields.io/pypi/l/tox-toml-fmt?style=flat-square)](https://opensource.org/licenses/MIT)
[![Build tox-toml-fmt](https://github.com/tox-dev/toml-fmt/actions/workflows/tox_toml_fmt_build.yaml/badge.svg)](https://github.com/tox-dev/toml-fmt/actions/workflows/tox_toml_fmt_build.yaml)
[![Test tox-toml-fmt](https://github.com/tox-dev/toml-fmt/actions/workflows/tox_toml_fmt_test.yaml/badge.svg)](https://github.com/tox-dev/toml-fmt/actions/workflows/tox_toml_fmt_test.yaml)
[![Documentation
status](https://readthedocs.org/projects/pyproject-fmt/badge/?version=latest)](https://pyproject-fmt.readthedocs.io/en/latest/)
