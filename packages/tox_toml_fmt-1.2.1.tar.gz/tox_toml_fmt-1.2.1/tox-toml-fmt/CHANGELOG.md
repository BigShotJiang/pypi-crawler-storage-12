<a id="1.2.1"></a>

## 1.2.1 - 2025-11-12

- perf: only compile regexes once by [@henryiii](https://github.com/henryiii) in
  [#$110](https://github.com/tox-dev/toml-fmt/pull/110)

<a id="1.2.0"></a>

## 1.2.0 - 2025-10-08

- Drop 3.9 and add 3.14 by [@gaborbernat](https://github.com/gaborbernat) in
  [#$96](https://github.com/tox-dev/toml-fmt/pull/96)

<a id="1.1.0"></a>

## 1.1.0 - 2025-10-01

- Release pyproject-fmt 2.7.0 by [@gaborbernat](https://github.com/gaborbernat)

<a id="1.0.0"></a>

## 1.0.0 - 2024-10-31

- Update Cargo.toml by [@gaborbernat](https://github.com/gaborbernat)
