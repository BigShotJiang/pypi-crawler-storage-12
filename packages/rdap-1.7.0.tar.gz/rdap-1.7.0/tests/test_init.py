import rdap


def test_init():
    rdap.RdapClient()
