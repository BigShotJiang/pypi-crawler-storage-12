default_gitlab_url = 'https://git.ligo.org'
default_gitlab_project = 'yumeng.xu/uib-o4a-catalog'