from enum import Enum
 
class MultiMotorStatusType(Enum):
    OK = 1
    ERROR = 2
