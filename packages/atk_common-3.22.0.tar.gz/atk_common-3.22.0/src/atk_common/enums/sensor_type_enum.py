from enum import Enum
 
class SensorType(Enum):
    PIEZO = 1
    LOOP = 2
