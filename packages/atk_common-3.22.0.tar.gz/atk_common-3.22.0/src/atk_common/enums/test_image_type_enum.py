from enum import Enum
 
class TestImageType(Enum):
    CAPTURE_IMAGE = 1
    GETLAST_IMAGE = 2
    GETNEXT_IMAGE = 3
    EXAMPLE = 4
