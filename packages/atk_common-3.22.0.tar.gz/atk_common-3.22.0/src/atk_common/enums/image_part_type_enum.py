from enum import Enum
 
class ImagePartType(Enum):
    LICENSE_PLATE = 1
    DRIVER = 2
    PHOTO_ZONE = 3
