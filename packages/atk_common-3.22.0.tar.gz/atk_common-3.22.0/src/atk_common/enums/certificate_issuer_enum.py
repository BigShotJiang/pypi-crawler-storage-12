from enum import Enum
 
class CertificateIssuer(Enum):
    JUSTERVESENET = 1
    PERSPIC = 2
