from sys import argv

from . import run

run(argv)
