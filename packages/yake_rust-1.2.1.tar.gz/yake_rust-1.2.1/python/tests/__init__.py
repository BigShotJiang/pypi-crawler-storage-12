"""Tests for the yake-rust python bindings package."""
