"""Python interface to yake-rust."""

from ._lib import Yake

__all__ = ("Yake",)
