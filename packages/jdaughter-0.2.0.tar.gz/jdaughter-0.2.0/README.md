# jdaughter

A JSON with Comments parsing/dumping library written in Python

## Usage

Read the source