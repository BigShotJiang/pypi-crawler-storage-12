# Copyright (C) Carbonlab - All Rights Reserved

* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary
* Written by Lou ! <lou@carbonlab.dev>
