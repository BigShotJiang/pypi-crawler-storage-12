# from ..client import get_client
# import pandas as pd


# def get_avaliable_products(date_time=None):
#     result = get_client().execute('api_test',
#                                   date_time=date_time,
#                                   instrument_type='futures')
#     return result


# def get_avaliable_products_2(date_time=None):
#     result = get_client().api_test(date_time=date_time,
#                                    instrument_type='futures')
#     return result
