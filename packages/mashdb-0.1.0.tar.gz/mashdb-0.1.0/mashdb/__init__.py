"""
MashDB - A simple Python interface for MashDB database.
"""

from .core import query

__all__ = ['query']
