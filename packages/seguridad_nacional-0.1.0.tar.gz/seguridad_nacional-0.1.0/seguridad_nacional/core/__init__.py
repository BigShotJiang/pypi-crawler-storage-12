"""Módulo core de la librería"""

