"""Dashboard de seguridad"""

