"""Módulo de configuración"""

