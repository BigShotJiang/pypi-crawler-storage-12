"""Detectores de vulnerabilidades"""

