.. djangocms-blog documentation master file, created by
   sphinx-quickstart on Sun Jun  5 23:27:04 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

##########################################
Welcome to djangocms-blog's documentation!
##########################################

.. include:: ../README.rst


********
Contents
********

.. toctree::
   :maxdepth: 3

   installation
   features/index
   autodoc/settings
   autodoc/index
   development
   contributing
   history


******************
Indices and tables
******************

* :ref:`genindex`
* :ref:`search`
