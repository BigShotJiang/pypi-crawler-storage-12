####################
djangocms_blog.admin
####################

Admin classes
#############

.. automodule:: djangocms_blog.admin
    :members:
    :private-members:

Admin forms
#############


.. autoclass:: djangocms_blog.forms.CategoryAdminForm
    :members:
    :private-members:

.. autoclass:: djangocms_blog.forms.PostAdminForm
    :members:
    :private-members:
