##########################################
Welcome to djangocms-stories documentation!
##########################################

.. include:: ../../README.rst

********
Contents
********

.. toctree::
   :maxdepth: 2

   tutorial/index

.. toctree::
   :maxdepth: 2

   how-tos/index

.. toctree::
   :maxdepth: 2

   explanations/index

.. toctree::
   :maxdepth: 2

   reference/index

******************
Indices and tables
******************

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
