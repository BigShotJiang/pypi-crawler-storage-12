########
Tutorial
########

This tutorial will guide you through setting up and using djangocms-stories from scratch.

.. toctree::
   :maxdepth: 2

   installation
   first-story
   customization
