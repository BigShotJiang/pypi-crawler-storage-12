from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [
        ("djangocms_blog", "0022_auto_20170304_1040"),
        ("djangocms_blog", "0033_auto_20180226_1410"),
    ]

    operations = []
