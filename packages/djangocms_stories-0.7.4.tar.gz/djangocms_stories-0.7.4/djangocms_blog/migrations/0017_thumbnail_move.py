from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [
        ("filer", "0003_thumbnailoption"),
        ("djangocms_blog", "0016_auto_20160502_1741"),
    ]

    operations = []
