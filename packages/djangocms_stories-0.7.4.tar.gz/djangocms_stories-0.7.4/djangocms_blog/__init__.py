__author__ = "Iacopo Spalletti"
__email__ = "i.spalletti@nephila.it"
__version__ = "5.0.0dev"
