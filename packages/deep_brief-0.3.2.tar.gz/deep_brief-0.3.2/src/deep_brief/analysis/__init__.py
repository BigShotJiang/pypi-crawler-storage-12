"""Speech and visual analysis components."""
