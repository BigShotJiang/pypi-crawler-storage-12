"""Model backbones for PSANN-LM (to be implemented).

Will contain transformer stacks adapted to ResPSANN/WaveResNet bases.
"""

