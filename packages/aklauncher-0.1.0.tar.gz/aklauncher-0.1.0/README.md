# aklauncher

A tiny Windows-only Python package to launch multiple Python scripts each in its own CMD window.

## Install (local test)

From the project root (the folder containing `setup.py`):

```bash
pip install .
# or for editable development
pip install -e .
