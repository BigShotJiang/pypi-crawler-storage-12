# aklauncher/__init__.py
from .core import launch

__all__ = ["launch"]
