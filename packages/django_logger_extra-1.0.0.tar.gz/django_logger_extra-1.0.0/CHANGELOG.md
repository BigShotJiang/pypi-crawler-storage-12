<!-- DOCTOC SKIP -->
# Changelog

## [1.0.0](https://github.com/City-of-Helsinki/django-logger-extra/compare/v0.1.0...v1.0.0) (2025-11-13)


### Dependencies

* Update python and django version support ([c1eccc4](https://github.com/City-of-Helsinki/django-logger-extra/commit/c1eccc4bf013839c9084da0706ba34a1c208de90))
