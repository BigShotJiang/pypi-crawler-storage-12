"""Tests for QuestFoundry loops."""
