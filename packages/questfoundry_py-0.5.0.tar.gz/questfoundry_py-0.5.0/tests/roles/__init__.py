"""Tests for QuestFoundry roles."""
