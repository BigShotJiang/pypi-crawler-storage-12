# Art Director Examples

- `scene_to_shotlist.json` - Converting Scene Smith output to shotlist
- `art_manifest_workflow.json` - Creating and updating art_manifest with render workflow
