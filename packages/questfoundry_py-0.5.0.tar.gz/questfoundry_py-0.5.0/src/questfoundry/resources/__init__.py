"""
Bundled resources package.

This package contains bundled prompts and schemas used by QuestFoundry roles
and validators. Resources are loaded dynamically to avoid hardcoding paths.
"""
