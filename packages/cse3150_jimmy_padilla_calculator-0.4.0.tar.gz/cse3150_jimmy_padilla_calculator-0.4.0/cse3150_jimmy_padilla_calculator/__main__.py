from .calculator import Calculator


def main():
    print("Im in main!")
    print(Calculator().add(3, 3))


if __name__ == "__main__":
    main()
