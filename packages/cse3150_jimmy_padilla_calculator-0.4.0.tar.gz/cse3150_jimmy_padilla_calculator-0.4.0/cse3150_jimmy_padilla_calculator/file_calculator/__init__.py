from .file_calculator import FileCalculator  # omit .py

__all__ = ["FileCalculator"]
