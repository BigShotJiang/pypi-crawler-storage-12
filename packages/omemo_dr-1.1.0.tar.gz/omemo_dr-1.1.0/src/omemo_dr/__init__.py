import logging

__version__ = "1.1.0"

logging.getLogger("omemo_dr").addHandler(logging.NullHandler())
