#ifndef CURVE25519_DONNA_H
#define CURVE25519_DONNA_H

extern int curve25519_donna(uint8_t *, const uint8_t *, const uint8_t *);

#endif
