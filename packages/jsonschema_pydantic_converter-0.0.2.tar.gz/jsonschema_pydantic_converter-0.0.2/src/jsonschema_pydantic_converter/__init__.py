"""Json schema to pydantic."""

from jsonschema_pydantic_converter.transform import transform

__all__ = [
    "transform",
]
