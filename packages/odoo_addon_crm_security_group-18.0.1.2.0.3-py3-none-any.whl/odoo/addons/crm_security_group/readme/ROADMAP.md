- Remove sale_crm dependency (now is not possible), maybe split this
  part in other addon
