# Templates directory for guru-pk-mcp
