from .html_blocks import SearchableHTMLBlock  # noqa

"""
This is provided for backward compatibility only.
Please use instead cjkcms.blocks.SearchableHTMLBlock
"""
