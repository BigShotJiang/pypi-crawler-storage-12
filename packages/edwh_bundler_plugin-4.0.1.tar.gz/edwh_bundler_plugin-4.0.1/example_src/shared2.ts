export function shared2() {
    console.log('-- shared 2 --')
}

console.log('shared 2 top-level')
