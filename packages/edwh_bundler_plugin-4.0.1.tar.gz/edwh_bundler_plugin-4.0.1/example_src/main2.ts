import {shared} from "./shared";
import {shared2} from "./shared2";

console.log("--- ts file 2 ---" as string)
shared()
shared2()
