class Error(Exception):
    pass


class CorruptDataError(Error):
    pass
