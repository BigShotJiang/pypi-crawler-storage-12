"""
Fastlife HTTP middlewares are Starlette HTTP Middleware.

HTTP middleware is a function that processes requests before they reach
the view function or modifies responses after the view has processed
the request.
"""
