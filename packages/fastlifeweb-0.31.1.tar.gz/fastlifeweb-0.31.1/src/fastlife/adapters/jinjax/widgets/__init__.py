"""HTML Form generation using widgets."""
