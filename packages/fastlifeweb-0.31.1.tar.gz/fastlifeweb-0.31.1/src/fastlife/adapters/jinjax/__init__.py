"""Main template renderer based on JinjaX."""

from .renderer import JinjaxEngine

__all__ = [
    "JinjaxEngine",
]
