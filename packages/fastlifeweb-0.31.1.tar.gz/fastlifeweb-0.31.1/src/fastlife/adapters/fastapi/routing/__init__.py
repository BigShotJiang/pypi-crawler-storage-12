"""
HTTP Routing.

The http routing is the process that choose the proper view functions based
on the http request received. Usually it is based on the request path_info
and the http method.
"""
