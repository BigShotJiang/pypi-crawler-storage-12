"""Workflows defined in fabricatio-yue."""
