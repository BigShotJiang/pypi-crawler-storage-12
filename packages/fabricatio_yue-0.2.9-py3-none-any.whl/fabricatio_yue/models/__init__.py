"""Models defined in fabricatio-yue."""
