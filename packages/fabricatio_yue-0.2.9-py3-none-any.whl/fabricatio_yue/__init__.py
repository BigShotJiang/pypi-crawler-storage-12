"""An extension of fabricatio, provide capability to compose lyrics that can be used in music generation with YuE.."""
