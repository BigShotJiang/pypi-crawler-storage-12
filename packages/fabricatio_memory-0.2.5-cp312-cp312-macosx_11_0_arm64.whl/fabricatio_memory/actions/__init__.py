"""Actions defined in fabricatio-memory."""
