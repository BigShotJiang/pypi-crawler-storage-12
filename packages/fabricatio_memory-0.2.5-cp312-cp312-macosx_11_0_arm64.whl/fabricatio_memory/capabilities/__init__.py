"""Capabilities defined in fabricatio-memory."""
