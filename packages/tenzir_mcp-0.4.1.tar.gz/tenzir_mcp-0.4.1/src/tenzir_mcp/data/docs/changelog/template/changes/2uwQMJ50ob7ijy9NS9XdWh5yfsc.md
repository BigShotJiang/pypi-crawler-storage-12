---
title: Improved changelog
type: change
authors: [mavam, dominiklohmann]
pr: 5069
---

As part of moving our docs site, we are also improving our changelog handling.
The new `tenzir/docs` repo will receive changelog entries from all of our other
repos and host an amalgamated changelog.
