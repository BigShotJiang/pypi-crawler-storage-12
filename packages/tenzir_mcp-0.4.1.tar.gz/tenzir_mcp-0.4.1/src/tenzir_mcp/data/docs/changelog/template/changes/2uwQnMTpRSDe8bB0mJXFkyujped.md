---
title: Fix broken changelog generation
type: bugfix
authors: mavam
pr: 5074
---

We had a bug in our changelog generation that nobody knew about. We fixed it and
moved on.
