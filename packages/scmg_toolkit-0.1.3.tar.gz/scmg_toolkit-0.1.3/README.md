# scmg_toolkit

A minimal example Python package with a simple models module.

## Installation

```bash
pip install scmg_toolkit

