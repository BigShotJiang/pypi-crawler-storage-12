"""Public API for diagramagic."""
from .diagramagic import diagramagic

__all__ = ["diagramagic"]
