class Parameter:
    def toBytes(self):
        pass

    def bytesToClass(self, dataBytes):
        pass
