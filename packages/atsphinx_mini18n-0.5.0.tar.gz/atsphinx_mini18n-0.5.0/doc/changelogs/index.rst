==========
Changelogs
==========

.. include:: ../../CHANGES.rst

.. toctree::
   :glob:
   :reversed:
   :maxdepth: 1
   :caption: Old changes

   *
