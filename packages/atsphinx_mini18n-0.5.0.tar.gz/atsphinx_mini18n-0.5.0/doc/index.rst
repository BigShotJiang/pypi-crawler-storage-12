================
atsphinx-mini18n
================

.. toctree::
   :maxdepth: 1

   usage/index
   changelogs/index

Overview
========

This is sphinx extension to build simple i18n website.

It is useful to deploy documentation into single deployment entrypoint (ex: GitHub Pages).

.. note::

   This is inspired by `article of DevelopersIO <https://dev.classmethod.jp/articles/implement-sphinx-i18n-switch-button/>`_.
