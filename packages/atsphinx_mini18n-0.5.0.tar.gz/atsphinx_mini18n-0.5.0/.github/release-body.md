Release update

- Changelog is https://github.com/atsphinx/mini18n/blob/v0.5.0/CHANGES.rst
