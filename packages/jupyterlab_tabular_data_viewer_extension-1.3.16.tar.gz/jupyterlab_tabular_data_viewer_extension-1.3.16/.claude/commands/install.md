Execute `make install` to build and install the extension
