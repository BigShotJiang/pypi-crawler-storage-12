TODO
# calc_pack_sdiaz
