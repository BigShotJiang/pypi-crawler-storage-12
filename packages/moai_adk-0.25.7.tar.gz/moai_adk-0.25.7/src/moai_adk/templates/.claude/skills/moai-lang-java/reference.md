# moai-lang-java - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **Java**: 23.0.0
- **JUnit**: 5.11.0
- **Maven**: 3.9.9
- **Gradle**: 8.12.0

---

_For detailed usage, see SKILL.md_
