from .version import __version__  # type: ignore  # noqa: F401
