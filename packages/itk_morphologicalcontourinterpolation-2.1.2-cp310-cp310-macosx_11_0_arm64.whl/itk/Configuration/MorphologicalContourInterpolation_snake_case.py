snake_case_functions = ('morphological_contour_interpolator', )
