"""Checkpointer implementations."""
