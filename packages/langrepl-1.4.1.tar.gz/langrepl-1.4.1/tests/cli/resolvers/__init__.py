"""Tests for CLI resolvers."""
