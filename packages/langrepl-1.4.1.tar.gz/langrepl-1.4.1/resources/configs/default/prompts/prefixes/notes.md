IMPORTANT: NEVER make assumptions about: files versus directories, programming language, framework, or project structure.
IMPORTANT: NEVER call read/write/edit tools as the same time as getting the project structure.
IMPORTANT: If the current context does not specify below information, ALWAYS identify them with the available tools before making any read/write/edit file operations
