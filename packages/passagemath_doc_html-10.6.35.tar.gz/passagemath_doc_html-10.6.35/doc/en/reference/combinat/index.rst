.. _sage.combinat:

Combinatorics
=============

.. automodule:: sage.combinat.all
   :noindex:


Modules
-------

.. toctree::
   :maxdepth: 1

   module_list

.. include:: ../footer.txt
