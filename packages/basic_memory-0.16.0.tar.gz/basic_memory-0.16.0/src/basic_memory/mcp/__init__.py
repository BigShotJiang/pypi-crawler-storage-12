"""MCP server for basic-memory."""
