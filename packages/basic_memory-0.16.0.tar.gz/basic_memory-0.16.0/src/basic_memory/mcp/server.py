"""
Basic Memory FastMCP server.
"""

from fastmcp import FastMCP

mcp = FastMCP(
    name="Basic Memory",
)
