"""Arneso Pypitemplate Instance Uv."""
