"""Vault module for Obsidian integration."""

from .markdown_writer import MarkdownWriter

__all__ = ["MarkdownWriter"]
