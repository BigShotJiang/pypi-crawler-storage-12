alias pgtree="$(\cd "${BASH_SOURCE%/*}";pwd)/pgtree/pgtree"
