alias pgtree="$(\cd "${0%/*}";pwd)/pgtree/pgtree"
