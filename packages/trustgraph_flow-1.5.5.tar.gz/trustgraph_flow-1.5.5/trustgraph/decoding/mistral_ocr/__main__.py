#!/usr/bin/env python3

from . processor import run

if __name__ == '__main__':
    run()

