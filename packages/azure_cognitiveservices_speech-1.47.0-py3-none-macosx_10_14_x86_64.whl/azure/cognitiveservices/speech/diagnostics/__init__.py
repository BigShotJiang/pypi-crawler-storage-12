#  Copyright (c) Microsoft. All rights reserved.
#  See https://aka.ms/csspeech/license for the full license information.

"""
Microsoft Speech SDK for Python
"""

from . import logging
