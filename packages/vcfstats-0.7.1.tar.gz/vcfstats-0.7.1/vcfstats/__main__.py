"""Main entrance for `python -m vcfstats`"""
# pragma: no cover
from .cli import main

if __name__ == "__main__":
    main()
