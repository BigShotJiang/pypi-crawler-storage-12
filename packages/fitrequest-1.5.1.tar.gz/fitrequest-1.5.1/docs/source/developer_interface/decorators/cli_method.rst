cli_method
==========

.. autodecorator:: fitrequest.decorators.cli_method.cli_method
