paginated
=========

.. autodecorator:: fitrequest.decorators.paginated.paginated

.. autoclass:: fitrequest.decorators.paginated.AbstractPage
.. autoclass:: fitrequest.decorators.paginated.PageDict
