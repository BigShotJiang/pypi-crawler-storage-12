retry
=====

.. autodecorator:: fitrequest.decorators.retry.retry
