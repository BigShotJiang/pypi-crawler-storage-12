hybrid_syntax
=============

.. autodecorator:: fitrequest.decorators.hybrid_syntax.hybrid_syntax
