CLI
===

.. autofunction:: fitrequest.cli_utils.run_pretty
.. autofunction:: fitrequest.cli_utils.add_httpx_args
.. autofunction:: fitrequest.cli_utils.transform_literals
.. autofunction:: fitrequest.cli_utils.literal_to_enum
.. autofunction:: fitrequest.cli_utils.fit_cli_command
.. autofunction:: fitrequest.cli_utils.is_cli_command
