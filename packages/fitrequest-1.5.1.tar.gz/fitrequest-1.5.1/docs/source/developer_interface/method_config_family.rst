MethodConfigFamily
==================

.. autopydantic_model:: fitrequest.method_config_family.MethodConfigFamily
