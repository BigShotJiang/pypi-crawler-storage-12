FitVar
======

.. autopydantic_model:: fitrequest.fit_var.FitVar


ValidFitVar
-----------

.. py:type:: fitrequest.fit_var.ValidFitVar
   :canonical: FitVar | dict | str | None

   Annotated type used for validation, coercion, and serialization of FitVar.
