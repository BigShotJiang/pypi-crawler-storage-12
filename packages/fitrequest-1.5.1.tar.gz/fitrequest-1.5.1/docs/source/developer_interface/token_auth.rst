Token Authentication
====================

HeaderTokenAuth
---------------

.. autoclass:: fitrequest.token_auth.HeaderTokenAuth



ParamsTokenAuth
---------------

.. autoclass:: fitrequest.token_auth.ParamsTokenAuth
