Response Models
===============


ValidResponse
-------------

.. py:type:: fitrequest.response_model.ValidResponse
   :canonical: type[BaseModel] | str | None,

   Annotated type used for validation, coercion, and serialization of response models.


ValidResponse validation
------------------------

.. autofunction:: fitrequest.response_model.validate_init_value
