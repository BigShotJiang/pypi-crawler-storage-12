Errors
======

.. autoexception:: fitrequest.errors.FitRequestConfigurationError
.. autoexception:: fitrequest.errors.FitRequestRuntimeError
.. autoexception:: fitrequest.errors.UnrecognizedParametersError
.. autoexception:: fitrequest.errors.UrlRequestTooLongError
.. autoexception:: fitrequest.errors.InvalidMethodDecoratorError
.. autoexception:: fitrequest.errors.UnexpectedNoneBaseURLError
.. autoexception:: fitrequest.errors.FitDecoratorInvalidUsageError
.. autoexception:: fitrequest.errors.MultipleAuthenticationError
.. autoexception:: fitrequest.errors.HttpVerbNotProvidedError
.. autoexception:: fitrequest.errors.UnexpectedLiteralTypeError
.. autoexception:: fitrequest.errors.InvalidParamsTypeError
.. autoexception:: fitrequest.errors.InvalidResponseTypeError
