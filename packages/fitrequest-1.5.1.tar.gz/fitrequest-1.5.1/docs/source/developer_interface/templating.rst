Templating
==========

.. autoclass:: fitrequest.templating.KeepPlaceholderUndefined

.. autodata:: fitrequest.templating.jinja_env
  :no-value:
