MethodConfigGroup
=================

.. autopydantic_model:: fitrequest.method_config_group.MethodConfigGroup
