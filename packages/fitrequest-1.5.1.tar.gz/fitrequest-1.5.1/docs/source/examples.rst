Examples
--------

Additional examples can be found in the ``tests/demo*`` files.
These examples demonstrate various functionalities of **fitrequest** using different syntax.
See the `git project <https://gitlab.com/public-corner/fitrequest/-/tree/main/tests>`_.

A practical example of using **fitrequest** can be seen in the open-source `skillcorner <https://gitlab.com/public-corner/skillcorner>`_ project.
