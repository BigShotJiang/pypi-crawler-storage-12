__version__ = "0.2.0"
__author__ = "Konstantin Zhmurko"


from .manager import SettingsManager

__all__ = ["SettingsManager"]
