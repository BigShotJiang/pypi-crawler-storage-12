"""GetUpAndRun - Scaffold development environments from natural language."""

__version__ = "0.1.2"
__author__ = "Wander"
__license__ = "MIT"

