"""CLI module for GetUpAndRun."""

