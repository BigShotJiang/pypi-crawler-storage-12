"""Template profiles for common development stacks."""

from getupandrun.templates.manager import TemplateManager, get_template_manager

__all__ = ["TemplateManager", "get_template_manager"]

