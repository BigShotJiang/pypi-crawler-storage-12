from pathlib import Path

COUNTRY_DIR = Path(__file__).parent
