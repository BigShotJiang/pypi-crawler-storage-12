"""This file will provide a function to load json example situations."""

import json
import os

DIR_PATH = os.path.dirname(os.path.abspath(__file__))
