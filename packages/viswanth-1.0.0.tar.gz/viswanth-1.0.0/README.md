# viswanth

Offline Conversational AI Lab Experiments 7–10  
By Viswanth S S  
Contains chatbot, voice bot, classroom bot, and medical bot.
