from .ParametricLogish import ParametricLogish


class PLogish(ParametricLogish):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
