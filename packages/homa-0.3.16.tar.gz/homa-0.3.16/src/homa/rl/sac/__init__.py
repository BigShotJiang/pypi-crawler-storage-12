from .SoftActor import SoftActor
from .SoftCritic import SoftCritic
