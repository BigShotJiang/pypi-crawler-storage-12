import torch


class Loss(torch.nn.Module):
    pass
