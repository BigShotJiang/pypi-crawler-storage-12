"""
工具函数模块
"""

def get_api_key():
    """
    获取API密钥
    请在这里配置您的通义千问API密钥
    """
    # TODO: 请替换为您的实际API密钥
    return "your-api-key-here"

