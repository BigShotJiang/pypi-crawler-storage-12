# 小舟智能客服平台

这是一个基于 Streamlit 和 AI 技术的智能客服平台项目模板。

## 📦 已包含的文件

- `app.py` - 主应用入口
- `page_1_streaming.py` - 任务一：智能客服助手
- `page_2_rag.py` - 任务二：知识库问答（RAG）
- `page_3_image.py` - 任务三：多模态智能
- `ui_config.py` - UI配置文件
- `utils.py` - 工具函数
- `products.json` - 知识库数据

## 🚀 快速开始

### 1. 配置API密钥

编辑 `utils.py` 文件，替换API密钥：

```python
def get_api_key():
    return "your-api-key-here"  # 替换为您的通义千问API密钥
```

### 2. 安装依赖

```bash
pip install streamlit openai sentence-transformers faiss-cpu numpy
```

### 3. 运行应用

```bash
streamlit run app.py
```

## 📋 功能说明

### 任务一：智能客服助手
- 实时对话功能
- 上下文记忆
- 参数调节（模型选择、温度）

### 任务二：知识库问答（RAG）
- 向量语义搜索
- FAISS索引
- 知识库管理

### 任务三：多模态智能
- 文生图（AI绘画）
- 图生文（图片解析）

## 📝 注意事项

1. 确保已配置正确的API密钥
2. 首次运行会自动下载AI模型（约500MB）
3. 建议使用Python 3.8或更高版本

## 🎯 项目结构

```
.
├── app.py                  # 主应用
├── page_1_streaming.py     # 任务一
├── page_2_rag.py          # 任务二
├── page_3_image.py        # 任务三
├── ui_config.py           # UI配置
├── utils.py               # 工具函数
└── products.json          # 知识库
```

## 📞 技术支持

如有问题，请参考 streamlit-ai-toolkit 文档。

