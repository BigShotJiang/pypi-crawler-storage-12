# profiler/__init__.py
from .profiler import Profiler, print_profile, time_block

__all__ = ["Profiler", "print_profile", "time_block"]
