from .discrete import sample_int, sample_int_numba, sample_int_numpy
