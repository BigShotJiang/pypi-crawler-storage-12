from ._base import DataModelImporterPlugin

__all__ = [
    "DataModelImporterPlugin",
]
