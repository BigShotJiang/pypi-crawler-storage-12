"""Default SSE Server Implementation for flock."""
