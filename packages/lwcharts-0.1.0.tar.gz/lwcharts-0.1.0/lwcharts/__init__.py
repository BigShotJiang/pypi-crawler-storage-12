"""
lwc - Lightweight Charts for Jupyter
Ultra-simple inline chart rendering using IPython HTML display
"""

from .chart import Chart

__version__ = '0.1.0'
__all__ = ['Chart']
