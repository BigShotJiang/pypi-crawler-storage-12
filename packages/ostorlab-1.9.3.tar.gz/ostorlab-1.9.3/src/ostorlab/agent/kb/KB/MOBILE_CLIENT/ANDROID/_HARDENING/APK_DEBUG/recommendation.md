Disable debug mode by setting the attribute `android:debuggeable` to false in the `Application` tag in the Android Manifest.

=== "XML"
	```xml
	<application android:icon="@drawable/icon" android:debuggable="false">
	```
