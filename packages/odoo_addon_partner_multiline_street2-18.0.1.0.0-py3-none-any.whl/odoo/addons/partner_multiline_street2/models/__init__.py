from . import res_partner
from . import res_users
