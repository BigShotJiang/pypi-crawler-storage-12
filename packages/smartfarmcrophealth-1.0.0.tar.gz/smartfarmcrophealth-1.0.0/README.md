# smartfarm-crop-health

Local crop health analysis library.

## Usage
```python
from smartfarm_crop_health import CropHealthAnalyzer
an = CropHealthAnalyzer()
print(an.analyze_image("image.jpg"))
