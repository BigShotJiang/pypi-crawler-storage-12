from setuptools import setup
setup(
    name='chec_code',
    version='1.0',
    packages = ['chec_code'],
    install_requires=[],
    python_requires=">=3.3",
    author="David_Yudin",
    author_email="dyudin1204@gmail.com"
)