"""PowerPoint MCP Server using python-pptx."""

__version__ = "1.0.0"
