
# To Do List de Jhon

Pequeño gestor de tareas en Python pensado para demostrar estructuras de control:
- Selección: `if`, `elif`, `else`
- Repetición: `for`, `while`, `break`, `continue`
- Excepciones: `try`, `except`, `else`, `finally`


Este proyecto es una aplicación sencilla de **To-Do List** para guardar tareas en local.
Utiliza un archivo **JSON** para almacenar los datos y un **dict** de Python para manejarlos internamente.

---

## Características

- Ver tareas
- Agregar tarea
- Marcar tareas como completadas
- Eliminar tareas
- Listar todas las tareas
- Guardado automático en **JSON**
- Manejo interno mediante **dict**

---

## Almacenamiento y estructura

### Archivo JSON (`tareas.json`)

Las tareas se guardan en un archivo JSON con una estructura como esta:

```json
{
  "tasks": [
    {
      "titulo": "Limpiar",
      "prioridad": "alta",
      "hecho": true
    },
    {
      "titulo": "Comer",
      "prioridad": "alta",
      "hecho": false
    }
  ]
}

El proyecto está pensado para empaquetarse y subirse a TestPyPI
