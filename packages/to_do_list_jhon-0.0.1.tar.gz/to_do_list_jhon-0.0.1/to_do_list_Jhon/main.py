import json
import os
from typing import List, Dict

#Constante que define el nombre que tendra el JSON
DATA_FILE = "tareas.json"

#Función qeu carga las tareas del archivo JSON, si no existe crea una lista vacia, y
# si se encuentra con un error al intentar abrirla tambien crea una lista vacia
def cargar_tareas() -> List[Dict]:
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            tareas = json.load(f)
    except FileNotFoundError:
        print(f"No se encontro {DATA_FILE}, comenzando con lista vacía...")
        tareas = []
    except Exception as e:
        print(f"Error: {e}")
        tareas = []
    else:
        print(f"Cargadas {len(tareas)} tareas desde {DATA_FILE}")
    finally:
        return tareas

#Función que guarda las tareas en el archivo JSON
def guardar_tareas(tareas: List[Dict]) -> None:
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(tareas, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Error al guardar: {e}")
    else:
        print(f"Tareas guardadas en {DATA_FILE}")


#Función que muestra las tareas en la consola, usa la función enumerate que obtiene el indice y el valor
def mostrar_tareas(tareas: List[Dict]) -> None:
    if not tareas:
        print("\n-------- No hay tareas ---------")
        return
    print("\n-- TAREAS --")
    for indice, t in enumerate(tareas, start=1):
        estado = "Hecho" if t.get("hecho") else "Por hacer"
        prioridad = t.get("prioridad", "media")
        print(f"{indice}. [{estado}] {t.get('titulo')} (prioridad: {prioridad})")
    print("------ fin listado ---------")

#Función que pide un entero al usuario, con validaciones de minimo y maximo
#se usa en varias partes del programaen las qeu se pide al usuario elegir una opción

def pedir_entero(prompt: str, minimo: int = None, maximo: int = None) -> int:
    while True:
        entrada = input(prompt)
        try:
            valor = int(entrada)
        except ValueError:
            print("Debes introducir un número entero")
            continue
        if minimo is not None and valor < minimo:
            print(f"El número debe ser >= {minimo}")
            continue
        if maximo is not None and valor > maximo:
            print(f"El número debe ser <= {maximo}")
            continue
        return valor
    

#Funcion que agrega una tarea a la lista, pero no la guarda en el archivo
def agregar_tarea(tareas: List[Dict]) -> None:
    titulo = input("Título de la tarea: ").strip()
    if not titulo:
        print("El titulo no puede estar vacío.")
        return
    print("Prioridad: 1. alta  2. media  3. baja")
    p = pedir_entero("Elige prioridad (1-3): ", 1, 3)
    prioridad = "alta" if p == 1 else ("media" if p == 2 else "baja")
    tarea = {"titulo": titulo, "prioridad": prioridad, "hecho": False}
    tareas.append(tarea)
    print("Tarea agregada")

#Funcion que elimina una tarea de la lista, pero no guarda esos cambios en el archivo
def eliminar_tarea(tareas: List[Dict]) -> None:
    if not tareas:
        print("No hay tareas para eliminar")
        return
    mostrar_tareas(tareas)
    idx = pedir_entero("Número de tarea a eliminar: ", 1, len(tareas))
    confirma = input(f"Eliminar la tarea #{idx}? (s/n): ").strip().lower()
    if confirma == "s":
        try:
            tarea = tareas.pop(idx - 1)
        except Exception as e:
            print(f"No se pudo eliminar la tarea: {e}")
        else:
            print(f"Tarea '{tarea.get('titulo')}' eliminada")
    else:
        print("Cancelado")

#Función que marca una tarea como hecha, cambiando su estado en la lista, pero no guarda esos cambios en el archivo
def marcar_como_hecha(tareas: List[Dict]) -> None:
    if not tareas:
        print("No hay tareas para marcar")
        return
    mostrar_tareas(tareas)
    idx = pedir_entero("Número de tarea a marcar como hecha: ", 1, len(tareas))
    for i, t in enumerate(tareas, start=1):
        if i == idx:
            t["hecho"] = True
            print(f"Tarea '{t['titulo']}' marcada como hecha")
            break

#Función que muestra el menú de opciones
def mostrar_menu() -> None:
    print("""
--- TO DO LIST ---
1) Ver tareas
2) Agregar tarea
3) Eliminar tarea
4) Marcar tarea como hecha
6) Guardar y salir
7) Salir sin guardar
""")
#Función principal que controla el flujo del programa
def main() -> None:
    tareas = cargar_tareas()
    while True:
        mostrar_menu()
        try:
            opcion = input("Elige una opción (1-7): ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n interrumpido por el usuario")
            break
        if opcion == "1":
            mostrar_tareas(tareas)
        elif opcion == "2":
            agregar_tarea(tareas)
        elif opcion == "3":
            eliminar_tarea(tareas)
        elif opcion == "4":
            marcar_como_hecha(tareas)
        elif opcion == "6":
            try:
                guardar_tareas(tareas)
            except Exception as e:
                print(f"Ocurrio un error al guardar: {e}")
            finally:
                print("Saliendo de la aplicación")
                break
        elif opcion == "7":
            confirma = input("Seguro que quieres salir sin guardar? (s/n): ").strip().lower()
            if confirma == "s":
                print("Saliendo sin guardar")
                break
            else:
                print("Cancelado")
                continue
        else:
            print("Opción no valida, Introduce un número entre 1 y 7")
            continue

if __name__ == "__main__":
    main()
