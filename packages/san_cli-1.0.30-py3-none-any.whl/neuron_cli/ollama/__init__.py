"""Ollama management module"""

from .manager import OllamaManager

__all__ = [
    'OllamaManager',
]
