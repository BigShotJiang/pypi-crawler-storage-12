# © 2019 Marco Calcagni(<http://www.dinamicheaziendali.it>)
# © 2016 Andrea Cometa (<http://www.andreacometa.it>)
# © 2012 Agile Business Group sagl (<http://www.agilebg.com>)
# © 2012 Domsense srl (<http://www.domsense.com>)
# © 2012 Associazione Odoo Italia
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import models, wizard, report
from .hooks import pre_absorb_old_module
