from .default import DefaultPrinterStrategy
from ..printer import PrinterStrategy

__all__ = ["DefaultPrinterStrategy", "PrinterStrategy"]
