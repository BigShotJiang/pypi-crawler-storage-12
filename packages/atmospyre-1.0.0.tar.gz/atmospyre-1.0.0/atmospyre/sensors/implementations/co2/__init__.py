from .vaisala import gmp252 as gmp252
