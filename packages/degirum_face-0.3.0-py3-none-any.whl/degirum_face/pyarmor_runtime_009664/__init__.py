# Pyarmor 9.2.0 (basic), 009664, 2025-11-13T22:05:52.930767
from .pyarmor_runtime import __pyarmor__
