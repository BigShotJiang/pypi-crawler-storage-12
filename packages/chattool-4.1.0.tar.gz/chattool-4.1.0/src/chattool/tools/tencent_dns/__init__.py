from .client import TencentDNSClient

# 导出的公共接口
__all__ = [
    # 主要客户端
    'TencentDNSClient',
]
