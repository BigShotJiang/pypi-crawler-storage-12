"""Version information for Voynich Morphemic Decryption."""

__version__ = "1.0.0"
__author__ = "Mateusz Piesiak"
__email__ = "mateuszpiesiak1990@gmail.com"
__license__ = "MIT"
