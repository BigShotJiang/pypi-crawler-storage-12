pub use tombi_ast::support::literal::integer::{
    try_from_binary, try_from_decimal, try_from_hexadecimal, try_from_octal, ParseIntError,
};
