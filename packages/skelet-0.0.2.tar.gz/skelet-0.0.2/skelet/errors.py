class CaseError(Exception):
    pass
