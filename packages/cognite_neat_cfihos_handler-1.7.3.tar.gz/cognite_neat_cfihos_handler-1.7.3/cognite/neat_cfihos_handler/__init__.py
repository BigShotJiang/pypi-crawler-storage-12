"""CFIHOS processor package initialization.

This package contains modules and configuration for processing CFIHOS data models,
including loader frameworks, configuration files, and processing utilities.
"""
