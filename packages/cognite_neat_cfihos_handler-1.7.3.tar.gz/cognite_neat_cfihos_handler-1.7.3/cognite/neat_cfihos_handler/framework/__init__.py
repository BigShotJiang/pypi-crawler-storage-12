"""Framework package initialization for CFIHOS.

This package provides the core framework modules and utilities for processing CFIHOS data models.
"""
