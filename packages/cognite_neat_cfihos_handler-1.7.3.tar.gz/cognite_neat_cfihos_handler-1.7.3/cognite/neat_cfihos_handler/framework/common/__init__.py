"""Common utilities and shared components for the CFIHOS framework.

This module provides common functionality, helpers, and base classes
used throughout the CFIHOS processing framework.
"""
