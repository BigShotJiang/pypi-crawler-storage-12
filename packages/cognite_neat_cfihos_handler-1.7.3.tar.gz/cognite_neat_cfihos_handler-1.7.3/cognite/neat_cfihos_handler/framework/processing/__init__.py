"""Processing framework for CFIHOS data models."""
