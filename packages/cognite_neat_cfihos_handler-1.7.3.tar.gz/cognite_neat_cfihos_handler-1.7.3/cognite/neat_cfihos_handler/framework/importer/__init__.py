"""Importer package for the CFIHOS framework.

This package provides modules and utilities for importing and integrating data
into the CFIHOS processing framework.
"""
