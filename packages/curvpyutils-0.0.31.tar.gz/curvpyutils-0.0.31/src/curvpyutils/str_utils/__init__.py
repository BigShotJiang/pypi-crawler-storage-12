"""String utilities."""

from .insert_underscores import insert_underscores

__all__ = [
    "insert_underscores",
]

