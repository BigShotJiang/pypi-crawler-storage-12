from kdb.webdriver.kdb_webdriver import KDBWebDriver

kdb_driver = KDBWebDriver()
