``fsl.utils.parse_data``
========================

.. automodule:: fsl.utils.parse_data
    :members:
    :undoc-members:
    :show-inheritance:
