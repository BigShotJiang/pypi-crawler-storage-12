``fsl.utils.settings``
======================

.. automodule:: fsl.utils.settings
    :members:
    :undoc-members:
    :show-inheritance:
