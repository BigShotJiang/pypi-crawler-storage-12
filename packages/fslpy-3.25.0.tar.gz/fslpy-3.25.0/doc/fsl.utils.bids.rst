``fsl.utils.bids``
==================

.. automodule:: fsl.utils.bids
    :members:
    :undoc-members:
    :show-inheritance:
