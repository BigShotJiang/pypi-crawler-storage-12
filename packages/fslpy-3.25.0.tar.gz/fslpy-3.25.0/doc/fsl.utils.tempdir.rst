``fsl.utils.tempdir``
=====================

.. automodule:: fsl.utils.tempdir
    :members:
    :undoc-members:
    :show-inheritance:
