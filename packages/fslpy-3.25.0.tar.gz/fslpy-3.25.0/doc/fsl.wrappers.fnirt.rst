``fsl.wrappers.fnirt``
======================

.. automodule:: fsl.wrappers.fnirt
    :members:
    :undoc-members:
    :show-inheritance:
