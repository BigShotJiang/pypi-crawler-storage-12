``fsl.data.dtifit``
===================

.. automodule:: fsl.data.dtifit
    :members:
    :undoc-members:
    :show-inheritance:
