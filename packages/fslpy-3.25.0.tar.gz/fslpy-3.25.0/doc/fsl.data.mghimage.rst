``fsl.data.mghimage``
=====================

.. automodule:: fsl.data.mghimage
    :members:
    :undoc-members:
    :show-inheritance:
