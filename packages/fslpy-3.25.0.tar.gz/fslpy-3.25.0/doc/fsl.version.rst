``fsl.version``
===============

.. automodule:: fsl.version
    :members:
    :undoc-members:
    :show-inheritance:
