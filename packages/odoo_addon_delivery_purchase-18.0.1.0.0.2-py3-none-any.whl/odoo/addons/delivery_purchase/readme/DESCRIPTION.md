This module allows to use delivery methods defined in *delivery* module
to calculate purchase delivery costs.

It reverses destinations in delivery pricelists to use them as sources
when applying the delivery method to purchases.
