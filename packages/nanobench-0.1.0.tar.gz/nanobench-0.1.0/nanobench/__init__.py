"""
nanobench - A simple hello world package
"""

__version__ = "0.1.0"


def hello():
    """Print hello world to the console."""
    print("hello world")


if __name__ == "__main__":
    hello()
