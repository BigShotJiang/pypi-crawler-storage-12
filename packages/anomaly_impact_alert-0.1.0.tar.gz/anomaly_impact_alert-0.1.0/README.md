# anomaly_impact_alert

Anomaly detection, impact explanation, forecasting, and Telegram alerting toolkit.

## Install
```bash
pip install anomaly_impact_alert
```
