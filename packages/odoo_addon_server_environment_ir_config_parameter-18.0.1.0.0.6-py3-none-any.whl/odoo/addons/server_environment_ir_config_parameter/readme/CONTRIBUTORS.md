- Stéphane Bidoul \<<stephane.bidoul@acsone.eu>\> (<https://acsone.eu>)
- Thierry Ducrest \<<thierry.ducrest@camptocamp.com>\>
- Gilles Meyomesse \<<gilles.meyomesse@acsone.eu>\>
  (<https://acsone.eu>)
- Sylvain LE GAL (<https://www.twitter.com/legalsylvain>)
- Chau Le \<<chaulb@trobz.com>\>
