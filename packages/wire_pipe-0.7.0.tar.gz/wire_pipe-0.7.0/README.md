# wire-pipe

Wire for communicating over pipes.
