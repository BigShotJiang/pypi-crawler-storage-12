"""nbutils - The Swiss Army Knife for Jupyter Notebooks"""

__version__ = "0.1.0"
__author__ = "Venkatachalam Subramanian Periya Subbu"
__email__ = "venkatachalam.sps@gmail.com"
