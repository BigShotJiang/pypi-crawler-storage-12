"""Kraken WebSocket provider."""

from .provider import KrakenWSProvider

__all__ = ["KrakenWSProvider"]
