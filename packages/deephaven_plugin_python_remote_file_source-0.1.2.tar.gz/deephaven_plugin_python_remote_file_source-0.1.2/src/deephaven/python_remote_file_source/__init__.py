"""
This is a plugin for Deephaven that provides a simple object that can send messages to and from the client.
"""

from .plugin_object import *
