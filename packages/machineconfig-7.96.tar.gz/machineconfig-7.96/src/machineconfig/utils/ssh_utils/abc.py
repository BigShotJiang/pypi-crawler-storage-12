

MACHINECONFIG_VERSION = "machineconfig>=7.96"
DEFAULT_PICKLE_SUBDIR = "tmp_results/tmp_scripts/ssh"

