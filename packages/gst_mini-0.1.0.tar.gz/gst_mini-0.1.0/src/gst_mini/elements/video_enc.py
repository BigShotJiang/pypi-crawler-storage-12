# GstMini
# Copyright (C) 2025 Rafael Caricio <rafael@caricio.com>
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.
#
# You should have received a copy of the GNU Library General Public
# License along with this library; if not, write to the
# Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.


from ..core.element import GstElement
from ..core.buffer import GstBuffer, BufferFlags
from ..core.pad import GstFlowReturn


class VideoEnc(GstElement):

    def __init__(self, name: str, gop_size: int = 30):
        """
        Create a video encoder element.

        Args:
            name: Element name
            gop_size: Group of Pictures size
        """
        super().__init__(name)
        # properties
        self.gop_size = gop_size

        # state
        self.processed_frames = 0

        self.sink_pad = self.create_sink_pad("sink")
        self.sink_pad.set_chain_function(self._chain)
        self.src_pad = self.create_src_pad("src")

    def _chain(self, buffer: GstBuffer) -> GstFlowReturn:
        # A fake encoding by counting the number of buffers and set the flags
        if buffer.has_flag(BufferFlags.EOS):
            self.log("Received EOS")
            return GstFlowReturn.EOS

        if self.processed_frames % self.gop_size == 0:
            buffer.unset_flag(BufferFlags.DELTA_UNIT)
            self.log(f"Encoded IDR frame #{self.processed_frames}")
        else:
            buffer.set_flag(BufferFlags.DELTA_UNIT)

        self.processed_frames += 1

        return self.src_pad.push(buffer)
