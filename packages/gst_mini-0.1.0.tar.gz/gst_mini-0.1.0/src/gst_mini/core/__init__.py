# GstMini
# Copyright (C) 2025 Rafael Caricio <rafael@caricio.com>
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.
#
# You should have received a copy of the GNU Library General Public
# License along with this library; if not, write to the
# Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.

"""Core GStreamer-like framework components."""

from .buffer import GstBuffer, BufferFlags
from .segment import GstSegment
from .pad import GstPad, GstFlowReturn
from .element import GstElement, GstState
from .pipeline import GstPipeline
from .clock import GstClock

__all__ = [
    'GstBuffer',
    'BufferFlags',
    'GstSegment',
    'GstPad',
    'GstElement',
    'GstState',
    'GstPipeline',
    'GstClock',
    'GstFlowReturn',
]
