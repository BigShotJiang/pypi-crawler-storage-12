#!/usr/bin/env python3
"""
Simple example showing GStreamer pipeline with live source and synchronized sink.

Creates a pipeline with a LiveSource generating video test patterns at 1fps
and a FakeSink with synchronization enabled to demonstrate clock-based timing.

Pipeline:
    LiveSource (videotestsrc, 1fps) → FakeSink (sync=True)
"""

from gst_mini import GstPipeline, GstState, FakeSink, LiveSource


def main():
    print("=" * 80)
    print("Simple Synchronization Example")
    print("=" * 80)
    print()
    print("Using LiveSource to generate buffers at 1fps")
    print("Watch for clock waits demonstrating synchronization")
    print()
    print("=" * 80)
    print()

    # Create pipeline
    pipeline = GstPipeline("simple-pipeline")

    # Create elements
    source = LiveSource('videotestsrc', fps=1)
    sink = FakeSink('fakesink', sync=True)

    # Add to pipeline
    pipeline.add(source)
    pipeline.add(sink)

    # Link elements
    source.link(sink)

    # Set to PLAYING
    pipeline.set_state(GstState.PLAYING)

    # Runs for 5 seconds
    pipeline.run(5)

    # Cleanup
    pipeline.set_state(GstState.NULL)

    print()
    print("=" * 80)
    print(f"Completed example, total processed frames by sink: {sink.buffer_count}")
    print("=" * 80)


if __name__ == '__main__':
    main()
