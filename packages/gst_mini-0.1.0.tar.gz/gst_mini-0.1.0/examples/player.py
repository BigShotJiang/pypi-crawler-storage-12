import threading
import time
from gst_mini import GstPipeline, GstState, FileSrc, TkSink, GstBuffer, GstFlowReturn


def main():
    """
    Test the TkSink element by creating a pipeline and pushing buffers to it.

    This demonstrates proper integration with Tkinter on macOS:
    - Tkinter runs on the main thread
    - Buffer pushing happens in a background thread
    - The sink queues buffers and renders them from the Tk thread

    This example is equivalent to running the gst-launch-1.0 command:

        gst-launch-1.0 filesrc location=/Users/rafaelcaricio/Downloads/simple.png ! pngdec ! videoconvert ! imagefreeze ! osxvideosink

    """
    # Create pipeline and TkSink
    pipeline = GstPipeline("test-tksink-pipeline")

    filesrc = FileSrc("filesrc", location="/Users/rafaelcaricio/Downloads/simple.png", blocksize=1_000_000)
    tksink = TkSink("osxvideosink", win_title="GstMini Video Output", win_geometry="530x453")

    pipeline.add(filesrc)
    pipeline.add(tksink)

    filesrc.link(tksink)

    # Set pipeline to PLAYING state
    pipeline.set_state(GstState.PLAYING)

    # Run Tkinter mainloop on the main thread
    # This will block until the window is closed
    try:
        print("Pipeline is playing - press Ctrl+C to stop")
        tksink.tk_root().mainloop()
    except KeyboardInterrupt:
        print("\nInterrupted by user")
    finally:
        # Clean shutdown
        pipeline.set_state(GstState.NULL)
        print("Test completed.")


if __name__ == '__main__':
    main()

