"""CereBro - A streamlined TUI for Ollama LLMs."""

__version__ = "0.1.0"