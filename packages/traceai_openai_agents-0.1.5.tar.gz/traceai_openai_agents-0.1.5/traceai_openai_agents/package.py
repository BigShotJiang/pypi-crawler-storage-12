_instruments = ("openai-agents >= 0.0.7",)
_supports_metrics = False
