Object.defineProperty(this, 'MessageEvent', { 
	get: function() {
		return 1/0;
	}
});
