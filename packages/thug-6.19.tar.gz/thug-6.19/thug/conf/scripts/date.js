Date.prototype.getYear = function()
{
	return this.getFullYear();
};
