class Activator:
    def __init__(self, delegate):
        self.delegate = delegate

    def CreateInstance(self, Type):
        pass
