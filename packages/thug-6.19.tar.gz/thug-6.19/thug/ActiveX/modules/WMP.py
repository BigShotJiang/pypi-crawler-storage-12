import logging

log = logging.getLogger("Thug")


def openPlayer(self, arg):  # pylint:disable=unused-argument
    log.warning(arg)
