"""I mean, you must write docstrings after you write the code because you don't know what the code will do until after you write it.

I strongly suspect this directory will slowly evolve into an entire ecosystem of docstring tools.
"""
