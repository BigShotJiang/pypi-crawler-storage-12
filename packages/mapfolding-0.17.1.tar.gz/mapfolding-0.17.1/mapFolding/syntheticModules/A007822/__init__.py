"""Everything in this directory is synthesized by other modules in the package."""
