"""Hand-made algorithms and formulas."""
