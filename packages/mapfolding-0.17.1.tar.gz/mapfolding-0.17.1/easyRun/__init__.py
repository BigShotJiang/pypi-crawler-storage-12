"""Instead of learning to make a Python UI, I made these modules."""
