# crosshair: analysis_kind=PEP316
