#!/usr/bin/python3
# -*- coding: utf-8 -*-


"""Stata MCP Prompts package."""
from .core_prompts import register_core_prompts

__all__ = ["register_core_prompts"]