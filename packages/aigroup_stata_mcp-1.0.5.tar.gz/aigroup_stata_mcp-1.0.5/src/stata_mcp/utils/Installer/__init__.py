#!/usr/bin/python3
# -*- coding: utf-8 -*-


from .installer import Installer

__all__ = ["Installer"]
