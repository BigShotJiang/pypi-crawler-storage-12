#!/usr/bin/python3
# -*- coding: utf-8 -*-


from ._cli import main as main

if __name__ == "__main__":
    main()
