#!/usr/bin/python3
# -*- coding: utf-8 -*-


from .finder import StataFinder

__all__ = [
    "StataFinder",
]
