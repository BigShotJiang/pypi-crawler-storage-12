__version__ = "2025.11.17"
__prog__ = "webscout"
