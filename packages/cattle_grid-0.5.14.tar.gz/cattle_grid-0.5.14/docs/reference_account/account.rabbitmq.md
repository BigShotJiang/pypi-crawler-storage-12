# cattle_grid.account.rabbit

<div class="grid cards" markdown>

- [:material-api:{ .lg .middle } __OpenAPI__](../assets/redoc.html?url=openapi_rabbit.json)

- [:material-download:{ .lg .middle } __Download__](../assets/schemas/openapi_rabbit.json)

</div>

:::cattle_grid.account.rabbit
    options:
        show_submodules: True
