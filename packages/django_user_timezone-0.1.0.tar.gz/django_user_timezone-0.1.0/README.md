django-timezome
==============

A quick timezone app for testing. Hopefully will replace this with a third-party maintained app later
