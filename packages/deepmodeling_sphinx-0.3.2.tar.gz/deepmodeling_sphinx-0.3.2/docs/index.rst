.. include:: ../README.md
   :parser: myst_parser.sphinx_

Others
------

.. toctree::
   :hidden:

   Summary <self>


.. toctree::
   :titlesonly:

   api_py/api_py
   credits

------------------


* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. _feedback:
.. _affiliated packages:
