"""Resource types package containing concrete resource type implementations."""
