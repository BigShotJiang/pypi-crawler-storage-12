📄 محتوى README.md
# reqlib

مكتبة بايثون بسيطة للتعامل مع HTTP مثل مكتبة `requests`، لكنها أخف وأبسط.

## 🚀 التثبيت

بعد رفعها على PyPI:

```bash
pip install reqlib


📖 الاستخدام
طلب GET مع باراميتر
import reqlib

resp = reqlib.get("https://jsonplaceholder.typicode.com/posts", params={"userId": 1})
print(resp.status)   # 200
print(resp.ok)       # True
print(resp.json()[0])


طلب POST مع JSON
resp2 = reqlib.post("https://jsonplaceholder.typicode.com/posts", json={"title": "foo", "body": "bar"})
print(resp2.status)  # 201
print(resp2.json())


طلب POST مع بيانات form-urlencoded
resp3 = reqlib.post("https://httpbin.org/post", data={"s": "ss"})
print(resp3.status)
print(resp3.json())


استخدام الـ timeout
resp = reqlib.get("https://jsonplaceholder.typicode.com/posts", timeout=5)
print(resp.status)


استخدام proxies
proxies = {
    "http": "http://127.0.0.1:8080",
    "https": "http://127.0.0.1:8080"
}
resp = reqlib.get("https://jsonplaceholder.typicode.com/posts", proxies=proxies)
print(resp.status)


ميزة res.html لاستخراج الحقول
يمكنك استخراج الحقول من صفحات HTML (مثل الفورم):
resp = reqlib.get("https://httpbin.org/forms/post")

# يرجع dict فيه كل الحقول name/value
print(resp.html)

# تستدعي متغير معين
print(resp.html.get("custname"))


استخراج الروابط من HTML
resp = reqlib.get("https://example.com")

# يرجع قائمة بكل الروابط الموجودة في الصفحة
print(resp.html_links)


✅ المزايا
- يدعم GET, POST, PUT, DELETE
- يدعم params, data, json
- خصائص الاستجابة: .status, .url, .headers, .cookies, .text, .json(), .content, .ok
- ميزة .html لاستخراج الحقول من صفحات HTML (input, textarea, select)
- ميزة .html_links لاستخراج جميع الروابط <a href="...">
- يدعم timeout و proxies

---
