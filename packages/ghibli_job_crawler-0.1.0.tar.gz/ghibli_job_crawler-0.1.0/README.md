# Job Crawler: Thư viện hỗ trợ cào data về các ngành nghề

### Cách cài đặt

Cách 1: tải từ repo
<pre>
git clone repo_url
pip install -e .
</pre>

Cách 2: từ PyPi
<pre>pip install ghibli_job_crawler</pre>
