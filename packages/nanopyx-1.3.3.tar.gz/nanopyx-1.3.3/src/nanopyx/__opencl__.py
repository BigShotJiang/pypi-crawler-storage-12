from liquid_engine.__opencl__ import *
from liquid_engine.__opencl__ import _fastest_device