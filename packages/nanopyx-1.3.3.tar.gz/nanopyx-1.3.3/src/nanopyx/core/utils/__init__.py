from ._le_mandelbrot_benchmark import MandelbrotBenchmark
from ._le_DUMMY import DUMMY
