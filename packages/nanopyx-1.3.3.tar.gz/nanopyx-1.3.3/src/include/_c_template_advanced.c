
void _c_template_advanced(float* image) {
    // add your code here
    image = image;
}