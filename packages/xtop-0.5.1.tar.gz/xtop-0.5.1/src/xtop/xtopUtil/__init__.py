from .xtopUtil import getOS, getArch


__all__ = ["getOS", "getArch"]

