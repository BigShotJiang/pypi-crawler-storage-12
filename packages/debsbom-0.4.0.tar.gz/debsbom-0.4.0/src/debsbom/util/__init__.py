# Copyright (C) 2025 Siemens
#
# SPDX-License-Identifier: MIT

from .compression import Compression
