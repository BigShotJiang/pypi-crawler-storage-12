from .. import __main__


def test_none():
    return
