from ..dbc_writer import write_dbc


def test_pass():
    return
