# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'signaldevice.ui',
# licensing of 'signaldevice.ui' applies.
#
# Created: Mon Oct 14 22:57:02 2019
#      by: pyside2-uic  running on PySide2 5.13.1
#
# WARNING! All changes made in this file will be lost!
