"""Main entry point for the Baldwin CLI."""
from __future__ import annotations

from .main import baldwin as main

main()
