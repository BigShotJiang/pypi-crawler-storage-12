from .elapi import app
from .._names import APP_NAME

app(prog_name=APP_NAME)
