"""Camel TUI - Enhanced Claude Code Interface"""
__version__ = "0.1.0"
