"""Basic tests for Camel TUI"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from core.tool_registry import ToolRegistry
import tempfile


def test_tool_registry():
    """Test tool registry initialization"""
    registry = ToolRegistry()
    assert "read" in registry.tools
    assert "write" in registry.tools
    assert "bash" in registry.tools
    print("✓ Tool registry initialized")


def test_read_write():
    """Test file read/write"""
    registry = ToolRegistry()

    # Create temp file
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        temp_path = f.name
        f.write("test content\n")

    # Test read
    result = registry.execute("read", path=temp_path)
    assert result["success"]
    assert "test content" in result["content"]
    print("✓ File read works")

    # Test write
    result = registry.execute("write", path=temp_path, content="new content\n")
    assert result["success"]

    result = registry.execute("read", path=temp_path)
    assert "new content" in result["content"]
    print("✓ File write works")

    # Cleanup
    os.unlink(temp_path)


def test_bash():
    """Test bash execution"""
    registry = ToolRegistry()

    result = registry.execute("bash", command="echo 'test'")
    assert result["success"]
    assert "test" in result["stdout"]
    print("✓ Bash execution works")


if __name__ == "__main__":
    test_tool_registry()
    test_read_write()
    test_bash()
    print("\n✅ All tests passed")
