# © 2019-present nextmv.io inc

__version__ = "v1.12.3"
