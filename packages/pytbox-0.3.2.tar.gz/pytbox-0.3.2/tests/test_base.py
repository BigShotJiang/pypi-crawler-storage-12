#!/usr/bin/env python3

from pytbox.base import config, feishu, dida, vm

def test_config():
    assert isinstance(config, dict)



