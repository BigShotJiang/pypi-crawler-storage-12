from django.apps import AppConfig


class OpenApiFrameworkConfig(AppConfig):
    name = "open_api_framework"
