# Vector3

A point with an x, y and z coordinate

|  TYPE  |
|:------:|
| object |

**Properties**

| NAME |  TYPE  | DESCRIPTION                   |
|:----:|:------:|:------------------------------|
|  x   | number | The x coordinate of the point |
|  y   | number | The y coordinate of the point |
|  z   | number | The z coordinate of the point |
