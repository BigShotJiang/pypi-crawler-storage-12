# Pointer

A circle shape that when moved leaves a trail

Extends [Item](item.md)

|  TYPE  |
|:------:|
| object |

**Properties**

|  NAME  |   TYPE    | DESCRIPTION                         |
|:------:|:---------:|:------------------------------------|
|  type  | "POINTER" | The type of item                    |
| color  |  string   | The color of the pointer            |
| radius |  number   | The radius of the pointer in pixels |
