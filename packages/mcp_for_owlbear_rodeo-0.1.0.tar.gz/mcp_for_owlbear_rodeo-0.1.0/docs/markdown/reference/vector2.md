# Vector2

A point with an x and y coordinate

|  TYPE  |
|:------:|
| object |

**Properties**

| NAME |  TYPE  | DESCRIPTION                   |
|:----:|:------:|:------------------------------|
|  x   | number | The x coordinate of the point |
|  y   | number | The y coordinate of the point |
