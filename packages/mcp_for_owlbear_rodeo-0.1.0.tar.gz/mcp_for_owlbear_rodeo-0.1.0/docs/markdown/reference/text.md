# Text

A text item without any background

Extends [Item](item.md)

|  TYPE  |
|:------:|
| object |

**Properties**

| NAME |              TYPE              | DESCRIPTION        |
|:----:|:------------------------------:|:-------------------|
| type |             "TEXT"             | The type of item   |
| text | [TextContent](text-content.md) | The text displayed |
