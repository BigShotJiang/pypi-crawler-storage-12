# Math

To help with updating item transforms the SDK ships with two static Math libraries.

## 📄️ Math2

Math class for Vector2's.

## 📄️ MathM

Math class for a 2D transformation Matrix.
