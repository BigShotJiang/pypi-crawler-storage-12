# Kunna

A simple CLI tool to display Q&A content.

## Installation

```bash
pip install kunna
```

## Usage

Display a specific question:

```bash
kunna show q1
kunna show Q1
kunna show q15
```

## Available Questions

Questions Q1 through Q15 are available.

## License

MIT
