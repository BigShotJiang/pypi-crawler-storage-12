"""Kunna - A CLI tool to display Q&A content."""

__version__ = "0.1.0"
