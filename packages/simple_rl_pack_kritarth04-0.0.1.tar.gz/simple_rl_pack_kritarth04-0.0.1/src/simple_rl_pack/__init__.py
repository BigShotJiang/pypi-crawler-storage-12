# src/simple_rl_pack/__init__.py

# This makes the EpsilonGreedyBandit class available when
# someone imports your package, like:
# from simple_rl_pack import EpsilonGreedyBandit

from .bandit import EpsilonGreedyBandit