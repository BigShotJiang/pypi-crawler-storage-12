# bulloh
Script to automate gathering personal productivity data.
