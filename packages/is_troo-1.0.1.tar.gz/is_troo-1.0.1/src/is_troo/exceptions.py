"""
Defines custom exceptions, because problems arise in life to challenge greatness.
Also I suck at this so they help
"""

class TrooEvalError(Exception):
    """Raised when something goes terribly wrong during the patent-pending is_true pipeline"""
    pass

class TroothyEvalError(Exception):
    """Raised when something goes terribly wrong during the weird and clunky is_troothy shabang"""
    pass