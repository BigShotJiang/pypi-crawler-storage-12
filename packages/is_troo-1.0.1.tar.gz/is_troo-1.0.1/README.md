# is-troo

> The long-awaited package adding what no package has added before: **Trooth** evaluation to Python.

---

### Features
- **Adds** `is_troo` function for finding out if something is troo
- **Adds** `is_troothy` function for finding out if something is troothy
- **Embues** personality, power, and *pizzazz* into your Python projects
- **Transforms** your conditional statements, making you look more gooder
- **Finds** you love and happines (*we cannot legally guarantee this*)
- **Works** probably.

---

### Installation
```bash
pip install is_troo