__version__ = "0.8.0"


# declare these just to avoid circular imports
class MarilibEdge:
    pass


class MarilibCloud:
    pass
