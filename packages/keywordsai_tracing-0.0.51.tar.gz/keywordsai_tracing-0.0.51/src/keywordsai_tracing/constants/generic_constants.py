SDK_PREFIX = "keywordsai"
LOGGER_NAME = "keywordsai_tracing"