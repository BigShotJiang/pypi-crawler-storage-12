# Gas required to transfer a regular token. Assume the worst scenario with a regular token transfer without storage
# initialized (payment_receiver no previous owner of token)
TOKEN_TRANSFER_GAS = 60_000
