This is the Swiss localization for the Cooperators module

Features:

- Add Swiss legal form of companies on partner and on Subscription Request
