"""Central version definition for the Syntropy package."""

__version__ = "0.1.0"
