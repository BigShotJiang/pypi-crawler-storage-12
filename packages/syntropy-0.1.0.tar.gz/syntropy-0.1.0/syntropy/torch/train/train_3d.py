"""PyTorch 3D training placeholder."""

from __future__ import annotations


def train(*args, **kwargs):
    raise NotImplementedError("PyTorch training utilities are not yet implemented.")
