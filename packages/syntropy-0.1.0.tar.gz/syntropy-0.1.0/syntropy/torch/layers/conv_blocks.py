"""PyTorch convolutional blocks for future Efficient Axial Networks."""

from __future__ import annotations


def efficient_2d_convblock(*args, **kwargs):
    raise NotImplementedError("PyTorch efficient_2d_convblock will land in a future release.")


def efficient_3d_convblock(*args, **kwargs):
    raise NotImplementedError("PyTorch efficient_3d_convblock will land in a future release.")
