"""PyTorch EffAxNet 2D placeholder."""

from __future__ import annotations


def build_model(*args, **kwargs):
    raise NotImplementedError("PyTorch EffAxNet 2D is not yet implemented.")
