"""PyTorch EffAxNet 3D placeholder."""

from __future__ import annotations


def build_model(*args, **kwargs):
    raise NotImplementedError("PyTorch EffAxNet 3D is not yet implemented.")
