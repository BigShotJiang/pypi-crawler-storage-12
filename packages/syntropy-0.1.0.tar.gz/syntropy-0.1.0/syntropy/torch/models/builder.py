"""PyTorch model builder placeholders."""

from __future__ import annotations


def build_from_config(*args, **kwargs):
    raise NotImplementedError("PyTorch model builder is not yet implemented.")
