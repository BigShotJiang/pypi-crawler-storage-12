"""Top-level package for the Syntropy library."""

from .version import __version__

__all__ = ["__version__"]
