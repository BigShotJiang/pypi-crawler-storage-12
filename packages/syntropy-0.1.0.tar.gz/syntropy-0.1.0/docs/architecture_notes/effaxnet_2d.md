# EffAxNet 2D Architecture Notes

This document tracks design decisions and future ideas for the 2D Efficient Axial Network.
