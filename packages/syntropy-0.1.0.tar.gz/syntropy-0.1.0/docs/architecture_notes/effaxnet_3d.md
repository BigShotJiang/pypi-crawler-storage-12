# EffAxNet 3D Architecture Notes

Notes describing the volumetric variant of Efficient Axial Networks.
