# Design Principles

Shared architectural principles guiding the development of Syntropy models.
