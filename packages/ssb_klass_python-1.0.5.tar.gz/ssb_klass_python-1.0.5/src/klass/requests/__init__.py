"""The requests module does the direct requests to the KLASS API.

The classes in the classes-module builds calls these, and builds from these.
The requests call the functions in validate, which are used to validate the parameters being sent to the api.
"""
