LANGUAGES: list[str] = ["nb", "nn", "en"]
BASE_URL: str = "https://data.ssb.no/api/klass/v1/"
HEADERS: dict[str, str] = {
    "Accept": "application/json",
}
TESTING: bool = False
