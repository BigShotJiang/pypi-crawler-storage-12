To use this module, you need to:

1. Grant your user access to Journal Entries Lines: Go to "Settings / Users & Companies / Groups", search the "Technical / Show Full Accounting Features" group, and add your user to it.
2. Go to "Invoicing / Customers / Invoices". Select an invoice and go to its formulary view. Select the "Journal Items" tab, you should be able to see the "Due Date" column. 
