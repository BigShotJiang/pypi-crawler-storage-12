"""
Author Michael Rapp (michael.rapp.ml@gmail.com)

Provides classes that allow to write algorithmic parameters to different sinks.
"""
from mlrl.testbed.experiments.output.parameters.writer import ParameterWriter
