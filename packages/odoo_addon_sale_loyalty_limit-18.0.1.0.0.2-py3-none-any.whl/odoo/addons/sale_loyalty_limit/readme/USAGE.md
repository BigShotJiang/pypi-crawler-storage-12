Once the program limits are configured, apply the programs as usual in
your sale orders.

Once the limit for a customer or a salesman is reached, if we try to
apply a promotion:

- A code promotion will raise an error.
- A program with no code won't be applied.
- A coupon belonging to a limited program will raise an error.
- A promotion applied on the next order won't generate the coupon.
