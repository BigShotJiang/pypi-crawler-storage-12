This module allows to configure a limit on the times a promotion can be
applied. Two limits can be configured: customer and salesman. Those
limits apply to either programs or coupons.
