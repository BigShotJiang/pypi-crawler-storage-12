from . import test_sale_loyalty_limit
