"""
Interactive reflectometry profile editor
"""
