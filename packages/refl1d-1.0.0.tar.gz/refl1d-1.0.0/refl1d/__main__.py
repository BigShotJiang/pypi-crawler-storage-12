"""
Refl1D application.

Run "refl1d --help" for details, or "python -m refl1d -help" if
refl1d isn't on your path.
"""

from refl1d.webview.server.cli import main

if __name__ == "__main__":
    main()
