# Colorblind-friendly colors, as per https://gist.github.com/thriveth/8560036
COLORS = ["#377eb8", "#ff7f00", "#4daf4a", "#f781bf", "#a65628", "#984ea3", "#999999", "#e41a1c", "#dede00"]
