from ...read_write_utils import read_from_file,write_to_file,get_text_or_read
from ...string_utils import eatAll,eatInner,eatElse,clean_line
from ...class_utils import get_caller_path
from ...list_utils import make_list
from ...path_utils import get_file_parts
from ...type_utils  import is_number,make_list
