__application_name__ = "awsimple"
__title__ = __application_name__
__author__ = "abel"
__version__ = "7.1.0"
__author_email__ = "j@abel.co"
__url__ = "https://github.com/jamesabel/awsimple"
__download_url__ = "https://github.com/jamesabel/awsimple"
__description__ = "Simple AWS API for S3, DynamoDB, SNS, and SQS"
