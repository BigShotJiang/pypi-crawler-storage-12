API_URL = "https://superstaq.infleqtion.com"
API_VERSION = "v0.2.0"
API_URL_V3 = "https://superstaq-prod.infleqtion.com"
