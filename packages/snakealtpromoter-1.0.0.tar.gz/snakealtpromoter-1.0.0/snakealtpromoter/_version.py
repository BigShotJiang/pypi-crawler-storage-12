"""
SnakeAltPromoter: End-to-End Differential Alternative Promoter Analysis.
"""

__version__ = "1.0.0"
