from pixelarraythirdparty.client import AsyncClient
from typing import Dict, Any, Optional, List, Tuple, Callable, Union
import os
import asyncio
import aiohttp
import mimetypes


class FileStorageManagerAsync(AsyncClient):
    async def upload(
        self, file_path: str, parent_id: Optional[int] = None
    ) -> Tuple[bool, Dict[str, Any]]:
        """
        description:
            上传文件（合并了初始化、分片上传、完成上传三个步骤）
        parameters:
            file_path: 文件路径（str）
            parent_id: 父文件夹ID（可选）
        return:
            - data: 结果数据
            - success: 是否成功
        """
        # 读取文件数据
        with open(file_path, "rb") as f:
            file_bytes = f.read()

        total_size = len(file_bytes)
        chunk_size = 2 * 1024 * 1024  # 2MB

        # 1. 初始化上传
        file_name = os.path.basename(file_path)
        mime_type = mimetypes.guess_type(file_path)[0]
        init_data = {
            "filename": file_name,
            "file_type": mime_type,
            "total_size": total_size,
        }
        if parent_id is not None:
            init_data["parent_id"] = parent_id

        init_result, success = await self._request(
            "POST", "/api/file_storage/upload/init", json=init_data
        )
        if not success:
            return {}, False

        upload_id = init_result.get("upload_id")
        chunk_urls = init_result.get("chunk_urls", [])
        total_chunks = len(chunk_urls)

        if not upload_id or not chunk_urls:
            return {}, False

        # 2. 上传所有分片
        parts = []

        async def upload_single_chunk(chunk_index: int, chunk_data: bytes):
            """上传单个分片"""
            chunk_info = chunk_urls[chunk_index]
            part_number = chunk_info.get("part_number")
            url = chunk_info.get("url")

            if not url or not part_number:
                return None

            # 使用预签名URL直接上传到OSS（PUT请求）
            async with aiohttp.ClientSession() as session:
                async with session.put(url, data=chunk_data) as resp:
                    if resp.status == 200:
                        etag = resp.headers.get("ETag", "").strip('"')
                        return {
                            "part_number": part_number,
                            "etag": etag,
                            "chunk_index": chunk_index,
                        }
            return None

        # 并发上传所有分片
        tasks = []
        for i in range(total_chunks):
            start = i * chunk_size
            end = min(start + chunk_size, total_size)
            chunk_data = file_bytes[start:end]
            tasks.append(upload_single_chunk(i, chunk_data))

        # 等待所有分片上传完成，并收集结果
        results = await asyncio.gather(*tasks)

        # 检查上传结果并更新进度
        # 按chunk_index排序，确保parts顺序正确
        sorted_results = sorted(
            [r for r in results if r is not None], key=lambda x: x.get("chunk_index", 0)
        )

        if len(sorted_results) != total_chunks:
            return {}, False

        for i, result in enumerate(sorted_results):
            parts.append({"part_number": result["part_number"], "etag": result["etag"]})

        # 3. 完成上传
        complete_data = {
            "upload_id": upload_id,
            "parts": parts,
        }
        complete_result, success = await self._request(
            "POST", "/api/file_storage/upload/complete", json=complete_data
        )
        if not success:
            return {}, False

        return complete_result, True

    async def list_files(
        self,
        parent_id: Optional[int] = None,
        is_folder: Optional[bool] = None,
        page: int = 1,
        page_size: int = 50,
    ) -> Tuple[List[Dict[str, Any]], bool]:
        """
        description:
            获取文件列表
        parameters:
            parent_id: 父文件夹ID（可选）
            is_folder: 是否只查询文件夹（可选）
            page: 页码（可选）
            page_size: 每页数量（可选）
        return:
            - data: 文件列表数据
            - success: 是否成功
        """
        data = {
            "page": page,
            "page_size": page_size,
        }
        if parent_id is not None:
            data["parent_id"] = parent_id
        if is_folder is not None:
            data["is_folder"] = is_folder

        result, success = await self._request(
            "POST", "/api/file_storage/files/list", json=data
        )
        if not success:
            return {}, False
        return result, True

    async def create_folder(
        self,
        folder_name: str,
        parent_id: Optional[int] = None,
    ) -> Tuple[Dict[str, Any], bool]:
        """
        description:
            创建文件夹
        parameters:
            folder_name: 文件夹名称
            parent_id: 父文件夹ID（可选）
        return:
            - data: 文件夹数据
            - success: 是否成功
        """
        data = {
            "folder_name": folder_name,
        }
        if parent_id is not None:
            data["parent_id"] = parent_id

        data, success = await self._request(
            "POST", "/api/file_storage/files/folder/create", json=data
        )
        if not success:
            return {}, False
        return data, True

    async def delete_file(
        self,
        record_id: int,
    ) -> Tuple[Dict[str, Any], bool]:
        """
        description:
            删除文件或文件夹
        parameters:
            record_id: 文件或文件夹ID
        return:
            - data: 结果数据
            - success: 是否成功
        """
        data, success = await self._request(
            "DELETE", f"/api/file_storage/files/{record_id}"
        )
        if not success:
            return {}, False
        return data, True

    async def get_folder_path(
        self,
        record_id: int,
    ) -> Tuple[List[Dict[str, Any]], bool]:
        """
        description:
            获取文件夹的完整路径
        parameters:
            record_id: 文件夹ID
        return:
            - data: 文件夹路径列表
            - success: 是否成功
        """
        data, success = await self._request(
            "GET", f"/api/file_storage/files/{record_id}/path"
        )
        if not success:
            return [], False
        # 如果data是字典，尝试获取data字段（因为API返回的是{"data": [...]}）
        if isinstance(data, dict):
            path_list = data.get("data", [])
            if isinstance(path_list, list):
                return path_list, True
        # 如果data本身就是列表，直接返回
        if isinstance(data, list):
            return data, True
        return [], False

    async def generate_signed_url(
        self,
        record_id: int,
        expires: int = 3600,
    ) -> Tuple[Dict[str, Any], bool]:
        """
        生成签名URL（异步版本）
        """
        data = {
            "expires": expires,
        }
        data, success = await self._request(
            "POST", f"/api/file_storage/files/{record_id}/generate_url", json=data
        )
        if not success:
            return {}, False
        return data, True

    async def download(
        self,
        record_id: int,
        save_path: str,
    ) -> Tuple[Dict[str, Any], bool]:
        """
        description:
            下载文件
        parameters:
            record_id: 文件记录ID
            save_path: 保存路径
        return:
            - data: 下载结果数据
            - success: 是否成功
        """
        # 1. 生成签名URL
        signed_url_data, success = await self.generate_signed_url(record_id)
        if not success:
            return {}, False

        signed_url = signed_url_data.get("signed_url")
        file_record = signed_url_data.get("file_record", {})
        total_size = file_record.get("file_size", 0)

        if not signed_url:
            return {}, False

        # 2. 下载文件
        async with aiohttp.ClientSession() as session:
            async with session.get(signed_url) as resp:
                if resp.status != 200:
                    return {}, False

                file_data = b""
                downloaded = 0

                async for chunk in resp.content.iter_chunked(8192):  # 8KB chunks
                    file_data += chunk
                    downloaded += len(chunk)

                with open(save_path, "wb") as f:
                    f.write(file_data)

                return {"total_size": total_size, "success": True}, True
