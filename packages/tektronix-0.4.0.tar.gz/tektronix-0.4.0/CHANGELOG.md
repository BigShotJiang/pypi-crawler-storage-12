# CHANGELOG.md

This file contains all notable changes to the [tektronix][] project.

## Unreleased

## v0.4.0 - 11-Nov-25

- Updated code to handle `EMC-EMI 1` in the first row of the CSV file.

## v0.3.1 - 04-Dec-24

- Switched to hatch for build and deployment.
- Updated package requirements.

## v0.2.0 - 20-Nov-24

- Added code and test for ver 1 of the RSA500 CSV file format.

## v0.1.0 - 30-Oct-23

- Initial release for RSA500

[tektronix]: https://github.com/questrail/tektronix
