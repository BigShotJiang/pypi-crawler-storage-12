# -*- coding: utf-8 -*-
# Copyright (c) 2013-2024 The tektronix developers. All rights reserved.
# Project site: https://github.com/questrail/tektronix
# Use of this source code is governed by a MIT-style license that
# can be found in the LICENSE.txt file for the project.
"""Package initialization."""
