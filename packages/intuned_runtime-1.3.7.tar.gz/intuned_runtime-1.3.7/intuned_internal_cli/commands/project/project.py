from intuned_internal_cli.utils.wrapper import internal_cli_command


@internal_cli_command
def project():
    """
    Commands to run on automation projects.
    """

    pass
