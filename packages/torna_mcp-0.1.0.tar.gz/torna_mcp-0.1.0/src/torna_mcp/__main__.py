#!/usr/bin/env python3
"""Main entry point for the torna-mcp package."""

from torna_mcp.main import main

if __name__ == "__main__":
    main()
