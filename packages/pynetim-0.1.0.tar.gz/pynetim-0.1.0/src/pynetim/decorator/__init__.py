from .decorator import Timer

__all__ = [
    'Timer'
]
