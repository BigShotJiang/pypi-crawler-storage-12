"""
MCP Prompts module for Knowledge Base Assistant
"""

from .mcp_prompts import mcp

__all__ = ["mcp"]
