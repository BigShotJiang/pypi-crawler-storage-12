# $Id: __init__.py,v 1.1.1.1 2024/02/02 07:06:20 shanshi Exp $

"""gnuplot python wrapper."""

__author__ = 'Yongping Guo <guoyoooping@163.com>'
__copyright__ = 'Copyright (c) 2020 Yongping guo'
__license__ = 'GPL'
__url__ = 'http://www.gnuplot.info'
__version__ = '0.1'

#from gnuplotpy import *
#import gnuplotpy
__all__ = ['gnuplot', 'pyplot'] 
