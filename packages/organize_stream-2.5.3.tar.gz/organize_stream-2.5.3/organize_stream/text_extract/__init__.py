from .text_extract import DocumentTextExtract

__all__ = ["DocumentTextExtract"]
