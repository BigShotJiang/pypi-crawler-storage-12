class Flag:
    def __init__(self):
        raise NotImplementedError


class Terminate(Flag):
    pass
