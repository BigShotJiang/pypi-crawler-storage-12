"""Deployment package for Kubernetes HTTP server."""
