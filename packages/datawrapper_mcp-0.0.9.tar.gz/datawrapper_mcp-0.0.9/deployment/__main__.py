"""Entry point for running deployment HTTP server as a module."""

if __name__ == "__main__":
    # Import and run the app module
    pass
