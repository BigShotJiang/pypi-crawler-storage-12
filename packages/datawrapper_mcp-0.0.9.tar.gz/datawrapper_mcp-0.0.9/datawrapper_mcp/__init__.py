"""A Model Context Protocol server for creating Datawrapper charts."""
