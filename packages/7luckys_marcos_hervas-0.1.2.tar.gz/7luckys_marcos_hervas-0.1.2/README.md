Proyecto que se basa en el 7 de la suerte, tienes 7 intervalos de apuestas, menor que 7,mayor e igual.
Tienes un saldo inicial de 100, y sales cuando quieras o te quedas con saldo 0.
La manera de utilizarlo es lanzar el main para que funcione todo el programa haciendo las llamadas a otras funciones.
Tiene varias funciones: 
-Main: es el que ejecuta todo el juego.
-Apuestas: Te dice que intervalo de apuesta quieres seleccionar.
-Apostar: Cuanto dinero quieres apostar.
-TirarDados: Tira los dados y ve el total.
-Resultado: Mira si has ganado o no.
-CalcularSaldo: Calcula el saldo a partir de lo apostado y el multiplicador.