"""Utilities for web dashboard."""

from prompt_versioner.web.utils.diff_utils import create_inline_diff

__all__ = ["create_inline_diff"]
