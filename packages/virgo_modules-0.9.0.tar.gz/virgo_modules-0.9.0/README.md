# Virgo-modules

this repo contains the code of the package virgo-modules that is used ion the virgo project

### Built with

python version: 3.9.*

the libraries:

* research
   + statistical analysis and modeling:
   + scikit learn
   + hmmlearn
   + Optuna
   + statsmodels
* visualization
   + plotly
   + matplotlib
   + seaborn
