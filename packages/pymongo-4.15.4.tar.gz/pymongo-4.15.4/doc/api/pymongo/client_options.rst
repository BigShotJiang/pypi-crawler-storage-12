:mod:`client_options` -- Read only configuration options for a MongoClient.
===========================================================================

.. automodule:: pymongo.client_options

   .. autoclass:: pymongo.client_options.ClientOptions()
      :members:
