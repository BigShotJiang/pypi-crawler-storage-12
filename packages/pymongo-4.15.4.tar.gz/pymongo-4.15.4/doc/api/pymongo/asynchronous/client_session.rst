:mod:`client_session` -- Logical sessions for sequential operations
===================================================================


.. automodule:: pymongo.asynchronous.client_session
   :members:
