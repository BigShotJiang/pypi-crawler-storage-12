:orphan:

:mod:`server_description` -- An object representation of a server the driver is connected to.
=============================================================================================

.. automodule:: pymongo.server_description

   .. autoclass:: pymongo.server_description.ServerDescription()
      :members:
