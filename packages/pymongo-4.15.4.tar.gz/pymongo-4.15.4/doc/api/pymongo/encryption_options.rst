:mod:`encryption_options` -- Automatic Client-Side Field Level Encryption
=========================================================================

.. automodule:: pymongo.encryption_options
   :synopsis: Support for automatic client-side field level encryption
   :members:
