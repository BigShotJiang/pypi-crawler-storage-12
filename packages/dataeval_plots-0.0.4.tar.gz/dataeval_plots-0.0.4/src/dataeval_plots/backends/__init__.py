"""Plotting backends for DataEval outputs."""

from __future__ import annotations

__all__ = ["PlottingBackend"]

from dataeval_plots.backends._base import PlottingBackend
