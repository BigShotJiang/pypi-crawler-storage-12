from typing import Any

import pulse as ps


@ps.react_component("ColorSwatch", "@mantine/core")
def ColorSwatch(*children: ps.Child, key: str | None = None, **props: Any): ...
