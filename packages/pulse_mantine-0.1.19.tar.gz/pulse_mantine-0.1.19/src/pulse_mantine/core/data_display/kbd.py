from typing import Any

import pulse as ps


@ps.react_component("Kbd", "@mantine/core")
def Kbd(*children: ps.Child, key: str | None = None, **props: Any): ...
