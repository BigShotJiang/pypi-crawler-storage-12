from typing import Any

import pulse as ps


@ps.react_component("Anchor", "@mantine/core")
def Anchor(*children: ps.Child, key: str | None = None, **props: Any): ...
