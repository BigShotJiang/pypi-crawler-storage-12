from typing import Any

import pulse as ps


@ps.react_component("Textarea", "pulse-mantine")
def Textarea(*children: ps.Child, key: str | None = None, **props: Any): ...
