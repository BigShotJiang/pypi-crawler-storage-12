from typing import Any

import pulse as ps


@ps.react_component("AngleSlider", "pulse-mantine")
def AngleSlider(key: str | None = None, **props: Any): ...
