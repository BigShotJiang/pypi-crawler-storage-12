from typing import Any

import pulse as ps


@ps.react_component("CloseButton", "@mantine/core")
def CloseButton(key: str | None = None, **props: Any): ...
