from typing import Any

import pulse as ps


@ps.react_component("DatePickerInput", "pulse-mantine")
def DatePickerInput(key: str | None = None, **props: Any): ...
