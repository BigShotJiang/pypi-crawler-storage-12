from typing import Any

import pulse as ps


@ps.react_component("LevelsGroup", "pulse-mantine")
def LevelsGroup(key: str | None = None, **props: Any): ...
