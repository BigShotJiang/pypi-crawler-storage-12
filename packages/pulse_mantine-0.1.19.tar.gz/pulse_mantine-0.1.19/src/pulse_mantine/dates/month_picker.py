from typing import Any

import pulse as ps


@ps.react_component("MonthPicker", "pulse-mantine")
def MonthPicker(key: str | None = None, **props: Any): ...
