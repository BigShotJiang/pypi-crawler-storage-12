from typing import Any

import pulse as ps


@ps.react_component("HiddenDatesInput", "pulse-mantine")
def HiddenDatesInput(key: str | None = None, **props: Any): ...
