from typing import Any

import pulse as ps


@ps.react_component("DecadeLevel", "pulse-mantine")
def DecadeLevel(key: str | None = None, **props: Any): ...
