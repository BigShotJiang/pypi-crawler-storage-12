from typing import Any

import pulse as ps


@ps.react_component("MiniCalendar", "pulse-mantine")
def MiniCalendar(key: str | None = None, **props: Any): ...
