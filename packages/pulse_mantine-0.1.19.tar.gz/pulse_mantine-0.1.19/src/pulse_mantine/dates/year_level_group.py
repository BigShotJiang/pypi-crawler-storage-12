from typing import Any

import pulse as ps


@ps.react_component("YearLevelGroup", "pulse-mantine")
def YearLevelGroup(key: str | None = None, **props: Any): ...
