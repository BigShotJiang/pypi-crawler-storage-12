from typing import Any

import pulse as ps


@ps.react_component("TimePicker", "pulse-mantine")
def TimePicker(key: str | None = None, **props: Any): ...
