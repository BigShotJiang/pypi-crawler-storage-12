# pythonbible-bwe

The Bible in WorldWide English NT (BWE) version of the Bible in Python. For use with the `pythonbible` library.
