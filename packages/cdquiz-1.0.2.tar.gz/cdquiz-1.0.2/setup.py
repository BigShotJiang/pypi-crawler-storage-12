from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of your README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="cdquiz",  # updated, unique multi-domain package name
    version="1.0.2",
    author="Applinet Technology (Godswill Moses Ikpotokin)",
    author_email="developers@applinet.com.ng",
    description="CodeHouse Quiz Suite — Practice and Learn Python, HTML, AI, Machine Learning, Data Science, and Cybersecurity directly from your terminal.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/applinet-technology/codehouse_quiz_suite",
    project_urls={
        "Homepage": "https://cli.codehouse.cloud",
        "Start Learning": "https://codehouse.cloud/technology/courses",
        "Go to Classroom": "https://classroom.codehouse.cloud",
        "CodeHouse Cloud": "https://codehouse.cloud",
        "Applinet Technology": "https://applinet.com.ng",
        "Source": "https://github.com/applinet-technology/codehouse_quiz_suite",
        "Issues": "https://github.com/applinet-technology/codehouse_quiz_suite/issues",
    },
    license="MIT",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "requests>=2.31.0",
        "rich>=13.7.0",
        "rapidfuzz>=3.6.0",
        "click>=8.1.7",
        "python-dateutil>=2.9.0",
        "tinydb>=4.8.0",
        "python-dotenv>=1.0.1",
    ],
    entry_points={
        "console_scripts": [
            "cdquiz-start=cdquiz.start:main",  # renamed CLI command for multi-domain usage
        ],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Education",
        "Topic :: Education",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.8",
)
