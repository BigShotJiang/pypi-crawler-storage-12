# 🧠 CODEHOUSE QUIZ SUITE

**CodeHouse Cloud Quiz & Training CLI Package**

---

## Overview
`cdquiz` is a **multi-domain Python CLI package** that connects learners to interactive training quizzes, coding challenges, and AI-powered learning simulations across **Python**, **HTML**, **AI**, **Machine Learning**, **Data Science**, and **Cybersecurity**.

It is part of the **CodeHouse Cloud Learning Suite**, created by **Applinet Technology** — an African-centered technology company that merges traditional African values with modern innovation — and **CodeHouse Cloud**, an initiative empowering African learners through technology and digital education.

This CLI tool transforms your terminal into an engaging classroom where you can test your knowledge, track progress, and learn by doing.

---

## Features

- 🎯 Interactive quizzes across multiple fields
- 🤖 AI-powered explanations and feedback
- 🧩 Smart scoring and progress tracking
- ⚡ Lightweight and fast — zero heavy dependencies

---

## Example Usage

### 1️⃣ Installation
Install from PyPI:

```bash
pip install cdquiz
```

---

### 🚀 Start a Session

```bash
python -m cdquiz.start
```

or simply:

```bash
python cdquiz.start
```

---

### Example Output

```bash
Welcome to CodeHouse Cloud Training Quiz!

Choose a category:
1) Python
2) HTML
3) Artificial Intelligence
4) Machine Learning
5) Data Science
6) Cybersecurity

Your Choice: 1

Loading Python questions...
Question 1: What does Applinet stands for?
A) Application Network
B) Africa Nation
C) AfroNet

Your Answer: B
✅ Correct! Great job.
```

---

## Requirements

- Python 3.8 or higher
- Internet connection (for live mode)

---

## Developer Notes

To build from source:

```bash
git clone https://github.com/applinet-technology/cdquiz.git
cd codehouse_quiz_suite
pip install -e .
```

---

## License

This project is licensed under the **MIT License**.
See [LICENSE](LICENSE) for details.

---

## Training and Community

- **CodeHouse Cloud Learning Platform** — African Coding & AI Initiative  
🌍 [View Quiz Leaderboard](https://cli.codehouse.cloud)  
🌍 [Go To Classroom](https://classroom.codehouse.cloud)  
🌍 [Explore All Courses](https://codehouse.cloud/technology/courses)

---

## Author

- **CodeHouse Cloud** — African Coding Initiative  
🌍 [https://codehouse.cloud](https://codehouse.cloud)  
📧 genius@codehouse.cloud  
🌍 [Join Genius Community](https://genius.codehouse.cloud/)  
🌍 [Join WhatsApp Group](https://chat.whatsapp.com/BYfgMwPZBpCEwr3piT77iE)

- **Applinet Technology**  
🌍 [https://applinet.com.ng](https://applinet.com.ng)  
📧 developers@applinet.com.ng  
🌍 [Join Applinet Technology WhatsApp Community](https://whatsapp.com/channel/0029VaBkX0Q96H4ZCYhgXF0a)  
🌍 [Follow us on LinkedIn](https://www.linkedin.com/company/applinet-technology)

---

## 💡 Credits

- **Godswill Moses Ikpotokin** — CEO, Applinet Technology & CodeHouse Cloud  
📧 godswill@ikpotokin.ng  
🌍 [https://ikpotokin.ng](https://ikpotokin.ng)
