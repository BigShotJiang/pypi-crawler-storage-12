import macrocosmos

print(macrocosmos.__version__)
