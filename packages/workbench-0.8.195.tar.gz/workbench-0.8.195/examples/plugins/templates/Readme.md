# Templates
These are **Plotly Templates**, the json blobs that you use when you want to customize your ploty figures.