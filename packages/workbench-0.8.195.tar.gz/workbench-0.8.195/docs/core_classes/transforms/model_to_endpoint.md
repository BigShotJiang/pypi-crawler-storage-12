# Model to Endpoint
!!! tip inline end "API Classes"
    For most users the [API Classes](../../api_classes/overview.md) will provide all the general functionality to create a full AWS ML Pipeline

::: workbench.core.transforms.model_to_endpoint.model_to_endpoint
