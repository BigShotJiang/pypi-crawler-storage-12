"""tinyjam - Jam to NPR Tiny Desk concerts."""

from __future__ import annotations

from .cli import main

__all__ = ["main", "__version__"]
__version__ = "1.0.0"
