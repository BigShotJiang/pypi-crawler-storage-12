"""CLI tool for Code Audit Companion."""

