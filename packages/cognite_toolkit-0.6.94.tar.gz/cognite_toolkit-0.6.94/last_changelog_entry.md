## cdf 

### Improved

- [alpha] The `cdf data upload` command has improved the asset hierarchy
upload. It now separates each level in the hierarchy by request.

## templates

No changes.