from pathlib import Path

_THIS_FOLDER = Path(__file__).resolve().parent
BUILD_DIR = _THIS_FOLDER / "tmp"
SNAPSHOTS_DIR_ALL = _THIS_FOLDER / "snapshots"
