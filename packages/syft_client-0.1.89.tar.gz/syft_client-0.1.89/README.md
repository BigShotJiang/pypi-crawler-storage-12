# Syft-client

## Install

```
uv pip install -e .
```

## Test

```
just test-unit
just test-integration
```
