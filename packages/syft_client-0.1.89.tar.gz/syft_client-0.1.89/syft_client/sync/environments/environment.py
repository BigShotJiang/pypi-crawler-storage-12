from enum import Enum


class Environment(Enum):
    COLAB = "colab"
    JUPYTER = "jupyter"
    REPL = "repl"
