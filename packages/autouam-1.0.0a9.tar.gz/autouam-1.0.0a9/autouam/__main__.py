"""Main module for AutoUAM."""

from .cli.commands import main

if __name__ == "__main__":
    main()
