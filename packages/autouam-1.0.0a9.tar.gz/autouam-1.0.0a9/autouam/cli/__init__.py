"""Command line interface for AutoUAM."""

from .commands import main

__all__ = ["main"]
