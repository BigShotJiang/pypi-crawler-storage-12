Data taken on April, 8, 2025 with Julia's laptop.

Flag width = 19.75 +/- 0.05 mm

At the end of the acquisition the piece of wood was misaligned.

Also, the transit times are all wrong, but the data were acquired with an old
version of the software, since Julia was on a tagged version of the main branch,
while I was working on a different branch.
