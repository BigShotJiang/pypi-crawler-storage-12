Data taken on april 8, 2025.

Long acquisition on table 2.

Flag width = 19.30 +/- 0.05 mm
