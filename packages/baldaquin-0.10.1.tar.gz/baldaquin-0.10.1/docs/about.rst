.. _about:

About baldaquin
===============

As it turns out, there is one and only one word in English containing
"daq"---*baldaquin*, which is apparently a less common form for *baldachin*.
Now, baldaquins are regal and glamorous. Also: baldaquin ends with "uin", that
can in turn be used to abbreviate "User INterface" (I know: it would have been
so much cooler is the final "n" was not there, but so goes life). Finally,
"bald" can be taken to mean *with no effort to conceal*, which is aligned with
the idea of an open-source project.
