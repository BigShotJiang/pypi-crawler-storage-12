"""Textual Reflector Widget."""

from .reflect import Reflector

__version__ = "0.1.7"
