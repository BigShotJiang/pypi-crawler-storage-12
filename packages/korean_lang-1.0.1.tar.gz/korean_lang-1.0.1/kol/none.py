
class NoneObject:
    pass

