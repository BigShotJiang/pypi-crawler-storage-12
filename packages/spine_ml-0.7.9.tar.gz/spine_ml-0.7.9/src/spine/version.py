"""Module which stores the current software version."""

__version__ = "0.7.9"
