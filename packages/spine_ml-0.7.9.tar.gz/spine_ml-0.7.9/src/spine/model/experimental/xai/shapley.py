def mc_shapley():
    pass
