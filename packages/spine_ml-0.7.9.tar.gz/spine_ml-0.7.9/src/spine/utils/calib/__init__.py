"""General calibration module."""

from .manager import CalibrationManager
