"""Optical module."""

from .flash_matching import *
