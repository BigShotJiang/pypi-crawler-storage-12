# JupyterLite AI Demo

This is a demo for showcasing [JupyterLite AI](https://github.com/jupyterlite/ai).
