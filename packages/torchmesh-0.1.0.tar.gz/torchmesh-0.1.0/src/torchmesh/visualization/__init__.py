"""Visualization utilities for torchmesh Mesh objects."""

from torchmesh.visualization.draw_mesh import draw_mesh

__all__ = ["draw_mesh"]
