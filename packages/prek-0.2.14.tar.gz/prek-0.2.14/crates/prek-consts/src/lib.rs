pub mod env_vars;

pub const CONFIG_FILE: &str = ".pre-commit-config.yaml";
pub const ALT_CONFIG_FILE: &str = ".pre-commit-config.yml";
pub const MANIFEST_FILE: &str = ".pre-commit-hooks.yaml";
