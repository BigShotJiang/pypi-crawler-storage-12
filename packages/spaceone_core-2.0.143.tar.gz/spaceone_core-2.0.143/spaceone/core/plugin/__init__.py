from spaceone.core.plugin.server import serve

__all__ = ['serve']
