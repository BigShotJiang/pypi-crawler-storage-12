# run.py
import bhavani

def main():
    name = "Praneeth"
    print(bhavani.greet(name))

if __name__ == "__main__":
    main()
