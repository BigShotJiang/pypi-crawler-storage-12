### Execution
Execute via terminal for secure processing of password input.
`python3 main.py`