"""
This file only exists to allow::

    python -m bpt [args...]

to work properly. The application entrypoints are defined in `bpt.main`
"""

from bpt.main import start

start()
