# `bpt` -- A Zero-Configuration Build+Package Tool

This package contains a Python implementation of [bpt](https://bpt.pizza).
