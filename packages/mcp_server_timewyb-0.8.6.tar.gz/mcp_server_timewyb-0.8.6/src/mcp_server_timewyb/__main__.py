from mcp_server_timewyb import main

main()
