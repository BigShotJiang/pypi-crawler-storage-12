This module should be installed before any other accounting related
module. Otherwise Odoo will install the module l10n_us in the current
company, by default.
