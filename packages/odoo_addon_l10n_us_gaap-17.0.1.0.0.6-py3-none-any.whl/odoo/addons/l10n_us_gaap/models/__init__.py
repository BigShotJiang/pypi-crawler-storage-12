from . import template_us_gaap
