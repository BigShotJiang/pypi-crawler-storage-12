from .smooth_upsampling import SmoothUpSampling1D, SmoothUpSampling2D, SmoothUpSampling3D
from .fft_upsampling import FFTUpSampling1D, FFTUpSampling2D, FFTUpSampling3D