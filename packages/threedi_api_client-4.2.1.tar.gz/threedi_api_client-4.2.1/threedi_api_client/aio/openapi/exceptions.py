# coding: utf-8

"""Import from the sync OpenAPI client to make all exceptions the same."""

from threedi_api_client.openapi.exceptions import *
