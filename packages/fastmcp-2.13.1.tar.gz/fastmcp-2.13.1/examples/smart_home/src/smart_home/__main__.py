from smart_home.hub import hub_mcp


def main():
    hub_mcp.run()


if __name__ == "__main__":
    main()
