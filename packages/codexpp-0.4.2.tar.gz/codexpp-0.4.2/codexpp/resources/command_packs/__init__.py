"""Built-in command packs shipped with Codexpp."""

