def main():
    """
    Entry point for the dhruv13x meta-suite.
    Currently empty — routing will be added in later phases.
    """
    print("dhruv13x package installed successfully (v0.0.1).")
    
def app():
    print("dhruv13x meta suite installed successfully!")