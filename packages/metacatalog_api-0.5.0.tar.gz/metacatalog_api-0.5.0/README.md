# metacatalog-api
FastAPI backend for managing a Metacatalog instance

More info to come
