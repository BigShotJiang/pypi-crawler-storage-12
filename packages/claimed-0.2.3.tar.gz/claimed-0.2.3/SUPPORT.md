


# Support

For support, please contact us on the [CLAIMED workspace](https://matrix.to/#/!HxmUqvBKioTlNGyZGJ:matrix.org?via=matrix.org) on Matrix.org, please use the [Issue Tracker](https://github.com/claimed-framework/component-library/issues)
if you feel that you've found a defect or want to propose a new feature.
