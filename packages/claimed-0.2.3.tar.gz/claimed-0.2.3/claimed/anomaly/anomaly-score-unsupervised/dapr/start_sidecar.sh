#!/bin/bash
dapr run --app-id anomalydetection --dapr-http-port 3601