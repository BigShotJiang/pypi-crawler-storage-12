# VULNERABILITIES reporting process

Vulnerabilities can be reported on the GitHub Issue Tracker but reporting them on a secure and private channel is preferred. 

The current way of reporting private vulnerabilities is using https://encrypt.to/romeokienzler.

We are working on a more generic channel and update this information accordingly
