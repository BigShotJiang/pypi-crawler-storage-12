---
description: 'When called from workflow'
---

# Advanced Elicitation

LOAD and execute the task at: .bmad/core/tasks/adv-elicit.xml

Follow all instructions in the task file exactly as written.
