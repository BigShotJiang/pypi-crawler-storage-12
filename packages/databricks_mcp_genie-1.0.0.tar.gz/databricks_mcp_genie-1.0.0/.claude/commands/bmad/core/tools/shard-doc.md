---
description: 'Splits large markdown documents into smaller, organized files based on level 2 (default) sections'
---

# Shard Document

LOAD and execute the tool at: .bmad/core/tools/shard-doc.xml

Follow all instructions in the tool file exactly as written.
