Once the surveys are submited a lead/opportunity (depending on the
default options for the company) will be generated with a link to the
answers.
