To configure the leads/opportunities generation:

1.  Go to the configured survey.
2.  In the *CRM* section of the *Options* tab, set *Generate leads* on.
3.  Optionally you can set default tags for the generated leads.
4.  You can set the crm team to assign the leads to.

The questions marked to be shown in the lead description will be shown
there.

If you want to fill crm.lead fields from the answers set the *CRM Lead
field* you want to fill with the given answer.
