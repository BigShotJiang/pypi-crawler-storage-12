This module allows to generate leads/opportunities from surveys.
