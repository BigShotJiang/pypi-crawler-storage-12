# AI engine package (OpenAI + Instructor)
