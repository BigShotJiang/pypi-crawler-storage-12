from .config import AiConfig

__all__ = ["AiConfig"]
