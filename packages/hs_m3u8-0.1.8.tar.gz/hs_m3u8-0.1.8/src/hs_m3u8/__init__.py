from hs_m3u8.main import M3u8Downloader, M3u8Key

__version__ = "0.1.6"
