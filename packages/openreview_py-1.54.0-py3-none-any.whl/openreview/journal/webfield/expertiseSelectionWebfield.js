// Webfield component
return {
    component: 'ExpertiseConsole',
    properties: {
      venueId: 'VENUE_ID',
      apiVersion: 2
    }
  }