# fps-file-watcher

An FPS plugin for the file watcher API.
