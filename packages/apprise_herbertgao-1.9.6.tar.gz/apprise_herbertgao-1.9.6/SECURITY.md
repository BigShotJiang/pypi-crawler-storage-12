# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.9.x   | :white_check_mark: |
| < 0.9.x | :x:                |

## Reporting a Vulnerability

If you find a vunerability, please notify me at lead2gold@gmail.com. If the vunerability
is severe then please just open a ticket at https://github.com/caronc/apprise/issues
