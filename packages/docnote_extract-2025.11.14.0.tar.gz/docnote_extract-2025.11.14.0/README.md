See [here](/README.clc) for more.

TODO: auto-generate this from distilled cleancopy.
