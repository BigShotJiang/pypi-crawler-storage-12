weaviate.collections.aggregations
=================================

.. automodule:: weaviate.collections.aggregations
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.aggregations.aggregate
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.aggregations.aggregate
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.aggregations.hybrid
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.aggregations.hybrid
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.aggregations.near\_image
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.aggregations.near_image
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.aggregations.near\_object
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.aggregations.near_object
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.aggregations.near\_text
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.aggregations.near_text
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.aggregations.near\_vector
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.aggregations.near_vector
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.aggregations.over\_all
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.aggregations.over_all
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
