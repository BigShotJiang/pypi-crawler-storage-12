weaviate.gql
============

.. automodule:: weaviate.gql
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.gql.aggregate
^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.gql.aggregate
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.gql.filter
^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.gql.filter
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
