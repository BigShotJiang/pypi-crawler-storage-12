"""Arneso Pypitemplate Instance."""
