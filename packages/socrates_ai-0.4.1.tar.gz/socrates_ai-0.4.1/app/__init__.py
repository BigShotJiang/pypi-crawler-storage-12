"""
Socrates Application Package
Phase 1: Infrastructure Foundation
"""

__version__ = "0.1.0"
