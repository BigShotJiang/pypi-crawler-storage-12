
wn.lmf
======

.. automodule:: wn.lmf

.. autofunction:: load
.. autofunction:: scan_lexicons
.. autofunction:: is_lmf

