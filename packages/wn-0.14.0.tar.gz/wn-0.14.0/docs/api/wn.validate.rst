
wn.validate
===========

.. automodule:: wn.validate

.. autofunction:: validate
