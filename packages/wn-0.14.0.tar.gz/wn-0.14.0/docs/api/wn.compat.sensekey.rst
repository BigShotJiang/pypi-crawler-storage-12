wn.compat.sensekey
==================

.. automodule:: wn.compat.sensekey

.. autofunction:: escape
.. autofunction:: unescape
.. autofunction:: sense_key_getter
.. autofunction:: sense_getter
