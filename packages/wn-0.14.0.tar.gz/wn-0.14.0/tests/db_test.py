
import sqlite3
import threading
import tempfile

import pytest

import wn
from wn import lmf


@pytest.mark.usefixtures('mini_db')
def test_schema_compatibility():
    conn = sqlite3.connect(str(wn.config.database_path))
    schema_hash = wn._db.schema_hash(conn)
    assert schema_hash in wn._db.COMPATIBLE_SCHEMA_HASHES


@pytest.mark.usefixtures('mini_db')
def test_db_multithreading():
    """
    See https://github.com/goodmami/wn/issues/86
    Thanks: @fushinari
    """

    class WNThread:
        w = None

        def __init__(self):
            w_thread = threading.Thread(target=self.set_w)
            w_thread.start()
            w_thread.join()
            self.w.synsets()

        def set_w(self):
            if self.w is None:
                self.w = wn.Wordnet()

    # close the connections by resetting the pool
    wn._db.pool = {}
    with pytest.raises(sqlite3.ProgrammingError):
        WNThread()
    wn._db.pool = {}
    wn.config.allow_multithreading = True
    WNThread()  # no error
    wn.config.allow_multithreading = False
    wn._db.pool = {}


def test_remove_extension(datadir):
    with tempfile.TemporaryDirectory('wn_data_1_1_trigger') as dir:
        old_data_dir = wn.config.data_directory
        wn.config.data_directory = dir
        wn.add(datadir / 'mini-lmf-1.0.xml')
        wn.add(datadir / 'mini-lmf-1.1.xml')
        assert len(wn.lexicons()) == 4
        wn.remove('test-en-ext')
        assert len(wn.lexicons()) == 3
        wn.remove('test-ja')
        assert len(wn.lexicons()) == 2
        wn.add(datadir / 'mini-lmf-1.1.xml')
        assert len(wn.lexicons()) == 4
        wn.remove('test-en')
        assert {lex.id for lex in wn.lexicons()} == {'test-es', 'test-ja'}
        wn.config.data_directory = old_data_dir
        # close any open DB connections before teardown
        for conn in wn._db.pool.values():
            conn.close()


def test_add_lexical_resource(datadir):
    with tempfile.TemporaryDirectory('wn_data_add_lexical_resource') as dir:
        old_data_dir = wn.config.data_directory
        wn.config.data_directory = dir
        wn.add_lexical_resource(lmf.load(datadir / 'mini-lmf-1.0.xml'))
        assert len(wn.lexicons()) == 2
        wn.add_lexical_resource(lmf.load(datadir / 'mini-lmf-1.1.xml'))
        assert len(wn.lexicons()) == 4
        wn.config.data_directory = old_data_dir
        # close any open DB connections before teardown
        for conn in wn._db.pool.values():
            conn.close()

