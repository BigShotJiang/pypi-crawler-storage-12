#!/usr/bin/env python

"""Tests for `geosdevpy` package."""


import unittest

from geosdevpy import geosdevpy


class TestGeosdevpy(unittest.TestCase):
    """Tests for `geosdevpy` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
