# geosdevpy


[![image](https://img.shields.io/pypi/v/geosdevpy.svg)](https://pypi.python.org/pypi/geosdevpy)
[![image](https://img.shields.io/conda/vn/conda-forge/geosdevpy.svg)](https://anaconda.org/conda-forge/geosdevpy)


**Python dev geospatial package for development and testing**


-   Free software: MIT License
-   Documentation: https://gsc-cmgd.github.io/geosdevpy
    

## Features

-   TODO
