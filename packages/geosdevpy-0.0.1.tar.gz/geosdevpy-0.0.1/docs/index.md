# Welcome to geosdevpy


[![image](https://img.shields.io/pypi/v/geosdevpy.svg)](https://pypi.python.org/pypi/geosdevpy)


**Python dev geospatial package for development and testing**


-   Free software: MIT License
-   Documentation: <https://gsc-cmgd.github.io/geosdevpy>
    

## Features

-   TODO
