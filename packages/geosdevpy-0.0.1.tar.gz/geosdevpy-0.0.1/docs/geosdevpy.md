
# geosdevpy module

::: geosdevpy.geosdevpy