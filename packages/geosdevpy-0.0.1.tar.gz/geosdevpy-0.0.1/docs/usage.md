# Usage

To use geosdevpy in a project:

```
import geosdevpy
```
