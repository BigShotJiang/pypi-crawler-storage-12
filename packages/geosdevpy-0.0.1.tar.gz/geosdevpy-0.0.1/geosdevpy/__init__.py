"""Top-level package for geosdevpy."""

__author__ = """gsc cmgd"""
__email__ = "renato.cumani@gmail.com"
__version__ = "0.0.1"
