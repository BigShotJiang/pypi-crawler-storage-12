# Generic terms and conditions

Be excellent to each other.

You see this content because you don't have provided a proper `SITE_TERMS_LOCATION` setting
pointing to the rightful content.
