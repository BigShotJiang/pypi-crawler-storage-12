from udata.app import create_app, standalone

app = standalone(create_app())
