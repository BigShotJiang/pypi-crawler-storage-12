from typing import Literal

TTSLangCodes = Literal["en", "nl", "es", "de", "hi", "en-hi", "ar"]
