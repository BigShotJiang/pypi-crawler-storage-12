"""Tests for claude-explore."""
