def main():
    print("Hello from mysql-mcp!")


if __name__ == "__main__":
    main()
