def inversion_recovery_fid():
    """
    TODO
    """