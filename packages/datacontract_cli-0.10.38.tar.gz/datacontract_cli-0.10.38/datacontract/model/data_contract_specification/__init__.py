from datacontract_specification.model import *
