"""Integration tests for user journeys and workflows."""

