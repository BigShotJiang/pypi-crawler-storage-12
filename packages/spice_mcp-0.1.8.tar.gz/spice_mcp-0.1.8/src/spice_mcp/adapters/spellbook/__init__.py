"""Spellbook adapter for discovering dbt models from GitHub repository."""

from .explorer import SpellbookExplorer

__all__ = ["SpellbookExplorer"]

