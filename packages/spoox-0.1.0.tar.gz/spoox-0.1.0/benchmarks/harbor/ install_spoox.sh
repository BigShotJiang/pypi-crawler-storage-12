
apt update -y
apt install -y python3 python3-pip
ln -sf /usr/bin/python3 /usr/bin/python
ln -sf /usr/bin/pip3 /usr/bin/pip
python --version
pip --version

pip install spoox