# 1. create src directory
mkdir ~/src

# 2. create hello world file with content
echo "hello world" > ~/src/hello_world.txt