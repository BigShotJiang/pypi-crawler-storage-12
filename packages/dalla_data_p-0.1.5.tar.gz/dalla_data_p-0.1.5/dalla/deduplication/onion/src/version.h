/*********************************************************************
 * Copyright (c) 2011-2016 Jan Pomikalek, Milos Jakubicek            *
 * All rights reserved.                                              *
 *                                                                   *
 * This software is licensed as described in the file COPYING, which *
 * you should have received as part of this distribution.            *
 *********************************************************************/

#define VERSION "1.4"
void print_version(const char* progname);
