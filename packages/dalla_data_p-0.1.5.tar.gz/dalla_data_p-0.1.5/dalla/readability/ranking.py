"""
Ranking and binning logic for readability scores.

Converts raw Flesch and Osman scores into 5-level difficulty rankings.
"""

import logging
import statistics

logger = logging.getLogger(__name__)


def compute_ranks_and_levels(
    osman_scores: list[float], flesch_scores: list[float]
) -> tuple[list[int], list[int], list[float], list[float], list[int], list[int], list[int]]:
    """
    Compute ranks, levels, bins, and final readability levels.

    This follows the methodology from process_scores_5levels.py:
    1. Rank documents by Osman & Flesch (lowest score = rank 1)
    2. Compute mean/stdev of rank differences
    3. Normalize ranks to get O-Level, F-Level
    4. Bin into 5 levels (0-4)
    5. Decide final level (prefer Flesch for hardest, Osman for easiest)

    Args:
        osman_scores: List of Osman scores
        flesch_scores: List of Flesch scores

    Returns:
        Tuple of:
        - o_ranks: Osman ranks (list of ints)
        - f_ranks: Flesch ranks (list of ints)
        - o_levels: Normalized Osman levels (list of floats)
        - f_levels: Normalized Flesch levels (list of floats)
        - o_bins: Osman bins 0-4 (list of ints)
        - f_bins: Flesch bins 0-4 (list of ints)
        - final_levels: Final readability levels 0-4 (list of ints)
    """
    n = len(osman_scores)

    if n == 0:
        return ([], [], [], [], [], [], [])

    # 1) Determine ranks (lowest score => rank=1)
    sorted_osman_idx = sorted(range(n), key=lambda i: osman_scores[i])
    o_ranks = [0] * n
    for rank_i, doc_idx in enumerate(sorted_osman_idx):
        o_ranks[doc_idx] = rank_i + 1

    sorted_flesch_idx = sorted(range(n), key=lambda i: flesch_scores[i])
    f_ranks = [0] * n
    for rank_i, doc_idx in enumerate(sorted_flesch_idx):
        f_ranks[doc_idx] = rank_i + 1

    # 2) Rank differences
    rank_diffs = [o_r - f_r for o_r, f_r in zip(o_ranks, f_ranks, strict=False)]

    if len(rank_diffs) > 1:
        std_diff = statistics.pstdev(rank_diffs)
        if std_diff == 0:
            std_diff = 1.0
    else:
        std_diff = 1.0

    # 3) Compute O-Level, F-Level = rank / std_diff
    o_levels = [float(o_r) / std_diff for o_r in o_ranks]
    f_levels = [float(f_r) / std_diff for f_r in f_ranks]

    # 4) Bin O-Levels & F-Levels into [0..4]
    o_bins = bin_levels_descending(o_levels)
    f_bins = bin_levels_ascending(f_levels)

    # 5) Decide final level
    final_levels = [decide_final_level(ob, fb) for ob, fb in zip(o_bins, f_bins, strict=False)]

    return (o_ranks, f_ranks, o_levels, f_levels, o_bins, f_bins, final_levels)


def bin_levels_descending(values: list[float]) -> list[int]:
    """
    Map values into 5 bins (0..4) where:
    - 0 = largest 20% (easiest for Osman)
    - 4 = smallest 20% (hardest for Osman)

    Args:
        values: List of numeric values

    Returns:
        List of bin assignments (0-4)
    """
    sorted_vals = sorted(values, reverse=True)  # descending
    n = len(sorted_vals)

    if n == 0:
        return []
    if n == 1:
        return [0]

    def percentile_value(pct):
        idx = int(round((pct / 100.0) * (n - 1)))
        return sorted_vals[idx]

    q1 = percentile_value(20)
    q2 = percentile_value(40)
    q3 = percentile_value(60)
    q4 = percentile_value(80)

    bins = []
    for v in values:
        if v >= q1:
            bins.append(0)  # top 20% => easiest
        elif v >= q2:
            bins.append(1)
        elif v >= q3:
            bins.append(2)
        elif v >= q4:
            bins.append(3)
        else:
            bins.append(4)  # bottom 20% => hardest

    return bins


def bin_levels_ascending(values: list[float]) -> list[int]:
    """
    Map values into 5 bins (0..4) where:
    - 0 = largest 20% (easiest for Flesch)
    - 4 = smallest 20% (hardest for Flesch)

    For Flesch, smaller value => harder, so we invert.

    Args:
        values: List of numeric values

    Returns:
        List of bin assignments (0-4)
    """
    sorted_vals = sorted(values)  # ascending
    n = len(sorted_vals)

    if n == 0:
        return []
    if n == 1:
        return [0]

    def percentile_value(pct):
        idx = int(round((pct / 100.0) * (n - 1)))
        return sorted_vals[idx]

    q1 = percentile_value(20)
    q2 = percentile_value(40)
    q3 = percentile_value(60)
    q4 = percentile_value(80)

    bins = []
    for v in values:
        if v < q1:
            bins.append(4)  # smaller values => harder => bin 4
        elif v < q2:
            bins.append(3)
        elif v < q3:
            bins.append(2)
        elif v < q4:
            bins.append(1)
        else:
            bins.append(0)  # larger values => easier => bin 0

    return bins


def decide_final_level(o_bin: int, f_bin: int) -> int:
    """
    Decide final readability level from Osman and Flesch bins.

    Strategy (Option B3 - Smart Conservative):
    - Trust Osman when it indicates hardness (bins 3-4)
    - Trust Flesch when it indicates easiness (bins 0-1)
    - On complete disagreement (diff >= 2), be conservative (take harder)
    - On small disagreement (diff = 1), average them

    Philosophy:
    - Osman is the expert at identifying hard texts
    - Flesch is the expert at identifying easy texts
    - When metrics completely disagree, the text is unusual → mark as harder
    - When metrics slightly disagree, compromise with average

    Args:
        o_bin: Osman bin (0-4, 0=easiest, 4=hardest)
        f_bin: Flesch bin (0-4, 0=easiest, 4=hardest)

    Returns:
        Final level (0-4)

    Examples:
        >>> decide_final_level(4, 0)  # Osman=hard, Flesch=easy → trust Osman
        4
        >>> decide_final_level(0, 4)  # Osman=easy, Flesch=hard → trust Flesch (unusual, conservative)
        4
        >>> decide_final_level(1, 0)  # Both easy, Flesch=easier → trust Flesch
        0
        >>> decide_final_level(3, 4)  # Both hard, Osman=easier → trust Osman
        3
        >>> decide_final_level(2, 3)  # Small disagreement → average
        2
    """
    # Strong Osman signal: text is hard (bins 3-4)
    # Trust Osman as the hardness expert
    if o_bin >= 3:
        return o_bin

    # Strong Flesch signal: text is easy (bins 0-1)
    # Trust Flesch as the easiness expert
    if f_bin <= 1:
        return f_bin

    # Calculate disagreement magnitude
    diff = abs(o_bin - f_bin)

    # Complete disagreement (diff >= 2)
    # The text has unusual characteristics - be conservative
    if diff >= 2:
        return max(o_bin, f_bin)

    # Small disagreement (diff = 1) or agreement
    # Compromise with average (round up for conservative bias)
    return (o_bin + f_bin + 1) // 2
