"""Tests for CLI interface."""

from click.testing import CliRunner

from dalla.cli import cli


def test_cli_help():
    """Test that CLI help works."""
    runner = CliRunner()
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "Dalla Process" in result.output


def test_cli_version():
    """Test that version flag works."""
    runner = CliRunner()
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.output


def test_deduplicate_help():
    """Test deduplicate command help."""
    runner = CliRunner()
    result = runner.invoke(cli, ["deduplicate", "--help"])
    assert result.exit_code == 0
    assert "deduplicate" in result.output.lower()


def test_stem_help():
    """Test stem command help."""
    runner = CliRunner()
    result = runner.invoke(cli, ["stem", "--help"])
    assert result.exit_code == 0
    assert "stem" in result.output.lower()


def test_quality_check_help():
    """Test quality-check command help."""
    runner = CliRunner()
    result = runner.invoke(cli, ["quality-check", "--help"])
    assert result.exit_code == 0
    assert "quality" in result.output.lower()


def test_readability_help():
    """Test readability command help."""
    runner = CliRunner()
    result = runner.invoke(cli, ["readability", "--help"])
    assert result.exit_code == 0
    assert "readability" in result.output.lower()


def test_split_help():
    """Test split command help."""
    runner = CliRunner()
    result = runner.invoke(cli, ["split", "--help"])
    assert result.exit_code == 0
    assert "split" in result.output.lower()


def test_info_command():
    """Test info command requires path."""
    runner = CliRunner()
    result = runner.invoke(cli, ["info"])
    assert result.exit_code != 0
