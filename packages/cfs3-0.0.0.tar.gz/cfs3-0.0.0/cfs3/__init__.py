__version__ = "0.2.0"

from cfs3.cftools import MetaFix, FileNameFix, CFSplitter, CFuploader
from cfs3.s3cmd import s3cmd