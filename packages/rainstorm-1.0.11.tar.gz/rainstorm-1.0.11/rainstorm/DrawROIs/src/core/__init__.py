# src/core/__init__.py
# Core modules for the DrawROIs application
