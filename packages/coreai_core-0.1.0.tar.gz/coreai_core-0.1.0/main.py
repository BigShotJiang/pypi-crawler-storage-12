def main():
    print("Hello from coreai-core!")


if __name__ == "__main__":
    main()
