import unittest
from mllab import Program


class TestProgram(unittest.TestCase):
    def test_run_existing(self):
        p = Program()
        result = p.run(1)
        # Expect a string (user-filled content). Do not assert exact contents.
        self.assertIsInstance(result, str)

    def test_run_invalid(self):
        p = Program()
        self.assertEqual(p.run(11), "Invalid program number")


if __name__ == "__main__":
    unittest.main()
