import setuptools 
setuptools.setup( 
name='mllab-kec',   
version='0.1', 
author="Alien", 
author_email="sooryagopaal@gmail.com", 
description="KEC ML Lab Package", 
packages=setuptools.find_packages(), 
classifiers=[ 
"Programming Language :: Python :: 3", 
"License :: OSI Approved :: MIT License", 
"Operating System :: OS Independent", 
], 
) 