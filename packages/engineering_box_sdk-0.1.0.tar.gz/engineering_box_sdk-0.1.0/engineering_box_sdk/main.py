def hello():
    """Print a greeting from the Quantum Hardware Team."""
    print("Hello from Quantum HardWare Team (Azhar)")

def main():
    """Entry point for the command-line interface."""
    hello()

if __name__ == "__main__":
    main()