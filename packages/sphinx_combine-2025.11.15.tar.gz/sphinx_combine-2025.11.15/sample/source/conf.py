"""
Sample ``conf.py``.
"""

extensions = [
    "sphinx_combine",
]
