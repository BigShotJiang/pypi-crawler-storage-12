"""
Tests for the code block combining extension.
"""
