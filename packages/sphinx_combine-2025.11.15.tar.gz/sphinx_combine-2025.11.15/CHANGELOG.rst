Changelog
=========

.. contents::

Next
----

2025.11.15
----------

* Give version in extension metadata.

2024.12.30.1
------------

2024.12.30
----------

2024.12.29
----------
