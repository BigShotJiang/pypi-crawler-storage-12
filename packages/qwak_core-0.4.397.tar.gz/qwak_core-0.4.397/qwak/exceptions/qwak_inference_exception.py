class QwakInferenceException(Exception):
    """
    Raise when there is an inference error
    """
