from xmagic_sdk.mcp import registry
from xmagic_sdk.mcp.mcp_api import run_mcp_server
from xmagic_sdk.mcp.fetch_info_from_kb import fetch_info_from_kb_v1, fetch_info_from_kb_v3
