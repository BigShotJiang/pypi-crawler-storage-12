"""Inference and generation utilities for PSANN-LM.

Sampling strategies (top-k/top-p), temperature, and penalties will be
implemented here.
"""

