"""Data utilities for PSANN-LM (tokenizer, datasets, collation).

This package will host tokenizer plugins and streaming datasets.
"""

