===================
Possible exceptions
===================

.. automodule:: secretstorage.exceptions
   :members:
