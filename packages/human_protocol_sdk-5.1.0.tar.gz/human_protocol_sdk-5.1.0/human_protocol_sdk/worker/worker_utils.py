import logging
from typing import List, Optional

from web3 import Web3

from human_protocol_sdk.constants import NETWORKS, ChainId
from human_protocol_sdk.utils import SubgraphOptions, custom_gql_fetch
from human_protocol_sdk.filter import WorkerFilter

LOG = logging.getLogger("human_protocol_sdk.worker")


class WorkerUtilsError(Exception):
    """
    Raised when an error occurs when getting data from subgraph.
    """

    pass


class WorkerData:
    def __init__(
        self,
        id: str,
        address: str,
        total_amount_received: str,
        payout_count: str,
    ):
        """
        Initializes a WorkerData instance.

        :param id: Worker ID
        :param address: Worker address
        :param total_amount_received: Total amount received by the worker
        :param payout_count: Number of payouts received by the worker
        """

        self.id = id
        self.address = address
        self.total_amount_received = int(total_amount_received)
        self.payout_count = int(payout_count)


class WorkerUtils:
    """
    A utility class that provides additional worker-related functionalities.
    """

    @staticmethod
    def get_workers(
        filter: WorkerFilter,
        options: Optional[SubgraphOptions] = None,
    ) -> List[WorkerData]:
        """Get workers data of the protocol.

        :param filter: Worker filter
        :param options: Optional config for subgraph requests

        :return: List of workers data
        """

        from human_protocol_sdk.gql.worker import get_workers_query

        workers = []
        network = NETWORKS.get(filter.chain_id)
        if not network:
            raise WorkerUtilsError("Unsupported Chain ID")

        workers_data = custom_gql_fetch(
            network,
            query=get_workers_query(filter),
            params={
                "address": filter.worker_address,
                "orderBy": filter.order_by,
                "orderDirection": filter.order_direction.value,
                "first": filter.first,
                "skip": filter.skip,
            },
            options=options,
        )

        if (
            not workers_data
            or "data" not in workers_data
            or "workers" not in workers_data["data"]
            or not workers_data["data"]["workers"]
        ):
            return []

        workers_raw = workers_data["data"]["workers"]

        for worker in workers_raw:
            workers.append(
                WorkerData(
                    id=worker.get("id"),
                    address=worker.get("address"),
                    total_amount_received=worker.get("totalHMTAmountReceived"),
                    payout_count=worker.get("payoutCount"),
                )
            )

        return workers

    @staticmethod
    def get_worker(
        chain_id: ChainId,
        worker_address: str,
        options: Optional[SubgraphOptions] = None,
    ) -> Optional[WorkerData]:
        """Gets the worker details.

        :param chain_id: Network in which the worker exists
        :param worker_address: Address of the worker
        :param options: Optional config for subgraph requests

        :return: Worker data if exists, otherwise None
        """

        from human_protocol_sdk.gql.worker import get_worker_query

        network = NETWORKS.get(chain_id)
        if not network:
            raise WorkerUtilsError("Unsupported Chain ID")

        if not Web3.is_address(worker_address):
            raise WorkerUtilsError(f"Invalid operator address: {worker_address}")

        network = NETWORKS[chain_id]
        worker_data = custom_gql_fetch(
            network,
            query=get_worker_query(),
            params={"address": worker_address.lower()},
            options=options,
        )

        if (
            not worker_data
            or "data" not in worker_data
            or "worker" not in worker_data["data"]
            or not worker_data["data"]["worker"]
        ):
            return None

        worker = worker_data["data"]["worker"]

        return WorkerData(
            id=worker.get("id"),
            address=worker.get("address"),
            total_amount_received=worker.get("totalHMTAmountReceived"),
            payout_count=worker.get("payoutCount"),
        )
