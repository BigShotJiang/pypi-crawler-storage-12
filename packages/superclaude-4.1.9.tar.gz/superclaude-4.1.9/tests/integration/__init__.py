"""
Integration tests for SuperClaude Framework

Tests component interactions and pytest plugin integration.
"""
