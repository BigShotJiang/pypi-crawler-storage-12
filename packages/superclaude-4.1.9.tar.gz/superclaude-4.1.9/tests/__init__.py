"""
SuperClaude Framework Test Suite

Test organization:
- unit/ - Unit tests for individual components
- integration/ - Integration tests for component interactions
- fixtures/ - Shared test fixtures and helpers
"""

__version__ = "0.4.0"
