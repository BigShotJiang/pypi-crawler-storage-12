"""
Unit tests for SuperClaude Framework components

Tests individual components in isolation without external dependencies.
"""
