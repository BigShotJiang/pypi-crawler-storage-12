Welcome to pandora_plugin_mccnn's documentation!
=================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   getting_started.rst
   api_reference/index.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
