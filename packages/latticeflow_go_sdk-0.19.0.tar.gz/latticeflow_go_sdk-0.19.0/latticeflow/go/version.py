__version__ = 'standard'
git_version = '561fae0db459dec08db4da6e122a347789d9e8e7'
