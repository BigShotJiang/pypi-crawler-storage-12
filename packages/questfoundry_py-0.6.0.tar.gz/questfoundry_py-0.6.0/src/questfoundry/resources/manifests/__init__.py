"""Bundled compiled manifests from spec/05-behavior/."""
