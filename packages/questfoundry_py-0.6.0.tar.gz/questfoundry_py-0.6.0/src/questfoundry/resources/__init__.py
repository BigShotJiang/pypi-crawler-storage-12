"""Bundled resources package for QuestFoundry schemas and prompts."""
