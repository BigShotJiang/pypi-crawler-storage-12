"""Bundled JSON schemas for QuestFoundry artifacts."""
