"""CLI-NLP: Natural Language to Shell Command Converter."""

__version__ = "0.3.0"

