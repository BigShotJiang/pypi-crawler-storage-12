"""Import all fixtures here."""

from tests.fixtures.dashboard import * # noqa
from tests.fixtures.database import * # noqa
from tests.fixtures.models import * # noqa
