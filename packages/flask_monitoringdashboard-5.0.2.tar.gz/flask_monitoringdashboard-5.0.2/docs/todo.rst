TODO List
=========================================================================

All things that can be improved in Flask-MonitoringDashboard are listed below.

Features to be implemented
--------------------------
- create a memory usage graph for the outliers, similar to the cpu usage one
- allow for endpoint purge and/or deletion
- allow for merging of endpoints
- improve code readability through comments

Work in progress
----------------

