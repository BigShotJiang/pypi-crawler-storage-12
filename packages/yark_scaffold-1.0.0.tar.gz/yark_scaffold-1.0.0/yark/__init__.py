"""Yark - YAML-based directory scaffolding tool."""

__version__ = "v1.0.0"