"""Test suite for pocketeer."""
