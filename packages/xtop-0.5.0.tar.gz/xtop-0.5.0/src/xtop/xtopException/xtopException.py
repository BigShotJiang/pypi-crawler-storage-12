class GPUNotFoundException(Exception):
    pass


class NPUNotFoundException(Exception):
    pass


class BackendException(Exception):
    pass


class OSUnsupportedException(Exception):
    pass

