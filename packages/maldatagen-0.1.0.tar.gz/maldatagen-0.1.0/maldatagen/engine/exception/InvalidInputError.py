class InvalidInputError(ValueError):
    """Custom exception for invalid input data."""

