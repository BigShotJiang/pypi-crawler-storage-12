class DataReaderError(Exception):
    pass