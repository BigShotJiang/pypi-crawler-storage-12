from Engine.Exception.DataReaderError import DataReaderError


class MissingValueError(DataReaderError):
    pass