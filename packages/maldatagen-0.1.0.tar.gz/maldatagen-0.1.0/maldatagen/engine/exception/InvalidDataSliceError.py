class InvalidDataSliceError(Exception):
    pass