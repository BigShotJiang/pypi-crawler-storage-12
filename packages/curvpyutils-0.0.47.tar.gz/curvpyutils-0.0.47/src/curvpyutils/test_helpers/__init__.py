from .compare_files import compare_files

__all__ = [
    "compare_files",
]