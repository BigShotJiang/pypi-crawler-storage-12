📄 محتوى ملف README.md
# reqlib

مكتبة Python خفيفة للتعامل مع HTTP و HTML و JSON، تدعم جميع أنواع الطلبات، رفع الملفات، تحليل الردود، واستخراج البيانات من الصفحات بسهولة.

---

## 🚀 التثبيت

```bash
pip install request
```



📡 الطلبات الأساسية
from request import get, post, put, delete, head, options, patch

res = get("https://httpbin.org/get", params={"q": "test"})
print(res.status)
print(res.text)



📦 رفع ملفات
res = post("https://httpbin.org/post", files={"file": "test.txt"})
print(res.json())



🍪 الكوكيز والهيدر
res = get("https://httpbin.org/cookies", cookies={"session": "abc123"})
print(res.cookies)



🔁 إعادة التوجيه
res = get("https://httpbin.org/redirect/2")
print(res.redirect_chain)



🧠 تحليل الرد
print(res.ok)               # هل الرد ناجح؟
print(res.status)           # كود الحالة
print(res.headers)          # الهيدر
print(res.cookies_dict)     # كل الكوكيز من التاريخ
print(res.url_parts)        # تفكيك الرابط
print(res.query_params)     # باراميترات الرابط



🧬 JSON و HTML
print(res.is_json)          # هل الرد JSON؟
print(res.json())           # فك JSON
print(res.html)             # استخراج الحقول من أول form
print(res.title)            # عنوان الصفحة
print(res.links)            # كل الروابط
print(res.assets)           # الصور والسكربتات والستايلات
print(res.meta)             # عناصر meta



🔍 استخراج عناصر HTML
استخراج قيمة attribute من أول عنصر:
res.search_attr("input", "data-token")


استخراج عناصر متعددة:
res.gethtml("input", "value")
res.gethtml("input", ["name", "value", "data-token"])
res.gethtml(["input", "textarea"], ["name", "value"])


النتيجة:
{
  "name": ["email", "bio"],
  "value": ["mhmd@example.com"],
  "data-token": ["abc123"]
}



🧪 تحليل السكربتات
print(res.js)               # متغيرات JavaScript
print(res.jsonhtml)         # كائنات JSON داخل HTML
print(res.get_script_vars())# نفس js



🔐 التعامل مع البروكسي
res = get("http://httpbin.org/ip", proxies={
    "http": "http://127.0.0.1:8080",
    "https": "http://127.0.0.1:8080"
})


SOCKS5 غير مدعوم مباشرة، استخدم requests + PySocks إذا احتجت ذلك.


🧵 تحليل النموذج
print(res.form_fields)      # كل الحقول من أول form
print(res.get_hidden_inputs)# كل الحقول المخفية



🧠 أدوات ذكية إضافية
res.is_redirect             # هل الرد إعادة توجيه؟
res.headers_lower           # الهيدر بدون حساسية حروف
res.get_cookie("session")   # جلب كوكي
res.get_header("Content-Type") # جلب هيدر
res.json_path("data.user.email") # استخراج من JSON باستخدام dot notation
res.find_tag("input", name="csrf_token") # أول عنصر يطابق



🌀 دعم أوامر curl
res = curl("curl -X POST https://httpbin.org/post -d 'name=mhmd'")
print(res.json())



📚 الترخيص
MIT License

✨ المؤلف
mhmd — مكتبة مصممة لتكون واضحة، قوية، وسهلة الاستخدام للمبرمجين المحترفين.



🤔 لماذا تستخدم reqlib بدلًا من requests؟
|  | reqlib | requests | 
| curl |  |  | 
|  |  |  | 
|  |  |  | 
|  |  |  | 
| multipart |  |  | 
|  |  |  | 
|  |  |  | 
|  |  |  | 
| **kwargs |  |  | 
|  |  |  | 



✨ متى تستخدم reqlib؟
- إذا كنت تبني أدوات scraping أو تحليل صفحات HTML.
- إذا كنت تريد مكتبة خفيفة وسهلة الفهم بدون تعقيد.
- إذا كنت تفضل واجهة واضحة وصريحة بدون **kwargs.
- إذا كنت تحب التحكم الكامل في كل تفاصيل الطلب والرد.
- إذا كنت تحب كتابة أدوات مخصصة فوق مكتبة قابلة للتوسعة.



