def main():
    print("Hello from coreai-torch!")


if __name__ == "__main__":
    main()
