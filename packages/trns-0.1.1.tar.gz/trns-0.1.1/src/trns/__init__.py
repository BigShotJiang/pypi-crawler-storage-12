"""
TRNS - Transcription and Language Model Processing

A tool for transcribing YouTube videos, Twitter/X.com videos, and local video files
with automatic translation and language model processing.
"""

__version__ = "0.1.1"

