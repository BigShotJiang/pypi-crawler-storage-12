"""A Python implementation of the classic tty-clock."""

__version__ = "2.0.0"
