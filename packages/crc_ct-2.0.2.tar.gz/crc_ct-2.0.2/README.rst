crc-ct (DEPRECATED)
===================

.. warning::

   This package is deprecated. Please use `crcc <https://pypi.org/project/crcc/>`_ instead.

Development and maintenance continue only in ``crcc``.

Python 3.10 or higher installing ``crc-ct`` will automatically install ``crcc``.
