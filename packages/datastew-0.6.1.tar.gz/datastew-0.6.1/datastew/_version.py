__version__ = "v0.6.1" # will be substituted in publish workflow
