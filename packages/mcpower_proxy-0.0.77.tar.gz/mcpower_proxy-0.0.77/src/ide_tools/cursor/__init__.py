"""
Cursor IDE Handler

Handles Cursor-specific hooks and operations.
"""

from .router import route_cursor_hook

__all__ = [
    "route_cursor_hook",
]
