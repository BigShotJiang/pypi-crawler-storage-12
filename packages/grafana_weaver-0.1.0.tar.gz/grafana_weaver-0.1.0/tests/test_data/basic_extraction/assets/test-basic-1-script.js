// EXTERNAL:test-basic-1-script.js
function renderPanel() {
  return 'Hello World';
}
