"""
Alprina API module.
REST API for AI-powered security scanning.
"""

from .main import app

__all__ = ["app"]
