"""Demo vulnerable application for tutorial purposes."""
