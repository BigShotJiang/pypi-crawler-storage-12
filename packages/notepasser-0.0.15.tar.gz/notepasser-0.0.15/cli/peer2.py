from cli.cli_peer import main

def fake():
    main(".fakenotepasser")

if __name__ == '__main__':
    fake()
