from cli.cli_peer import main


if __name__ == '__main__':
    main()