def hello():
    print("Hello, dude!")