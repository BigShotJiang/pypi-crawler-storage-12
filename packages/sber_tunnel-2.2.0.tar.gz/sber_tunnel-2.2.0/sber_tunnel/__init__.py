"""Sber-tunnel - File synchronization via Confluence API."""

__version__ = "1.0.0"
__author__ = "Sber Team"
