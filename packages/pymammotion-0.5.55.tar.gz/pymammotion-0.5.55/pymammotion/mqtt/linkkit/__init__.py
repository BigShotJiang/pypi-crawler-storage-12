"""Package for linkkit."""

from .linkkit import LinkKit

__all__ = ["LinkKit"]
