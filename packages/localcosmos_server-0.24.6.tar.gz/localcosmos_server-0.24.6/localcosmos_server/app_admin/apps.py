from django.apps import AppConfig


class AppAdminConfig(AppConfig):
    name = 'localcosmos_server.app_admin'
