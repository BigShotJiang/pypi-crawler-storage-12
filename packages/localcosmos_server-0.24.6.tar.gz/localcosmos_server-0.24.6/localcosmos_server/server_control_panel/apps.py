from django.apps import AppConfig


class ServerControlPanelConfig(AppConfig):
    name = 'localcosmos_server.server_control_panel'
