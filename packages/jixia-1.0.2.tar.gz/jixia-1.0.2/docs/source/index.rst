Welcome to jixia's documentation!
=================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   structs
   run
   glossary



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
