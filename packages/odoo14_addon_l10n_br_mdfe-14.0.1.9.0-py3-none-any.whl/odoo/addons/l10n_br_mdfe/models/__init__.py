from . import transporte
from . import res_company
from . import document
from . import document_related
from . import res_partner
from . import res_config_settings
from . import modal_aereo
from . import modal_aquaviario
from . import modal_ferroviario
from . import modal_rodoviario
from . import document_info
from . import seguro_carga
from . import product_product
from . import document_supplement
from . import document_type

spec_schema = "mdfe"
spec_version = "30"
