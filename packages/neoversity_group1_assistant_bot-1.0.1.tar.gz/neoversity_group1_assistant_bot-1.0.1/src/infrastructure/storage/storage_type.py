from enum import Enum


class StorageType(Enum):
    PICKLE = 1
    JSON = 2
    SQLITE = 3
