from sqlalchemy.orm import declarative_base

DBBase = declarative_base()
