from collections import UserDict


class Notebook(UserDict):
    pass
