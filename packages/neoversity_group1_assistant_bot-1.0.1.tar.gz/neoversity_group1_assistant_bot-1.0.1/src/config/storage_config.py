class StorageConfig:

    # Default storage type can be configured here if needed
    # DEFAULT_STORAGE_TYPE = StorageType.SQLITE
    pass
