class StorageException(Exception):
    pass
