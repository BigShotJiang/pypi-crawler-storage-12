def main():
    print("Hello from agent-infra-dev!")


if __name__ == "__main__":
    main()
