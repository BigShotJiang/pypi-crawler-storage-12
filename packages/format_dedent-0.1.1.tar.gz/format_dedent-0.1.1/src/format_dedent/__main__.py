#!/usr/bin/env python3
"""Entry point for format-dedent CLI."""

if __name__ == "__main__":
    from format_dedent.cli import main

    main()
