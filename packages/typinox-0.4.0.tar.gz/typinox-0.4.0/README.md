Typinox
=======

**Typinox** (TAI-pee-nox) is a Python library for enhancing run-time type-checking of
`jaxtyping`-annotated arrays and `equinox.Module`s.

Installation
------------

```bash
pip install typinox
```

Documentation
-------------

Read the documentation at [https://typinox.readthedocs.io](https://typinox.readthedocs.io).

License
-------

This project is licensed under the BSD 3-Clause License. See the [LICENSE](LICENSE) file for details.
