This is the `v0.4.0` release of the `typinox` project.

In this version:

- A workaround is applied to the internal handling of `TypeVarTuple` for `ValidatedT`.
- Bumping dependencies: `beartype` to 0.22.5, `jaxtyping` to 0.3.3, and `equinox` to 0.13.2.

<!-- TODO before release: pyproject.toml, docs/src/conf.py -->
