.. currentmodule:: typinox.shaped

``typinox.shaped`` module
=========================

.. automodule:: typinox.shaped
    :members:
    :show-inheritance:
    :member-order: bysource
