.. currentmodule:: typinox.error

``typinox.error`` module
========================

.. automodule:: typinox.error
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource
