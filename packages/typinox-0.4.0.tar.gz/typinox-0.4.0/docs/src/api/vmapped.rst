Vmapped annotation
==================

.. autoclass:: typinox.Vmapped

.. autoclass:: typinox.VmappedT

.. autoclass:: typinox.VmappedI
