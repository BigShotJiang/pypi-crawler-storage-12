Typed Modules
=============

.. autoclass:: typinox.TypedModule
    :members:
        _validate

.. autofunction:: typinox.field

.. autoclass:: typinox.TypedPolicy

.. autoclass:: typinox.module.TypedModuleMeta
