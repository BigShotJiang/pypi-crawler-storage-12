How to write annotations
========================

To be continued...
