"""Tests for Trino MCP Server."""
