German localization for Cooperators module.
