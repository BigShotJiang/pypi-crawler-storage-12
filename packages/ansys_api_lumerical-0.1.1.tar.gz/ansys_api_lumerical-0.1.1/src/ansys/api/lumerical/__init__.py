# (c) 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
"""Low level Python API for Ansys Lumerical."""

__version__ = "0.1.1"
"""Lumerical Low Level API version."""
