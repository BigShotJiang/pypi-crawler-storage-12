from .gradients import build_gradient_method
from .spsa import *
from .param_shift import *
from .dummy import *
