from .model import Net, MnistNet
