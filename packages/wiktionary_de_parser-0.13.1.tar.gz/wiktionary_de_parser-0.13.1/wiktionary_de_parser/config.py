from pathlib import Path


PACKAGE_PATH = Path(__file__).parent.absolute()
