
from setuptools import setup

setup(package_data={'ttkthemes-stubs': ['__init__.pyi', '_imgops.pyi', '_utils.pyi', '_widget.pyi', 'themed_style.pyi', 'themed_tk.pyi', 'METADATA.toml', 'py.typed']})
