"""Integration tests for end-to-end scenarios."""
