"""Unit tests for Axon integrations with LLM frameworks."""
