Credit to Fig2a of https://www.nature.com/articles/nature14439

I emailed them and was given data.
