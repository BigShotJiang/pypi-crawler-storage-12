# MCP imports using the new SDK patterns
from mcp.server.fastmcp import FastMCP


gis_mcp = FastMCP("GIS MCP")
