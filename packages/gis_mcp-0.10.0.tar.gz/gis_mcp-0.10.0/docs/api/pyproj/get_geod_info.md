### get_geod_info

Return parameters of a Geod model.

- Tool: `get_geod_info`

Parameters

- ellps (string, default "WGS84")
- a (number, optional), b (number, optional), f (number, optional)

Returns

- ellps, a, b, f, es, e; status, message
