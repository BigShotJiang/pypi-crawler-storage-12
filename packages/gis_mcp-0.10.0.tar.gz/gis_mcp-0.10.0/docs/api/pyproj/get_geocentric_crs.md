### get_geocentric_crs

Return a geocentric CRS (WKT) for given lon/lat.

- Tool: `get_geocentric_crs`

Parameters

- coordinates (array [lon, lat])

Returns

- crs (string, WKT), status, message
