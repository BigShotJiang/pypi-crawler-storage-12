### get_available_crs

Return a list of available CRS entries.

- Tool: `get_available_crs`

Returns

- crs_list[] with auth_name, code, name, type; status, message
