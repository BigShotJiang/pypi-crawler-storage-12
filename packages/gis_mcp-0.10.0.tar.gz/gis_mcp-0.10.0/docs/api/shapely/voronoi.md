### voronoi

Create a Voronoi diagram from input points.

- Tool: `voronoi`

Parameters

- geometry (string, WKT multipoint/lines)

Returns

- geometry (string, WKT), status, message
