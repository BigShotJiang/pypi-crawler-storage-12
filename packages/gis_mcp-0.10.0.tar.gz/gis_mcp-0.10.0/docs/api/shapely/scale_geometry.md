### scale_geometry

Scale a geometry by factors around origin.

- Tool: `scale_geometry`

Parameters

- geometry (string, WKT)
- xfact (number)
- yfact (number)
- origin (string, default "center")

Returns

- geometry (string, WKT), status, message
