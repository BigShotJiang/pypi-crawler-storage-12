### convex_hull

Compute the convex hull of a geometry.

- Tool: `convex_hull`

Parameters

- geometry (string, WKT)

Returns

- geometry (string, WKT), status, message
