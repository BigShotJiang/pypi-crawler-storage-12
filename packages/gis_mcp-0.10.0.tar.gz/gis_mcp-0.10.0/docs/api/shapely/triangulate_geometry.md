### triangulate_geometry

Triangulate a polygon geometry; returns multiple triangles.

- Tool: `triangulate_geometry`

Parameters

- geometry (string, WKT)

Returns

- geometries (array of WKT), status, message
