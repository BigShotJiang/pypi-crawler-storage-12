### unary_union_geometries

Compute the unary union of multiple geometries.

- Tool: `unary_union_geometries`

Parameters

- geometries (array of strings, WKT)

Returns

- geometry (string, WKT), status, message
