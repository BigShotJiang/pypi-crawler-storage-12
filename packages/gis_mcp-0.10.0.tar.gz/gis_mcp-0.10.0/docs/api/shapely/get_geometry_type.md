### get_geometry_type

Return the geometry type string.

- Tool: `get_geometry_type`

Parameters

- geometry (string, WKT)

Returns

- type (string), status, message
