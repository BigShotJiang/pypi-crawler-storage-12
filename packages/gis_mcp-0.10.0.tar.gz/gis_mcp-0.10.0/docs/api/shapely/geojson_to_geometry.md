# geojson_to_geometry

Convert GeoJSON to a Shapely geometry using shapely.shape.

**Arguments:**

- `geojson` (dict): GeoJSON dictionary.

**Returns:**

- Dictionary with status, message, and geometry as WKT.
