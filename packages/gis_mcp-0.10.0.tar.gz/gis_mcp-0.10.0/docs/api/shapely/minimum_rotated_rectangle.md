### minimum_rotated_rectangle

Return the minimum rotated rectangle of a geometry.

- Tool: `minimum_rotated_rectangle`

Parameters

- geometry (string, WKT)

Returns

- geometry (string, WKT), status, message
