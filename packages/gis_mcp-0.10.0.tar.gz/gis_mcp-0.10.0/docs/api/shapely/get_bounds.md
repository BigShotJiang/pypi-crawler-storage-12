### get_bounds

Return bounds [minx, miny, maxx, maxy] of a geometry.

- Tool: `get_bounds`

Parameters

- geometry (string, WKT)

Returns

- bounds (array [minx, miny, maxx, maxy]), status, message
