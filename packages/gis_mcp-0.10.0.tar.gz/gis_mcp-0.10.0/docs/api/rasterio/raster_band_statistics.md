### raster_band_statistics

Calculate min, max, mean, std for each band.

- Tool: `raster_band_statistics`

Parameters

- source (string)

Returns

- statistics object keyed by band; status, message
