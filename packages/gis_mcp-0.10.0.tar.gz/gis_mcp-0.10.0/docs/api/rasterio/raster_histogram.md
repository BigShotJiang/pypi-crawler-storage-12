### raster_histogram

Compute histogram of pixel values for each band.

- Tool: `raster_histogram`

Parameters

- source (string)
- bins (integer, default 256)

Returns

- histograms with histogram and bin_edges per band; status, message
