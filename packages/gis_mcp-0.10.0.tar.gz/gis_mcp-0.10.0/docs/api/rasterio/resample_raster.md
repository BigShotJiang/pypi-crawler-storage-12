### resample_raster

Resample a raster by a scale factor and write the result.

- Tool: `resample_raster`

Parameters

- source (string)
- scale_factor (number)
- resampling (string)
- destination (string)

Returns

- destination; status, message
