### concat_bands

Concatenate multiple single-band rasters into a multi-band raster; auto-aligns if needed.

- Tool: `concat_bands`

Parameters

- folder_path (string)
- destination (string)

Returns

- destination; status, message
