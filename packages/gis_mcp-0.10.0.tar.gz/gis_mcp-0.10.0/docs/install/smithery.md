### Install via Smithery

Installs and wires the server into Claude Desktop automatically.

```bash
npx -y @smithery/cli install @mahdin75/gis-mcp --client claude
```

Start the server from Claude when prompted, or run it directly once installed:

```bash
gis-mcp
```
