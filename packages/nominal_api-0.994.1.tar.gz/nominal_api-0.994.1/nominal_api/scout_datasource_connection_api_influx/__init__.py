# coding=utf-8
from .._impl import (
    scout_datasource_connection_api_influx_OrgId as OrgId,
)

__all__ = [
    'OrgId',
]

