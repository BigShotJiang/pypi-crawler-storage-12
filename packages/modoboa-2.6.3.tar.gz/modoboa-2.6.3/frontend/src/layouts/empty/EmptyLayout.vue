<template>
  <v-app>
    <EmptyView />
  </v-app>
</template>

<script setup>
import EmptyView from './EmptyView.vue'
</script>
