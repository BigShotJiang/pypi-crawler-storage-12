# Import these to force registration of checks
from . import settings_checks  # NOQA:F401
