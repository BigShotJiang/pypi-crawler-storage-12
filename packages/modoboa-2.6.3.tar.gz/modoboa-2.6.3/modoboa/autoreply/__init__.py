"""Away message editor for Modoboa."""

default_app_config = "modoboa.autoreply.apps.AutoreplyConfig"
