
# Installation

## Using sources

Download the repository, then run the following command inside :

```bash
pip install .
```

For developers, you can also install it in editable mode, so any change to the source will be taken into account :

```bash
pip install -e .
```
