Antes de instalar este módulo, asegúrese de tener configurada la agencia fiscal de Canarias en la configuración de la empresa.
Esto es necesario para la correcta asignación del tipo de impuesto "03" (IGIC) tanto en las facturas como en las posiciones fiscales.
Se recomienda hacer uso del modulo `account_chart_update`, esto permitira una actualizacion correcta a la localización.
