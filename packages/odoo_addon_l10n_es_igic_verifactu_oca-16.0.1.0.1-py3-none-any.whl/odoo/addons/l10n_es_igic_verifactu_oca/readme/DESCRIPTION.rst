Módulo para la adaptación de la comunicación con el servicio Veri*FACTU de los impuestos de Canarias (IGIC).
