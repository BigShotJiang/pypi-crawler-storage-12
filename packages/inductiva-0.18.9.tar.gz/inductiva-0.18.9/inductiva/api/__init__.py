"""Functionality to interact with the Web API."""
from .methods import submit_task, get_task_status
from .methods import get_api_config
from .methods import get_client, get_machines_catalogue_client
