"""Version file for deepnote-toolkit."""

__version__ = "1.1.4"
