This module allows to set different price rules depending on the
destination.

This module restores the concept of delivery grid, reusing the same
model for nesting several "children" delivery methods, one per possible
destination. It has been designed to reuse all possible extensions to
the base delivery, without the need to create a glue module for having
multiple destinations.
