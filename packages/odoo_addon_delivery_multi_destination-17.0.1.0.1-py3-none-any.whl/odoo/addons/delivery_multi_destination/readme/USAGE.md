1.  When using the delivery method in a Sales order, delivery address
    will be used for computing the delivery price according introduced
    destinations.
