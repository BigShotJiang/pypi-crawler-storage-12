- Delivery prices for e-commerce (website_sale_delivery module) might
  need an extra module for handling everything properly.
