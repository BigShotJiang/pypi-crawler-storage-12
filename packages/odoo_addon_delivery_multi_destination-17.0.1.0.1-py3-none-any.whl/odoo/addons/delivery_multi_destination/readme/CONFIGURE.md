To configure delivery methods with multiple destinations:

1.  Go to Inventory \> Configuration \> Delivery \> Shipping Methods
2.  Create or edit an existing record.
3.  Select "Destination type" = "Multiple destinations".
4.  Introduce a line for each destination in the new tab "Destinations"
5.  Lines have priority, so you have to put first the lines with more
    restricted destinations.
