from heracless.cli_tool import run_cli as _run_cli
from heracless.fight import fight as load_config
if __name__ == "__main__":
    _run_cli()
