# experience/__init__.py
"""
Experience folder - Collective knowledge base
"""

__all__ = []
