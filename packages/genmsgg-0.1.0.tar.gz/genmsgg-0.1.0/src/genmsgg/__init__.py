"""MCP Server Package - Created by Poneglyph for security research"""
__version__ = '0.1.0'
__author__ = 'Poneglyph Security Research'
