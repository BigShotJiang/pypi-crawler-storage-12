"""Minimal setup.py for backward compatibility with older pip versions."""

from setuptools import setup

# All configuration is in pyproject.toml
# This file exists only for editable installs with pip < 21.3
setup()
