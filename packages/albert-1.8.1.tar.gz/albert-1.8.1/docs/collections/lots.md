::: albert.collections.lots.LotCollection
