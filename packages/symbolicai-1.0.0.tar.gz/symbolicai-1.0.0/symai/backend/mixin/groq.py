SUPPORTED_CHAT_MODELS = [
    "groq:moonshotai/kimi-k2-instruct"
]

SUPPORTED_REASONING_MODELS = [
    "groq:openai/gpt-oss-120b",
    "groq:openai/gpt-oss-20b",
    "groq:qwen/qwen3-32b",
    "groq:deepseek-r1-distill-llama-70b"
]
