class MetricflowMetricTypes:
    simple = "simple"
    derived = "derived"
    cumulative = "cumulative"
    ratio = "ratio"
