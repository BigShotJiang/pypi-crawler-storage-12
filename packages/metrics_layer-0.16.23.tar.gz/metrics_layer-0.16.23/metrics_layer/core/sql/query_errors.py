from metrics_layer.core.exceptions import MetricsLayerException


class ParseError(MetricsLayerException):
    pass


class ArgumentError(MetricsLayerException):
    pass
