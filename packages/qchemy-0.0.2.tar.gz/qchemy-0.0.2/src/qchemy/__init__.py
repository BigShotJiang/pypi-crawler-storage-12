"""QChemy: Python library for basic quantum chemistry calculations."""


from qchemy import eleconfig, termsym

__all__ = ['eleconfig', 'termsym']
