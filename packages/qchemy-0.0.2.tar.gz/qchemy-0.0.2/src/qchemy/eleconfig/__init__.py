"""Electron configuration calculations."""

from . import atom

__all__ = ['atom']
