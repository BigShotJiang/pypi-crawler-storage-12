"""Term symbol calculations."""

from . import atom

__all__ = ['atom']
