Calculation Architecture
========================

This document explains how Path of Building performs calculations and how our API extracts the calculated results.

.. include:: CALCULATION_ARCHITECTURE.md
   :language: markdown
