from pro_craft.prompt_craft import AsyncIntel



def test_asyncintel_init():
    aintel = AsyncIntel(database_url="")


def test_get_prompt():
    get_prompt


def test_save_prompt():
    save_prompt


def test_adjust_prompt():
    pass

def test_cc():

    # def test_
    inference_format
    inference_format_gather