Pipeline Runners
===========================

.. currentmodule:: hats_import

Given some pipeline arguments method, pass to one of the pipeline
execution methods below.

This method will delegate to the appropriate pipeline, and is in
charge of sending the completion email.

.. autofunction:: pipeline

.. autofunction:: pipeline_with_client
