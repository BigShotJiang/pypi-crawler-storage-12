"""Convert a hipscatted catalog into a HATS catalog, with appropriate metadata/properties."""

from .arguments import ConversionArguments
from .run_conversion import run
