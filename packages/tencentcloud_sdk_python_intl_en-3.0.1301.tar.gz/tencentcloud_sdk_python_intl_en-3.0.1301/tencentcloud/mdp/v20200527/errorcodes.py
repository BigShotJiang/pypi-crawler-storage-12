# -*- coding: utf8 -*-
# Copyright (c) 2017-2025 Tencent. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


# Internal error.
INTERNALERROR = 'InternalError'

# Failed to obtain SSAI ad configuration.
INTERNALERROR_GETSSAICHANNELSFAILED = 'InternalError.GetSSAIChannelsFailed'

# Failed to obtain SSAI ad configuration usage.
INTERNALERROR_GETSSAIUSAGEPARTIALFAILED = 'InternalError.GetSSAIUsagePartialFailed'

# Invalid `ActionType`.
INVALIDPARAMETER_ACTIONTYPE = 'InvalidParameter.ActionType'

# Incorrect authentication configuration.
INVALIDPARAMETER_AUTHINFO = 'InvalidParameter.AuthInfo'

# Invalid `CacheInfo` value
INVALIDPARAMETER_CACHEINFO = 'InvalidParameter.CacheInfo'

# Invalid CDN playback domain name.
INVALIDPARAMETER_CDNDOMAIN = 'InvalidParameter.CdnDomain'

# Invalid `ChannelId`.
INVALIDPARAMETER_CHANNELID = 'InvalidParameter.ChannelId'

# The quantity exceeds the limit.
INVALIDPARAMETER_EXCEEDEDQUANTITYLIMIT = 'InvalidParameter.ExceededQuantityLimit'

# Invalid `Id`.
INVALIDPARAMETER_ID = 'InvalidParameter.Id'

# The InputFileInfo is invalid.
INVALIDPARAMETER_INPUTFILEINFO = 'InvalidParameter.InputFileInfo'

# SSAI channel id is invalid.
INVALIDPARAMETER_INVALIDPARAMETERCHANNELID = 'InvalidParameter.InvalidParameterChannelId'

# Invalid `LvbDomain`.
INVALIDPARAMETER_LVBDOMAIN = 'InvalidParameter.LvbDomain'

# Invalid name.
INVALIDPARAMETER_NAME = 'InvalidParameter.Name'

# Failed to find the VOD remux task.
INVALIDPARAMETER_NOTFOUND = 'InvalidParameter.NotFound'

# OutputGroups is invalid.
INVALIDPARAMETER_OUTPUTGROUPS = 'InvalidParameter.OutputGroups'

# The OutputStorage is invalid.
INVALIDPARAMETER_OUTPUTSTORAGE = 'InvalidParameter.OutputStorage'

# Invalid `PageNum`.
INVALIDPARAMETER_PAGENUM = 'InvalidParameter.PageNum'

# Invalid `PageSize`.
INVALIDPARAMETER_PAGESIZE = 'InvalidParameter.PageSize'

# Invalid `Points` value
INVALIDPARAMETER_POINTS = 'InvalidParameter.Points'

# Invalid protocol.
INVALIDPARAMETER_PROTOCOL = 'InvalidParameter.Protocol'

# Invalid ad insertion configuration parameters.
INVALIDPARAMETER_SSAIINFO = 'InvalidParameter.SSAIInfo'

# VOD remux task state is invalid.
INVALIDPARAMETER_STATE = 'InvalidParameter.State'

# VOD remux task type error.
INVALIDPARAMETER_TYPE = 'InvalidParameter.Type'

# Invalid `Url`.
INVALIDPARAMETER_URL = 'InvalidParameter.Url'
