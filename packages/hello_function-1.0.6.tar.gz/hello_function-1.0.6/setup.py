from setuptools import setup, find_packages

setup(
    name="Hello_Function",  
    version="1.0.6",
    author="Saqib Raheem(ws)",
    author_email="wsssaqib99@gmail.com",
    description="A simple library that says hello.",
    packages=['hello_function'],  
)
