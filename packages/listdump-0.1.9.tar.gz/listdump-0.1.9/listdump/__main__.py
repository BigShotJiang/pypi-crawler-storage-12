from listdump.list_files import main

if __name__ == "__main__":
    main()
