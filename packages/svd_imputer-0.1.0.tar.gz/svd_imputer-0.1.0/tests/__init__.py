"""Tests for svd_imputer package"""
