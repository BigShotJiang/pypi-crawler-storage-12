class CreateScenarioTestError(Exception):
    pass


class EvalFunctionNotAvailableError(Exception):
    pass
