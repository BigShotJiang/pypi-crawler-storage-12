def test_load():
    assert True
