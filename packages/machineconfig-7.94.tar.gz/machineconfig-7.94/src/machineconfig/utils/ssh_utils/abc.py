

MACHINECONFIG_VERSION = "machineconfig>=7.94"
DEFAULT_PICKLE_SUBDIR = "tmp_results/tmp_scripts/ssh"

