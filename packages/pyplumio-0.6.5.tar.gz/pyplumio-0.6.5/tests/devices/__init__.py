"""Contains tests for the devices module."""
