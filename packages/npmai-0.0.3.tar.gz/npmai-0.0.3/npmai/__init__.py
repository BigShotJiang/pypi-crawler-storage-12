__version__ = "0.0.3"
from .npmai import GeminiAIMode, Gemini, ChatGPT, Grok, Perplexity
