"""Core orchestration components."""
