"""CLI entry point for accuralai-core."""

from .main import app, main

__all__ = ["app", "main"]
