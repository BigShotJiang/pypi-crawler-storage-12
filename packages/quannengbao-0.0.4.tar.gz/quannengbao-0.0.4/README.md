需要安装 bytedtqs 
pip3 install bytedtqs --index-url=https://bytedpypi.byted.org/simple/
或是显示安装全能包指定路径
pip install quannengbao[byted] --extra-index-url https://bytedpypi.byted.org/simple