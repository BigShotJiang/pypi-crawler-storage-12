def main():
    print("Hello from langdoc!")


if __name__ == "__main__":
    main()
