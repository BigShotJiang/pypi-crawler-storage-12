from setuptools import setup

# Use metadata from setup.cfg / pyproject.toml
setup()