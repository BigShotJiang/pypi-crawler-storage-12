"""Replicate image generators."""
