"""Setup script for fastapi-mongo-admin package."""

from setuptools import setup

setup()
