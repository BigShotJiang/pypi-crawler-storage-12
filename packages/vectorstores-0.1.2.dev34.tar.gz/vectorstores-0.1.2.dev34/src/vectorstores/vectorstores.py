from __future__ import annotations

import datetime
import logging
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    Iterable,
    List,
    Optional,
    Sequence,
    Tuple,
    Union,
)
from uuid import uuid4

import numpy as np
import weaviate  # type: ignore
from langchain_core.embeddings import Embeddings
from vectorstores.base import VectorStore


if TYPE_CHECKING:
    import weaviate


logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

handler = logging.StreamHandler()
formatter = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s", datefmt="%Y-%b-%d %I:%M %p"
)
handler.setFormatter(formatter)

logger.addHandler(handler)


# TODO: Find out how this schema has to be updated to match the new vector
# embedding input.
def _default_schema(index_name: str) -> Dict:
    return {
        "class": index_name,
        "properties": [
            {
                "name": "text",
                "dataType": ["text"],
            }
        ],
    }


# TODO: What does this normalize?
def _default_score_normalizer(val: float) -> float:
    # prevent overflow
    # use 709 because that's the largest exponent that doesn't overflow
    # use -709 because that's the smallest exponent that doesn't underflow
    val = np.clip(val, -709, 709)
    return 1 - 1 / (1 + np.exp(val))


# TODO: What is this responsible for?
def _json_serializable(value: Any) -> Any:
    if isinstance(value, datetime.datetime):
        return value.isoformat()
    return value


@dataclass
class VectorDocument:
    """
    Schema for rows sent to or returned from the vector store.
    """

    text: str
    uuid: Optional[str] = None
    vector: Any = None  # NumPy array of embedding values
    metadata: Dict[str, Any] = field(default_factory=dict)
    dataset: Optional[str] = None
    id: Optional[str] = None
    embedding_model_name: Optional[str] = None

    @property
    def page_content(self) -> str:
        """
        Compatibility property mirroring langchain's `Document.page_content`.
        """
        return self.text


class Vector:
    """
    Schema for rows sent to the vector store.
    """

    uuid: str
    vector: Any  # NumPy array of embedding values


class WeaviateVectorStore(VectorStore):
    """Weaviate vector store.

    To use, you should have the `weaviate-client` python package installed.

    Example:
        ```python
        import weaviate
        from langchain_community.vectorstores import Weaviate

        client = weaviate.Client(url=os.environ["WEAVIATE_URL"], ...)
        weaviate = Weaviate(client, index_name, text_key)
        ```
    """

    # TODO: Find out why exactly embedding is parsed, when it
    # is computed inside the add_text function?
    # TODO: Find out what is attributes parameter, when metadata
    # is parsed in the add_text function?
    def __init__(
        self,
        client: weaviate.WeaviateClient,  # client used for connceting to the database
        index_name: Optional[str],  # name of the index
        text_key: str,  # key for uploading to weaviate
        embedding: Optional[Embeddings] = None,  # embedding model, maybe absolete
        attributes: Optional[
            List[str]
        ] = None,  # list of metadata/property names that will be retrieved from Weaviate and stored in Document.metadata
        relevance_score_fn: Optional[
            Callable[[float], float]
        ] = _default_score_normalizer,
        use_multi_tenancy: bool = False,
    ):
        """Initialize with Weaviate client."""
        self._client = client
        self._index_name = index_name or f"LangChain_{uuid4().hex}"
        self._embedding = embedding
        self._text_key = text_key
        self._query_attrs = [self._text_key]
        self.relevance_score_fn = relevance_score_fn
        if attributes is not None:
            self._query_attrs.extend(attributes)

        schema = _default_schema(self._index_name)
        schema["MultiTenancyConfig"] = {"enabled": use_multi_tenancy}

        # check whether the index already exists
        if not client.collections.exists(self._index_name):
            client.collections.create_from_dict(schema)

        # store collection for convenience
        # this does not actually send a request to weaviate
        self._collection = client.collections.get(self._index_name)

        # store this setting so we don't have to send a request to weaviate
        # every time we want to do a CRUD operation
        self._multi_tenancy_enabled = self._collection.config.get(
            simple=False
        ).multi_tenancy_config.enabled

    def add_vector(
        self,
        vectors: Iterable[VectorDocument],  # added vector compatibility
        metadatas: Optional[List[dict]] = None,
        texts: Optional[Iterable[str]] = None,  # made this optional
        tenant: Optional[str] = None,
        ids: Optional[Any] = None,  # added this for later search
        **kwargs: Any,
    ) -> List[str]:
        """Upload vectors with metadata (properties) to Weaviate."""
        from weaviate.util import get_valid_uuid  # type: ignore

        if tenant and not self._does_tenant_exist(tenant):
            logger.info(
                f"Tenant {tenant} does not exist in index {self._index_name}. "
                "Creating tenant."
            )
            tenant_objs = [weaviate.classes.tenants.Tenant(name=tenant)]
            self._collection.tenants.create(tenants=tenant_objs)

        ids = []
        embeddings: Optional[List[List[float]]] = None

        # TODO: ensuring vector count matches `metadatas`/`ids`, and update VectorStore docs to
        # describe the new path.

        # TODO: If embeddings are supplied externally, skip this branch and accept numpy /
        # torch tensors directly (including enforcing device/dtype conversions).
        # Will this colide with the backward compatibility?
        if self._embedding and texts is not None and vectors is None:
            vectors = self._embedding.embed_documents(list(texts))

        with self._client.batch.dynamic() as batch:
            # TODO: Iterate over zipped (text, vector, metadata) tuples so we can upload
            # entries that might not include raw text (RankingTransformer outputs).
            # Is this step necessary or can text be removed without conflict?
            for i, vector_obj in enumerate(vectors):
                data_properties = {
                    self._text_key: getattr(vector_obj, "text", vector_obj)
                }
                # TODO: Permit `text` to be optional/None when only embeddings exist, and
                # avoid inserting placeholder strings in Weaviate.
                # How exactly? When text is already None?
                if metadatas is not None:
                    for key, val in metadatas[i].items():
                        data_properties[key] = _json_serializable(val)

                # Allow for ids (consistent w/ other methods)
                # # Or uuids (backwards compatible w/ existing arg)
                # If the UUID of one of the objects already exists
                # then the existing object will be replaced by the new object.
                _id = vector_obj.uuid
                if "uuids" in kwargs:
                    _id = kwargs["uuids"][i]
                elif "ids" in kwargs:
                    _id = kwargs["ids"][i]

                # TODO: Validate that a vector is always available when ingesting
                # RankingTransformer embeddings and raise a helpful error if not.
                batch.add_object(
                    collection=self._index_name,
                    properties=data_properties,
                    uuid=_id,
                    vector=vector_obj.vector,
                    tenant=tenant,
                )

                ids.append(_id)

        failed_objs = self._client.batch.failed_objects
        for obj in failed_objs:
            err_message = (
                f"Failed to add object: {obj.original_uuid}\nReason: {obj.message}"
            )

            logger.error(err_message)

        return ids

    @classmethod
    def from_texts(
        cls,
        documents: List[VectorDocument],
        embedding: Optional[Embeddings],
        metadatas: Optional[List[dict]] = None,
        *,
        tenant: Optional[str] = None,
        client: Optional[weaviate.WeaviateClient] = None,
        index_name: Optional[str] = None,
        text_key: str = "text",
        relevance_score_fn: Optional[
            Callable[[float], float]
        ] = _default_score_normalizer,
        **kwargs: Any,
    ) -> WeaviateVectorStore:
        """Construct Weaviate wrapper from raw documents.

        This is a user-friendly interface that:

        1. Embeds documents.
        2. Creates a new index for the embeddings in the Weaviate instance.
        3. Adds the documents to the newly created Weaviate index.

        This is intended to be a quick way to get started.

        Args:
            texts: Texts to add to vector store.
            embedding: Text embedding model to use.
            client: weaviate.Client to use.
            metadatas: Metadata associated with each text.
            tenant: The tenant name.
            index_name: Index name.
            text_key: Key to use for uploading/retrieving text to/from vectorstore.
            relevance_score_fn: Function for converting whatever distance function the
                vector store uses to a relevance score, which is a normalized similarity
                score (`0` means dissimilar, `1` means similar).
            **kwargs: Additional named parameters to pass to `Weaviate.__init__()`.

        Example:
            ```python
            from langchain_community.embeddings import OpenAIEmbeddings
            from langchain_community.vectorstores import Weaviate

            embeddings = OpenAIEmbeddings()
            weaviate = Weaviate.from_texts(
                texts,
                embeddings,
                client=client
            )
            ```
        """
        # TODO: Provide a companion constructor (e.g., `from_embeddings`) or extend this
        # method to accept precomputed vectors + ids so RankingTransformer batches can be
        # uploaded without re-embedding inside the vector store.

        attributes = list(metadatas[0].keys()) if metadatas else None

        if client is None:
            raise ValueError("client must be an instance of WeaviateClient")

        weaviate_vector_store = cls(
            client,
            index_name,
            text_key,
            embedding=embedding,
            attributes=attributes,
            relevance_score_fn=relevance_score_fn,
            use_multi_tenancy=tenant is not None,
        )

        weaviate_vector_store.add_vectors(documents, metadatas, tenant=tenant, **kwargs)

        return weaviate_vector_store

    def delete(
        self,
        ids: Optional[List[str]] = None,
        tenant: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Delete by vector IDs.

        Args:
            ids: List of ids to delete.
            tenant: The tenant name.
        """

        if ids is None:
            raise ValueError("No ids provided to delete.")

        id_filter = weaviate.classes.query.Filter.by_id().contains_any(ids)

        with self._tenant_context(tenant) as collection:
            collection.data.delete_many(where=id_filter)

    def _does_tenant_exist(self, tenant: str) -> bool:
        """Check if tenant exists in Weaviate."""
        assert self._multi_tenancy_enabled, (
            "Cannot check for tenant existence when multi-tenancy is not enabled"
        )
        tenants = self._collection.tenants.get()

        return tenant in tenants

    @contextmanager
    def _tenant_context(
        self, tenant: Optional[str] = None
    ) -> Generator[weaviate.collections.Collection, None, None]:
        """Context manager for handling tenants.

        Args:
            tenant: The tenant name.
        """

        if tenant is not None and not self._multi_tenancy_enabled:
            raise ValueError(
                "Cannot use tenant context when multi-tenancy is not enabled"
            )

        if tenant is None and self._multi_tenancy_enabled:
            raise ValueError("Must use tenant context when multi-tenancy is enabled")

        try:
            yield self._collection.with_tenant(tenant)
        finally:
            pass

    def _perform_search(
        self,
        vector: Optional[Sequence[float]],
        query: Optional[str],
        k: int,
        return_score: bool = False,
        tenant: Optional[str] = None,
        **kwargs: Any,
    ) -> Union[List[VectorDocument], List[Tuple[VectorDocument, float]]]:
        """
        Perform a similarity search.

        Parameters:
            query: The query string to search for.
            k: The number of results to return.
            return_score: Whether to return the score along with the document.
            tenant: The tenant name.
            **kwargs: Additional parameters to pass to the search method. These
                parameters will be directly passed to the underlying Weaviate client's
                search method.

        Returns:
            A list of documents that match the query. If `return_score` is `True`, each
                document is returned as a tuple with the document and its score.

        Raises:
            ValueError: If `_embedding` is `None` or an invalid search method is
                provided.
        """
        if vector is None and query is None:
            raise ValueError("Either `vector` or `query` must be provided.")

        if vector is None:
            if self._embedding is None:
                raise ValueError("_embedding must be set when searching by query text.")
            vector = self._embedding.embed_query(query)  # type: ignore[arg-type]

        return_uuids = kwargs.pop("return_uuids", False)
        # Ensure Weaviate returns a distance/certainty so we can compute scores.
        if "return_metadata" not in kwargs:
            kwargs["return_metadata"] = ["distance"]
        elif "distance" not in kwargs["return_metadata"] and "certainty" not in kwargs["return_metadata"]:
            kwargs["return_metadata"].append("distance")

        with self._tenant_context(tenant) as collection:
            try:
                # Weaviate client expects the payload under the `near_vector` keyword.
                result = collection.query.near_vector(
                    near_vector=vector, limit=k, **kwargs
                )  # type: ignore[operator]
            except weaviate.exceptions.WeaviateQueryException as e:
                raise ValueError(f"Error during query: {e}")

        docs_and_scores: List[Tuple[VectorDocument, float]] = []
        for obj in result.objects:
            text = obj.properties.get(self._text_key)

            # Merge Weaviate properties and decoded metadata payload.
            merged_metadata: Dict[str, Any] = {}
            for key, value in obj.properties.items():
                if key == self._text_key:
                    continue
                if key == "metadata" and isinstance(value, str):
                    try:
                        merged_metadata.update(json.loads(value))
                    except json.JSONDecodeError:
                        merged_metadata[key] = value
                else:
                    merged_metadata[key] = value

            if obj.vector and "default" in obj.vector:
                merged_metadata["vector"] = obj.vector["default"]

            if return_uuids:
                merged_metadata["uuid"] = str(obj.uuid)

            # Choose score source: distance (normalize) or certainty (already [0,1]).
            score = 0.0
            if hasattr(obj.metadata, "distance") and obj.metadata.distance is not None:
                score = (
                    self.relevance_score_fn(obj.metadata.distance)
                    if self.relevance_score_fn
                    else obj.metadata.distance
                )
            elif (
                hasattr(obj.metadata, "certainty")
                and obj.metadata.certainty is not None
            ):
                score = float(obj.metadata.certainty)
            else:
                score = 0.0

            vector_payload = merged_metadata.pop("vector", None)
            # Prefer UUID we added to metadata; fall back to object's UUID if available.
            doc_uuid = merged_metadata.get("uuid") or (
                str(obj.uuid) if return_uuids else None
            )

            doc = VectorDocument(
                text=text or "",
                uuid=doc_uuid,
                vector=vector_payload,
                metadata=merged_metadata,
            )
            docs_and_scores.append((doc, score))

        if return_score:
            return docs_and_scores
        else:
            return [doc for doc, _ in docs_and_scores]

    def similarity_search(
        self,
        vector: Optional[Sequence[float]],
        query: Optional[str],
        k: int = 4,
        **kwargs: Any,
    ) -> Union[List[VectorDocument], List[Tuple[VectorDocument, float]]]:
        """Return docs most similar to query.

        Args:
            query: Text to look up documents similar to.
            k: Number of `VectorDocument` objects to return. Defaults to `4`.
            **kwargs: Additional keyword arguments will be passed to the `hybrid()`
                function of the weaviate client.

        Returns:
            List of `VectorDocument` objects most similar to the query.
        """

        result = self._perform_search(vector, query, k, **kwargs)
        return result
