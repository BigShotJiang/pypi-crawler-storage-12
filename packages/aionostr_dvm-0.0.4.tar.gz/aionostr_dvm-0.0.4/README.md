# aionostr-dvm

Simple Framework for building basic NIP-89/90 Data Vending Machines with electrum-aionostr.

The NIP-89/90 specification is kind of a mess so this is mostly tested against the Amethyst client 
and might not work with other clients. Feel free to open PRs to improve things.

## Installation

```bash
pip install aionostr-dvm
```

## Usage

Check out this repository for an example of how to use this library:
https://github.com/f321x/notarized-notes-dvm