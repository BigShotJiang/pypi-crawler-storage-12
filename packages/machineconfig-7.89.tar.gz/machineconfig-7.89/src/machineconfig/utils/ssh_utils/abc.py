

MACHINECONFIG_VERSION = "machineconfig>=7.89"
DEFAULT_PICKLE_SUBDIR = "tmp_results/tmp_scripts/ssh"

