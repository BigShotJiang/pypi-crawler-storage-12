# QURI Parts Braket

QURI Parts Braket is a support library for using Amazon Braket SDK with QURI Parts.
You can combine your code written in QURI Parts with this library to execute it on Amazon Braket.

## Documentation

[QURI Parts Documentation](https://quri-parts.qunasys.com)

## Installation

```
pip install quri-parts-braket
```

## License

Apache License 2.0
