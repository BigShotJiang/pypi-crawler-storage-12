class ForeignKey:
    def __init__(self, type):
        self.type = type

    def retrieve(self):
        ...
    