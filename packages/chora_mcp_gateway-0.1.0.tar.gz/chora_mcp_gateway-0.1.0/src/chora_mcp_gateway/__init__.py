"""chora-mcp-gateway: Routing layer with auto-discovery for MCP ecosystem."""

__version__ = "0.1.0"
