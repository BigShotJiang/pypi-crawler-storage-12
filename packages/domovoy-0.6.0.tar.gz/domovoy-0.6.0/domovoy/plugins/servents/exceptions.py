from domovoy.core.errors import DomovoyError


class ServentMissingRegistrationError(DomovoyError):
    ...


class ServentInvalidConfigurationError(DomovoyError):
    ...
