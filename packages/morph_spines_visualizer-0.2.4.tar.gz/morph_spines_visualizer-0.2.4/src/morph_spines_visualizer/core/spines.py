from typing import List, Tuple

def get_spine_ids_by_section_id(
    morphology, 
    section_id: int) -> List[int]:
    """
    Get the IDs of spines that belong to a specific section of a neuronal morphology.

    This function queries the morphology object (assumed to follow NeuroM-style indexing)
    and returns all spine IDs associated with the given section.

    Args:
        morphology: A morphology object that contains spines. Expected to have a method
                    `spine_indices_for_section(section_index: int) -> List[int]`.
        section_id (int): The ID of the section to query. Uses zero-based indexing.

    Returns:
        List[int]: List of spine IDs belonging to the specified section.
    """
    # NeuroM indexing might be 1-based internally, so adjust if necessary
    return morphology.spines.spine_indices_for_section(section_id + 1)

def get_section_ids_for_sections_with_spines(
    morphology) -> List[int]:
    """
    Get the IDs of sections in a morphology that have at least one spine.

    Args:
        morphology: A morphology object containing sections and spines.
                    Each section should have an `.id` attribute, and the
                    morphology object should be compatible with
                    `get_spine_ids_by_section_id`.

    Returns:
        List[int]: List of section IDs that contain one or more spines.
    """
    ids_of_sections_with_spines = []

    for section in morphology.morphology.sections:
        spine_ids = get_spine_ids_by_section_id(morphology, section.id)
        if len(spine_ids) > 0:
            ids_of_sections_with_spines.append(section.id)

    return ids_of_sections_with_spines

def get_section_ids_with_spine_counts_for_sections_with_spines(
    morphology) -> List[Tuple[int, int]]:
    """
    Get the IDs of sections that have spines along with the number of spines in each section.

    Args:
        morphology: A morphology object containing sections and spines.
                    Each section should have an `.id` attribute, and the
                    morphology object should be compatible with
                    `get_spine_ids_by_section_id`.

    Returns:
        List[Tuple[int, int]]: List of tuples `(section_id, spine_count)` for each section
                               that contains one or more spines.
    """
    section_ids_and_spine_counts = []

    for section in morphology.morphology.sections:
        spine_ids = get_spine_ids_by_section_id(morphology, section.id)
        if len(spine_ids) > 0:
            section_ids_and_spine_counts.append((section.id, len(spine_ids)))

    return section_ids_and_spine_counts

def get_spine_counts_for_sections_with_spines(
    morphology) -> List[int]:
    """
    Get the number of spines for each section that contains at least one spine.

    Args:
        morphology: A morphology object containing sections and spines.
                    Each section should have an `.id` attribute, and the
                    morphology object should be compatible with
                    `get_spine_ids_by_section_id`.
    Returns:
        List[int]: List of spine counts for each section that contains one or more spines.
    """ 
    spine_counts = []
    for section in morphology.morphology.sections:
        spine_ids = get_spine_ids_by_section_id(morphology, section.id)
        if len(spine_ids) > 0:
            spine_counts.append(len(spine_ids))
    return spine_counts

def get_spine_meshes_for_section(
    morphology,
    section_id: int) -> List:
    """
    Retrieve the spine mesh objects associated with a specific section in the morphology.

    Args:
        morphology: A morphology object containing spines.
                    Expected to have a `.spines` attribute with a method
                    `spine_indices_for_section(section_index: int) -> List[int]`
                    and a `.spine_meshes` attribute that is indexable.
        section_id (int): The ID of the section to retrieve spine meshes for.

    Returns:
        List: List of spine mesh objects associated with the specified section.
    """
    spine_ids = get_spine_ids_by_section_id(morphology, section_id)
    spine_meshes = [morphology.spines.spine_meshes[spine_id] for spine_id in spine_ids]
    return spine_meshes

def get_spine_colors():
    """
    Returns 25 colors for the spines that we can basically switch between.
    """
    spine_colors = [
        0xFF0000,  # Red
        0x00FF00,  # Lime
        0x0000FF,  # Blue
        0xFFFF00,  # Yellow
        0xFF00FF,  # Magenta
        0x00FFFF,  # Cyan
        0xFF8000,  # Orange
        0x8000FF,  # Violet
        0x00FF80,  # Spring Green
        0x0080FF,  # Sky Blue
        0xFF0080,  # Hot Pink
        0x80FF00,  # Chartreuse
        0x00FFFF,  # Aqua
        0xFFBF00,  # Amber
        0xBF00FF,  # Purple
        0x00FFBF,  # Mint
        0x00BFFF,  # Deep Sky Blue
        0xFF00BF,  # Fuchsia
        0xBFFF00,  # Lime-Yellow
        0xFF4000,  # Vermilion
        0x40FF00,  # Bright Green
        0x0040FF,  # Royal Blue
        0xFF0040,  # Crimson
        0x00FF40,  # Neon Green
        0x4000FF   # Indigo
    ]
    return spine_colors

def get_synaptic_locations(morphology):
    """
    Extract the 3D locations of synaptic (afferent surface) points from a neuron morphology.

    Parameters
    ----------
    morphology : object
        Morphology object containing a `.spines.spine_table` DataFrame with
        columns 'afferent_surface_x', 'afferent_surface_y', 'afferent_surface_z'.

    Returns
    -------
    list of tuple
        A list of (x, y, z) coordinates for each spine synapse.

    Example
    -------
    >>> locations = get_synaptic_locations(morph)
    >>> locations[:5]
    [(12.3, 45.6, 7.8), (14.5, 48.2, 9.1), ...]
    """
    # Extract columns from spine table
    x = morphology.spines.spine_table['afferent_surface_x'].to_numpy()
    y = morphology.spines.spine_table['afferent_surface_y'].to_numpy()
    z = morphology.spines.spine_table['afferent_surface_z'].to_numpy()

    # Combine into a list of (x, y, z) tuples
    locations = list(zip(x, y, z))

    return locations
