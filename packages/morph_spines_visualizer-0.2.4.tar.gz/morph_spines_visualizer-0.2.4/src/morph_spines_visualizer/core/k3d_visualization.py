import k3d 
import numpy as np 
from morph_spines_visualizer.core import k3d_core, data_loading, geometry
from morph_spines_visualizer.core import spines as spines_lib
import ipywidgets as widgets
from IPython.display import display

def create_spiny_sections_dropdown_options(section_ids_with_spine_counts):
    """
    Create dropdown options for neuron sections that have associated spine counts.

    Parameters
    ----------
    section_ids_with_spine_counts : dict or list
        A mapping or list-like object containing section IDs and their corresponding
        spine counts. If it's a dictionary, keys should be section IDs and values
        the spine counts. If it's a list of tuples, each tuple should be (section_id, spine_count).

    Returns
    -------
    list of tuple
        A list of (label, value) pairs suitable for use in a dropdown menu.
        The first entry is a placeholder option: ("-- Select Section --", None).
        Each subsequent entry has the format:
        ("Section <ID> (<count> spines)", <ID>)

    Examples
    --------
    >>> data = [(1, 12), (2, 8), (3, 15)]
    >>> create_spiny_sections_dropdown_options(data)
    [
        ("-- Select Section --", None),
        ("Section 1 (12 spines)", 1),
        ("Section 2 (8 spines)", 2),
        ("Section 3 (15 spines)", 3)
    ]
    """
    # Handle both dicts and list-of-tuples inputs
    if isinstance(section_ids_with_spine_counts, dict):
        items = section_ids_with_spine_counts.items()
    else:
        items = section_ids_with_spine_counts

    dropdown_options = [
        (f"Section {section_id} ({spine_count} spines)", section_id)
        for section_id, spine_count in items
    ]

    # Insert default placeholder option
    dropdown_options.insert(0, ("-- Select Section --", None))

    return dropdown_options

def create_spiny_sections_dropdown_menu(section_ids_with_spine_counts, width=300):
    """
    Create an interactive dropdown menu widget for selecting neuron sections
    with associated spine counts.

    Parameters
    ----------
    section_ids_with_spine_counts : dict or list
        A mapping or list-like object containing section IDs and their corresponding
        spine counts. This data is passed to
        `create_spiny_sections_dropdown_options` to build the menu options.

    width : int, optional
        The width of the dropdown menu in pixels (default is 300).

    Returns
    -------
    ipywidgets.Dropdown
        A configured dropdown widget where each option label shows the section ID
        and its number of spines (e.g., "Section 5 (12 spines)").
        The first entry is a placeholder: "-- Select Section --".

    Examples
    --------
    >>> data = [(1, 12), (2, 8), (3, 15)]
    >>> dropdown = create_spiny_sections_dropdown_menu(data, width=250)
    >>> display(dropdown)
    """
    # Create dropdown options from the provided section and spine data
    options = create_spiny_sections_dropdown_options(section_ids_with_spine_counts)

    # Configure the dropdown widget
    section_dropdown = widgets.Dropdown(
        options=options,
        value=None,
        description="Select Section:",
        style={"description_width": "initial"},
        layout=widgets.Layout(width=f"{width}px")
    )

    return section_dropdown

def visualize_morphology_with_point_cloud(
    mesh_path: str,
    morphology_path: str,
    grid_visible: bool = False,
    axes_helper: bool = False,
    background_color: int = 0xffffff
):
    """
    Visualize a neuron morphology together with its mesh as a point cloud using K3D.

    This function loads a spiny neuron morphology and its corresponding mesh, creates
    a K3D plot, adds the morphology and mesh points, and provides interactive controls:
    - Section selection dropdown (highlights section and its spines)
    - Camera reset and predefined orthogonal views (XY, XZ, YZ)

    Args:
        mesh_path (str): Path to the mesh file.
        morphology_path (str): Path to the morphology file.
        grid_visible (bool, optional): Show grid in K3D plot. Defaults to False.
        axes_helper (bool, optional): Show axes helper. Defaults to False.
        background_color (int, optional): Background color (hex). Defaults to 0xffffff.
    """

    # Load data
    morphology = data_loading.load_spiny_morphology(morphology_path)
    mesh_vertices = data_loading.load_mesh_vertices_pyvista(mesh_path, scale_factor=1e-3)

    # Create K3D plot
    plot = k3d.plot(
        grid_visible=grid_visible,
        axes_helper=axes_helper,
        background_color=background_color
    )

    # Add mesh point cloud
    k3d_core.add_mesh_point_cloud_to_plot(
        mesh_points=mesh_vertices,
        plot=plot,
        point_size=0.15,
        color=0x00ffcc
    )

    # Add morphology lines
    k3d_core.add_morphology_to_plot(
        morphology=morphology,
        plot=plot,
        line_color=0xff6666
    )

    # State variables for interactivity
    highlighted_line = [None]       # Current highlighted section line
    highlighted_points = [None]     # Optional points highlight
    current_center = [None]         # Center of currently selected section
    current_radius = [None]         # Radius of currently selected section
    spine_meshes = []               # List of displayed spine meshes

    # Camera utilities
    def set_camera(position, target, up):
        """Set the camera position and orientation."""
        plot.camera_auto_fit = False
        plot.camera = list(position) + list(target) + list(up)

    def reset_camera(_=None):
        """Reset the camera to default full neuron view."""
        plot.camera_reset()
        plot.camera_auto_fit = True

    def view_xy(_=None):
        """Top-down view (+Z)."""
        if current_center[0] is None:
            return
        pos = current_center[0] + np.array([0, 0, current_radius[0]])
        up = np.array([0, 1, 0])
        set_camera(pos, current_center[0], up)

    def view_xz(_=None):
        """Front view (-Y)."""
        if current_center[0] is None:
            return
        pos = current_center[0] + np.array([0, -current_radius[0], 0])
        up = np.array([0, 0, 1])
        set_camera(pos, current_center[0], up)

    def view_yz(_=None):
        """Side view (+X)."""
        if current_center[0] is None:
            return
        pos = current_center[0] + np.array([current_radius[0], 0, 0])
        up = np.array([0, 0, 1])
        set_camera(pos, current_center[0], up)

    # Compute initial neuron bounds
    _, _, center, extent, radius = geometry.compute_morphology_bounds(morphology)
    current_center[0] = center
    current_radius[0] = radius

    # Initial camera setup
    distance_factor = 1.0
    camera_position = center + np.array([0, 0, distance_factor * radius], dtype=np.float32)
    plot.camera_auto_fit = False
    plot.camera = camera_position.tolist() + center.tolist() + [0, 1, 0]

    # Section dropdown menu
    spiny_sections_dropdown_menu = create_spiny_sections_dropdown_menu(
        section_ids_with_spine_counts=spines_lib.get_section_ids_with_spine_counts_for_sections_with_spines(
            morphology=morphology
        )
    )

    # Map section ID to points
    sections_points = geometry.get_sections_points(morphology)

    # Section selection callback
    def focus_on_selected_section(change):
        """
        Highlight the selected section and its spines, and adjust the camera.

        Handles:
        - Clearing previous highlights
        - Resetting camera for empty selection
        - Highlighting section and drawing spines for selected section
        """
        nonlocal plot, spine_meshes

        if change.get("name") != "value":
            return

        sec_id = change.get("new")

        # Clear previous highlights
        for obj_list in [highlighted_line, highlighted_points]:
            if obj_list[0] is not None:
                try:
                    plot -= obj_list[0]
                except Exception:
                    pass
                obj_list[0] = None

        # Clear previous spine meshes
        for spine_obj in spine_meshes:
            try:
                plot -= spine_obj
            except Exception:
                pass
        spine_meshes.clear()

        # Empty selection → reset camera
        if sec_id not in sections_points:
            current_center[0] = center
            current_radius[0] = radius

            camera_pos = center + np.array([0, 0, 1.0 * radius], dtype=np.float32)
            plot.camera_auto_fit = False
            plot.camera = camera_pos.tolist() + center.tolist() + [0, 1, 0]
            return

        # Section selected → highlight
        pts = sections_points[sec_id]

        # Highlight the section line
        highlight = k3d.line(pts, width=0.15, color=0xFF0000, shader='flat')
        plot += highlight
        highlighted_line[0] = highlight

        # Compute section bounds and update state
        min_pt, max_pt = pts.min(axis=0), pts.max(axis=0)
        sec_center = (min_pt + max_pt) / 2.0
        sec_radius = np.linalg.norm(max_pt - min_pt) / 2.0
        current_center[0], current_radius[0] = sec_center, sec_radius

        # Adjust camera
        camera_pos = sec_center + np.array([0, 0, 2.0 * sec_radius], dtype=np.float32)
        plot.camera_auto_fit = False
        plot.camera = camera_pos.tolist() + sec_center.tolist() + [0, 1, 0]

        # Draw spine meshes
        spine_colors = spines_lib.get_spine_colors()
        spine_list = morphology.spines.spine_meshes_for_section(sec_id + 1)  # MICrONS IDs start at 1

        for i, spine_mesh in enumerate(spine_list):
            if spine_mesh.is_empty or len(spine_mesh.vertices) == 0:
                continue

            color = spine_colors[i % len(spine_colors)]
            vertices = np.asarray(spine_mesh.vertices, dtype=np.float32)

            if len(spine_mesh.faces) == 0:
                # Display as point cloud if faces are missing
                points = k3d.points(vertices, point_size=0.05, color=color)
                plot += points
                spine_meshes.append(points)
            else:
                faces = np.asarray(spine_mesh.faces, dtype=np.uint32)
                mesh = k3d.mesh(vertices, faces, color=color, flat_shading=True)
                plot += mesh
                spine_meshes.append(mesh)

    # Connect dropdown menu to callback
    spiny_sections_dropdown_menu.observe(focus_on_selected_section, names='value')

    # Camera control buttons
    reset_btn = widgets.Button(description="🔄 Reset", button_style='primary')
    xy_btn = widgets.Button(description="XY View")
    xz_btn = widgets.Button(description="XZ View")
    yz_btn = widgets.Button(description="YZ View")

    # Bind actions
    reset_btn.on_click(reset_camera)
    xy_btn.on_click(view_xy)
    xz_btn.on_click(view_xz)
    yz_btn.on_click(view_yz)

    # Layout controls
    controls = widgets.HBox([reset_btn, xy_btn, xz_btn, yz_btn, spiny_sections_dropdown_menu])
    display(widgets.VBox([plot, controls]))

def visualization_morphology_with_synapses(
        mesh_path: str,
        morphology_path: str,
        grid_visible: bool = False,
        axes_helper: bool = False,
        background_color: int = 0xffffff):
    """
    Visualize a spiny neuron morphology together with its mesh and synaptic locations using K3D.

    This function:
    1. Loads a neuron morphology and its corresponding mesh.
    2. Creates a K3D plot with optional grid and axes helper.
    3. Adds the mesh as a point cloud.
    4. Adds the morphology lines.
    5. Adds synaptic locations as a colored point cloud.

    Args:
        mesh_path (str): Path to the mesh file (e.g., .obj, .vtu).
        morphology_path (str): Path to the neuron morphology file.
        grid_visible (bool, optional): If True, display a grid in the plot. Defaults to False.
        axes_helper (bool, optional): If True, show axes helper in the plot. Defaults to False.
        background_color (int, optional): Background color of the plot in hexadecimal. Defaults to 0xffffff.

    Workflow:
        - Loads morphology and mesh data using `data_loading`.
        - Converts mesh vertices to point cloud format for K3D visualization.
        - Adds the neuron morphology as line structures.
        - Retrieves synaptic locations from the morphology and visualizes them as points.
    """

    # Load data
    morphology = data_loading.load_spiny_morphology(morphology_path)
    mesh_vertices = data_loading.load_mesh_vertices_pyvista(mesh_path, scale_factor=1e-3)

    # Create K3D plot
    plot = k3d.plot(
        grid_visible=grid_visible,
        axes_helper=axes_helper,
        background_color=background_color
    )

    # Add mesh as point cloud
    k3d_core.add_mesh_point_cloud_to_plot(
        mesh_points=mesh_vertices,
        plot=plot,
        point_size=0.15,
        color=0x00ffcc
    )

    # Add morphology lines
    k3d_core.add_morphology_to_plot(
        morphology=morphology,
        plot=plot,
        line_color=0xff6666
    )

    # # Add synaptic locations
    synaptic_locations = spines_lib.get_synaptic_locations(morphology=morphology)
    k3d_core.add_point_cloud_to_plot(
        points=np.array(synaptic_locations, dtype=np.float32), 
        plot=plot,
        point_size=1.0,
        opacity=1.0,
        color=0xFF8000
    )

    # Example button
    reset_btn = widgets.Button(description="Reset Camera")

    def reset_camera(btn):
        plot.camera_reset()
        plot.camera_auto_fit = True

    reset_btn.on_click(reset_camera)

    # Combine plot and button in a VBox
    container = widgets.VBox([plot, reset_btn])

    # Display everything
    display(container)

