import numpy as np
from typing import Tuple

def get_section_points(
    morphology, section_id: int) -> np.ndarray:
    """
    Retrieve the 3D points of a specific section in the morphology.

    Args:
        morphology: A morphology object containing sections with 3D points.
                    Expected structure: morphology.morphology.sections, where
                    each section has a `.points` attribute as an array-like of (x, y, z[, r]).
        section_id (int): The ID of the section to retrieve points from.

    Returns:
        np.ndarray: An array of shape (N, 3) containing the 3D points of the section.
    """
    for section in morphology.morphology.sections:
        if section.id == section_id:
            pts = np.asarray(section.points)[:, :3].astype(np.float32)
            return pts
    raise ValueError(f"Section ID {section_id} not found in morphology.")

def get_sections_points(morphology):
    """
    Extract 3D point coordinates for each section in a neuron morphology.

    Parameters
    ----------
    morphology : object
        A morphology object containing a `.morphology.sections` iterable.
        Each section is expected to have:
            - section.points : array-like of shape (N, ≥3)
            - section.id : unique identifier

    Returns
    -------
    dict
        A dictionary mapping section IDs to Nx3 NumPy arrays of float32
        coordinates. Sections with fewer than 2 points are skipped.

    Examples
    --------
    >>> sections = get_sections_points(morph)
    >>> sections[12].shape
    (45, 3)
    """
    sections_points = {}

    for section in morphology.morphology.sections:
        pts = np.asarray(section.points, dtype=np.float32)[:, :3]

        # Skip if section does not contain enough points to define a segment
        if pts.shape[0] < 2:
            continue

        sections_points[section.id] = pts

    return sections_points

def compute_morphology_bounds(
    morphology) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, float]:
    """
    Compute the bounding box and related metrics for a neuronal morphology.

    Args:
        morphology: A morphology object containing sections with 3D points.
                    Expected structure: morphology.morphology.sections, where
                    each section has a `.points` attribute as an array-like of (x, y, z[, r]).

    Returns:
        Tuple containing:
            - min_pt (np.ndarray): Minimum coordinates [x, y, z] of the bounding box.
            - max_pt (np.ndarray): Maximum coordinates [x, y, z] of the bounding box.
            - center (np.ndarray): Center of the bounding box.
            - extent (np.ndarray): Size of the bounding box along each axis (max - min).
            - radius (float): Approximate radius for visualization purposes (0.6 * diagonal length).
    """
    section_points = {}

    # Collect 3D points from all sections with at least 2 points
    for section in morphology.morphology.sections:
        pts = np.asarray(section.points)[:, :3].astype(np.float32)
        if pts.shape[0] < 2:
            continue
        section_points[section.id] = pts

    if not section_points:
        raise ValueError("Morphology contains no sections with valid points.")

    # Concatenate all vertices to compute bounding box
    all_vertices = np.concatenate(list(section_points.values()), axis=0)
    min_pt = all_vertices.min(axis=0)
    max_pt = all_vertices.max(axis=0)
    center = (min_pt + max_pt) / 2
    extent = max_pt - min_pt
    radius = np.linalg.norm(extent) * 0.6

    return min_pt, max_pt, center, extent, radius
