import k3d
import numpy as np
from typing import Optional

def k3d_version():
    """
    Returns the installed version of the k3d library.  

    Returns:
        str: The instaleld version of the k3d library. 
    """
    return k3d.__version__

def add_mesh_to_plot(
    mesh_vertices: np.ndarray,
    mesh_faces: np.ndarray,
    plot: k3d.plot,
    color: int = 0x00ffcc
) -> k3d.mesh:
    """
    Add a triangular mesh to a K3D plot.

    Args:
        mesh_vertices (np.ndarray): Nx3 array of vertex coordinates (x, y, z).
        mesh_faces (np.ndarray): Mx3 array of triangle vertex indices.
        plot_ (k3d.plot): The K3D plot object to which the mesh will be added.
        color (int, optional): RGB color of the mesh in 0xRRGGBB format. Defaults to 0x00ffcc.

    Returns:
        k3d.mesh: The K3D mesh object added to the plot.
    """
    # Flatten faces if necessary (K3D expects a 1D array of indices)
    faces_flat = mesh_faces.flatten()

    mesh_plot = k3d.mesh(
        mesh_vertices,
        faces_flat,
        color=color,
        opacity=1.0,
        wireframe=False,
        flat_shading=True
    )

    plot += mesh_plot
    return mesh_plot

def add_point_cloud_to_plot(
    points: np.ndarray,
    plot: k3d.plot,
    point_size: float = 0.15,
    opacity: float = 0.15,
    color: int = 0x00ffcc,
    shader: str = 'flat'
) -> k3d.points:
    """
    Add a 3D point cloud to a K3D plot.

    Args:
        points (np.ndarray): Nx3 array of points coordinates (x, y, z).
        plot (k3d.plot): The K3D plot object to which the point cloud will be added.
        point_size (float, optional): Size of the points. Defaults to 0.15.
        opacity (float, optional): Opacity of the points. Defaults to 0.15.
        color (int, optional): RGB color of the points in 0xRRGGBB format. Defaults to 0x00ffcc.
        shader (str, optional): Shader to use for rendering points ('flat', 'mesh', 'sphere', etc.). 
        Defaults to 'flat'.

    Returns:
        k3d.points: The K3D point cloud object added to the plot.
    """
    # Create point cloud object
    point_cloud_plot = k3d.points(
        points,
        point_size=point_size,
        color=color,
        opacity=opacity
    )

    # Set shader
    point_cloud_plot.shader = shader

    # Add to the plot
    plot += point_cloud_plot

    return point_cloud_plot
    
def add_mesh_point_cloud_to_plot(
    mesh_points: np.ndarray,
    plot: k3d.plot,
    point_size: float = 0.15,
    opacity: float = 0.15,
    color: int = 0x00ffcc,
    shader: str = 'flat'
) -> k3d.points:
    """
    Add a 3D point cloud representing mesh vertices to a K3D plot.

    Args:
        mesh_points (np.ndarray): Nx3 array of vertex coordinates (x, y, z).
        plot (k3d.plot): The K3D plot object to which the point cloud will be added.
        point_size (float, optional): Size of the points. Defaults to 0.15.
        opacity (float, optional): Opacity of the points. Defaults to 0.15.
        color (int, optional): RGB color of the points in 0xRRGGBB format. Defaults to 0x00ffcc.
        shader (str, optional): Shader to use for rendering points ('flat', 'mesh', 'sphere', etc.). 
        Defaults to 'flat'.

    Returns:
        k3d.points: The K3D point cloud object added to the plot.
    """
    # Create point cloud object
    point_cloud_plot = k3d.points(
        mesh_points,
        point_size=point_size,
        color=color,
        opacity=opacity
    )

    # Set shader
    point_cloud_plot.shader = shader

    # Add to the plot
    plot += point_cloud_plot

    return point_cloud_plot

def add_morphology_to_plot(
    morphology,
    plot: k3d.plot,
    line_color: int = 0x0000FF
) -> Optional[k3d.line]:
    """
    Add a neuronal morphology to a K3D plot as connected lines.

    Each section in the morphology is drawn as a line, with NaN separators
    to prevent connecting separate sections.

    Args:
        morphology: A morphology object containing sections with points.
                    Expected structure: morphology.morphology.sections,
                    where each section has a `.points` attribute as an array-like of (x, y, z[, r]).
        plot (k3d.plot): The K3D plot object to which the morphology lines will be added.
        line_color (int, optional): RGB color of the morphology lines in 0xRRGGBB format.
                                    Defaults to 0x0000FF (blue).

    Returns:
        k3d.line or None: The K3D line object added to the plot, or None if no valid sections exist.
    """
    all_points = []

    # Collect all section points, with NaN separators between sections
    for section in morphology.morphology.sections:
        pts = np.asarray(section.points)[:, :3].astype(np.float32)
        if pts.shape[0] < 2:  # skip sections with fewer than 2 points
            continue
        
        all_points.append(pts)
        
        # NaN separator to break the line between sections
        all_points.append(np.array([[np.nan, np.nan, np.nan]], dtype=np.float32))

    # Remove last NaN separator and concatenate
    if not all_points:
        return None

    all_points = all_points[:-1]
    vertices = np.vstack(all_points)

    # Add single line plot for all vertices
    line_plot = k3d.line(vertices, width=1.0, color=line_color, shader='simple')
    plot += line_plot

    return line_plot