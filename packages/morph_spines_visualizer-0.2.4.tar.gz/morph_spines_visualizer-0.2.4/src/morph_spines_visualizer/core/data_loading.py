import pyvista as pv 
import numpy as np 
import trimesh
import os 
import morph_spines 
from morph_spines_visualizer.utils import supress

def load_mesh_vertices_and_faces_trimesh(mesh_path: str, scale_factor: float = 1.0):
    """
    Load a triangular mesh using trimesh and return its vertices and faces.

    This function reads a mesh file (e.g., .obj, .ply, .stl) using trimesh,
    optionally scales it, and extracts the vertex coordinates and triangle indices
    in NumPy array format.

    Args:
        mesh_path (str): Path to the mesh file to load.
        scale_factor (float, optional): Scale factor to apply to the mesh coordinates.
            Defaults to 1.0.

    Returns:
        tuple[np.ndarray, np.ndarray]:
            - vertices (np.ndarray of shape (N, 3)): Vertex coordinates (x, y, z)
            - faces (np.ndarray of shape (M, 3)): Triangle vertex indices
    """
    # Load the mesh using trimesh
    mesh = trimesh.load(mesh_path, process=False)

    # Scale vertices if needed
    vertices = mesh.vertices * scale_factor
    faces = mesh.faces

    return vertices.astype(np.float32), faces.astype(np.uint32)


def load_mesh_vertices_trimesh(mesh_path: str, scale_factor: float = 1.0):
    """
    Load only the vertices of a mesh using trimesh.

    Args:
        mesh_path (str): Path to the mesh file.
        scale_factor (float, optional): Scale factor to apply to the mesh coordinates.
            Defaults to 1.0.

    Returns:
        np.ndarray: Vertex coordinates (Nx3) in float32.
    """
    mesh = trimesh.load(mesh_path, process=False)
    vertices = mesh.vertices * scale_factor
    return vertices.astype(np.float32)

def load_mesh_vertices_and_faces_pyvista(mesh_path: str, scale_factor: float = 1.0):
    """
    Load a triangular mesh using PyVista and return its vertices and faces.

    This function reads a mesh file (e.g., .obj, .ply, .stl, .vtu, etc.) using PyVista,
    optionally scales it, and extracts the vertex coordinates and triangle indices
    in NumPy array format. It is optimized for performance and simplicity compared
    to K3D’s data loading.

    Args:
        mesh_path (str): Path to the mesh file to load.
        scale_factor (float, optional): Scale factor to apply to the mesh coordinates.
            Defaults to 1.0.

    Returns:
        tuple[np.ndarray, np.ndarray]:
            - **vertices** (`np.ndarray` of shape `(N, 3)`): Array of vertex coordinates (x, y, z).
            - **faces** (`np.ndarray` of shape `(M, 3)`): Array of triangle vertex indices.
    """
    # Read mesh using PyVista
    mesh = pv.read(mesh_path)

    # Scale vertices if needed
    mesh.points *= scale_factor

    # Extract vertices and faces
    vertices = mesh.points.astype(np.float32)
    
    # PyVista stores faces as [n, v0, v1, v2, n, v0, v1, v2, ...]
    # So we reshape and drop the leading 'n' (number of vertices per face)
    faces = mesh.faces.reshape(-1, 4)[:, 1:4].astype(np.uint32)

    return vertices, faces

def load_mesh_vertices_pyvista(mesh_path: str, scale_factor: float = 1.0):
    """
    Load only the vertices of a mesh using PyVista.

    This function reads a mesh file (e.g., .obj, .ply, .stl, .vtu, etc.) using PyVista,
    optionally scales its coordinates, and returns the vertex positions as a NumPy array.
    It is lightweight and optimized for when face data is not needed.

    Args:
        mesh_path (str): Path to the mesh file to load.
        scale_factor (float, optional): Scale factor to apply to the mesh coordinates.
            Defaults to 1.0.

    Returns:
        np.ndarray:
            **vertices** (`np.ndarray` of shape `(N, 3)`): Array of vertex coordinates (x, y, z)
            in single precision (`float32`).
    """
    # Read mesh using PyVista
    mesh = pv.read(mesh_path)

    # Scale vertices if needed
    mesh.points *= scale_factor

    # Extract and convert vertices
    vertices = mesh.points.astype(np.float32)

    return vertices

def load_spiny_morphology(morphology_path: str):
    """
    Load a spiny neuronal morphology from a file using the morph-spine libaray.

    This function uses the morph_spines library to load a neuronal morphology
    that includes spines using the morph-spine library. 
    The morphology file can be in formats supported by morph_spines (e.g., .swc, .asc).

    Args:
        morphology_path (str): Path to the morphology file.
        
    Returns:
        morphology: A morphology object containing the spines.
    Raises:
        FileNotFoundError: If the morphology file does not exist at `morphology_path`.
        RuntimeError: If the morphology cannot be loaded by `morph_spines`.
    """
    if not os.path.exists(morphology_path):
        raise FileNotFoundError(f"Morphology file not found: {morphology_path}")
    
    # Load morphology using morph_spines
    try: 
        import warnings
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        warnings.filterwarnings("ignore", category=UserWarning)

        # To suppress the stdout/stderr output from morph_spines loading
        with supress.SuppressOutput():
            morphology = morph_spines.load_morphology_with_spines(morphology_path)
    except Exception as e:
        raise RuntimeError(f"Failed to load morphology from {morphology_path}: {e}")
    return morphology