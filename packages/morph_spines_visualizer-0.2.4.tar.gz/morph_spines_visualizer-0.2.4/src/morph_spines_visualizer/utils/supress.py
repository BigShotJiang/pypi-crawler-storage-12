import os

class SuppressOutput:
    def __enter__(self):
        self.null_fd = os.open(os.devnull, os.O_WRONLY)

        self.old_stdout = os.dup(1)
        self.old_stderr = os.dup(2)

        os.dup2(self.null_fd, 1)
        os.dup2(self.null_fd, 2)
        return self

    def __exit__(self, exc_type, exc, tb):
        os.dup2(self.old_stdout, 1)
        os.dup2(self.old_stderr, 2)

        os.close(self.null_fd)
        os.close(self.old_stdout)
        os.close(self.old_stderr)