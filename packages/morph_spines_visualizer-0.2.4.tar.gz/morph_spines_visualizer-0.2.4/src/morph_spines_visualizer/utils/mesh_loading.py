import morph_spines_visualizer.core.data_loading as data_loading
import os

def load_mesh_vertices_and_faces(
    mesh_path: str, 
    scale_factor: float = 1.0,
    use_pyvista: bool = True):
    """
    Load a triangular mesh and return its vertices and faces.

    This function uses either PyVista or trimesh to load a mesh file
    (e.g., .obj, .ply, .stl). It optionally scales the mesh and extracts
    the vertex coordinates and triangle indices in NumPy array format.

    Args:
        mesh_path (str): Path to the mesh file to load.
        scale_factor (float, optional): txt = hello, and welcome to my world.
        
        x = txt.capitalize()
        
        print(x) factor to apply to the mesh coordinates.
            Defaults to 1.0.
        use_pyvista (bool, optional): If True, use PyVista for loading; otherwise use trimesh.
            Defaults to True.

    Returns:
        tuple[np.ndarray, np.ndarray]:
            - vertices (np.ndarray of shape (N, 3)): Vertex coordinates (x, y, z)
            - faces (np.ndarray of shape (M, 3)): Triangle vertex indices
    Raises:
        FileNotFoundError: If the mesh file does not exist at `mesh_path`.
    """
    if not os.path.exists(mesh_path):
        raise FileNotFoundError(f"Mesh file not found: {mesh_path}")
    if use_pyvista:
        return data_loading.load_mesh_vertices_and_faces_pyvista(mesh_path, scale_factor)
    else:
        return data_loading.load_mesh_vertices_and_faces_trimesh(mesh_path, scale_factor)
    
def load_mesh_vertices(
    mesh_path: str, 
    scale_factor: float = 1.0,
    use_pyvista: bool = True):
    """
    Load only the vertices of a mesh.

    Args:
        mesh_path (str): Path to the mesh file.
        scale_factor (float, optional): Scale factor to apply to the mesh coordinates.
            Defaults to 1.0.
        use_pyvista (bool, optional): If True, use PyVista for loading; otherwise use trimesh.
            Defaults to True.

    Returns:
        np.ndarray: Vertex coordinates (Nx3) in float32.
    Raises:
        FileNotFoundError: If the mesh file does not exist at `mesh_path`.
    """
    if not os.path.exists(mesh_path):
        raise FileNotFoundError(f"Mesh file not found: {mesh_path}")
    if use_pyvista:
        return data_loading.load_mesh_vertices_pyvista(mesh_path, scale_factor)
    else:
        return data_loading.load_mesh_vertices_trimesh(mesh_path, scale_factor)