Changelog
=========

Version 0.2.2
-----------
- Fixing minor bugs in the codebase.

Version 0.2.1
-----------
- Removing unwanted warning.

Version 0.1.0
-----------

- Adding the initial changelog file.
- Initial release of the project.