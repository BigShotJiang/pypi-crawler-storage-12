## Introduction

morph-spine-vislizaer is a mini-package to visualize morphologies with spines.


## Installation

The package can be installed through `pip`.


## Examples

See `examples` folder for usage examples.


Copyright (c) 2025 Open Brain Institute
