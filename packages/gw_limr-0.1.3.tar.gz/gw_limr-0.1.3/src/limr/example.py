def greet(name:str):
    return f"Hello, {name}! new version"
