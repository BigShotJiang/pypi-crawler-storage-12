class VideoChooser extends window.SnippetChooser {
    titleStateKey = 'string';

    chooserModalClass = window.VideoChooserModal;
}

window.VideoChooser = VideoChooser;
