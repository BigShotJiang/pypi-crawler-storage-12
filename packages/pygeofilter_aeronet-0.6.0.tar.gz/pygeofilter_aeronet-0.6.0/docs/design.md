# AERONET Client software design

## Class Diagram

![file](diagrams/out/class.svg)
