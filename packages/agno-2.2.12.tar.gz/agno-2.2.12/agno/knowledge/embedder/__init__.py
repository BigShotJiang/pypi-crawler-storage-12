from agno.knowledge.embedder.base import Embedder

__all__ = [
    "Embedder",
]
