"""Entry-point for `python -m codexpp`."""

from .cli import main


if __name__ == "__main__":
    main()

