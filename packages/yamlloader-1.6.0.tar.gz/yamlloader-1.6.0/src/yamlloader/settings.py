"""Global settings for the behavior of the module."""

from __future__ import annotations

ALLOW_NON_C_FALLBACK = True
