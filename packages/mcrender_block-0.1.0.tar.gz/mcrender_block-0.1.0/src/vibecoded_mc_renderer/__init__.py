"""VibeCoded Minecraft Renderer - Render Minecraft blocks from jar files."""

__version__ = "0.1.0"
__author__ = "VibeCoded"
