""" 
GBIF collection APIs methods

* `search`: Search for collections in GRSciColl

"""

from .search import search
