__version__ = "0.6.6"
__title__ = "pygbif"
__author__ = "Scott Chamberlain"
__license__ = "MIT"
