""" 
GBIF literature APIs methods

* `search`: Search for literature indexed by GBIF

"""

from .search import search
