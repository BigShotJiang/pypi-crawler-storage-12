""" 
GBIF institution APIs methods

* `search`: Search for institutions in GRSciColl

"""

from .search import search
