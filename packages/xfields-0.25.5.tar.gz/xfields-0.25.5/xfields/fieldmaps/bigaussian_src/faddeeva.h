// copyright ################################# //
// This file is part of the Xfields Package.   //
// Copyright (c) CERN, 2021.                   //
// ########################################### //

#ifndef XFIELDS_FADDEEVA_H
#define XFIELDS_FADDEEVA_H

//include_file faddeeva_cernlib.h for_context opencl cuda cpu_openmp
//include_file faddeeva_mit.h for_context cpu_serial

#endif /* XFIELDS_FADDEEVA_H */

