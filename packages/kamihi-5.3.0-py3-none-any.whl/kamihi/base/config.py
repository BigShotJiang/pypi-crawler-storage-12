"""
Configuration module.

This module contains the configuration settings for the Kamihi framework. The configuration settings are loaded from
environment variables and/or a `.env` file. They must begin with the prefix `KAMIHI_`.

License:
    MIT

"""

import os
from enum import StrEnum
from pathlib import Path

import pytz
import yaml
from pydantic import BaseModel, Field, field_validator
from pydantic_extra_types.timezone_name import TimeZoneName
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    YamlConfigSettingsSource,
)
from pytz.tzinfo import DstTzInfo

from kamihi.datasources import DataSourceConfig


class LogLevel(StrEnum):
    """
    Enum for log levels.

    This enum defines the log levels used in the logging configuration.

    Attributes:
        TRACE: Trace level logging.
        DEBUG: Debug level logging.
        INFO: Info level logging.
        SUCCESS: Success level logging.
        WARNING: Warning level logging.
        ERROR: Error level logging.
        CRITICAL: Critical level logging.

    """

    TRACE = "TRACE"
    DEBUG = "DEBUG"
    INFO = "INFO"
    SUCCESS = "SUCCESS"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class LogSettings(BaseModel):
    """
    Defines the logging configuration schema.

    Attributes:
        stdout_enable (bool): Enable or disable stdout logging.
        stdout_level (str): Log level for stdout logging.
        stdout_serialize (bool): Enable or disable serialization for stdout logging.

        stderr_enable (bool): Enable or disable stderr logging.
        stderr_level (str): Log level for stderr logging.
        stderr_serialize (bool): Enable or disable serialization for stderr logging.

        file_enable (bool): Enable or disable file logging.
        file_level (str): Log level for file logging.
        file_path (str): Path to the log file.
        file_serialize (bool): Enable or disable serialization for file logging.
        file_rotation (str): Rotation policy for the log file.
        file_retention (str): Retention policy for the log file.

        notification_enable (bool): Enable or disable notification logging.
        notification_level (str): Log level for notification logging.
        notification_urls (list[str]): List of URLs for notification services.

    """

    stdout_enable: bool = Field(default=True)
    stdout_level: LogLevel = LogLevel.INFO
    stdout_serialize: bool = Field(default=False)

    stderr_enable: bool = Field(default=False)
    stderr_level: LogLevel = LogLevel.ERROR
    stderr_serialize: bool = Field(default=False)

    file_enable: bool = Field(default=False)
    file_level: LogLevel = LogLevel.DEBUG
    file_path: str = Field(default="kamihi.log")
    file_serialize: bool = Field(default=False)
    file_rotation: str = Field(default="1 MB")
    file_retention: str = Field(default="7 days")

    notification_enable: bool = Field(default=False)
    notification_level: LogLevel = LogLevel.SUCCESS
    notification_urls: list[str] = Field(default_factory=list)


class ResponseSettings(BaseModel):
    """
    Defines the response settings schema.

    Attributes:
        default_enabled(bool): Whether to enable the default message
        default_message(str): The message to return when no handler has been triggered
        error_message(str): The message to send to the user when an error happens
        cancel_command(str): The command to cancel an ongoing operation
        cancel_message(str): The message to send when an operation is cancelled

    """

    default_enabled: bool = Field(default=True)
    default_message: str = Field(default="I'm sorry, but I don't know how to respond to that")
    error_message: str = Field(default="An error occurred while processing your request, please try again later")
    cancel_command: str = Field(default="cancel")
    cancel_message: str = Field(default="Operation cancelled")


class QuestionSettings(BaseModel):
    """
    Defines the question settings schema.

    Attributes:
        timeout (int): The timeout for questions in seconds.

    """

    timeout: int = Field(default=300)

    bool_error_text: str = Field(default="Please answer with yes or no.")
    bool_true_values: set[str] = Field(default_factory=lambda: {"yes", "y", "true", "t", "1"})
    bool_false_values: set[str] = Field(default_factory=lambda: {"no", "n", "false", "f", "0"})

    integer_error_text: str = Field(default="Please enter a valid integer.")

    string_error_text: str = Field(default="Please enter a valid string.")

    datetime_error_text: str = Field(default="Please enter a valid date and time.")

    date_error_text: str = Field(default="Please enter a valid date.")

    time_error_text: str = Field(default="Please enter a valid time.")

    choice_error_text: str = Field(default="Please select a valid option.")

    dynamic_choice_error_text: str = Field(default="Please select a valid option.")

    remove_keyboard_text: str = Field(default="Removing keyboard...")


class WebSettings(BaseModel):
    """
    Defines the web settings schema.

    Attributes:
        host (str): The host of the web interface.
        port (int): The port of the web interface.

    """

    host: str = Field(default="localhost")
    port: int = Field(default=4242)


class DatabaseSettings(BaseModel):
    """
    Defines the database settings schema.

    Attributes:
        url (str): The database connection URL.

    """

    url: str = Field(default="sqlite:///kamihi.db")
    pages_expiration_days: int | float = Field(default=7)


class JobSettings(BaseModel):
    """
    Defines the job settings schema.

    Attributes:
        enabled (bool): Whether to enable job scheduling.

    """

    enabled: bool = Field(default=False)


class KamihiSettings(BaseSettings):
    """
    Defines the configuration schema for the Kamihi framework.

    Attributes:
        timezone (str): The timezone for the application.
        log (LogSettings): The logging settings.
        db (DatabaseSettings): The database settings.
        token (str | None): The Telegram bot token.
        responses (ResponseSettings): The response settings.
        web (WebSettings): The web settings.

    """

    # General settings
    testing: bool = Field(default=False)
    timezone: TimeZoneName = Field(default="UTC", validate_default=True)

    # Logging settings
    log: LogSettings = Field(default_factory=LogSettings)

    # Database settings
    db: DatabaseSettings = Field(default_factory=DatabaseSettings)

    # Datasources settings
    datasources: list[DataSourceConfig.union_type()] = Field(default_factory=list)

    # Telegram settings
    token: str | None = Field(default=None, pattern=r"^\d+:[0-9A-Za-z_-]{35}$", exclude=True)
    responses: ResponseSettings = Field(default_factory=ResponseSettings)

    # Questions settings
    questions: QuestionSettings = Field(default_factory=QuestionSettings)

    # Web settings
    web: WebSettings = Field(default_factory=WebSettings)

    # Job settings
    jobs: JobSettings = Field(default_factory=JobSettings)

    @property
    def timezone_obj(self) -> DstTzInfo:
        """
        Get the timezone object.

        Returns:
            DstTzInfo: The timezone object.

        """
        return pytz.timezone(self.timezone)

    @field_validator("datasources", mode="after")
    @classmethod
    def _validate_datasources(cls, value: list[DataSourceConfig]) -> list[DataSourceConfig]:
        """Check if all datasources have unique names."""
        names = [ds.name for ds in value]
        if len(names) != len(set(names)):
            raise ValueError("Datasources must have unique names.")
        return value

    model_config = SettingsConfigDict(
        env_prefix="KAMIHI_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
        env_nested_delimiter="__",
        yaml_file="kamihi.yaml",
    )

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,  # skipcq: PYL-W0621
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        """
        Customize the order of settings sources.

        This method allows you to customize the order in which settings sources are
        loaded. The order of sources is important because it determines which settings
        take precedence when there are conflicts.
        The order of sources is as follows:
            1. Environment variables
            2. .env file
            3. YAML file
            4. Initial settings

        Args:
            settings_cls: the settings class to customize sources for
            init_settings: settings from class initialization
            env_settings: settings from environment variables
            dotenv_settings: settings from .env file
            file_secret_settings: settings from file secrets

        Returns:
            tuple: A tuple containing the customized settings sources in the desired order.

        """
        return (
            init_settings,
            env_settings,
            dotenv_settings,
            YamlConfigSettingsSource(
                settings_cls,
                yaml_file=[
                    os.getenv("KAMIHI_CONFIG_FILE", "kamihi.yaml"),
                    "kamihi.yaml",
                    "kamihi.yml",
                ],
            ),
            file_secret_settings,
        )

    @classmethod
    def from_yaml(cls, path: Path) -> "KamihiSettings":
        """
        Load settings from a custom YAML file.

        Args:
            path (Path): The path to the YAML file.

        Returns:
            KamihiSettings: An instance of KamihiSettings with the loaded settings.

        """
        if path.exists() and path.is_file():
            with path.open("r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
            if data and isinstance(data, dict):
                return cls(**data)
        return cls()


_settings: KamihiSettings | None = None


def init_settings(path: Path | None = None) -> None:
    """
    Initialize the global settings instance.

    Args:
        path (Path | None): Optional path to a YAML configuration file.

    """
    global _settings  # skipcq: PYL-W0603
    if _settings is None:
        _settings = KamihiSettings.from_yaml(path) if path else KamihiSettings()


def get_settings() -> KamihiSettings:
    """Get the global settings instance."""
    if _settings is None:
        raise RuntimeError("Settings not initialized. Call init_settings() first.")
    return _settings
