"""
Web interface module for Kamihi.

License:
    MIT

"""

from .web import KamihiWeb

__all__ = ["KamihiWeb"]
