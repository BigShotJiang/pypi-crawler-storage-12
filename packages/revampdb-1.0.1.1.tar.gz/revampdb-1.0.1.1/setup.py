from setuptools import setup, find_packages

setup(
    name='revampDB',
    version='1.0.1.1',
    author='MrNarrow',
    description="An Easiest Atomic Database",
    long_description_content_type="text/markdown",
    long_description="""
    
## RevampDB: Easiest Atomic Database

RevampDB is a minimalist and robust Python utility class designed for **simple, persistent key-value storage**. It enables developers to quickly save and retrieve data to a local file, serving as an ideal lightweight database replacement for small-scale applications, configuration management, or caching layers.

![Static Badge](https://img.shields.io/badge/downloads-1k-green)

### Core Modes & Serialization

The class offers two distinct operational modes for handling data serialization:

1.  **Pickle Mode (`mode=False`, Default):**

      * Utilizes the standard Python `pickle` module.
      * Provides **efficient serialization** of complex Python objects (e.g., custom classes, complex nested structures).
      * Files are **non-human-readable** and are best for internal application use.

2.  **Json Mode (`mode=True`):**

      * Utilizes the built-in `json` module.
      * Ensures data is **human-readable**, easily shareable, and portable across different systems or languages.
      * Requires data to be composed of standard JSON-compatible types (lists, dictionaries, strings, numbers, boolean, null).

### Key Features

  * **Simple API:** Offers intuitive methods (`WriteDatabase`, `ReadDatabase`, etc.) for managing data and the underlying file.
  * **Dual Format Support:** Seamlessly handles both `pickle` (binary) and `json` (text) formats based on the initialization mode.
  * **Atomic Write Operation:** Guarantees **data integrity** by utilizing a temporary file during the write process. After the data has been fully and successfully written, preventing file corruption upon interruption.
  * **Optional Logging:** Provides clear console output to track successful write and delete operations when enabled (`logging=True`).

### Installation & Usage

#### Installation

If packaged on PyPI, installation is standard:

```bash
pip install revampDB
```

*(Note: As a single-file class, you may also integrate the source file directly into your project.)*

#### Usage Example

```python
from revampDB import database # Assuming the class is named 'database' in your module

# 1. JSON Mode (mode=True)
db_config = database("config.json", mode=True, logging=True)
db_config.WriteDatabase({"username": "alice", "email": "a@example.com"}, cell="user_profile")

# Retrieve and print specific data
profile = db_config.ReadDatabase("user_profile")
print(f"User Profile: {profile}") 
# Output: User Profile: {'username': 'alice', 'email': 'a@example.com'}

# 2. Pickle Mode (mode=False) - suitable for complex objects
db_cache = database("data.dat", mode=False)
db_cache.WriteDatabase([1, 2, 3, {'a': 1}], cell="data_list")

# Read entire database contents
all_data = db_cache.ReadEntireDatabase()
print(f"All Data: {all_data}")
# Output: All Data: {'data_list': [1, 2, 3, {'a': 1}]}
```""",

    packages=find_packages(),
)