# let's wait for the blockchain to have the min confirmation blocks
# this will wait for last deployed transaction + blockchain.min_confirmations
transaction.blockchain.wait()
