from django.apps import AppConfig


class DjwebdappEthereumConfig(AppConfig):
    name = 'djwebdapp_ethereum'
