from django.apps import AppConfig


class DjwebdappRestFrameworkConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'djwebdapp_rest_framework'
