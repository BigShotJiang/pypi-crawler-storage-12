from django.apps import AppConfig


class MultisigConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'djwebdapp_multisig'
