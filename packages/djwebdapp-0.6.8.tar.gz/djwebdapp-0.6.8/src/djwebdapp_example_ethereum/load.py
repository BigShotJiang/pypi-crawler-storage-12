bytecode = open('src/djwebdapp_example_ethereum/contracts/FA12.bin', 'r').read()
abi = open('src/djwebdapp_example_ethereum/contracts/FA12.abi', 'r').read()
