AIRFLOW_DEPENDENCIES_KEY = "airflowDependencies"
AIRFLOW_LABEL_DEPENDENCIES_KEY = "airflowLabelDependencies"
PARTITION_COLUMN_KEY = "spark.chronon.partition.column"
