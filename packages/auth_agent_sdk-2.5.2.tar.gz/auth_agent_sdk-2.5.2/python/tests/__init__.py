"""
Tests for Auth Agent SDK
"""



