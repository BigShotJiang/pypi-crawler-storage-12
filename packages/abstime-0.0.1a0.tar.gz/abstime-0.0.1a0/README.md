# abstime

Early alpha placeholder for the upcoming **abstime** project.

```python
from abstime import ping
print(ping())
This package currently only contains a placeholder function to keep the name reserved on PyPI.
```

 