__version__ = "0.0.1a0"

def ping() -> str:
    """Placeholder to reserve the package name."""
    return "abstime is reserved. Coming soon!"
