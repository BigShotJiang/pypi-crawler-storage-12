## cdf 

### Changed

- [alpha] The clean command requires the module name to be passed as a
parameter. If not, the user will be prompted to select modules
interactively.

## templates

No changes.