//! No fixed size [`OctetString`](struct@crate::types::octet_string).
