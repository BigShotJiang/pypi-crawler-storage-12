"""
QuerySUTRA v0.3.3 - PROPER RELATIONAL DATABASE EXTRACTION
SUTRA: Structured-Unstructured-Text-Retrieval-Architecture

FIXED: Proper primary keys, foreign keys, and relational integrity
- Unique IDs for each entity
- Proper foreign key relationships
- No duplicate keys
- Comprehensive entity extraction (skills, technologies, projects, etc.)

Author: Aditya Batta
License: MIT
Version: 0.3.3
"""

__version__ = "0.3.3"
__author__ = "Aditya Batta"
__title__ = "QuerySUTRA: Structured-Unstructured-Text-Retrieval-Architecture"
__all__ = ["SUTRA", "QueryResult", "quick_start"]

import os
import sqlite3
import pandas as pd
import numpy as np
from typing import Optional, Union, Dict, Any, List
from pathlib import Path
import json
import hashlib
import warnings
import shutil
import datetime
import re
from io import StringIO
from difflib import get_close_matches
warnings.filterwarnings('ignore')

try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

try:
    import plotly.express as px
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

try:
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

try:
    import PyPDF2
    HAS_PYPDF2 = True
except ImportError:
    HAS_PYPDF2 = False

try:
    import docx
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False

try:
    from sentence_transformers import SentenceTransformer
    HAS_EMBEDDINGS = True
except ImportError:
    HAS_EMBEDDINGS = False


class SUTRA:
    """
    SUTRA: Structured-Unstructured-Text-Retrieval-Architecture
    
    Professional data analysis with proper relational database structure
    """
    
    def __init__(self, 
                 api_key: Optional[str] = None, 
                 db: str = "sutra.db",
                 use_embeddings: bool = False,
                 check_relevance: bool = False,
                 fuzzy_match: bool = True,
                 cache_queries: bool = True):
        """Initialize SUTRA with optional features."""
        print("Initializing QuerySUTRA v0.3.3")
        print("SUTRA: Structured-Unstructured-Text-Retrieval-Architecture")
        
        if api_key:
            os.environ["OPENAI_API_KEY"] = api_key
        
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.client = OpenAI(api_key=self.api_key) if self.api_key and HAS_OPENAI else None
        
        self.db_path = db
        self.conn = sqlite3.connect(db, check_same_thread=False)
        self.cursor = self.conn.cursor()
        
        self.current_table = None
        self.schema_info = {}
        
        self.cache_queries = cache_queries
        self.cache = {} if cache_queries else None
        
        self.use_embeddings = use_embeddings
        self.embedding_model = None
        self.query_embeddings = {}
        
        self.check_relevance = check_relevance
        self.fuzzy_match = fuzzy_match
        
        if use_embeddings and HAS_EMBEDDINGS:
            try:
                print("Loading embeddings model...")
                self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
                print("Embeddings ready")
            except:
                print("Embeddings unavailable")
                self.use_embeddings = False
        
        self._refresh_schema()
        
        print(f"Ready! Database: {db}")
        if not self.api_key:
            print("No API key - use .sql() for direct queries")
    
    @classmethod
    def load_from_db(cls, db_path: str, api_key: Optional[str] = None, **kwargs):
        """Load existing SQLite database."""
        if not Path(db_path).exists():
            raise FileNotFoundError(f"Database not found: {db_path}")
        
        print(f"Loading database: {db_path}")
        instance = cls(api_key=api_key, db=db_path, **kwargs)
        
        tables = instance.tables()
        print(f"Loaded {len(tables)} tables")
        
        return instance
    
    @classmethod
    def connect_mysql(cls, host: str, user: str, password: str, database: str,
                     port: int = 3306, api_key: Optional[str] = None, **kwargs):
        """Connect to MySQL database."""
        try:
            from sqlalchemy import create_engine
        except ImportError:
            raise ImportError("Run: pip install QuerySUTRA[mysql]")
        
        print(f"Connecting to MySQL: {host}:{port}/{database}")
        
        connection_string = f"mysql+mysqlconnector://{user}:{password}@{host}:{port}/{database}"
        
        temp_db = f"sutra_mysql_{database}.db"
        instance = cls(api_key=api_key, db=temp_db, **kwargs)
        
        engine = create_engine(connection_string)
        
        tables = pd.read_sql_query("SHOW TABLES", engine).iloc[:, 0].tolist()
        
        print(f"Found {len(tables)} tables, syncing...")
        
        for table in tables:
            df = pd.read_sql_query(f"SELECT * FROM {table}", engine)
            df.to_sql(table, instance.conn, if_exists='replace', index=False)
            print(f"  {table}: {len(df)} rows")
        
        instance._refresh_schema()
        print(f"Connected! {len(tables)} tables available")
        
        return instance
    
    @classmethod
    def connect_postgres(cls, host: str, user: str, password: str, database: str,
                        port: int = 5432, api_key: Optional[str] = None, **kwargs):
        """Connect to PostgreSQL database."""
        try:
            from sqlalchemy import create_engine
        except ImportError:
            raise ImportError("Run: pip install QuerySUTRA[postgres]")
        
        print(f"Connecting to PostgreSQL: {host}:{port}/{database}")
        
        connection_string = f"postgresql://{user}:{password}@{host}:{port}/{database}"
        
        temp_db = f"sutra_postgres_{database}.db"
        instance = cls(api_key=api_key, db=temp_db, **kwargs)
        
        engine = create_engine(connection_string)
        
        tables = pd.read_sql_query(
            "SELECT tablename FROM pg_tables WHERE schemaname='public'", 
            engine
        )['tablename'].tolist()
        
        print(f"Found {len(tables)} tables, syncing...")
        
        for table in tables:
            df = pd.read_sql_query(f"SELECT * FROM {table}", engine)
            df.to_sql(table, instance.conn, if_exists='replace', index=False)
            print(f"  {table}: {len(df)} rows")
        
        instance._refresh_schema()
        print(f"Connected! {len(tables)} tables available")
        
        return instance
    
    def upload(self, data: Union[str, pd.DataFrame], name: Optional[str] = None, 
               extract_entities: Optional[List[str]] = None) -> 'SUTRA':
        """
        Upload data with optional custom entity extraction.
        
        Args:
            data: File path or DataFrame
            name: Table name
            extract_entities: Custom entities to extract (e.g., ['skills', 'technologies'])
        """
        print(f"\nUploading data...")
        
        if isinstance(data, pd.DataFrame):
            name = name or "data"
            self._store_dataframe(data, name)
            return self
        
        path = Path(data)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {data}")
        
        name = name or path.stem.replace(" ", "_").replace("-", "_")
        ext = path.suffix.lower()
        
        print(f"File: {path.name}")
        
        if ext == ".csv":
            df = pd.read_csv(path)
            self._store_dataframe(df, name)
        
        elif ext in [".xlsx", ".xls"]:
            df = pd.read_excel(path)
            self._store_dataframe(df, name)
        
        elif ext == ".json":
            df = pd.read_json(path)
            self._store_dataframe(df, name)
        
        elif ext == ".sql":
            with open(path) as f:
                self.cursor.executescript(f.read())
            self.conn.commit()
            self._refresh_schema()
            print("SQL executed")
        
        elif ext == ".pdf":
            self._smart_upload_pdf(path, name, extract_entities)
        
        elif ext == ".docx":
            self._smart_upload_docx(path, name, extract_entities)
        
        elif ext == ".txt":
            self._smart_upload_txt(path, name, extract_entities)
        
        else:
            raise ValueError(f"Unsupported format: {ext}")
        
        return self
    
    def _smart_upload_pdf(self, path: Path, base_name: str, extract_entities: Optional[List[str]] = None):
        """Parse PDF with proper relational structure."""
        if not HAS_PYPDF2:
            raise ImportError("Run: pip install PyPDF2")
        
        print("Extracting text from PDF...")
        
        with open(path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            text = ""
            for page_num, page in enumerate(pdf_reader.pages, 1):
                text += page.extract_text() + "\n"
                print(f"  Page {page_num}/{len(pdf_reader.pages)}")
        
        if self.client:
            print("AI: Comprehensive entity extraction with proper relationships...")
            tables = self._create_tables_with_ai(text, base_name, extract_entities)
            
            if tables and len(tables) > 0:
                print(f"\nCreated {len(tables)} relational tables:")
                for tbl_name in tables:
                    count = pd.read_sql_query(f"SELECT COUNT(*) FROM {tbl_name}", self.conn).iloc[0, 0]
                    cols = len(self.schema_info.get(tbl_name, {}))
                    print(f"  {tbl_name}: {count} rows, {cols} columns")
                return
        
        print("AI unavailable, creating simple table")
        df = self._parse_text_simple(text)
        self._store_dataframe(df, base_name)
    
    def _smart_upload_docx(self, path: Path, base_name: str, extract_entities: Optional[List[str]] = None):
        """Parse DOCX with proper structure."""
        if not HAS_DOCX:
            raise ImportError("Run: pip install python-docx")
        
        print("Extracting from DOCX...")
        
        doc = docx.Document(path)
        
        if doc.tables:
            print(f"Found {len(doc.tables)} table(s)")
            for i, table in enumerate(doc.tables):
                data = [[cell.text.strip() for cell in row.cells] for row in table.rows]
                if data and len(data) > 1:
                    df = pd.DataFrame(data[1:], columns=data[0])
                    table_name = f"{base_name}_table_{i+1}" if len(doc.tables) > 1 else base_name
                    self._store_dataframe(df, table_name)
            return
        
        text = "\n".join([para.text for para in doc.paragraphs])
        
        if self.client:
            print("AI: Analyzing...")
            tables = self._create_tables_with_ai(text, base_name, extract_entities)
            
            if tables and len(tables) > 0:
                print(f"\nCreated {len(tables)} tables:")
                for tbl_name in tables:
                    count = pd.read_sql_query(f"SELECT COUNT(*) FROM {tbl_name}", self.conn).iloc[0, 0]
                    cols = len(self.schema_info.get(tbl_name, {}))
                    print(f"  {tbl_name}: {count} rows, {cols} columns")
                return
        
        df = self._parse_text_simple(text)
        self._store_dataframe(df, base_name)
    
    def _smart_upload_txt(self, path: Path, base_name: str, extract_entities: Optional[List[str]] = None):
        """Parse TXT with proper structure."""
        print("Reading TXT...")
        
        with open(path, 'r', encoding='utf-8') as file:
            text = file.read()
        
        if self.client:
            print("AI: Analyzing...")
            tables = self._create_tables_with_ai(text, base_name, extract_entities)
            
            if tables and len(tables) > 0:
                print(f"\nCreated {len(tables)} tables:")
                for tbl_name in tables:
                    count = pd.read_sql_query(f"SELECT COUNT(*) FROM {tbl_name}", self.conn).iloc[0, 0]
                    cols = len(self.schema_info.get(tbl_name, {}))
                    print(f"  {tbl_name}: {count} rows, {cols} columns")
                return
        
        df = self._parse_text_simple(text)
        self._store_dataframe(df, base_name)
    
    def _create_tables_with_ai(self, text: str, base_name: str, custom_entities: Optional[List[str]] = None) -> List[str]:
        """
        AI extracts ALL entities with PROPER primary and foreign keys.
        
        CRITICAL: Each entity gets UNIQUE IDs, foreign keys properly link tables.
        """
        if not self.client:
            return []
        
        try:
            if custom_entities:
                entity_instruction = f"""Extract these specific entities: {', '.join(custom_entities)}
For each entity type, create a proper table with unique IDs."""
            else:
                entity_instruction = """Automatically identify and extract ALL structured entities.

Common entities (extract ALL you find):
- people: Personal information (id, name, email, phone, address, city, state, zip)
- skills: Individual skills (id, person_id, skill_name, proficiency_level, years_experience)
- technologies: Technologies/tools (id, person_id, technology_name, category, proficiency)
- projects: Projects (id, person_id, project_name, description, start_date, end_date)
- certifications: Certifications (id, person_id, cert_name, issuer, date_obtained)
- education: Education records (id, person_id, degree, institution, graduation_year)
- work_experience: Work history (id, person_id, company, title, start_date, end_date)
- events: Events/meetings (id, host_id, description, location, date, attendee_ids)
- organizations: Companies/departments (id, name, address, city, industry)
- products: Products/services (id, name, description, price, category)
- ANY other structured entities you identify

Extract EVERYTHING you find in the text."""

            extraction_prompt = f"""Analyze this text and extract ALL structured data into proper relational database tables.

Text:
{text[:6000]}

{entity_instruction}

CRITICAL REQUIREMENTS FOR PROPER DATABASE DESIGN:

1. PRIMARY KEYS:
   - Each table MUST have unique sequential IDs starting from 1
   - Person 1 gets id=1, Person 2 gets id=2, etc.
   - NO DUPLICATE IDs within same table
   - IDs must be integers

2. FOREIGN KEYS:
   - Use foreign keys to link related tables
   - Example: skills table has person_id that references people.id
   - Example: projects table has person_id that references people.id
   - Foreign keys MUST match existing primary keys

3. TABLE STRUCTURE:
   - Each entity type gets its own table
   - Use clear table names (people, skills, technologies, not table1, table2)
   - Include ALL relevant attributes for each entity

Return JSON with this EXACT structure:
{{
  "people": [
    {{"id": 1, "name": "John Doe", "email": "john@email.com", "phone": "+1-555-0100", "city": "Dallas", "state": "TX"}},
    {{"id": 2, "name": "Jane Smith", "email": "jane@email.com", "phone": "+1-555-0101", "city": "New York", "state": "NY"}},
    ...
  ],
  "skills": [
    {{"id": 1, "person_id": 1, "skill_name": "Python", "proficiency": "Expert", "years": 5}},
    {{"id": 2, "person_id": 1, "skill_name": "SQL", "proficiency": "Advanced", "years": 3}},
    {{"id": 3, "person_id": 2, "skill_name": "Java", "proficiency": "Expert", "years": 7}},
    ...
  ],
  "technologies": [
    {{"id": 1, "person_id": 1, "technology": "React", "category": "Frontend"}},
    {{"id": 2, "person_id": 1, "technology": "PostgreSQL", "category": "Database"}},
    {{"id": 3, "person_id": 2, "technology": "Spring Boot", "category": "Backend"}},
    ...
  ],
  "projects": [
    {{"id": 1, "person_id": 1, "project_name": "E-commerce Platform", "role": "Lead Developer"}},
    {{"id": 2, "person_id": 2, "project_name": "Analytics Dashboard", "role": "Backend Engineer"}},
    ...
  ]
}}

IMPORTANT:
- Extract EVERY structured piece of data you find
- Assign UNIQUE sequential IDs (1, 2, 3, ...) for each table
- Foreign keys MUST reference valid primary keys
- Create as many tables as needed (don't limit yourself)
- Return ONLY valid JSON, no explanations
- Be COMPREHENSIVE - extract skills, technologies, projects, certifications, education, work history, etc."""

            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a database design expert. Extract ALL entities with proper primary keys (unique sequential IDs) and foreign keys (referencing valid IDs). Be comprehensive and extract EVERYTHING. Return only valid JSON."},
                    {"role": "user", "content": extraction_prompt}
                ],
                temperature=0,
                max_tokens=4096
            )
            
            json_text = response.choices[0].message.content.strip()
            json_text = json_text.replace("```json", "").replace("```", "").strip()
            
            extracted_data = json.loads(json_text)
            
            created_tables = []
            
            for entity_type, records in extracted_data.items():
                if records and isinstance(records, list) and len(records) > 0:
                    table_name = f"{base_name}_{entity_type}"
                    
                    try:
                        df = pd.DataFrame(records)
                        if not df.empty:
                            self._store_dataframe(df, table_name, silent=True)
                            created_tables.append(table_name)
                            print(f"  {entity_type}: {len(df)} records")
                    except Exception as e:
                        print(f"  Failed {entity_type}: {e}")
            
            return created_tables
        
        except Exception as e:
            print(f"AI extraction error: {e}")
            return []
    
    def _parse_text_simple(self, text: str) -> pd.DataFrame:
        """Fallback text parsing."""
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        
        if not lines:
            return pd.DataFrame({'content': ['No content']})
        
        sample = lines[:min(10, len(lines))]
        for delimiter in ['\t', ',', '|', ';']:
            if all(delimiter in line for line in sample):
                try:
                    df = pd.read_csv(StringIO('\n'.join(lines)), sep=delimiter)
                    if len(df.columns) > 1:
                        return df
                except:
                    continue
        
        return pd.DataFrame({
            'line_number': range(1, len(lines) + 1),
            'content': lines
        })
    
    def _store_dataframe(self, df: pd.DataFrame, name: str, silent: bool = False):
        """Store DataFrame."""
        df.columns = [str(c).strip().replace(" ", "_").replace("-", "_") for c in df.columns]
        df.to_sql(name, self.conn, if_exists='replace', index=False)
        self.current_table = name
        self._refresh_schema()
        
        if not silent:
            print(f"Uploaded: {name}")
            print(f"  {len(df)} rows, {len(df.columns)} columns")
    
    def ask(self, question: str, viz: Union[bool, str] = False, table: Optional[str] = None) -> 'QueryResult':
        """Query with natural language."""
        if not self.client:
            print("No API key")
            return QueryResult(False, "", pd.DataFrame(), None, "No API key")
        
        print(f"\nQuestion: {question}")
        
        if self.check_relevance:
            if not self._is_relevant_query(question):
                print("Warning: Query may be irrelevant")
                choice = input("Continue? (yes/no): ").strip().lower()
                if choice not in ['yes', 'y']:
                    return QueryResult(False, "", pd.DataFrame(), None, "Irrelevant")
        
        tbl = table or self.current_table
        if not tbl:
            all_tables = self._get_table_names()
            if all_tables:
                tbl = all_tables[0]
            else:
                print("No tables found")
                return QueryResult(False, "", pd.DataFrame(), None, "No table")
        
        if self.use_embeddings and self.embedding_model:
            cached_result = self._check_embedding_cache(question, tbl)
            if cached_result:
                print("  Using cached result")
                return cached_result
        
        if self.fuzzy_match:
            question = self._apply_fuzzy_matching(question, tbl)
        
        cache_key = hashlib.md5(f"{question}:{tbl}".encode()).hexdigest()
        if self.cache_queries and self.cache and cache_key in self.cache:
            sql_query = self.cache[cache_key]
            print("  From cache")
        else:
            sql_query = self._generate_sql(question, tbl)
            if self.cache_queries and self.cache is not None:
                self.cache[cache_key] = sql_query
        
        print(f"SQL: {sql_query}")
        
        try:
            df = pd.read_sql_query(sql_query, self.conn)
            print(f"Success! {len(df)} rows")
            
            fig = None
            if viz:
                viz_type = viz if isinstance(viz, str) else "auto"
                fig = self._visualize(df, question, viz_type=viz_type)
            
            result = QueryResult(True, sql_query, df, fig)
            
            if self.use_embeddings and self.embedding_model:
                self._store_in_embedding_cache(question, tbl, result)
            
            return result
        except Exception as e:
            print(f"Error: {e}")
            return QueryResult(False, sql_query, pd.DataFrame(), None, str(e))
    
    def _is_relevant_query(self, question: str) -> bool:
        """Check relevance."""
        if not self.client:
            return True
        
        tables = self._get_table_names()
        columns = []
        for tbl in tables[:3]:
            cols = list(self.schema_info.get(tbl, {}).keys())
            columns.extend(cols[:5])
        
        db_context = f"Tables: {', '.join(tables[:5])}. Columns: {', '.join(columns[:15])}"
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "Relevance checker. Return only 'yes' or 'no'."},
                    {"role": "user", "content": f"Is this relevant to database with {db_context}?\n\nQuestion: {question}\n\nyes or no:"}
                ],
                temperature=0,
                max_tokens=5
            )
            
            return 'yes' in response.choices[0].message.content.strip().lower()
        except:
            return True
    
    def _apply_fuzzy_matching(self, question: str, table: str) -> str:
        """Fuzzy match query terms."""
        if not self.schema_info.get(table):
            return question
        
        try:
            string_cols = [col for col, dtype in self.schema_info[table].items() 
                          if 'TEXT' in dtype or 'VARCHAR' in dtype]
            
            if not string_cols:
                return question
            
            for col in string_cols[:2]:
                df = pd.read_sql_query(f"SELECT DISTINCT {col} FROM {table} LIMIT 100", self.conn)
                unique_values = [str(v) for v in df[col].dropna().tolist()]
                
                words = question.split()
                for i, word in enumerate(words):
                    matches = get_close_matches(word, unique_values, n=1, cutoff=0.6)
                    if matches and word != matches[0]:
                        words[i] = matches[0]
                        print(f"  Fuzzy: '{word}' -> '{matches[0]}'")
                
                question = " ".join(words)
            
            return question
        except:
            return question
    
    def _check_embedding_cache(self, question: str, table: str) -> Optional['QueryResult']:
        """Check embedding cache."""
        if not self.query_embeddings:
            return None
        
        q_embedding = self.embedding_model.encode([question])[0]
        
        best_match = None
        best_similarity = 0.85
        
        for cached_q, cached_data in self.query_embeddings.items():
            if cached_data['table'] != table:
                continue
            
            similarity = np.dot(q_embedding, cached_data['embedding']) / (
                np.linalg.norm(q_embedding) * np.linalg.norm(cached_data['embedding'])
            )
            
            if similarity > best_similarity:
                best_similarity = similarity
                best_match = cached_q
        
        if best_match:
            print(f"  Similar query ({best_similarity:.0%}): '{best_match}'")
            return self.query_embeddings[best_match]['result']
        
        return None
    
    def _store_in_embedding_cache(self, question: str, table: str, result: 'QueryResult'):
        """Store in cache."""
        q_embedding = self.embedding_model.encode([question])[0]
        self.query_embeddings[question] = {
            'table': table,
            'embedding': q_embedding,
            'result': result
        }
    
    def _visualize(self, df: pd.DataFrame, title: str, viz_type: str = "auto"):
        """Create visualization."""
        if not HAS_PLOTLY and not HAS_MATPLOTLIB:
            print("Install plotly or matplotlib")
            return None
        
        print(f"Creating {viz_type} chart...")
        
        if HAS_PLOTLY:
            return self._plotly_viz(df, title, viz_type)
        else:
            return self._matplotlib_viz(df, title, viz_type)
    
    def _plotly_viz(self, df: pd.DataFrame, title: str, viz_type: str):
        """Plotly visualization."""
        try:
            numeric = df.select_dtypes(include=[np.number]).columns.tolist()
            categorical = df.select_dtypes(include=['object']).columns.tolist()
            
            if viz_type == "table" or len(df) == 1:
                fig = go.Figure(data=[go.Table(
                    header=dict(values=list(df.columns)),
                    cells=dict(values=[df[c] for c in df.columns])
                )])
            elif viz_type == "pie" and categorical and numeric:
                fig = px.pie(df, names=categorical[0], values=numeric[0], title=title)
            elif viz_type == "bar" and categorical and numeric:
                fig = px.bar(df, x=categorical[0], y=numeric[0], title=title)
            elif viz_type == "line" and numeric:
                fig = px.line(df, y=numeric[0], title=title)
            elif viz_type == "scatter" and len(numeric) >= 2:
                fig = px.scatter(df, x=numeric[0], y=numeric[1], title=title)
            elif viz_type == "heatmap" and len(numeric) >= 2:
                corr = df[numeric].corr()
                fig = go.Figure(data=go.Heatmap(
                    z=corr.values, x=corr.columns, y=corr.columns, colorscale='Viridis'
                ))
                fig.update_layout(title=title)
            elif viz_type == "auto":
                if categorical and numeric:
                    fig = px.pie(df, names=categorical[0], values=numeric[0], title=title) if len(df) <= 10 else px.bar(df, x=categorical[0], y=numeric[0], title=title)
                elif len(numeric) >= 2:
                    fig = px.line(df, y=numeric[0], title=title)
                else:
                    fig = px.bar(df, y=df.columns[0], title=title)
            else:
                fig = px.bar(df, x=categorical[0] if categorical else df.index, y=numeric[0] if numeric else df.columns[0], title=title)
            
            fig.show()
            print("Chart displayed")
            return fig
        except Exception as e:
            print(f"Viz error: {e}")
            return None
    
    def _matplotlib_viz(self, df: pd.DataFrame, title: str, viz_type: str):
        """Matplotlib visualization."""
        try:
            plt.figure(figsize=(10, 6))
            numeric = df.select_dtypes(include=[np.number]).columns
            
            if viz_type == "pie" and len(numeric) > 0:
                df[df.columns[0]].value_counts().plot(kind='pie')
            elif viz_type == "line" and len(numeric) > 0:
                df[numeric[0]].plot(kind='line')
            else:
                if len(numeric) > 0:
                    df[numeric[0]].plot(kind='bar')
                else:
                    df.iloc[:, 0].value_counts().plot(kind='bar')
            
            plt.title(title)
            plt.tight_layout()
            plt.show()
            print("Chart displayed")
            return plt.gcf()
        except Exception as e:
            print(f"Viz error: {e}")
            return None
    
    def tables(self) -> Dict[str, dict]:
        """List all tables."""
        print("\n" + "="*70)
        print("TABLES IN DATABASE")
        print("="*70)
        
        all_tables = self._get_table_names()
        
        if not all_tables:
            print("No tables found")
            return {}
        
        result = {}
        for i, tbl in enumerate(all_tables, 1):
            count = pd.read_sql_query(f"SELECT COUNT(*) FROM {tbl}", self.conn).iloc[0, 0]
            cols = self.schema_info.get(tbl, {})
            col_list = list(cols.keys())
            
            marker = ">" if tbl == self.current_table else " "
            print(f"{marker} {i}. {tbl}")
            print(f"     {count} rows, {len(col_list)} columns")
            print(f"     Columns: {', '.join(col_list[:8])}")
            
            result[tbl] = {'rows': count, 'columns': col_list}
        
        print("="*70)
        return result
    
    def schema(self, table: Optional[str] = None) -> dict:
        """Show schema."""
        if not self.schema_info:
            self._refresh_schema()
        
        print("\n" + "="*70)
        print("DATABASE SCHEMA")
        print("="*70)
        
        tables_to_show = [table] if table else self.schema_info.keys()
        
        result = {}
        for tbl in tables_to_show:
            if tbl in self.schema_info:
                count = pd.read_sql_query(f"SELECT COUNT(*) FROM {tbl}", self.conn).iloc[0, 0]
                print(f"\nTable: {tbl}")
                print(f"Records: {count}")
                print("Columns:")
                
                for col, dtype in self.schema_info[tbl].items():
                    print(f"  - {col:<30} ({dtype})")
                
                result[tbl] = {
                    'records': count,
                    'columns': self.schema_info[tbl]
                }
        
        print("="*70)
        return result
    
    def peek(self, table: Optional[str] = None, n: int = 5) -> pd.DataFrame:
        """Preview data."""
        tbl = table or self.current_table
        if not tbl:
            print("No table specified")
            return pd.DataFrame()
        
        df = pd.read_sql_query(f"SELECT * FROM {tbl} LIMIT {n}", self.conn)
        print(f"\nSample from '{tbl}' ({n} rows):")
        print(df.to_string(index=False))
        return df
    
    def info(self):
        """Database overview."""
        return self.tables()
    
    def sql(self, query: str, viz: Union[bool, str] = False) -> 'QueryResult':
        """Execute SQL."""
        print("\nExecuting SQL...")
        
        try:
            df = pd.read_sql_query(query, self.conn)
            print(f"Success! {len(df)} rows")
            
            fig = None
            if viz:
                viz_type = viz if isinstance(viz, str) else "auto"
                fig = self._visualize(df, "SQL Result", viz_type=viz_type)
            
            return QueryResult(True, query, df, fig)
        except Exception as e:
            print(f"Error: {e}")
            return QueryResult(False, query, pd.DataFrame(), None, str(e))
    
    def interactive(self, question: str) -> 'QueryResult':
        """Interactive query."""
        print(f"\nQuestion: {question}")
        choice = input("Visualize? (yes/no/pie/bar/line/scatter): ").strip().lower()
        
        viz = choice if choice in ['pie', 'bar', 'line', 'scatter', 'table', 'heatmap'] else (True if choice in ['yes', 'y'] else False)
        
        return self.ask(question, viz=viz)
    
    def export_db(self, path: str, format: str = "sqlite"):
        """Export database."""
        print(f"\nExporting to {format}...")
        
        if format == "sqlite":
            shutil.copy2(self.db_path, path)
        elif format == "sql":
            with open(path, 'w', encoding='utf-8') as f:
                for line in self.conn.iterdump():
                    f.write(f'{line}\n')
        elif format == "json":
            data = {}
            for table in self._get_table_names():
                df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
                data[table] = df.to_dict(orient='records')
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, default=str)
        elif format == "excel":
            with pd.ExcelWriter(path, engine='openpyxl') as writer:
                for table in self._get_table_names():
                    df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
                    df.to_excel(writer, sheet_name=table[:31], index=False)
        else:
            raise ValueError(f"Unsupported: {format}")
        
        print(f"Saved to {path}")
        return self
    
    def save_to_mysql(self, host: str, user: str, password: str, database: str,
                      port: int = 3306, tables: Optional[List[str]] = None):
        """Export to MySQL."""
        try:
            from sqlalchemy import create_engine
        except ImportError:
            raise ImportError("Run: pip install QuerySUTRA[mysql]")
        
        print(f"\nConnecting to MySQL: {host}:{port}...")
        
        engine = create_engine(f"mysql+mysqlconnector://{user}:{password}@{host}:{port}/{database}")
        
        tables_to_export = tables or self._get_table_names()
        
        print(f"Exporting {len(tables_to_export)} tables...")
        
        for table in tables_to_export:
            df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
            df.to_sql(table, engine, if_exists='replace', index=False)
            print(f"  {table}: {len(df)} rows")
        
        print("Complete!")
        return self
    
    def save_to_postgres(self, host: str, user: str, password: str, database: str,
                         port: int = 5432, tables: Optional[List[str]] = None):
        """Export to PostgreSQL."""
        try:
            from sqlalchemy import create_engine
        except ImportError:
            raise ImportError("Run: pip install QuerySUTRA[postgres]")
        
        print(f"\nConnecting to PostgreSQL: {host}:{port}...")
        
        engine = create_engine(f"postgresql://{user}:{password}@{host}:{port}/{database}")
        
        tables_to_export = tables or self._get_table_names()
        
        print(f"Exporting {len(tables_to_export)} tables...")
        
        for table in tables_to_export:
            df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
            df.to_sql(table, engine, if_exists='replace', index=False)
            print(f"  {table}: {len(df)} rows")
        
        print("Complete!")
        return self
    
    def backup(self, backup_path: str = None):
        """Create backup."""
        if backup_path:
            backup_dir = Path(backup_path)
            backup_dir.mkdir(parents=True, exist_ok=True)
        else:
            backup_dir = Path(".")
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        print("\nCreating backup...")
        
        db_backup = backup_dir / f"sutra_{timestamp}.db"
        self.export_db(str(db_backup), format="sqlite")
        
        json_backup = backup_dir / f"sutra_{timestamp}.json"
        self.export_db(str(json_backup), format="json")
        
        print(f"\nBackup complete!")
        print(f"  Database: {db_backup}")
        print(f"  Data: {json_backup}")
        
        return self
    
    def export(self, data: pd.DataFrame, path: str, format: str = "csv"):
        """Export results."""
        if format == "csv":
            data.to_csv(path, index=False)
        elif format in ["excel", "xlsx"]:
            data.to_excel(path, index=False)
        elif format == "json":
            data.to_json(path, orient="records", indent=2)
        else:
            raise ValueError(f"Unknown: {format}")
        
        print(f"Exported to {path}")
        return self
    
    def close(self):
        """Close connection."""
        if self.conn:
            self.conn.close()
            print("Closed")
    
    def _get_table_names(self) -> List[str]:
        """Get tables."""
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        return [r[0] for r in self.cursor.fetchall()]
    
    def _refresh_schema(self):
        """Refresh schema."""
        tables = self._get_table_names()
        
        self.schema_info = {}
        for tbl in tables:
            self.cursor.execute(f"PRAGMA table_info({tbl})")
            self.schema_info[tbl] = {r[1]: r[2] for r in self.cursor.fetchall()}
    
    def _generate_sql(self, question: str, table: str) -> str:
        """Generate SQL."""
        schema = self.schema_info.get(table, {})
        sample_df = pd.read_sql_query(f"SELECT * FROM {table} LIMIT 3", self.conn)
        sample = sample_df.to_string(index=False)
        
        schema_str = ", ".join([f"{col} ({dtype})" for col, dtype in schema.items()])
        
        prompt = f"""Convert to SQL.

Database: SQLite
Table: {table}
Columns: {schema_str}

Sample:
{sample}

Question: {question}

Return ONLY SQL."""
        
        response = self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "SQL expert. Return only SQL code."},
                {"role": "user", "content": prompt}
            ],
            temperature=0
        )
        
        sql = response.choices[0].message.content.strip()
        return sql.replace("```sql", "").replace("```", "").strip()
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()
    
    def __repr__(self):
        features = []
        if self.cache_queries:
            features.append("cache")
        if self.use_embeddings:
            features.append("embeddings")
        if self.check_relevance:
            features.append("relevance")
        if self.fuzzy_match:
            features.append("fuzzy")
        
        feat_str = f", {', '.join(features)}" if features else ""
        return f"SUTRA(tables={len(self.schema_info)}{feat_str})"


class QueryResult:
    """Query result."""
    
    def __init__(self, success: bool, sql: str, data: pd.DataFrame, viz, error: str = None):
        self.success = success
        self.sql = sql
        self.data = data
        self.viz = viz
        self.error = error
    
    def __repr__(self):
        return f"QueryResult(rows={len(self.data)}, cols={len(self.data.columns)})" if self.success else f"QueryResult(error='{self.error}')"
    
    def show(self):
        print(self.data) if self.success else print(f"Error: {self.error}")
        return self


def quick_start(api_key: str, data_path: str, question: str, viz: Union[bool, str] = False):
    """One-liner."""
    with SUTRA(api_key=api_key) as sutra:
        sutra.upload(data_path)
        return sutra.ask(question, viz=viz)


if __name__ == "__main__":
    print("""
QuerySUTRA v0.3.3 - Professional Data Analysis
SUTRA: Structured-Unstructured-Text-Retrieval-Architecture

Fixed: Proper primary and foreign keys with unique IDs
Features: Load existing DB, custom viz, fuzzy matching, embeddings

Installation: pip install QuerySUTRA
Usage: from sutra import SUTRA
""")
