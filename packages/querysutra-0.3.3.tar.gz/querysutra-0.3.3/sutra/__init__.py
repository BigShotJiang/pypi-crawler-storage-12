"""
QuerySUTRA - Structured-Unstructured-Text-Retrieval-Architecture
Creates multiple structured tables from ANY data with AI

v0.3.3 - FIXED: Proper primary/foreign keys and comprehensive extraction
"""

__version__ = "0.3.3"

from sutra.sutra import SUTRA, QueryResult, quick_start

__all__ = ["SUTRA", "QueryResult", "quick_start"]
