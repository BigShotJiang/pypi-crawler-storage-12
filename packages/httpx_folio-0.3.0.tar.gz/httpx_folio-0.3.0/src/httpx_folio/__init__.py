"""FOLIO related niceties for the next generation HTTP client for Python."""
