# export retained to maintain backwards compatibility until we deprecate measures fully
from dbt_semantic_interfaces.transformations.boolean_aggregations import (  # noqa: F401
    BooleanMeasureAggregationRule,
)
