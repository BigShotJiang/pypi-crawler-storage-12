"""Slippage models for AlphaFlow."""

from alphaflow.slippage_models.fixed_slippage_model import FixedSlippageModel

__all__ = ["FixedSlippageModel"]
