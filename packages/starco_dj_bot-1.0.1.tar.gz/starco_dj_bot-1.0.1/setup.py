
from setuptools import setup, find_packages

setup(
    name='starco-dj-bot',
    version='1.0.1',
    packages=['bot'],
    include_package_data=True,
    license='MIT',
    description='A Django pluggable app for telegram bot development.',
    author='Mojtaba',
    author_email='m.tahmasbi0111@yahoo.com',
    install_requires=[
        'Django>=4.0',
        'celery',
        'redis',
        'django-redis',
        'python-telegram-bot==22.5',
        'colorama',
        'uvicorn',
        'python-dotenv',
    ],
    classifiers=[
        'Framework :: Django',
        'Programming Language :: Python :: 3',
    ],
)
