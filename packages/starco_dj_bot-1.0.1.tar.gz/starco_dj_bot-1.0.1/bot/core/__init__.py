import os

from telegram import Bot

from telegram.ext import (
    Application,
)
from bot.core.base import Base
import inspect
from utility import root_path,FileFinder,Logger
from bot.utils.service.translation_manager import TranslationManager
from telegram.ext import PicklePersistence
import importlib
from pathlib import Path
class TelegramBot:
    def __init__(
            self,
            token: str = None,
            admins: list[int] = None,
            translation_manager: TranslationManager = None,
            **kwargs
    ):
            token = token or os.environ.get('TELEGRAM_BOT_TOKEN_EV')
            if admins is None:
                admins: list = os.getenv('TELEGRAM_BOT_ADMINS_EV').split(',')
                admins = list(map(lambda x: int(x.strip()), admins))
            persistence = PicklePersistence(filepath="bot_persistence",update_interval=5)
            self.app = Application.builder().token(token).persistence(persistence).build()

            self.bot:Bot = self.app.bot
            self.admins = admins
            self.translation_manager = translation_manager
            self._node_dir=kwargs.get('node_dir','bot/panels')
            self.log=Logger("setting")
            self.app.add_error_handler(self.error_handler)
    async def error_handler(self,update, context):
        # ثبت اطلاعات خطا در لاگ
        self.log.error("Exception occurred", exc_info=context.error)

    def autodiscover(self):
        path=root_path()
        ff=FileFinder(f"{path}/{self._node_dir}")
        # Get all Python files in the nodes directory
        python_files = ff.find_by_extension('.py')
        for file_path in python_files:
            # Convert file path to module path
            relative_path = Path(file_path).relative_to(path)
            module_path = str(relative_path).replace('/', '.').replace('.py', '')
            # Load the module
            module = self.__load_module_from_str(module_path)

            if module:
                # Find all Base subclasses in the module
                subclasses_in_module = [
                    cls for name, cls in inspect.getmembers(module, inspect.isclass)
                    if issubclass(cls, Base) and cls is not Base
                ]
                # Initialize and process each subclass
                for cls in subclasses_in_module:
                    print(f"Loading panel {cls.__name__}")
                    instance:Base = cls()
                    instance.build(self.bot,self.log,self.admins,self.translation_manager)
                    for handler in instance._handlers:
                        self.app.add_handler(handler)

    async def stop(self):
        """Stops the setting and cleans up resources"""
        if self.app:
            await self.app.stop()
            await self.app.shutdown()

    def run(self):
        self.autodiscover()
        self.app.run_polling()


    def __load_module_from_str(self,module_path: str):
        """
        Load a module from a string path.
        Example: 'nodes.admin.commands' will load the commands module
        """
        try:

            return importlib.import_module(module_path)
        except ImportError as e:
            self.log.error(e)
            return None