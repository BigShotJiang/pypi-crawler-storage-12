from pathlib import Path
from bot.component.button import ButtonBuilder

def button(data: list | dict, pattern: int | tuple, reverse: bool = False, close: bool = False, level=1):
    new_data = data.copy()
    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, dict):
                if 'R' not in value:
                    value['R'] = level
                new_data[key] = value
    return ButtonBuilder(new_data, pattern, reverse, close).build()


def get_static_file_bytes(static_path):
    return Path(static_path).read_bytes()


def get_media_type(file_extension):
    """Determine media type based on file extension"""
    photo_extensions = {'jpg', 'jpeg', 'png', 'webp'}
    video_extensions = {'mp4', 'avi', 'mov', 'mkv'}
    audio_extensions = {'mp3', 'wav', 'ogg', 'm4a'}
    document_extensions = {'pdf', 'doc', 'docx', 'txt', 'zip', 'rar'}

    ext = file_extension.lower()

    if ext in photo_extensions:
        return 'photo'
    elif ext in video_extensions:
        return 'video'
    elif ext in audio_extensions:
        return 'audio'
    elif ext in document_extensions:
        return 'document'
    else:
        return 'document'


def status_maker(status):
    if status == 'completed':
        return f'✅{status}'
    elif status == 'confirmed':
        return f'✅{status}'
    elif status == 'canceled':
        return f'❌{status}'
    elif status == 'pending':
        return f'⏳{status}'
    elif status == 'processing':
        return f'🔄{status}'
    elif status == 'refund':
        return f'💸{status}'
    elif status == 'failed':
        return f'❌{status}'
    elif status == 'rejected':
        return f'❌{status}'

import os

from pathlib import Path
import os
from pathlib import Path
from django.conf import settings

def root_path():
    return settings.BASE_DIR

class FileFinder:
    def __init__(self, directory):
        self.directory = directory

    def find_all_files(self):
        """Returns a list of all files in the directory and subdirectories"""
        files = []
        for root, dirs, filenames in os.walk(self.directory):
            for filename in filenames:
                files.append(os.path.join(root, filename))
        return files

    def find_by_extension(self, extension):
        """Returns a list of files with specific extension"""
        files = []
        for file in self.find_all_files():
            if file.endswith(extension):
                files.append(file)
        return files

    def get_file_count(self):
        """Returns total number of files"""
        return len(self.find_all_files())


