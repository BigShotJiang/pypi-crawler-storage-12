from django.core.management import call_command
from django.core.management.base import BaseCommand
from pathlib import Path
from django.conf import settings
import os


class Command(BaseCommand):
    help = 'Creates bot_panel directory structure in Django root'

    def add_arguments(self, parser):
        parser.add_argument(
            '--force',
            action='store_true',
            help='Force creation even if directory exists',
        )

    def handle(self, *args, **options):
        # Get Django project root (where manage.py is located)
        django_root = Path(settings.BASE_DIR)
        bot_panel_dir = django_root / 'bot_panel'
        call_command('bot_env', add_missing=True, show_values=True)


        try:
            # Create main bot_panel directory
            bot_panel_dir.mkdir(exist_ok=True)
            self.stdout.write(
                self.style.SUCCESS(f'Created directory: {bot_panel_dir}')
            )

            # Create __init__.py
            init_file = bot_panel_dir / '__init__.py'
            init_file.touch()
            self.stdout.write(
                self.style.SUCCESS(f'Created file: {init_file}')
            )

            # Create core subdirectory
            core_dir = bot_panel_dir / 'texts'
            core_dir.mkdir(exist_ok=True)
            self.stdout.write(
                self.style.SUCCESS(f'Created directory: {core_dir}')
            )
            core_dir = bot_panel_dir / 'roles'
            core_dir.mkdir(exist_ok=True)
            self.stdout.write(
                self.style.SUCCESS(f'Created directory: {core_dir}')
            )
            core_dir = bot_panel_dir/ 'roles' / 'admin'
            core_dir.mkdir(exist_ok=True)
            self.stdout.write(
                self.style.SUCCESS(f'Created directory: {core_dir}')
            )
            core_dir = bot_panel_dir/ 'roles' / 'user'
            core_dir.mkdir(exist_ok=True)
            self.stdout.write(
                self.style.SUCCESS(f'Created directory: {core_dir}')
            )
            #
            # # Create core/__init__.py
            # core_init = core_dir / '__init__.py'
            # core_init.touch()
            # self.stdout.write(
            #     self.style.SUCCESS(f'Created file: {core_init}')
            # )
            #
            # # Create basic Django project files in core
            # files_to_create = [
            #     'settings.py',
            #     'urls.py',
            #     'asgi.py',
            #     'wsgi.py'
            # ]
            #
            # for filename in files_to_create:
            #     file_path = core_dir / filename
            #     if not file_path.exists() or force:
            #         file_path.touch()
            #         self.stdout.write(
            #             self.style.SUCCESS(f'Created file: {file_path}')
            #         )

            self.stdout.write(
                self.style.SUCCESS(
                    '\nbot_panel directory structure created successfully!'
                )
            )

        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f'Error creating bot_panel directory: {str(e)}')
            )