__name__ = "hedgetech_core_sdk"
__version__ = "0.0.1"

def test()-> bool:
    
    return True