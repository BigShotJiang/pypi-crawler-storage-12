snake_case_functions = ('higher_order_accurate_derivative_image_filter', 'higher_order_accurate_gradient_image_filter', )
