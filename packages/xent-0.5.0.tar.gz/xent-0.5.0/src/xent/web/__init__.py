"""Web interface for XENT benchmark monitoring."""

__all__ = ["app"]

from xent.web.server import app
