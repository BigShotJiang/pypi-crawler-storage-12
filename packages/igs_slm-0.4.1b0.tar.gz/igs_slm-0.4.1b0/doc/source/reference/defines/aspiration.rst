.. include:: ../../refs.rst

.. autoclass:: slm.defines.Aspiration
   :members:
   :undoc-members:
   :show-inheritance:
