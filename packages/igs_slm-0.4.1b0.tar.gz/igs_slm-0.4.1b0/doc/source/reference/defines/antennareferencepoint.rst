.. include:: ../../refs.rst

.. autoclass:: slm.defines.AntennaReferencePoint
   :members:
   :undoc-members:
   :show-inheritance:
