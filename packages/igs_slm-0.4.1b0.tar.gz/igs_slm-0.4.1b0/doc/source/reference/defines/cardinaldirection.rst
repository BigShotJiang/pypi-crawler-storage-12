.. include:: ../../refs.rst

.. autoclass:: slm.defines.CardinalDirection
   :members:
   :undoc-members:
   :show-inheritance:
