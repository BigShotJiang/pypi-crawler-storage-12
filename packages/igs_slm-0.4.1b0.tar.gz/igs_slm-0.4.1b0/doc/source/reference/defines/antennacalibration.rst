.. include:: ../../refs.rst

.. autoclass:: slm.defines.AntennaCalibrationMethod
   :members:
   :undoc-members:
   :show-inheritance:
