.. include:: ../../refs.rst

.. autoclass:: slm.defines.SiteFileUploadStatus
   :members:
   :undoc-members:
   :show-inheritance:
