.. include:: ../../refs.rst

.. autoclass:: slm.defines.FlagSeverity
   :members:
   :undoc-members:
   :show-inheritance:
