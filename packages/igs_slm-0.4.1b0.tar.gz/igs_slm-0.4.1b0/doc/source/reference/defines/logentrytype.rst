.. include:: ../../refs.rst

.. autoclass:: slm.defines.LogEntryType
   :members:
   :undoc-members:
   :show-inheritance:
