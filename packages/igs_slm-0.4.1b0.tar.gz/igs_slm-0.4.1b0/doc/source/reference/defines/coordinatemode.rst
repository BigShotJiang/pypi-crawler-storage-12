.. include:: ../../refs.rst

.. autoclass:: slm.defines.CoordinateMode
   :members:
   :undoc-members:
   :show-inheritance:
