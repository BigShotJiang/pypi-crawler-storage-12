.. include:: ../refs.rst


=================
Data Organization
=================

.. todo::

    Data model organization docs - including state diagram.
