# Welcome to symmray's documentation!


```{toctree}
:caption: Guides
:maxdepth: 2

installation.md
```


```{toctree}
:caption: Development
:hidden:

GitHub Repository <https://github.com/jcmgray/cotengra>
```
