"""
Migrations for openedx_authz app.
"""
