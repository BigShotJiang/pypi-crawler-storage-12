__all__ = ["OpenGHGServiceError"]


class OpenGHGServiceError(Exception):
    pass
