"""
MarlOS Scripts
Contains utility scripts for installation, building, and testing
"""
