Developer Documentation
=======================

Here you can find developer specific documentation on Spine Toolbox.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   ui_guidelines
   unit_testing_guidelines
   execution_tests
   project_item_development
   publishing_to_pypi
