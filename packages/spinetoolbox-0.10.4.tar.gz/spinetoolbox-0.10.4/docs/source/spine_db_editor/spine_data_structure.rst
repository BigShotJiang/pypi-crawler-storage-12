********************
Spine Data Structure
********************

.. contents::
   :local:

Documentation for the Spine data structure can be found `here
<https://github.com/ines-tools/spine-data-model#spine-data-model>`_.
