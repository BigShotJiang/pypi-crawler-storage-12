"""Init File for MatFold: A Python package for CIF file manipulation and analysis."""
from .main import MatFold, cifs_to_dict
from ._version import __version__
