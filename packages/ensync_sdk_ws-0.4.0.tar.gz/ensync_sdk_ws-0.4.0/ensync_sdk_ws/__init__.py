"""
EnSync WebSocket Client - WebSocket client for EnSync Engine.
"""

from .websocket import EnSyncEngine

__version__ = "0.4.0"

__all__ = ['EnSyncEngine']
