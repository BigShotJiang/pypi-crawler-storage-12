.. include:: ../LICENSE.rst
