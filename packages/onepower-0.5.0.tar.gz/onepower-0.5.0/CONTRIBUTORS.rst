Authors
=======
* Andrej Dvornik: `@andrejdvornik <https://github.com/andrejdvornik>`_
* Maria Cristina Fortuna: `@mcfortuna <https://github.com/mcfortuna>`_
* Marika Asgari: `@maricool <https://github.com/maricool>`_

Contributors
------------
* Constance Mahony: `@crcmahony <https://github.com/crcmahony>`_
* Catherine Heymans: `@cheymans <https://github.com/cheymans>`_
* Christos Georgiou: `@chrgeorgiou <https://github.com/chrgeorgiou>`_
* Tassia Ferreira: `@tassia-ferreira <https://github.com/tassia-ferreira>`_

Comments, corrections and suggestions
-------------------------------------
* Alex Mead: `@alexander-mead <https://github.com/alexander-mead>`_
