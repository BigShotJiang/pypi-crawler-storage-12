#!/bin/bash
# Run tests using uv
uv run pytest
