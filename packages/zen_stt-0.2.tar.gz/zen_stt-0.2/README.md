# Zen-STT

A simple Speech-to-Text automation package created by ZEN using Selenium.
