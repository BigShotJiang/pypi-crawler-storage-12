NS_RSM = "urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100"
NS_UDT = "urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100"
NS_A = "urn:un:unece:uncefact:data:standard:QualifiedDataType:100"
NS_RAM = (
    "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100"
)
NS_QDT = "urn:un:unece:uncefact:data:standard:QualifiedDataType:100"
BASIC = "BASIC"
COMFORT = "COMFORT"
EXTENDED = "EXTENDED"
