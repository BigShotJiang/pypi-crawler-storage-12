from .google_gemini_parser import analyze_document as google_gemini_parser

__all__ = ['google_gemini_parser']

version = "0.0.1"
