from .utils.useful import arg_parser

def main():
    arg_parser()

if __name__ == '__main__':
    main()
