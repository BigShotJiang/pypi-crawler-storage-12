"""Plugin exports."""

__name__ = __name__.split("_")[-1]
