# Fedora Account System / IPA JSON gateway

A JSON gateway to query FreeIPA, built for the Fedora Account System.

The documentation is available at https://fasjson.readthedocs.io/

![Tests & build status](https://github.com/fedora-infra/fasjson/actions/workflows/main.yml/badge.svg?branch=develop)
![Documentation](https://readthedocs.org/projects/fasjson/badge/?version=latest)


## TODO

- documentation
- HTTPS
