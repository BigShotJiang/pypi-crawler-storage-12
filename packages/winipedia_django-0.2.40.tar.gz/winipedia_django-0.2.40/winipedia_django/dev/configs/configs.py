"""Configs for winipedia_utils.

All subclasses of ConfigFile in the configs package are automatically called.
"""
