class AuthenticationException(Exception):
    """Exception to indicate authentication has failed"""

    pass
