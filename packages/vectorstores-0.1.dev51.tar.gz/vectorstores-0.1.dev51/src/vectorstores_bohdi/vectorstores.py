from __future__ import annotations

import datetime
import logging
from collections.abc import Generator
from contextlib import contextmanager
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    Iterable,
    List,
    Literal,
    Optional,
    Tuple,
    Union,
    overload,
)
from uuid import uuid4

import numpy as np
import weaviate  # type: ignore
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from vectorstores.base import VectorStore


if TYPE_CHECKING:
    import weaviate


logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

handler = logging.StreamHandler()
formatter = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s", datefmt="%Y-%b-%d %I:%M %p"
)
handler.setFormatter(formatter)

logger.addHandler(handler)

# TODO: Find out how this schema has to be updated to match the new vector
# embedding input.
def _default_schema(index_name: str) -> Dict:
    return {
        "class": index_name,
        "properties": [
            {
                "name": "text",
                "dataType": ["text"],
            }
        ],
    }

# TODO: What does this normalize?
def _default_score_normalizer(val: float) -> float:
    # prevent overflow
    # use 709 because that's the largest exponent that doesn't overflow
    # use -709 because that's the smallest exponent that doesn't underflow
    val = np.clip(val, -709, 709)
    return 1 - 1 / (1 + np.exp(val))

# TODO: What is this responsible for?
def _json_serializable(value: Any) -> Any:
    if isinstance(value, datetime.datetime):
        return value.isoformat()
    return value


class WeaviateVectorStore(VectorStore):
    """Weaviate vector store.

    To use, you should have the `weaviate-client` python package installed.

    Example:
        ```python
        import weaviate
        from langchain_community.vectorstores import Weaviate

        client = weaviate.Client(url=os.environ["WEAVIATE_URL"], ...)
        weaviate = Weaviate(client, index_name, text_key)
        ```
    """
    # TODO: Find out why exactly embedding is parsed, when it 
    # is computed inside the add_text function?
    # TODO: Find out what is attributes parameter, when metadata
    # is parsed in the add_text function?
    def __init__(
        self,
        client: weaviate.WeaviateClient, # client used for connceting to the database
        index_name: Optional[str], # name of the index
        text_key: str, # key for uploading to weaviate
        embedding: Optional[Embeddings] = None, # embedding model, maybe absolete
        attributes: Optional[List[str]] = None, # list of metadata/property names that will be retrieved from Weaviate and stored in Document.metadata
        relevance_score_fn: Optional[
            Callable[[float], float]
        ] = _default_score_normalizer,
        use_multi_tenancy: bool = False,
    ):
        """Initialize with Weaviate client."""
        self._client = client
        self._index_name = index_name or f"LangChain_{uuid4().hex}"
        self._embedding = embedding
        self._text_key = text_key
        self._query_attrs = [self._text_key]
        self.relevance_score_fn = relevance_score_fn
        if attributes is not None:
            self._query_attrs.extend(attributes)

        schema = _default_schema(self._index_name)
        schema["MultiTenancyConfig"] = {"enabled": use_multi_tenancy}

        # check whether the index already exists
        if not client.collections.exists(self._index_name):
            client.collections.create_from_dict(schema)

        # store collection for convenience
        # this does not actually send a request to weaviate
        self._collection = client.collections.get(self._index_name)

        # store this setting so we don't have to send a request to weaviate
        # every time we want to do a CRUD operation
        self._multi_tenancy_enabled = self._collection.config.get(
            simple=False
        ).multi_tenancy_config.enabled

    def add_vector(
        self,
        vectors: Iterable[Vector], # added vector compatibility
        metadatas: Optional[List[dict]] = None,
        texts: Optional[Iterable[str]] = None, # made this optional
        tenant: Optional[str] = None,
        ids: Optional[Any] = None, # added this for later search
        **kwargs: Any,
    ) -> List[str]:
        """Upload vectors with metadata (properties) to Weaviate."""
        # TODO: Allow callers to supply precomputed embedding vectors (e.g., `vectors` kwarg)
        # so RankingTransformer can bypass `self._embedding`.
        # TODO: Keep backward compatibility by falling back to current behavior when no
        # vectors are provided.
        # is this TODO necessary, or can I change the interface?
        from weaviate.util import get_valid_uuid  # type: ignore

        if tenant and not self._does_tenant_exist(tenant):
            logger.info(
                f"Tenant {tenant} does not exist in index {self._index_name}. "
                "Creating tenant."
            )
            tenant_objs = [weaviate.classes.tenants.Tenant(name=tenant)]
            self._collection.tenants.create(tenants=tenant_objs)


        ids = []
        embeddings: Optional[List[List[float]]] = None

        # TODO: ensuring vector count matches `metadatas`/`ids`, and update VectorStore docs to 
        # describe the new path.
        # -----------------------------------------------------------------------------------------------------
        # 
        # -----------------------------------------------------------------------------------------------------
                

        # TODO: If embeddings are supplied externally, skip this branch and accept numpy /
        # torch tensors directly (including enforcing device/dtype conversions).
        # Will this colide with the backward compatibility?
        if self._embedding and texts is not None and vectors is None:
            vectors = self._embedding.embed_documents(list(texts))

        with self._client.batch.dynamic() as batch:
            # TODO: Iterate over zipped (text, vector, metadata) tuples so we can upload
            # entries that might not include raw text (RankingTransformer outputs).
            # Is this step necessary or can text be removed without conflict?
            for i, text in enumerate(vectors):
                data_properties = {self._text_key: text}
                # TODO: Permit `text` to be optional/None when only embeddings exist, and
                # avoid inserting placeholder strings in Weaviate.
                # How exactly? When text is already None?
                if metadatas is not None:
                    for key, val in metadatas[i].items():
                        data_properties[key] = _json_serializable(val)

                # Allow for ids (consistent w/ other methods)
                # # Or uuids (backwards compatible w/ existing arg)
                # If the UUID of one of the objects already exists
                # then the existing object will be replaced by the new object.
                _id = get_valid_uuid(uuid4())
                if "uuids" in kwargs:
                    _id = kwargs["uuids"][i]
                elif "ids" in kwargs:
                    _id = kwargs["ids"][i]

                # TODO: Validate that a vector is always available when ingesting
                # RankingTransformer embeddings and raise a helpful error if not.
                batch.add_object(
                    collection=self._index_name,
                    properties=data_properties,
                    uuid=_id,
                    vector=embeddings[i] if embeddings else None,
                    tenant=tenant,
                )

                ids.append(_id)

        failed_objs = self._client.batch.failed_objects
        for obj in failed_objs:
            err_message = (
                f"Failed to add object: {obj.original_uuid}\nReason: {obj.message}"
            )

            logger.error(err_message)

        return ids
    
    @classmethod
    def from_texts(
        cls,
        docuemtns: List[VectorDocument],
        embedding: Optional[Embeddings],
        metadatas: Optional[List[dict]] = None,
        *,
        tenant: Optional[str] = None,
        client: Optional[weaviate.WeaviateClient] = None,
        index_name: Optional[str] = None,
        text_key: str = "text",
        relevance_score_fn: Optional[
            Callable[[float], float]
        ] = _default_score_normalizer,
        **kwargs: Any,
    ) -> WeaviateVectorStore:
        """Construct Weaviate wrapper from raw documents.

        This is a user-friendly interface that:

        1. Embeds documents.
        2. Creates a new index for the embeddings in the Weaviate instance.
        3. Adds the documents to the newly created Weaviate index.

        This is intended to be a quick way to get started.

        Args:
            texts: Texts to add to vector store.
            embedding: Text embedding model to use.
            client: weaviate.Client to use.
            metadatas: Metadata associated with each text.
            tenant: The tenant name.
            index_name: Index name.
            text_key: Key to use for uploading/retrieving text to/from vectorstore.
            relevance_score_fn: Function for converting whatever distance function the
                vector store uses to a relevance score, which is a normalized similarity
                score (`0` means dissimilar, `1` means similar).
            **kwargs: Additional named parameters to pass to `Weaviate.__init__()`.

        Example:
            ```python
            from langchain_community.embeddings import OpenAIEmbeddings
            from langchain_community.vectorstores import Weaviate

            embeddings = OpenAIEmbeddings()
            weaviate = Weaviate.from_texts(
                texts,
                embeddings,
                client=client
            )
            ```
        """
        # TODO: Provide a companion constructor (e.g., `from_embeddings`) or extend this
        # method to accept precomputed vectors + ids so RankingTransformer batches can be
        # uploaded without re-embedding inside the vector store.

        attributes = list(metadatas[0].keys()) if metadatas else None

        if client is None:
            raise ValueError("client must be an instance of WeaviateClient")

        weaviate_vector_store = cls(
            client,
            index_name,
            text_key,
            embedding=embedding,
            attributes=attributes,
            relevance_score_fn=relevance_score_fn,
            use_multi_tenancy=tenant is not None,
        )

        weaviate_vector_store.add_vectors(texts, metadatas, tenant=tenant, **kwargs)

        return weaviate_vector_store

    def delete(
        self,
        ids: Optional[List[str]] = None,
        tenant: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Delete by vector IDs.

        Args:
            ids: List of ids to delete.
            tenant: The tenant name.
        """

        if ids is None:
            raise ValueError("No ids provided to delete.")

        id_filter = weaviate.classes.query.Filter.by_id().contains_any(ids)

        with self._tenant_context(tenant) as collection:
            collection.data.delete_many(where=id_filter)

    def _does_tenant_exist(self, tenant: str) -> bool:
        """Check if tenant exists in Weaviate."""
        assert (
            self._multi_tenancy_enabled
        ), "Cannot check for tenant existence when multi-tenancy is not enabled"
        tenants = self._collection.tenants.get()

        return tenant in tenants

    @contextmanager
    def _tenant_context(
        self, tenant: Optional[str] = None
    ) -> Generator[weaviate.collections.Collection, None, None]:
        """Context manager for handling tenants.

        Args:
            tenant: The tenant name.
        """

        if tenant is not None and not self._multi_tenancy_enabled:
            raise ValueError(
                "Cannot use tenant context when multi-tenancy is not enabled"
            )

        if tenant is None and self._multi_tenancy_enabled:
            raise ValueError("Must use tenant context when multi-tenancy is enabled")

        try:
            yield self._collection.with_tenant(tenant)
        finally:
            pass
