"""Tests for elecnova-client."""
