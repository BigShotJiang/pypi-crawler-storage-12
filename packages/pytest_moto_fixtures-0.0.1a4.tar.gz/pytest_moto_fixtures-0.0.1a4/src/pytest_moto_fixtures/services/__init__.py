"""Access to AWS services."""
