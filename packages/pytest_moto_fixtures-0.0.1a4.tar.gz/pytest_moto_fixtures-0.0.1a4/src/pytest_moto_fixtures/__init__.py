"""Resources for testing code that interacts with AWS."""
