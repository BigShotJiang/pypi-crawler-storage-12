__version__ = "0.60.0"


if __name__ == "__main__":
    print(__version__)
