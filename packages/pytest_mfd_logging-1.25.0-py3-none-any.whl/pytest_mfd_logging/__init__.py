# Copyright (C) 2025 Intel Corporation
# SPDX-License-Identifier: MIT
"""Module for Pytest MFD Logging."""
