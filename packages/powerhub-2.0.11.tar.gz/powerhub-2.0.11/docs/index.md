# Welcome to PowerHub's documentation!

```{toctree}
:hidden:
:maxdepth: 2
:caption: "Contents:"

installation
philosophy
new
changelog
evasion
usage
troubleshooting
contrib
```


```{include} ../README.md
```
