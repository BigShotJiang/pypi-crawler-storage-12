"""This module contains provider of Spain data."""

from pydtmdl.base.dtm import DTMProvider
from pydtmdl.base.wcs import WCSProvider


class SpainProvider(WCSProvider, DTMProvider):
    """Provider of Spain data."""

    _code = "spain"
    _name = "Spain"
    _region = "ES"
    _icon = "🇪🇸"
    _resolution = 5.0
    _extents = [
        (43.9299999999999997, 27.6299999999999990, 4.9400000000000004, -18.2100000000000009)
    ]

    _url = "https://servicios.idee.es/wcs-inspire/mdt"
    _wcs_version = "2.0.1"
    _source_crs = "EPSG:25830"
    _tile_size = 1000

    def get_wcs_parameters(self, tile: tuple[float, float, float, float]) -> dict:
        return {
            "identifier": ["Elevacion25830_5"],
            "subsets": [("y", str(tile[0]), str(tile[2])), ("x", str(tile[1]), str(tile[3]))],
            "format": "GEOTIFFINT16",
            "timeout": 600,
        }
