"""
Services module for the Verbatim RAG API
"""
