def main():
    print("Hello from mindcluster!")


if __name__ == "__main__":
    main()
