*WARNING*:This project is not functional and is a placeholder form HUAWEI Ascend
