from yt_experiments._version import __version__

version = __version__
