import yt_experiments


def test_yt_experiments():
    assert yt_experiments.version is not None
