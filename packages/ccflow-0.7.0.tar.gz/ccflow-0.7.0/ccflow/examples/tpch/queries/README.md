# Narwhals TPC-H Queries

The queries in this folder are taken from the [Narwhals Repo](https://github.com/narwhals-dev/narwhals/tree/main/tpch/queries).
See the `LICENSE.md` file in this folder for the license of the queries.
