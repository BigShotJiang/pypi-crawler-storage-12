from __future__ import unicode_literals


CERTIFICATE = "specs/certs/gisce.pfx"
CERTIFICATE_PUBLIC = "specs/certs/public.pem"
CERTIFICATE_PASSWD = "gisce"
