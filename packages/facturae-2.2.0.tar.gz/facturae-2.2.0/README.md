# Facturae library

This repo is a fork from [totaler/facturae](https://github.com/totaler/facturae) desired to add XML signature support and some improvements.

Originally it allows you to build Facturae xml format based on v3.2.2

It depends on [libComXML](https://github.com/gisce/libComXML)

## Install

```
$ pip install facturae
```
