# CLI Reference

## Quick help

```bash
# Show top-level help
civic-dev --help

# Show help for a subcommand
civic-dev <subcommand> --help
```
