"""
tMap.

Making Column Transformations using a Mapping JSON file.
"""

from .tMap import tMap

__all__ = ["tMap"]
