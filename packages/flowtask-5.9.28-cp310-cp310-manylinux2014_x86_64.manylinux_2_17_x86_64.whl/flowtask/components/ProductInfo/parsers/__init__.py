from .epson import EpsonParser
from .hp import HPParser
from .canon import CanonParser
from .brother import BrotherParser
from .samsung import SamsungParser 