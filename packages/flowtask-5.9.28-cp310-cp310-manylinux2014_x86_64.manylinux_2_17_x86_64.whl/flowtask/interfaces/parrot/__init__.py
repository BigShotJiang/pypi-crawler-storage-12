"""
Parrot-ai Interfaces for creating Chatbots and IA-Agents integrated with FlowTask.
"""
from .agent import AgentBase
