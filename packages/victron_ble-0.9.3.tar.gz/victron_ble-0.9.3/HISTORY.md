Changelog
=========

0.6.0 (2023)
------------------
- Add VEBus support
- Improve readme 

0.5.1 (2023)
------------------
- Fix DC/DC output voltage when off

0.5.0 (2023)
------------------
- Add DC/DC charger support
- [breaking] Change format of alarm getters

0.4.0 (2022)
------------------
- Add solar charger support


0.3.3 (2022)
------------------
- Update pypi description


0.3.2 (2022)
------------------
- Fix release


0.3.1 (2022)
------------------
- Relax dependency requirements


0.3.0 (2022)
------------------
- Switch delimiter format in CLI


0.2.2 (2022)
------------------
- Change JSON output


0.2.1 (2022)
------------------
- Fix KeyErrors for auxilary data


0.2.0 (2022)
------------------
- Change return types for parsers (breaking)
- Add partial support for DC energy meter mode on SmartShunt


0.1.0 (2022)
------------------
- Add basic data parsing for SmartShunt
