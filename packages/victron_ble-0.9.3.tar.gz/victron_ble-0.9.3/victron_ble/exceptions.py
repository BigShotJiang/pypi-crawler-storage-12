class UnknownDeviceError(Exception):
    pass


class AdvertisementKeyMissingError(Exception):
    pass


class AdvertisementKeyMismatchError(Exception):
    pass
