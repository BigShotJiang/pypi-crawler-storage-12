"""Application commands common to all interfaces."""

from edupsyadmin.api import managers

__all__ = ("managers",)
