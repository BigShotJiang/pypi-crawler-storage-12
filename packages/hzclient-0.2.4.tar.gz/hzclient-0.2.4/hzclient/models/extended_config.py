from .base import _Base


class ExtendedConfig(_Base):
  default_locale: str = "en_GB"
