# Placeholder for pydantic models (to be added as API payloads stabilize).
