# wexa-sdk (Python)

Python SDK for Wexa API.

```python
from wexa_sdk import WexaClient
```
