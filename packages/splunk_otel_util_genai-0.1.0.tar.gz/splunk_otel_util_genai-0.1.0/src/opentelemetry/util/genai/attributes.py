"""
Centralized constants for GenAI telemetry attribute names.
This module replaces inline string literals for span & event attributes.
"""

# Semantic attribute names for core GenAI spans/events
GEN_AI_PROVIDER_NAME = "gen_ai.provider.name"
GEN_AI_INPUT_MESSAGES = "gen_ai.input.messages"
GEN_AI_OUTPUT_MESSAGES = "gen_ai.output.messages"
GEN_AI_FRAMEWORK = "gen_ai.framework"
GEN_AI_COMPLETION_PREFIX = "gen_ai.completion"

# Additional semantic attribute constants
GEN_AI_OPERATION_NAME = "gen_ai.operation.name"
GEN_AI_REQUEST_MODEL = "gen_ai.request.model"
GEN_AI_RESPONSE_MODEL = "gen_ai.response.model"
GEN_AI_RESPONSE_ID = "gen_ai.response.id"
GEN_AI_USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
GEN_AI_USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
GEN_AI_EVALUATION_NAME = "gen_ai.evaluation.name"
GEN_AI_EVALUATION_SCORE_VALUE = "gen_ai.evaluation.score.value"
GEN_AI_EVALUATION_SCORE_LABEL = "gen_ai.evaluation.score.label"
GEN_AI_EVALUATION_EXPLANATION = "gen_ai.evaluation.explanation"
GEN_AI_EVALUATION_ATTRIBUTES_PREFIX = "gen_ai.evaluation.attributes."

# Agent attributes (from semantic conventions)
GEN_AI_AGENT_NAME = "gen_ai.agent.name"
GEN_AI_AGENT_ID = "gen_ai.agent.id"
GEN_AI_AGENT_DESCRIPTION = "gen_ai.agent.description"
GEN_AI_AGENT_TOOLS = "gen_ai.agent.tools"
GEN_AI_AGENT_TYPE = "gen_ai.agent.type"
GEN_AI_AGENT_SYSTEM_INSTRUCTIONS = "gen_ai.agent.system_instructions"
GEN_AI_AGENT_INPUT_CONTEXT = "gen_ai.agent.input_context"
GEN_AI_AGENT_OUTPUT_RESULT = "gen_ai.agent.output_result"

# Workflow attributes (not in semantic conventions)
GEN_AI_WORKFLOW_NAME = "gen_ai.workflow.name"
GEN_AI_WORKFLOW_TYPE = "gen_ai.workflow.type"
GEN_AI_WORKFLOW_DESCRIPTION = "gen_ai.workflow.description"
GEN_AI_WORKFLOW_INITIAL_INPUT = "gen_ai.workflow.initial_input"
GEN_AI_WORKFLOW_FINAL_OUTPUT = "gen_ai.workflow.final_output"

# Step attributes (not in semantic conventions)
GEN_AI_STEP_NAME = "gen_ai.step.name"
GEN_AI_STEP_TYPE = "gen_ai.step.type"
GEN_AI_STEP_OBJECTIVE = "gen_ai.step.objective"
GEN_AI_STEP_SOURCE = "gen_ai.step.source"
GEN_AI_STEP_ASSIGNED_AGENT = "gen_ai.step.assigned_agent"
GEN_AI_STEP_STATUS = "gen_ai.step.status"
GEN_AI_STEP_INPUT_DATA = "gen_ai.step.input_data"
GEN_AI_STEP_OUTPUT_DATA = "gen_ai.step.output_data"

# Embedding attributes
GEN_AI_EMBEDDINGS_DIMENSION_COUNT = "gen_ai.embeddings.dimension.count"
GEN_AI_EMBEDDINGS_INPUT_TEXTS = "gen_ai.embeddings.input.texts"
GEN_AI_REQUEST_ENCODING_FORMATS = "gen_ai.request.encoding_formats"

# Server attributes (from semantic conventions)
SERVER_ADDRESS = "server.address"
SERVER_PORT = "server.port"
