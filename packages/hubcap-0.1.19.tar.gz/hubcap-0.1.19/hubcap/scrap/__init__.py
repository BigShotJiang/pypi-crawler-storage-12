from hubcap.scrap.direct_github_api import *
