"""Data import for characterization experiments.

.. currentmodule:: erlab.io.characterization

Modules
=======

.. autosummary::
   :toctree:

   xrd
   resistance

"""
