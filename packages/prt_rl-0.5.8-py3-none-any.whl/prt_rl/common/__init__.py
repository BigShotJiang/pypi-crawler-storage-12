"""Common functions that are not specific to a single RL algorithm"""
