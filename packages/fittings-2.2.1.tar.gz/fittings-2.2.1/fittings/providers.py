from esi.clients import EsiClientProvider

esi = EsiClientProvider()
