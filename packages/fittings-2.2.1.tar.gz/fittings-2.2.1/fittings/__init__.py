__version__ = '2.2.1'
default_app_config = 'fittings.apps.FittingsConfig'