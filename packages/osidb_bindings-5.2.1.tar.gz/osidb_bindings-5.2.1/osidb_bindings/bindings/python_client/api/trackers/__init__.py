from .trackers_api_v1_file_create import *
from .trackers_api_v2_file_create import *

ENDPOINT_NAMES = [
    "trackers_api_v1_file_create",
    "trackers_api_v2_file_create",
]
