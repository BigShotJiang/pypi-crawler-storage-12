"""
The version of linode_metadata.
"""

__version__ = "v0.3.2"
