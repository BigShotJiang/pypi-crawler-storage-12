"""
Constants values for the linode_metadata package.
"""

LOGGER_NAME = "linode_metadata"
