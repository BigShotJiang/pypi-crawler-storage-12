# sahajmails/__init__.py
__version__ = "1.0.0"
__app_name__ = "SahajMails"