# Version pinning for JS components and Python package
__eox_chart_version__ = "1.0.1"
__eox_layercontrol_version__ = "1.3.1"
__eox_map_version__ = "1.26.2"
__version__ = "0.2.2"
