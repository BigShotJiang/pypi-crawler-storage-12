from django.apps import AppConfig


class WilayahIndonesiaConfig(AppConfig):
    name = 'wilayah_indonesia'
