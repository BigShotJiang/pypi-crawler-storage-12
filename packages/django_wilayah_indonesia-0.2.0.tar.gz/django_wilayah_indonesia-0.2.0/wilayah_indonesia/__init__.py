__title__ = 'Django Wilayah Indonesia'
__version__ = '0.2.0'
__author__ = 'irfanpule'
