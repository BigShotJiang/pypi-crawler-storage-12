# vercel-workers

## Installation

```bash
pip install vercel-workers
```
