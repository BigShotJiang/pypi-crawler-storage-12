"""Shared constants for the cellular automata generation toolkit."""

SCHEMA_VERSION = "1.0.2"

__all__ = ["SCHEMA_VERSION"]
