"""Sanity CMS adapter for Kurt."""

from kurt.integrations.cms.sanity.adapter import SanityAdapter

__all__ = ["SanityAdapter"]
