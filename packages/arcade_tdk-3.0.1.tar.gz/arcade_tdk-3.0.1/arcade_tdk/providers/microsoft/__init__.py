"""Microsoft Graph SDK error adapter for Arcade TDK."""

from arcade_tdk.providers.microsoft.error_adapter import MicrosoftGraphErrorAdapter

__all__ = ["MicrosoftGraphErrorAdapter"]
