# SQL Assembly
Open-source инструмент для борьбы с дублированием SQL-кода через композицию переиспользуемых блоков.

## Проблема

При работе со сложными аналитическими запросами часто возникают одинаковые CTE (Common Table Expressions), которые копируются между разными SQL-файлами. Это приводит к:
- дублированию кода
- сложностям при изменении логики
- ошибкам синхронизации

## Решение

SQL Blocks Assembler позволяет декомпозировать SQL-запросы на переиспользуемые блоки с системой зависимостей. 

### Ключевые возможности

- **📦 Модульность** - разбивайте запросы на логические блоки
- **🔄 Переиспользование** - используйте одни и те же блоки в разных запросах  
- **📐 Зависимости** - автоматическое разрешение порядка выполнения через граф зависимостей

## Быстрый старт

### Установка

```bash
pip install sql-assembly
```
### Пример использования
#### 1. Создайте директорию sql_blocks
#### 2. Создайте SQL блоки в директории sql_blocks
users.sql
```sql
-- name: "users_block"
SELECT 
    id,
    name,
    email
FROM users 
WHERE active = true
```
sales.sql
```sql
-- name: "sales_b"
-- depends: "users_block"
SELECT
    u.name,
    s.amount,
    s.date
FROM sales s
JOIN users_block u ON s.user_id = u.id  -- зависит от блока "users_block"
```
#### 3. Создайте билд ваших sql блоков
```bash
sql-assembly build 
```
#### 4. Использование
##### В консоле
```bash
> sql-assembly assembly sales_b
WITH
users_block AS (
SELECT
    id,
    name,
    email
FROM users
WHERE active = true
),
sales_b AS (
SELECT
    u.name,
    s.amount,
    s.date
FROM sales s
JOIN users_block u ON s.user_id = u.id  -- зависит от блока
)
SELECT * FROM sales_b
```
##### В коде
```python
from sqlblocks import SQLAssembler

assembler = SQLAssembler()
sql = assembler.assembly_sql("sales_b") # В sql будет лежать тот же выввод, что и выше
```

## Архитектура

Основные компоненты
- **SQLBlock** - модель блока с зависимостями
- **SQLBlockRegistry** - реестр для управления блоками
- **SQLAssembler** - ядро для сборки запросов
- **Плагины** - система загрузки блоков

## Поддерживаемые плагины

- **✅ FolderPlugin** - загрузка из файловой системы (пока ограничена настройка)
- **🔄 In progress:** БД, REST API, словари

## Текущий статус

**🚧 Активная разработка** - проект в стадии альфа-тестирования. Основной функционал работает, API может меняться.

Вклад в разработку

Любые предложения и pull requests приветствуются!

## Лицензия

📄 **MIT License** - свободная лицензия с минимальными ограничениями.  
Разрешает использование, модификацию и распространение кода в коммерческих и некоммерческих целях.

Полный текст лицензии доступен в файле [LICENSE](LICENSE).