#! /usr/bin/env python3

from fastmcp import FastMCP

mcp = FastMCP("Demo2 🚀")

@mcp.tool
def get_current_location() -> str:
    """Get the current location of the user"""
    return "Walldorf, Germany at the SAP headquarters"

@mcp.tool
def add_numbers(a: int, b: int) -> int:
    """Add two numbers"""
    return a + b

def main():
    mcp.run(transport="http", host="127.0.0.1", port=8083)

if __name__ == "__main__":
    main()
