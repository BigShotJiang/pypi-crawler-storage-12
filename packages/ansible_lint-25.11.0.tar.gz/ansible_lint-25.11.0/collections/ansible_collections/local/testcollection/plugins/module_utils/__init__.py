"""module_utils package."""

# Some value that can be imported from a module
MY_STRING: str = "foo"
