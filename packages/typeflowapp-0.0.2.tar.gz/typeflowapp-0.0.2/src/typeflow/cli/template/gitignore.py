content = """\
# Python
__pycache__/
*.pyc
*.pyo
*.pyd
env/
venv/
.venv/
.typeflow/
.idea/
*.egg-info/
dist/
build/
"""
