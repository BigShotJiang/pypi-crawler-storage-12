NODE_TEMPLATE = """from typeflow import node

@node()
def {func_name}(*args,**kwargs)->None:
    pass
"""
