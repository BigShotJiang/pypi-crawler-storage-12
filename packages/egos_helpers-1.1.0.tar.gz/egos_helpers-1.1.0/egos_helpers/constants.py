#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" Constants declarations """

# These get overwritten at build time. See build.sh
VERSION = '1.1.0'
BUILD = '2160398825'
NAME = 'egos-helpers'
