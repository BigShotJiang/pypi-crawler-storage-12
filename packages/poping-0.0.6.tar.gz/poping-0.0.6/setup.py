"""
Setup script for backward compatibility.
Configuration is in pyproject.toml
"""

from setuptools import setup

setup()
