from .icon import FAIcon
from .provider import FontAwesomeFontProvider

__all__ = ["FontAwesomeFontProvider", "FAIcon"]
