__version__ = "0.1.2"
from .rar_class import *