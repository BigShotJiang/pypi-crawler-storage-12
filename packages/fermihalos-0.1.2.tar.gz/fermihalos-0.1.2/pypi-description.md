# FermiHalos
Repository containing the codes needed to solve the extended RAR model's equations modeling fermionic dark matter halos.

Visit the webpage here: [FermiHalos](https://santiq22.github.io/FermiHalos).