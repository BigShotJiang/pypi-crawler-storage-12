_disable_notifications = False

__version__ = "1.5.0"

default_app_config = "django_nyt.apps.DjangoNytConfig"
