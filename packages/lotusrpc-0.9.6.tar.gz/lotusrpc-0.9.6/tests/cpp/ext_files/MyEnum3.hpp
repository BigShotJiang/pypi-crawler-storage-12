#pragma once

enum class MyEnum3
{
    V0,
    V55 = 55,
    V200 = 200,
};