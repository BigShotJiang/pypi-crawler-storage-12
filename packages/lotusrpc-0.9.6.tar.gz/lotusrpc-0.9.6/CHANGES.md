---
title: LotusRPC release notes
toc: true
---

LotusRPC is an RPC framework for embedded systems. Here are the release notes.

<!-- towncrier release notes start -->
