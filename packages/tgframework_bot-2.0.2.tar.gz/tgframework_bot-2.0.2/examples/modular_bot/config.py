"""
Конфигурация бота - единственный экземпляр бота
"""

from tgframework import Bot

# Создаём единственный экземпляр бота
bot = Bot(token="YOUR_BOT_TOKEN_HERE")

