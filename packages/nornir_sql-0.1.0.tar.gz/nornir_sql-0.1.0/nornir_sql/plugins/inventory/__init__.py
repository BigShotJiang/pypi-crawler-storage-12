"""nornir_sql.plugins.inventory"""
from .sql import SQLInventory

__all__ = ("SQLInventory",)
