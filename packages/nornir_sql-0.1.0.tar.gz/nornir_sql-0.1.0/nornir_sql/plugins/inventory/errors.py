"""nornir_sql.plugins.inventory.errors"""


class NornirSQLException(Exception):
    pass


class NornirSQLConfigurationError(Exception):
    pass
