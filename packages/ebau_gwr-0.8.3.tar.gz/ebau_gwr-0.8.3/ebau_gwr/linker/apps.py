from django.apps import AppConfig


class LinkerConfig(AppConfig):
    name = "ebau_gwr.linker"
