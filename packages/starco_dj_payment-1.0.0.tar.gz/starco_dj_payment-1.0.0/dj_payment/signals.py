
from django.dispatch import Signal

payment_verified = Signal()
