"""SQLAlchemy repository implementations."""

from .base import BaseRepository

__all__ = ["BaseRepository"]
