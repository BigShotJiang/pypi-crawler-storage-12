"""Persistence adapters - Repository and UoW implementations."""
