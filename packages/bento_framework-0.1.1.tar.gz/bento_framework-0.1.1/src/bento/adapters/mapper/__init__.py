"""Mapper adapters - Object mapping implementations."""
