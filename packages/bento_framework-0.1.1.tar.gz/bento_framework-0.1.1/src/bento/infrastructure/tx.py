def transactional(fn): return fn
