#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" Constants declarations """

# These get overwritten at build time. See build.sh
VERSION = '1.1.1'
BUILD = '2161039284'
NAME = 'egos-helpers'
