"""Tests for Parquet MCP server."""
