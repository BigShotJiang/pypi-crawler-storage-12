Pseudo Labeling
========================

.. autofunction:: mlcpl.pseudo_labeling.CurriculumLabeling

.. autofunction:: mlcpl.pseudo_labeling.CurriculumLabeling.__init__

.. autofunction:: mlcpl.pseudo_labeling.CurriculumLabeling.update