## [1.41.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.41.0...v1.41.1) (2025-11-14)


### chore

* **security:** sanitize example cookies and test literals to avoid secret detection ([6727e95](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6727e958cdd487836bf59f8738f43dd0b2353522))


### Refactor

* update console log formatting in advanced and complete agentic scraper examples to use repeat method ([997ae16](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/997ae16f92e2e69b0807a04d87aa7d2edf0342ea))

## [1.41.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.40.0...v1.41.0) (2025-11-04)


### Features

* add health endpoint ([6edfe67](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6edfe67000627f9b3d435e8d9f7b660e467e54b6))
* update health endpoint ([3e993b3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3e993b3de38bd6358bc4c01252df444895ec5bf6))

## [1.40.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.39.0...v1.40.0) (2025-11-04)


### Features

* add markdown for smartscraper ([9d868b5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9d868b52b2f72cac3fdb13ad0b711e76b1eb3367))

## [1.39.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.38.0...v1.39.0) (2025-11-03)


### Features

* refactoring local scraping ([76f446f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/76f446f1cea174ed5342afe5fb39c6ceee2dec98))

## [1.38.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.37.0...v1.38.0) (2025-10-23)


### Features

* update js rendering ([07a898c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/07a898c69e78d8b7af0242d995b42bd74928b94d))

## [1.37.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.36.0...v1.37.0) (2025-10-23)


### Features

* update render_heavy_js ([2a02cb9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a02cb988fc860352bc679fc7cbc6a0c2dc85b4b))

## [1.36.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.35.0...v1.36.0) (2025-10-16)


### Features

* add stealth mode ([0d658c1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0d658c18ca50588fb165a8e57cd761bef0fbf318))

## [1.35.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.34.0...v1.35.0) (2025-10-15)


### Features

* add docstring ([8984f4b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8984f4b36849a078fc05da8abdf66d646216c022))

## [1.34.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.33.0...v1.34.0) (2025-10-08)


### Features

* add sitemap endpoint ([f5e907e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f5e907ed5de2974817d9fb9bba7b66a0a209b24e))
* add sitemap example ([e07cd76](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e07cd769e6baaff4961f48723e7703cab48e61e6))


### Docs

* update for agentic doc oriented development ([d0a10e5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d0a10e5b1e838a6867317955253a7f5696593601))

## [1.33.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.32.0...v1.33.0) (2025-10-06)


### Features

* add examples ([c260512](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c26051253a11b308b053518a66c2db4e5ccbbb38))
* add generate schema ([5f3ccf2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5f3ccf27c0e0b3b03071900eb19bdaf11b8d1bf6))

## [1.32.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.31.0...v1.32.0) (2025-10-06)


### Features

* update smartcrawler with sitemamp functionalities ([73e1e42](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/73e1e42361d80f7042c5082722f1ac49724b6cde))

## [1.31.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.30.0...v1.31.0) (2025-09-17)


### Features

* add scrape endpoint ([43d1bf6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/43d1bf6877e9ae132f40034888c8fd92946877ec))

## [1.30.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.29.0...v1.30.0) (2025-09-17)


### Features

* add md mode in searchscraper ([c6b513a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c6b513a67413582e107451739f8eef23efa7c9d0))

## [1.29.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.28.0...v1.29.0) (2025-09-16)


### Features

* add render_heavy_js ([8d6994f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8d6994f0885d521cedcd81cdf8e7510453a1eac6))

## [1.28.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.27.0...v1.28.0) (2025-09-16)


### Features

* add render_heavy ([6874ed9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6874ed9a8fb01dad237db59dfda62814c6b6f750))

## [1.27.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.26.0...v1.27.0) (2025-09-14)


### Features

* add user agent ([00bb21b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/00bb21b72a5c859fc610b3a31ddfc42907c02eda))

## [1.26.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.25.1...v1.26.0) (2025-09-11)


### Features

* refactoring of the example folder ([78f2318](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/78f23184626061b22dfde6d6b5b3c3df93f2a73a))

## [1.25.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.25.0...v1.25.1) (2025-09-08)


### Bug Fixes

* removed unused name ([1147570](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1147570d751d1aba75ce274d6c07261d44b5f829))
* scheduled jobs ([6f5cbf3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6f5cbf3335dd7dfffa4803dd33c07c678a56ef0e))

## [1.25.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.24.0...v1.25.0) (2025-09-08)


### Features

* add cron jobs ([d22e8eb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d22e8ebbc3bb978217ae5c486ab8bddd586b24f3))

## [1.24.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.23.0...v1.24.0) (2025-09-03)


### Features

* add new mock ([db6a5ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/db6a5ea8baac250f70358c9ffc2a5ceb4d206993))

## [1.23.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.22.0...v1.23.0) (2025-09-01)


### Features

* add examples ([710129e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/710129e24e6e0d1bb2aa9576c20b4a0e2d483be3))
* add files ([af63d00](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/af63d0034cb7b2ce50123bc4698fe94a6b628cfe))

## [1.22.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.21.0...v1.22.0) (2025-09-01)


### Features

* add files ([e056508](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e056508fd3b706ba40e2ab7cffd26e58f3f0c0ae))

## [1.21.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.20.0...v1.21.0) (2025-09-01)


### Features

* add files for htmlify ([73539a0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/73539a0c486baad7c479ee2fa488e3571ca369df))
* add js files ([013f3ce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/013f3ceb932fa95c8d559a16cd9c78260d844fd8))
* rebranding ([cf5a26d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cf5a26dc7a8c7d135fb5ce8f6c7eea9cca25b15b))

## [1.20.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.19.0...v1.20.0) (2025-08-19)


### Features

* add examples and md mode ([a02cb1e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a02cb1e6c31942c05a633aa5abddc5d3a9e105d9))

## [1.19.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.18.2...v1.19.0) (2025-08-18)


### Features

* add file for python ([2010ea1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2010ea14673a70fdf1aad3ef9b0485ee00a8bf1b))
* add files ([bf3d42d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bf3d42d7534121f21e8cfec267760320c404a7f1))


### chore

* add tests ([b059fd6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b059fd6112b7f391b2b82f10255f27949c0767c7))

## [1.18.2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.18.1...v1.18.2) (2025-08-06)


### Bug Fixes

* removedunused imports ([ad55f88](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ad55f886a08bbf8644e82fd40f4764022ba8cba7))

## [1.18.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.18.0...v1.18.1) (2025-08-06)


### Bug Fixes

* linting errors ([e88a710](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e88a710a6a7c63c68e5ae8f4b632732c6c28f8ce))

## [1.18.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.17.0...v1.18.0) (2025-08-05)


### Features

* add crawling markdown ([e5d573b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e5d573b98c4ecbfeaec794f7bbfb89f429d4da26))
* add js files ([1a9053e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1a9053e3d702e2c447c14d8142a37dc382f60cd0))
* add tests ([7a50122](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7a50122230e77a1e319534bebc6ea28deb7eed5d))

## [1.17.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.16.0...v1.17.0) (2025-07-30)


### Features

* update crawl integrarion ([f1e9efe](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f1e9efe20107ab15496343a5d3de19ff56946b55))

## [1.16.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.15.0...v1.16.0) (2025-07-21)


### Features

* add cookies integration ([043d3b3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/043d3b3284e8d89c434cc86f3e4f2f26b2b2a1b7))
* add js ([767f810](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/767f81018d7060043bcd4420446a57acabff7bf7))

## [1.15.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.14.2...v1.15.0) (2025-07-18)


### Features

* add examples in javascript ([16426de](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/16426de3bf24a153574979c5b1d0cbf84c53ca09))
* add python integration ([5f5ec1b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5f5ec1b9fcf4c62c50ccea29519c9e6f71efc4a0))
* update examples ([2e477d1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2e477d1b550a5044e58b8cfab66d70146544e357))

## [1.14.2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.14.1...v1.14.2) (2025-07-12)


### Bug Fixes

* broken sdk ([b2890d5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b2890d5128b167d181280bfeb846f2e22ef00d54))

## [1.14.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.14.0...v1.14.1) (2025-07-08)


### Bug Fixes

* pyproject ([a3b3121](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a3b312161762bcd4aec898c4bf360fb0dedbc637))

## [1.14.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.13.0...v1.14.0) (2025-07-08)


### Features

* update a tag ([2a4b6aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a4b6aa73c9672dde558b2f487b9fa0637838478))

## [1.1.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.0.0...v1.1.0) (2025-07-08)


### Features

* update lock file ([4ae7aa1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4ae7aa1687e2fdcae145ecb3375ac8ef4a83b411))

## 1.0.0 (2025-07-02)


### Features

* add client integration ([5cbc551](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5cbc551092b33849fdbb1e1468eb35ba8b4f5c20))
* add crawling endpoint ([4cf4ea6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4cf4ea67915e7dbb27dae6d3fa0a71719b28dfec))
* add docstring ([04622dd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/04622dd39bb45223d266aab64ea086b2f1548425))
* add infinite scrolling ([928fb9b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/928fb9b274b55caaec3024bf1c3ca5b865120aa2))
* add infinte scrolling ([3166542](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3166542005eeae2b9fd9e5aaad0abc1966ec4abc))
* add integration for env variables ([2bf03a7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2bf03a7ca7a7936ad2c3b50ded4a6d90161fffa4))
* add integration for local_scraper ([4f6402a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4f6402a94ebfa1b7534fc77ccef2deee5e9295d1))
* add integration for sql ([8ae60c4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ae60c4cfcc070a0a7053862aafaf758e91f465f))
* add integration for the api ([457a2aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/457a2aac6c9afcf4bbb06a99e35a7f5ca5ed5797))
* add localScraper functionality ([7ee0bc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7ee0bc0778c1fc65b6f33bd76d0a4ca8735ce373))
* add markdownify and localscraper ([675de86](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/675de867428efb01d8d9f8aedca34055bce9e974))
* add markdownify functionality ([938274f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/938274f2f67d9e6bca212e6bebd6203349c6494c))
* add optional headers to request ([246f10e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/246f10ef3b24649887a813b5a31d2ffc7b848b1b))
* add requirement files ([65fe013](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/65fe013ff3859b53f17d097bad780038216797e3))
* add scrapegraphai api integration ([382c347](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/382c347061f9a0690cfab09393c11fd5e0ebee70))
* add search number example ([4e93394](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4e93394a2a010cb0459abd7c5cc9aa68d7bc8c8c))
* add time varying timeout ([12afa1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/12afa1d09858b04cb99b158ab2f9f1ea2c4967dd))
* added example of the smartScraper function using a schema ([e79c300](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e79c30038ede5c0b6b6460ecc3d791be6b21b811))
* changed SyncClient to Client ([89210bf](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/89210bf26ee8ee5fd15fd7994b3c1fb0b0ad185e))
* check ([5f9b4ed](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5f9b4edc08e6325124dc335eb1e145cfb7394113))
* enhaced python sdk ([e66e60d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e66e60de27b89c0ea0a9abcd097a001feb7e8147))
* final release maybe semantic? ([d096725](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d09672512605b2d8289abc017ef3c82147a69cd3))
* fix ([d03013c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d03013c5330d9b2728848655e373ea878eebf71d))
* implemented search scraper functionality ([44834c2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/44834c2e3c8523fffe88c9bbd97009a846b5997c))
* implemented support for requests with schema ([ad5f0b4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ad5f0b45d2dc183b63b27f5e5f4dd4b9801aa008))
* maybe final release? ([40035f3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/40035f3f0d9c8c2fcecbcd603397c38af405153a))
* merged localscraper into smartscraper ([eaac552](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/eaac552493f4a245cfb2246713a8febf87851d05))
* modified icons ([836faea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/836faea0975e7b1dcc13495a0c76c7d50cbedbaa))
* refactoring of the folders ([e613e2e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e613e2e07c95a4e5348d1a74b8ba9f1f853a0911))
* refctoring of the folder ([3085b5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3085b5a74f748c4ce42fa6e02fd04029a4dc25a5))
* removed local scraper ([021bf6d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/021bf6dcc6bd216cc8129b146e1f7892e52cf244))
* revert to old release ([6565b3e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6565b3e937958fc0b897eb84456643e02d90790e))
* searchscraper ([e281e0d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e281e0d798eccbe8114c75f8a3e2a2a4ab8cca25))
* semantic relaase ([93759c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/93759c39b8f44ee1c51fac843544c93e87708760))
* semantic release ([9613ba9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9613ba933274fe1bddb56339aae40617eaf46d65))
* semantic release ([956eceb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/956ecebc27dae00fa0b487f97eec8114dfc3a1bd))
* semantic release ([0bc1358](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0bc135814e6ebb438313b4d466357b2e5631f09d))
* splitted files ([5337d1e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5337d1e39f7625165066c4aada771a4eb25fa635))
* test ([9bec234](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9bec2340b0e507409c6ae221a8eb0ea93178a82f))
* test semantic release ([5dbb0cc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5dbb0cc1243be847f2d7dee4f6e3df0c6550d8aa))
* test semantic release ([66c789e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/66c789e907d69b6c8a919a2c7d4a2c4a79826d3d))
* test semantic release ([d63fdda](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d63fddaa3794677c862313b0058d34ddc358441d))
* test semantic release ([682baa3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/682baa39695f564b684568d9a6bf23ecda00b5ec))
* try semantic release ([d686c1f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d686c1ff1911885a553e68897efa95afcd09a503))
* update doc readme ([e317b1b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e317b1b0135c0d0134846ea0b0b63552773cff45))
* update version ([4d1851d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4d1851dae4825570f4ba74381595037512a8103b))
* update versions ([282aa5d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/282aa5d7c98d6e0e9a3781cb6be477d1eed23bcf))
* updated readmes ([d485cf0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d485cf0ee0bd331e5970a158636dcdb44db98d81))


### Bug Fixes

* .toml file ([31d9ad8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31d9ad8d65fde79022a9971c1b463ccd5452820a))
* add enw timeout ([cfc565c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cfc565c5ad23f547138be0466820c1c2dee6aa47))
* add new python compatibility ([45d24a6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/45d24a6a3d1c3090f1c575cf4fe6a8d80d637c38))
* add revert ([b81ec1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b81ec1d37d0a1635f444525e1e4a99823f5cea83))
* come back to py 3.10 ([e10bb5c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e10bb5c0ed0cd93a36b97eb91d634db8aac575d7))
* fixed configuration for ignored files ([76e1d0e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/76e1d0edbfbb796b87c3608610e4d4125cdf4bfd))
* fixed HttpError messages ([935dac1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/935dac100185b3622aa2744a38a2d4ce740deaa5))
* fixed schema example ([4be2bd0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4be2bd0310cb860864e7666d5613d1664818e505))
* houses examples and typos ([e787776](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e787776125215bc5c9d40e6691c971d46651548e))
* improve api desc ([87e2040](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/87e2040ce4fd090cf511f67048f6275502120ab7))
* logger working properly now ([6c619c1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6c619c11ea90c81e0054b36504cc3d9e62dce249))
* make timeout optional ([09b0cc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/09b0cc015d2b8f8848a625a7d75e36a5caf7b546))
* minor fix version ([d05bb6a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d05bb6a34a15d45ebce2056c89c146f4fcf5a35f))
* pyproject ([d5005a0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d5005a00671148c22956eb52f4bedc369f9361c2))
* pyproject ([d04f0aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d04f0aa770ebe480f293b60db0c5883f2c39e0f3))
* pyproject.toml ([1c2ae7f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1c2ae7fc9ffc485c9d36020da3fcc90037ea3c98))
* pyproject.toml ([a509471](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a5094710e63b903da61e359b9ea8f79bf57b48f2))
* python version ([98b859d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/98b859dab0effc966d1731372750e14abb0373c8))
* readme js sdk ([6f95f27](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6f95f2782354ab62ab2ad320e338c4be2701c20b))
* removed wrong information ([75ef97e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/75ef97eae8b31bac72a3e999e3423b8a455000f6))
* semanti release 2 ([b008a3b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b008a3bc691b52be167edd1cbd9f0d1d689d0989))
* semantic release ([4d230ae](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4d230ae6b2404466b956c7a567223a03ff6ae448))
* sync client ([8fee46f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fee46f7645c5b9e0cfa6d3d90b7d7e4e30567eb))
* the "workspace" key has been removed because it was conflicting with the package.json file in the scrapegraph-js folder. ([15e590c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15e590ca23b3ecfeabd387af3eb7b42548337f87))
* timeout ([57f6593](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/57f6593ee632595c39a9241009a0e71120baecc2))
* update ([527539b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/527539b01dcfc30f22bd9ca1c356613459c35569))
* updated comment ([62e2792](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/62e2792174d5403f05c73aeb64bb515d722721d2))
* updated env variable loading ([e259ed1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e259ed173f249c935e2de3c54831edf9fa954caa))
* updated hatchling version ([2b41262](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2b412623aec22c3be37061347ec25e74ea8d6126))


### chore

* added dotenv pakage dependency ([e88abab](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e88abab18a3a375b6090790af4a1012381af164c))
* added more information about the package ([a91198d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a91198de86e9be84b20aeac0e69eba81392ad39b))
* added Zod package dependency ([49d3a59](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/49d3a59f916ac27170c3640775f0844063afd65a))
* changed pakage name ([f93e49b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f93e49bff839b8de2c4f41c638c9c4df76592463))
* fix _make_request not using it ([05f61ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/05f61ea10a8183fc8863b1703fd4fbf6ca921c93))
* fix pylint scripts ([7a593a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7a593a8a116d863d573f68d6e2282ba6c2204cbc))
* fix pyproject version ([bc0c722](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc0c722986d65c500496b91f5cd8cec23b19189a))
* fix semantic release, migrate to uv ([a70e1b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a70e1b7f86671e5d7a49c882b4c854d32c6b5944))
* improved url validation ([25072a9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/25072a9976873e59169cd7a9bcce5797f5dcbfa3))
* refactor examples ([85738d8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/85738d87117cf803e02c608b2476d24265ce65c6))
* set up CI scripts ([7b33f8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7b33f8f78e37c13eafcc0193fe7a2b2efb258cdf))
* set up eslint and prettier for code linting and formatting ([9d54406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9d544066c08d6dca6e4dd764f665e56912bc4285))
* update workflow scripts ([80ae3f7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/80ae3f761cc1b5cb860b9d75ee14920e37725cc0))
* **tests:** updated tests ([b33f0b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b33f0b7b602e29ea86ae2bfff7862279b5cca9ec))


### Docs

* added an example of the smartScraper functionality using a schema ([ae245c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ae245c83d70259a8eb5c626c21dfb3a0f6e76f62))
* added api reference ([f87a7c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f87a7c8fc3b39360f2339731af52b0b0766c80c2))
* added api reference ([0cf5f3a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0cf5f3ae4b5b8704e86fc21b298a053f3bd9822e))
* added cookbook reference ([54841e5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/54841e5c0f705a64c4295e4fc8a414af0e62ca4f))
* added langchain-scrapegraph examples ([b9d771e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b9d771eab5b0eace6eb03f0075094e3cc51efce9))
* added new image ([b710bd3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b710bd3d60603e3b720b1a811ad91f35b1bea832))
* added open in colab badge ([9e5519c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e5519c55be9a20da0d4a08e363a66bfacc970be))
* added two langchain-scrapegraph examples ([b18b14d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b18b14d41eab4cdd7ed8d6fdc7ceb5e9f8fa9b24))
* added two new examples ([b3fd406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b3fd406680ab9aab2d99640fbe5244a9ebb14263))
* **cookbook:** added two new examples ([2a8fb8c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a8fb8c45af4ff5b03483c7031ab541a03e36b83))
* added wired langgraph react agent ([69c82ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69c82ea3d068c677866cb062a4b0345073dce6de))
* added zillow example ([1eb365c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1eb365c7cf41aa8b04c96bd2667a7bddff7f6220))
* api reference ([2f3210c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2f3210cd37e40d29699fada48e754449e4b163e7))
* fixed cookbook images and urls ([b743830](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b74383090261f3d242fc58c16d8071f6da05dc97))
* github trending sdk ([f0890ef](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f0890efa79ca884d1825e4d47b92601d092d0080))
* improved examples ([5245394](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/52453944c5be0a71459bb324731331b194346174))
* improved main readme ([8e280c6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8e280c64a64bb3d36b19bff74f90ea305852aceb))
* link typo ([d6038b0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d6038b0e1ed636959633ec03524ff5cf1cad3164))
* llama-index @VinciGit00 ([b847053](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b8470535f52730f6d1757912b420e35ef94688b4))
* research agent ([628fdd5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/628fdd5c0b0fbe371648b8a0171461ff2d615257))
* updated new documentation urls ([bd4cbf8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bd4cbf81e3c5740c1cc77b6204447cd7878c3978))
* updated precommit and installation guide ([bca95c5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bca95c5d6f1bd8fff3d0303b562ac229c6936f5d))
* updated readme ([2a1e643](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a1e64328ca4b20e9593b65517e7c5bf1fe43ffa))


### Refactor

* code refactoring ([197638b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/197638b7742854fceca756261b96e74024bdfc3f))
* code refactoring ([1be81f0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1be81f0539c631659dcf7e90540cebdd8539ae6a))
* code refactoring ([6270a6e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6270a6e43782f9efbb407e71b1ca7c57c37db38a))
* improved code structure ([d1a33dc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d1a33dcf87c401043b3ff7676638daadeca0f2c8))
* renamed functions ([95719e3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/95719e3b4a2c78de381bfdc39a077c42fdddec05))
* simplify infinite scroll config by replacing scroll_options with number_of_scrolls parameter ([ffc32ce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ffc32ce05a5c3546579142181466e34c3027ec67))
* update readme ([fee30c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fee30c3355ffee30fc1bffb56984085000df6192))


### Test

* Add coverage improvement test for scrapegraph-py/tests/test_localscraper.py ([84ba517](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/84ba51747898cec2bb74b4d6c4a5ea398b56bca7))
* Add coverage improvement test for scrapegraph-py/tests/test_markdownify.py ([c39dbb0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c39dbb034ab89e1830da63f24f534ee070046c5d))
* Add coverage improvement test for scrapegraph-py/tests/test_smartscraper.py ([2216f6f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2216f6f309cac66f6688c0d84190d71c29290415))


### CI

* **release:** 1.0.0 [skip ci] ([5217502](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/52175023e4735aed6a1f8d6532779e0a4c81b2a5))
* **release:** 1.0.0 [skip ci] ([6ce94d6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6ce94d69309d5cab85a57817a46e1d5363fc3588))
* **release:** 1.0.0 [skip ci] ([7fef9f1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7fef9f10cfb8ea8f7f52dcb543571937848b393c))
* **release:** 1.0.0 [skip ci] ([99af971](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/99af971aa0df717ae2f8c4148d60c45870926100))
* **release:** 1.0.0 [skip ci] ([46756ac](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/46756ac26d7b540e523f3a23afe688673293e8c6))
* **release:** 1.0.0 [skip ci] ([635f7d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/635f7d09b172e6b00cd498ebf2d95799c82e0821))
* **release:** 1.0.0 [skip ci] ([763e52b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/763e52bdf696192eb8f0143f3e97ccd40ae0bb8c))
* **release:** 1.0.0 [skip ci] ([0a7a968](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0a7a96864fbe38f8b2b2887807415f8869d96c65))
* **release:** 1.1.0 [skip ci] ([fd55dc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fd55dc0d82f16dc277a9c45cf2e687245c4b76a2))
* **release:** 1.10.0 [skip ci] ([69a5d7d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69a5d7d66236050c2ba9c88fd53785f573d34fa2))
* **release:** 1.10.1 [skip ci] ([48eb09d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/48eb09d406bd1dafb02bc9b001c6ef9752c4125a))
* **release:** 1.10.2 [skip ci] ([9f2a50c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9f2a50c940a70aa04b4484053ccae3a1cfb4148c))
* **release:** 1.11.0 [skip ci] ([82fc505](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/82fc50507bb610f1059a12779a90d7d200c1759b))
* **release:** 1.11.0-beta.1 [skip ci] ([e25a870](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e25a87013eb7be0db193d0093392eb78f3f1cfb6))
* **release:** 1.12.0 [skip ci] ([15b9626](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15b9626c11f84c60b496d70422a2df86e76d49a5))
* **release:** 1.2.0 [skip ci] ([8ebd90b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ebd90b963de62c879910d7cf64f491bcf4c47f7))
* **release:** 1.2.1 [skip ci] ([bc5c9a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc5c9a8db64d0c792566f58d5265f6936edc5526))
* **release:** 1.2.2 [skip ci] ([14dcf99](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/14dcf99173a589557b7a2860716eedbee892b16b))
* **release:** 1.3.0 [skip ci] ([daf43d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/daf43d06761d85608b9599337e111da694a858a6))
* **release:** 1.4.0 [skip ci] ([cb18d8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cb18d8fb219dd55b6478ee33c051a40a091c4fd0))
* **release:** 1.4.1 [skip ci] ([0b42489](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0b424891395f0630c9886eb1a8a23232603e856f))
* **release:** 1.4.2 [skip ci] ([e4ad100](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e4ad100e3004a4b7c63f865d3f12398a080bb599))
* **release:** 1.4.3 [skip ci] ([11a0edc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/11a0edc54b299eea60a382c2781d3d1ac0084c3f))
* **release:** 1.4.3-beta.1 [skip ci] ([c4ba791](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c4ba791e45edfbff13332117f2583781354f90d6))
* **release:** 1.4.3-beta.2 [skip ci] ([3110601](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31106014d662745fa9afef6083f61452508b67fb))
* **release:** 1.4.3-beta.3 [skip ci] ([b6f7589](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b6f75899bd9f5d906cb5034b3a74c3ef46280537))
* **release:** 1.5.0 [skip ci] ([c7c91bd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c7c91bd7c6f3550089d1231b2167ca18921fd48f))
* **release:** 1.5.0-beta.1 [skip ci] ([298fce2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/298fce2058f7f39546afa022a135b497b9d8024d))
* **release:** 1.6.0 [skip ci] ([1b0fdce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1b0fdce5827378dc80a5cd0a83e7444d50db79c1))
* **release:** 1.6.0-beta.1 [skip ci] ([ba7588d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ba7588d978217d2c2fce5404d989c527fe63bb16))
* **release:** 1.7.0 [skip ci] ([bb2847c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bb2847ca1f7045c86b5fa26cb1c16422039bfafb))
* **release:** 1.7.0-beta.1 [skip ci] ([aab21db](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/aab21db9230800707c7814b0702e7d1f70a6a4f4))
* **release:** 1.8.0 [skip ci] ([8fa12bb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fa12bbc56dbcb4976551818ae5c99132ac393b3))
* **release:** 1.9.0 [skip ci] ([a21e331](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a21e3317a48632bbb442d352c47e5b155ee96d94))
* **release:** 1.9.0-beta.1 [skip ci] ([3173f66](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3173f661ff6d954a6059c8e899faba391cb51276))
* **release:** 1.9.0-beta.2 [skip ci] ([c2fef9e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2fef9e5405e16ba5d61a8b2fbf0b1c03c6fa306))
* **release:** 1.9.0-beta.3 [skip ci] ([ca9fa71](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ca9fa71d2e68aafa2a438b659349e1fb4589ebdf))
* **release:** 1.9.0-beta.4 [skip ci] ([b2e5ab1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b2e5ab167c0777449ac4974674abd294e0f7e41d))
* **release:** 1.9.0-beta.5 [skip ci] ([604aea3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/604aea3c6aff087388d6014f0d1fcd7df0c66f69))
* **release:** 1.9.0-beta.6 [skip ci] ([19c33b2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/19c33b2e0d8160d78549878c64355e16702d406a))
* **release:** 1.9.0-beta.7 [skip ci] ([c232796](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2327961096cd9f9ad3b0f54cf242a7d99ab11bc))

## 1.0.0 (2025-07-02)


### Features

* add client integration ([5cbc551](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5cbc551092b33849fdbb1e1468eb35ba8b4f5c20))
* add crawling endpoint ([4cf4ea6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4cf4ea67915e7dbb27dae6d3fa0a71719b28dfec))
* add docstring ([04622dd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/04622dd39bb45223d266aab64ea086b2f1548425))
* add infinite scrolling ([928fb9b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/928fb9b274b55caaec3024bf1c3ca5b865120aa2))
* add infinte scrolling ([3166542](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3166542005eeae2b9fd9e5aaad0abc1966ec4abc))
* add integration for env variables ([2bf03a7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2bf03a7ca7a7936ad2c3b50ded4a6d90161fffa4))
* add integration for local_scraper ([4f6402a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4f6402a94ebfa1b7534fc77ccef2deee5e9295d1))
* add integration for sql ([8ae60c4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ae60c4cfcc070a0a7053862aafaf758e91f465f))
* add integration for the api ([457a2aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/457a2aac6c9afcf4bbb06a99e35a7f5ca5ed5797))
* add localScraper functionality ([7ee0bc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7ee0bc0778c1fc65b6f33bd76d0a4ca8735ce373))
* add markdownify and localscraper ([675de86](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/675de867428efb01d8d9f8aedca34055bce9e974))
* add markdownify functionality ([938274f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/938274f2f67d9e6bca212e6bebd6203349c6494c))
* add optional headers to request ([246f10e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/246f10ef3b24649887a813b5a31d2ffc7b848b1b))
* add requirement files ([65fe013](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/65fe013ff3859b53f17d097bad780038216797e3))
* add scrapegraphai api integration ([382c347](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/382c347061f9a0690cfab09393c11fd5e0ebee70))
* add search number example ([4e93394](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4e93394a2a010cb0459abd7c5cc9aa68d7bc8c8c))
* add time varying timeout ([12afa1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/12afa1d09858b04cb99b158ab2f9f1ea2c4967dd))
* added example of the smartScraper function using a schema ([e79c300](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e79c30038ede5c0b6b6460ecc3d791be6b21b811))
* changed SyncClient to Client ([89210bf](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/89210bf26ee8ee5fd15fd7994b3c1fb0b0ad185e))
* check ([5f9b4ed](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5f9b4edc08e6325124dc335eb1e145cfb7394113))
* enhaced python sdk ([e66e60d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e66e60de27b89c0ea0a9abcd097a001feb7e8147))
* final release maybe semantic? ([d096725](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d09672512605b2d8289abc017ef3c82147a69cd3))
* fix ([d03013c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d03013c5330d9b2728848655e373ea878eebf71d))
* implemented search scraper functionality ([44834c2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/44834c2e3c8523fffe88c9bbd97009a846b5997c))
* implemented support for requests with schema ([ad5f0b4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ad5f0b45d2dc183b63b27f5e5f4dd4b9801aa008))
* maybe final release? ([40035f3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/40035f3f0d9c8c2fcecbcd603397c38af405153a))
* merged localscraper into smartscraper ([eaac552](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/eaac552493f4a245cfb2246713a8febf87851d05))
* modified icons ([836faea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/836faea0975e7b1dcc13495a0c76c7d50cbedbaa))
* refactoring of the folders ([e613e2e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e613e2e07c95a4e5348d1a74b8ba9f1f853a0911))
* refctoring of the folder ([3085b5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3085b5a74f748c4ce42fa6e02fd04029a4dc25a5))
* removed local scraper ([021bf6d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/021bf6dcc6bd216cc8129b146e1f7892e52cf244))
* revert to old release ([6565b3e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6565b3e937958fc0b897eb84456643e02d90790e))
* searchscraper ([e281e0d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e281e0d798eccbe8114c75f8a3e2a2a4ab8cca25))
* semantic relaase ([93759c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/93759c39b8f44ee1c51fac843544c93e87708760))
* semantic release ([9613ba9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9613ba933274fe1bddb56339aae40617eaf46d65))
* semantic release ([956eceb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/956ecebc27dae00fa0b487f97eec8114dfc3a1bd))
* semantic release ([0bc1358](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0bc135814e6ebb438313b4d466357b2e5631f09d))
* splitted files ([5337d1e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5337d1e39f7625165066c4aada771a4eb25fa635))
* test ([9bec234](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9bec2340b0e507409c6ae221a8eb0ea93178a82f))
* test semantic release ([5dbb0cc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5dbb0cc1243be847f2d7dee4f6e3df0c6550d8aa))
* test semantic release ([66c789e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/66c789e907d69b6c8a919a2c7d4a2c4a79826d3d))
* test semantic release ([d63fdda](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d63fddaa3794677c862313b0058d34ddc358441d))
* test semantic release ([682baa3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/682baa39695f564b684568d9a6bf23ecda00b5ec))
* try semantic release ([d686c1f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d686c1ff1911885a553e68897efa95afcd09a503))
* update doc readme ([e317b1b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e317b1b0135c0d0134846ea0b0b63552773cff45))
* update version ([4d1851d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4d1851dae4825570f4ba74381595037512a8103b))
* update versions ([282aa5d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/282aa5d7c98d6e0e9a3781cb6be477d1eed23bcf))
* updated readmes ([d485cf0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d485cf0ee0bd331e5970a158636dcdb44db98d81))


### Bug Fixes

* .toml file ([31d9ad8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31d9ad8d65fde79022a9971c1b463ccd5452820a))
* add enw timeout ([cfc565c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cfc565c5ad23f547138be0466820c1c2dee6aa47))
* add new python compatibility ([45d24a6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/45d24a6a3d1c3090f1c575cf4fe6a8d80d637c38))
* add revert ([b81ec1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b81ec1d37d0a1635f444525e1e4a99823f5cea83))
* come back to py 3.10 ([e10bb5c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e10bb5c0ed0cd93a36b97eb91d634db8aac575d7))
* fixed configuration for ignored files ([76e1d0e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/76e1d0edbfbb796b87c3608610e4d4125cdf4bfd))
* fixed HttpError messages ([935dac1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/935dac100185b3622aa2744a38a2d4ce740deaa5))
* fixed schema example ([4be2bd0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4be2bd0310cb860864e7666d5613d1664818e505))
* houses examples and typos ([e787776](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e787776125215bc5c9d40e6691c971d46651548e))
* improve api desc ([87e2040](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/87e2040ce4fd090cf511f67048f6275502120ab7))
* logger working properly now ([6c619c1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6c619c11ea90c81e0054b36504cc3d9e62dce249))
* make timeout optional ([09b0cc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/09b0cc015d2b8f8848a625a7d75e36a5caf7b546))
* minor fix version ([d05bb6a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d05bb6a34a15d45ebce2056c89c146f4fcf5a35f))
* pyproject ([d5005a0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d5005a00671148c22956eb52f4bedc369f9361c2))
* pyproject ([d04f0aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d04f0aa770ebe480f293b60db0c5883f2c39e0f3))
* pyproject.toml ([1c2ae7f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1c2ae7fc9ffc485c9d36020da3fcc90037ea3c98))
* pyproject.toml ([a509471](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a5094710e63b903da61e359b9ea8f79bf57b48f2))
* python version ([98b859d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/98b859dab0effc966d1731372750e14abb0373c8))
* readme js sdk ([6f95f27](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6f95f2782354ab62ab2ad320e338c4be2701c20b))
* removed wrong information ([75ef97e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/75ef97eae8b31bac72a3e999e3423b8a455000f6))
* semanti release 2 ([b008a3b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b008a3bc691b52be167edd1cbd9f0d1d689d0989))
* semantic release ([4d230ae](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4d230ae6b2404466b956c7a567223a03ff6ae448))
* sync client ([8fee46f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fee46f7645c5b9e0cfa6d3d90b7d7e4e30567eb))
* the "workspace" key has been removed because it was conflicting with the package.json file in the scrapegraph-js folder. ([15e590c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15e590ca23b3ecfeabd387af3eb7b42548337f87))
* timeout ([57f6593](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/57f6593ee632595c39a9241009a0e71120baecc2))
* updated comment ([62e2792](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/62e2792174d5403f05c73aeb64bb515d722721d2))
* updated env variable loading ([e259ed1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e259ed173f249c935e2de3c54831edf9fa954caa))
* updated hatchling version ([2b41262](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2b412623aec22c3be37061347ec25e74ea8d6126))


### chore

* added dotenv pakage dependency ([e88abab](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e88abab18a3a375b6090790af4a1012381af164c))
* added more information about the package ([a91198d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a91198de86e9be84b20aeac0e69eba81392ad39b))
* added Zod package dependency ([49d3a59](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/49d3a59f916ac27170c3640775f0844063afd65a))
* changed pakage name ([f93e49b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f93e49bff839b8de2c4f41c638c9c4df76592463))
* fix _make_request not using it ([05f61ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/05f61ea10a8183fc8863b1703fd4fbf6ca921c93))
* fix pylint scripts ([7a593a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7a593a8a116d863d573f68d6e2282ba6c2204cbc))
* fix pyproject version ([bc0c722](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc0c722986d65c500496b91f5cd8cec23b19189a))
* fix semantic release, migrate to uv ([a70e1b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a70e1b7f86671e5d7a49c882b4c854d32c6b5944))
* improved url validation ([25072a9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/25072a9976873e59169cd7a9bcce5797f5dcbfa3))
* refactor examples ([85738d8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/85738d87117cf803e02c608b2476d24265ce65c6))
* set up CI scripts ([7b33f8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7b33f8f78e37c13eafcc0193fe7a2b2efb258cdf))
* set up eslint and prettier for code linting and formatting ([9d54406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9d544066c08d6dca6e4dd764f665e56912bc4285))
* update workflow scripts ([80ae3f7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/80ae3f761cc1b5cb860b9d75ee14920e37725cc0))
* **tests:** updated tests ([b33f0b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b33f0b7b602e29ea86ae2bfff7862279b5cca9ec))


### Docs

* added an example of the smartScraper functionality using a schema ([ae245c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ae245c83d70259a8eb5c626c21dfb3a0f6e76f62))
* added api reference ([f87a7c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f87a7c8fc3b39360f2339731af52b0b0766c80c2))
* added api reference ([0cf5f3a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0cf5f3ae4b5b8704e86fc21b298a053f3bd9822e))
* added cookbook reference ([54841e5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/54841e5c0f705a64c4295e4fc8a414af0e62ca4f))
* added langchain-scrapegraph examples ([b9d771e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b9d771eab5b0eace6eb03f0075094e3cc51efce9))
* added new image ([b710bd3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b710bd3d60603e3b720b1a811ad91f35b1bea832))
* added open in colab badge ([9e5519c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e5519c55be9a20da0d4a08e363a66bfacc970be))
* added two langchain-scrapegraph examples ([b18b14d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b18b14d41eab4cdd7ed8d6fdc7ceb5e9f8fa9b24))
* added two new examples ([b3fd406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b3fd406680ab9aab2d99640fbe5244a9ebb14263))
* **cookbook:** added two new examples ([2a8fb8c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a8fb8c45af4ff5b03483c7031ab541a03e36b83))
* added wired langgraph react agent ([69c82ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69c82ea3d068c677866cb062a4b0345073dce6de))
* added zillow example ([1eb365c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1eb365c7cf41aa8b04c96bd2667a7bddff7f6220))
* api reference ([2f3210c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2f3210cd37e40d29699fada48e754449e4b163e7))
* fixed cookbook images and urls ([b743830](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b74383090261f3d242fc58c16d8071f6da05dc97))
* github trending sdk ([f0890ef](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f0890efa79ca884d1825e4d47b92601d092d0080))
* improved examples ([5245394](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/52453944c5be0a71459bb324731331b194346174))
* improved main readme ([8e280c6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8e280c64a64bb3d36b19bff74f90ea305852aceb))
* link typo ([d6038b0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d6038b0e1ed636959633ec03524ff5cf1cad3164))
* llama-index @VinciGit00 ([b847053](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b8470535f52730f6d1757912b420e35ef94688b4))
* research agent ([628fdd5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/628fdd5c0b0fbe371648b8a0171461ff2d615257))
* updated new documentation urls ([bd4cbf8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bd4cbf81e3c5740c1cc77b6204447cd7878c3978))
* updated precommit and installation guide ([bca95c5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bca95c5d6f1bd8fff3d0303b562ac229c6936f5d))
* updated readme ([2a1e643](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a1e64328ca4b20e9593b65517e7c5bf1fe43ffa))


### Refactor

* code refactoring ([197638b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/197638b7742854fceca756261b96e74024bdfc3f))
* code refactoring ([1be81f0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1be81f0539c631659dcf7e90540cebdd8539ae6a))
* code refactoring ([6270a6e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6270a6e43782f9efbb407e71b1ca7c57c37db38a))
* improved code structure ([d1a33dc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d1a33dcf87c401043b3ff7676638daadeca0f2c8))
* renamed functions ([95719e3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/95719e3b4a2c78de381bfdc39a077c42fdddec05))
* simplify infinite scroll config by replacing scroll_options with number_of_scrolls parameter ([ffc32ce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ffc32ce05a5c3546579142181466e34c3027ec67))
* update readme ([fee30c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fee30c3355ffee30fc1bffb56984085000df6192))


### Test

* Add coverage improvement test for scrapegraph-py/tests/test_localscraper.py ([84ba517](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/84ba51747898cec2bb74b4d6c4a5ea398b56bca7))
* Add coverage improvement test for scrapegraph-py/tests/test_markdownify.py ([c39dbb0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c39dbb034ab89e1830da63f24f534ee070046c5d))
* Add coverage improvement test for scrapegraph-py/tests/test_smartscraper.py ([2216f6f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2216f6f309cac66f6688c0d84190d71c29290415))


### CI

* **release:** 1.0.0 [skip ci] ([6ce94d6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6ce94d69309d5cab85a57817a46e1d5363fc3588))
* **release:** 1.0.0 [skip ci] ([7fef9f1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7fef9f10cfb8ea8f7f52dcb543571937848b393c))
* **release:** 1.0.0 [skip ci] ([99af971](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/99af971aa0df717ae2f8c4148d60c45870926100))
* **release:** 1.0.0 [skip ci] ([46756ac](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/46756ac26d7b540e523f3a23afe688673293e8c6))
* **release:** 1.0.0 [skip ci] ([635f7d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/635f7d09b172e6b00cd498ebf2d95799c82e0821))
* **release:** 1.0.0 [skip ci] ([763e52b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/763e52bdf696192eb8f0143f3e97ccd40ae0bb8c))
* **release:** 1.0.0 [skip ci] ([0a7a968](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0a7a96864fbe38f8b2b2887807415f8869d96c65))
* **release:** 1.1.0 [skip ci] ([fd55dc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fd55dc0d82f16dc277a9c45cf2e687245c4b76a2))
* **release:** 1.10.0 [skip ci] ([69a5d7d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69a5d7d66236050c2ba9c88fd53785f573d34fa2))
* **release:** 1.10.1 [skip ci] ([48eb09d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/48eb09d406bd1dafb02bc9b001c6ef9752c4125a))
* **release:** 1.10.2 [skip ci] ([9f2a50c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9f2a50c940a70aa04b4484053ccae3a1cfb4148c))
* **release:** 1.11.0 [skip ci] ([82fc505](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/82fc50507bb610f1059a12779a90d7d200c1759b))
* **release:** 1.11.0-beta.1 [skip ci] ([e25a870](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e25a87013eb7be0db193d0093392eb78f3f1cfb6))
* **release:** 1.12.0 [skip ci] ([15b9626](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15b9626c11f84c60b496d70422a2df86e76d49a5))
* **release:** 1.2.0 [skip ci] ([8ebd90b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ebd90b963de62c879910d7cf64f491bcf4c47f7))
* **release:** 1.2.1 [skip ci] ([bc5c9a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc5c9a8db64d0c792566f58d5265f6936edc5526))
* **release:** 1.2.2 [skip ci] ([14dcf99](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/14dcf99173a589557b7a2860716eedbee892b16b))
* **release:** 1.3.0 [skip ci] ([daf43d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/daf43d06761d85608b9599337e111da694a858a6))
* **release:** 1.4.0 [skip ci] ([cb18d8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cb18d8fb219dd55b6478ee33c051a40a091c4fd0))
* **release:** 1.4.1 [skip ci] ([0b42489](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0b424891395f0630c9886eb1a8a23232603e856f))
* **release:** 1.4.2 [skip ci] ([e4ad100](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e4ad100e3004a4b7c63f865d3f12398a080bb599))
* **release:** 1.4.3 [skip ci] ([11a0edc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/11a0edc54b299eea60a382c2781d3d1ac0084c3f))
* **release:** 1.4.3-beta.1 [skip ci] ([c4ba791](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c4ba791e45edfbff13332117f2583781354f90d6))
* **release:** 1.4.3-beta.2 [skip ci] ([3110601](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31106014d662745fa9afef6083f61452508b67fb))
* **release:** 1.4.3-beta.3 [skip ci] ([b6f7589](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b6f75899bd9f5d906cb5034b3a74c3ef46280537))
* **release:** 1.5.0 [skip ci] ([c7c91bd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c7c91bd7c6f3550089d1231b2167ca18921fd48f))
* **release:** 1.5.0-beta.1 [skip ci] ([298fce2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/298fce2058f7f39546afa022a135b497b9d8024d))
* **release:** 1.6.0 [skip ci] ([1b0fdce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1b0fdce5827378dc80a5cd0a83e7444d50db79c1))
* **release:** 1.6.0-beta.1 [skip ci] ([ba7588d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ba7588d978217d2c2fce5404d989c527fe63bb16))
* **release:** 1.7.0 [skip ci] ([bb2847c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bb2847ca1f7045c86b5fa26cb1c16422039bfafb))
* **release:** 1.7.0-beta.1 [skip ci] ([aab21db](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/aab21db9230800707c7814b0702e7d1f70a6a4f4))
* **release:** 1.8.0 [skip ci] ([8fa12bb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fa12bbc56dbcb4976551818ae5c99132ac393b3))
* **release:** 1.9.0 [skip ci] ([a21e331](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a21e3317a48632bbb442d352c47e5b155ee96d94))
* **release:** 1.9.0-beta.1 [skip ci] ([3173f66](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3173f661ff6d954a6059c8e899faba391cb51276))
* **release:** 1.9.0-beta.2 [skip ci] ([c2fef9e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2fef9e5405e16ba5d61a8b2fbf0b1c03c6fa306))
* **release:** 1.9.0-beta.3 [skip ci] ([ca9fa71](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ca9fa71d2e68aafa2a438b659349e1fb4589ebdf))
* **release:** 1.9.0-beta.4 [skip ci] ([b2e5ab1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b2e5ab167c0777449ac4974674abd294e0f7e41d))
* **release:** 1.9.0-beta.5 [skip ci] ([604aea3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/604aea3c6aff087388d6014f0d1fcd7df0c66f69))
* **release:** 1.9.0-beta.6 [skip ci] ([19c33b2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/19c33b2e0d8160d78549878c64355e16702d406a))
* **release:** 1.9.0-beta.7 [skip ci] ([c232796](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2327961096cd9f9ad3b0f54cf242a7d99ab11bc))

## 1.0.0 (2025-07-02)


### Features

* add client integration ([5cbc551](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5cbc551092b33849fdbb1e1468eb35ba8b4f5c20))
* add crawling endpoint ([4cf4ea6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4cf4ea67915e7dbb27dae6d3fa0a71719b28dfec))
* add docstring ([04622dd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/04622dd39bb45223d266aab64ea086b2f1548425))
* add infinite scrolling ([928fb9b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/928fb9b274b55caaec3024bf1c3ca5b865120aa2))
* add infinte scrolling ([3166542](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3166542005eeae2b9fd9e5aaad0abc1966ec4abc))
* add integration for env variables ([2bf03a7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2bf03a7ca7a7936ad2c3b50ded4a6d90161fffa4))
* add integration for local_scraper ([4f6402a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4f6402a94ebfa1b7534fc77ccef2deee5e9295d1))
* add integration for sql ([8ae60c4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ae60c4cfcc070a0a7053862aafaf758e91f465f))
* add integration for the api ([457a2aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/457a2aac6c9afcf4bbb06a99e35a7f5ca5ed5797))
* add localScraper functionality ([7ee0bc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7ee0bc0778c1fc65b6f33bd76d0a4ca8735ce373))
* add markdownify and localscraper ([675de86](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/675de867428efb01d8d9f8aedca34055bce9e974))
* add markdownify functionality ([938274f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/938274f2f67d9e6bca212e6bebd6203349c6494c))
* add optional headers to request ([246f10e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/246f10ef3b24649887a813b5a31d2ffc7b848b1b))
* add requirement files ([65fe013](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/65fe013ff3859b53f17d097bad780038216797e3))
* add scrapegraphai api integration ([382c347](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/382c347061f9a0690cfab09393c11fd5e0ebee70))
* add search number example ([4e93394](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4e93394a2a010cb0459abd7c5cc9aa68d7bc8c8c))
* add time varying timeout ([12afa1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/12afa1d09858b04cb99b158ab2f9f1ea2c4967dd))
* added example of the smartScraper function using a schema ([e79c300](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e79c30038ede5c0b6b6460ecc3d791be6b21b811))
* changed SyncClient to Client ([89210bf](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/89210bf26ee8ee5fd15fd7994b3c1fb0b0ad185e))
* check ([5f9b4ed](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5f9b4edc08e6325124dc335eb1e145cfb7394113))
* enhaced python sdk ([e66e60d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e66e60de27b89c0ea0a9abcd097a001feb7e8147))
* final release maybe semantic? ([d096725](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d09672512605b2d8289abc017ef3c82147a69cd3))
* fix ([d03013c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d03013c5330d9b2728848655e373ea878eebf71d))
* implemented search scraper functionality ([44834c2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/44834c2e3c8523fffe88c9bbd97009a846b5997c))
* implemented support for requests with schema ([ad5f0b4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ad5f0b45d2dc183b63b27f5e5f4dd4b9801aa008))
* maybe final release? ([40035f3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/40035f3f0d9c8c2fcecbcd603397c38af405153a))
* merged localscraper into smartscraper ([eaac552](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/eaac552493f4a245cfb2246713a8febf87851d05))
* modified icons ([836faea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/836faea0975e7b1dcc13495a0c76c7d50cbedbaa))
* refactoring of the folders ([e613e2e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e613e2e07c95a4e5348d1a74b8ba9f1f853a0911))
* refctoring of the folder ([3085b5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3085b5a74f748c4ce42fa6e02fd04029a4dc25a5))
* removed local scraper ([021bf6d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/021bf6dcc6bd216cc8129b146e1f7892e52cf244))
* revert to old release ([6565b3e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6565b3e937958fc0b897eb84456643e02d90790e))
* searchscraper ([e281e0d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e281e0d798eccbe8114c75f8a3e2a2a4ab8cca25))
* semantic relaase ([93759c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/93759c39b8f44ee1c51fac843544c93e87708760))
* semantic release ([9613ba9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9613ba933274fe1bddb56339aae40617eaf46d65))
* semantic release ([956eceb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/956ecebc27dae00fa0b487f97eec8114dfc3a1bd))
* semantic release ([0bc1358](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0bc135814e6ebb438313b4d466357b2e5631f09d))
* splitted files ([5337d1e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5337d1e39f7625165066c4aada771a4eb25fa635))
* test ([9bec234](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9bec2340b0e507409c6ae221a8eb0ea93178a82f))
* test semantic release ([5dbb0cc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5dbb0cc1243be847f2d7dee4f6e3df0c6550d8aa))
* test semantic release ([66c789e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/66c789e907d69b6c8a919a2c7d4a2c4a79826d3d))
* test semantic release ([d63fdda](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d63fddaa3794677c862313b0058d34ddc358441d))
* test semantic release ([682baa3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/682baa39695f564b684568d9a6bf23ecda00b5ec))
* try semantic release ([d686c1f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d686c1ff1911885a553e68897efa95afcd09a503))
* update doc readme ([e317b1b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e317b1b0135c0d0134846ea0b0b63552773cff45))
* updated readmes ([d485cf0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d485cf0ee0bd331e5970a158636dcdb44db98d81))


### Bug Fixes

* .toml file ([31d9ad8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31d9ad8d65fde79022a9971c1b463ccd5452820a))
* add enw timeout ([cfc565c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cfc565c5ad23f547138be0466820c1c2dee6aa47))
* add new python compatibility ([45d24a6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/45d24a6a3d1c3090f1c575cf4fe6a8d80d637c38))
* add revert ([b81ec1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b81ec1d37d0a1635f444525e1e4a99823f5cea83))
* come back to py 3.10 ([e10bb5c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e10bb5c0ed0cd93a36b97eb91d634db8aac575d7))
* fixed configuration for ignored files ([76e1d0e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/76e1d0edbfbb796b87c3608610e4d4125cdf4bfd))
* fixed HttpError messages ([935dac1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/935dac100185b3622aa2744a38a2d4ce740deaa5))
* fixed schema example ([4be2bd0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4be2bd0310cb860864e7666d5613d1664818e505))
* houses examples and typos ([e787776](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e787776125215bc5c9d40e6691c971d46651548e))
* improve api desc ([87e2040](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/87e2040ce4fd090cf511f67048f6275502120ab7))
* logger working properly now ([6c619c1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6c619c11ea90c81e0054b36504cc3d9e62dce249))
* make timeout optional ([09b0cc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/09b0cc015d2b8f8848a625a7d75e36a5caf7b546))
* minor fix version ([d05bb6a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d05bb6a34a15d45ebce2056c89c146f4fcf5a35f))
* pyproject ([d5005a0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d5005a00671148c22956eb52f4bedc369f9361c2))
* pyproject ([d04f0aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d04f0aa770ebe480f293b60db0c5883f2c39e0f3))
* pyproject.toml ([1c2ae7f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1c2ae7fc9ffc485c9d36020da3fcc90037ea3c98))
* pyproject.toml ([a509471](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a5094710e63b903da61e359b9ea8f79bf57b48f2))
* python version ([98b859d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/98b859dab0effc966d1731372750e14abb0373c8))
* readme js sdk ([6f95f27](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6f95f2782354ab62ab2ad320e338c4be2701c20b))
* removed wrong information ([75ef97e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/75ef97eae8b31bac72a3e999e3423b8a455000f6))
* semanti release 2 ([b008a3b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b008a3bc691b52be167edd1cbd9f0d1d689d0989))
* semantic release ([4d230ae](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4d230ae6b2404466b956c7a567223a03ff6ae448))
* sync client ([8fee46f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fee46f7645c5b9e0cfa6d3d90b7d7e4e30567eb))
* the "workspace" key has been removed because it was conflicting with the package.json file in the scrapegraph-js folder. ([15e590c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15e590ca23b3ecfeabd387af3eb7b42548337f87))
* timeout ([57f6593](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/57f6593ee632595c39a9241009a0e71120baecc2))
* updated comment ([62e2792](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/62e2792174d5403f05c73aeb64bb515d722721d2))
* updated env variable loading ([e259ed1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e259ed173f249c935e2de3c54831edf9fa954caa))
* updated hatchling version ([2b41262](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2b412623aec22c3be37061347ec25e74ea8d6126))


### chore

* added dotenv pakage dependency ([e88abab](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e88abab18a3a375b6090790af4a1012381af164c))
* added more information about the package ([a91198d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a91198de86e9be84b20aeac0e69eba81392ad39b))
* added Zod package dependency ([49d3a59](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/49d3a59f916ac27170c3640775f0844063afd65a))
* changed pakage name ([f93e49b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f93e49bff839b8de2c4f41c638c9c4df76592463))
* fix _make_request not using it ([05f61ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/05f61ea10a8183fc8863b1703fd4fbf6ca921c93))
* fix pylint scripts ([7a593a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7a593a8a116d863d573f68d6e2282ba6c2204cbc))
* fix pyproject version ([bc0c722](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc0c722986d65c500496b91f5cd8cec23b19189a))
* fix semantic release, migrate to uv ([a70e1b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a70e1b7f86671e5d7a49c882b4c854d32c6b5944))
* improved url validation ([25072a9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/25072a9976873e59169cd7a9bcce5797f5dcbfa3))
* refactor examples ([85738d8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/85738d87117cf803e02c608b2476d24265ce65c6))
* set up CI scripts ([7b33f8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7b33f8f78e37c13eafcc0193fe7a2b2efb258cdf))
* set up eslint and prettier for code linting and formatting ([9d54406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9d544066c08d6dca6e4dd764f665e56912bc4285))
* update workflow scripts ([80ae3f7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/80ae3f761cc1b5cb860b9d75ee14920e37725cc0))
* **tests:** updated tests ([b33f0b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b33f0b7b602e29ea86ae2bfff7862279b5cca9ec))


### Docs

* added an example of the smartScraper functionality using a schema ([ae245c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ae245c83d70259a8eb5c626c21dfb3a0f6e76f62))
* added api reference ([f87a7c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f87a7c8fc3b39360f2339731af52b0b0766c80c2))
* added api reference ([0cf5f3a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0cf5f3ae4b5b8704e86fc21b298a053f3bd9822e))
* added cookbook reference ([54841e5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/54841e5c0f705a64c4295e4fc8a414af0e62ca4f))
* added langchain-scrapegraph examples ([b9d771e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b9d771eab5b0eace6eb03f0075094e3cc51efce9))
* added new image ([b710bd3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b710bd3d60603e3b720b1a811ad91f35b1bea832))
* added open in colab badge ([9e5519c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e5519c55be9a20da0d4a08e363a66bfacc970be))
* added two langchain-scrapegraph examples ([b18b14d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b18b14d41eab4cdd7ed8d6fdc7ceb5e9f8fa9b24))
* added two new examples ([b3fd406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b3fd406680ab9aab2d99640fbe5244a9ebb14263))
* **cookbook:** added two new examples ([2a8fb8c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a8fb8c45af4ff5b03483c7031ab541a03e36b83))
* added wired langgraph react agent ([69c82ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69c82ea3d068c677866cb062a4b0345073dce6de))
* added zillow example ([1eb365c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1eb365c7cf41aa8b04c96bd2667a7bddff7f6220))
* api reference ([2f3210c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2f3210cd37e40d29699fada48e754449e4b163e7))
* fixed cookbook images and urls ([b743830](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b74383090261f3d242fc58c16d8071f6da05dc97))
* github trending sdk ([f0890ef](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f0890efa79ca884d1825e4d47b92601d092d0080))
* improved examples ([5245394](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/52453944c5be0a71459bb324731331b194346174))
* improved main readme ([8e280c6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8e280c64a64bb3d36b19bff74f90ea305852aceb))
* link typo ([d6038b0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d6038b0e1ed636959633ec03524ff5cf1cad3164))
* llama-index @VinciGit00 ([b847053](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b8470535f52730f6d1757912b420e35ef94688b4))
* research agent ([628fdd5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/628fdd5c0b0fbe371648b8a0171461ff2d615257))
* updated new documentation urls ([bd4cbf8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bd4cbf81e3c5740c1cc77b6204447cd7878c3978))
* updated precommit and installation guide ([bca95c5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bca95c5d6f1bd8fff3d0303b562ac229c6936f5d))
* updated readme ([2a1e643](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a1e64328ca4b20e9593b65517e7c5bf1fe43ffa))


### Refactor

* code refactoring ([197638b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/197638b7742854fceca756261b96e74024bdfc3f))
* code refactoring ([1be81f0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1be81f0539c631659dcf7e90540cebdd8539ae6a))
* code refactoring ([6270a6e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6270a6e43782f9efbb407e71b1ca7c57c37db38a))
* improved code structure ([d1a33dc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d1a33dcf87c401043b3ff7676638daadeca0f2c8))
* renamed functions ([95719e3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/95719e3b4a2c78de381bfdc39a077c42fdddec05))
* simplify infinite scroll config by replacing scroll_options with number_of_scrolls parameter ([ffc32ce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ffc32ce05a5c3546579142181466e34c3027ec67))
* update readme ([fee30c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fee30c3355ffee30fc1bffb56984085000df6192))


### Test

* Add coverage improvement test for scrapegraph-py/tests/test_localscraper.py ([84ba517](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/84ba51747898cec2bb74b4d6c4a5ea398b56bca7))
* Add coverage improvement test for scrapegraph-py/tests/test_markdownify.py ([c39dbb0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c39dbb034ab89e1830da63f24f534ee070046c5d))
* Add coverage improvement test for scrapegraph-py/tests/test_smartscraper.py ([2216f6f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2216f6f309cac66f6688c0d84190d71c29290415))


### CI

* **release:** 1.0.0 [skip ci] ([7fef9f1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7fef9f10cfb8ea8f7f52dcb543571937848b393c))
* **release:** 1.0.0 [skip ci] ([99af971](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/99af971aa0df717ae2f8c4148d60c45870926100))
* **release:** 1.0.0 [skip ci] ([46756ac](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/46756ac26d7b540e523f3a23afe688673293e8c6))
* **release:** 1.0.0 [skip ci] ([635f7d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/635f7d09b172e6b00cd498ebf2d95799c82e0821))
* **release:** 1.0.0 [skip ci] ([763e52b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/763e52bdf696192eb8f0143f3e97ccd40ae0bb8c))
* **release:** 1.0.0 [skip ci] ([0a7a968](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0a7a96864fbe38f8b2b2887807415f8869d96c65))
* **release:** 1.1.0 [skip ci] ([fd55dc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fd55dc0d82f16dc277a9c45cf2e687245c4b76a2))
* **release:** 1.10.0 [skip ci] ([69a5d7d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69a5d7d66236050c2ba9c88fd53785f573d34fa2))
* **release:** 1.10.1 [skip ci] ([48eb09d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/48eb09d406bd1dafb02bc9b001c6ef9752c4125a))
* **release:** 1.10.2 [skip ci] ([9f2a50c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9f2a50c940a70aa04b4484053ccae3a1cfb4148c))
* **release:** 1.11.0 [skip ci] ([82fc505](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/82fc50507bb610f1059a12779a90d7d200c1759b))
* **release:** 1.11.0-beta.1 [skip ci] ([e25a870](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e25a87013eb7be0db193d0093392eb78f3f1cfb6))
* **release:** 1.12.0 [skip ci] ([15b9626](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15b9626c11f84c60b496d70422a2df86e76d49a5))
* **release:** 1.2.0 [skip ci] ([8ebd90b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ebd90b963de62c879910d7cf64f491bcf4c47f7))
* **release:** 1.2.1 [skip ci] ([bc5c9a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc5c9a8db64d0c792566f58d5265f6936edc5526))
* **release:** 1.2.2 [skip ci] ([14dcf99](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/14dcf99173a589557b7a2860716eedbee892b16b))
* **release:** 1.3.0 [skip ci] ([daf43d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/daf43d06761d85608b9599337e111da694a858a6))
* **release:** 1.4.0 [skip ci] ([cb18d8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cb18d8fb219dd55b6478ee33c051a40a091c4fd0))
* **release:** 1.4.1 [skip ci] ([0b42489](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0b424891395f0630c9886eb1a8a23232603e856f))
* **release:** 1.4.2 [skip ci] ([e4ad100](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e4ad100e3004a4b7c63f865d3f12398a080bb599))
* **release:** 1.4.3 [skip ci] ([11a0edc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/11a0edc54b299eea60a382c2781d3d1ac0084c3f))
* **release:** 1.4.3-beta.1 [skip ci] ([c4ba791](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c4ba791e45edfbff13332117f2583781354f90d6))
* **release:** 1.4.3-beta.2 [skip ci] ([3110601](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31106014d662745fa9afef6083f61452508b67fb))
* **release:** 1.4.3-beta.3 [skip ci] ([b6f7589](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b6f75899bd9f5d906cb5034b3a74c3ef46280537))
* **release:** 1.5.0 [skip ci] ([c7c91bd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c7c91bd7c6f3550089d1231b2167ca18921fd48f))
* **release:** 1.5.0-beta.1 [skip ci] ([298fce2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/298fce2058f7f39546afa022a135b497b9d8024d))
* **release:** 1.6.0 [skip ci] ([1b0fdce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1b0fdce5827378dc80a5cd0a83e7444d50db79c1))
* **release:** 1.6.0-beta.1 [skip ci] ([ba7588d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ba7588d978217d2c2fce5404d989c527fe63bb16))
* **release:** 1.7.0 [skip ci] ([bb2847c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bb2847ca1f7045c86b5fa26cb1c16422039bfafb))
* **release:** 1.7.0-beta.1 [skip ci] ([aab21db](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/aab21db9230800707c7814b0702e7d1f70a6a4f4))
* **release:** 1.8.0 [skip ci] ([8fa12bb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fa12bbc56dbcb4976551818ae5c99132ac393b3))
* **release:** 1.9.0 [skip ci] ([a21e331](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a21e3317a48632bbb442d352c47e5b155ee96d94))
* **release:** 1.9.0-beta.1 [skip ci] ([3173f66](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3173f661ff6d954a6059c8e899faba391cb51276))
* **release:** 1.9.0-beta.2 [skip ci] ([c2fef9e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2fef9e5405e16ba5d61a8b2fbf0b1c03c6fa306))
* **release:** 1.9.0-beta.3 [skip ci] ([ca9fa71](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ca9fa71d2e68aafa2a438b659349e1fb4589ebdf))
* **release:** 1.9.0-beta.4 [skip ci] ([b2e5ab1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b2e5ab167c0777449ac4974674abd294e0f7e41d))
* **release:** 1.9.0-beta.5 [skip ci] ([604aea3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/604aea3c6aff087388d6014f0d1fcd7df0c66f69))
* **release:** 1.9.0-beta.6 [skip ci] ([19c33b2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/19c33b2e0d8160d78549878c64355e16702d406a))
* **release:** 1.9.0-beta.7 [skip ci] ([c232796](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2327961096cd9f9ad3b0f54cf242a7d99ab11bc))

## 1.0.0 (2025-07-01)


### Features

* add client integration ([5cbc551](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5cbc551092b33849fdbb1e1468eb35ba8b4f5c20))
* add crawling endpoint ([4cf4ea6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4cf4ea67915e7dbb27dae6d3fa0a71719b28dfec))
* add docstring ([04622dd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/04622dd39bb45223d266aab64ea086b2f1548425))
* add infinite scrolling ([928fb9b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/928fb9b274b55caaec3024bf1c3ca5b865120aa2))
* add infinte scrolling ([3166542](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3166542005eeae2b9fd9e5aaad0abc1966ec4abc))
* add integration for env variables ([2bf03a7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2bf03a7ca7a7936ad2c3b50ded4a6d90161fffa4))
* add integration for local_scraper ([4f6402a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4f6402a94ebfa1b7534fc77ccef2deee5e9295d1))
* add integration for sql ([8ae60c4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ae60c4cfcc070a0a7053862aafaf758e91f465f))
* add integration for the api ([457a2aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/457a2aac6c9afcf4bbb06a99e35a7f5ca5ed5797))
* add localScraper functionality ([7ee0bc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7ee0bc0778c1fc65b6f33bd76d0a4ca8735ce373))
* add markdownify and localscraper ([675de86](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/675de867428efb01d8d9f8aedca34055bce9e974))
* add markdownify functionality ([938274f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/938274f2f67d9e6bca212e6bebd6203349c6494c))
* add optional headers to request ([246f10e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/246f10ef3b24649887a813b5a31d2ffc7b848b1b))
* add requirement files ([65fe013](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/65fe013ff3859b53f17d097bad780038216797e3))
* add scrapegraphai api integration ([382c347](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/382c347061f9a0690cfab09393c11fd5e0ebee70))
* add time varying timeout ([12afa1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/12afa1d09858b04cb99b158ab2f9f1ea2c4967dd))
* added example of the smartScraper function using a schema ([e79c300](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e79c30038ede5c0b6b6460ecc3d791be6b21b811))
* changed SyncClient to Client ([89210bf](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/89210bf26ee8ee5fd15fd7994b3c1fb0b0ad185e))
* check ([5f9b4ed](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5f9b4edc08e6325124dc335eb1e145cfb7394113))
* enhaced python sdk ([e66e60d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e66e60de27b89c0ea0a9abcd097a001feb7e8147))
* final release maybe semantic? ([d096725](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d09672512605b2d8289abc017ef3c82147a69cd3))
* fix ([d03013c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d03013c5330d9b2728848655e373ea878eebf71d))
* implemented search scraper functionality ([44834c2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/44834c2e3c8523fffe88c9bbd97009a846b5997c))
* implemented support for requests with schema ([ad5f0b4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ad5f0b45d2dc183b63b27f5e5f4dd4b9801aa008))
* maybe final release? ([40035f3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/40035f3f0d9c8c2fcecbcd603397c38af405153a))
* merged localscraper into smartscraper ([eaac552](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/eaac552493f4a245cfb2246713a8febf87851d05))
* modified icons ([836faea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/836faea0975e7b1dcc13495a0c76c7d50cbedbaa))
* refactoring of the folders ([e613e2e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e613e2e07c95a4e5348d1a74b8ba9f1f853a0911))
* refctoring of the folder ([3085b5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3085b5a74f748c4ce42fa6e02fd04029a4dc25a5))
* removed local scraper ([021bf6d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/021bf6dcc6bd216cc8129b146e1f7892e52cf244))
* revert to old release ([6565b3e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6565b3e937958fc0b897eb84456643e02d90790e))
* searchscraper ([e281e0d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e281e0d798eccbe8114c75f8a3e2a2a4ab8cca25))
* semantic relaase ([93759c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/93759c39b8f44ee1c51fac843544c93e87708760))
* semantic release ([9613ba9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9613ba933274fe1bddb56339aae40617eaf46d65))
* semantic release ([956eceb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/956ecebc27dae00fa0b487f97eec8114dfc3a1bd))
* semantic release ([0bc1358](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0bc135814e6ebb438313b4d466357b2e5631f09d))
* splitted files ([5337d1e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5337d1e39f7625165066c4aada771a4eb25fa635))
* test ([9bec234](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9bec2340b0e507409c6ae221a8eb0ea93178a82f))
* test semantic release ([5dbb0cc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5dbb0cc1243be847f2d7dee4f6e3df0c6550d8aa))
* test semantic release ([66c789e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/66c789e907d69b6c8a919a2c7d4a2c4a79826d3d))
* test semantic release ([d63fdda](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d63fddaa3794677c862313b0058d34ddc358441d))
* test semantic release ([682baa3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/682baa39695f564b684568d9a6bf23ecda00b5ec))
* try semantic release ([d686c1f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d686c1ff1911885a553e68897efa95afcd09a503))
* update doc readme ([e317b1b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e317b1b0135c0d0134846ea0b0b63552773cff45))
* updated readmes ([d485cf0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d485cf0ee0bd331e5970a158636dcdb44db98d81))


### Bug Fixes

* .toml file ([31d9ad8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31d9ad8d65fde79022a9971c1b463ccd5452820a))
* add enw timeout ([cfc565c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cfc565c5ad23f547138be0466820c1c2dee6aa47))
* add new python compatibility ([45d24a6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/45d24a6a3d1c3090f1c575cf4fe6a8d80d637c38))
* add revert ([b81ec1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b81ec1d37d0a1635f444525e1e4a99823f5cea83))
* come back to py 3.10 ([e10bb5c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e10bb5c0ed0cd93a36b97eb91d634db8aac575d7))
* fixed configuration for ignored files ([76e1d0e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/76e1d0edbfbb796b87c3608610e4d4125cdf4bfd))
* fixed HttpError messages ([935dac1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/935dac100185b3622aa2744a38a2d4ce740deaa5))
* fixed schema example ([4be2bd0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4be2bd0310cb860864e7666d5613d1664818e505))
* houses examples and typos ([e787776](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e787776125215bc5c9d40e6691c971d46651548e))
* improve api desc ([87e2040](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/87e2040ce4fd090cf511f67048f6275502120ab7))
* logger working properly now ([6c619c1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6c619c11ea90c81e0054b36504cc3d9e62dce249))
* make timeout optional ([09b0cc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/09b0cc015d2b8f8848a625a7d75e36a5caf7b546))
* minor fix version ([d05bb6a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d05bb6a34a15d45ebce2056c89c146f4fcf5a35f))
* pyproject ([d5005a0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d5005a00671148c22956eb52f4bedc369f9361c2))
* pyproject ([d04f0aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d04f0aa770ebe480f293b60db0c5883f2c39e0f3))
* pyproject.toml ([1c2ae7f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1c2ae7fc9ffc485c9d36020da3fcc90037ea3c98))
* pyproject.toml ([a509471](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a5094710e63b903da61e359b9ea8f79bf57b48f2))
* python version ([98b859d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/98b859dab0effc966d1731372750e14abb0373c8))
* readme js sdk ([6f95f27](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6f95f2782354ab62ab2ad320e338c4be2701c20b))
* removed wrong information ([75ef97e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/75ef97eae8b31bac72a3e999e3423b8a455000f6))
* semanti release 2 ([b008a3b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b008a3bc691b52be167edd1cbd9f0d1d689d0989))
* semantic release ([4d230ae](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4d230ae6b2404466b956c7a567223a03ff6ae448))
* sync client ([8fee46f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fee46f7645c5b9e0cfa6d3d90b7d7e4e30567eb))
* the "workspace" key has been removed because it was conflicting with the package.json file in the scrapegraph-js folder. ([15e590c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15e590ca23b3ecfeabd387af3eb7b42548337f87))
* timeout ([57f6593](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/57f6593ee632595c39a9241009a0e71120baecc2))
* updated comment ([62e2792](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/62e2792174d5403f05c73aeb64bb515d722721d2))
* updated env variable loading ([e259ed1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e259ed173f249c935e2de3c54831edf9fa954caa))
* updated hatchling version ([2b41262](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2b412623aec22c3be37061347ec25e74ea8d6126))


### chore

* added dotenv pakage dependency ([e88abab](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e88abab18a3a375b6090790af4a1012381af164c))
* added more information about the package ([a91198d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a91198de86e9be84b20aeac0e69eba81392ad39b))
* added Zod package dependency ([49d3a59](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/49d3a59f916ac27170c3640775f0844063afd65a))
* changed pakage name ([f93e49b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f93e49bff839b8de2c4f41c638c9c4df76592463))
* fix _make_request not using it ([05f61ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/05f61ea10a8183fc8863b1703fd4fbf6ca921c93))
* fix pylint scripts ([7a593a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7a593a8a116d863d573f68d6e2282ba6c2204cbc))
* fix pyproject version ([bc0c722](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc0c722986d65c500496b91f5cd8cec23b19189a))
* fix semantic release, migrate to uv ([a70e1b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a70e1b7f86671e5d7a49c882b4c854d32c6b5944))
* improved url validation ([25072a9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/25072a9976873e59169cd7a9bcce5797f5dcbfa3))
* refactor examples ([85738d8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/85738d87117cf803e02c608b2476d24265ce65c6))
* set up CI scripts ([7b33f8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7b33f8f78e37c13eafcc0193fe7a2b2efb258cdf))
* set up eslint and prettier for code linting and formatting ([9d54406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9d544066c08d6dca6e4dd764f665e56912bc4285))
* update workflow scripts ([80ae3f7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/80ae3f761cc1b5cb860b9d75ee14920e37725cc0))
* **tests:** updated tests ([b33f0b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b33f0b7b602e29ea86ae2bfff7862279b5cca9ec))


### Docs

* added an example of the smartScraper functionality using a schema ([ae245c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ae245c83d70259a8eb5c626c21dfb3a0f6e76f62))
* added api reference ([f87a7c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f87a7c8fc3b39360f2339731af52b0b0766c80c2))
* added api reference ([0cf5f3a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0cf5f3ae4b5b8704e86fc21b298a053f3bd9822e))
* added cookbook reference ([54841e5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/54841e5c0f705a64c4295e4fc8a414af0e62ca4f))
* added langchain-scrapegraph examples ([b9d771e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b9d771eab5b0eace6eb03f0075094e3cc51efce9))
* added new image ([b710bd3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b710bd3d60603e3b720b1a811ad91f35b1bea832))
* added open in colab badge ([9e5519c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e5519c55be9a20da0d4a08e363a66bfacc970be))
* added two langchain-scrapegraph examples ([b18b14d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b18b14d41eab4cdd7ed8d6fdc7ceb5e9f8fa9b24))
* added two new examples ([b3fd406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b3fd406680ab9aab2d99640fbe5244a9ebb14263))
* **cookbook:** added two new examples ([2a8fb8c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a8fb8c45af4ff5b03483c7031ab541a03e36b83))
* added wired langgraph react agent ([69c82ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69c82ea3d068c677866cb062a4b0345073dce6de))
* added zillow example ([1eb365c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1eb365c7cf41aa8b04c96bd2667a7bddff7f6220))
* api reference ([2f3210c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2f3210cd37e40d29699fada48e754449e4b163e7))
* fixed cookbook images and urls ([b743830](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b74383090261f3d242fc58c16d8071f6da05dc97))
* github trending sdk ([f0890ef](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f0890efa79ca884d1825e4d47b92601d092d0080))
* improved examples ([5245394](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/52453944c5be0a71459bb324731331b194346174))
* improved main readme ([8e280c6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8e280c64a64bb3d36b19bff74f90ea305852aceb))
* link typo ([d6038b0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d6038b0e1ed636959633ec03524ff5cf1cad3164))
* llama-index @VinciGit00 ([b847053](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b8470535f52730f6d1757912b420e35ef94688b4))
* research agent ([628fdd5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/628fdd5c0b0fbe371648b8a0171461ff2d615257))
* updated new documentation urls ([bd4cbf8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bd4cbf81e3c5740c1cc77b6204447cd7878c3978))
* updated precommit and installation guide ([bca95c5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bca95c5d6f1bd8fff3d0303b562ac229c6936f5d))
* updated readme ([2a1e643](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a1e64328ca4b20e9593b65517e7c5bf1fe43ffa))


### Refactor

* code refactoring ([197638b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/197638b7742854fceca756261b96e74024bdfc3f))
* code refactoring ([1be81f0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1be81f0539c631659dcf7e90540cebdd8539ae6a))
* code refactoring ([6270a6e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6270a6e43782f9efbb407e71b1ca7c57c37db38a))
* improved code structure ([d1a33dc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d1a33dcf87c401043b3ff7676638daadeca0f2c8))
* renamed functions ([95719e3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/95719e3b4a2c78de381bfdc39a077c42fdddec05))
* simplify infinite scroll config by replacing scroll_options with number_of_scrolls parameter ([ffc32ce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ffc32ce05a5c3546579142181466e34c3027ec67))
* update readme ([fee30c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fee30c3355ffee30fc1bffb56984085000df6192))


### Test

* Add coverage improvement test for scrapegraph-py/tests/test_localscraper.py ([84ba517](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/84ba51747898cec2bb74b4d6c4a5ea398b56bca7))
* Add coverage improvement test for scrapegraph-py/tests/test_markdownify.py ([c39dbb0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c39dbb034ab89e1830da63f24f534ee070046c5d))
* Add coverage improvement test for scrapegraph-py/tests/test_smartscraper.py ([2216f6f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2216f6f309cac66f6688c0d84190d71c29290415))


### CI

* **release:** 1.0.0 [skip ci] ([99af971](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/99af971aa0df717ae2f8c4148d60c45870926100))
* **release:** 1.0.0 [skip ci] ([46756ac](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/46756ac26d7b540e523f3a23afe688673293e8c6))
* **release:** 1.0.0 [skip ci] ([635f7d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/635f7d09b172e6b00cd498ebf2d95799c82e0821))
* **release:** 1.0.0 [skip ci] ([763e52b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/763e52bdf696192eb8f0143f3e97ccd40ae0bb8c))
* **release:** 1.0.0 [skip ci] ([0a7a968](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0a7a96864fbe38f8b2b2887807415f8869d96c65))
* **release:** 1.1.0 [skip ci] ([fd55dc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fd55dc0d82f16dc277a9c45cf2e687245c4b76a2))
* **release:** 1.10.0 [skip ci] ([69a5d7d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69a5d7d66236050c2ba9c88fd53785f573d34fa2))
* **release:** 1.10.1 [skip ci] ([48eb09d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/48eb09d406bd1dafb02bc9b001c6ef9752c4125a))
* **release:** 1.10.2 [skip ci] ([9f2a50c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9f2a50c940a70aa04b4484053ccae3a1cfb4148c))
* **release:** 1.11.0 [skip ci] ([82fc505](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/82fc50507bb610f1059a12779a90d7d200c1759b))
* **release:** 1.11.0-beta.1 [skip ci] ([e25a870](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e25a87013eb7be0db193d0093392eb78f3f1cfb6))
* **release:** 1.12.0 [skip ci] ([15b9626](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15b9626c11f84c60b496d70422a2df86e76d49a5))
* **release:** 1.2.0 [skip ci] ([8ebd90b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ebd90b963de62c879910d7cf64f491bcf4c47f7))
* **release:** 1.2.1 [skip ci] ([bc5c9a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc5c9a8db64d0c792566f58d5265f6936edc5526))
* **release:** 1.2.2 [skip ci] ([14dcf99](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/14dcf99173a589557b7a2860716eedbee892b16b))
* **release:** 1.3.0 [skip ci] ([daf43d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/daf43d06761d85608b9599337e111da694a858a6))
* **release:** 1.4.0 [skip ci] ([cb18d8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cb18d8fb219dd55b6478ee33c051a40a091c4fd0))
* **release:** 1.4.1 [skip ci] ([0b42489](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0b424891395f0630c9886eb1a8a23232603e856f))
* **release:** 1.4.2 [skip ci] ([e4ad100](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e4ad100e3004a4b7c63f865d3f12398a080bb599))
* **release:** 1.4.3 [skip ci] ([11a0edc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/11a0edc54b299eea60a382c2781d3d1ac0084c3f))
* **release:** 1.4.3-beta.1 [skip ci] ([c4ba791](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c4ba791e45edfbff13332117f2583781354f90d6))
* **release:** 1.4.3-beta.2 [skip ci] ([3110601](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31106014d662745fa9afef6083f61452508b67fb))
* **release:** 1.4.3-beta.3 [skip ci] ([b6f7589](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b6f75899bd9f5d906cb5034b3a74c3ef46280537))
* **release:** 1.5.0 [skip ci] ([c7c91bd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c7c91bd7c6f3550089d1231b2167ca18921fd48f))
* **release:** 1.5.0-beta.1 [skip ci] ([298fce2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/298fce2058f7f39546afa022a135b497b9d8024d))
* **release:** 1.6.0 [skip ci] ([1b0fdce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1b0fdce5827378dc80a5cd0a83e7444d50db79c1))
* **release:** 1.6.0-beta.1 [skip ci] ([ba7588d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ba7588d978217d2c2fce5404d989c527fe63bb16))
* **release:** 1.7.0 [skip ci] ([bb2847c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bb2847ca1f7045c86b5fa26cb1c16422039bfafb))
* **release:** 1.7.0-beta.1 [skip ci] ([aab21db](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/aab21db9230800707c7814b0702e7d1f70a6a4f4))
* **release:** 1.8.0 [skip ci] ([8fa12bb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fa12bbc56dbcb4976551818ae5c99132ac393b3))
* **release:** 1.9.0 [skip ci] ([a21e331](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a21e3317a48632bbb442d352c47e5b155ee96d94))
* **release:** 1.9.0-beta.1 [skip ci] ([3173f66](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3173f661ff6d954a6059c8e899faba391cb51276))
* **release:** 1.9.0-beta.2 [skip ci] ([c2fef9e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2fef9e5405e16ba5d61a8b2fbf0b1c03c6fa306))
* **release:** 1.9.0-beta.3 [skip ci] ([ca9fa71](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ca9fa71d2e68aafa2a438b659349e1fb4589ebdf))
* **release:** 1.9.0-beta.4 [skip ci] ([b2e5ab1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b2e5ab167c0777449ac4974674abd294e0f7e41d))
* **release:** 1.9.0-beta.5 [skip ci] ([604aea3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/604aea3c6aff087388d6014f0d1fcd7df0c66f69))
* **release:** 1.9.0-beta.6 [skip ci] ([19c33b2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/19c33b2e0d8160d78549878c64355e16702d406a))
* **release:** 1.9.0-beta.7 [skip ci] ([c232796](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2327961096cd9f9ad3b0f54cf242a7d99ab11bc))

## 1.0.0 (2025-07-01)


### Features

* add client integration ([5cbc551](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5cbc551092b33849fdbb1e1468eb35ba8b4f5c20))
* add crawling endpoint ([4cf4ea6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4cf4ea67915e7dbb27dae6d3fa0a71719b28dfec))
* add docstring ([04622dd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/04622dd39bb45223d266aab64ea086b2f1548425))
* add infinite scrolling ([928fb9b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/928fb9b274b55caaec3024bf1c3ca5b865120aa2))
* add infinte scrolling ([3166542](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3166542005eeae2b9fd9e5aaad0abc1966ec4abc))
* add integration for env variables ([2bf03a7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2bf03a7ca7a7936ad2c3b50ded4a6d90161fffa4))
* add integration for local_scraper ([4f6402a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4f6402a94ebfa1b7534fc77ccef2deee5e9295d1))
* add integration for sql ([8ae60c4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ae60c4cfcc070a0a7053862aafaf758e91f465f))
* add integration for the api ([457a2aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/457a2aac6c9afcf4bbb06a99e35a7f5ca5ed5797))
* add localScraper functionality ([7ee0bc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7ee0bc0778c1fc65b6f33bd76d0a4ca8735ce373))
* add markdownify and localscraper ([675de86](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/675de867428efb01d8d9f8aedca34055bce9e974))
* add markdownify functionality ([938274f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/938274f2f67d9e6bca212e6bebd6203349c6494c))
* add optional headers to request ([246f10e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/246f10ef3b24649887a813b5a31d2ffc7b848b1b))
* add requirement files ([65fe013](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/65fe013ff3859b53f17d097bad780038216797e3))
* add scrapegraphai api integration ([382c347](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/382c347061f9a0690cfab09393c11fd5e0ebee70))
* add time varying timeout ([12afa1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/12afa1d09858b04cb99b158ab2f9f1ea2c4967dd))
* added example of the smartScraper function using a schema ([e79c300](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e79c30038ede5c0b6b6460ecc3d791be6b21b811))
* changed SyncClient to Client ([89210bf](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/89210bf26ee8ee5fd15fd7994b3c1fb0b0ad185e))
* check ([5f9b4ed](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5f9b4edc08e6325124dc335eb1e145cfb7394113))
* enhaced python sdk ([e66e60d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e66e60de27b89c0ea0a9abcd097a001feb7e8147))
* final release maybe semantic? ([d096725](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d09672512605b2d8289abc017ef3c82147a69cd3))
* fix ([d03013c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d03013c5330d9b2728848655e373ea878eebf71d))
* implemented search scraper functionality ([44834c2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/44834c2e3c8523fffe88c9bbd97009a846b5997c))
* implemented support for requests with schema ([ad5f0b4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ad5f0b45d2dc183b63b27f5e5f4dd4b9801aa008))
* maybe final release? ([40035f3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/40035f3f0d9c8c2fcecbcd603397c38af405153a))
* merged localscraper into smartscraper ([eaac552](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/eaac552493f4a245cfb2246713a8febf87851d05))
* modified icons ([836faea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/836faea0975e7b1dcc13495a0c76c7d50cbedbaa))
* refactoring of the folders ([e613e2e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e613e2e07c95a4e5348d1a74b8ba9f1f853a0911))
* refctoring of the folder ([3085b5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3085b5a74f748c4ce42fa6e02fd04029a4dc25a5))
* removed local scraper ([021bf6d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/021bf6dcc6bd216cc8129b146e1f7892e52cf244))
* revert to old release ([6565b3e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6565b3e937958fc0b897eb84456643e02d90790e))
* searchscraper ([e281e0d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e281e0d798eccbe8114c75f8a3e2a2a4ab8cca25))
* semantic relaase ([93759c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/93759c39b8f44ee1c51fac843544c93e87708760))
* semantic release ([9613ba9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9613ba933274fe1bddb56339aae40617eaf46d65))
* semantic release ([956eceb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/956ecebc27dae00fa0b487f97eec8114dfc3a1bd))
* semantic release ([0bc1358](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0bc135814e6ebb438313b4d466357b2e5631f09d))
* splitted files ([5337d1e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5337d1e39f7625165066c4aada771a4eb25fa635))
* test ([9bec234](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9bec2340b0e507409c6ae221a8eb0ea93178a82f))
* test semantic release ([5dbb0cc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5dbb0cc1243be847f2d7dee4f6e3df0c6550d8aa))
* test semantic release ([66c789e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/66c789e907d69b6c8a919a2c7d4a2c4a79826d3d))
* test semantic release ([d63fdda](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d63fddaa3794677c862313b0058d34ddc358441d))
* test semantic release ([682baa3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/682baa39695f564b684568d9a6bf23ecda00b5ec))
* try semantic release ([d686c1f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d686c1ff1911885a553e68897efa95afcd09a503))
* update doc readme ([e317b1b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e317b1b0135c0d0134846ea0b0b63552773cff45))
* updated readmes ([d485cf0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d485cf0ee0bd331e5970a158636dcdb44db98d81))


### Bug Fixes

* .toml file ([31d9ad8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31d9ad8d65fde79022a9971c1b463ccd5452820a))
* add enw timeout ([cfc565c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cfc565c5ad23f547138be0466820c1c2dee6aa47))
* add new python compatibility ([45d24a6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/45d24a6a3d1c3090f1c575cf4fe6a8d80d637c38))
* add revert ([b81ec1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b81ec1d37d0a1635f444525e1e4a99823f5cea83))
* come back to py 3.10 ([e10bb5c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e10bb5c0ed0cd93a36b97eb91d634db8aac575d7))
* fixed configuration for ignored files ([76e1d0e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/76e1d0edbfbb796b87c3608610e4d4125cdf4bfd))
* fixed HttpError messages ([935dac1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/935dac100185b3622aa2744a38a2d4ce740deaa5))
* fixed schema example ([4be2bd0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4be2bd0310cb860864e7666d5613d1664818e505))
* houses examples and typos ([e787776](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e787776125215bc5c9d40e6691c971d46651548e))
* improve api desc ([87e2040](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/87e2040ce4fd090cf511f67048f6275502120ab7))
* logger working properly now ([6c619c1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6c619c11ea90c81e0054b36504cc3d9e62dce249))
* make timeout optional ([09b0cc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/09b0cc015d2b8f8848a625a7d75e36a5caf7b546))
* minor fix version ([d05bb6a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d05bb6a34a15d45ebce2056c89c146f4fcf5a35f))
* pyproject ([d5005a0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d5005a00671148c22956eb52f4bedc369f9361c2))
* pyproject ([d04f0aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d04f0aa770ebe480f293b60db0c5883f2c39e0f3))
* pyproject.toml ([1c2ae7f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1c2ae7fc9ffc485c9d36020da3fcc90037ea3c98))
* pyproject.toml ([a509471](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a5094710e63b903da61e359b9ea8f79bf57b48f2))
* python version ([98b859d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/98b859dab0effc966d1731372750e14abb0373c8))
* readme js sdk ([6f95f27](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6f95f2782354ab62ab2ad320e338c4be2701c20b))
* removed wrong information ([75ef97e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/75ef97eae8b31bac72a3e999e3423b8a455000f6))
* semanti release 2 ([b008a3b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b008a3bc691b52be167edd1cbd9f0d1d689d0989))
* semantic release ([4d230ae](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4d230ae6b2404466b956c7a567223a03ff6ae448))
* sync client ([8fee46f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fee46f7645c5b9e0cfa6d3d90b7d7e4e30567eb))
* the "workspace" key has been removed because it was conflicting with the package.json file in the scrapegraph-js folder. ([15e590c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15e590ca23b3ecfeabd387af3eb7b42548337f87))
* timeout ([57f6593](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/57f6593ee632595c39a9241009a0e71120baecc2))
* updated comment ([62e2792](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/62e2792174d5403f05c73aeb64bb515d722721d2))
* updated env variable loading ([e259ed1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e259ed173f249c935e2de3c54831edf9fa954caa))
* updated hatchling version ([2b41262](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2b412623aec22c3be37061347ec25e74ea8d6126))


### chore

* added dotenv pakage dependency ([e88abab](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e88abab18a3a375b6090790af4a1012381af164c))
* added more information about the package ([a91198d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a91198de86e9be84b20aeac0e69eba81392ad39b))
* added Zod package dependency ([49d3a59](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/49d3a59f916ac27170c3640775f0844063afd65a))
* changed pakage name ([f93e49b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f93e49bff839b8de2c4f41c638c9c4df76592463))
* fix _make_request not using it ([05f61ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/05f61ea10a8183fc8863b1703fd4fbf6ca921c93))
* fix pylint scripts ([7a593a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7a593a8a116d863d573f68d6e2282ba6c2204cbc))
* fix pyproject version ([bc0c722](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc0c722986d65c500496b91f5cd8cec23b19189a))
* fix semantic release, migrate to uv ([a70e1b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a70e1b7f86671e5d7a49c882b4c854d32c6b5944))
* improved url validation ([25072a9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/25072a9976873e59169cd7a9bcce5797f5dcbfa3))
* refactor examples ([85738d8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/85738d87117cf803e02c608b2476d24265ce65c6))
* set up CI scripts ([7b33f8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7b33f8f78e37c13eafcc0193fe7a2b2efb258cdf))
* set up eslint and prettier for code linting and formatting ([9d54406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9d544066c08d6dca6e4dd764f665e56912bc4285))
* update workflow scripts ([80ae3f7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/80ae3f761cc1b5cb860b9d75ee14920e37725cc0))
* **tests:** updated tests ([b33f0b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b33f0b7b602e29ea86ae2bfff7862279b5cca9ec))


### Docs

* added an example of the smartScraper functionality using a schema ([ae245c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ae245c83d70259a8eb5c626c21dfb3a0f6e76f62))
* added api reference ([f87a7c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f87a7c8fc3b39360f2339731af52b0b0766c80c2))
* added api reference ([0cf5f3a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0cf5f3ae4b5b8704e86fc21b298a053f3bd9822e))
* added cookbook reference ([54841e5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/54841e5c0f705a64c4295e4fc8a414af0e62ca4f))
* added langchain-scrapegraph examples ([b9d771e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b9d771eab5b0eace6eb03f0075094e3cc51efce9))
* added new image ([b710bd3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b710bd3d60603e3b720b1a811ad91f35b1bea832))
* added open in colab badge ([9e5519c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e5519c55be9a20da0d4a08e363a66bfacc970be))
* added two langchain-scrapegraph examples ([b18b14d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b18b14d41eab4cdd7ed8d6fdc7ceb5e9f8fa9b24))
* added two new examples ([b3fd406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b3fd406680ab9aab2d99640fbe5244a9ebb14263))
* **cookbook:** added two new examples ([2a8fb8c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a8fb8c45af4ff5b03483c7031ab541a03e36b83))
* added wired langgraph react agent ([69c82ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69c82ea3d068c677866cb062a4b0345073dce6de))
* added zillow example ([1eb365c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1eb365c7cf41aa8b04c96bd2667a7bddff7f6220))
* api reference ([2f3210c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2f3210cd37e40d29699fada48e754449e4b163e7))
* fixed cookbook images and urls ([b743830](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b74383090261f3d242fc58c16d8071f6da05dc97))
* github trending sdk ([f0890ef](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f0890efa79ca884d1825e4d47b92601d092d0080))
* improved examples ([5245394](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/52453944c5be0a71459bb324731331b194346174))
* improved main readme ([8e280c6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8e280c64a64bb3d36b19bff74f90ea305852aceb))
* link typo ([d6038b0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d6038b0e1ed636959633ec03524ff5cf1cad3164))
* llama-index @VinciGit00 ([b847053](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b8470535f52730f6d1757912b420e35ef94688b4))
* research agent ([628fdd5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/628fdd5c0b0fbe371648b8a0171461ff2d615257))
* updated new documentation urls ([bd4cbf8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bd4cbf81e3c5740c1cc77b6204447cd7878c3978))
* updated precommit and installation guide ([bca95c5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bca95c5d6f1bd8fff3d0303b562ac229c6936f5d))
* updated readme ([2a1e643](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a1e64328ca4b20e9593b65517e7c5bf1fe43ffa))


### Refactor

* code refactoring ([197638b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/197638b7742854fceca756261b96e74024bdfc3f))
* code refactoring ([1be81f0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1be81f0539c631659dcf7e90540cebdd8539ae6a))
* code refactoring ([6270a6e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6270a6e43782f9efbb407e71b1ca7c57c37db38a))
* improved code structure ([d1a33dc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d1a33dcf87c401043b3ff7676638daadeca0f2c8))
* renamed functions ([95719e3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/95719e3b4a2c78de381bfdc39a077c42fdddec05))
* simplify infinite scroll config by replacing scroll_options with number_of_scrolls parameter ([ffc32ce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ffc32ce05a5c3546579142181466e34c3027ec67))
* update readme ([fee30c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fee30c3355ffee30fc1bffb56984085000df6192))


### Test

* Add coverage improvement test for scrapegraph-py/tests/test_localscraper.py ([84ba517](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/84ba51747898cec2bb74b4d6c4a5ea398b56bca7))
* Add coverage improvement test for scrapegraph-py/tests/test_markdownify.py ([c39dbb0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c39dbb034ab89e1830da63f24f534ee070046c5d))
* Add coverage improvement test for scrapegraph-py/tests/test_smartscraper.py ([2216f6f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2216f6f309cac66f6688c0d84190d71c29290415))


### CI

* **release:** 1.0.0 [skip ci] ([46756ac](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/46756ac26d7b540e523f3a23afe688673293e8c6))
* **release:** 1.0.0 [skip ci] ([635f7d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/635f7d09b172e6b00cd498ebf2d95799c82e0821))
* **release:** 1.0.0 [skip ci] ([763e52b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/763e52bdf696192eb8f0143f3e97ccd40ae0bb8c))
* **release:** 1.0.0 [skip ci] ([0a7a968](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0a7a96864fbe38f8b2b2887807415f8869d96c65))
* **release:** 1.1.0 [skip ci] ([fd55dc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fd55dc0d82f16dc277a9c45cf2e687245c4b76a2))
* **release:** 1.10.0 [skip ci] ([69a5d7d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69a5d7d66236050c2ba9c88fd53785f573d34fa2))
* **release:** 1.10.1 [skip ci] ([48eb09d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/48eb09d406bd1dafb02bc9b001c6ef9752c4125a))
* **release:** 1.10.2 [skip ci] ([9f2a50c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9f2a50c940a70aa04b4484053ccae3a1cfb4148c))
* **release:** 1.11.0 [skip ci] ([82fc505](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/82fc50507bb610f1059a12779a90d7d200c1759b))
* **release:** 1.11.0-beta.1 [skip ci] ([e25a870](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e25a87013eb7be0db193d0093392eb78f3f1cfb6))
* **release:** 1.12.0 [skip ci] ([15b9626](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15b9626c11f84c60b496d70422a2df86e76d49a5))
* **release:** 1.2.0 [skip ci] ([8ebd90b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ebd90b963de62c879910d7cf64f491bcf4c47f7))
* **release:** 1.2.1 [skip ci] ([bc5c9a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc5c9a8db64d0c792566f58d5265f6936edc5526))
* **release:** 1.2.2 [skip ci] ([14dcf99](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/14dcf99173a589557b7a2860716eedbee892b16b))
* **release:** 1.3.0 [skip ci] ([daf43d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/daf43d06761d85608b9599337e111da694a858a6))
* **release:** 1.4.0 [skip ci] ([cb18d8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cb18d8fb219dd55b6478ee33c051a40a091c4fd0))
* **release:** 1.4.1 [skip ci] ([0b42489](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0b424891395f0630c9886eb1a8a23232603e856f))
* **release:** 1.4.2 [skip ci] ([e4ad100](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e4ad100e3004a4b7c63f865d3f12398a080bb599))
* **release:** 1.4.3 [skip ci] ([11a0edc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/11a0edc54b299eea60a382c2781d3d1ac0084c3f))
* **release:** 1.4.3-beta.1 [skip ci] ([c4ba791](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c4ba791e45edfbff13332117f2583781354f90d6))
* **release:** 1.4.3-beta.2 [skip ci] ([3110601](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31106014d662745fa9afef6083f61452508b67fb))
* **release:** 1.4.3-beta.3 [skip ci] ([b6f7589](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b6f75899bd9f5d906cb5034b3a74c3ef46280537))
* **release:** 1.5.0 [skip ci] ([c7c91bd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c7c91bd7c6f3550089d1231b2167ca18921fd48f))
* **release:** 1.5.0-beta.1 [skip ci] ([298fce2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/298fce2058f7f39546afa022a135b497b9d8024d))
* **release:** 1.6.0 [skip ci] ([1b0fdce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1b0fdce5827378dc80a5cd0a83e7444d50db79c1))
* **release:** 1.6.0-beta.1 [skip ci] ([ba7588d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ba7588d978217d2c2fce5404d989c527fe63bb16))
* **release:** 1.7.0 [skip ci] ([bb2847c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bb2847ca1f7045c86b5fa26cb1c16422039bfafb))
* **release:** 1.7.0-beta.1 [skip ci] ([aab21db](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/aab21db9230800707c7814b0702e7d1f70a6a4f4))
* **release:** 1.8.0 [skip ci] ([8fa12bb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fa12bbc56dbcb4976551818ae5c99132ac393b3))
* **release:** 1.9.0 [skip ci] ([a21e331](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a21e3317a48632bbb442d352c47e5b155ee96d94))
* **release:** 1.9.0-beta.1 [skip ci] ([3173f66](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3173f661ff6d954a6059c8e899faba391cb51276))
* **release:** 1.9.0-beta.2 [skip ci] ([c2fef9e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2fef9e5405e16ba5d61a8b2fbf0b1c03c6fa306))
* **release:** 1.9.0-beta.3 [skip ci] ([ca9fa71](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ca9fa71d2e68aafa2a438b659349e1fb4589ebdf))
* **release:** 1.9.0-beta.4 [skip ci] ([b2e5ab1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b2e5ab167c0777449ac4974674abd294e0f7e41d))
* **release:** 1.9.0-beta.5 [skip ci] ([604aea3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/604aea3c6aff087388d6014f0d1fcd7df0c66f69))
* **release:** 1.9.0-beta.6 [skip ci] ([19c33b2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/19c33b2e0d8160d78549878c64355e16702d406a))
* **release:** 1.9.0-beta.7 [skip ci] ([c232796](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2327961096cd9f9ad3b0f54cf242a7d99ab11bc))

## 1.0.0 (2025-06-19)


### Features

* add client integration ([5cbc551](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5cbc551092b33849fdbb1e1468eb35ba8b4f5c20))
* add docstring ([04622dd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/04622dd39bb45223d266aab64ea086b2f1548425))
* add infinite scrolling ([928fb9b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/928fb9b274b55caaec3024bf1c3ca5b865120aa2))
* add infinte scrolling ([3166542](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3166542005eeae2b9fd9e5aaad0abc1966ec4abc))
* add integration for env variables ([2bf03a7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2bf03a7ca7a7936ad2c3b50ded4a6d90161fffa4))
* add integration for local_scraper ([4f6402a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4f6402a94ebfa1b7534fc77ccef2deee5e9295d1))
* add integration for sql ([8ae60c4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ae60c4cfcc070a0a7053862aafaf758e91f465f))
* add integration for the api ([457a2aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/457a2aac6c9afcf4bbb06a99e35a7f5ca5ed5797))
* add localScraper functionality ([7ee0bc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7ee0bc0778c1fc65b6f33bd76d0a4ca8735ce373))
* add markdownify and localscraper ([675de86](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/675de867428efb01d8d9f8aedca34055bce9e974))
* add markdownify functionality ([938274f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/938274f2f67d9e6bca212e6bebd6203349c6494c))
* add optional headers to request ([246f10e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/246f10ef3b24649887a813b5a31d2ffc7b848b1b))
* add requirement files ([65fe013](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/65fe013ff3859b53f17d097bad780038216797e3))
* add scrapegraphai api integration ([382c347](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/382c347061f9a0690cfab09393c11fd5e0ebee70))
* add time varying timeout ([12afa1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/12afa1d09858b04cb99b158ab2f9f1ea2c4967dd))
* added example of the smartScraper function using a schema ([e79c300](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e79c30038ede5c0b6b6460ecc3d791be6b21b811))
* changed SyncClient to Client ([89210bf](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/89210bf26ee8ee5fd15fd7994b3c1fb0b0ad185e))
* check ([5f9b4ed](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5f9b4edc08e6325124dc335eb1e145cfb7394113))
* enhaced python sdk ([e66e60d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e66e60de27b89c0ea0a9abcd097a001feb7e8147))
* final release maybe semantic? ([d096725](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d09672512605b2d8289abc017ef3c82147a69cd3))
* fix ([d03013c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d03013c5330d9b2728848655e373ea878eebf71d))
* implemented search scraper functionality ([44834c2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/44834c2e3c8523fffe88c9bbd97009a846b5997c))
* implemented support for requests with schema ([ad5f0b4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ad5f0b45d2dc183b63b27f5e5f4dd4b9801aa008))
* maybe final release? ([40035f3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/40035f3f0d9c8c2fcecbcd603397c38af405153a))
* merged localscraper into smartscraper ([eaac552](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/eaac552493f4a245cfb2246713a8febf87851d05))
* modified icons ([836faea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/836faea0975e7b1dcc13495a0c76c7d50cbedbaa))
* refactoring of the folders ([e613e2e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e613e2e07c95a4e5348d1a74b8ba9f1f853a0911))
* refctoring of the folder ([3085b5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3085b5a74f748c4ce42fa6e02fd04029a4dc25a5))
* removed local scraper ([021bf6d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/021bf6dcc6bd216cc8129b146e1f7892e52cf244))
* revert to old release ([6565b3e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6565b3e937958fc0b897eb84456643e02d90790e))
* searchscraper ([e281e0d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e281e0d798eccbe8114c75f8a3e2a2a4ab8cca25))
* semantic relaase ([93759c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/93759c39b8f44ee1c51fac843544c93e87708760))
* semantic release ([9613ba9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9613ba933274fe1bddb56339aae40617eaf46d65))
* semantic release ([956eceb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/956ecebc27dae00fa0b487f97eec8114dfc3a1bd))
* semantic release ([0bc1358](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0bc135814e6ebb438313b4d466357b2e5631f09d))
* splitted files ([5337d1e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5337d1e39f7625165066c4aada771a4eb25fa635))
* test ([9bec234](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9bec2340b0e507409c6ae221a8eb0ea93178a82f))
* test semantic release ([5dbb0cc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5dbb0cc1243be847f2d7dee4f6e3df0c6550d8aa))
* test semantic release ([66c789e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/66c789e907d69b6c8a919a2c7d4a2c4a79826d3d))
* test semantic release ([d63fdda](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d63fddaa3794677c862313b0058d34ddc358441d))
* test semantic release ([682baa3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/682baa39695f564b684568d9a6bf23ecda00b5ec))
* try semantic release ([d686c1f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d686c1ff1911885a553e68897efa95afcd09a503))
* update doc readme ([e317b1b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e317b1b0135c0d0134846ea0b0b63552773cff45))
* updated readmes ([d485cf0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d485cf0ee0bd331e5970a158636dcdb44db98d81))


### Bug Fixes

* .toml file ([31d9ad8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31d9ad8d65fde79022a9971c1b463ccd5452820a))
* add enw timeout ([cfc565c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cfc565c5ad23f547138be0466820c1c2dee6aa47))
* add new python compatibility ([45d24a6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/45d24a6a3d1c3090f1c575cf4fe6a8d80d637c38))
* add revert ([b81ec1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b81ec1d37d0a1635f444525e1e4a99823f5cea83))
* come back to py 3.10 ([e10bb5c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e10bb5c0ed0cd93a36b97eb91d634db8aac575d7))
* fixed configuration for ignored files ([76e1d0e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/76e1d0edbfbb796b87c3608610e4d4125cdf4bfd))
* fixed HttpError messages ([935dac1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/935dac100185b3622aa2744a38a2d4ce740deaa5))
* fixed schema example ([4be2bd0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4be2bd0310cb860864e7666d5613d1664818e505))
* houses examples and typos ([e787776](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e787776125215bc5c9d40e6691c971d46651548e))
* improve api desc ([87e2040](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/87e2040ce4fd090cf511f67048f6275502120ab7))
* logger working properly now ([6c619c1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6c619c11ea90c81e0054b36504cc3d9e62dce249))
* make timeout optional ([09b0cc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/09b0cc015d2b8f8848a625a7d75e36a5caf7b546))
* minor fix version ([d05bb6a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d05bb6a34a15d45ebce2056c89c146f4fcf5a35f))
* pyproject ([d5005a0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d5005a00671148c22956eb52f4bedc369f9361c2))
* pyproject ([d04f0aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d04f0aa770ebe480f293b60db0c5883f2c39e0f3))
* pyproject.toml ([1c2ae7f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1c2ae7fc9ffc485c9d36020da3fcc90037ea3c98))
* pyproject.toml ([a509471](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a5094710e63b903da61e359b9ea8f79bf57b48f2))
* python version ([98b859d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/98b859dab0effc966d1731372750e14abb0373c8))
* readme js sdk ([6f95f27](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6f95f2782354ab62ab2ad320e338c4be2701c20b))
* removed wrong information ([75ef97e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/75ef97eae8b31bac72a3e999e3423b8a455000f6))
* semanti release 2 ([b008a3b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b008a3bc691b52be167edd1cbd9f0d1d689d0989))
* semantic release ([4d230ae](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4d230ae6b2404466b956c7a567223a03ff6ae448))
* sync client ([8fee46f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fee46f7645c5b9e0cfa6d3d90b7d7e4e30567eb))
* the "workspace" key has been removed because it was conflicting with the package.json file in the scrapegraph-js folder. ([15e590c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15e590ca23b3ecfeabd387af3eb7b42548337f87))
* timeout ([57f6593](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/57f6593ee632595c39a9241009a0e71120baecc2))
* updated comment ([62e2792](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/62e2792174d5403f05c73aeb64bb515d722721d2))
* updated env variable loading ([e259ed1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e259ed173f249c935e2de3c54831edf9fa954caa))
* updated hatchling version ([2b41262](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2b412623aec22c3be37061347ec25e74ea8d6126))


### chore

* added dotenv pakage dependency ([e88abab](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e88abab18a3a375b6090790af4a1012381af164c))
* added more information about the package ([a91198d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a91198de86e9be84b20aeac0e69eba81392ad39b))
* added Zod package dependency ([49d3a59](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/49d3a59f916ac27170c3640775f0844063afd65a))
* changed pakage name ([f93e49b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f93e49bff839b8de2c4f41c638c9c4df76592463))
* fix _make_request not using it ([05f61ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/05f61ea10a8183fc8863b1703fd4fbf6ca921c93))
* fix pylint scripts ([7a593a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7a593a8a116d863d573f68d6e2282ba6c2204cbc))
* fix pyproject version ([bc0c722](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc0c722986d65c500496b91f5cd8cec23b19189a))
* fix semantic release, migrate to uv ([a70e1b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a70e1b7f86671e5d7a49c882b4c854d32c6b5944))
* improved url validation ([25072a9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/25072a9976873e59169cd7a9bcce5797f5dcbfa3))
* refactor examples ([85738d8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/85738d87117cf803e02c608b2476d24265ce65c6))
* set up CI scripts ([7b33f8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7b33f8f78e37c13eafcc0193fe7a2b2efb258cdf))
* set up eslint and prettier for code linting and formatting ([9d54406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9d544066c08d6dca6e4dd764f665e56912bc4285))
* update workflow scripts ([80ae3f7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/80ae3f761cc1b5cb860b9d75ee14920e37725cc0))
* **tests:** updated tests ([b33f0b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b33f0b7b602e29ea86ae2bfff7862279b5cca9ec))


### Docs

* added an example of the smartScraper functionality using a schema ([ae245c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ae245c83d70259a8eb5c626c21dfb3a0f6e76f62))
* added api reference ([f87a7c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f87a7c8fc3b39360f2339731af52b0b0766c80c2))
* added api reference ([0cf5f3a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0cf5f3ae4b5b8704e86fc21b298a053f3bd9822e))
* added cookbook reference ([54841e5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/54841e5c0f705a64c4295e4fc8a414af0e62ca4f))
* added langchain-scrapegraph examples ([b9d771e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b9d771eab5b0eace6eb03f0075094e3cc51efce9))
* added new image ([b710bd3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b710bd3d60603e3b720b1a811ad91f35b1bea832))
* added open in colab badge ([9e5519c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e5519c55be9a20da0d4a08e363a66bfacc970be))
* added two langchain-scrapegraph examples ([b18b14d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b18b14d41eab4cdd7ed8d6fdc7ceb5e9f8fa9b24))
* added two new examples ([b3fd406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b3fd406680ab9aab2d99640fbe5244a9ebb14263))
* **cookbook:** added two new examples ([2a8fb8c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a8fb8c45af4ff5b03483c7031ab541a03e36b83))
* added wired langgraph react agent ([69c82ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69c82ea3d068c677866cb062a4b0345073dce6de))
* added zillow example ([1eb365c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1eb365c7cf41aa8b04c96bd2667a7bddff7f6220))
* api reference ([2f3210c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2f3210cd37e40d29699fada48e754449e4b163e7))
* fixed cookbook images and urls ([b743830](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b74383090261f3d242fc58c16d8071f6da05dc97))
* github trending sdk ([f0890ef](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f0890efa79ca884d1825e4d47b92601d092d0080))
* improved examples ([5245394](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/52453944c5be0a71459bb324731331b194346174))
* improved main readme ([8e280c6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8e280c64a64bb3d36b19bff74f90ea305852aceb))
* link typo ([d6038b0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d6038b0e1ed636959633ec03524ff5cf1cad3164))
* llama-index @VinciGit00 ([b847053](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b8470535f52730f6d1757912b420e35ef94688b4))
* research agent ([628fdd5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/628fdd5c0b0fbe371648b8a0171461ff2d615257))
* updated new documentation urls ([bd4cbf8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bd4cbf81e3c5740c1cc77b6204447cd7878c3978))
* updated precommit and installation guide ([bca95c5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bca95c5d6f1bd8fff3d0303b562ac229c6936f5d))
* updated readme ([2a1e643](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a1e64328ca4b20e9593b65517e7c5bf1fe43ffa))


### Refactor

* code refactoring ([197638b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/197638b7742854fceca756261b96e74024bdfc3f))
* code refactoring ([1be81f0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1be81f0539c631659dcf7e90540cebdd8539ae6a))
* code refactoring ([6270a6e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6270a6e43782f9efbb407e71b1ca7c57c37db38a))
* improved code structure ([d1a33dc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d1a33dcf87c401043b3ff7676638daadeca0f2c8))
* renamed functions ([95719e3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/95719e3b4a2c78de381bfdc39a077c42fdddec05))
* simplify infinite scroll config by replacing scroll_options with number_of_scrolls parameter ([ffc32ce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ffc32ce05a5c3546579142181466e34c3027ec67))
* update readme ([fee30c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fee30c3355ffee30fc1bffb56984085000df6192))


### Test

* Add coverage improvement test for scrapegraph-py/tests/test_localscraper.py ([84ba517](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/84ba51747898cec2bb74b4d6c4a5ea398b56bca7))
* Add coverage improvement test for scrapegraph-py/tests/test_markdownify.py ([c39dbb0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c39dbb034ab89e1830da63f24f534ee070046c5d))
* Add coverage improvement test for scrapegraph-py/tests/test_smartscraper.py ([2216f6f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2216f6f309cac66f6688c0d84190d71c29290415))


### CI

* **release:** 1.0.0 [skip ci] ([635f7d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/635f7d09b172e6b00cd498ebf2d95799c82e0821))
* **release:** 1.0.0 [skip ci] ([763e52b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/763e52bdf696192eb8f0143f3e97ccd40ae0bb8c))
* **release:** 1.0.0 [skip ci] ([0a7a968](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0a7a96864fbe38f8b2b2887807415f8869d96c65))
* **release:** 1.1.0 [skip ci] ([fd55dc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fd55dc0d82f16dc277a9c45cf2e687245c4b76a2))
* **release:** 1.10.0 [skip ci] ([69a5d7d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69a5d7d66236050c2ba9c88fd53785f573d34fa2))
* **release:** 1.10.1 [skip ci] ([48eb09d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/48eb09d406bd1dafb02bc9b001c6ef9752c4125a))
* **release:** 1.10.2 [skip ci] ([9f2a50c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9f2a50c940a70aa04b4484053ccae3a1cfb4148c))
* **release:** 1.11.0 [skip ci] ([82fc505](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/82fc50507bb610f1059a12779a90d7d200c1759b))
* **release:** 1.11.0-beta.1 [skip ci] ([e25a870](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e25a87013eb7be0db193d0093392eb78f3f1cfb6))
* **release:** 1.12.0 [skip ci] ([15b9626](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15b9626c11f84c60b496d70422a2df86e76d49a5))
* **release:** 1.2.0 [skip ci] ([8ebd90b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ebd90b963de62c879910d7cf64f491bcf4c47f7))
* **release:** 1.2.1 [skip ci] ([bc5c9a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc5c9a8db64d0c792566f58d5265f6936edc5526))
* **release:** 1.2.2 [skip ci] ([14dcf99](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/14dcf99173a589557b7a2860716eedbee892b16b))
* **release:** 1.3.0 [skip ci] ([daf43d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/daf43d06761d85608b9599337e111da694a858a6))
* **release:** 1.4.0 [skip ci] ([cb18d8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cb18d8fb219dd55b6478ee33c051a40a091c4fd0))
* **release:** 1.4.1 [skip ci] ([0b42489](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0b424891395f0630c9886eb1a8a23232603e856f))
* **release:** 1.4.2 [skip ci] ([e4ad100](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e4ad100e3004a4b7c63f865d3f12398a080bb599))
* **release:** 1.4.3 [skip ci] ([11a0edc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/11a0edc54b299eea60a382c2781d3d1ac0084c3f))
* **release:** 1.4.3-beta.1 [skip ci] ([c4ba791](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c4ba791e45edfbff13332117f2583781354f90d6))
* **release:** 1.4.3-beta.2 [skip ci] ([3110601](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31106014d662745fa9afef6083f61452508b67fb))
* **release:** 1.4.3-beta.3 [skip ci] ([b6f7589](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b6f75899bd9f5d906cb5034b3a74c3ef46280537))
* **release:** 1.5.0 [skip ci] ([c7c91bd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c7c91bd7c6f3550089d1231b2167ca18921fd48f))
* **release:** 1.5.0-beta.1 [skip ci] ([298fce2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/298fce2058f7f39546afa022a135b497b9d8024d))
* **release:** 1.6.0 [skip ci] ([1b0fdce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1b0fdce5827378dc80a5cd0a83e7444d50db79c1))
* **release:** 1.6.0-beta.1 [skip ci] ([ba7588d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ba7588d978217d2c2fce5404d989c527fe63bb16))
* **release:** 1.7.0 [skip ci] ([bb2847c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bb2847ca1f7045c86b5fa26cb1c16422039bfafb))
* **release:** 1.7.0-beta.1 [skip ci] ([aab21db](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/aab21db9230800707c7814b0702e7d1f70a6a4f4))
* **release:** 1.8.0 [skip ci] ([8fa12bb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fa12bbc56dbcb4976551818ae5c99132ac393b3))
* **release:** 1.9.0 [skip ci] ([a21e331](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a21e3317a48632bbb442d352c47e5b155ee96d94))
* **release:** 1.9.0-beta.1 [skip ci] ([3173f66](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3173f661ff6d954a6059c8e899faba391cb51276))
* **release:** 1.9.0-beta.2 [skip ci] ([c2fef9e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2fef9e5405e16ba5d61a8b2fbf0b1c03c6fa306))
* **release:** 1.9.0-beta.3 [skip ci] ([ca9fa71](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ca9fa71d2e68aafa2a438b659349e1fb4589ebdf))
* **release:** 1.9.0-beta.4 [skip ci] ([b2e5ab1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b2e5ab167c0777449ac4974674abd294e0f7e41d))
* **release:** 1.9.0-beta.5 [skip ci] ([604aea3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/604aea3c6aff087388d6014f0d1fcd7df0c66f69))
* **release:** 1.9.0-beta.6 [skip ci] ([19c33b2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/19c33b2e0d8160d78549878c64355e16702d406a))
* **release:** 1.9.0-beta.7 [skip ci] ([c232796](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2327961096cd9f9ad3b0f54cf242a7d99ab11bc))

## 1.0.0 (2025-06-19)


### Features

* add client integration ([5cbc551](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5cbc551092b33849fdbb1e1468eb35ba8b4f5c20))
* add docstring ([04622dd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/04622dd39bb45223d266aab64ea086b2f1548425))
* add infinite scrolling ([928fb9b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/928fb9b274b55caaec3024bf1c3ca5b865120aa2))
* add infinte scrolling ([3166542](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3166542005eeae2b9fd9e5aaad0abc1966ec4abc))
* add integration for env variables ([2bf03a7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2bf03a7ca7a7936ad2c3b50ded4a6d90161fffa4))
* add integration for local_scraper ([4f6402a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4f6402a94ebfa1b7534fc77ccef2deee5e9295d1))
* add integration for sql ([8ae60c4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ae60c4cfcc070a0a7053862aafaf758e91f465f))
* add integration for the api ([457a2aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/457a2aac6c9afcf4bbb06a99e35a7f5ca5ed5797))
* add localScraper functionality ([7ee0bc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7ee0bc0778c1fc65b6f33bd76d0a4ca8735ce373))
* add markdownify and localscraper ([675de86](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/675de867428efb01d8d9f8aedca34055bce9e974))
* add markdownify functionality ([938274f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/938274f2f67d9e6bca212e6bebd6203349c6494c))
* add optional headers to request ([246f10e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/246f10ef3b24649887a813b5a31d2ffc7b848b1b))
* add requirement files ([65fe013](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/65fe013ff3859b53f17d097bad780038216797e3))
* add scrapegraphai api integration ([382c347](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/382c347061f9a0690cfab09393c11fd5e0ebee70))
* add time varying timeout ([12afa1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/12afa1d09858b04cb99b158ab2f9f1ea2c4967dd))
* added example of the smartScraper function using a schema ([e79c300](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e79c30038ede5c0b6b6460ecc3d791be6b21b811))
* changed SyncClient to Client ([89210bf](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/89210bf26ee8ee5fd15fd7994b3c1fb0b0ad185e))
* check ([5f9b4ed](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5f9b4edc08e6325124dc335eb1e145cfb7394113))
* enhaced python sdk ([e66e60d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e66e60de27b89c0ea0a9abcd097a001feb7e8147))
* final release maybe semantic? ([d096725](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d09672512605b2d8289abc017ef3c82147a69cd3))
* fix ([d03013c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d03013c5330d9b2728848655e373ea878eebf71d))
* implemented search scraper functionality ([44834c2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/44834c2e3c8523fffe88c9bbd97009a846b5997c))
* implemented support for requests with schema ([ad5f0b4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ad5f0b45d2dc183b63b27f5e5f4dd4b9801aa008))
* maybe final release? ([40035f3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/40035f3f0d9c8c2fcecbcd603397c38af405153a))
* merged localscraper into smartscraper ([eaac552](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/eaac552493f4a245cfb2246713a8febf87851d05))
* modified icons ([836faea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/836faea0975e7b1dcc13495a0c76c7d50cbedbaa))
* refactoring of the folders ([e613e2e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e613e2e07c95a4e5348d1a74b8ba9f1f853a0911))
* refctoring of the folder ([3085b5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3085b5a74f748c4ce42fa6e02fd04029a4dc25a5))
* removed local scraper ([021bf6d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/021bf6dcc6bd216cc8129b146e1f7892e52cf244))
* revert to old release ([6565b3e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6565b3e937958fc0b897eb84456643e02d90790e))
* searchscraper ([e281e0d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e281e0d798eccbe8114c75f8a3e2a2a4ab8cca25))
* semantic relaase ([93759c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/93759c39b8f44ee1c51fac843544c93e87708760))
* semantic release ([9613ba9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9613ba933274fe1bddb56339aae40617eaf46d65))
* semantic release ([956eceb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/956ecebc27dae00fa0b487f97eec8114dfc3a1bd))
* semantic release ([0bc1358](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0bc135814e6ebb438313b4d466357b2e5631f09d))
* splitted files ([5337d1e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5337d1e39f7625165066c4aada771a4eb25fa635))
* test ([9bec234](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9bec2340b0e507409c6ae221a8eb0ea93178a82f))
* test semantic release ([5dbb0cc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5dbb0cc1243be847f2d7dee4f6e3df0c6550d8aa))
* test semantic release ([66c789e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/66c789e907d69b6c8a919a2c7d4a2c4a79826d3d))
* test semantic release ([d63fdda](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d63fddaa3794677c862313b0058d34ddc358441d))
* test semantic release ([682baa3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/682baa39695f564b684568d9a6bf23ecda00b5ec))
* try semantic release ([d686c1f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d686c1ff1911885a553e68897efa95afcd09a503))
* update doc readme ([e317b1b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e317b1b0135c0d0134846ea0b0b63552773cff45))
* updated readmes ([d485cf0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d485cf0ee0bd331e5970a158636dcdb44db98d81))


### Bug Fixes

* .toml file ([31d9ad8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31d9ad8d65fde79022a9971c1b463ccd5452820a))
* add enw timeout ([cfc565c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cfc565c5ad23f547138be0466820c1c2dee6aa47))
* add new python compatibility ([45d24a6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/45d24a6a3d1c3090f1c575cf4fe6a8d80d637c38))
* add revert ([b81ec1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b81ec1d37d0a1635f444525e1e4a99823f5cea83))
* come back to py 3.10 ([e10bb5c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e10bb5c0ed0cd93a36b97eb91d634db8aac575d7))
* fixed configuration for ignored files ([76e1d0e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/76e1d0edbfbb796b87c3608610e4d4125cdf4bfd))
* fixed HttpError messages ([935dac1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/935dac100185b3622aa2744a38a2d4ce740deaa5))
* fixed schema example ([4be2bd0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4be2bd0310cb860864e7666d5613d1664818e505))
* houses examples and typos ([e787776](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e787776125215bc5c9d40e6691c971d46651548e))
* improve api desc ([87e2040](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/87e2040ce4fd090cf511f67048f6275502120ab7))
* logger working properly now ([6c619c1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6c619c11ea90c81e0054b36504cc3d9e62dce249))
* make timeout optional ([09b0cc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/09b0cc015d2b8f8848a625a7d75e36a5caf7b546))
* minor fix version ([d05bb6a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d05bb6a34a15d45ebce2056c89c146f4fcf5a35f))
* pyproject ([d5005a0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d5005a00671148c22956eb52f4bedc369f9361c2))
* pyproject ([d04f0aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d04f0aa770ebe480f293b60db0c5883f2c39e0f3))
* pyproject.toml ([1c2ae7f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1c2ae7fc9ffc485c9d36020da3fcc90037ea3c98))
* pyproject.toml ([a509471](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a5094710e63b903da61e359b9ea8f79bf57b48f2))
* python version ([98b859d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/98b859dab0effc966d1731372750e14abb0373c8))
* readme js sdk ([6f95f27](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6f95f2782354ab62ab2ad320e338c4be2701c20b))
* removed wrong information ([75ef97e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/75ef97eae8b31bac72a3e999e3423b8a455000f6))
* semanti release 2 ([b008a3b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b008a3bc691b52be167edd1cbd9f0d1d689d0989))
* semantic release ([4d230ae](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4d230ae6b2404466b956c7a567223a03ff6ae448))
* sync client ([8fee46f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fee46f7645c5b9e0cfa6d3d90b7d7e4e30567eb))
* the "workspace" key has been removed because it was conflicting with the package.json file in the scrapegraph-js folder. ([15e590c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15e590ca23b3ecfeabd387af3eb7b42548337f87))
* timeout ([57f6593](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/57f6593ee632595c39a9241009a0e71120baecc2))
* updated comment ([62e2792](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/62e2792174d5403f05c73aeb64bb515d722721d2))
* updated env variable loading ([e259ed1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e259ed173f249c935e2de3c54831edf9fa954caa))
* updated hatchling version ([2b41262](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2b412623aec22c3be37061347ec25e74ea8d6126))


### chore

* added dotenv pakage dependency ([e88abab](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e88abab18a3a375b6090790af4a1012381af164c))
* added more information about the package ([a91198d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a91198de86e9be84b20aeac0e69eba81392ad39b))
* added Zod package dependency ([49d3a59](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/49d3a59f916ac27170c3640775f0844063afd65a))
* changed pakage name ([f93e49b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f93e49bff839b8de2c4f41c638c9c4df76592463))
* fix _make_request not using it ([05f61ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/05f61ea10a8183fc8863b1703fd4fbf6ca921c93))
* fix pylint scripts ([7a593a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7a593a8a116d863d573f68d6e2282ba6c2204cbc))
* fix pyproject version ([bc0c722](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc0c722986d65c500496b91f5cd8cec23b19189a))
* fix semantic release, migrate to uv ([a70e1b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a70e1b7f86671e5d7a49c882b4c854d32c6b5944))
* improved url validation ([25072a9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/25072a9976873e59169cd7a9bcce5797f5dcbfa3))
* refactor examples ([85738d8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/85738d87117cf803e02c608b2476d24265ce65c6))
* set up CI scripts ([7b33f8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7b33f8f78e37c13eafcc0193fe7a2b2efb258cdf))
* set up eslint and prettier for code linting and formatting ([9d54406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9d544066c08d6dca6e4dd764f665e56912bc4285))
* update workflow scripts ([80ae3f7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/80ae3f761cc1b5cb860b9d75ee14920e37725cc0))
* **tests:** updated tests ([b33f0b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b33f0b7b602e29ea86ae2bfff7862279b5cca9ec))


### Docs

* added an example of the smartScraper functionality using a schema ([ae245c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ae245c83d70259a8eb5c626c21dfb3a0f6e76f62))
* added api reference ([f87a7c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f87a7c8fc3b39360f2339731af52b0b0766c80c2))
* added api reference ([0cf5f3a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0cf5f3ae4b5b8704e86fc21b298a053f3bd9822e))
* added cookbook reference ([54841e5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/54841e5c0f705a64c4295e4fc8a414af0e62ca4f))
* added langchain-scrapegraph examples ([b9d771e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b9d771eab5b0eace6eb03f0075094e3cc51efce9))
* added new image ([b710bd3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b710bd3d60603e3b720b1a811ad91f35b1bea832))
* added open in colab badge ([9e5519c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e5519c55be9a20da0d4a08e363a66bfacc970be))
* added two langchain-scrapegraph examples ([b18b14d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b18b14d41eab4cdd7ed8d6fdc7ceb5e9f8fa9b24))
* added two new examples ([b3fd406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b3fd406680ab9aab2d99640fbe5244a9ebb14263))
* **cookbook:** added two new examples ([2a8fb8c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a8fb8c45af4ff5b03483c7031ab541a03e36b83))
* added wired langgraph react agent ([69c82ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69c82ea3d068c677866cb062a4b0345073dce6de))
* added zillow example ([1eb365c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1eb365c7cf41aa8b04c96bd2667a7bddff7f6220))
* api reference ([2f3210c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2f3210cd37e40d29699fada48e754449e4b163e7))
* fixed cookbook images and urls ([b743830](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b74383090261f3d242fc58c16d8071f6da05dc97))
* github trending sdk ([f0890ef](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f0890efa79ca884d1825e4d47b92601d092d0080))
* improved examples ([5245394](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/52453944c5be0a71459bb324731331b194346174))
* improved main readme ([8e280c6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8e280c64a64bb3d36b19bff74f90ea305852aceb))
* link typo ([d6038b0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d6038b0e1ed636959633ec03524ff5cf1cad3164))
* llama-index @VinciGit00 ([b847053](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b8470535f52730f6d1757912b420e35ef94688b4))
* research agent ([628fdd5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/628fdd5c0b0fbe371648b8a0171461ff2d615257))
* updated new documentation urls ([bd4cbf8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bd4cbf81e3c5740c1cc77b6204447cd7878c3978))
* updated precommit and installation guide ([bca95c5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bca95c5d6f1bd8fff3d0303b562ac229c6936f5d))
* updated readme ([2a1e643](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a1e64328ca4b20e9593b65517e7c5bf1fe43ffa))


### Refactor

* code refactoring ([197638b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/197638b7742854fceca756261b96e74024bdfc3f))
* code refactoring ([1be81f0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1be81f0539c631659dcf7e90540cebdd8539ae6a))
* code refactoring ([6270a6e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6270a6e43782f9efbb407e71b1ca7c57c37db38a))
* improved code structure ([d1a33dc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d1a33dcf87c401043b3ff7676638daadeca0f2c8))
* renamed functions ([95719e3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/95719e3b4a2c78de381bfdc39a077c42fdddec05))
* simplify infinite scroll config by replacing scroll_options with number_of_scrolls parameter ([ffc32ce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ffc32ce05a5c3546579142181466e34c3027ec67))
* update readme ([fee30c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fee30c3355ffee30fc1bffb56984085000df6192))


### Test

* Add coverage improvement test for scrapegraph-py/tests/test_localscraper.py ([84ba517](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/84ba51747898cec2bb74b4d6c4a5ea398b56bca7))
* Add coverage improvement test for scrapegraph-py/tests/test_markdownify.py ([c39dbb0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c39dbb034ab89e1830da63f24f534ee070046c5d))
* Add coverage improvement test for scrapegraph-py/tests/test_smartscraper.py ([2216f6f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2216f6f309cac66f6688c0d84190d71c29290415))


### CI

* **release:** 1.0.0 [skip ci] ([763e52b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/763e52bdf696192eb8f0143f3e97ccd40ae0bb8c))
* **release:** 1.0.0 [skip ci] ([0a7a968](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0a7a96864fbe38f8b2b2887807415f8869d96c65))
* **release:** 1.1.0 [skip ci] ([fd55dc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fd55dc0d82f16dc277a9c45cf2e687245c4b76a2))
* **release:** 1.10.0 [skip ci] ([69a5d7d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69a5d7d66236050c2ba9c88fd53785f573d34fa2))
* **release:** 1.10.1 [skip ci] ([48eb09d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/48eb09d406bd1dafb02bc9b001c6ef9752c4125a))
* **release:** 1.10.2 [skip ci] ([9f2a50c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9f2a50c940a70aa04b4484053ccae3a1cfb4148c))
* **release:** 1.11.0 [skip ci] ([82fc505](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/82fc50507bb610f1059a12779a90d7d200c1759b))
* **release:** 1.11.0-beta.1 [skip ci] ([e25a870](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e25a87013eb7be0db193d0093392eb78f3f1cfb6))
* **release:** 1.12.0 [skip ci] ([15b9626](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15b9626c11f84c60b496d70422a2df86e76d49a5))
* **release:** 1.2.0 [skip ci] ([8ebd90b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ebd90b963de62c879910d7cf64f491bcf4c47f7))
* **release:** 1.2.1 [skip ci] ([bc5c9a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc5c9a8db64d0c792566f58d5265f6936edc5526))
* **release:** 1.2.2 [skip ci] ([14dcf99](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/14dcf99173a589557b7a2860716eedbee892b16b))
* **release:** 1.3.0 [skip ci] ([daf43d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/daf43d06761d85608b9599337e111da694a858a6))
* **release:** 1.4.0 [skip ci] ([cb18d8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cb18d8fb219dd55b6478ee33c051a40a091c4fd0))
* **release:** 1.4.1 [skip ci] ([0b42489](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0b424891395f0630c9886eb1a8a23232603e856f))
* **release:** 1.4.2 [skip ci] ([e4ad100](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e4ad100e3004a4b7c63f865d3f12398a080bb599))
* **release:** 1.4.3 [skip ci] ([11a0edc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/11a0edc54b299eea60a382c2781d3d1ac0084c3f))
* **release:** 1.4.3-beta.1 [skip ci] ([c4ba791](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c4ba791e45edfbff13332117f2583781354f90d6))
* **release:** 1.4.3-beta.2 [skip ci] ([3110601](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31106014d662745fa9afef6083f61452508b67fb))
* **release:** 1.4.3-beta.3 [skip ci] ([b6f7589](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b6f75899bd9f5d906cb5034b3a74c3ef46280537))
* **release:** 1.5.0 [skip ci] ([c7c91bd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c7c91bd7c6f3550089d1231b2167ca18921fd48f))
* **release:** 1.5.0-beta.1 [skip ci] ([298fce2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/298fce2058f7f39546afa022a135b497b9d8024d))
* **release:** 1.6.0 [skip ci] ([1b0fdce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1b0fdce5827378dc80a5cd0a83e7444d50db79c1))
* **release:** 1.6.0-beta.1 [skip ci] ([ba7588d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ba7588d978217d2c2fce5404d989c527fe63bb16))
* **release:** 1.7.0 [skip ci] ([bb2847c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bb2847ca1f7045c86b5fa26cb1c16422039bfafb))
* **release:** 1.7.0-beta.1 [skip ci] ([aab21db](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/aab21db9230800707c7814b0702e7d1f70a6a4f4))
* **release:** 1.8.0 [skip ci] ([8fa12bb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fa12bbc56dbcb4976551818ae5c99132ac393b3))
* **release:** 1.9.0 [skip ci] ([a21e331](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a21e3317a48632bbb442d352c47e5b155ee96d94))
* **release:** 1.9.0-beta.1 [skip ci] ([3173f66](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3173f661ff6d954a6059c8e899faba391cb51276))
* **release:** 1.9.0-beta.2 [skip ci] ([c2fef9e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2fef9e5405e16ba5d61a8b2fbf0b1c03c6fa306))
* **release:** 1.9.0-beta.3 [skip ci] ([ca9fa71](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ca9fa71d2e68aafa2a438b659349e1fb4589ebdf))
* **release:** 1.9.0-beta.4 [skip ci] ([b2e5ab1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b2e5ab167c0777449ac4974674abd294e0f7e41d))
* **release:** 1.9.0-beta.5 [skip ci] ([604aea3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/604aea3c6aff087388d6014f0d1fcd7df0c66f69))
* **release:** 1.9.0-beta.6 [skip ci] ([19c33b2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/19c33b2e0d8160d78549878c64355e16702d406a))
* **release:** 1.9.0-beta.7 [skip ci] ([c232796](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2327961096cd9f9ad3b0f54cf242a7d99ab11bc))

## 1.0.0 (2025-06-16)


### Features

* add client integration ([5cbc551](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5cbc551092b33849fdbb1e1468eb35ba8b4f5c20))
* add docstring ([04622dd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/04622dd39bb45223d266aab64ea086b2f1548425))
* add infinite scrolling ([928fb9b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/928fb9b274b55caaec3024bf1c3ca5b865120aa2))
* add integration for env variables ([2bf03a7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2bf03a7ca7a7936ad2c3b50ded4a6d90161fffa4))
* add integration for local_scraper ([4f6402a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4f6402a94ebfa1b7534fc77ccef2deee5e9295d1))
* add integration for sql ([8ae60c4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ae60c4cfcc070a0a7053862aafaf758e91f465f))
* add integration for the api ([457a2aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/457a2aac6c9afcf4bbb06a99e35a7f5ca5ed5797))
* add localScraper functionality ([7ee0bc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7ee0bc0778c1fc65b6f33bd76d0a4ca8735ce373))
* add markdownify and localscraper ([675de86](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/675de867428efb01d8d9f8aedca34055bce9e974))
* add markdownify functionality ([938274f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/938274f2f67d9e6bca212e6bebd6203349c6494c))
* add optional headers to request ([246f10e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/246f10ef3b24649887a813b5a31d2ffc7b848b1b))
* add requirement files ([65fe013](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/65fe013ff3859b53f17d097bad780038216797e3))
* add scrapegraphai api integration ([382c347](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/382c347061f9a0690cfab09393c11fd5e0ebee70))
* add time varying timeout ([12afa1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/12afa1d09858b04cb99b158ab2f9f1ea2c4967dd))
* added example of the smartScraper function using a schema ([e79c300](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e79c30038ede5c0b6b6460ecc3d791be6b21b811))
* changed SyncClient to Client ([89210bf](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/89210bf26ee8ee5fd15fd7994b3c1fb0b0ad185e))
* check ([5f9b4ed](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5f9b4edc08e6325124dc335eb1e145cfb7394113))
* enhaced python sdk ([e66e60d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e66e60de27b89c0ea0a9abcd097a001feb7e8147))
* final release maybe semantic? ([d096725](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d09672512605b2d8289abc017ef3c82147a69cd3))
* fix ([d03013c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d03013c5330d9b2728848655e373ea878eebf71d))
* implemented search scraper functionality ([44834c2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/44834c2e3c8523fffe88c9bbd97009a846b5997c))
* implemented support for requests with schema ([ad5f0b4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ad5f0b45d2dc183b63b27f5e5f4dd4b9801aa008))
* maybe final release? ([40035f3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/40035f3f0d9c8c2fcecbcd603397c38af405153a))
* merged localscraper into smartscraper ([eaac552](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/eaac552493f4a245cfb2246713a8febf87851d05))
* modified icons ([836faea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/836faea0975e7b1dcc13495a0c76c7d50cbedbaa))
* refactoring of the folders ([e613e2e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e613e2e07c95a4e5348d1a74b8ba9f1f853a0911))
* refctoring of the folder ([3085b5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3085b5a74f748c4ce42fa6e02fd04029a4dc25a5))
* removed local scraper ([021bf6d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/021bf6dcc6bd216cc8129b146e1f7892e52cf244))
* revert to old release ([6565b3e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6565b3e937958fc0b897eb84456643e02d90790e))
* searchscraper ([e281e0d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e281e0d798eccbe8114c75f8a3e2a2a4ab8cca25))
* semantic relaase ([93759c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/93759c39b8f44ee1c51fac843544c93e87708760))
* semantic release ([9613ba9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9613ba933274fe1bddb56339aae40617eaf46d65))
* semantic release ([956eceb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/956ecebc27dae00fa0b487f97eec8114dfc3a1bd))
* semantic release ([0bc1358](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0bc135814e6ebb438313b4d466357b2e5631f09d))
* splitted files ([5337d1e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5337d1e39f7625165066c4aada771a4eb25fa635))
* test ([9bec234](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9bec2340b0e507409c6ae221a8eb0ea93178a82f))
* test semantic release ([5dbb0cc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5dbb0cc1243be847f2d7dee4f6e3df0c6550d8aa))
* test semantic release ([66c789e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/66c789e907d69b6c8a919a2c7d4a2c4a79826d3d))
* test semantic release ([d63fdda](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d63fddaa3794677c862313b0058d34ddc358441d))
* test semantic release ([682baa3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/682baa39695f564b684568d9a6bf23ecda00b5ec))
* try semantic release ([d686c1f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d686c1ff1911885a553e68897efa95afcd09a503))
* update doc readme ([e317b1b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e317b1b0135c0d0134846ea0b0b63552773cff45))
* updated readmes ([d485cf0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d485cf0ee0bd331e5970a158636dcdb44db98d81))


### Bug Fixes

* .toml file ([31d9ad8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31d9ad8d65fde79022a9971c1b463ccd5452820a))
* add enw timeout ([cfc565c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cfc565c5ad23f547138be0466820c1c2dee6aa47))
* add new python compatibility ([45d24a6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/45d24a6a3d1c3090f1c575cf4fe6a8d80d637c38))
* add revert ([b81ec1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b81ec1d37d0a1635f444525e1e4a99823f5cea83))
* come back to py 3.10 ([e10bb5c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e10bb5c0ed0cd93a36b97eb91d634db8aac575d7))
* fixed configuration for ignored files ([76e1d0e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/76e1d0edbfbb796b87c3608610e4d4125cdf4bfd))
* fixed HttpError messages ([935dac1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/935dac100185b3622aa2744a38a2d4ce740deaa5))
* fixed schema example ([4be2bd0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4be2bd0310cb860864e7666d5613d1664818e505))
* houses examples and typos ([e787776](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e787776125215bc5c9d40e6691c971d46651548e))
* improve api desc ([87e2040](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/87e2040ce4fd090cf511f67048f6275502120ab7))
* logger working properly now ([6c619c1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6c619c11ea90c81e0054b36504cc3d9e62dce249))
* make timeout optional ([09b0cc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/09b0cc015d2b8f8848a625a7d75e36a5caf7b546))
* minor fix version ([d05bb6a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d05bb6a34a15d45ebce2056c89c146f4fcf5a35f))
* pyproject ([d5005a0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d5005a00671148c22956eb52f4bedc369f9361c2))
* pyproject ([d04f0aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d04f0aa770ebe480f293b60db0c5883f2c39e0f3))
* pyproject.toml ([1c2ae7f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1c2ae7fc9ffc485c9d36020da3fcc90037ea3c98))
* pyproject.toml ([a509471](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a5094710e63b903da61e359b9ea8f79bf57b48f2))
* python version ([98b859d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/98b859dab0effc966d1731372750e14abb0373c8))
* readme js sdk ([6f95f27](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6f95f2782354ab62ab2ad320e338c4be2701c20b))
* removed wrong information ([75ef97e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/75ef97eae8b31bac72a3e999e3423b8a455000f6))
* semanti release 2 ([b008a3b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b008a3bc691b52be167edd1cbd9f0d1d689d0989))
* semantic release ([4d230ae](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4d230ae6b2404466b956c7a567223a03ff6ae448))
* sync client ([8fee46f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fee46f7645c5b9e0cfa6d3d90b7d7e4e30567eb))
* the "workspace" key has been removed because it was conflicting with the package.json file in the scrapegraph-js folder. ([15e590c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15e590ca23b3ecfeabd387af3eb7b42548337f87))
* timeout ([57f6593](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/57f6593ee632595c39a9241009a0e71120baecc2))
* updated comment ([62e2792](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/62e2792174d5403f05c73aeb64bb515d722721d2))
* updated env variable loading ([e259ed1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e259ed173f249c935e2de3c54831edf9fa954caa))
* updated hatchling version ([2b41262](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2b412623aec22c3be37061347ec25e74ea8d6126))


### chore

* added dotenv pakage dependency ([e88abab](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e88abab18a3a375b6090790af4a1012381af164c))
* added more information about the package ([a91198d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a91198de86e9be84b20aeac0e69eba81392ad39b))
* added Zod package dependency ([49d3a59](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/49d3a59f916ac27170c3640775f0844063afd65a))
* changed pakage name ([f93e49b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f93e49bff839b8de2c4f41c638c9c4df76592463))
* fix _make_request not using it ([05f61ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/05f61ea10a8183fc8863b1703fd4fbf6ca921c93))
* fix pylint scripts ([7a593a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7a593a8a116d863d573f68d6e2282ba6c2204cbc))
* fix pyproject version ([bc0c722](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc0c722986d65c500496b91f5cd8cec23b19189a))
* fix semantic release, migrate to uv ([a70e1b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a70e1b7f86671e5d7a49c882b4c854d32c6b5944))
* improved url validation ([25072a9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/25072a9976873e59169cd7a9bcce5797f5dcbfa3))
* refactor examples ([85738d8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/85738d87117cf803e02c608b2476d24265ce65c6))
* set up CI scripts ([7b33f8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7b33f8f78e37c13eafcc0193fe7a2b2efb258cdf))
* set up eslint and prettier for code linting and formatting ([9d54406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9d544066c08d6dca6e4dd764f665e56912bc4285))
* update workflow scripts ([80ae3f7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/80ae3f761cc1b5cb860b9d75ee14920e37725cc0))
* **tests:** updated tests ([b33f0b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b33f0b7b602e29ea86ae2bfff7862279b5cca9ec))


### Docs

* added an example of the smartScraper functionality using a schema ([ae245c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ae245c83d70259a8eb5c626c21dfb3a0f6e76f62))
* added api reference ([f87a7c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f87a7c8fc3b39360f2339731af52b0b0766c80c2))
* added api reference ([0cf5f3a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0cf5f3ae4b5b8704e86fc21b298a053f3bd9822e))
* added cookbook reference ([54841e5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/54841e5c0f705a64c4295e4fc8a414af0e62ca4f))
* added langchain-scrapegraph examples ([b9d771e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b9d771eab5b0eace6eb03f0075094e3cc51efce9))
* added new image ([b710bd3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b710bd3d60603e3b720b1a811ad91f35b1bea832))
* added open in colab badge ([9e5519c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e5519c55be9a20da0d4a08e363a66bfacc970be))
* added two langchain-scrapegraph examples ([b18b14d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b18b14d41eab4cdd7ed8d6fdc7ceb5e9f8fa9b24))
* added two new examples ([b3fd406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b3fd406680ab9aab2d99640fbe5244a9ebb14263))
* **cookbook:** added two new examples ([2a8fb8c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a8fb8c45af4ff5b03483c7031ab541a03e36b83))
* added wired langgraph react agent ([69c82ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69c82ea3d068c677866cb062a4b0345073dce6de))
* added zillow example ([1eb365c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1eb365c7cf41aa8b04c96bd2667a7bddff7f6220))
* api reference ([2f3210c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2f3210cd37e40d29699fada48e754449e4b163e7))
* fixed cookbook images and urls ([b743830](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b74383090261f3d242fc58c16d8071f6da05dc97))
* github trending sdk ([f0890ef](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f0890efa79ca884d1825e4d47b92601d092d0080))
* improved examples ([5245394](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/52453944c5be0a71459bb324731331b194346174))
* improved main readme ([8e280c6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8e280c64a64bb3d36b19bff74f90ea305852aceb))
* link typo ([d6038b0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d6038b0e1ed636959633ec03524ff5cf1cad3164))
* llama-index @VinciGit00 ([b847053](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b8470535f52730f6d1757912b420e35ef94688b4))
* research agent ([628fdd5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/628fdd5c0b0fbe371648b8a0171461ff2d615257))
* updated new documentation urls ([bd4cbf8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bd4cbf81e3c5740c1cc77b6204447cd7878c3978))
* updated precommit and installation guide ([bca95c5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bca95c5d6f1bd8fff3d0303b562ac229c6936f5d))
* updated readme ([2a1e643](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a1e64328ca4b20e9593b65517e7c5bf1fe43ffa))


### Refactor

* code refactoring ([197638b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/197638b7742854fceca756261b96e74024bdfc3f))
* code refactoring ([1be81f0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1be81f0539c631659dcf7e90540cebdd8539ae6a))
* code refactoring ([6270a6e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6270a6e43782f9efbb407e71b1ca7c57c37db38a))
* improved code structure ([d1a33dc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d1a33dcf87c401043b3ff7676638daadeca0f2c8))
* renamed functions ([95719e3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/95719e3b4a2c78de381bfdc39a077c42fdddec05))
* simplify infinite scroll config by replacing scroll_options with number_of_scrolls parameter ([ffc32ce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ffc32ce05a5c3546579142181466e34c3027ec67))
* update readme ([fee30c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fee30c3355ffee30fc1bffb56984085000df6192))


### Test

* Add coverage improvement test for scrapegraph-py/tests/test_localscraper.py ([84ba517](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/84ba51747898cec2bb74b4d6c4a5ea398b56bca7))
* Add coverage improvement test for scrapegraph-py/tests/test_markdownify.py ([c39dbb0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c39dbb034ab89e1830da63f24f534ee070046c5d))
* Add coverage improvement test for scrapegraph-py/tests/test_smartscraper.py ([2216f6f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2216f6f309cac66f6688c0d84190d71c29290415))


### CI

* **release:** 1.0.0 [skip ci] ([0a7a968](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0a7a96864fbe38f8b2b2887807415f8869d96c65))
* **release:** 1.1.0 [skip ci] ([fd55dc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fd55dc0d82f16dc277a9c45cf2e687245c4b76a2))
* **release:** 1.10.0 [skip ci] ([69a5d7d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69a5d7d66236050c2ba9c88fd53785f573d34fa2))
* **release:** 1.10.1 [skip ci] ([48eb09d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/48eb09d406bd1dafb02bc9b001c6ef9752c4125a))
* **release:** 1.10.2 [skip ci] ([9f2a50c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9f2a50c940a70aa04b4484053ccae3a1cfb4148c))
* **release:** 1.11.0 [skip ci] ([82fc505](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/82fc50507bb610f1059a12779a90d7d200c1759b))
* **release:** 1.11.0-beta.1 [skip ci] ([e25a870](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e25a87013eb7be0db193d0093392eb78f3f1cfb6))
* **release:** 1.12.0 [skip ci] ([15b9626](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15b9626c11f84c60b496d70422a2df86e76d49a5))
* **release:** 1.2.0 [skip ci] ([8ebd90b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ebd90b963de62c879910d7cf64f491bcf4c47f7))
* **release:** 1.2.1 [skip ci] ([bc5c9a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc5c9a8db64d0c792566f58d5265f6936edc5526))
* **release:** 1.2.2 [skip ci] ([14dcf99](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/14dcf99173a589557b7a2860716eedbee892b16b))
* **release:** 1.3.0 [skip ci] ([daf43d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/daf43d06761d85608b9599337e111da694a858a6))
* **release:** 1.4.0 [skip ci] ([cb18d8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cb18d8fb219dd55b6478ee33c051a40a091c4fd0))
* **release:** 1.4.1 [skip ci] ([0b42489](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0b424891395f0630c9886eb1a8a23232603e856f))
* **release:** 1.4.2 [skip ci] ([e4ad100](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e4ad100e3004a4b7c63f865d3f12398a080bb599))
* **release:** 1.4.3 [skip ci] ([11a0edc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/11a0edc54b299eea60a382c2781d3d1ac0084c3f))
* **release:** 1.4.3-beta.1 [skip ci] ([c4ba791](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c4ba791e45edfbff13332117f2583781354f90d6))
* **release:** 1.4.3-beta.2 [skip ci] ([3110601](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31106014d662745fa9afef6083f61452508b67fb))
* **release:** 1.4.3-beta.3 [skip ci] ([b6f7589](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b6f75899bd9f5d906cb5034b3a74c3ef46280537))
* **release:** 1.5.0 [skip ci] ([c7c91bd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c7c91bd7c6f3550089d1231b2167ca18921fd48f))
* **release:** 1.5.0-beta.1 [skip ci] ([298fce2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/298fce2058f7f39546afa022a135b497b9d8024d))
* **release:** 1.6.0 [skip ci] ([1b0fdce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1b0fdce5827378dc80a5cd0a83e7444d50db79c1))
* **release:** 1.6.0-beta.1 [skip ci] ([ba7588d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ba7588d978217d2c2fce5404d989c527fe63bb16))
* **release:** 1.7.0 [skip ci] ([bb2847c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bb2847ca1f7045c86b5fa26cb1c16422039bfafb))
* **release:** 1.7.0-beta.1 [skip ci] ([aab21db](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/aab21db9230800707c7814b0702e7d1f70a6a4f4))
* **release:** 1.8.0 [skip ci] ([8fa12bb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fa12bbc56dbcb4976551818ae5c99132ac393b3))
* **release:** 1.9.0 [skip ci] ([a21e331](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a21e3317a48632bbb442d352c47e5b155ee96d94))
* **release:** 1.9.0-beta.1 [skip ci] ([3173f66](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3173f661ff6d954a6059c8e899faba391cb51276))
* **release:** 1.9.0-beta.2 [skip ci] ([c2fef9e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2fef9e5405e16ba5d61a8b2fbf0b1c03c6fa306))
* **release:** 1.9.0-beta.3 [skip ci] ([ca9fa71](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ca9fa71d2e68aafa2a438b659349e1fb4589ebdf))
* **release:** 1.9.0-beta.4 [skip ci] ([b2e5ab1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b2e5ab167c0777449ac4974674abd294e0f7e41d))
* **release:** 1.9.0-beta.5 [skip ci] ([604aea3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/604aea3c6aff087388d6014f0d1fcd7df0c66f69))
* **release:** 1.9.0-beta.6 [skip ci] ([19c33b2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/19c33b2e0d8160d78549878c64355e16702d406a))
* **release:** 1.9.0-beta.7 [skip ci] ([c232796](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2327961096cd9f9ad3b0f54cf242a7d99ab11bc))

## 1.0.0 (2025-06-16)


### Features

* add client integration ([5cbc551](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5cbc551092b33849fdbb1e1468eb35ba8b4f5c20))
* add docstring ([04622dd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/04622dd39bb45223d266aab64ea086b2f1548425))
* add integration for env variables ([2bf03a7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2bf03a7ca7a7936ad2c3b50ded4a6d90161fffa4))
* add integration for local_scraper ([4f6402a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4f6402a94ebfa1b7534fc77ccef2deee5e9295d1))
* add integration for sql ([8ae60c4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ae60c4cfcc070a0a7053862aafaf758e91f465f))
* add integration for the api ([457a2aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/457a2aac6c9afcf4bbb06a99e35a7f5ca5ed5797))
* add localScraper functionality ([7ee0bc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7ee0bc0778c1fc65b6f33bd76d0a4ca8735ce373))
* add markdownify and localscraper ([675de86](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/675de867428efb01d8d9f8aedca34055bce9e974))
* add markdownify functionality ([938274f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/938274f2f67d9e6bca212e6bebd6203349c6494c))
* add optional headers to request ([246f10e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/246f10ef3b24649887a813b5a31d2ffc7b848b1b))
* add requirement files ([65fe013](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/65fe013ff3859b53f17d097bad780038216797e3))
* add scrapegraphai api integration ([382c347](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/382c347061f9a0690cfab09393c11fd5e0ebee70))
* add time varying timeout ([12afa1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/12afa1d09858b04cb99b158ab2f9f1ea2c4967dd))
* added example of the smartScraper function using a schema ([e79c300](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e79c30038ede5c0b6b6460ecc3d791be6b21b811))
* changed SyncClient to Client ([89210bf](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/89210bf26ee8ee5fd15fd7994b3c1fb0b0ad185e))
* check ([5f9b4ed](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5f9b4edc08e6325124dc335eb1e145cfb7394113))
* enhaced python sdk ([e66e60d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e66e60de27b89c0ea0a9abcd097a001feb7e8147))
* final release maybe semantic? ([d096725](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d09672512605b2d8289abc017ef3c82147a69cd3))
* fix ([d03013c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d03013c5330d9b2728848655e373ea878eebf71d))
* implemented search scraper functionality ([44834c2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/44834c2e3c8523fffe88c9bbd97009a846b5997c))
* implemented support for requests with schema ([ad5f0b4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ad5f0b45d2dc183b63b27f5e5f4dd4b9801aa008))
* maybe final release? ([40035f3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/40035f3f0d9c8c2fcecbcd603397c38af405153a))
* merged localscraper into smartscraper ([eaac552](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/eaac552493f4a245cfb2246713a8febf87851d05))
* modified icons ([836faea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/836faea0975e7b1dcc13495a0c76c7d50cbedbaa))
* refactoring of the folders ([e613e2e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e613e2e07c95a4e5348d1a74b8ba9f1f853a0911))
* refctoring of the folder ([3085b5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3085b5a74f748c4ce42fa6e02fd04029a4dc25a5))
* removed local scraper ([021bf6d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/021bf6dcc6bd216cc8129b146e1f7892e52cf244))
* revert to old release ([6565b3e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6565b3e937958fc0b897eb84456643e02d90790e))
* searchscraper ([e281e0d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e281e0d798eccbe8114c75f8a3e2a2a4ab8cca25))
* semantic relaase ([93759c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/93759c39b8f44ee1c51fac843544c93e87708760))
* semantic release ([9613ba9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9613ba933274fe1bddb56339aae40617eaf46d65))
* semantic release ([956eceb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/956ecebc27dae00fa0b487f97eec8114dfc3a1bd))
* semantic release ([0bc1358](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0bc135814e6ebb438313b4d466357b2e5631f09d))
* splitted files ([5337d1e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5337d1e39f7625165066c4aada771a4eb25fa635))
* test ([9bec234](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9bec2340b0e507409c6ae221a8eb0ea93178a82f))
* test semantic release ([5dbb0cc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5dbb0cc1243be847f2d7dee4f6e3df0c6550d8aa))
* test semantic release ([66c789e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/66c789e907d69b6c8a919a2c7d4a2c4a79826d3d))
* test semantic release ([d63fdda](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d63fddaa3794677c862313b0058d34ddc358441d))
* test semantic release ([682baa3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/682baa39695f564b684568d9a6bf23ecda00b5ec))
* try semantic release ([d686c1f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d686c1ff1911885a553e68897efa95afcd09a503))
* update doc readme ([e317b1b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e317b1b0135c0d0134846ea0b0b63552773cff45))
* updated readmes ([d485cf0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d485cf0ee0bd331e5970a158636dcdb44db98d81))


### Bug Fixes

* .toml file ([31d9ad8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31d9ad8d65fde79022a9971c1b463ccd5452820a))
* add enw timeout ([cfc565c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cfc565c5ad23f547138be0466820c1c2dee6aa47))
* add new python compatibility ([45d24a6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/45d24a6a3d1c3090f1c575cf4fe6a8d80d637c38))
* add revert ([b81ec1d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b81ec1d37d0a1635f444525e1e4a99823f5cea83))
* come back to py 3.10 ([e10bb5c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e10bb5c0ed0cd93a36b97eb91d634db8aac575d7))
* fixed configuration for ignored files ([76e1d0e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/76e1d0edbfbb796b87c3608610e4d4125cdf4bfd))
* fixed HttpError messages ([935dac1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/935dac100185b3622aa2744a38a2d4ce740deaa5))
* fixed schema example ([4be2bd0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4be2bd0310cb860864e7666d5613d1664818e505))
* houses examples and typos ([e787776](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e787776125215bc5c9d40e6691c971d46651548e))
* improve api desc ([87e2040](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/87e2040ce4fd090cf511f67048f6275502120ab7))
* logger working properly now ([6c619c1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6c619c11ea90c81e0054b36504cc3d9e62dce249))
* make timeout optional ([09b0cc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/09b0cc015d2b8f8848a625a7d75e36a5caf7b546))
* minor fix version ([d05bb6a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d05bb6a34a15d45ebce2056c89c146f4fcf5a35f))
* pyproject ([d5005a0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d5005a00671148c22956eb52f4bedc369f9361c2))
* pyproject ([d04f0aa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d04f0aa770ebe480f293b60db0c5883f2c39e0f3))
* pyproject.toml ([1c2ae7f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1c2ae7fc9ffc485c9d36020da3fcc90037ea3c98))
* pyproject.toml ([a509471](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a5094710e63b903da61e359b9ea8f79bf57b48f2))
* python version ([98b859d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/98b859dab0effc966d1731372750e14abb0373c8))
* readme js sdk ([6f95f27](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6f95f2782354ab62ab2ad320e338c4be2701c20b))
* removed wrong information ([75ef97e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/75ef97eae8b31bac72a3e999e3423b8a455000f6))
* semanti release 2 ([b008a3b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b008a3bc691b52be167edd1cbd9f0d1d689d0989))
* semantic release ([4d230ae](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/4d230ae6b2404466b956c7a567223a03ff6ae448))
* sync client ([8fee46f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fee46f7645c5b9e0cfa6d3d90b7d7e4e30567eb))
* the "workspace" key has been removed because it was conflicting with the package.json file in the scrapegraph-js folder. ([15e590c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15e590ca23b3ecfeabd387af3eb7b42548337f87))
* timeout ([57f6593](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/57f6593ee632595c39a9241009a0e71120baecc2))
* updated comment ([62e2792](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/62e2792174d5403f05c73aeb64bb515d722721d2))
* updated env variable loading ([e259ed1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e259ed173f249c935e2de3c54831edf9fa954caa))
* updated hatchling version ([2b41262](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2b412623aec22c3be37061347ec25e74ea8d6126))


### chore

* added dotenv pakage dependency ([e88abab](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e88abab18a3a375b6090790af4a1012381af164c))
* added more information about the package ([a91198d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a91198de86e9be84b20aeac0e69eba81392ad39b))
* added Zod package dependency ([49d3a59](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/49d3a59f916ac27170c3640775f0844063afd65a))
* changed pakage name ([f93e49b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f93e49bff839b8de2c4f41c638c9c4df76592463))
* fix _make_request not using it ([05f61ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/05f61ea10a8183fc8863b1703fd4fbf6ca921c93))
* fix pylint scripts ([7a593a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7a593a8a116d863d573f68d6e2282ba6c2204cbc))
* fix pyproject version ([bc0c722](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc0c722986d65c500496b91f5cd8cec23b19189a))
* fix semantic release, migrate to uv ([a70e1b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a70e1b7f86671e5d7a49c882b4c854d32c6b5944))
* improved url validation ([25072a9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/25072a9976873e59169cd7a9bcce5797f5dcbfa3))
* refactor examples ([85738d8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/85738d87117cf803e02c608b2476d24265ce65c6))
* set up CI scripts ([7b33f8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7b33f8f78e37c13eafcc0193fe7a2b2efb258cdf))
* set up eslint and prettier for code linting and formatting ([9d54406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9d544066c08d6dca6e4dd764f665e56912bc4285))
* update workflow scripts ([80ae3f7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/80ae3f761cc1b5cb860b9d75ee14920e37725cc0))
* **tests:** updated tests ([b33f0b7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b33f0b7b602e29ea86ae2bfff7862279b5cca9ec))


### Docs

* added an example of the smartScraper functionality using a schema ([ae245c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ae245c83d70259a8eb5c626c21dfb3a0f6e76f62))
* added api reference ([f87a7c8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f87a7c8fc3b39360f2339731af52b0b0766c80c2))
* added api reference ([0cf5f3a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0cf5f3ae4b5b8704e86fc21b298a053f3bd9822e))
* added cookbook reference ([54841e5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/54841e5c0f705a64c4295e4fc8a414af0e62ca4f))
* added langchain-scrapegraph examples ([b9d771e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b9d771eab5b0eace6eb03f0075094e3cc51efce9))
* added new image ([b710bd3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b710bd3d60603e3b720b1a811ad91f35b1bea832))
* added open in colab badge ([9e5519c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e5519c55be9a20da0d4a08e363a66bfacc970be))
* added two langchain-scrapegraph examples ([b18b14d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b18b14d41eab4cdd7ed8d6fdc7ceb5e9f8fa9b24))
* added two new examples ([b3fd406](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b3fd406680ab9aab2d99640fbe5244a9ebb14263))
* **cookbook:** added two new examples ([2a8fb8c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a8fb8c45af4ff5b03483c7031ab541a03e36b83))
* added wired langgraph react agent ([69c82ea](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69c82ea3d068c677866cb062a4b0345073dce6de))
* added zillow example ([1eb365c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1eb365c7cf41aa8b04c96bd2667a7bddff7f6220))
* api reference ([2f3210c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2f3210cd37e40d29699fada48e754449e4b163e7))
* fixed cookbook images and urls ([b743830](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b74383090261f3d242fc58c16d8071f6da05dc97))
* github trending sdk ([f0890ef](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f0890efa79ca884d1825e4d47b92601d092d0080))
* improved examples ([5245394](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/52453944c5be0a71459bb324731331b194346174))
* improved main readme ([8e280c6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8e280c64a64bb3d36b19bff74f90ea305852aceb))
* link typo ([d6038b0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d6038b0e1ed636959633ec03524ff5cf1cad3164))
* llama-index @VinciGit00 ([b847053](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b8470535f52730f6d1757912b420e35ef94688b4))
* research agent ([628fdd5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/628fdd5c0b0fbe371648b8a0171461ff2d615257))
* updated new documentation urls ([bd4cbf8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bd4cbf81e3c5740c1cc77b6204447cd7878c3978))
* updated precommit and installation guide ([bca95c5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bca95c5d6f1bd8fff3d0303b562ac229c6936f5d))
* updated readme ([2a1e643](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a1e64328ca4b20e9593b65517e7c5bf1fe43ffa))


### Refactor

* code refactoring ([197638b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/197638b7742854fceca756261b96e74024bdfc3f))
* code refactoring ([1be81f0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1be81f0539c631659dcf7e90540cebdd8539ae6a))
* code refactoring ([6270a6e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6270a6e43782f9efbb407e71b1ca7c57c37db38a))
* improved code structure ([d1a33dc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d1a33dcf87c401043b3ff7676638daadeca0f2c8))
* renamed functions ([95719e3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/95719e3b4a2c78de381bfdc39a077c42fdddec05))
* update readme ([fee30c3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fee30c3355ffee30fc1bffb56984085000df6192))


### Test

* Add coverage improvement test for scrapegraph-py/tests/test_localscraper.py ([84ba517](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/84ba51747898cec2bb74b4d6c4a5ea398b56bca7))
* Add coverage improvement test for scrapegraph-py/tests/test_markdownify.py ([c39dbb0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c39dbb034ab89e1830da63f24f534ee070046c5d))
* Add coverage improvement test for scrapegraph-py/tests/test_smartscraper.py ([2216f6f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2216f6f309cac66f6688c0d84190d71c29290415))


### CI

* **release:** 1.1.0 [skip ci] ([fd55dc0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/fd55dc0d82f16dc277a9c45cf2e687245c4b76a2))
* **release:** 1.10.0 [skip ci] ([69a5d7d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/69a5d7d66236050c2ba9c88fd53785f573d34fa2))
* **release:** 1.10.1 [skip ci] ([48eb09d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/48eb09d406bd1dafb02bc9b001c6ef9752c4125a))
* **release:** 1.10.2 [skip ci] ([9f2a50c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9f2a50c940a70aa04b4484053ccae3a1cfb4148c))
* **release:** 1.11.0 [skip ci] ([82fc505](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/82fc50507bb610f1059a12779a90d7d200c1759b))
* **release:** 1.11.0-beta.1 [skip ci] ([e25a870](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e25a87013eb7be0db193d0093392eb78f3f1cfb6))
* **release:** 1.12.0 [skip ci] ([15b9626](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/15b9626c11f84c60b496d70422a2df86e76d49a5))
* **release:** 1.2.0 [skip ci] ([8ebd90b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ebd90b963de62c879910d7cf64f491bcf4c47f7))
* **release:** 1.2.1 [skip ci] ([bc5c9a8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc5c9a8db64d0c792566f58d5265f6936edc5526))
* **release:** 1.2.2 [skip ci] ([14dcf99](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/14dcf99173a589557b7a2860716eedbee892b16b))
* **release:** 1.3.0 [skip ci] ([daf43d0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/daf43d06761d85608b9599337e111da694a858a6))
* **release:** 1.4.0 [skip ci] ([cb18d8f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cb18d8fb219dd55b6478ee33c051a40a091c4fd0))
* **release:** 1.4.1 [skip ci] ([0b42489](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0b424891395f0630c9886eb1a8a23232603e856f))
* **release:** 1.4.2 [skip ci] ([e4ad100](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e4ad100e3004a4b7c63f865d3f12398a080bb599))
* **release:** 1.4.3 [skip ci] ([11a0edc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/11a0edc54b299eea60a382c2781d3d1ac0084c3f))
* **release:** 1.4.3-beta.1 [skip ci] ([c4ba791](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c4ba791e45edfbff13332117f2583781354f90d6))
* **release:** 1.4.3-beta.2 [skip ci] ([3110601](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/31106014d662745fa9afef6083f61452508b67fb))
* **release:** 1.4.3-beta.3 [skip ci] ([b6f7589](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b6f75899bd9f5d906cb5034b3a74c3ef46280537))
* **release:** 1.5.0 [skip ci] ([c7c91bd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c7c91bd7c6f3550089d1231b2167ca18921fd48f))
* **release:** 1.5.0-beta.1 [skip ci] ([298fce2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/298fce2058f7f39546afa022a135b497b9d8024d))
* **release:** 1.6.0 [skip ci] ([1b0fdce](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1b0fdce5827378dc80a5cd0a83e7444d50db79c1))
* **release:** 1.6.0-beta.1 [skip ci] ([ba7588d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ba7588d978217d2c2fce5404d989c527fe63bb16))
* **release:** 1.7.0 [skip ci] ([bb2847c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bb2847ca1f7045c86b5fa26cb1c16422039bfafb))
* **release:** 1.7.0-beta.1 [skip ci] ([aab21db](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/aab21db9230800707c7814b0702e7d1f70a6a4f4))
* **release:** 1.8.0 [skip ci] ([8fa12bb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8fa12bbc56dbcb4976551818ae5c99132ac393b3))
* **release:** 1.9.0 [skip ci] ([a21e331](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a21e3317a48632bbb442d352c47e5b155ee96d94))
* **release:** 1.9.0-beta.1 [skip ci] ([3173f66](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3173f661ff6d954a6059c8e899faba391cb51276))
* **release:** 1.9.0-beta.2 [skip ci] ([c2fef9e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2fef9e5405e16ba5d61a8b2fbf0b1c03c6fa306))
* **release:** 1.9.0-beta.3 [skip ci] ([ca9fa71](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ca9fa71d2e68aafa2a438b659349e1fb4589ebdf))
* **release:** 1.9.0-beta.4 [skip ci] ([b2e5ab1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b2e5ab167c0777449ac4974674abd294e0f7e41d))
* **release:** 1.9.0-beta.5 [skip ci] ([604aea3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/604aea3c6aff087388d6014f0d1fcd7df0c66f69))
* **release:** 1.9.0-beta.6 [skip ci] ([19c33b2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/19c33b2e0d8160d78549878c64355e16702d406a))
* **release:** 1.9.0-beta.7 [skip ci] ([c232796](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2327961096cd9f9ad3b0f54cf242a7d99ab11bc))

## [1.12.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.11.0...v1.12.0) (2025-02-05)


### Features

* implemented search scraper functionality ([2c5a59b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2c5a59bd5cee46535aa1b157463db9164d7d42fb))


### Bug Fixes

* fixed HttpError messages ([869441b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/869441b156f49ed38bb95236f26d5b87139d6db0))


### CI

* **release:** 1.11.0-beta.1 [skip ci] ([2a62b40](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2a62b403df3481f5ad803bc192d3177beee79e35))

## [1.11.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.10.2...v1.11.0) (2025-02-03)
## [1.11.0-beta.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.10.2...v1.11.0-beta.1) (2025-02-03)


### Features

* add optional headers to request ([bb851d7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bb851d785d121b039d5e968327fb930955a3fd92))
* merged localscraper into smartscraper ([503dbd1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/503dbd19b8cec4d2ff4575786b0eec25db2e80e6))
* modified icons ([bcb9b0b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bcb9b0b731b057d242fdf80b43d96879ff7a2764))
* searchscraper ([2e04e5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2e04e5a1bbd207a7ceeea594878bdea542a7a856))
* updated readmes ([bfdbea0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bfdbea038918d79df2e3e9442e25d5f08bbccbbc))


### chore

* refactor examples ([8e00846](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8e008465f7280c53e2faab7a92f02871ffc5b867))
* **tests:** updated tests ([9149ce8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9149ce85a78b503098f80910c20de69831030378))


### CI

* **release:** 1.9.0-beta.6 [skip ci] ([c898e99](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c898e9917cde8fe291312e3b2dc7d06f6afd3932))
* **release:** 1.9.0-beta.7 [skip ci] ([2c1875b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2c1875b1413eef5a2335688a7e0baf32ec31dcee))

## [1.9.0-beta.7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.9.0-beta.6...v1.9.0-beta.7) (2025-02-03)
## [1.10.2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.10.1...v1.10.2) (2025-01-22)


### Bug Fixes

* pyproject ([5d6a9ee](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5d6a9eed262d1041eea3110fbaa1729f2c16855c))

## [1.10.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.10.0...v1.10.1) (2025-01-22)


### Bug Fixes

* pyproject.toml ([c6e6c6e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c6e6c6e33cd189bd78d7366dd570ee1e4d8c2c68))
* pyproject.toml ([e8aed70](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e8aed7011c1a65eca2909df88a804179a04bdd96))

## [1.10.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.9.0...v1.10.0) (2025-01-16)


### Features

* add optional headers to request ([bb851d7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bb851d785d121b039d5e968327fb930955a3fd92))
* merged localscraper into smartscraper ([503dbd1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/503dbd19b8cec4d2ff4575786b0eec25db2e80e6))
* modified icons ([bcb9b0b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bcb9b0b731b057d242fdf80b43d96879ff7a2764))
* searchscraper ([2e04e5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2e04e5a1bbd207a7ceeea594878bdea542a7a856))
* updated readmes ([bfdbea0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bfdbea038918d79df2e3e9442e25d5f08bbccbbc))


### chore

* refactor examples ([8e00846](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8e008465f7280c53e2faab7a92f02871ffc5b867))
* **tests:** updated tests ([9149ce8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9149ce85a78b503098f80910c20de69831030378))

## [1.9.0-beta.6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.9.0-beta.5...v1.9.0-beta.6) (2025-01-08)
* add integration for sql ([2543b5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2543b5a9b84826de5c583d38fe89cf21aad077e6))


### Docs

* added new image ([b052ddb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b052ddbe0d1a5ea182c54897c94d4c88fbc54ab8))

## [1.9.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.8.0...v1.9.0) (2025-01-08)


### Features

* add localScraper functionality ([8701eb2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8701eb2ca7f108b922eb1617c850a58c0f88f8f9))
* add time varying timeout ([945b876](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/945b876a0c23d4b2a29ef916bd6fa9af425f9ab5))
* revert to old release ([d88a3ac](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d88a3ac6969a0abdf1f6b8eccde9ad8284d41d20))
* update doc readme ([c02c411](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c02c411ffba9fc7906fcc7664d0ce841e0e2fb54))


### Bug Fixes

* .toml file ([e719881](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e7198817d8dac802361ab84bc4d5d961fb926767))
* add new python compatibility ([77b67f6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/77b67f646d75abd3a558b40cb31c52c12cc7182e))
* add revert ([09257e0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/09257e08246d8aee96b3944ac14cc14b88e5f818))
* come back to py 3.10 ([26d3a75](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/26d3a75ed973590e21d55c985bf71f3905a3ac0e))
* houses examples and typos ([c596c44](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c596c448e334a76444ecf3ee738ec275fd5316fa))
* improve api desc ([62243f8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/62243f84384ae238c0bd0c48abc76a6b99376c74))
* make timeout optional ([49b8e4b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/49b8e4b8d3aa637bfd28a59e47cd1f5efad91075))
* minor fix version ([0b972c6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0b972c69a9ea843d8ec89327f35c287b0d7a2bb4))
* pyproject ([2440f7f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2440f7f2a5179c6e3a86faf4eefa1d5edf7524c8))
* python version ([24366b0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/24366b08eefe0789da9a0ccafb8058e8744ee58b))
* updated hatchling version ([740933a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/740933aff79a5873e6d1c633afcedb674d1f4cf0))


### chore

* fix _make_request not using it ([701a4c1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/701a4c13bbe7e5d4ba9eae1846b0bd8abbbdb6b8))
* fix pyproject version ([3567034](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3567034e02e4dfab967248a5a4eaee426f145d6b))


### Docs

* added api reference ([6929a7a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6929a7adcc09f47a652cfd7ad7557314b52db9c0))
* added api reference ([7b88876](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7b88876facc2b37e4738797b6a18c65ca89f9aa0))
* added cookbook reference ([e68c1bd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e68c1bd1268663a625441bc7f955a1d4514ac0ef))
* added langchain-scrapegraph examples ([479dbdb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/479dbdb1833a3ce6c2ce03eaf1400487ff534dd0))
* added open in colab badge ([c2fc1ef](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2fc1efc687623bd821468c19a102dbaed70bd4b))
* added two langchain-scrapegraph examples ([8f3a87e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8f3a87e880f820f4453d564fec02ef02af3742b3))
* added two new examples ([5fa2b42](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5fa2b42685df565531cd7d2495e1d42e5c34ff90))
* **cookbook:** added two new examples ([f67769e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f67769e0ef0bba6fc4fd6908ec666b63ac2368b9))
* added wired langgraph react agent ([9f1e0cf](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9f1e0cf72f4f84ee1f81439befaeace8c5c7ffa5))
* added zillow example ([7fad92c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/7fad92ca5e87cd9ecc60702e1599b2cff479af5c))
* api reference ([855c2e5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/855c2e51ebfaf7d8e4be008e8f22fdf66c0dc0e0))
* fixed cookbook images and urls ([f860167](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f8601674f686084a7df88e221475c014b40015b8))
* github trending sdk ([320de37](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/320de37d2e8ec0d859ca91725c6cc35dab68e183))
* link typo ([e1bfd6a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e1bfd6aa364b369c17457513f1c68e91376d0c68))
* llama-index @VinciGit00 ([6de5eb2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6de5eb22490de2f5ff4075836bf1aca2e304ff8d))
* research agent ([6e06afa](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6e06afa9f8d5e9f05a38e605562ec10249216704))
* updated new documentation urls ([1d0cb46](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1d0cb46e5710707151ce227fa2043d5de5e92657))


### CI

* **release:** 1.9.0-beta.1 [skip ci] ([236d55b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/236d55b7c3ce571258fdd488ad7ac0891b2958ce))
* **release:** 1.9.0-beta.2 [skip ci] ([59611f6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/59611f6d1d690b89917abd03ba863b46b40c2b95))
* **release:** 1.9.0-beta.3 [skip ci] ([cbf2da4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cbf2da44b22da23c4d3870d52f88f9b0214cab27))
* **release:** 1.9.0-beta.4 [skip ci] ([05d57ae](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/05d57aee168b1d184ef352240a03a43457e16749))
* **release:** 1.9.0-beta.5 [skip ci] ([d03b9bf](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d03b9bf8807d6a42a41e6f82d65e54931844039c))

## [1.9.0-beta.5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.9.0-beta.4...v1.9.0-beta.5) (2025-01-03)


### Bug Fixes

* updated hatchling version ([740933a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/740933aff79a5873e6d1c633afcedb674d1f4cf0))

## [1.9.0-beta.4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.9.0-beta.3...v1.9.0-beta.4) (2025-01-03)


### Bug Fixes

* improve api desc ([62243f8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/62243f84384ae238c0bd0c48abc76a6b99376c74))

## [1.9.0-beta.3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.9.0-beta.2...v1.9.0-beta.3) (2024-12-10)


### Bug Fixes

* come back to py 3.10 ([26d3a75](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/26d3a75ed973590e21d55c985bf71f3905a3ac0e))

## [1.9.0-beta.2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.9.0-beta.1...v1.9.0-beta.2) (2024-12-10)


### Bug Fixes

* add new python compatibility ([77b67f6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/77b67f646d75abd3a558b40cb31c52c12cc7182e))

## [1.9.0-beta.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.8.0...v1.9.0-beta.1) (2024-12-10)


### Features

* add localScraper functionality ([8701eb2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8701eb2ca7f108b922eb1617c850a58c0f88f8f9))
* revert to old release ([d88a3ac](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d88a3ac6969a0abdf1f6b8eccde9ad8284d41d20))


### Bug Fixes

* .toml file ([e719881](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e7198817d8dac802361ab84bc4d5d961fb926767))
* add revert ([09257e0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/09257e08246d8aee96b3944ac14cc14b88e5f818))
* minor fix version ([0b972c6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0b972c69a9ea843d8ec89327f35c287b0d7a2bb4))
* pyproject ([2440f7f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2440f7f2a5179c6e3a86faf4eefa1d5edf7524c8))
* python version ([24366b0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/24366b08eefe0789da9a0ccafb8058e8744ee58b))

## [1.8.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.7.0...v1.8.0) (2024-12-08)


### Features

* add markdownify functionality ([239d27a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/239d27aac28c6b132aba54bbb1fa0216cc59ce89))


### Bug Fixes

* fixed configuration for ignored files ([bc08dcb](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/bc08dcb21536a146fd941119931bc8e89e8e42c6))
* fixed schema example ([365378a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/365378a0c8c9125800ed6d74629d87776cf484a0))


### Docs

* improved main readme ([50fdf92](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/50fdf920e1d00e8f457138f9e68df74354696fc0))

## [1.7.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.6.0...v1.7.0) (2024-12-05)


### Features

* add markdownify and localscraper ([6296510](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6296510b22ce511adde4265532ac6329a05967e0))


### CI

* **release:** 1.7.0-beta.1 [skip ci] ([5e65800](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5e6580067903644ac0c47b2c2f8d27a3e9dd2ae2))

## [1.7.0-beta.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.6.0...v1.7.0-beta.1) (2024-12-05)


### Features

* add markdownify and localscraper ([6296510](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6296510b22ce511adde4265532ac6329a05967e0))

## [1.6.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.5.0...v1.6.0) (2024-12-05)


### Features

* changed SyncClient to Client ([9e1e496](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e1e496059cd24810a96b818da1811830586f94b))


### Bug Fixes

* logger working properly now ([9712d4c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9712d4c39eea860f813e86a5e2ffc14db6d3a655))
* updated env variable loading ([2643f11](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2643f11c968f0daab26529d513f08c2817763b50))


### CI

* **release:** 1.4.3-beta.2 [skip ci] ([8ab6147](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ab61476b6763b936e2e7d423b04bb51983fb8ea))
* **release:** 1.4.3-beta.3 [skip ci] ([1bc26c7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1bc26c738443f7f52492a7b2cbe7c9f335315797))
* **release:** 1.5.0-beta.1 [skip ci] ([8900f7b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8900f7bf53239b6a73fb41196f5327d05763bae4))
* **release:** 1.6.0-beta.1 [skip ci] ([636db26](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/636db26649dfac76503b556d5f724faf32e3522c))

## [1.6.0-beta.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.5.0...v1.6.0-beta.1) (2024-12-05)


### Features

* changed SyncClient to Client ([9e1e496](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e1e496059cd24810a96b818da1811830586f94b))


### Bug Fixes

* logger working properly now ([9712d4c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9712d4c39eea860f813e86a5e2ffc14db6d3a655))
* updated env variable loading ([2643f11](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2643f11c968f0daab26529d513f08c2817763b50))


### CI

* **release:** 1.4.3-beta.2 [skip ci] ([8ab6147](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ab61476b6763b936e2e7d423b04bb51983fb8ea))
* **release:** 1.4.3-beta.3 [skip ci] ([1bc26c7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/1bc26c738443f7f52492a7b2cbe7c9f335315797))
* **release:** 1.5.0-beta.1 [skip ci] ([8900f7b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8900f7bf53239b6a73fb41196f5327d05763bae4))

## [1.5.0-beta.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.4.3-beta.3...v1.5.0-beta.1) (2024-12-05)


### Features

* changed SyncClient to Client ([9e1e496](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e1e496059cd24810a96b818da1811830586f94b))


## [1.5.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.4.3...v1.5.0) (2024-12-04)


### Features

* splitted files ([2791691](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2791691a9381063cc38ac4f4fe7c884166c93116))

## [1.4.3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.4.2...v1.4.3) (2024-12-03)

## [1.4.3-beta.3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.4.3-beta.2...v1.4.3-beta.3) (2024-12-05)


### Bug Fixes

* updated env variable loading ([2643f11](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2643f11c968f0daab26529d513f08c2817763b50))

## [1.4.3-beta.2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.4.3-beta.1...v1.4.3-beta.2) (2024-12-05)


### Bug Fixes

* logger working properly now ([9712d4c](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9712d4c39eea860f813e86a5e2ffc14db6d3a655))

### Bug Fixes

* updated comment ([8250818](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/825081883940bc1caa37f4f13e10f710770aeb9c))


### chore

* improved url validation ([83eac53](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/83eac530269a767e5469c4aded1656fe00a2cdc0))


### CI

* **release:** 1.4.3-beta.1 [skip ci] ([cd1169b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cd1169b584ffa621d99961e2e95db96a28037e13))

## [1.4.3-beta.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.4.2...v1.4.3-beta.1) (2024-12-03)


### Bug Fixes

* updated comment ([8250818](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/825081883940bc1caa37f4f13e10f710770aeb9c))


### chore

* improved url validation ([83eac53](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/83eac530269a767e5469c4aded1656fe00a2cdc0))

## [1.4.2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.4.1...v1.4.2) (2024-12-02)


### Bug Fixes

* timeout ([589aa49](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/589aa49d4434f7112a840d178e5e48918b7799e1))

## [1.4.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.4.0...v1.4.1) (2024-12-02)


### Bug Fixes

* sync client ([690e87b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/690e87b52505f12da172147a78007497f6edf54c))


### chore

* set up eslint and prettier for code linting and formatting ([13cf1e5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/13cf1e5c28ec739d2d35617bd57d7cf8203c3f7e))

## [1.4.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.3.0...v1.4.0) (2024-11-30)


### Features

* added example of the smartScraper function using a schema ([baf933b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/baf933b0826b63d4ecf61c8593676357619a1c73))
* implemented support for requests with schema ([10a1a5a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/10a1a5a477a6659aabf3afebfffdbefc14d12d3e))


### Bug Fixes

* the "workspace" key has been removed because it was conflicting with the package.json file in the scrapegraph-js folder. ([1299173](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/129917377b6a685d769a480b717bf980d3199833))


### chore

* added Zod package dependency ([ee5738b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ee5738bd737cd07a553d148403a4bbb5e80e5be3))


### Docs

* added an example of the smartScraper functionality using a schema ([cf2f28f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/cf2f28fa029df0acb7058fde8239046d77ef0a8a))


### Refactor

* code refactoring ([a2b57c7](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a2b57c7e482dfb5c7c1a125d1684e0367088c83b))

## [1.3.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.2.2...v1.3.0) (2024-11-30)


### Features

* add integration for env variables ([6a351f3](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6a351f3ef70a1f00b5f5de5aaba2f408b6bf07dd))

## [1.2.2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.2.1...v1.2.2) (2024-11-29)


### Bug Fixes

* add enw timeout ([46ebd9d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/46ebd9dc9897ca2ef9460a3e46b3a24abe90f943))

## [1.2.1](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.2.0...v1.2.1) (2024-11-29)


### Bug Fixes

* readme js sdk ([3c2178e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3c2178e04e873885abc8aca0312f5a4a1dd9cdd0))
* removed wrong information ([88a2f50](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/88a2f509dc34ad69f41fe6d13f31de191895bc1a))


### chore

* changed pakage name ([9e9e138](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9e9e138617658e068a1c77a4dbac24b4d550d42a))
* fix pylint scripts ([5913d5f](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5913d5f0d697196469f8ec952e1a65e1c7f49621))


### Docs

* improved examples ([a9c1fa5](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/a9c1fa5dcd7610b2b0c217d39fb2b77a67aa3fac))
* updated precommit and installation guide ([c16705b](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c16705b8f405f57d2cb1719099d4b566186a7257))
* updated readme ([ee9efa6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/ee9efa608b9a284861f712ab2a69d49da3d26523))


### Refactor

* code refactoring ([01ca238](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/01ca2384f098ecbb063ac4681e6d32f590a03f42))

## [1.2.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.1.0...v1.2.0) (2024-11-28)


### Features

* enhaced python sdk ([c253363](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/c2533636c230426be06cd505598e8a85d5771cbc))


### chore

* set up CI scripts ([f688bdc](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/f688bdc11746325582787fa3c1ffb429838f46b6))
* update workflow scripts ([5ea9cac](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/5ea9cacb6758171283d96ff9aa1934c25af804f1))

## [1.1.0](https://github.com/ScrapeGraphAI/scrapegraph-sdk/compare/v1.0.0...v1.1.0) (2024-11-28)


### Features

* check ([9871ff8](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/9871ff81acfb42031ee9db526a7dba9e29d3c55b))
* final release maybe semantic? ([8ce3ccd](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/8ce3ccd3509d0487da212f541e039ee7009dd8f3))
* fix ([d81ab09](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d81ab091aa1ff08927ed7765055764b9e51083ee))
* maybe final release? ([595c3c6](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/595c3c6b6ca0e8eaacd5959422ab9018516f3fa8))
* semantic relaase ([30ff13a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/30ff13a219df982e07df7b5366f09dedc0892de5))
* semantic release ([6df4b18](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6df4b1833c8c418766b1649f80f9d6cd1fa8a201))
* semantic release ([edd23d9](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/edd23d93375ef33fa97a0b409045fdbd18090d10))
* semantic release ([e5e4908](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/e5e49080bc6d3d1440d6b333f9cadfd493ff0449))
* test ([3bb66c4](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3bb66c4efe3eb5407f6eb88d31bda678ac3651b3))
* test semantic release ([63d3a36](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/63d3a3623363c358e5761e1b7737f262c8238c82))
* test semantic release ([19eda59](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/19eda59be7adbea80ed189fd0af85ab0c3c930bd))
* test semantic release ([3e611f2](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/3e611f21248a46120fa8ff3d30392522f6d1419a))
* test semantic release ([6320819](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/6320819e12cbd3e0fa3faa93179d2d26f1323bb4))
* try semantic release ([d953723](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d9537230ef978aaf42d72073dc95ba598db8db6c))


### chore

* added dotenv pakage dependency ([2e9d93d](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/2e9d93d571c47c3b7aa789be811f53161387b08e))
* fix semantic release, migrate to uv ([b6db205](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/b6db205ad5a90031bc658e65794e4dda2159fee2))


### Refactor

* code refactoring ([164131a](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/164131a2abe899bd151113bd84efa113306327c2))
* renamed functions ([d39f14e](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/d39f14e344ef59e3a8e4f501a080ccbe1151abee))
* update readme ([0669f52](https://github.com/ScrapeGraphAI/scrapegraph-sdk/commit/0669f5219970079bbe7bde7502b4f55e5c3f5a45))
