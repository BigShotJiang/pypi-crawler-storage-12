from ...utilities.zmq.communicable.request import AnalysisRequest


class AnalysisCancel(AnalysisRequest):
    pass
