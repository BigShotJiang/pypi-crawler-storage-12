# Placeholder package
This package exists only to reserve the name **phishsage** on PyPI.
