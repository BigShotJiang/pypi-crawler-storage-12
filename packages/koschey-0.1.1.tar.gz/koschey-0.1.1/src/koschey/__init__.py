def main() -> None:
    print(
        "🪦 Koschey — internal immortal PyPI index\n"
        "--------------------------------------\n"
        "An official release will arrive soon.\n"
        "Currently, this is a placeholder while the project "
        "is being renamed and refactored from its internal version.\n\n"
        "Apologies to any brave souls who tried to run this already —\n"
        "Koschey is still gathering his strength (and dependencies)."
    )


if __name__ == "__main__":
    main()
