.. _gallery:

=======
Gallery
=======

This page contains a few specific and advanced use cases of `mmspy`. It is
still under construction. More examples to come!

.. include:: notebooks-examples-gallery.txt

.. toctree::
    :maxdepth: 1
    :hidden:

    examples/fpi-distribution
