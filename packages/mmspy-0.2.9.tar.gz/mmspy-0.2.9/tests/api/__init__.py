"""Tests for query interface in `mmsws.query`."""
