"""Provide xarray accessor for FEEPS datasets."""

__all__ = ["FeepsAccessor"]

from mmspy.configure.xarray.feeps.accessor import FeepsAccessor
