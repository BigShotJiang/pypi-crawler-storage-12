class SplatPDFGenerationFailure(Exception):
    pass
