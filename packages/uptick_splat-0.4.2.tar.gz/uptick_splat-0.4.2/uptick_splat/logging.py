import logging

metrics = logging.getLogger("metrics")
logger = logging.getLogger("splat")
