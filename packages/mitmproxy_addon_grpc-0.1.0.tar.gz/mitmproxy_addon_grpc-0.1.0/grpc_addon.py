import asyncio
import os
import sys
import mitmproxy
from mitmproxy import ctx, http
from mitmproxy.net.dns import classes
from mitmproxy.net.dns import types

from datetime import datetime

# Ensure generated protos under gen/ are on the import path.
_GEN_PATH = os.path.join(os.path.dirname(__file__), "gen")
if _GEN_PATH not in sys.path:
    sys.path.insert(0, _GEN_PATH)

import mitmproxygrpc.v1.service_pb2 as mitmproxygrpc_pb2  # noqa: E402
from mitmproxygrpc.v1.service_pb2 import ConnectionState, TransportProtocol, TLSVersion, Cert, ViaProtocol  # noqa: E402
import mitmproxygrpc.v1.service_connect as mitmflow_connect  # noqa: E402

def _to_grpc_client_conn(conn: mitmproxy.connection.Client) -> mitmproxygrpc_pb2.ClientConn:
    c = mitmproxygrpc_pb2.ClientConn()
    if conn.peername:
        c.peername_host = conn.peername[0]
        c.peername_port = conn.peername[1]
    if conn.sockname:
        c.sockname_host = conn.sockname[0]
        c.sockname_port = conn.sockname[1]
    if conn.state == mitmproxy.connection.ConnectionState.CLOSED:
        c.state = ConnectionState.CONNECTION_STATE_CLOSED
    elif conn.state == mitmproxy.connection.ConnectionState.CAN_READ:
        c.state = ConnectionState.CONNECTION_STATE_CAN_READ
    elif conn.state == mitmproxy.connection.ConnectionState.CAN_WRITE:
        c.state = ConnectionState.CONNECTION_STATE_CAN_WRITE
    elif conn.state == mitmproxy.connection.ConnectionState.OPEN:
        c.state = ConnectionState.CONNECTION_STATE_OPEN
    c.id = str(conn.id)
    if conn.transport_protocol == 'tcp':
        c.transport_protocol = TransportProtocol.TRANSPORT_PROTOCOL_TCP
    elif conn.transport_protocol == 'udp':
        c.transport_protocol = TransportProtocol.TRANSPORT_PROTOCOL_UDP
    if conn.error:
        c.error = str(conn.error)
    c.tls = conn.tls_established
    if conn.certificate_list:
        for cert in conn.certificate_list:
            c.certificate_list.append(_to_grpc_cert(cert))
    if conn.alpn:
        c.alpn = conn.alpn
    if conn.alpn_offers:
        c.alpn_offers.extend(conn.alpn_offers)
    if conn.cipher:
        c.cipher = conn.cipher
    if conn.cipher_list:
        c.cipher_list.extend(conn.cipher_list)
    if conn.tls_version:
        # Map mitmproxy TLS version string to protobuf enum
        if conn.tls_version == "TLSv1.3":
            c.tls_version = TLSVersion.TLS_VERSION_TLSV1_3
        elif conn.tls_version == "TLSv1.2":
            c.tls_version = TLSVersion.TLS_VERSION_TLSV1_2
        elif conn.tls_version == "TLSv1.1":
            c.tls_version = TLSVersion.TLS_VERSION_TLSV1_1
        elif conn.tls_version == "TLSv1":
            c.tls_version = TLSVersion.TLS_VERSION_TLSV1
        elif conn.tls_version == "SSLv3":
            c.tls_version = TLSVersion.TLS_VERSION_SSLV3
        elif conn.tls_version == "DTLSv0.9":
            c.tls_version = TLSVersion.TLS_VERSION_DTLSV0_9
        elif conn.tls_version == "DTLSv1":
            c.tls_version = TLSVersion.TLS_VERSION_DTLSV1
        elif conn.tls_version == "DTLSv1.2":
            c.tls_version = TLSVersion.TLS_VERSION_DTLSV1_2
        elif conn.tls_version == "QUICv1":
            c.tls_version = TLSVersion.TLS_VERSION_QUICV1
    if conn.sni:
        c.sni = conn.sni
    if conn.timestamp_start:
        c.timestamp_start.FromDatetime(datetime.fromtimestamp(conn.timestamp_start))
    if conn.timestamp_end:
        c.timestamp_end.FromDatetime(datetime.fromtimestamp(conn.timestamp_end))
    if conn.timestamp_tls_setup:
        c.timestamp_tls_setup.FromDatetime(datetime.fromtimestamp(conn.timestamp_tls_setup))
    c.proxy_mode = str(conn.proxy_mode) if conn.proxy_mode else ""
    return c

def _to_grpc_via(via: tuple) -> mitmproxygrpc_pb2.Via:
    v = mitmproxygrpc_pb2.Via()
    if via[0] == "http":
        v.protocol = ViaProtocol.VIA_PROTOCOL_HTTP
    elif via[0] == "https":
        v.protocol = ViaProtocol.VIA_PROTOCOL_HTTPS
    elif via[0] == "http3":
        v.protocol = ViaProtocol.VIA_PROTOCOL_HTTP3
    elif via[0] == "tls":
        v.protocol = ViaProtocol.VIA_PROTOCOL_TLS
    elif via[0] == "dtls":
        v.protocol = ViaProtocol.VIA_PROTOCOL_DTLS
    elif via[0] == "tcp":
        v.protocol = ViaProtocol.VIA_PROTOCOL_TCP
    elif via[0] == "udp":
        v.protocol = ViaProtocol.VIA_PROTOCOL_UDP
    elif via[0] == "dns":
        v.protocol = ViaProtocol.VIA_PROTOCOL_DNS
    elif via[0] == "quic":
        v.protocol = ViaProtocol.VIA_PROTOCOL_QUIC
    v.host = via[1][0]
    v.port = via[1][1]
    return v

def _to_grpc_cert(cert: mitmproxy.tls.Certificate) -> Cert:
    c = Cert()
    c.content = cert.to_pem()
    c.fingerprint = cert.fingerprint()
    for k, v in cert.issuer:
        c.issuers[k] = v
    c.notbefore.FromDatetime(cert.notbefore)
    c.notafter.FromDatetime(cert.notafter)
    c.hasexpired = cert.has_expired()
    for k, v in cert.subject:
        c.subjects[k] = v
    c.serial = str(cert.serial)
    c.is_ca = cert.is_ca
    if cert.keyinfo:
        k, v = cert.keyinfo
        if isinstance(v, int):
            c.keyinfo[k] = v
    if cert.cn:
        c.cn = cert.cn
    if cert.organization:
        c.organization = cert.organization
    if cert.altnames:
        altnames = []
        for x in cert.altnames:
            if hasattr(x, 'value'):
                value = x.value
                if isinstance(value, bytes):
                    altnames.append(value.decode('utf-8', 'replace'))
                else:
                    altnames.append(str(value))
            elif isinstance(x, bytes):
                altnames.append(x.decode('utf-8', 'replace'))
            else:
                altnames.append(str(x))
        c.altnames.extend(altnames)
    if cert.crl_distribution_points:
        crls = []
        for x in cert.crl_distribution_points:
            if isinstance(x, bytes):
                crls.append(x.decode('utf-8', 'replace'))
            else:
                crls.append(str(x))
        c.crl_distribution_points.extend(crls)
    return c

def _to_grpc_server_conn(conn: mitmproxy.connection.Server) -> mitmproxygrpc_pb2.ServerConn:
    s = mitmproxygrpc_pb2.ServerConn()
    if conn.peername:
        s.peername_host = conn.peername[0]
        s.peername_port = conn.peername[1]
    if conn.sockname:
        s.sockname_host = conn.sockname[0]
        s.sockname_port = conn.sockname[1]
    if conn.state == mitmproxy.connection.ConnectionState.CLOSED:
        s.state = ConnectionState.CONNECTION_STATE_CLOSED
    elif conn.state == mitmproxy.connection.ConnectionState.CAN_READ:
        s.state = ConnectionState.CONNECTION_STATE_CAN_READ
    elif conn.state == mitmproxy.connection.ConnectionState.CAN_WRITE:
        s.state = ConnectionState.CONNECTION_STATE_CAN_WRITE
    elif conn.state == mitmproxy.connection.ConnectionState.OPEN:
        s.state = ConnectionState.CONNECTION_STATE_OPEN
    s.id = str(conn.id)
    if conn.transport_protocol == 'tcp':
        s.transport_protocol = TransportProtocol.TRANSPORT_PROTOCOL_TCP
    elif conn.transport_protocol == 'udp':
        s.transport_protocol = TransportProtocol.TRANSPORT_PROTOCOL_UDP
    if conn.error:
        s.error = str(conn.error)
    s.tls = conn.tls_established
    if conn.certificate_list:
        for cert in conn.certificate_list:
            s.certificate_list.append(_to_grpc_cert(cert))
    if conn.alpn:
        s.alpn = conn.alpn
    if conn.alpn_offers:
        s.alpn_offers.extend(conn.alpn_offers)
    if conn.cipher:
        s.cipher = conn.cipher
    if conn.cipher_list:
        s.cipher_list.extend(conn.cipher_list)
    if conn.tls_version:
        # Map mitmproxy TLS version string to protobuf enum
        if conn.tls_version == "TLSv1.3":
            s.tls_version = TLSVersion.TLS_VERSION_TLSV1_3
        elif conn.tls_version == "TLSv1.2":
            s.tls_version = TLSVersion.TLS_VERSION_TLSV1_2
        elif conn.tls_version == "TLSv1.1":
            s.tls_version = TLSVersion.TLS_VERSION_TLSV1_1
        elif conn.tls_version == "TLSv1":
            s.tls_version = TLSVersion.TLS_VERSION_TLSV1
        elif conn.tls_version == "SSLv3":
            s.tls_version = TLSVersion.TLS_VERSION_SSLV3
        elif conn.tls_version == "DTLSv0.9":
            s.tls_version = TLSVersion.TLS_VERSION_DTLSV0_9
        elif conn.tls_version == "DTLSv1":
            s.tls_version = TLSVersion.TLS_VERSION_DTLSV1
        elif conn.tls_version == "DTLSv1.2":
            s.tls_version = TLSVersion.TLS_VERSION_DTLSV1_2
        elif conn.tls_version == "QUICv1":
            s.tls_version = TLSVersion.TLS_VERSION_QUICV1
    if conn.sni:
        s.sni = conn.sni
    if conn.timestamp_start:
        s.timestamp_start.FromDatetime(datetime.fromtimestamp(conn.timestamp_start))
    if conn.timestamp_end:
        s.timestamp_end.FromDatetime(datetime.fromtimestamp(conn.timestamp_end))
    if conn.timestamp_tls_setup:
        s.timestamp_tls_setup.FromDatetime(datetime.fromtimestamp(conn.timestamp_tls_setup))
    if conn.address:
        s.address_host = conn.address[0]
        s.address_port = conn.address[1]
    if conn.timestamp_tcp_setup:
        s.timestamp_tcp_setup.FromDatetime(datetime.fromtimestamp(conn.timestamp_tcp_setup))
    if conn.via:
        s.via.CopyFrom(_to_grpc_via(conn.via))
    return s

def to_grpc_flow(flow: http.HTTPFlow) -> mitmproxygrpc_pb2.HTTPFlow:
    f = mitmproxygrpc_pb2.HTTPFlow()
    f.id = str(flow.id)

    # Request
    f.request.method = flow.request.method
    f.request.url = flow.request.url
    f.request.pretty_url = flow.request.pretty_url
    f.request.http_version = flow.request.http_version
    f.request.timestamp_start.FromDatetime(datetime.fromtimestamp(flow.request.timestamp_start))
    if flow.request.timestamp_end:
        f.request.timestamp_end.FromDatetime(datetime.fromtimestamp(flow.request.timestamp_end))
    for k, v in flow.request.headers.items():
        f.request.headers[k] = v.encode('utf-8', 'replace').decode('utf-8')
    if flow.request.content is not None:
        f.request.content = flow.request.content
    if flow.request.trailers:
        for k, v in flow.request.trailers.items():
            f.request.trailers[k] = v.encode('utf-8', 'replace').decode('utf-8')

    # Response
    if flow.response:
        f.response.status_code = flow.response.status_code
        f.response.reason = flow.response.reason
        f.response.http_version = flow.response.http_version
        f.response.timestamp_start.FromDatetime(datetime.fromtimestamp(flow.response.timestamp_start))
        if flow.response.timestamp_end:
            f.response.timestamp_end.FromDatetime(datetime.fromtimestamp(flow.response.timestamp_end))
        for k, v in flow.response.headers.items():
            f.response.headers[k] = v.encode('utf-8', 'replace').decode('utf-8')
        if flow.response.content is not None:
            f.response.content = flow.response.content
        if flow.response.trailers:
            for k, v in flow.response.trailers.items():
                f.response.trailers[k] = v.encode('utf-8', 'replace').decode('utf-8')

    # Timestamps
    f.timestamp_start.FromDatetime(datetime.fromtimestamp(flow.timestamp_start))
    if flow.response and flow.response.timestamp_end:
        f.duration_ms = (flow.response.timestamp_end - flow.timestamp_start) * 1000

    # Connections
    if flow.client_conn:
        f.client.CopyFrom(_to_grpc_client_conn(flow.client_conn))
    if flow.server_conn:
        f.server.CopyFrom(_to_grpc_server_conn(flow.server_conn))

    # Other attributes
    if flow.error:
        f.error = str(flow.error)
    f.live = flow.live
    f.is_websocket = flow.websocket is not None

    if flow.websocket:
        for message in flow.websocket.messages:
            ws_message = mitmproxygrpc_pb2.WebSocketMessage()
            ws_message.content = message.content
            ws_message.timestamp.FromDatetime(datetime.fromtimestamp(message.timestamp))
            ws_message.from_client = message.from_client
            f.websocket_messages.append(ws_message)

    return f

def to_grpc_tcp_flow(flow: mitmproxy.tcp.TCPFlow) -> mitmproxygrpc_pb2.TCPFlow:
    f = mitmproxygrpc_pb2.TCPFlow()
    f.id = str(flow.id)

    # Connections
    if flow.client_conn:
        f.client.CopyFrom(_to_grpc_client_conn(flow.client_conn))
    if flow.server_conn:
        f.server.CopyFrom(_to_grpc_server_conn(flow.server_conn))

    # Messages
    for message in flow.messages:
        tcp_message = mitmproxygrpc_pb2.TCPMessage()
        tcp_message.content = message.content
        tcp_message.timestamp.FromDatetime(datetime.fromtimestamp(message.timestamp))
        tcp_message.from_client = message.from_client
        f.messages.append(tcp_message)

    # Timestamps
    f.timestamp_start.FromDatetime(datetime.fromtimestamp(flow.timestamp_start))
    if hasattr(flow, 'timestamp_end') and flow.timestamp_end:
        f.duration_ms = (flow.timestamp_end - flow.timestamp_start) * 1000

    # Other attributes
    if flow.error:
        f.error = str(flow.error)
    f.live = flow.live

    return f

def to_grpc_udp_flow(flow: mitmproxy.udp.UDPFlow) -> mitmproxygrpc_pb2.UDPFlow:
    f = mitmproxygrpc_pb2.UDPFlow()
    f.id = str(flow.id)

    # Connections
    if flow.client_conn:
        f.client.CopyFrom(_to_grpc_client_conn(flow.client_conn))
    if flow.server_conn:
        f.server.CopyFrom(_to_grpc_server_conn(flow.server_conn))

    # Messages
    for message in flow.messages:
        udp_message = mitmproxygrpc_pb2.UDPMessage()
        udp_message.content = message.content
        udp_message.timestamp.FromDatetime(datetime.fromtimestamp(message.timestamp))
        udp_message.from_client = message.from_client
        f.messages.append(udp_message)

    # Timestamps
    f.timestamp_start.FromDatetime(datetime.fromtimestamp(flow.timestamp_start))
    if hasattr(flow, 'timestamp_end') and flow.timestamp_end:
        f.duration_ms = (flow.timestamp_end - flow.timestamp_start) * 1000

    # Other attributes
    if flow.error:
        f.error = str(flow.error)
    f.live = flow.live

    return f

def _to_grpc_dns_question(q: mitmproxy.dns.Question) -> mitmproxygrpc_pb2.DNSQuestion:
    msg = mitmproxygrpc_pb2.DNSQuestion(
        name=q.name,
        type=types.to_str(q.type),
    )
    setattr(msg, 'class', classes.to_str(q.class_))
    return msg


def _to_grpc_dns_resource_record(rr: mitmproxy.dns.ResourceRecord) -> mitmproxygrpc_pb2.DNSResourceRecord:
    msg = mitmproxygrpc_pb2.DNSResourceRecord(
        name=rr.name,
        type=types.to_str(rr.type),
        ttl=rr.ttl,
        data=rr.data,
    )
    setattr(msg, 'class', classes.to_str(rr.class_))
    return msg


def _to_grpc_dns_message(msg: mitmproxy.dns.DNSMessage) -> mitmproxygrpc_pb2.DNSMessage:
    return mitmproxygrpc_pb2.DNSMessage(
        packed=msg.content,
        questions=[_to_grpc_dns_question(q) for q in msg.questions],
        answers=[_to_grpc_dns_resource_record(rr) for rr in msg.answers],
        authorities=[_to_grpc_dns_resource_record(rr) for rr in msg.authorities],
        additionals=[_to_grpc_dns_resource_record(rr) for rr in msg.additionals],
        id=msg.id,
        query=msg.query,
        op_code=msg.op_code,
        authoritative_answer=msg.authoritative_answer,
    )


def to_grpc_dns_flow(flow: mitmproxy.dns.DNSFlow) -> mitmproxygrpc_pb2.DNSFlow:
    f = mitmproxygrpc_pb2.DNSFlow()
    f.id = str(flow.id)

    if flow.request:
        f.request.CopyFrom(_to_grpc_dns_message(flow.request))

    if flow.response:
        f.response.CopyFrom(_to_grpc_dns_message(flow.response))

    f.timestamp_start.FromDatetime(datetime.fromtimestamp(flow.timestamp_start))

    if flow.client_conn:
        f.client.CopyFrom(_to_grpc_client_conn(flow.client_conn))
    if flow.server_conn:
        f.server.CopyFrom(_to_grpc_server_conn(flow.server_conn))

    if flow.error:
        f.error = str(flow.error)
    f.live = flow.live

    return f


class MitmFlowAddon:
    def __init__(self):
        self.flowclient = None
        self.queue = asyncio.Queue()
        self.export_task = None
        self.event_types = []
        self.allowed_events = {
            "all", "requestheaders", "response", "responseheaders", "error",
            "http_connect", "http_connect_upstream", "http_connected", "http_connect_error",
            "dns_request", "dns_response", "dns_error",
            "tcp_start", "tcp_message", "tcp_end", "tcp_error",
            "udp_start", "udp_message", "udp_end", "udp_error",
            "websocket_start", "websocket_message", "websocket_end",
        }

    def load(self, loader):
        loader.add_option(
            name="grpc_addr",
            typespec=str,
            default="http://127.0.0.1:50051",
            help="Address of the gRPC server",
        )
        loader.add_option(
            name="grpc_events",
            typespec=str,
            default="all",
            help="Comma-separated list of event types to emit (e.g., request,response)",
        )

    def running(self):
        self.flowclient = mitmflow_connect.ServiceClient(ctx.options.grpc_addr)
        self.export_task = asyncio.create_task(self._export_flows())
        self._update_events()

    def configure(self, updates):
        if "grpc_events" in updates:
            self._update_events()

    def _update_events(self):
        events = ctx.options.grpc_events.split(',')
        valid_events = []
        for event in [e.strip() for e in events]:
            if event in self.allowed_events:
                valid_events.append(event)
            else:
                ctx.log.warn(f"Invalid gRPC event type: {event}")
        self.event_types = valid_events

    def _is_event_enabled(self, event_type: str) -> bool:
        return "all" in self.event_types or event_type in self.event_types

    async def _export_flows(self):
        async def flow_generator():
            while True:
                req = await self.queue.get()
                if req is None:
                    break
                yield req

        while True:
            try:
                # connectrpc expects the request as an async iterator
                response = await self.flowclient.export_flow(flow_generator())
                ctx.log.info(f"Export response: {getattr(response, 'message', response)}")
                break  # a successful response means the stream is closed
            except Exception as e:
                # Print more details for debugging
                import traceback
                ctx.log.error(f"Export failed: {e!r}\n{traceback.format_exc()}")
                await asyncio.sleep(5)  # wait before retrying

    async def requestheaders(self, flow: mitmproxy.http.HTTPFlow):
        if not self._is_event_enabled("requestheaders"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_REQUESTHEADERS,
            flow=mitmproxygrpc_pb2.Flow(http_flow=to_grpc_flow(flow)),
        ))

    async def response(self, flow: http.HTTPFlow):
        if not self._is_event_enabled("response"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_RESPONSE,
            flow=mitmproxygrpc_pb2.Flow(http_flow=to_grpc_flow(flow)),
        ))

    async def responseheaders(self, flow: mitmproxy.http.HTTPFlow):
        if not self._is_event_enabled("responseheaders"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_RESPONSEHEADERS,
            flow=mitmproxygrpc_pb2.Flow(http_flow=to_grpc_flow(flow)),
        ))

    async def error(self, flow: mitmproxy.http.HTTPFlow):
        if not self._is_event_enabled("error"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_ERROR,
            flow=mitmproxygrpc_pb2.Flow(http_flow=to_grpc_flow(flow)),
        ))

    async def http_connect(self, flow: mitmproxy.http.HTTPFlow):
        if not self._is_event_enabled("http_connect"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_HTTP_CONNECT,
            flow=mitmproxygrpc_pb2.Flow(http_flow=to_grpc_flow(flow)),
        ))

    async def http_connect_upstream(self, flow: mitmproxy.http.HTTPFlow):
        if not self._is_event_enabled("http_connect_upstream"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_HTTP_CONNECT_UPSTREAM,
            flow=mitmproxygrpc_pb2.Flow(http_flow=to_grpc_flow(flow)),
        ))

    async def http_connected(self, flow: mitmproxy.http.HTTPFlow):
        if not self._is_event_enabled("http_connected"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_HTTP_CONNECTED,
            flow=mitmproxygrpc_pb2.Flow(http_flow=to_grpc_flow(flow)),
        ))

    async def http_connect_error(self, flow: mitmproxy.http.HTTPFlow):
        if not self._is_event_enabled("http_connect_error"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_HTTP_CONNECT_ERROR,
            flow=mitmproxygrpc_pb2.Flow(http_flow=to_grpc_flow(flow)),
        ))

    async def dns_request(self, flow: mitmproxy.dns.DNSFlow):
        if not self._is_event_enabled("dns_request"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_DNS_REQUEST,
            flow=mitmproxygrpc_pb2.Flow(dns_flow=to_grpc_dns_flow(flow)),
        ))
        
    async def dns_response(self, flow: mitmproxy.dns.DNSFlow):
        if not self._is_event_enabled("dns_response"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_DNS_RESPONSE,
            flow=mitmproxygrpc_pb2.Flow(dns_flow=to_grpc_dns_flow(flow)),
        ))

    async def dns_error(self, flow: mitmproxy.dns.DNSFlow):
        if not self._is_event_enabled("dns_error"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_DNS_ERROR,
            flow=mitmproxygrpc_pb2.Flow(dns_flow=to_grpc_dns_flow(flow)),
        ))

    async def tcp_start(self, flow: mitmproxy.tcp.TCPFlow):
        if not self._is_event_enabled("tcp_start"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_TCP_START,
            flow=mitmproxygrpc_pb2.Flow(tcp_flow=to_grpc_tcp_flow(flow)),
        ))

    async def tcp_message(self, flow: mitmproxy.tcp.TCPFlow):
        if not self._is_event_enabled("tcp_message"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_TCP_MESSAGE,
            flow=mitmproxygrpc_pb2.Flow(tcp_flow=to_grpc_tcp_flow(flow)),
        ))

    async def tcp_end(self, flow: mitmproxy.tcp.TCPFlow):
        if not self._is_event_enabled("tcp_end"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_TCP_END,
            flow=mitmproxygrpc_pb2.Flow(tcp_flow=to_grpc_tcp_flow(flow)),
        ))

    async def tcp_error(self, flow: mitmproxy.tcp.TCPFlow):
        if not self._is_event_enabled("tcp_error"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_TCP_ERROR,
            flow=mitmproxygrpc_pb2.Flow(tcp_flow=to_grpc_tcp_flow(flow)),
        ))

    async def udp_start(self, flow: mitmproxy.udp.UDPFlow):
        if not self._is_event_enabled("udp_start"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_UDP_START,
            flow=mitmproxygrpc_pb2.Flow(udp_flow=to_grpc_udp_flow(flow)),
        ))

    async def udp_message(self, flow: mitmproxy.udp.UDPFlow):
        if not self._is_event_enabled("udp_message"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_UDP_MESSAGE,
            flow=mitmproxygrpc_pb2.Flow(udp_flow=to_grpc_udp_flow(flow)),
        ))

    async def udp_end(self, flow: mitmproxy.udp.UDPFlow):
        if not self._is_event_enabled("udp_end"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_UDP_END,
            flow=mitmproxygrpc_pb2.Flow(udp_flow=to_grpc_udp_flow(flow)),
        ))

    async def udp_error(self, flow: mitmproxy.udp.UDPFlow):
        if not self._is_event_enabled("udp_error"):
            return
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_UDP_ERROR,
            flow=mitmproxygrpc_pb2.Flow(udp_flow=to_grpc_udp_flow(flow)),
        ))

    async def quic_start_client(self, data: mitmproxy.proxy.layers.quic._hooks.QuicTlsData):
        pass

    async def quic_start_server(self, data: mitmproxy.proxy.layers.quic._hooks.QuicTlsData):
        pass

    async def tls_clienthello(self, data: mitmproxy.tls.ClientHelloData):
        pass

    async def tls_start_client(self, data: mitmproxy.tls.TlsData):
        pass

    async def tls_start_server(self, data: mitmproxy.tls.TlsData):
        pass

    async def tls_established_client(self, data: mitmproxy.tls.TlsData):
        pass

    async def tls_established_server(self, data: mitmproxy.tls.TlsData):
        pass

    async def tls_failed_client(self, data: mitmproxy.tls.TlsData):
        pass

    async def tls_failed_server(self, data: mitmproxy.tls.TlsData):
        pass

    async def websocket_start(self, flow: mitmproxy.http.HTTPFlow):
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_WEBSOCKET_START,
            flow=mitmproxygrpc_pb2.Flow(http_flow=to_grpc_flow(flow)),
        ))

    async def websocket_message(self, flow: mitmproxy.http.HTTPFlow):
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_WEBSOCKET_MESSAGE,
            flow=mitmproxygrpc_pb2.Flow(http_flow=to_grpc_flow(flow)),
        ))

    async def websocket_end(self, flow: mitmproxy.http.HTTPFlow):
        await self.queue.put(mitmproxygrpc_pb2.ExportFlowRequest(
            event_type=mitmproxygrpc_pb2.EVENT_TYPE_WEBSOCKET_END,
            flow=mitmproxygrpc_pb2.Flow(http_flow=to_grpc_flow(flow)),
        ))

    async def socks5_auth(self, data: mitmproxy.proxy.layers.modes.Socks5AuthData):
        pass


    async def done(self):
        """
        Called when the addon is shutting down.
        """
        await self.queue.put(None)
        await self.export_task
        await self.flowclient.close()

addons = [
    MitmFlowAddon()
]
