.. _papers-using-lenskit:

Papers using LensKit
====================

This page lists known papers using the Python version of LensKit.  If you use
LensKit for research, please e-mail Michael Ekstrand <ekstrand@acm.org> with a
copy of your paper and bibliographic information so we can add it to this list.

.. raw:: html

    <script src="https://bibbase.org/show?bib=https%3A%2F%2Fapi.zotero.org%2Fusers%2F6655%2Fcollections%2F3TB3KT36%2Fitems%3Fkey%3DVFvZhZXIoHNBbzoLZ1IM2zgf%26format%3Dbibtex%26limit%3D100&jsonp=1"></script>
