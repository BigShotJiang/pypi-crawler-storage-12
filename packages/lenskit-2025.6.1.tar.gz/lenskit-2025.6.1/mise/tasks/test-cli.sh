#!/usr/bin/env bash
#MISE description="Run CLI tests"

exec ./tests/cli/run.sh "$@"
