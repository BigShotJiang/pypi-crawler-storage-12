run-lenskit doctor

run-lenskit doctor --packages --paths
