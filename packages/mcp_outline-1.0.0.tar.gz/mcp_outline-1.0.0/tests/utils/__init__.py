"""
Test utilities for mcp-outline.
"""
