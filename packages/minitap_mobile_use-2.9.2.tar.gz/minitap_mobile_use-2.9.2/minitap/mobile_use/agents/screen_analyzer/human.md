## Task

Analyze the provided screenshot and answer the following specific question:

{{ prompt }}

## Instructions

1. Look carefully at the screenshot
2. Provide a concise, direct answer to the question
3. Focus only on what is visible in the screenshot
4. Be specific and factual

## Output

Provide your analysis as a clear, concise text response.
