===
Baz
===

The baz is a specialized :ref:`bar` with more than one pim.  Keep in
mind that it is not a simple :ref:`bar`, but a specialized :ref:`bar`!


**Pages referring to this:**

.. refstothis::

