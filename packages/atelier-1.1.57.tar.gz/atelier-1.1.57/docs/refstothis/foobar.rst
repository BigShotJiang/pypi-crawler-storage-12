=============
Foos and Bars
=============

This document defines Foo_ and Bar_, while :doc:`baz` is definied in a
separate document.

.. _foo:

Foo
===

A foo is a nob that has been attached to a sib.

**Pages referring to this:**

.. refstothis:: foo



.. _bar:

Bar
===

A bar is a nob that has been attached to a :ref:`foo`.

**Pages referring to this:**

.. refstothis:: bar


