from rstgen.sphinxconf import configure

configure(globals())
