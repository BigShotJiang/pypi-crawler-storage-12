from setuptools import setup
if __name__ == '__main__':
    setup(name='foo', version='1.0.0')
