from setuptools import setup

setup(name='foo', version='1.0.0')
