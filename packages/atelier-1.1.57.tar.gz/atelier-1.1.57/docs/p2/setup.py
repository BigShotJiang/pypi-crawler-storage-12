from setuptools import setup

SETUP_INFO = dict(name='foo', version='1.0.0')
if __name__ == '__main__':
    setup(**SETUP_INFO)
