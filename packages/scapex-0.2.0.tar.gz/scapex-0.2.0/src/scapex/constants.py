"""Defines constants across modules"""

APPLICATION_NAME = "ScapeX"
PACKAGE_NAME = "scapex"
