if __name__ == '__main__':  # pragma: nocover
    from . import DyngleApp
    DyngleApp.main()
