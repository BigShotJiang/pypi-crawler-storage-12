class PlanStats:
    def __init__(self):
        self.stats = []

    def add_stat(self, stat):
        self.stats.append(stat)