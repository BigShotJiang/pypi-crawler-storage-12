# Kitty Escape
`pip install kitty-escape && kitty-escape`

* `ctrl-C`: quit current screen
* `ESC`: reset view
* `F11`: fullscreen

Interact with the room by clicking. Input characters by typing them.

Hint: how many walls does a room have?
