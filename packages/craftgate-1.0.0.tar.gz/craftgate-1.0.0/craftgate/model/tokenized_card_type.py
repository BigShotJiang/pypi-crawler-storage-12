from enum import Enum


class TokenizedCardType(str, Enum):
    APPLE_PAY = "APPLE_PAY"
