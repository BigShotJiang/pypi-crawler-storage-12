from enum import Enum


class ReportPeriod(str, Enum):
    INSTANT = "INSTANT"
