from enum import Enum


class BankAccountTrackingSource(str, Enum):
    YKB = "YKB"
    GARANTI = "GARANTI"
