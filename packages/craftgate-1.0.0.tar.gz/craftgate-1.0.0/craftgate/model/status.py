from enum import Enum


class Status(str, Enum):
    PASSIVE = "PASSIVE"
    ACTIVE = "ACTIVE"
