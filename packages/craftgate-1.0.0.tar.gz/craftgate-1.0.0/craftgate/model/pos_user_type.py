from enum import Enum


class PosUserType(str, Enum):
    API = "API"
