from enum import Enum


class ReportFileType(str, Enum):
    CSV = "CSV"
    XLSX = "XLSX"
