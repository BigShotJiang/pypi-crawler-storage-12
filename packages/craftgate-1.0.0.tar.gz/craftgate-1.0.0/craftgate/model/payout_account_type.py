from enum import Enum


class PayoutAccountType(str, Enum):
    WISE = "WISE"
