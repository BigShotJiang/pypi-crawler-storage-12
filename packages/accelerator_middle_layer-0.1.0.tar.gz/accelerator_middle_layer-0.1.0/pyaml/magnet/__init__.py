"""
PyAML Magnet module
"""

