PART_EXAMPLES_PROMPT = """
## Examples:

### Example Input:
{example_input}

### Example Output:
{example_output}
"""
