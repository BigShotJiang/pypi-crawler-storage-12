PART_INPUT_PROMPT = """
## Input:

{question}

## Answer:
"""
