src_0_en = [
    "Have you noticed how accurate",
    "LLM are now that GPU have became more powerful, ",
    "especially when we think at the difficulties we had in the 2010 era",
    "where online chatbots were not performant",
    "at all, and ofter doing strict rules worked better",
    "do you remember that era?"]

src_0_fr = [
    "As-tu remarqué à quel point",
    "les LLM sont précis maintenant que les GPU sont devenus plus puissants, ",
    "surtout quand on pense aux difficultés qu'on avait dans les années 2010",
    "où les chatbots en ligne n'étaient pas performants",
    "du tout, et souvent faire des règles strictes fonctionnait mieux.",
    "Tu te souviens de cette époque, ",
    "c'était bien plus compliqué de travailler"]

src_1_fr = ["Il s’arrêtait par moments devant une villa",
    "coquettement nichée dans la verdure, il regardait",
    "par la grille et voyait au loin des femmes",
    "élégantes sur les balcons et les terrasses, des",
    "enfants couraient dans les jardins. Il s’intéressait",
    "surtout aux fleurs ; c’étaient elles qui attiraient",
    "particulièrement ses regards. De temps en temps,"
    "il voyait passer des cavaliers, des amazones et de"
    "belles voitures ; il les suivait d’un œil curieux et",
    "les oubliait avant qu’ils eussent disparu. "]

src_1_en = ["He would stop occasionally in front of a villa",
    "nestled charmingly in the greenery, look",
    "through the gate, and see elegant women",
    "on balconies and terraces in the distance,",
    "children running in the gardens. He was particularly interested",
    "in the flowers; they were what caught his eye. From time to time,", 
    "he would see horsemen, horsewomen, and beautiful carriages passing by;",
    "he would follow them with a curious eye and",
    "forget them before they had disappeared.",
    ]

src_2_fr = [
    "Il s'arrêtait par moments devant une villa",
    "coquettement nichée dans la verdure, il regardait",
    "par la grille et voyait au loin des femmes",
    "élégantes sur les balcons et les terrasses, des",
    "enfants couraient dans les jardins. Il s'intéressait",
    "surtout aux fleurs ; c'étaient elles qui attiraient",
    "particulièrement ses regards. De temps en temps,",
    "il voyait passer des cavaliers, des amazones et de",
    "belles voitures ; il les suivait d'un œil curieux et",
    "les oubliait avant qu'ils eussent disparu. ",
    "Une fois, il s'arrêta et compta son argent ; il",
    "lui restait trente kopecks : « vingt au sergent de",
    "ville, trois à Nastassia pour la lettre, j'en ai donc",
    "donné hier à Marmeladov quarante-sept ou",
    "cinquante », se dit-il. Il devait avoir une raison de",
    "calculer ainsi, mais il l'oublia en tirant l'argent de",
    "sa poche et ne s'en souvint qu'un peu plus tard en",
    "passant devant un marchand de comestibles, une",
    "sorte de gargote plutôt ; il sentit alors qu'il avait",
    "faim. "
]


src_3_fr = ["Ceci est un test de traduction avec un point. On se demande à quel point tout cela va bien fonctionner haha"]