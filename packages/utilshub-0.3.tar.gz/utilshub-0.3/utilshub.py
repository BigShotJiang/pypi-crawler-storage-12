import pandas as pd
import numpy as py
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

df = pd.read_csv("Iris_Dataset.csv")

df.head()

df.tail()

df.shape

num_col = df.select_dtypes(include = ['number']).columns
cat_col = df.select_dtypes(include = ['object']).columns
print("Num COL:", len(num_col))
print("Cat COL:", len(cat_col))

print(df[num_col].describe()) 

df[num_col].mode()

print(df.isnull().sum())

plt.boxplot(df[num_col].corr(),showfliers = False)
plt.show()

z_score = stats.zscore(df[num_col])
outliers = (abs(z_score)>3)
print(df[outliers.any(axis=1)])

corr_matrix = df[num_col].corr()
print("High corr : " , corr_matrix > 0.7)

print("Negative corr : " , corr_matrix < 0.7)

print("No corr : " , corr_matrix[(corr_matrix < -0.1) & (corr_matrix>0.1)])

skew = df[num_col]
print("Right Skew:", skew>0.5)

skew = df[num_col]
print("Left Skew:", skew < 0.5)

print("No Skew:", skew)

df[cat_col].value_counts().plot(kind='bar')
plt.xlabel('Category')
plt.ylabel('Count')
plt.title(f'Bar Plot of {cat_col}')
plt.show()


sns.swarmplot(x=df['SepalLengthCm'])
plt.title('Swarm Plot of SepalLengthCm')
plt.xlabel('SepalLengthCm')
plt.show()

sns.violinplot(x=df['SepalLengthCm'])
plt.title('Violin Plot of SepalLengthCm')
plt.xlabel('SepalLengthCm')
plt.show()

plt.scatter(df['SepalLengthCm'], df['SepalWidthCm'])
plt.xlabel('SepalLengthCm')
plt.ylabel('SepalWidthCm')
plt.title('Scatter Plot: SepalLengthCm vs SepalWidthCm')
plt.show()

cat_col = 'Species'
num_col = 'SepalLengthCm'
sns.boxplot(x=df[cat_col], y=df[num_col])
plt.title(f'Boxplot of {num_col} across {cat_col}')
plt.xlabel(cat_col)
plt.ylabel(num_col)
plt.xticks(rotation=45)
plt.show()


sns.countplot(x = df[cat_col])
plt.xlabel("spices")
plt.ylabel("count")
plt.show


sns.pairplot(df, hue='Species')
plt.show()


def display_code():
    with open(__file__, 'r') as f:
        code = f.read()
    print(code)