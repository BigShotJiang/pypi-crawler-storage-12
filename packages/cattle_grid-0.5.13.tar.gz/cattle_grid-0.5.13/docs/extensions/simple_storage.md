::: cattle_grid.extensions.examples.simple_storage
    options:
        heading_level: 1
        show_submodules: true
