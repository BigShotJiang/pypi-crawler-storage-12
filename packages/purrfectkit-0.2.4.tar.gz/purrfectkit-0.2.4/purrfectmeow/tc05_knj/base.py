class Kornja:
    @classmethod
    def generating(cls) -> None:
        pass
