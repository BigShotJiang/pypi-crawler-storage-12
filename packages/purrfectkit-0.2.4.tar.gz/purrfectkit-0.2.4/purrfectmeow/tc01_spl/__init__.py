from .base import Suphalak

__all__ = ['Suphalak']
