# Data

Static data and assets used by the package (keep small; large assets belong elsewhere).
