本框架採用 [MIT](https://opensource.org/licenses/MIT) 授權條款，其知識庫設計理念參考 [MITRE ATT&CK®](https://attack.mitre.org)。
