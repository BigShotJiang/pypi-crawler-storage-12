from .main import cli as main

if __name__ == "__main__":
    main()  # pylint: disable=no-value-for-parameter
