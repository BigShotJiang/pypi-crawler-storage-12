.. _general_examples:

Example Gallery
===============

Introductory examples.
