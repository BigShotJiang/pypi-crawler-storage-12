'''
Outdated file from an outdated project architecture
But ... constant still used 

TODO: move to rstt.config.py
+ doc
+ suited refactoring in ranking.standard and ranking.rating

'''


# elo
DEFAULT_ELO = 1500.0

# glicko
GLICKO_MEAN = 1500.0
GLICKO_VAR = 250.0

# glicko2
GLICKO2_MEAN = 1500.0
GLICKO2_VAR = 250.0
GLICKO2_VOLATILITY = 50.0
