import os
version = version = os.environ.get('VERSION_FRAMEWORK', "2.0.0")
