=================================
project put
=================================

Description
=================================
プロジェクトを作成します。

.. warning::
   
   このコマンドは非推奨です。代わりに :doc:`create` コマンドを使用してください。
   
   ``project put`` コマンドは2026年01月01日以降に廃止予定です。


詳細な使用方法は :doc:`create` コマンドのドキュメントを参照してください。
コマンドライン引数の使い方は :doc:`create` コマンドと同じです。


Usage Details
=================================

.. argparse::
   :ref: annofabcli.project.put_project.add_parser
   :prog: annofabcli project put
   :nosubcommands:
   :nodefaultconst:
