==========================================
line-graph/折れ線-横軸_日-全体.html
==========================================


タスク数や作業時間、生産性などを、日毎にプロットした折れ線グラフです。日毎のタスク数や作業時間、生産性などをの推移が分かります。

グラフのデータは :doc:`日毎の生産量と生産性_csv` を参照しています。




.. image:: ../visualize/img/日ごとのタスク数と作業時間.png

.. image:: ../visualize/img/日ごとのアノテーションあたり作業時間.png


`折れ線-横軸_日-全体.htmlのサンプル <https://kurusugawa-computer.github.io/annofab-cli/command_reference/statistics/visualize/out_dir/line-graph/%E6%8A%98%E3%82%8C%E7%B7%9A-%E6%A8%AA%E8%BB%B8_%E6%97%A5-%E5%85%A8%E4%BD%93.html>`_
