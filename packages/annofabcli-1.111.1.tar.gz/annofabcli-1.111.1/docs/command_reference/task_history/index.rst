==================================================
task_history
==================================================

Description
=================================
タスク履歴関係のコマンドです。


Available Commands
=================================


.. toctree::
   :maxdepth: 1
   :titlesonly:

   download
   list
   list_all

Usage Details
=================================

.. argparse::
   :ref: annofabcli.task_history.subcommand_task_history.add_parser
   :prog: annofabcli task_history
   :nosubcommands:
