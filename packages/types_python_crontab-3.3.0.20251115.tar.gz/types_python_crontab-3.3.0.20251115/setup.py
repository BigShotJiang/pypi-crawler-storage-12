
from setuptools import setup

setup(package_data={'crontab-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed'], 'crontabs-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed'], 'cronlog-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
