"""Terminal UI models."""

from xp.models.term.protocol_keys_config import (
    ProtocolKeyConfig,
    ProtocolKeysConfig,
)

__all__ = [
    "ProtocolKeyConfig",
    "ProtocolKeysConfig",
]
