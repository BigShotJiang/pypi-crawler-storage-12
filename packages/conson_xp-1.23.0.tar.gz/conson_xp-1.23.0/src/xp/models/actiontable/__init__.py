"""Action table models for XP protocol."""
