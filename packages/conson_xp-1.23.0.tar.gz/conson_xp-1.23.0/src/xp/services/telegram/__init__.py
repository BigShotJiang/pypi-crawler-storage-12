"""Telegram parsing and processing services."""
