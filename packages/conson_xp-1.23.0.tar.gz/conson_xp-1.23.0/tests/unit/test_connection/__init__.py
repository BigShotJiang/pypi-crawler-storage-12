"""Unit tests for connection handling."""
