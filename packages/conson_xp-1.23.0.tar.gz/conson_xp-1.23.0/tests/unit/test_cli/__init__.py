"""Unit tests for CLI commands."""
