class MaximumMetricReached(RuntimeError):
    pass
