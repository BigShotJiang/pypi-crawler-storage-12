# akimgreceiver

Simple image receiver utility:

Waits for a `frame.png` file in a folder, reads it as an OpenCV image, deletes it, and returns the image.

## Installation (local test)

```bash
pip install .
