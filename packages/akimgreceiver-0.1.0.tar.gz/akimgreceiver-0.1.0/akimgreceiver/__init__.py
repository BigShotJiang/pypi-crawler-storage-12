from .core import receive_image

__all__ = ["receive_image"]
