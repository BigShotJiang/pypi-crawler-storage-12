from ._AimTTi_PL_P import AimTTi


class AimTTiPL303P(AimTTi):
    """
    This is the QCoDeS driver for the Aim TTi PL303-P series power supply.
    """

    pass
