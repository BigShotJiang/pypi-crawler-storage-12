from ._AimTTi_PL_P import AimTTi


class AimTTiQL355TP(AimTTi):
    """
    This is the QCoDeS driver for the Aim TTi QL355TP series power supply.
    """

    pass
