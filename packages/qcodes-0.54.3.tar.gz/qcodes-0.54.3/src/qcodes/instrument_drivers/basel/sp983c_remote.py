"""
Legacy module kept around for backwards compatibility reasons.
Will eventually be deprecated and removed

"""

from .BaselSP983a import BaselSP983a as SP983A
