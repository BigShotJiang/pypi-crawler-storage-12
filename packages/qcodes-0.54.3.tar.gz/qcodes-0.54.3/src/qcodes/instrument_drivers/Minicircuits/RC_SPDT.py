from ._minicircuits_rc_spdt import MiniCircuitsRCSPDT, MiniCircuitsRCSPDTChannel

MC_channel = MiniCircuitsRCSPDTChannel
"""
Alias for backwards compatibility
"""


RC_SPDT = MiniCircuitsRCSPDT
"""
Alias for backwards compatibility
"""
