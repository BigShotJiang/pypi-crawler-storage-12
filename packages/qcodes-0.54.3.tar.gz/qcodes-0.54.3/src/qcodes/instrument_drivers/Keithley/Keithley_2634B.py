from ._Keithley_2600 import Keithley2600


class Keithley2634B(Keithley2600):
    """
    QCoDeS driver for the Keithley 2634B Source-Meter
    """

    pass
