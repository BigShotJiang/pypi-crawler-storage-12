from ._Keithley_2600 import Keithley2600


class Keithley2612B(Keithley2600):
    """
    QCoDeS driver for the Keithley 2612B Source-Meter
    """

    pass
