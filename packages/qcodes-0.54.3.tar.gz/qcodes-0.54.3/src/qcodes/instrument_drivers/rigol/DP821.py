"""
Old alias for RigolDP821 for backwards compatibility.
Will eventually be deprecated and removed.
"""

from .Rigol_DP821 import RigolDP821
