"""
Old alias for RigolDP831 for backwards compatibility.
Will eventually be deprecated and removed.
"""

from .Rigol_DP831 import RigolDP831
