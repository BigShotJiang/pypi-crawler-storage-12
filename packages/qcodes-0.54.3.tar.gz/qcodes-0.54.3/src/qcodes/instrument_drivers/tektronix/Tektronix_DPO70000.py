from .DPO7200xx import TektronixDPO7000xx


class TektronixDPO70000(TektronixDPO7000xx):
    """
    QCoDeS driver for Tektronix DPO70000 Digital Oscilloscopes
    """
