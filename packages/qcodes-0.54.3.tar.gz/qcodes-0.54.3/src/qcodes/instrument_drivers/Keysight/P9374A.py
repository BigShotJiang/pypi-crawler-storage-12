from .Keysight_P9374A import KeysightP9374A


class P9374A(KeysightP9374A):
    """
    Alias for backwards compatibility.
    """
