from .Keysight_N5230C import KeysightN5230C


class N5230C(KeysightN5230C):
    """
    Alias for backwards compatibility
    """
