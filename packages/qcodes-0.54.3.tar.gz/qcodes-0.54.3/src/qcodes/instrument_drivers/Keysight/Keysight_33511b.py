from .KeysightAgilent_33XXX import Keysight33xxxSingleChannel


class Keysight33511B(Keysight33xxxSingleChannel):
    """
    QCoDeS driver for the Keysight 33511B waveform generator.
    """
