# Ensuring backwards compatibility

from .ZNB import RohdeSchwarzZNBBase

ZNB20 = RohdeSchwarzZNBBase
