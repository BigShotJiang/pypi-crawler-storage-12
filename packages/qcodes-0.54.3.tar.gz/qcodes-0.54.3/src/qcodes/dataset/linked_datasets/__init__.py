"""
This module contains the code used to generate the edges that link different
datasets together
"""
