function renderPanel() {
  return 'Hello from Jsonnet';
}
