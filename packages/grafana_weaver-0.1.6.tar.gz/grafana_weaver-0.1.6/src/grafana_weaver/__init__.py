"""Grafana-Weaver: Manage Grafana dashboards as code using Jsonnet."""

__version__ = "0.1.0"
