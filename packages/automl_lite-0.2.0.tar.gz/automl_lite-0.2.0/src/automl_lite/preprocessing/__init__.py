"""Preprocessing functionality for AutoML Lite."""

from .pipeline import PreprocessingPipeline

__all__ = ["PreprocessingPipeline"] 