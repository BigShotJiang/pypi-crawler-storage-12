"""Command-line interface for AutoML Lite."""

from .main import main

__all__ = ["main"] 