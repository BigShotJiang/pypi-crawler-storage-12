`nuitka_plus` is a small utility to load a lot of arguments into Nuitka in the form of a JSON file.

This is to get around argument limits on Windows 10.