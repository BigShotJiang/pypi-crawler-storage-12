"""Utility modules for the RLang compiler."""

from rlang.utils.canonical_json import canonical_dumps

__all__ = ["canonical_dumps"]

