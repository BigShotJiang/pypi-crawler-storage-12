"""Data package for shotgrid_mcp_server."""
