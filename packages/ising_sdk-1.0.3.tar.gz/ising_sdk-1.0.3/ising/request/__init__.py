from .GeneralTaskCreateRequest import GeneralTaskCreateRequest
from .TemplateTaskCreateRequest import TemplateTaskCreateRequest

__all__ = ['GeneralTaskCreateRequest', 'TemplateTaskCreateRequest']