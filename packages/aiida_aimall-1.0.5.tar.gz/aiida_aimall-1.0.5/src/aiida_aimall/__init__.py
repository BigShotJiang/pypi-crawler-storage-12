"""Integration of AIMQB and aiida
"""

__version__ = "1.0.5"
