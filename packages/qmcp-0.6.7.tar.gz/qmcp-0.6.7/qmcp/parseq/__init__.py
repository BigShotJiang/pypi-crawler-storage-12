# ParseQ package
from .parseq import translate