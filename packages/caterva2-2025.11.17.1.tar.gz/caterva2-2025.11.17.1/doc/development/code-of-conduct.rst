.. include:: ../../code_of_conduct.md
   :parser: myst_parser.sphinx_
