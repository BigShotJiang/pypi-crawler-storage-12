from ._base_enum import BaseEnum


class SERCode(BaseEnum):
    MAJOR = "MAJOR"
    MINOR = "MINOR"
    NONE = "NONE"
    NULL = None
