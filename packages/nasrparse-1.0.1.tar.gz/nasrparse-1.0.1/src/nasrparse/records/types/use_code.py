from nasrparse.records.types._base_enum import BaseEnum


class UseCode(BaseEnum):
    PUBLIC = "PU"
    PRIVATE = "PR"
    NULL = None
