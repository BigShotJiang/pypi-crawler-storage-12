from ._base_enum import BaseEnum


class WeatherStationCode(BaseEnum):
    WXL = "WXL"
    NULL = None
