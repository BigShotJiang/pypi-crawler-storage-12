from ._base_enum import BaseEnum


class GSTypeCode(BaseEnum):
    GLIDE_SLOPE = "GLIDE SLOPE"
    GLIDE_SLOPE_DME = "GLIDE SLOPE/DME"
    NULL = None
