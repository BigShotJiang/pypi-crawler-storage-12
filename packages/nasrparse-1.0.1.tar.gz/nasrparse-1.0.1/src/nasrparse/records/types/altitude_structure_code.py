from ._base_enum import BaseEnum


class AltitudeStructureCode(BaseEnum):
    HIGH = "HIGH"
    LOW = "LOW"
    UNLIMITED = "UNLIMITED"
    NULL = None
