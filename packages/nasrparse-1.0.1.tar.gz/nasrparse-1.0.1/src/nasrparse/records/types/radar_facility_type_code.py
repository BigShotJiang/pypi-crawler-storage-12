from ._base_enum import BaseEnum


class RadarFacilityTypeCode(BaseEnum):
    AIRPORT = "AIRPORT"
    TRACON = "TRACON"
    NULL = None
