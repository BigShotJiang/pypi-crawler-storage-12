from ._base_enum import BaseEnum


class MagVarCode(BaseEnum):
    EAST = "E"
    WEST = "W"
    NULL = None
