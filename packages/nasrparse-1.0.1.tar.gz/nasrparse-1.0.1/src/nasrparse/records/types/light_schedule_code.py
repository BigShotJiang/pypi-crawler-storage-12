from ._base_enum import BaseEnum


class LightScheduleCode(BaseEnum):
    SS_SR = "SS-SR"
    SEE_RMK = "SEE RMK"
    NULL = None
