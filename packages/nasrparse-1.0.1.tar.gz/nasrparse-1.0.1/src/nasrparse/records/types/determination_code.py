from ._base_enum import BaseEnum


class DeterminationCode(BaseEnum):
    TECHNICAL = "T"
    USING_AIRCRAFT = "U"
    NULL = None
