from ._base_enum import BaseEnum


class PavementCode(BaseEnum):
    RIGID = "R"
    FLEXIBLE = "F"
    NULL = None
