from ._base_enum import BaseEnum


class LocationTypeCode(BaseEnum):
    ARTCC = "ARTCC"
    CERAP = "CERAP"
    NULL = None
