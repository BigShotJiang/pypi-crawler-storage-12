from ._base_enum import BaseEnum


class MilRouteTypeCode(BaseEnum):
    IFR_ROUTE = "IR"
    VFR_ROUTE = "VR"
    NULL = None
