from .com_base import COM_BASE

__all__ = [
    "COM_BASE",
]
