#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : transparent_transmission
# @Time         : 2025/6/18 16:45
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  : 透传

