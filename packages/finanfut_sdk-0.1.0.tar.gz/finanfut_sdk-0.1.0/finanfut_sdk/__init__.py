"""FinanFut Intelligence Python SDK."""

from .client import FinanFutClient

__all__ = ["FinanFutClient"]
