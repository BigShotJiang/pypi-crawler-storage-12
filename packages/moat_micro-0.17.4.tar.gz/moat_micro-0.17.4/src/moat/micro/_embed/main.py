"""
MoaT main code.

Simply load and run moat.go.go().

This file is not replaced if it already exists!
"""

from __future__ import annotations

from moat.go import go

go(cmd=False)
