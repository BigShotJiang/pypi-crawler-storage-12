"""
Very simple battery monitor.

This implementation merely measures and aggregates voltage and current.
"""

from __future__ import annotations


class Batt:
    pass
