"""Mock objects for testing MemAgent components."""
