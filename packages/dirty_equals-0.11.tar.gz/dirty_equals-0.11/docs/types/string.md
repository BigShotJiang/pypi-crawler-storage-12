# String Types

::: dirty_equals.IsAnyStr

::: dirty_equals.IsStr

::: dirty_equals.IsBytes
