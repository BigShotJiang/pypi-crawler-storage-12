# Sequence Types

::: dirty_equals.IsListOrTuple

::: dirty_equals.IsList

::: dirty_equals.IsTuple

::: dirty_equals.HasLen

::: dirty_equals.Contains
