# Numeric Types

::: dirty_equals.IsInt
    options:
      merge_init_into_class: false
      separate_signature: false

::: dirty_equals.IsFloat
    options:
      merge_init_into_class: false
      separate_signature: false

::: dirty_equals.IsPositive
    options:
      merge_init_into_class: false

::: dirty_equals.IsNegative
    options:
      merge_init_into_class: false

::: dirty_equals.IsNonNegative
    options:
      merge_init_into_class: false

::: dirty_equals.IsNonPositive
    options:
      merge_init_into_class: false

::: dirty_equals.IsPositiveInt
    options:
      merge_init_into_class: false

::: dirty_equals.IsNegativeInt
    options:
      merge_init_into_class: false

::: dirty_equals.IsPositiveFloat
    options:
      merge_init_into_class: false

::: dirty_equals.IsNegativeFloat
    options:
      merge_init_into_class: false

::: dirty_equals.IsFloatInf
    options:
      merge_init_into_class: false

::: dirty_equals.IsFloatInfPos
    options:
      merge_init_into_class: false

::: dirty_equals.IsFloatInfNeg
    options:
      merge_init_into_class: false

::: dirty_equals.IsFloatNan
    options:
      merge_init_into_class: false

::: dirty_equals.IsApprox

::: dirty_equals.IsNumber
    options:
      merge_init_into_class: false

::: dirty_equals.IsNumeric
