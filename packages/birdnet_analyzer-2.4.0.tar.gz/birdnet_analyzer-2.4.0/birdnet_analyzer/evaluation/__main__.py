from birdnet_analyzer.evaluation import main

main()
