from birdnet_analyzer.species.cli import main

main()
