from birdnet_analyzer.species.core import species

__all__ = ["species"]
