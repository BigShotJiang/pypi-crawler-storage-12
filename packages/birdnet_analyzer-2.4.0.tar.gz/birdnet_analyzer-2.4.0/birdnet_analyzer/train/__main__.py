from birdnet_analyzer.train.cli import main

main()
