from birdnet_analyzer.train.core import train

__all__ = ["train"]
