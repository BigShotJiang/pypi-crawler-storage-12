from birdnet_analyzer.segments.core import segments

__all__ = ["segments"]
