from birdnet_analyzer.segments.cli import main

main()
