from birdnet_analyzer.embeddings.core import embeddings

__all__ = ["embeddings"]
