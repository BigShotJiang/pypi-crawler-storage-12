from birdnet_analyzer.embeddings.cli import main

main()
