from birdnet_analyzer.search.cli import main

main()
