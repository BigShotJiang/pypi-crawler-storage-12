"""UI files for GlanceWatch web interface."""
