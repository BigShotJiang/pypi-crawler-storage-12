class CompilationError(RuntimeError):
    pass


class CppTypeError(RuntimeError):
    pass
