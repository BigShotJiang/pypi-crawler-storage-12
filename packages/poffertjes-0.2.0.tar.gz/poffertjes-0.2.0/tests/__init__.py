"""Test suite for poffertjes."""
