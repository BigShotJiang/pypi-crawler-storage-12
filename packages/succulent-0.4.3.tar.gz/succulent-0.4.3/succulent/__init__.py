from succulent.configuration import Configuration

__all__ = [
    'Configuration']

__version__ = '0.4.3'
