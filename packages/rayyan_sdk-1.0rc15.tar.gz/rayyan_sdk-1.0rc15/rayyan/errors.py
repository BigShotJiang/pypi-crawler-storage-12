class InvalidCredentialsError(Exception):
    pass


class RefreshTokenExpiredError(Exception):
    pass
