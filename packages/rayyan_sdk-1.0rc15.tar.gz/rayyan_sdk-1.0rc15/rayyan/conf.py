TOKEN_EXPIRED = "Token expired"
TOKEN_NOT_DEFINED_ERROR = "Token is not defined"
CREDENTIAL_KEYS = ("access_token", "refresh_token")
MENDELEY = "mendeley"
