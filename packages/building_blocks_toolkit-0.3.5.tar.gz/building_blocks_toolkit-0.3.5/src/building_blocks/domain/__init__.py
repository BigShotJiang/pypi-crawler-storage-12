"""BuildingBlocks for domain-specific modules."""
