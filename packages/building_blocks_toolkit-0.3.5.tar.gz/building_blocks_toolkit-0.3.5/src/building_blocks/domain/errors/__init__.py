"""BuildingBlocks for domain errors."""
