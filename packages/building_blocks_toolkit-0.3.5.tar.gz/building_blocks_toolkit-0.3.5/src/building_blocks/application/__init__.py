"""BuildingBlocks for application-specific modules."""
