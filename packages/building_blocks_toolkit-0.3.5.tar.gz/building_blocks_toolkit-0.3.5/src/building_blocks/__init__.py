"""BuildingBlocks package initialization."""
