"""BuildingBlocks foundation.errors package initialization."""
