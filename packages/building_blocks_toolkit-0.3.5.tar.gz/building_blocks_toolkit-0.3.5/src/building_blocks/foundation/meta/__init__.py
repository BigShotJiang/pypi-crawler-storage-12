"""BuildingBlocks foundation.meta package initialization."""
