"""BuildingBlocks foundation modules."""
