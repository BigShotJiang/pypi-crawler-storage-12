# 最大行间距
MAX_HEIGHT_GAP_SIZE = 20

# 最大列间距，用于判断单双栏布局
MAX_WIDTH_GAP_SIZE = 12

# 默认存储图片位置
DEFAULT_IMAGE_SAVE_DIR = "./tmp/images/"
