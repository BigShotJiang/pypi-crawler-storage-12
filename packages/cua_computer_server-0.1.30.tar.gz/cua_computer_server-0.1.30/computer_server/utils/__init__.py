from . import wallpaper

__all__ = ["wallpaper"]
