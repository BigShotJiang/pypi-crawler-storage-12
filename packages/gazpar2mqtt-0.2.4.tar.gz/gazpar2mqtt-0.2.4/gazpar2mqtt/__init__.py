from gazpar2mqtt.version import __version__  # noqa: F401
