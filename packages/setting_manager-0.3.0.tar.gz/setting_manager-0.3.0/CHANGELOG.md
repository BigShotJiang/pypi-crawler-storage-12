# CHANGELOG

> All notable changes to this project will be documented in this file.


## v0.3.0 (2025-11-16)

### Bug Fixes


- Incorrect order of determining the source
  ([`e4acda0`](https://github.com/Frojen/setting-manager/commit/e4acda0c552dea9cb8e907dc4005c2669c784a7b))

### 📦 Build System



- Add link for changelog to pypi
  ([`daf0f5b`](https://github.com/Frojen/setting-manager/commit/daf0f5b498fb4b94d6efaf4079e5ef7a2ebe5cd0))

### 🚀 New Features



- Use local path for api template
  ([`da9bbd8`](https://github.com/Frojen/setting-manager/commit/da9bbd8a244209212c59af9d0c716dd625112fb3))


## v0.2.0 (2025-11-15)

### 📦 Build System



- Add changelog
  ([`1390d89`](https://github.com/Frojen/setting-manager/commit/1390d8964f2a42dc10293a531e968ce45dffec6f))

### 🚀 New Features



- Add base implementation
  ([`ae1d371`](https://github.com/Frojen/setting-manager/commit/ae1d371d803490e8173b453bf4a572fca1be58dd))

### 🧪 Tests



- Add basic test
  ([`cd957d7`](https://github.com/Frojen/setting-manager/commit/cd957d76576f3c354cd5ef3318480659eb4d21a2))


## v0.1.0 (2025-11-12)

- Initial Release
