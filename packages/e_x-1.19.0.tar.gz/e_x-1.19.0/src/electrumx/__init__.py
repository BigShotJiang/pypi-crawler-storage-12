from electrumx.server.controller import Controller
from electrumx.server.env import Env


BRANDING = "spesmilo"
__version__ = "1.19.0"
version = f'ElectrumX {__version__}'
version_short = __version__
