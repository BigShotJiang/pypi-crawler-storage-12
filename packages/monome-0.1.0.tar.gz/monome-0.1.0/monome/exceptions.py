class NoDevicesFoundError (Exception):
    """
    No serialio devices could be found.
    """
    pass