This module adds fuel logs in a similar way as services.
