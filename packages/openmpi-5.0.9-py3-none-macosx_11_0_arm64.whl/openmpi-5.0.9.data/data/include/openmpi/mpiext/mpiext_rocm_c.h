/* ompi/mpiext/rocm/c/mpiext_rocm_c.h.  Generated from mpiext_rocm_c.h.in by configure.  */
/*
 * Copyright (c) 2004-2009 The Trustees of Indiana University.
 *                         All rights reserved.
 * Copyright (c) 2010-2012 Cisco Systems, Inc.  All rights reserved.
 * Copyright (c) 2010      Oracle and/or its affiliates.  All rights reserved.
 * Copyright (c) 2015      NVIDIA, Inc. All rights reserved.
 * Copyright (c) 2022      Advanced Micro Devices, Inc. All rights reserved.
 * $COPYRIGHT$
 *
 * Additional copyrights may follow
 *
 * $HEADER$
 *
 */

#define MPIX_ROCM_AWARE_SUPPORT 0
OMPI_DECLSPEC int MPIX_Query_rocm_support(void);
