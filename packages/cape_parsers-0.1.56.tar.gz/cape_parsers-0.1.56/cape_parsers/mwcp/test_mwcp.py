from mwcp.parser import Parser


class MWCP_TEST(Parser):
    DESCRIPTION = "Test module to ensure that framework loads properly."
    AUTHOR = "doomedraven"

    def run(self):
        pass
