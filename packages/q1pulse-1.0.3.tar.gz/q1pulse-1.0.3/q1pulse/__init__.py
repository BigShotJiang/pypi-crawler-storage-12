__version__ = "1.0.3"

from .instrument import Q1Instrument, set_exception_on_overload
from .lang.math_expressions import Lsr as lsr

