command_registry = {}

x_tokens = {
	'?=': 'declare',
	'=': 'assign',
	'+=': 'increment',
	'-=': 'decrement',
	'*=': 'multiply',
	'/=': 'divide',
	'//=': 'floor-divide',
	'%=': 'modulus',
	'^=': 'power'
}