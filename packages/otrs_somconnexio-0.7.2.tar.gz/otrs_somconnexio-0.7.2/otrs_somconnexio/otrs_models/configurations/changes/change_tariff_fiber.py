class ChangeTariffTicketFiberConfiguration:
    process_id = "Process-a7b08ec0f281167899a5b72c8bd0899d"
    activity_id = "Activity-ea6172a702d09d7cbe8c2b44de9a9853"
    queue_id = 157
    type = "Petición"
    state = "new"
    priority = "3 normal"
    subject = "Sol·licitud Canvi de tarifa sense fix oficina virtual"
    code_fiber_100_landline = "SE_SC_REC_BA_F_100"
    code_fiber_100 = "SE_SC_REC_BA_F_100_SF"
    code_fiber_300 = "SE_SC_REC_BA_F_300_SF"
