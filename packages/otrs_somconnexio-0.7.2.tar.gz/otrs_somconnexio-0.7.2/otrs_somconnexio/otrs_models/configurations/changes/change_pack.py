class ChangePackNotSharedDataTicketConfiguration:
    process_id = "Process-4112fd4fbd7f4f384947621ae36ae74f"
    activity_id = "Activity-1a175e9802e4ec5784aa6948c3fd4080"
    queue_id = 249
    subject = "Canvi paquet F600 a F300"
    service = "Oficina Virtual"
