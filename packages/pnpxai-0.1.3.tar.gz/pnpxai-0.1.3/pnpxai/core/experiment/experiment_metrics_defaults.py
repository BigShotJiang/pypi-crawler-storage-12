EVALUATION_METRIC_AUTO_KWARGS = {}

EVALUATION_METRIC_REVERSE_SORT = {
    "MuFidelity": True,
    "Complexity": False,
    "Sensitivity": False
}

EVALUATION_METRIC_SORT_PRIORITY = [
    "MuFidelity",
    "Sensitivity",
    "Complexity"
]