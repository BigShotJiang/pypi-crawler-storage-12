from pnpxai.core.detector.detector import detect_model_architecture, symbolic_trace, extract_graph_data
