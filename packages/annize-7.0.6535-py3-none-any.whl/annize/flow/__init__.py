# SPDX-FileCopyrightText: © 2025 Josef Hahn
# SPDX-License-Identifier: AGPL-3.0-only
"""
Execution of Annize projects.

See e.g. :py:class:`annize.flow.runner.Runner` and :py:class:`annize.flow.run_context.RunContext`.
"""
