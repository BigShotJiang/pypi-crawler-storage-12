homepage_url = 'https://pseudopolis.eu/pino/annize'
version = '7.0.6535'
