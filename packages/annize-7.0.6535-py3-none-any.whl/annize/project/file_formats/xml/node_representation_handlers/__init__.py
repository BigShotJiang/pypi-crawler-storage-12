# SPDX-FileCopyrightText: © 2025 Josef Hahn
# SPDX-License-Identifier: AGPL-3.0-only
"""
Node readers and node editors for XML files, used internally by the XML file format support.
"""
