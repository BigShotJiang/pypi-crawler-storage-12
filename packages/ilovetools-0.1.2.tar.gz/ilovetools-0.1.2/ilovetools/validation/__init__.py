"""
Data validation and sanitization utilities
"""

__all__ = []