# handsoff/__main__.py
from .modules.cli import run

if __name__ == "__main__":
    run()
