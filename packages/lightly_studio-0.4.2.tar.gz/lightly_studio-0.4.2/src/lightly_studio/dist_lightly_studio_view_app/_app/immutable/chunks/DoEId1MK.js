import{v as o,E as f,x as i,n as p,y as c,z as d,A as h}from"./C3xJX0nD.js";function y(s,e,...t){var r=s,n=p,a;o(()=>{n!==(n=e())&&(a&&(c(a),a=null),a=i(()=>n(r,...t)))},f),d&&(r=h)}export{y as s};
