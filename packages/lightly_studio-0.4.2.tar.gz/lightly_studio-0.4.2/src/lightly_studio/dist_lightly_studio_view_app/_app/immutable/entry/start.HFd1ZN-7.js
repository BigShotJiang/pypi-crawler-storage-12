import{l as o,e as r}from"../chunks/lrI25eI9.js";export{o as load_css,r as start};
