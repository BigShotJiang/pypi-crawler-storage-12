=====
Guide
=====

To be filled from example notebooks.
