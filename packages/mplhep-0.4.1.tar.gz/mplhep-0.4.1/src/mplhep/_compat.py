from __future__ import annotations

from matplotlib import _docstring as docstring  # type: ignore[attr-defined]

__all__ = ("docstring",)
