# fastapi_opinionated/routing/controller.py

# Bisa dikembangkan nanti untuk base controller
class BaseController:
    pass