from fastapi_opinionated.registry.plugin import PluginRegistry
__all__ = ["PluginRegistry"]