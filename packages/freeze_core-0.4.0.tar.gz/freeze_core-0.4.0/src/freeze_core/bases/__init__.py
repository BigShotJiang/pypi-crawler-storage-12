"""The source of the base executables.

The base executables are used to launch your Python applications. Different
bases serve for different types of application on Windows
(GUI, console application or service).
The base executable calls the initscript, which in turn calls the user's code.
"""
