"""Core components for cx_Freeze."""

__version__ = "0.4.0"
