"""Enable running the package as a module: python -m midi_markdown."""

from midi_markdown.cli.main import cli

if __name__ == "__main__":
    cli()
