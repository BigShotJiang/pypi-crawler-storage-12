"""CLI package for MIDI Markdown."""
