"""MIDI generation package.

Handles conversion of AST to MIDI events and file writing.
"""
