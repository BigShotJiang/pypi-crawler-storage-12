"""Parser package for MIDI Markdown.

This package handles parsing of MML files into an Abstract Syntax Tree (AST).
"""
