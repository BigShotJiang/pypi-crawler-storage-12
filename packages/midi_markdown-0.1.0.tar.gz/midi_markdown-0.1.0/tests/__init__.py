"""Test suite for MIDI Markdown."""
