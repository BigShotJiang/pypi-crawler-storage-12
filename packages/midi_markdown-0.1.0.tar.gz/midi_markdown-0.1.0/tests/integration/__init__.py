"""Integration tests for MIDI Markdown."""
