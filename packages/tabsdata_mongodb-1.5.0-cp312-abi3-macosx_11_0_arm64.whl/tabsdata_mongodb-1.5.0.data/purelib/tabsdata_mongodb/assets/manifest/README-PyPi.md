Tabsdata MongoDB Python Package

Warning: this is not a standalone package. It is an `extra` of the Tabsdata package. 
Refer to the Tabsdata package for details on how to install it: https://pypi.org/project/tabsdata/
