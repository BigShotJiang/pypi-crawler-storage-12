from typing import Optional

from .config import Config


class ConfigAccessor:
    """
    Static accessor for managing the current configuration instance.

    This class provides a singleton pattern for accessing application configuration
    loaded from environment variables, files, or JSON strings.
    """

    _current_config: Optional[Config] = None

    @classmethod
    def current(cls) -> Optional[Config]:
        """
        Get the current configuration instance.

        Returns:
            The current Config instance, or None if not initialized.
        """
        return cls._current_config

    @classmethod
    def ensure_from_env(cls, env_name: str = "CONFIG_FILE") -> None:
        """
        Ensure configuration is loaded from environment variables.

        Only initializes if not already loaded. Safe to call multiple times.

        Args:
            env_name: Name of the environment variable containing the config file path.
                     Defaults to 'CONFIG_FILE'.

        Raises:
            AssertionError: If the environment variable is not set.
        """
        if cls._current_config is None:
            cls.init_from_env(env_name)

    @classmethod
    def init_from_env(cls, env_name: str = "CONFIG_FILE") -> None:
        """
        Initialize configuration from environment variable pointing to a config file.

        Args:
            env_name: Name of the environment variable containing the config file path.
                     Defaults to 'CONFIG_FILE'.

        Raises:
            AssertionError: If the environment variable is not set or file doesn't exist.
        """
        cls._current_config = Config.from_env(env_name)

    @classmethod
    def init_from_file(cls, filename: str) -> None:
        """
        Initialize configuration from a JSON file.

        Args:
            filename: Path to the JSON configuration file.

        Raises:
            AssertionError: If the file doesn't exist or is not readable.
            json.JSONDecodeError: If the file is not valid JSON.
        """
        cls._current_config = Config.from_file(filename)

    @classmethod
    def init_from_json_str(cls, json_string: str) -> None:
        """
        Initialize configuration from a JSON string.

        Args:
            json_string: JSON string containing the configuration.

        Raises:
            json.JSONDecodeError: If the string is not valid JSON.
        """
        cls._current_config = Config.from_json_str(json_string)
