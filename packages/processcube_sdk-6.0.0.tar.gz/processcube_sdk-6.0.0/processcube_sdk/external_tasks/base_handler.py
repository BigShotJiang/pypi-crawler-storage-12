"""Base handler for external task processing."""

import copy
import inspect
import logging
import os
import traceback
from typing import Any, Callable, Dict, Optional

from processcube_client.external_task import FunctionalError

logger = logging.getLogger("processcube.external_tasks")

# Re-export FunctionalError for convenience
__all__ = ["BaseHandler", "FunctionalError"]


def has_task_param(handle_func: Callable) -> bool:
    """
    Check if a handler function accepts a task parameter.

    Inspects the function signature to determine if it accepts 2 (with task)
    or 1 (without task) parameters (excluding self).

    Args:
        handle_func: The handler function to inspect.

    Returns:
        True if function signature suggests task parameter is supported, False otherwise.
    """

    def is_handler_a_func(func: Callable) -> bool:
        """Check if function has exactly 2 parameters (self, payload)."""
        try:
            spec = inspect.getfullargspec(func)
            is_func = inspect.isroutine(func)
            arg_count = len(spec.args)

            result = arg_count == 2 and is_func
            logger.debug(
                f"is_handler_a_func: arg_count={arg_count}, is_func={is_func}, result={result}"
            )
            return result
        except Exception as e:
            logger.warning(f"Failed to inspect handler function: {e}")
            return False

    def is_handler_callable(caller: Callable) -> bool:
        """Check if function has exactly 3 parameters (self, payload, task)."""
        try:
            spec = inspect.getfullargspec(caller)
            is_func = inspect.isroutine(caller)
            arg_count = len(spec.args)

            result = arg_count == 3 and is_func
            logger.debug(
                f"is_handler_callable: arg_count={arg_count}, is_func={is_func}, result={result}"
            )
            return result
        except Exception as e:
            logger.warning(f"Failed to inspect handler callable: {e}")
            return False

    return is_handler_a_func(handle_func) or is_handler_callable(handle_func)


class BaseHandler:
    """
    Base class for external task handlers.

    Provides common functionality for handling external tasks including
    payload processing, error handling, and result management.
    """

    def __init__(
        self, topic: Optional[str] = None, temp_folder: Optional[str] = None
    ) -> None:
        """
        Initialize the handler.

        Args:
            topic: The topic/type of external task this handler processes.
            temp_folder: Optional temporary folder path for task artifacts.
        """
        if not isinstance(topic, str) and topic is not None:
            logger.warning(f"topic should be a string, got: {type(topic)}")

        self._topic = topic
        logger.debug(f"Initialized BaseHandler for topic: {topic}")

    def get_topic(self) -> Optional[str]:
        """
        Get the topic handled by this handler.

        Returns:
            The topic string, or None if not set.
        """
        return self._topic

    def handle_task(
        self, payload: Dict[str, Any], task: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Handle an external task.

        Override this method to implement task-specific logic.

        Args:
            payload: Task payload containing parameters and data.
            task: Optional task metadata (processInstanceId, etc.).

        Returns:
            Dictionary of result values to append to payload.
        """
        logger.debug(
            f"Default handle_task for topic {self.get_topic()}: returning empty dict"
        )
        return {}

    def get_temp_folder(self, temp_folder: Optional[str] = None) -> str:
        """
        Get or create a temporary folder for task artifacts.

        Args:
            temp_folder: Optional specific path to use. If None, creates 'temp' folder
                        in the application root.

        Returns:
            Path to the temporary folder (created if necessary).

        Raises:
            OSError: If folder creation fails.
        """
        try:
            if temp_folder is None:
                root_folder = self.get_root_folder()
                temp_folder = os.path.join(root_folder, "temp")

            if not os.path.isdir(temp_folder) and not os.path.exists(temp_folder):
                os.makedirs(temp_folder, exist_ok=True)
                logger.info(f"Created temporary folder: {temp_folder}")
            else:
                logger.debug(f"Using existing temporary folder: {temp_folder}")

            return temp_folder

        except OSError as e:
            logger.error(f"Failed to create temp folder {temp_folder}: {e}")
            raise

    def get_root_folder(self) -> str:
        """
        Get the application root folder.

        Returns:
            Absolute path to the application root directory.
        """
        file_folder = os.path.dirname(__file__)
        app_root_folder = os.path.abspath(
            os.path.join(
                file_folder, "../controlling_platform/data_preparation", "..", ".."
            )
        )
        logger.debug(f"Resolved root folder: {app_root_folder}")
        return app_root_folder

    def __call__(self, payload: Dict[str, Any], task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the task handler.

        Orchestrates task execution, error handling, and result merging.

        Args:
            payload: Task payload containing input data.
            task: Task metadata including processInstanceId.

        Returns:
            Updated payload with task results merged in.

        Raises:
            FunctionalError: If task processing fails.
        """
        try:
            process_instance_id = task.get("processInstanceId", "unknown")
            logger.info(
                f"Running worker for topic '{self.get_topic()}' "
                f"on process instance '{process_instance_id}'"
            )

            copy_payload = copy.deepcopy(payload)

            # Detect handler signature and call appropriately
            if has_task_param(self.handle_task):
                logger.debug(f"Calling handler with task parameter")
                result = self.handle_task(payload, task)
            else:
                logger.debug(f"Calling handler without task parameter")
                result = self.handle_task(payload)

            if not isinstance(result, dict):
                logger.warning(f"Handler returned non-dict result: {type(result)}")
                result = {}

            logger.debug(f"Handle task '{self.get_topic()}' returned result: {result}")

            copy_payload.update(result)
            logger.info(
                f"Successfully completed worker for topic '{self.get_topic()}' "
                f"on process instance '{process_instance_id}'"
            )

            return copy_payload

        except FunctionalError as fe:
            logger.error(
                f"FunctionalError in handler for topic '{self.get_topic()}': {fe}"
            )
            raise

        except Exception as e:
            logger.error(
                f"Unexpected error in worker for topic '{self.get_topic()}': {e}",
                exc_info=True,
            )
            formatted_lines = traceback.format_exc().splitlines()
            raise FunctionalError("ProcessingFailed", str(formatted_lines))
