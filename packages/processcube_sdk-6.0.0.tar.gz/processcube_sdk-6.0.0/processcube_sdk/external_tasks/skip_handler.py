"""Skip handler for external tasks."""

from typing import Any, Dict, Optional

from .base_handler import BaseHandler


class SkipHandler(BaseHandler):
    """
    Handler that skips task execution.

    Useful for development/testing or when a task topic should be
    acknowledged but no actual processing is needed.
    """

    def __init__(
        self, topic: Optional[str] = None, temp_folder: Optional[str] = None
    ) -> None:
        """
        Initialize the skip handler.

        Args:
            topic: The topic/type of external task this handler processes.
            temp_folder: Optional temporary folder path (not used by SkipHandler).
        """
        super().__init__(topic, temp_folder)

    def handle_task(
        self, payload: Dict[str, Any], task: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Skip task execution and return success marker.

        Args:
            payload: Task payload (unused).
            task: Optional task metadata (unused).

        Returns:
            Dictionary with skipped flag set to True.
        """
        return {"skipped": True}
