"""External task worker command-line interface.

Provides CLI entry point for running external task workers that process
tasks from the ProcessCube engine.
"""

import logging

import typer
from processcube_client.external_task import ExternalTaskClient

from ..configuration import ConfigAccessor
from ..logging import setup_logging
from . import check_running_process_instance

logger = logging.getLogger("processcube_sdk")

app = typer.Typer(help="ProcessCube SDK External Task Worker")


def start_external_task() -> None:
    """
    Start external task workers for registered handler factories.

    Loads configuration from environment, creates external task client,
    and registers configured task handlers.

    Raises:
        ValueError: If required configuration is missing.
    """
    try:
        logger.debug("Starting external task worker initialization")

        ConfigAccessor.ensure_from_env()
        config = ConfigAccessor.current()

        engine_url = config.get("engine", "url")
        logger.info(f"Connecting to ProcessCube engine at: {engine_url}")

        client = ExternalTaskClient(engine_url)

        # Register available handler factories
        handler_factories = [
            check_running_process_instance,
        ]

        # Subscribe all handlers
        for factory in handler_factories:
            handler = factory.create_external_task(config)
            topic = handler.get_topic()

            logger.info(f"Registering external task worker for topic: '{topic}'")

            client.subscribe_to_external_task_for_topic(topic, handler)

        logger.info("All task handlers registered, starting client...")
        client.start()

    except Exception as e:
        logger.error(f"Failed to start external task worker: {e}", exc_info=True)
        raise


@app.command()
def external_task() -> None:
    """Start external task worker with command entry point."""
    setup_logging()
    start_external_task()


@app.callback(invoke_without_command=True)
def default() -> None:
    """Default command to start external task worker."""
    setup_logging()
    start_external_task()


if __name__ == "__main__":
    app()
