"""Check running process instance external task worker CLI.

Provides command-line interface for running the check running process instance
external task handler.
"""

import logging

import typer
from processcube_client.external_task import ExternalTaskClient

from ...configuration import Config
from . import DEFAULT_ENGINE_URL, create_external_task

logger = logging.getLogger(__name__)

app = typer.Typer(help="Check Running Process Instance External Task Worker")


def setup_logging(level: str = "INFO") -> None:
    """
    Configure logging for the CLI.

    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR).
    """
    format_template = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    logging_level = getattr(logging, level.upper(), logging.INFO)
    logging.basicConfig(level=logging_level, format=format_template, force=True)
    logger.debug(f"Logging configured with level: {level}")


@app.command()
def main(
    engine_url: str = typer.Option(DEFAULT_ENGINE_URL, help="ProcessCube engine URL"),
    log_level: str = typer.Option(
        "INFO", help="Logging level (DEBUG, INFO, WARNING, ERROR)"
    ),
) -> None:
    """
    Start the check running process instance external task worker.

    Args:
        engine_url: URL of the ProcessCube engine to connect to.
        log_level: Logging level for diagnostic output.
    """
    try:
        setup_logging(log_level)

        logger.info(f"Starting check running process instance worker on {engine_url}")

        # Create configuration
        config_data = {"engine": {"url": engine_url}}

        config = Config(config_data)
        logger.debug("Configuration loaded successfully")

        # Create handler
        handler = create_external_task(config)
        topic = handler.get_topic()
        logger.info(f"Handler created for topic: '{topic}'")

        # Create client and subscribe
        client = ExternalTaskClient(engine_url)
        logger.info(f"Subscribed to external task topic: '{topic}'")

        client.subscribe_to_external_task_for_topic(topic, handler, max_tasks=5)

        logger.info("Starting external task client...")
        client.start()

    except Exception as e:
        logger.error(f"Failed to start worker: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    app()
