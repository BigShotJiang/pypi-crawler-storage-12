import logging
from typing import Any, Dict, List, Optional, Type

import numpy as np
import pandas
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, load_only, Session

logger = logging.getLogger("processcube.database")

# ⚠️ SQLAlchemy 2.0: Uses modern async-ready API
# The code below is compatible with both 1.4 and 2.0 versions


class ORMHelper:
    """
    Helper class for ORM operations using SQLAlchemy and Pandas.

    Provides utilities for:
    - Creating SQLAlchemy engines and sessions
    - Merging Pandas DataFrames into ORM objects
    - Querying ORM objects and returning results as Pandas DataFrames
    """

    def __init__(self, connection_string: str) -> None:
        """
        Initialize ORMHelper with a database connection string.

        Args:
            connection_string: SQLAlchemy connection string (e.g., 'postgresql://user:pass@localhost/db')

        Raises:
            ValueError: If connection_string is empty or None.
        """
        if not connection_string or not isinstance(connection_string, str):
            raise ValueError(
                f"connection_string must be a non-empty string, got: {type(connection_string)}"
            )

        self._connection_string = connection_string
        logger.debug(
            f"ORMHelper initialized with connection string (masked for security)"
        )

    def create_engine(self) -> Any:
        """
        Create a SQLAlchemy engine from the connection string.

        Returns:
            SQLAlchemy Engine instance (sqlalchemy.engine.Engine).

        Raises:
            sqlalchemy.exc.ArgumentError: If connection string is invalid.
        """
        try:
            engine = create_engine(self._connection_string)
            logger.debug("SQLAlchemy engine created successfully")
            return engine
        except Exception as e:
            logger.error(f"Failed to create SQLAlchemy engine: {e}")
            raise

    def create_session(self) -> Session:
        """
        Create a SQLAlchemy session.

        Returns:
            SQLAlchemy Session instance.

        Note:
            The caller is responsible for closing the session when done.
        """
        engine = self.create_engine()
        session_maker = sessionmaker(bind=engine)
        session = session_maker()
        logger.debug("SQLAlchemy session created successfully")
        return session

    @staticmethod
    def _get_columns_from_dataframe(pandas_dataframe: Any) -> List[str]:
        """
        Extract column names from a Pandas DataFrame.

        Args:
            pandas_dataframe: Pandas DataFrame instance.

        Returns:
            List of column names.

        Raises:
            AttributeError: If pandas_dataframe doesn't have a 'columns' attribute.
        """
        if not hasattr(pandas_dataframe, "columns"):
            raise AttributeError(
                f"Object must be a Pandas DataFrame with 'columns' attribute"
            )

        # Use list() instead of manual loop for better performance and clarity
        return list(pandas_dataframe.columns)

    def merge_panda_records(
        self,
        orm_type: Type,
        pandas_dataframe: Any,
        session: Optional[Session] = None,
        **additional_fields: Dict[str, Any],
    ) -> int:
        """
        Merge Pandas DataFrame records into ORM objects.

        Converts each row of a Pandas DataFrame into an ORM object and merges it
        into the database. Handles NaN/None values appropriately.

        Args:
            orm_type: ORM class type to create instances of.
            pandas_dataframe: Pandas DataFrame with data to merge.
            session: Optional SQLAlchemy session. If None, creates and manages its own.
            **additional_fields: Additional fields to pass to ORM object constructor.

        Returns:
            Number of records merged.

        Raises:
            TypeError: If orm_type is not a valid ORM class.
            ValueError: If pandas_dataframe is not a valid DataFrame.

        Example:
            >>> helper = ORMHelper('sqlite:///:memory:')
            >>> import pandas as pd
            >>> df = pd.DataFrame({'id': [1, 2], 'name': ['Alice', 'Bob']})
            >>> count = helper.merge_panda_records(UserModel, df)
            >>> print(f"Merged {count} records")
        """
        if not pandas_dataframe.__class__.__name__ == "DataFrame":
            raise ValueError("pandas_dataframe must be a Pandas DataFrame instance")

        must_destroy_session = False
        if session is None:
            must_destroy_session = True
            session = self.create_session()

        try:
            columns = self._get_columns_from_dataframe(pandas_dataframe)
            record_count = 0

            for _, row in pandas_dataframe.iterrows():
                fields = {}

                for column in columns:
                    # ⚠️ NumPy 2.0+ compatibility: use pandas.isna() instead of np.NaN comparison
                    if pandas.isna(row[column]) or row[column] == "NaN":
                        fields[column] = None
                    else:
                        fields[column] = row[column]

                # Add any additional fields
                fields.update(additional_fields)

                try:
                    record = orm_type(**fields)
                    session.merge(record)
                    record_count += 1
                except Exception as e:
                    logger.warning(f"Failed to merge record: {e}")
                    raise

            logger.info(f"Successfully merged {record_count} records")
            return record_count

        finally:
            if must_destroy_session:
                try:
                    session.commit()
                    logger.debug("Session committed successfully")
                except Exception as e:
                    logger.error(f"Failed to commit session: {e}")
                    session.rollback()
                    raise
                finally:
                    session.close()
                    logger.debug("Session closed")

    def query_as_pandas_dataframe(
        self,
        query: Any,
        fields: Optional[List[str]] = None,
        **additional: Dict[str, Any],
    ) -> Any:
        """
        Execute a SQLAlchemy query and return results as a Pandas DataFrame.

        Args:
            query: SQLAlchemy Query object.
            fields: Optional list of field names to select (uses load_only optimization).
            **additional: Additional arguments (for backward compatibility).

        Returns:
            Pandas DataFrame with query results.

        Raises:
            AttributeError: If query doesn't have required SQLAlchemy methods.
            Exception: If query execution or DataFrame conversion fails.

        Example:
            >>> helper = ORMHelper('sqlite:///:memory:')
            >>> from sqlalchemy.orm import Query
            >>> session = helper.create_session()
            >>> query = session.query(UserModel)
            >>> df = helper.query_as_pandas_dataframe(query, fields=['id', 'name'])
            >>> print(df.shape)
        """
        # Support both new signature and old signature for backward compatibility
        if fields is None:
            fields = additional.get("fields", None)

        engine = self.create_engine()

        try:
            # Apply field selection if provided
            if fields:
                if not isinstance(fields, (list, tuple)):
                    raise TypeError(
                        f"fields must be a list or tuple, got {type(fields)}"
                    )

                try:
                    query = query.options(load_only(*fields))
                    logger.debug(f"Applied load_only optimization for fields: {fields}")
                except Exception as e:
                    logger.warning(f"Failed to apply load_only: {e}")

            # Execute query and convert to DataFrame
            try:
                df = pandas.read_sql(query.statement, engine)
                logger.info(f"Successfully loaded {len(df)} rows into DataFrame")
                return df
            except Exception as e:
                logger.error(f"Failed to read query results into DataFrame: {e}")
                raise

        finally:
            engine.dispose()
            logger.debug("Database engine disposed")
