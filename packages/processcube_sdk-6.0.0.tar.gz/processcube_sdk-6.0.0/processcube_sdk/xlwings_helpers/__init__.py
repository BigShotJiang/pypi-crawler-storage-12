"""Excel/xlwings utilities for ProcessCube SDK.

Provides helper functions for programmatic Excel workbook manipulation,
including sheet management, data formatting, and report generation.
"""

import logging
from typing import Any, Dict, List, Optional

import pandas as pd

logger = logging.getLogger("processcube.xlwings")


def make_link(link: str, title: str) -> str:
    """
    Create an Excel HYPERLINK formula.

    Args:
        link: The URL or file path to link to.
        title: The display text for the hyperlink.

    Returns:
        Excel HYPERLINK formula string.

    Example:
        >>> make_link("https://example.com", "Click here")
        '=HYPERLINK("https://example.com"; "Click here")'
    """
    return f'=HYPERLINK("{link}"; "{title}")'


def make_email(email: str, title: str) -> str:
    """
    Create an Excel mailto HYPERLINK formula.

    Args:
        email: Email address to link to.
        title: The display text for the email link.

    Returns:
        Excel HYPERLINK formula for email.

    Example:
        >>> make_email("test@example.com", "Send email")
        '=HYPERLINK("mailto:test@example.com"; "Send email")'
    """
    return f'=HYPERLINK("mailto:{email}"; "{title}")'


def sheet_by_name(book: Any, sheet_name: str, create: bool = True) -> Optional[Any]:
    """
    Get or create a worksheet by name.

    Args:
        book: xlwings Book object.
        sheet_name: Name of the sheet to find or create.
        create: If True, creates the sheet if it doesn't exist. Defaults to True.

    Returns:
        Sheet object if found/created, None if not found and create=False.

    Raises:
        ValueError: If sheet_name is empty.

    Example:
        >>> sheet = sheet_by_name(book, 'MySheet')
        >>> sheet = sheet_by_name(book, 'NonExistent', create=False)  # Returns None
    """
    if not sheet_name or not isinstance(sheet_name, str):
        raise ValueError(
            f"sheet_name must be a non-empty string, got: {type(sheet_name)}"
        )

    logger.debug(f"Looking for sheet: {sheet_name}")

    # Check if sheet exists
    existing_sheets = [sheet.name for sheet in book.sheets]

    if sheet_name in existing_sheets:
        sheet = book.sheets[sheet_name]
        logger.debug(f"Found existing sheet: {sheet_name}")
    elif create:
        sheet = book.sheets.add(sheet_name)
        logger.info(f"Created new sheet: {sheet_name}")
    else:
        logger.debug(f"Sheet not found and create=False: {sheet_name}")
        sheet = None

    return sheet


def get_config(book: Any) -> Dict[str, str]:
    """
    Extract configuration from workbook config sheet.

    Looks for 'Report_Config' or 'Config' sheet and reads key-value pairs.

    Args:
        book: xlwings Book object.

    Returns:
        Dictionary with configuration values (all keys and values as lowercase strings).

    Raises:
        ValueError: If neither 'Report_Config' nor 'Config' sheet is found.

    Example:
        >>> config = get_config(book)
        >>> print(config['sheet'])
        'Arbeitsleistung'
    """
    try:
        sheet = sheet_by_name(book, "Report_Config", create=False)

        if sheet is None:
            sheet = sheet_by_name(book, "Config", create=False)

        if sheet is None:
            logger.error("Config sheet not found (tried 'Report_Config' and 'Config')")
            raise ValueError(
                'Config sheet not found (tried "Report_Config" and "Config")'
            )

        logger.debug(f"Reading configuration from sheet: {sheet.name}")
        config: Dict[str, str] = {}

        data = sheet.range("A1").expand().value

        # Handle single cell vs. range
        if not isinstance(data, list):
            data = [data]

        # Parse key-value pairs
        for entry in data:
            try:
                key, value = entry[0], entry[1]
                config[str(key).lower()] = str(value)
            except (TypeError, IndexError) as e:
                logger.warning(f"Failed to parse config entry: {e}")
                continue

        logger.info(f"Loaded {len(config)} configuration values")
        return config

    except Exception as e:
        logger.error(f"Failed to get configuration: {e}")
        raise


def default_table_formatter(rng: Any, df: pd.DataFrame) -> None:
    """
    Apply default formatting to a table range.

    Applies alternating row colors and header formatting.

    Args:
        rng: xlwings Range object representing the table.
        df: Pandas DataFrame (used for metadata, not modified).

    Returns:
        None (modifies rng in-place).

    Example:
        >>> range_obj = sheet.range("A1").expand()
        >>> default_table_formatter(range_obj, df)
    """
    row_odd_color = "#f3f3f3"
    row_even_color = "#FFFFFF"
    header_color = "#bdbdbd"

    logger.debug(f"Applying default formatting to range with {len(df)} rows")

    # Header
    rng[0, :].color = header_color

    # Rows with alternating colors
    for ix, row in enumerate(rng.rows[1:]):
        if ix % 2 == 0:
            row.color = row_odd_color  # Even rows
        else:
            row.color = row_even_color  # Odd rows


def fill_sheet(
    book: Any,
    sheet_name: str,
    df: pd.DataFrame,
    formatter_options: Optional[Dict[str, Any]] = None,
    cell_options: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Fill a worksheet with DataFrame data.

    Clears existing content, writes DataFrame, and optionally applies formatting.

    Args:
        book: xlwings Book object.
        sheet_name: Name of the target sheet.
        df: Pandas DataFrame to write.
        formatter_options: Optional formatter function/options dict.
        cell_options: Options for cell.options() call. Defaults to {'index': False}.

    Returns:
        None (modifies book in-place).

    Raises:
        ValueError: If sheet doesn't exist and couldn't be created.

    Example:
        >>> fill_sheet(book, 'Report', df, cell_options={'index': False})
    """
    if formatter_options is None:
        formatter_options = {}
    if cell_options is None:
        cell_options = {"index": False}

    logger.debug(
        f"Filling sheet '{sheet_name}' with {len(df)} rows and {len(df.columns)} columns"
    )

    try:
        report_sheet = sheet_by_name(book, sheet_name)

        if report_sheet is None:
            logger.error(f"Sheet '{sheet_name}' could not be found or created")
            raise ValueError(f"Sheet '{sheet_name}' not available")

        # Add formatter if provided
        if formatter_options:
            cell_options["formatter"] = formatter_options

        report_cell = report_sheet["A1"]
        report_cell.expand().clear_contents()
        logger.debug(f"Cleared contents of sheet '{sheet_name}'")

        # Write DataFrame
        report_cell.options(**cell_options).value = df
        logger.debug(f"Wrote DataFrame to sheet '{sheet_name}'")

        # Auto-fit columns
        report_cell.offset(row_offset=1).columns.autofit()
        logger.info(f"Successfully filled sheet '{sheet_name}'")

    except Exception as e:
        logger.error(f"Failed to fill sheet '{sheet_name}': {e}")
        raise


def fill_sheet_and_result_json(
    book: Any,
    sheet_name: str,
    df: pd.DataFrame,
    formatter_options: Optional[Dict[str, Any]] = None,
    cell_options: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Fill worksheet and return workbook as JSON.

    Combines fill_sheet operation with JSON serialization.

    Args:
        book: xlwings Book object.
        sheet_name: Name of the target sheet.
        df: Pandas DataFrame to write.
        formatter_options: Optional formatter function/options dict.
        cell_options: Options for cell.options() call. Defaults to {'index': False}.

    Returns:
        JSON representation of the workbook.

    Example:
        >>> result_json = fill_sheet_and_result_json(book, 'Report', df)
        >>> return result_json
    """
    if formatter_options is None:
        formatter_options = {}
    if cell_options is None:
        cell_options = {"index": False}

    logger.debug(f"Filling sheet and generating JSON for '{sheet_name}'")

    fill_sheet(book, sheet_name, df, formatter_options, cell_options)

    book_json = book.json()
    logger.info(f"Successfully generated JSON representation of workbook")

    return book_json


def fill_report_sheet_and_result_json(
    book: Any,
    df: pd.DataFrame,
    formatter_options: Optional[Dict[str, Any]] = None,
    cell_options: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Fill report sheet using config and return workbook as JSON.

    Uses configuration sheet to determine target sheet name.

    Args:
        book: xlwings Book object.
        df: Pandas DataFrame to write.
        formatter_options: Optional formatter function/options dict.
        cell_options: Options for cell.options() call. Defaults to {'index': False}.

    Returns:
        JSON representation of the workbook.

    Raises:
        ValueError: If configuration cannot be loaded.
        KeyError: If 'sheet' key not found in configuration.

    Example:
        >>> result_json = fill_report_sheet_and_result_json(book, df)
    """
    if formatter_options is None:
        formatter_options = {}
    if cell_options is None:
        cell_options = {"index": False}

    logger.debug("Filling report sheet using configuration")

    try:
        book_config = get_config(book)

        if "sheet" not in book_config:
            logger.error("'sheet' key not found in configuration")
            raise KeyError("Configuration must contain 'sheet' key")

        target_sheet = book_config["sheet"]
        logger.debug(f"Using configured sheet: {target_sheet}")

        return fill_sheet_and_result_json(
            book, target_sheet, df, formatter_options, cell_options
        )

    except Exception as e:
        logger.error(f"Failed to fill report sheet: {e}")
        raise


def default_book_json(config_values: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """
    Create default workbook JSON structure.

    Generates a template workbook JSON with optional config sheet values.

    Args:
        config_values: Optional dictionary of config values to add to Config sheet.

    Returns:
        Dictionary representing workbook JSON structure.

    Example:
        >>> book_json = default_book_json({'report': 'monthly', 'period': 'Q1'})
    """
    if config_values is None:
        config_values = {}

    logger.debug(f"Creating default book JSON with {len(config_values)} config values")

    data: Dict[str, Any] = {
        "book": {
            "active_sheet_index": 1,
            "name": "Reporting [local Dev] (Arbeitsleistung v2)",
            "selection": "A1",
        },
        "client": "Google Apps Script",
        "names": [],
        "sheets": [
            {
                "name": "Config",
                "pictures": [],
                "values": [
                    ["Report", "arbeitsleistung_v2"],
                    ["Sheet", "Arbeitsleistung"],
                    ["Start", "2023-02-01T00:00:00.000Z"],
                    ["Ende", "2023-02-28T00:00:00.000Z"],
                ],
            },
            {"name": "Arbeitsleistung", "pictures": [], "values": [[]]},
            {"name": "Summen zur Arbeitsleistung", "pictures": [], "values": [[]]},
            {"name": "Arbeitsleistung v2", "pictures": [], "values": [[]]},
        ],
        "version": "0.28.7",
    }

    # Add custom config values to Config sheet
    if config_values:
        config_sheet_index = next(
            i for i, sheet in enumerate(data["sheets"]) if sheet["name"] == "Config"
        )
        data["sheets"][config_sheet_index]["values"].extend(
            [[key, value] for key, value in config_values.items()]
        )
        logger.debug(f"Added {len(config_values)} custom config values")

    return data


__all__ = [
    "make_link",
    "make_email",
    "sheet_by_name",
    "get_config",
    "default_table_formatter",
    "fill_sheet",
    "fill_sheet_and_result_json",
    "fill_report_sheet_and_result_json",
    "default_book_json",
]
