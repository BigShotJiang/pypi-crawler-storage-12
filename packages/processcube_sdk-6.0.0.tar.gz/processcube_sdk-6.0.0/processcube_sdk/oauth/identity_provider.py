import logging
import os
import sys
from typing import Dict, Optional

from oauth2_client.credentials_manager import CredentialManager, ServiceInformation
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    after_log,
)
from requests import exceptions

logger = logging.getLogger("processcube.oauth")

# Convert environment variable to integer with fallback
MAX_GET_OAUTH_ACCESS_TOKEN_RETRIES = int(
    os.environ.get("MAX_GET_OAUTH_ACCESS_TOKEN_RETRIES", "10")
)


def exit_after_retries(retry_state):
    logger.error(f"Failed all {retry_state.attempt_number} retries. Now exiting.")
    sys.exit(1)


class IdentityProvider:

    def __init__(
        self,
        authority_url: str,
        client_name: str,
        client_secret: str,
        client_scopes: str,
        verify_ssl: bool = True,
        proxies: Optional[Dict[str, str]] = None,
        user_agent: Optional[str] = None,
    ):
        """
        Initialize OAuth2 Identity Provider.

        Args:
            authority_url: Base URL for the OAuth2 authority (e.g., 'https://auth.example.com')
            client_name: OAuth2 client ID
            client_secret: OAuth2 client secret
            client_scopes: Space-separated list of OAuth2 scopes
            verify_ssl: Whether to verify SSL certificates (default: True)
            proxies: Optional dictionary of proxy settings for HTTP/HTTPS
            user_agent: Optional custom User-Agent header
        """
        self._authority_url = authority_url
        self._client_name = client_name
        self._client_secret = client_secret
        self._client_scopes = client_scopes
        self._verify_ssl = verify_ssl
        self._proxies = proxies
        self._user_agent = user_agent

        self._access_token_caller = self._prepare_get_access_token_caller()
        logger.debug(
            f"Prepare identity provider with (authority_url={authority_url}, "
            f"client_name={client_name}, client_secret=***, client_scopes={client_scopes})."
        )

    def __call__(self) -> Dict[str, str]:
        """
        Get current access token by calling the access token callable.

        Returns:
            Dictionary with 'token' key containing the access token
        """
        return self._access_token_caller()

    def _prepare_get_access_token_caller(self):
        """Prepare and return the access token getter function with retry logic."""

        @retry(
            stop=stop_after_attempt(MAX_GET_OAUTH_ACCESS_TOKEN_RETRIES),
            wait=wait_exponential(multiplier=1, min=2, max=30),
            retry=retry_if_exception_type(exceptions.ConnectionError),
            after=after_log(logger, logging.ERROR),
            retry_error_callback=exit_after_retries,
        )
        def get_access_token(
            authority_url: str,
            client_name: str,
            client_secret: str,
            client_scopes: str,
            verify_ssl: bool,
            proxies: Optional[Dict[str, str]],
            user_agent: Optional[str],
        ) -> Dict[str, str]:
            logger.debug(
                f"Get access token from ProcessCube (authority_url={authority_url}, "
                f"client_name={client_name}, client_secret=***, client_scopes={client_scopes})."
            )

            # Parse scopes from space-separated string to list
            scopes_list = client_scopes.split()

            # Construct OAuth2 service information
            service_information = ServiceInformation(
                authorize_service=f"{authority_url}/auth",
                token_service=f"{authority_url}/token",
                client_id=client_name,
                client_secret=client_secret,
                scopes=scopes_list,
                verify=verify_ssl,
            )

            # Create credential manager with optional proxy and user-agent settings
            manager = CredentialManager(
                service_information, proxies=proxies, user_agent=user_agent
            )

            # Get access token using client credentials flow
            manager.init_with_client_credentials()

            # Access token is stored internally after init_with_client_credentials()
            # Use the private attribute as oauth2_client doesn't expose public accessor
            access_token = manager._access_token
            if not access_token:
                raise ValueError("Failed to obtain access token from OAuth2 provider")

            logger.debug("Successfully obtained access token")

            return {"token": access_token}

        return lambda: get_access_token(
            self._authority_url,
            self._client_name,
            self._client_secret,
            self._client_scopes,
            self._verify_ssl,
            self._proxies,
            self._user_agent,
        )
