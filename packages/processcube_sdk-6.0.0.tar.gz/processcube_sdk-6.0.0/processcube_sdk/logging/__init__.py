"""
Logging configuration module for ProcessCube SDK.

Provides utilities for setting up application-wide logging with configuration
support from environment variables and configuration files.
"""

from .setup import setup_logging

__all__ = ["setup_logging"]
