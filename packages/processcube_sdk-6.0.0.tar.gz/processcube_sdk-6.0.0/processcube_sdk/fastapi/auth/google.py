"""
Google OAuth2 authentication and authorization for FastAPI.

Provides OAuth2-based authentication using Google's OpenID Connect provider
and authorization via Google Directory group membership verification.
"""

import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, Optional

import googleapiclient.errors
import requests
from cachetools import TTLCache, cached
from fastapi import Depends, HTTPException, Security, status
from fastapi.security import SecurityScopes
from fastapi.security.api_key import APIKeyHeader
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from pydantic import BaseModel

from processcube_sdk.configuration.config_accessor import ConfigAccessor

logger = logging.getLogger("processcube.fastapi")

# See https://developers.google.com/identity/protocols/oauth2/openid-connect#obtaininguserprofileinformation
GOOGLE_DISCOVERY_URL = "https://accounts.google.com/.well-known/openid-configuration"

# Cache configuration for Google userinfo endpoint discovery
CACHE_MAX_SIZE = int(os.environ.get("GOOGLE_AUTH_CLIENT_CACHE_MAX_SIZE", "100"))
CACHE_TTL = int(
    os.environ.get("GOOGLE_AUTH_CLIENT_CACHE_TTL", str(2 * 60 * 60))
)  # 2 hours


class AuthUser(BaseModel):
    """Represents an authenticated user from Google OAuth2."""

    id: str
    email: str
    domain: Optional[str] = None


@cached(
    cache=TTLCache(
        maxsize=CACHE_MAX_SIZE, ttl=timedelta(seconds=CACHE_TTL), timer=datetime.now
    )
)
def get_userinfo_endpoint() -> str:
    """
    Fetch Google's OpenID Connect userinfo endpoint URL.

    Uses caching to avoid repeated HTTP requests to the discovery endpoint.
    Cache TTL is configurable via GOOGLE_AUTH_CLIENT_CACHE_TTL environment variable.

    Returns:
        URL of the Google userinfo endpoint.

    Raises:
        requests.RequestException: If the discovery request fails.
        KeyError: If the userinfo_endpoint is not in the discovery response.
    """
    try:
        response = requests.get(GOOGLE_DISCOVERY_URL, timeout=5)
        response.raise_for_status()
        userinfo_url = response.json()["userinfo_endpoint"]
        logger.debug(f"Successfully retrieved userinfo endpoint: {userinfo_url}")
        return userinfo_url
    except Exception as e:
        logger.error(f"Failed to fetch Google discovery endpoint: {e}")
        raise


def authenticate(
    oauth_token: str = Security(APIKeyHeader(name="Authorization")),
) -> AuthUser:
    """
    Authenticate a user using Google OAuth2 token.

    Validates the provided OAuth2 token against Google's userinfo endpoint
    and checks that the user belongs to the authorized domain (5minds.de).

    Args:
        oauth_token: OAuth2 token from the Authorization header.

    Returns:
        AuthUser object with authenticated user information.

    Raises:
        HTTPException: If authentication fails or user domain is not authorized.
    """
    try:
        userinfo_url = get_userinfo_endpoint()
        headers = {"Authorization": f"Bearer {oauth_token}"}
        response = requests.get(userinfo_url, headers=headers, timeout=5)

        if response.status_code == 200:
            userinfo = response.json()
            user = AuthUser(
                id=userinfo["sub"], email=userinfo["email"], domain=userinfo.get("hd")
            )

            # Check domain authorization
            if user.domain == "5minds.de":
                logger.debug(f"User {user.email} authenticated successfully")
                return user
            else:
                logger.warning(
                    f"Authentication failed for user {user.email}: "
                    f"domain '{user.domain}' not authorized"
                )
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Unauthorized",
                )
        else:
            logger.warning(f"Google userinfo request failed: {response.status_code}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid OAuth Token",
            )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Authentication error: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid OAuth Token",
        )


async def get_current_user(user: AuthUser = Depends(authenticate)) -> AuthUser:
    """
    Get the currently authenticated user.

    Can be used as a dependency in FastAPI routes to ensure authentication.

    Args:
        user: Authenticated user (injected via Depends).

    Returns:
        The authenticated AuthUser object.
    """
    return user


async def authorize(
    security_scopes: SecurityScopes, user: AuthUser = Depends(authenticate)
) -> AuthUser:
    """
    Authorize a user based on Google Directory group membership.

    Checks if the authenticated user is a member of the required security scopes
    (represented as Google Directory groups).

    Args:
        security_scopes: FastAPI SecurityScopes containing required group names.
        user: Authenticated user (injected via Depends).

    Returns:
        The authenticated and authorized AuthUser object.

    Raises:
        HTTPException: If user is not member of required groups.

    Example:
        ```python
        @app.get("/admin")
        async def admin_endpoint(
            current_user: AuthUser = Security(authorize, scopes=["admins"])
        ):
            return {"message": f"Hello {current_user.email}"}
        ```
    """
    if not security_scopes.scopes:
        logger.debug(f"No scopes required, authorizing user {user.email}")
        return user

    logger.debug(
        f"Checking authorization for user {user.email} with scopes {security_scopes.scopes}"
    )

    for scope in security_scopes.scopes:
        if is_member(email=user.email, group=scope):
            logger.debug(f"User {user.email} authorized for scope {scope}")
            return user

    logger.warning(
        f"Authorization failed for user {user.email}: "
        f"not member of required groups {security_scopes.scopes}"
    )
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail=f"Missing authorization! Required scope: "
        f"{' or '.join(security_scopes.scopes)}",
    )


def is_member(email: str, group: str, **kwargs: Dict[str, Any]) -> bool:
    """
    Check if a user is a member of a Google Directory group.

    Uses Google Directory API to verify group membership. Credentials are loaded
    from configuration and support delegation for service account access.

    Args:
        email: User email address to check.
        group: Google Directory group email/key to check membership.
        **kwargs: Optional 'http' parameter for testing (HttpMock object).

    Returns:
        True if user is a member of the group, False otherwise.

    Configuration keys:
    - fastapi:google_service_account_file: Path to Google service account JSON file
    - fastapi:google_delegate_email: Email to delegate authority to (usually admin email)
    """
    ConfigAccessor.ensure_from_env()
    config = ConfigAccessor.current()

    scopes = [
        "https://www.googleapis.com/auth/admin.directory.group.readonly",
        "https://www.googleapis.com/auth/admin.directory.group.member.readonly",
    ]

    try:
        if kwargs.get("http"):
            # HttpMock for unit testing
            logger.debug("Using HttpMock for Google Directory API (unit test mode)")
            service = build("admin", "directory_v1", http=kwargs["http"])
        else:
            # Load credentials from service account file
            service_account_file = config.get("fastapi", "google_service_account_file")
            delegate_email = config.get("fastapi", "google_delegate_email")

            logger.debug(
                f"Loading Google service account credentials from {service_account_file}"
            )
            credentials = Credentials.from_service_account_file(
                service_account_file, scopes=scopes
            )

            # Delegate to admin account for group membership checks
            delegated_credentials = credentials.with_subject(delegate_email)
            service = build("admin", "directory_v1", credentials=delegated_credentials)

        # Check group membership
        results = (
            service.members()
            .hasMember(
                groupKey=group,
                memberKey=email,
            )
            .execute()
        )

        is_member_result = results.get("isMember", False)
        logger.debug(
            f"Group membership check for {email} in {group}: {is_member_result}"
        )
        return is_member_result

    except googleapiclient.errors.HttpError as e:
        logger.error(
            f"Failed to look up user '{email}' in group '{group}': "
            f"{e.reason} (Error {e.status_code})"
        )
        return False
    except Exception as e:
        logger.error(
            f"Unexpected error checking group membership for {email} in {group}: {e}"
        )
        return False
