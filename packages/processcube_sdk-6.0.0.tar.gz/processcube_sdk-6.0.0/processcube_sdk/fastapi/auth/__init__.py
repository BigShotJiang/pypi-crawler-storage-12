"""
FastAPI authentication and authorization utilities.

Provides OAuth2-based authentication and authorization mechanisms,
including Google Directory integration for group membership verification.
"""

from .google import authenticate, authorize, get_current_user, AuthUser

__all__ = ["authenticate", "authorize", "get_current_user", "AuthUser"]
