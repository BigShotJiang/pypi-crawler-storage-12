"""Jupyter notebook execution and result extraction utilities."""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas
import papermill as pm
import scrapbook as sb

logger = logging.getLogger("processcube.jupyter")


class NotebookRunner:
    """
    Execute Jupyter notebooks and extract results.

    Provides utilities to run notebooks with parameters using Papermill
    and extract scrapbook results for further processing.
    """

    def __init__(self, temp_path: str) -> None:
        """
        Initialize NotebookRunner with a temporary output directory.

        Args:
            temp_path: Path to store executed notebooks.
                      Can be a local path or cloud storage path (e.g., "s3://bucket/path").

        Raises:
            ValueError: If temp_path is empty or None.
        """
        if not temp_path or not isinstance(temp_path, str):
            raise ValueError(
                f"temp_path must be a non-empty string, got: {type(temp_path)}"
            )

        self._temp_path = temp_path
        self._notebook: Optional[Any] = None
        logger.debug(f"NotebookRunner initialized with temp_path: {temp_path}")

    def get(self, key: str) -> Any:
        """
        Get a scrapbook result by key.

        Args:
            key: The scrapbook key to retrieve.

        Returns:
            The value associated with the key, or None if notebook hasn't been executed.

        Raises:
            KeyError: If the key doesn't exist in notebook scraps.
        """
        if self._notebook is None:
            logger.warning(
                f"Attempted to get key '{key}' from notebook that hasn't been executed"
            )
            return None

        try:
            result = self._notebook.scraps[key].data
            logger.debug(f"Retrieved scrapbook result for key: {key}")
            return result
        except KeyError as e:
            logger.error(f"Scrapbook key '{key}' not found in notebook results")
            raise

    def keys(self) -> List[str]:
        """
        Get all scrapbook result keys from the executed notebook.

        Returns:
            List of scrapbook keys, or empty list if notebook hasn't been executed.
        """
        if self._notebook is None:
            logger.debug(
                "Attempted to get keys from notebook that hasn't been executed"
            )
            return []

        keys = list(self._notebook.scraps.keys())
        logger.debug(f"Retrieved {len(keys)} scrapbook keys")
        return keys

    def result_to_dict(self) -> Dict[str, Any]:
        """
        Convert all notebook scrapbook results to a dictionary.

        Converts Pandas DataFrames to list-based dictionaries for JSON serialization.

        Returns:
            Dictionary of all scrapbook results. Empty dict if notebook hasn't been executed.

        Example:
            >>> runner = NotebookRunner('/tmp/notebooks')
            >>> runner.execute('analysis.ipynb', {'param': 'value'})
            >>> results = runner.result_to_dict()
            >>> print(results)
        """
        result: Dict[str, Any] = {}

        for key in self.keys():
            value = self.get(key)

            # Convert Pandas DataFrames to dict for serialization
            if isinstance(value, pandas.DataFrame):
                value = value.to_dict("list")
                logger.debug(f"Converted DataFrame result '{key}' to dict format")

            result[key] = value

        logger.info(f"Converted {len(result)} results to dictionary")
        return result

    def execute(
        self, input_path: str, parameters: Optional[Dict[str, Any]] = None
    ) -> "NotebookRunner":
        """
        Execute a Jupyter notebook with parameters.

        Runs the notebook using Papermill and stores results for later retrieval.

        Args:
            input_path: Path to the input notebook file.
            parameters: Dictionary of parameters to inject into notebook cells.
                       Defaults to empty dict if None.

        Returns:
            Self for method chaining.

        Raises:
            FileNotFoundError: If input_path doesn't exist.
            Exception: If notebook execution fails.

        Example:
            >>> runner = NotebookRunner('/tmp/notebooks')
            >>> runner.execute('analysis.ipynb', {'date': '2025-01-15'})
            >>> results = runner.result_to_dict()
        """
        if parameters is None:
            parameters = {}

        try:
            input_filename = Path(input_path)

            # Check if input file exists
            if not input_filename.exists():
                logger.error(f"Input notebook not found: {input_path}")
                raise FileNotFoundError(f"Notebook not found: {input_path}")

            logger.debug(
                f"Executing notebook: {input_path} with parameters: {parameters}"
            )

            # Determine output path
            if ":/" in self._temp_path:
                # Cloud storage path (e.g., S3, GCS)
                output_filename = f"{self._temp_path}/{input_filename.name}"
                logger.debug(f"Using cloud storage path: {output_filename}")
            else:
                # Local filesystem path
                output_temp_dir = Path(self._temp_path)
                if not output_temp_dir.exists():
                    output_temp_dir.mkdir(parents=True, exist_ok=True)
                    logger.debug(f"Created output directory: {self._temp_path}")

                output_filename = str(output_temp_dir.joinpath(input_filename.name))

            # Execute notebook
            pm.execute_notebook(
                input_filename,
                output_filename,
                parameters=parameters,
                request_save_on_cell_execute=False,
                progress_bar=False,
                report_mode=True,
            )

            logger.info(f"Successfully executed notebook: {input_path}")

            # Read results
            self._notebook = sb.read_notebook(str(output_filename))
            logger.debug(f"Loaded notebook results from: {output_filename}")

            return self

        except FileNotFoundError:
            raise
        except Exception as e:
            logger.error(f"Failed to execute notebook '{input_path}': {e}")
            raise
