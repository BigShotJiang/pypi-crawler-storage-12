"""Tests for processcube_sdk.configuration module."""

import pytest

from processcube_sdk.configuration import Config, ConfigAccessor


class TestConfig:
    """Test cases for Config class."""

    def test_config_initialization(self):
        """Test Config initialization with dictionary."""
        config_dict = {
            "database": {"host": "localhost", "port": 5432},
            "api": {"url": "http://api.example.com"},
        }
        config = Config(config_dict)
        assert config is not None

    def test_config_get_single_level(self):
        """Test getting a single-level config value."""
        config = Config({"app_name": "MyApp"})
        assert config.get("app_name") == "MyApp"

    def test_config_get_nested(self):
        """Test getting nested config values."""
        config = Config({"database": {"host": "localhost", "port": 5432}})
        assert config.get("database", "host") == "localhost"
        assert config.get("database", "port") == 5432

    def test_config_get_with_default(self):
        """Test getting config with default value."""
        config = Config({"key": "value"})
        assert config.get("missing_key", default="default_value") == "default_value"

    def test_config_get_nested_with_default(self):
        """Test getting nested config with default."""
        config = Config({"database": {"host": "localhost"}})
        assert config.get("database", "password", default="secret") == "secret"

    def test_config_get_missing_raises_exception(self):
        """Test that getting missing key without default raises exception."""
        config = Config({})
        with pytest.raises(AssertionError):
            config.get("missing_key")

    def test_config_get_nested_missing_raises_exception(self):
        """Test that getting nested missing key raises exception."""
        config = Config({"database": {}})
        with pytest.raises(AssertionError):
            config.get("database", "host")

    def test_config_invalid_connection_string(self):
        """Test Config with invalid connection string raises error."""
        with pytest.raises(TypeError):
            Config(None)

    def test_config_lowercase_keys(self):
        """Test that config keys can be case-insensitive for lookups."""
        config = Config({"Database": {"Host": "localhost"}})
        # Keys should be preserved as provided
        assert config.get("Database", "Host") == "localhost"


class TestConfigAccessor:
    """Test cases for ConfigAccessor class."""

    def test_config_accessor_current(self):
        """Test ConfigAccessor.current() returns current config or None."""
        # current() should return None or a Config instance
        result = ConfigAccessor.current()
        assert result is None or isinstance(result, Config)

    def test_config_accessor_ensure_from_env(self):
        """Test ConfigAccessor.ensure_from_env() raises on missing env var."""
        import os

        # Remove CONFIG_FILE if it exists
        config_file_backup = os.environ.pop("CONFIG_FILE", None)
        try:
            # Should raise AssertionError if CONFIG_FILE env var is not set
            with pytest.raises(AssertionError):
                ConfigAccessor.ensure_from_env()
        finally:
            # Restore if it existed
            if config_file_backup:
                os.environ["CONFIG_FILE"] = config_file_backup
