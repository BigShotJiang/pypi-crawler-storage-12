"""Tests for processcube_sdk.external_tasks module."""

import pytest

from processcube_sdk.external_tasks import (
    BaseHandler,
    FunctionalError,
    SkipHandler,
)


class TestBaseHandler:
    """Test cases for BaseHandler class."""

    def test_base_handler_initialization(self):
        """Test BaseHandler initialization."""
        handler = BaseHandler(topic="test_topic")
        assert handler.get_topic() == "test_topic"

    def test_base_handler_default_topic(self):
        """Test BaseHandler with default (None) topic."""
        handler = BaseHandler()
        assert handler.get_topic() is None

    def test_base_handler_handle_task_default(self):
        """Test BaseHandler.handle_task returns empty dict by default."""
        handler = BaseHandler(topic="test")
        result = handler.handle_task({"key": "value"})
        assert result == {}

    def test_base_handler_handle_task_with_task_param(self):
        """Test BaseHandler.handle_task with task parameter."""
        handler = BaseHandler(topic="test")
        task = {"processInstanceId": "123", "processModelId": "model1"}
        result = handler.handle_task({"key": "value"}, task)
        assert result == {}

    def test_base_handler_call_method(self):
        """Test BaseHandler.__call__ method."""
        handler = BaseHandler(topic="test")
        payload = {"input": "data"}
        task = {"processInstanceId": "123"}

        result = handler(payload, task)
        assert result == payload

    def test_base_handler_invalid_topic_type(self):
        """Test BaseHandler with invalid topic type logs warning."""
        # Should not raise but log warning
        handler = BaseHandler(topic=123)
        assert handler.get_topic() == 123


class TestSkipHandler:
    """Test cases for SkipHandler class."""

    def test_skip_handler_initialization(self):
        """Test SkipHandler initialization."""
        handler = SkipHandler(topic="skip_topic")
        assert handler.get_topic() == "skip_topic"

    def test_skip_handler_handle_task(self):
        """Test SkipHandler.handle_task returns skipped flag."""
        handler = SkipHandler()
        result = handler.handle_task({"key": "value"})
        assert result == {"skipped": True}

    def test_skip_handler_handle_task_with_task_param(self):
        """Test SkipHandler.handle_task with task parameter."""
        handler = SkipHandler()
        task = {"processInstanceId": "123"}
        result = handler.handle_task({"key": "value"}, task)
        assert result == {"skipped": True}

    def test_skip_handler_call_method(self):
        """Test SkipHandler.__call__ method."""
        handler = SkipHandler(topic="skip")
        payload = {"data": "test"}
        task = {"processInstanceId": "456"}

        result = handler(payload, task)
        assert "skipped" in result
        assert result["skipped"] is True
        assert result["data"] == "test"


class TestFunctionalError:
    """Test cases for FunctionalError exception."""

    def test_functional_error_creation(self):
        """Test FunctionalError can be created."""
        error = FunctionalError("ErrorCode", "Error message")
        assert str(error) is not None

    def test_functional_error_is_exception(self):
        """Test FunctionalError is an Exception."""
        error = FunctionalError("Code", "Message")
        assert isinstance(error, Exception)

    def test_functional_error_raised_in_handler(self):
        """Test FunctionalError can be raised in handler."""
        handler = BaseHandler(topic="error_test")
        with pytest.raises(FunctionalError):
            raise FunctionalError("TestError", "Test message")


class TestHandlerFactory:
    """Test cases for handler factory pattern."""

    def test_handler_factory_pattern(self):
        """Test creating handlers through factory pattern."""

        # Simulate factory pattern
        def create_handler():
            return SkipHandler(topic="factory_test")

        handler = create_handler()
        assert handler.get_topic() == "factory_test"
        assert handler.handle_task({})["skipped"] is True
