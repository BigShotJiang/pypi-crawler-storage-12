"""Tests for processcube_sdk.xlwings_helpers module."""

import pytest

from processcube_sdk.xlwings_helpers import (
    default_book_json,
    make_email,
    make_link,
)


class TestMakeLink:
    """Test cases for make_link function."""

    def test_make_link_basic(self):
        """Test basic hyperlink formula generation."""
        result = make_link("https://example.com", "Click here")
        assert result == '=HYPERLINK("https://example.com"; "Click here")'

    def test_make_link_with_spaces(self):
        """Test hyperlink with spaces in title."""
        result = make_link("https://example.com", "Click here now")
        assert result == '=HYPERLINK("https://example.com"; "Click here now")'

    def test_make_link_empty_url(self):
        """Test hyperlink with empty URL."""
        result = make_link("", "Empty")
        assert result == '=HYPERLINK(""; "Empty")'

    def test_make_link_special_characters(self):
        """Test hyperlink with special characters."""
        result = make_link("https://example.com/path?query=1&other=2", "Link & Info")
        assert "HYPERLINK" in result
        assert "Link & Info" in result

    def test_make_link_file_path(self):
        """Test hyperlink with file path."""
        result = make_link("C:\\path\\to\\file.xlsx", "Open File")
        assert "HYPERLINK" in result
        assert "file.xlsx" in result


class TestMakeEmail:
    """Test cases for make_email function."""

    def test_make_email_basic(self):
        """Test basic email hyperlink formula generation."""
        result = make_email("test@example.com", "Send email")
        assert result == '=HYPERLINK("mailto:test@example.com"; "Send email")'

    def test_make_email_with_spaces_in_title(self):
        """Test email hyperlink with spaces in title."""
        result = make_email("contact@example.com", "Contact us now")
        assert "mailto:contact@example.com" in result
        assert "Contact us now" in result

    def test_make_email_complex_email(self):
        """Test email hyperlink with complex email address."""
        result = make_email("john.doe+tag@example.co.uk", "Email John")
        assert "mailto:john.doe+tag@example.co.uk" in result
        assert "Email John" in result

    def test_make_email_empty_title(self):
        """Test email hyperlink with empty title."""
        result = make_email("test@example.com", "")
        assert "mailto:test@example.com" in result


class TestDefaultBookJson:
    """Test cases for default_book_json function."""

    def test_default_book_json_no_config(self):
        """Test default book JSON generation without config."""
        result = default_book_json()
        assert isinstance(result, dict)
        assert "book" in result
        assert "sheets" in result
        assert "version" in result

    def test_default_book_json_structure(self):
        """Test default book JSON has required structure."""
        result = default_book_json()
        assert result["book"]["name"] == "Reporting [local Dev] (Arbeitsleistung v2)"
        assert result["client"] == "Google Apps Script"
        assert result["version"] == "0.28.7"

    def test_default_book_json_with_config_values(self):
        """Test default book JSON with config values."""
        config = {"report": "monthly", "period": "Q1"}
        result = default_book_json(config)

        # Should have more values in Config sheet
        config_sheet = next(s for s in result["sheets"] if s["name"] == "Config")
        assert len(config_sheet["values"]) > 4  # Original 4 + new ones

    def test_default_book_json_sheets_count(self):
        """Test default book JSON has expected sheets."""
        result = default_book_json()
        sheet_names = [s["name"] for s in result["sheets"]]
        assert "Config" in sheet_names
        assert "Arbeitsleistung" in sheet_names

    def test_default_book_json_empty_config(self):
        """Test default book JSON with empty config dict."""
        result = default_book_json({})
        # Should be same as no config
        result_with_none = default_book_json(None)
        assert len(result["sheets"]) == len(result_with_none["sheets"])

    def test_default_book_json_config_values_added(self):
        """Test that config values are correctly added."""
        config = {"key1": "value1", "key2": "value2"}
        result = default_book_json(config)

        config_sheet = next(s for s in result["sheets"] if s["name"] == "Config")
        values_list = config_sheet["values"]

        # Check that original config is preserved
        assert any("Report" in str(v) for v in values_list)

        # Check that new values are added
        assert any("key1" in str(v) for v in values_list)
        assert any("value1" in str(v) for v in values_list)
