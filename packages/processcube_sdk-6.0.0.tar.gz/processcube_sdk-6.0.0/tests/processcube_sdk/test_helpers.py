"""Tests for processcube_sdk.helpers module."""

import pytest

from processcube_sdk.helpers import str2bool


class TestStr2Bool:
    """Test cases for str2bool function."""

    def test_truthy_strings(self):
        """Test that truthy string values return True."""
        assert str2bool("yes") is True
        assert str2bool("YES") is True
        assert str2bool("Yes") is True
        assert str2bool("true") is True
        assert str2bool("TRUE") is True
        assert str2bool("True") is True
        assert str2bool("t") is True
        assert str2bool("T") is True
        assert str2bool("1") is True

    def test_falsy_strings(self):
        """Test that falsy string values return False."""
        assert str2bool("no") is False
        assert str2bool("false") is False
        assert str2bool("False") is False
        assert str2bool("f") is False
        assert str2bool("0") is False
        assert str2bool("") is False
        assert str2bool("random") is False

    def test_boolean_inputs(self):
        """Test that boolean inputs are returned as-is."""
        assert str2bool(True) is True
        assert str2bool(False) is False

    def test_none_input(self):
        """Test that None input returns False."""
        assert str2bool(None) is False

    def test_numeric_inputs(self):
        """Test that numeric inputs return False."""
        assert str2bool(0) is False
        assert str2bool(1) is False
        assert str2bool(42) is False
        assert str2bool(-1) is False
        assert str2bool(3.14) is False

    def test_list_input(self):
        """Test that list inputs return False."""
        assert str2bool([]) is False
        assert str2bool([1, 2, 3]) is False

    def test_dict_input(self):
        """Test that dict inputs return False."""
        assert str2bool({}) is False
        assert str2bool({"key": "value"}) is False
