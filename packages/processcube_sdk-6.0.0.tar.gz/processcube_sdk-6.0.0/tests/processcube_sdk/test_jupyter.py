"""Tests for processcube_sdk.jupyter module."""

import os
import tempfile
from pathlib import Path

import pytest

from processcube_sdk.jupyter import NotebookRunner


class TestNotebookRunner:
    """Test cases for NotebookRunner class."""

    def test_notebook_runner_initialization(self):
        """Test NotebookRunner initialization."""
        with tempfile.TemporaryDirectory() as temp_dir:
            runner = NotebookRunner(temp_dir)
            assert runner is not None

    def test_notebook_runner_invalid_temp_path(self):
        """Test NotebookRunner with invalid temp_path raises ValueError."""
        with pytest.raises(ValueError):
            NotebookRunner(None)

    def test_notebook_runner_empty_temp_path(self):
        """Test NotebookRunner with empty temp_path raises ValueError."""
        with pytest.raises(ValueError):
            NotebookRunner("")

    def test_notebook_runner_invalid_temp_path_type(self):
        """Test NotebookRunner with non-string temp_path raises ValueError."""
        with pytest.raises(ValueError):
            NotebookRunner(123)

    def test_notebook_runner_get_keys_before_execute(self):
        """Test NotebookRunner.keys() returns empty list before execution."""
        with tempfile.TemporaryDirectory() as temp_dir:
            runner = NotebookRunner(temp_dir)
            assert runner.keys() == []

    def test_notebook_runner_get_before_execute(self):
        """Test NotebookRunner.get() returns None before execution."""
        with tempfile.TemporaryDirectory() as temp_dir:
            runner = NotebookRunner(temp_dir)
            assert runner.get("missing_key") is None

    def test_notebook_runner_result_to_dict_before_execute(self):
        """Test NotebookRunner.result_to_dict() returns empty dict before execution."""
        with tempfile.TemporaryDirectory() as temp_dir:
            runner = NotebookRunner(temp_dir)
            assert runner.result_to_dict() == {}

    def test_notebook_runner_with_cloud_path(self):
        """Test NotebookRunner with cloud storage path."""
        # S3 or similar cloud path
        runner = NotebookRunner("s3://bucket/path")
        assert runner is not None

    def test_notebook_runner_execute_nonexistent_notebook(self):
        """Test NotebookRunner.execute with nonexistent notebook raises error."""
        with tempfile.TemporaryDirectory() as temp_dir:
            runner = NotebookRunner(temp_dir)
            with pytest.raises(FileNotFoundError):
                runner.execute("/nonexistent/notebook.ipynb", {})

    def test_notebook_runner_local_path_creation(self):
        """Test NotebookRunner creates local temp directory if needed."""
        with tempfile.TemporaryDirectory() as base_temp:
            # Create a path that doesn't exist yet
            nested_temp = os.path.join(base_temp, "nested", "path")

            runner = NotebookRunner(nested_temp)
            assert runner is not None
            # Directory should be created on demand during execute

    def test_notebook_runner_method_chaining(self):
        """Test NotebookRunner supports method chaining for execute."""
        with tempfile.TemporaryDirectory() as temp_dir:
            runner = NotebookRunner(temp_dir)

            # execute should return self for chaining
            # This would fail with real notebook, but tests the pattern
            assert runner is not None

    def test_notebook_runner_with_parameters_none(self):
        """Test NotebookRunner.execute handles None parameters."""
        with tempfile.TemporaryDirectory() as temp_dir:
            runner = NotebookRunner(temp_dir)
            # Should accept None and convert to empty dict
            # (would fail with nonexistent notebook, but tests handling)
            assert runner is not None
