"""Pytest configuration and fixtures for ProcessCube SDK tests."""

import os
import sys
from pathlib import Path

import pytest

# Add the project root to the path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))


@pytest.fixture
def temp_config_dict():
    """Fixture providing a temporary configuration dictionary."""
    return {
        "engine": {"url": "http://localhost:56100"},
        "database": {"host": "localhost", "port": 5432, "name": "test_db"},
        "logging": {
            "level": "INFO",
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        },
    }


@pytest.fixture
def temp_directory(tmp_path):
    """Fixture providing a temporary directory."""
    return str(tmp_path)


@pytest.fixture(scope="session")
def project_root_path():
    """Fixture providing the project root path."""
    return Path(__file__).parent.parent


def pytest_configure(config):
    """Pytest hook for configuration."""
    # Set environment for testing
    os.environ["TESTING"] = "true"


def pytest_collection_modifyitems(config, items):
    """Pytest hook to modify collected items."""
    # Add unit marker to all tests by default if not marked
    for item in items:
        if not any(item.iter_markers()):
            item.add_marker(pytest.mark.unit)
