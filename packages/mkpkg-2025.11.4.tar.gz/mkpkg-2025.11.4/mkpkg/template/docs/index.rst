.. include:: ../README.rst


Contents
--------

.. toctree::
    :glob:
    :maxdepth: 2
