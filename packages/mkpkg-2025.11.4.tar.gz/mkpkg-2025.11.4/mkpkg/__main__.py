"""
Create Python packages, hooray!
"""

from mkpkg import _cli

_cli.main()
