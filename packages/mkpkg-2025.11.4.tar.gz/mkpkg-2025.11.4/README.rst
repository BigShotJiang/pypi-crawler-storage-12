=========
``mkpkg``
=========

|PyPI| |Pythons| |CI| |ReadTheDocs|

.. |PyPI| image:: https://img.shields.io/pypi/v/mkpkg.svg
   :alt: PyPI version
   :target: https://pypi.org/project/mkpkg/

.. |Pythons| image:: https://img.shields.io/pypi/pyversions/mkpkg.svg
   :alt: Supported Python versions
   :target: https://pypi.org/project/mkpkg/

.. |CI| image:: https://github.com/Julian/mkpkg/workflows/CI/badge.svg
  :alt: Build status
  :target: https://github.com/Julian/mkpkg/actions?query=workflow%3ACI

.. |ReadTheDocs| image:: https://readthedocs.org/projects/mkpkg/badge/?version=stable&style=flat
   :alt: ReadTheDocs status
   :target: https://mkpkg.readthedocs.io/en/stable/


A package I (`Julian <https://github.com/Julian>`_) use to create Python packages.

It’s here for myself, but feel free to use it if you’d like.
