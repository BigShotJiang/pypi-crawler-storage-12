from dependency_needle.example.example import *  # noqa
