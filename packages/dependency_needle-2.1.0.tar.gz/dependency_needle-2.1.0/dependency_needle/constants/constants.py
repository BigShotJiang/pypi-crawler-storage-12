from typing import TypeVar


ANNOTATIONS = "__annotations__"
RETURN = "return"
INIT = "__init__"
InterfaceType = TypeVar('InterfaceType')
