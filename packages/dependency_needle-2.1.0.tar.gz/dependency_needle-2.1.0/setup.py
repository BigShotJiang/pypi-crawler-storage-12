from setuptools import setup, find_packages

setup(
    name="dependency_needle",
    version="2.1.0",
    description="Dependency injection container",
    author="Abdelrahman Torky",
    author_email="24torky@gmail.com",
    packages=find_packages(),
)
