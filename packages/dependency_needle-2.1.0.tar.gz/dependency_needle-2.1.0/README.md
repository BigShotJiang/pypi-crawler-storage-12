Dependency Injection Python Package for automating dependency injection. Inspired by .NET's Dependency Inversion Container.
