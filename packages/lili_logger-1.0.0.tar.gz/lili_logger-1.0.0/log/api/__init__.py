"""
日志系统API接口包
提供简洁易用的对外接口
"""

from .logger import Log, setup



__all__ = ['Log', 'setup']