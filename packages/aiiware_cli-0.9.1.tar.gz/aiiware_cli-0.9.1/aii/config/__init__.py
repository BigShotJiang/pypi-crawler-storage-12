"""Configuration management for AII CLI"""
