"""Authentication module for aii"""

from .subscription_client import ClaudeSubscriptionClient

__all__ = ["ClaudeSubscriptionClient"]