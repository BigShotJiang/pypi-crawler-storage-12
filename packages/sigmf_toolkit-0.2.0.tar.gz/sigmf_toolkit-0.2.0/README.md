# sigmf-toolkit

This Python package contains miscellaneous tools to work with SigMF files.
