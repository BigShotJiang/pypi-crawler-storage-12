
# EcoDev Sankey

**This is work in progress** This library easily allows to create (DataPoint) objects having associated (TreeNode) hierarchies, and manipulate these objects: filtering on them... The final aim is usually to show the filtered information in a Sankey diagram, hence the library name
