'''
The convertimagetoobjects module does not have any options.
'''