from .player import *
print("""
=======================================
DVS Audio Library (ap_ds) - Official Version -1.3.2
official website https://www.dvsyun.top/ap_ds
=======================================
""")
