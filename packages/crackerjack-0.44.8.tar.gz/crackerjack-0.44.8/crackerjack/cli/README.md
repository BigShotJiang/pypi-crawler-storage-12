# CLI

Command-line entrypoints and subcommands. Discover via `uv run python -m crackerjack --help`.
