# Agents

Agent implementations (suffix classes with `*Agent`). Encapsulate roles and coordinated behaviors.
