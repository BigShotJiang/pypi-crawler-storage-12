# Settings

Project-level configuration and defaults. Prefer Python settings with intelligent defaults; document any new options in `docs/`.
