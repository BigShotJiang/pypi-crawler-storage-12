# Templates

Shared templates used by the project (docs/UI/codegen as applicable). Keep them simple and documented with usage examples in `docs/`.
