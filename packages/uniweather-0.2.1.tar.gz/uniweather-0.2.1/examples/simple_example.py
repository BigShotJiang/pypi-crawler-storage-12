"""
Simple example matching Swift-style usage
"""

import asyncio
from uniWeather import uniWeatherCloud


async def main():
    # Create and connect
    uniWeather = uniWeatherCloud(base_url="http://localhost:8080")
    await uniWeather.connect(token="your-api-key-here")
    
    # Get devices
    myDevices = await uniWeather.my_devices()
    
    for device in myDevices:
        channels = await uniWeather.get_channels(device)
        print(f"{device.device_id}: {channels}")
    
    if myDevices:
        # Get data
        tmpMay = await uniWeather.data(
            device=myDevices[0],
            channels="all",
            from_date="2025-05-05",
            to_date="2025-05-07"
        )
        
        # Convert to DataFrame
        df = tmpMay.to_dataframe()
        print(df)
    
    await uniWeather.close()


asyncio.run(main())

