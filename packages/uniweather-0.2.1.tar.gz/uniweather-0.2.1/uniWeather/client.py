"""
uniWeather Cloud API Client
"""

import httpx
from typing import List, Optional, Union
from datetime import datetime, date
from .models import Device, DataQueryResponse, DeviceInfo
from .exceptions import (
    UniWeatherError,
    AuthenticationError,
    NotFoundError,
    APIError
)


class uniWeatherCloud:
    """
    Async client for uniWeather Cloud API
    
    Example:
        client = uniWeatherCloud(base_url="https://api.uniweather.io")
        await client.connect(token="your-api-key")
        
        devices = await client.my_devices()
        data = await client.data(devices[0], from_date="2025-05-05", to_date="2025-05-07")
    """
    
    def __init__(self, base_url: str = "https://api.uniweather.io"):
        """
        Initialize uniWeather client
        
        Args:
            base_url: Base URL of the uniWeather API server
        """
        self.base_url = base_url.rstrip('/')
        self._token: Optional[str] = None
        self._client: Optional[httpx.AsyncClient] = None
    
    async def connect(self, token: str) -> 'uniWeatherCloud':
        """
        Connect to the API with authentication token
        
        Args:
            token: API authentication token
            
        Returns:
            Self for method chaining
            
        Raises:
            AuthenticationError: If token is invalid
        """
        self._token = token
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {token}",
                "User-Agent": "uniWeather-Python-Client/0.2.0"
            },
            timeout=30.0
        )
        
        # Test connection
        try:
            response = await self._client.get("/devices")
            if response.status_code == 401:
                raise AuthenticationError("Invalid API token")
            elif response.status_code == 403:
                raise AuthenticationError("Access forbidden - check your token")
        except httpx.ConnectError as e:
            error_msg = str(e)
            if "CERTIFICATE_VERIFY_FAILED" in error_msg:
                raise UniWeatherError(
                    f"SSL Certificate verification failed connecting to {self.base_url}. "
                    f"On macOS, run: /Applications/Python\\ 3.*/Install\\ Certificates.command"
                )
            raise UniWeatherError(f"Failed to connect to {self.base_url}: {e}")
        
        return self
    
    async def close(self):
        """Close the HTTP client connection"""
        if self._client:
            await self._client.aclose()
            self._client = None
    
    async def __aenter__(self):
        """Support async context manager"""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Close connection on context exit"""
        await self.close()
    
    def _ensure_connected(self):
        """Ensure client is connected"""
        if not self._client or not self._token:
            raise UniWeatherError("Not connected. Call connect() first.")
    
    async def my_devices(self, all: bool = False) -> List[Device]:
        """
        Get list of devices accessible to the user
        
        Args:
            all: If True, show all assigned devices (including inactive)
            
        Returns:
            List of Device objects
        """
        self._ensure_connected()
        
        params = {"all": "true"} if all else {}
        response = await self._client.get("/devices", params=params)
        
        if response.status_code != 200:
            raise APIError(f"Failed to fetch devices: {response.status_code}")
        
        data = response.json()
        device_ids = data.get('devices', [])
        
        devices = []
        for device_id in device_ids:
            device = Device(device_id=device_id)
            devices.append(device)
        
        return devices
    
    async def get_device_info(self, device: Union[str, Device]) -> DeviceInfo:
        """
        Get detailed information about a device (requires admin access)
        
        Args:
            device: Device ID string or Device object
            
        Returns:
            DeviceInfo object
        """
        self._ensure_connected()
        
        device_id = device if isinstance(device, str) else device.device_id
        
        response = await self._client.get(f"/admin/devices/{device_id}")
        
        if response.status_code == 404:
            raise NotFoundError(f"Device '{device_id}' not found")
        elif response.status_code == 403:
            raise AuthenticationError("Admin access required")
        elif response.status_code != 200:
            raise APIError(f"Failed to fetch device info: {response.status_code}")
        
        return DeviceInfo.from_dict(response.json())
    
    async def get_channels(self, device: Union[str, Device]) -> List[str]:
        """
        Get list of available channels for a device
        
        Args:
            device: Device ID string or Device object
            
        Returns:
            List of channel names
        """
        self._ensure_connected()
        
        device_id = device if isinstance(device, str) else device.device_id
        
        response = await self._client.get(f"/devices/{device_id}/channels")
        
        if response.status_code == 404:
            raise NotFoundError(f"Device '{device_id}' not found")
        elif response.status_code == 403:
            raise AuthenticationError("Access forbidden to this device")
        elif response.status_code != 200:
            raise APIError(f"Failed to fetch channels: {response.status_code}")
        
        data = response.json()
        return data.get('channels', [])
    
    def _parse_date(self, date_input: Union[str, date, datetime, float, None]) -> Optional[float]:
        """Convert various date formats to Unix timestamp"""
        if date_input is None:
            return None
        
        if isinstance(date_input, (int, float)):
            return float(date_input)
        
        if isinstance(date_input, str):
            # Try parsing ISO format
            try:
                dt = datetime.fromisoformat(date_input)
                return dt.timestamp()
            except ValueError:
                pass
            
            # Try parsing common date formats
            for fmt in ['%Y-%m-%d', '%Y/%m/%d', '%d.%m.%Y']:
                try:
                    dt = datetime.strptime(date_input, fmt)
                    return dt.timestamp()
                except ValueError:
                    continue
            
            raise ValueError(f"Could not parse date: {date_input}")
        
        if isinstance(date_input, datetime):
            return date_input.timestamp()
        
        if isinstance(date_input, date):
            return datetime.combine(date_input, datetime.min.time()).timestamp()
        
        raise ValueError(f"Unsupported date type: {type(date_input)}")
    
    async def data(
        self,
        device: Union[str, Device],
        channels: Union[str, List[str], None] = None,
        from_date: Union[str, date, datetime, float, None] = None,
        to_date: Union[str, date, datetime, float, None] = None,
        format: str = "json"
    ) -> Union[DataQueryResponse, str]:
        """
        Query data from a device
        
        Args:
            device: Device ID string or Device object
            channels: Channel name, list of channels, or "all" for all channels
            from_date: Start date (string, datetime, or Unix timestamp)
            to_date: End date (string, datetime, or Unix timestamp)
            format: Output format - "json" or "csv"
            
        Returns:
            DataQueryResponse object (for json format) or CSV string (for csv format)
            
        Example:
            # Get all data for May 2025
            data = await client.data(
                device="device123",
                channels="all",
                from_date="2025-05-01",
                to_date="2025-05-31"
            )
            
            # Convert to pandas DataFrame
            df = data.to_dataframe()
            
            # Or get as CSV
            csv = await client.data(device="device123", format="csv")
        """
        self._ensure_connected()
        
        device_id = device if isinstance(device, str) else device.device_id
        
        # Build query parameters
        params = {}
        
        if from_date is not None:
            params['start'] = self._parse_date(from_date)
        
        if to_date is not None:
            params['end'] = self._parse_date(to_date)
        
        if channels is not None:
            if channels == "all":
                # Don't pass channels parameter to get all
                pass
            elif isinstance(channels, str):
                params['channels'] = channels
            elif isinstance(channels, list):
                params['channels'] = ','.join(channels)
        
        if format == "csv":
            params['format'] = 'csv'
        
        response = await self._client.get(f"/data/{device_id}", params=params)
        
        if response.status_code == 404:
            raise NotFoundError(f"Device '{device_id}' not found")
        elif response.status_code == 403:
            raise AuthenticationError("Access forbidden to this device")
        elif response.status_code != 200:
            raise APIError(f"Failed to fetch data: {response.status_code} - {response.text}")
        
        if format == "csv":
            return response.text
        else:
            return DataQueryResponse.from_dict(response.json())
    
    async def download_csv(
        self,
        device: Union[str, Device],
        filename: str,
        channels: Union[str, List[str], None] = None,
        from_date: Union[str, date, datetime, float, None] = None,
        to_date: Union[str, date, datetime, float, None] = None
    ):
        """
        Download data as CSV file
        
        Args:
            device: Device ID string or Device object
            filename: Output filename for CSV
            channels: Channel name, list of channels, or "all" for all channels
            from_date: Start date
            to_date: End date
        """
        csv_data = await self.data(
            device=device,
            channels=channels,
            from_date=from_date,
            to_date=to_date,
            format="csv"
        )
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(csv_data)
    
    async def list_all_devices(self) -> List[DeviceInfo]:
        """
        List all devices in the system (requires admin access)
        
        Returns:
            List of DeviceInfo objects
        """
        self._ensure_connected()
        
        response = await self._client.get("/admin/devices")
        
        if response.status_code == 403:
            raise AuthenticationError("Admin access required")
        elif response.status_code != 200:
            raise APIError(f"Failed to fetch devices: {response.status_code}")
        
        devices_data = response.json()
        return [DeviceInfo.from_dict(d) for d in devices_data]


class uniWeatherCloudSync:
    """
    Synchronous wrapper for uniWeatherCloud
    
    Example:
        with uniWeatherCloudSync() as client:
            client.connect(token="your-api-key")
            devices = client.my_devices()
            data = client.data(devices[0])
    """
    
    def __init__(self, base_url: str = "https://api.uniweather.io"):
        self._async_client = uniWeatherCloud(base_url=base_url)
        self._loop = None
    
    def _run_async(self, coro):
        """Run async coroutine synchronously"""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        return loop.run_until_complete(coro)
    
    def connect(self, token: str) -> 'uniWeatherCloudSync':
        """Connect to the API"""
        self._run_async(self._async_client.connect(token))
        return self
    
    def close(self):
        """Close connection"""
        self._run_async(self._async_client.close())
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    def my_devices(self, all: bool = False) -> List[Device]:
        """Get list of accessible devices"""
        return self._run_async(self._async_client.my_devices(all=all))
    
    def get_channels(self, device: Union[str, Device]) -> List[str]:
        """Get channels for a device"""
        return self._run_async(self._async_client.get_channels(device))
    
    def data(
        self,
        device: Union[str, Device],
        channels: Union[str, List[str], None] = None,
        from_date: Union[str, date, datetime, float, None] = None,
        to_date: Union[str, date, datetime, float, None] = None,
        format: str = "json"
    ) -> Union[DataQueryResponse, str]:
        """Query data from device"""
        return self._run_async(
            self._async_client.data(device, channels, from_date, to_date, format)
        )
    
    def download_csv(
        self,
        device: Union[str, Device],
        filename: str,
        channels: Union[str, List[str], None] = None,
        from_date: Union[str, date, datetime, float, None] = None,
        to_date: Union[str, date, datetime, float, None] = None
    ):
        """Download data as CSV"""
        return self._run_async(
            self._async_client.download_csv(device, filename, channels, from_date, to_date)
        )

