"""
Data models for uniWeather API
"""

from dataclasses import dataclass
from typing import List, Optional, Dict, Any
from datetime import datetime


@dataclass
class TimeSeriesEntry:
    """Represents a single timestamped data point"""
    timestamp: float
    values: List[float]
    mins: List[float]
    maxs: List[float]
    
    @property
    def datetime(self) -> datetime:
        """Convert timestamp to datetime object"""
        return datetime.fromtimestamp(self.timestamp)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TimeSeriesEntry':
        """Create TimeSeriesEntry from API response dict"""
        return cls(
            timestamp=data['timestamp'],
            values=data['values'],
            mins=data['mins'],
            maxs=data['maxs']
        )


@dataclass
class Channel:
    """Represents a sensor channel with time series data"""
    key: str
    entries: List[TimeSeriesEntry]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Channel':
        """Create Channel from API response dict"""
        entries = [TimeSeriesEntry.from_dict(e) for e in data['entries']]
        return cls(key=data['key'], entries=entries)
    
    def to_dict(self) -> Dict[str, List]:
        """Convert channel data to dictionary format for DataFrame"""
        timestamps = [e.datetime for e in self.entries]
        values = [e.values for e in self.entries]
        mins = [e.mins for e in self.entries]
        maxs = [e.maxs for e in self.entries]
        
        return {
            'timestamp': timestamps,
            'values': values,
            'mins': mins,
            'maxs': maxs
        }


@dataclass
class DeviceInfo:
    """Information about a device"""
    device_id: str
    status: Optional[str] = None
    station_name: Optional[str] = None
    location_latitude: Optional[float] = None
    location_longitude: Optional[float] = None
    provider_name: Optional[str] = None
    project_name: Optional[str] = None
    city_name: Optional[str] = None
    first_seen: Optional[datetime] = None
    last_seen: Optional[datetime] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DeviceInfo':
        """Create DeviceInfo from API response dict"""
        first_seen = None
        last_seen = None
        
        if 'firstSeen' in data:
            first_seen = datetime.fromisoformat(data['firstSeen'].replace('Z', '+00:00'))
        if 'lastSeen' in data:
            last_seen = datetime.fromisoformat(data['lastSeen'].replace('Z', '+00:00'))
        
        return cls(
            device_id=data['deviceID'],
            status=data.get('status'),
            station_name=data.get('stationName'),
            location_latitude=data.get('locationLatitude'),
            location_longitude=data.get('locationLongitude'),
            provider_name=data.get('providerName'),
            project_name=data.get('projectName'),
            city_name=data.get('cityName'),
            first_seen=first_seen,
            last_seen=last_seen
        )


@dataclass
class Device:
    """Represents a device with its channels"""
    device_id: str
    channels: Optional[List[str]] = None
    info: Optional[DeviceInfo] = None
    
    @property
    def name(self) -> str:
        """Get device name (station_name or device_id)"""
        if self.info and self.info.station_name:
            return self.info.station_name
        return self.device_id


@dataclass
class DataQueryResponse:
    """Response from a data query"""
    device_id: str
    start_time: float
    end_time: float
    channels: List[Channel]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DataQueryResponse':
        """Create DataQueryResponse from API response dict"""
        channels = [Channel.from_dict(c) for c in data['channels']]
        return cls(
            device_id=data['deviceID'],
            start_time=data['startTime'],
            end_time=data['endTime'],
            channels=channels
        )
    
    def to_dataframe(self):
        """
        Convert response to pandas DataFrame
        
        Returns:
            pandas.DataFrame with timestamp index and channel columns
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas is required for DataFrame conversion. "
                "Install it with: pip install pandas"
            )
        
        if not self.channels:
            return pd.DataFrame()
        
        # Collect all unique timestamps
        all_timestamps = set()
        for channel in self.channels:
            for entry in channel.entries:
                all_timestamps.add(entry.timestamp)
        
        timestamps = sorted(all_timestamps)
        dates = [datetime.fromtimestamp(ts) for ts in timestamps]
        
        # Build DataFrame with one column per channel
        data = {'timestamp': dates}
        
        for channel in self.channels:
            # Create lookup for this channel
            lookup = {e.timestamp: e.values for e in channel.entries}
            
            # Fill in values for each timestamp
            channel_values = []
            for ts in timestamps:
                if ts in lookup:
                    vals = lookup[ts]
                    # If single value, use it directly; if multiple, join with semicolon
                    if len(vals) == 1:
                        channel_values.append(vals[0])
                    else:
                        channel_values.append(vals)
                else:
                    channel_values.append(None)
            
            data[channel.key] = channel_values
        
        df = pd.DataFrame(data)
        df.set_index('timestamp', inplace=True)
        return df
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format"""
        return {
            'deviceID': self.device_id,
            'startTime': self.start_time,
            'endTime': self.end_time,
            'channels': [
                {
                    'key': ch.key,
                    'entries': [
                        {
                            'timestamp': e.timestamp,
                            'values': e.values,
                            'mins': e.mins,
                            'maxs': e.maxs
                        } for e in ch.entries
                    ]
                } for ch in self.channels
            ]
        }

