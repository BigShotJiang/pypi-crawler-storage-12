# uniWeather Python Client

Python client for the uniWeather Cloud API - Access IoT weather station and sensor data.

## Installation

```bash
pip install uniweather
```

For pandas DataFrame support:

```bash
pip install uniweather[pandas]
```

**macOS SSL Certificate Fix (if needed):**
```bash
/Applications/Python\ 3.*/Install\ Certificates.command
```

## Quick Start

### Async API (Recommended)

```python
import asyncio
from uniWeather import uniWeatherCloud

async def main():
    # Initialize client (defaults to https://api.uniweather.io)
    client = uniWeatherCloud()
    
    # Connect with your API token
    await client.connect(token="your-api-key-here")
    
    # Get your devices
    devices = await client.my_devices()
    
    for device in devices:
        print(f"Device: {device.device_id}")
        channels = await client.get_channels(device)
        print(f"Channels: {channels}")
    
    # Query data for a device
    data = await client.data(
        device=devices[0],
        channels="all",
        from_date="2025-05-05",
        to_date="2025-05-07"
    )
    
    # Convert to pandas DataFrame
    df = data.to_dataframe()
    print(df)
    
    await client.close()

asyncio.run(main())
```

### Synchronous API

```python
from uniWeather import uniWeatherCloudSync

with uniWeatherCloudSync() as client:
    client.connect(token="your-api-key-here")
    devices = client.my_devices()
    data = client.data(devices[0], channels="all")
    df = data.to_dataframe()
    print(df)
```

## Features

### Device Management

```python
# Get all accessible devices
devices = await client.my_devices()

# Get all assigned devices (including inactive)
all_devices = await client.my_devices(all=True)

# Get channels for a device
channels = await client.get_channels(device)
```

### Data Queries

```python
# Using date strings (YYYY-MM-DD)
data = await client.data(device, from_date="2025-05-01", to_date="2025-05-31")

# Using datetime objects
from datetime import datetime
data = await client.data(
    device,
    from_date=datetime(2025, 5, 1),
    to_date=datetime(2025, 5, 31)
)

# Filter specific channels
data = await client.data(device, channels=["temperature", "humidity"])

# Get all channels
data = await client.data(device, channels="all")
```

### Output Formats

#### Pandas DataFrame

```python
data = await client.data(device)
df = data.to_dataframe()
print(df.head())
print(df.describe())

# Plot data
import matplotlib.pyplot as plt
df.plot()
plt.show()
```

#### CSV File

```python
# Download directly to file
await client.download_csv(
    device=device,
    filename="data.csv",
    from_date="2025-05-01",
    to_date="2025-05-31"
)
```

## API Reference

### uniWeatherCloud

Main async client for the uniWeather API.

**Methods:**

- `connect(token: str)` - Authenticate with API token
- `my_devices(all: bool = False)` - Get accessible devices
- `get_channels(device)` - Get available channels for a device
- `data(device, channels=None, from_date=None, to_date=None, format="json")` - Query device data
- `download_csv(device, filename, channels=None, from_date=None, to_date=None)` - Download data as CSV
- `close()` - Close connection

### uniWeatherCloudSync

Synchronous wrapper with the same methods (without `await`).

## Error Handling

```python
from uniWeather import (
    UniWeatherError,
    AuthenticationError,
    NotFoundError,
    APIError
)

try:
    await client.connect(token="invalid")
except AuthenticationError as e:
    print(f"Authentication failed: {e}")
except APIError as e:
    print(f"API error: {e}")
```

## Troubleshooting

### SSL Certificate Error (macOS)

If you get `CERTIFICATE_VERIFY_FAILED` error on macOS:

```bash
# Run Python's certificate installer
/Applications/Python\ 3.*/Install\ Certificates.command
```

Or install certificates via:
```bash
pip install certifi
```

### Custom Base URL

For local development:

```python
client = uniWeatherCloud(base_url="http://localhost:8080")
```

## Support

- Email: support@uniweather.io
- Documentation: https://docs.uniweather.io

## License

MIT License
