"""Version information for vogel-model-trainer."""

__version__ = "0.1.9"
