"""Version information for PySpark StoryDoc."""

__version__ = "0.2.1"
__author__ = "PySpark StoryDoc Team"
__email__ = "team@pysparkstorydoc.com"
__description__ = "Business-friendly data lineage documentation for PySpark"