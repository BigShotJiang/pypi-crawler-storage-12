"""Python unit tests for jupyterlab_tabular_data_viewer_extension."""
