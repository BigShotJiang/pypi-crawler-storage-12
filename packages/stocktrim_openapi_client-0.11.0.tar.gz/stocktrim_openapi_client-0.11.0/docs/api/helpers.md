# Helper Methods API Reference

## Products Helper

::: stocktrim_public_api_client.helpers.products.Products
    options:
      show_source: true
      heading_level: 3

## Customers Helper

::: stocktrim_public_api_client.helpers.customers.Customers
    options:
      show_source: true
      heading_level: 3

## Suppliers Helper

::: stocktrim_public_api_client.helpers.suppliers.Suppliers
    options:
      show_source: true
      heading_level: 3

## Sales Orders Helper

::: stocktrim_public_api_client.helpers.sales_orders.SalesOrders
    options:
      show_source: true
      heading_level: 3

## Purchase Orders Helper

::: stocktrim_public_api_client.helpers.purchase_orders.PurchaseOrders
    options:
      show_source: true
      heading_level: 3

## Locations Helper

::: stocktrim_public_api_client.helpers.locations.Locations
    options:
      show_source: true
      heading_level: 3

## Inventory Helper

::: stocktrim_public_api_client.helpers.inventory.Inventory
    options:
      show_source: true
      heading_level: 3
