# Client API Reference

## StockTrimClient

::: stocktrim_public_api_client.stocktrim_client.StockTrimClient
    options:
      show_source: true
      heading_level: 3

## IdempotentOnlyRetry

::: stocktrim_public_api_client.stocktrim_client.IdempotentOnlyRetry
    options:
      show_source: true
      heading_level: 3

## ErrorLoggingTransport

::: stocktrim_public_api_client.stocktrim_client.ErrorLoggingTransport
    options:
      show_source: true
      heading_level: 3
