# Forecast Update Status

**Status**: ❌ Failed

**Error**: {error}

## Troubleshooting

- Verify API credentials are valid
- Check that products have sales history data
- Ensure no other forecast calculations are running
- Try again in a few minutes
