No forecast data found matching your criteria.

## Troubleshooting

- Try different filters or remove some filters
- Ensure products have sales history
- Run `forecasts_update_and_monitor` to calculate new forecasts
