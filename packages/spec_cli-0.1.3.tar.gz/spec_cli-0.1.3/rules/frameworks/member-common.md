# Member Common 组件使用

## 验证
- **字符串判空**: 使用StringValidation
- **集合类判空**: 使用CollectionUtility
- **Map判空**: 使用MapUtility

## 序列化
- **JSON序列化和反序列化**: JacksonSerializer