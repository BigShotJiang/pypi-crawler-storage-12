# 公司框架使用规范

优先使用携程内部框架支持的技术，公司框架组提供的技术组件包括但不限于：

- Qshedule：分布式任务调度
- QMQ：消息队列
- Qconfig：配置中心
- Dal：ORM 数据库访问框架
- SOA：分布式服务治理
- CRedis：缓存
- Minos：分布式锁和幂等

可通过 **Tech Doc** MCP工具 查询到。
