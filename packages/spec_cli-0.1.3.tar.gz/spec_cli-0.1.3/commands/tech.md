---
description: "进行AI技术方案设计"
argument-hint: "需提供功能点报告"
---


基于用户输入  $ARGUMENTS ，执行技术方案设计工作流
