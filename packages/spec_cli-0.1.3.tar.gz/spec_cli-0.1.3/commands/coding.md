---
description: "进行全流程开发"
argument-hint: "需提供PRD文档，或者技术方案设计文档"
---
基于用户输入  $ARGUMENTS  ， 执行代码生成工作流
