"""spec-cli: AI 规则仓库自动配置工具"""

__version__ = "0.1.3"

