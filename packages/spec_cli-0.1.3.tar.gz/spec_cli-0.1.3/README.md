# Airules

> **AI 编程的结构化知识库 + 工作流编排引擎**

<br>

## 🚀 快速上手

### 前置条件

在安装 Airules 前，请确保你的环境满足以下条件：

- ✅ **Git**：版本 >= 2.0
- ✅ **Bash**：用于执行安装脚本（Windows 用户推荐使用 Git Bash）
- ✅ **AI 编程工具**：Cursor 或 ClaudeCode

### 一键安装

在你的项目根目录打开终端，执行以下命令：

```bash
rm -rf /tmp/airules && \
git clone http://git.dev.sh.ctripcorp.com/ibu/airules.git /tmp/airules && \
bash /tmp/airules/setup-ai-rules.sh "$(pwd)" && \
rm -rf /tmp/airules
```

**安装过程**：

```bash
==========================================
  AI 规则仓库自动配置脚本
==========================================

[INFO] 目标安装目录: /your/project/path
[INFO] 检查前置条件...
[INFO] 前置条件检查通过

请选择您使用的 AI 客户端工具：
1) Cursor
2) ClaudeCode

请输入选项 [1-2]: 1
[INFO] 您选择了: Cursor
[INFO] 开始下载规则仓库...
[INFO] 仓库下载成功
[INFO] 正在拷贝 rules 文件夹...
[INFO] 正在拷贝 commands 文件夹...
[INFO] 文件拷贝完成！

==========================================
[INFO] 配置完成！请重启您的 AI 工具以使配置生效
==========================================
```

### 安装结果

安装完成后，项目目录结构如下：

```
your-project/
└── .cursor/           # Cursor 配置目录
    ├── rules/         # 规则文件（上下文库）
    │   ├── common/          # 通用规范
    │   ├── languages/       # 编程语言
    │   ├── frameworks/      # 技术框架
    │   ├── project/         # 项目知识（需生成）
    │   └── workflow/        # 工作流定义
    └── commands/      # 斜杠命令
        ├── req.md           # /req 命令
        ├── tech.md          # /tech 命令
        ├── coding.md        # /coding 命令
        └── dev.md           # /dev 命令
```

### 验证安装

打开 Cursor，在对话框中输入 `/`，应该能看到新增的命令：

![命令列表](images/README/1762761482607.png)

如果看到 `/req`、`/tech`、`/coding`、`/dev` 等命令，说明安装成功！

### 第一个示例

让我们用 `/req` 命令体验需求预评审工作流：

**1. 准备 PRD 文档**

假设你有一个飞书的 PRD 文档链接：

```
https://trip.larkenterprise.com/wiki/xxx
```

**2. 执行需求评审**

在 Cursor 对话框中输入：

```
/req auto https://trip.larkenterprise.com/wiki/xxx
```

**3. 观察执行过程**

AI 会自动按照以下阶段执行：

```
[STAGE: Collect] | [PRD_Review_Workflow] | [Auto]
↓ 收集 PRD 文档...

[STAGE: Research] | [PRD_Review_Workflow] | [Auto]
↓ 分析需求、识别术语、发现问题...

[STAGE: Innovation] | [PRD_Review_Workflow] | [Auto]
↓ 探索潜在缺失、边界场景...

[STAGE: Execution] | [PRD_Review_Workflow] | [Auto]
↓ 生成评审报告和功能点清单...
```

**4. 查看输出**

执行完成后，在 `.tasks/需求预评审_yyyyMMddHHmm/` 目录下会生成：

```
.tasks/需求预评审_202501101530/
├── inputs/
│   └── 需求原文.md              # PRD 原文
└── execution/
    ├── 需求预评审报告.md        # 评审报告
    └── 功能点报告.md            # 功能点拆分
```

恭喜！你已经成功使用 Airules 完成了第一次需求评审 🎉

<br>

## 📖 为什么需要 Airules

### 当前 AI 辅助编程的痛点

在日常使用 Cursor、Claude Code 等 AI 编程工具时，你是否遇到过这些问题：

**🤔 上下文散乱，每次都要重新组织**

- 每次对话都要重新告诉 AI 项目的技术栈、规范、业务逻辑
- 上下文信息零散，容易遗漏关键信息
- 无法复用和积累上下文知识

**😵 AI 输出不可控，质量不稳定**

- AI 直接生成代码，没有经过充分的分析和规划
- 生成的代码可能偏离需求或破坏现有架构
- 缺少质量保证机制，需要大量人工审查

**🔄 缺少标准化流程，难以复用经验**

- 每个人使用 AI 的方式不同，经验难以沉淀
- 没有统一的工作流程，效率参差不齐
- 团队协作困难，AI 辅助开发难以规模化

### Airules 的解决方案

Airules 提供了一套基于**上下文工程**和 **Spec 驱动开发**理念的系统化解决方案：

```
Airules = 结构化知识库 + 工作流编排引擎
```

**核心价值**：

- 🎯 **结构化上下文管理**：分层组织、动态组合、按需加载
- 📋 **标准化工作流程**：从需求评审到代码生成的全流程覆盖
- 🛡️ **Planning-First 原则**：先规划后执行，确保可控和可验证
- 🔍 **证据驱动决策**：每个决策都有证据链，可追溯
- ⚡ **工具无关设计**：支持 Cursor、ClaudeCode 等多种 AI 工具

<br>

## 🎯 Airules 是什么

### 项目定位

Airules 是一个**AI 工具无关的、统一的 AI 编程上下文规范与工作流框架**。

它不是简单的 Prompt 工程，而是一套完整的**上下文工程基础设施**：

```
┌──────────────────────────────────────────┐
│      结构化知识库（rules/）               │
│  ─────────────────────────────────       │
│  📋 声明性知识                            │
│     • 通用规范（common/）                 │
│     • 编程语言（languages/）              │
│     • 技术框架（frameworks/）             │
│     • 项目知识（project/）                │
│                                          │
│  ⚙️ 过程性知识                            │
│     • 工作流定义（workflow/）             │
│       - RIPER-5 元协议                   │
│       - 需求评审流程                      │
│       - 技术设计流程                      │
│       - 代码生成流程                      │
└──────────────────────────────────────────┘
              ↓ 被读取和应用
┌──────────────────────────────────────────┐
│      工作流编排引擎（运行时）             │
│  ─────────────────────────────────       │
│  🎯 命令解析器                            │
│     └─ 解析用户命令（/req /tech...）     │
│                                          │
│  🔗 上下文编排器                          │
│     └─ 根据 context-map.yaml 组装上下文  │
│                                          │
│  🚀 工作流调度器                          │
│     └─ 驱动工作流阶段执行和质量门禁       │
└──────────────────────────────────────────┘
```

### 核心设计理念

#### 基于 Spec-Driven Development（规格驱动开发）

Airules 深度实践了 **Spec-Driven Development** 理念，这是软件工程中确保质量的重要方法论：

**传统 AI 编程方式**：

```
用户需求 → AI 直接生成代码 → 质量不可控、难以验证
```

**Spec-Driven 方式**：

```
用户需求 → 生成 Spec（规格说明） → 基于 Spec 实现 → 验证符合性
```

**在 Airules 中的体现**：

| 阶段                     | Spec-Driven 对应   | Airules 实现                                      |
| ------------------------ | ------------------ | ------------------------------------------------- |
| **Specification**  | 编写精确的规格说明 | **PLAN 阶段**：生成详细到函数级别的执行规格 |
| **Implementation** | 基于规格实现       | **EXECUTE 阶段**：100% 按照 PLAN 的规格执行 |
| **Verification**   | 验证符合规格       | **REVIEW 阶段**：逐条验证实现与规格的一致性 |

**核心保证**：

- ✅ **可预测性**：有明确的 Spec，清楚知道会产生什么
- ✅ **可验证性**：可以逐条对比 Spec 和实现
- ✅ **可追溯性**：每行代码都能追溯到 Spec 中的某一条
- ✅ **可控性**：AI 不会"自作主张"偏离规格

**示例**：

```
PLAN 阶段生成的 Spec：
1. 修改文件：src/service/OrderService.java
2. 添加方法：public Order createOrder(OrderRequest req)
3. 实现逻辑：
   - 验证 req 参数完整性
   - 调用库存服务检查库存
   - 创建订单记录
   - 返回订单对象

EXECUTE 阶段：
严格按照上述 Spec 实现，不添加额外逻辑

REVIEW 阶段：
验证是否完全符合 Spec，标记任何偏差
```

这避免了 AI "创造性发挥"导致的代码破坏。

### 两大核心组件

#### 1. 结构化知识库（rules/）

**什么是结构化知识库？**

结构化知识库是 Airules 的"大脑"，存储了 AI 工作所需的所有知识：

**知识类型**：

- **声明性知识**（Declarative Knowledge）：描述"是什么"
  - 通用规范、编程语言特性、技术框架用法、项目业务逻辑
- **过程性知识**（Procedural Knowledge）：描述"怎么做"
  - 工作流定义、执行步骤、质量标准、元协议

**知识管理能力**：

- **知识组织**：分层结构化组织规范、技术栈、业务知识
- **知识组合**：根据任务动态组合所需的上下文
- **知识复用**：让上下文知识可积累、可复用、可扩展

**Airules 的上下文体系**：

```
.cursor/rules/
├── common/          # 通用层：所有场景的基础上下文
│   ├── document.md     # 文档规范
│   ├── git.md          # Git 规范
│   └── general.md      # 通用规范
│
├── languages/       # 语言层：特定编程语言的上下文
│   └── java.md         # Java 知识与规范
│
├── frameworks/      # 框架层：特定技术框架的上下文
│   ├── dal.md          # 数据访问层框架
│   └── soa.md          # SOA 服务框架
│
├── project/         # 项目层：业务领域的上下文
│   ├── overview.md     # 项目概述
│   └── business.md     # 业务逻辑
│
└── workflow/        # 工作流层：任务执行的元协议
    ├── common/         # 通用工作流协议（RIPER-5）
    ├── requirement-review/  # 需求评审工作流
    ├── tech-design/         # 技术设计工作流
    └── coding/              # 代码生成工作流
```

**关键机制：context-map.yaml**

每个工作流通过 `context-map.yaml` 定义所需的上下文组合：

```yaml
# 示例：编码工作流的上下文映射
includes:
  - ../../common/general.md      # 加载通用规范
  - ../../languages/java.md      # 加载 Java 知识
  - ../../frameworks/dal.md      # 加载 DAL 框架
  - ../../project/overview.md    # 加载项目知识

excludes:
  - ../../languages/python.md    # 排除无关内容
```

这样实现了：

- ✅ **按需加载**：只加载任务相关的上下文
- ✅ **自动组合**：无需手动拼接，由系统自动组装
- ✅ **避免冲突**：通过 excludes 排除矛盾信息

#### 2. 工作流编排引擎（运行时）

**什么是工作流编排引擎？**

工作流编排引擎是 Airules 的"导演"，它读取知识库中的工作流定义，并驱动 AI 按照标准流程执行：

**三大核心组件**：

- **命令解析器**：识别用户命令（/req、/tech、/coding 等）
- **上下文编排器**：根据 context-map.yaml 动态组装相关上下文
- **工作流调度器**：驱动工作流阶段执行、质量门禁控制、状态管理

**核心理念：Planning-First（规划优先）**

```
传统 AI 方式：
  用户需求 → AI 直接生成 → 人工审查（质量不可控）

Airules 方式：
  用户需求 → 研究分析 → 创新方案 → 详细规划 → 按规划执行 → 验证审查
           (可控的、分阶段的、可验证的)
```

**工作流标准结构**：

大多数工作流遵循以下阶段：

1. **Research（研究）**：充分理解需求和现状
2. **Innovate（创新）**：探索多种解决方案
3. **Plan（规划）**：制定详细的执行计划（Specification）
4. **Execute（执行）**：严格按照计划实施
5. **Review（审查）**：验证实现与计划的一致性

每个阶段都有：

- 明确的输入输出
- 质量门禁（P0/P1/P2）
- 证据追溯要求

<br>

## ✨ 核心特性

### ✅ 1. 标准化工作流

提供从需求到代码的全流程标准化工作流：

| 工作流       | 命令        | 输入              | 输出                      | 适用场景               |
| ------------ | ----------- | ----------------- | ------------------------- | ---------------------- |
| 需求预评审   | `/req`    | PRD 文档          | 需求评审报告 + 功能点清单 | 需求分析、PRD 质量检查 |
| 技术方案设计 | `/tech`   | 功能点清单        | 技术实现方案文档          | 架构设计、技术选型     |
| 代码生成     | `/coding` | 需求文档 + 代码库 | 代码实现                  | 功能开发、代码重构     |
| 全流程开发   | `/dev`    | PRD 文档          | 需求报告 + 方案 + 代码    | 一站式开发             |

### ✅ 2. Planning-First 原则

**先规划，后执行**，确保 AI 输出的可控性：

```
PLAN 阶段：
  生成详细的执行规格（Specification）
  ├─ 要修改哪些文件
  ├─ 要实现哪些函数
  ├─ 具体的修改步骤
  └─ 预期的结果

EXECUTE 阶段：
  100% 按照规格执行
  ├─ 不偏离计划
  ├─ 不创造性发挥
  └─ 每步都可追溯到计划

REVIEW 阶段：
  验证实现与规格的一致性
  └─ 任何偏差都要明确标注
```

这避免了 AI "自作主张"导致的代码破坏。

### ✅ 3. 证据驱动决策

每个决策都要有证据支撑，避免 AI 幻觉：

**Claim-Evidence 模型**：

- **Claim（断言）**：AI 做出的每个结论
- **Evidence（证据）**：支撑该结论的原始证据
- **Anchor（锚点）**：证据在原文中的位置

示例：

```
❌ 无证据的断言：
  "订单支持优惠券功能"

✅ 有证据的断言：
  Claim: "订单支持优惠券功能"
  Evidence: PRD 第 3.2 节 "订单结构" → "promotion 字段（优惠信息）"
  Anchor: PRD § 3.2
```

当证据不足时，AI 会生成 **Clarification（澄清问题）** 而非猜测。

### ✅ 4. 质量门禁机制

通过分级门禁保证质量：

| 优先级       | 处理策略                    | 说明                       |
| ------------ | --------------------------- | -------------------------- |
| **P0** | 阻断，必须解决              | 影响系统正确性或关键业务   |
| **P1** | 建议停顿，需假设 + 缓解方案 | 强烈建议解决，否则记录风险 |
| **P2** | 记录假设，后续验证          | 可在假设下前进，但要追踪   |

自动模式下，P0 会触发自动回退重新规划。

### ✅ 5. 分层上下文体系

知识模块化、可组合、可复用：

```
通用层 → 适用于所有项目（文档规范、Git 规范）
  ↓
语言层 → 适用于特定语言（Java、Python）
  ↓
框架层 → 适用于特定框架（Spring、DAL）
  ↓
项目层 → 特定项目的业务知识
```

通过 `context-map.yaml` 动态组合所需上下文。

### ✅ 6. 工具无关设计

一套规范，多种工具支持：

- ✅ Cursor
- ✅ ClaudeCode
- 🔄 其他 AI 编程工具（持续扩展）

<br>

## 📋 工作流详解

### 🔍 需求预评审工作流（/req）

**适用场景**：

- 在正式需求评审会议前，使用 AI 预先分析 PRD
- 发现 PRD 中的缺失、冲突、模糊之处
- 生成结构化的功能点清单

**输入**：

- PRD 飞书文档链接（必需）
- 需求预评审报告模板（可选）

**输出**：

- 《需求预评审报告》：包含术语问题、流程问题、逻辑问题等
- 《功能点报告》：使用 EARS 语法描述的用户故事

**执行阶段**：

```
Collect（收集）
  ├─ 检查 feishu2md MCP 工具
  ├─ 下载 PRD 文档
  └─ 下载报告模板（如有）

Research（研究）
  ├─ PRD 原子化解析（拆分为 Claim）
  ├─ 证据绑定（Evidence Anchor）
  ├─ 一致性校验
  ├─ 需求气味扫描（模糊词、占位符等）
  ├─ 术语对齐
  ├─ 生成澄清问题（Clarification）
  └─ 功能点拆分（用户故事）

Innovation（创新）
  ├─ 领域模式映射（典型生命周期）
  ├─ 业务规则骨架检测
  ├─ 场景穷举（边界、异常）
  └─ 多方案对比

Execution（执行）
  ├─ 生成功能点报告
  ├─ 生成需求预评审报告
  └─ 自动过滤技术细节（仅保留业务问题）
```

**命令格式**：

```bash
# 自动模式（推荐）
/req auto https://trip.larkenterprise.com/wiki/xxx

# 手动模式（每个阶段需确认）
/req manual https://trip.larkenterprise.com/wiki/xxx

# 带自定义模板
/req auto prd_link=https://xxx template_link=https://yyy
```

**核心价值**：

- ✅ 系统化发现 PRD 问题，避免遗漏
- ✅ 证据驱动，每个问题都有出处
- ✅ 自动过滤技术细节，聚焦业务问题
- ✅ 生成 EARS 语法的用户故事，对接敏捷开发

### 🏗️ 技术方案设计工作流（/tech）

**适用场景**：

- 基于功能点清单生成技术实现方案
- 评估多种技术方案的优劣
- 输出可交付的技术设计文档

**输入**：

- 功能点清单或需求文档
- 代码仓库（可选）

**输出**：

- 《技术实现方案文档》
- 技术决策日志
- 风险清单

**执行阶段**：

```
Collect（收集）
  ├─ 收集功能点清单
  ├─ 分析代码仓库现状（如有）
  └─ 识别技术约束

Research（研究）
  ├─ 需求分解与能力映射
  ├─ 现有代码能力分析
  ├─ 依赖与约束识别
  └─ 构建事实基线（Fact Baseline）

Innovation（创新）
  ├─ 多方案设计（2-3 个）
  ├─ 方案对比矩阵（完整性、复杂度、风险）
  ├─ 架构模式选择
  └─ 技术选型

Execute（执行）
  ├─ 生成详细技术方案
  ├─ 数据模型设计
  ├─ 接口定义
  ├─ 部署架构
  └─ 风险与缓解措施
```

**命令格式**：

```bash
# 自动模式
/tech auto 功能点文档路径

# 手动模式
/tech manual 功能点文档路径
```

**核心价值**：

- ✅ 多方案对比，避免一言堂
- ✅ 基于事实基线，避免空谈
- ✅ 技术决策可追溯
- ✅ 输出可直接交付的技术文档

### 💻 代码生成工作流（/coding）

**适用场景**：

- 基于需求文档和代码库生成代码实现
- 确保代码符合项目规范和架构
- 系统性进行代码重构

**输入**：

- 需求文档
- 代码仓库

**输出**：

- 代码实现
- 实施日志

**执行阶段**：

```
Research（研究）
  ├─ 分析需求文档
  ├─ 理解现有代码结构
  ├─ 识别修改范围
  └─ 识别技术约束

Plan（规划）
  ├─ 生成详细实施计划
  ├─ 列出要修改的文件
  ├─ 定义函数签名
  ├─ 规划数据结构变更
  └─ 生成原子任务清单

Execute（执行）
  ├─ 严格按计划实施
  ├─ 每个任务完成后记录
  └─ 不偏离计划

Review（审查）
  ├─ 验证实现与计划一致性
  ├─ 检测偏差
  ├─ 代码质量检查
  └─ 生成审查报告
```

**命令格式**：

```bash
# 自动模式（推荐）
/coding auto 需求文档路径

# 手动模式（适合复杂重构）
/coding manual 需求文档路径
```

**核心价值**：

- ✅ Planning-First，先规划后编码
- ✅ 100% 按计划执行，避免破坏性修改
- ✅ 每步可追溯，便于审查
- ✅ 自动遵循项目规范和架构

### 🚀 组合工作流（/dev）

**适用场景**：

- 从需求到代码的一站式开发
- 需要完整的开发流程

**执行流程**：

```
/dev = /req + /tech + /coding
```

自动依次执行三个工作流：

1. 需求预评审 → 生成评审报告和功能点
2. 技术方案设计 → 生成技术方案文档
3. 代码生成 → 实现功能代码

**命令格式**：

```bash
# 全自动模式
/dev auto https://trip.larkenterprise.com/wiki/xxx

# 手动模式（每个工作流完成后需确认）
/dev manual https://trip.larkenterprise.com/wiki/xxx
```

### 🧠 RIPER-5 通用工作流

**适用场景**：

- 复杂的项目重构
- 系统架构设计
- 任何需要严格控制的任务

**核心理念**：

RIPER-5 是一个**元工作流协议**，定义了 AI 如何系统性地工作：

```
R - Research（研究）：充分理解问题
I - Innovate（创新）：探索多种方案
P - Plan（规划）：制定详细计划
E - Execute（执行）：严格按计划实施
R - Review（审查）：验证与计划一致性
```

**五大原则**：

1. **模式声明**：每次响应必须声明当前模式
2. **严格分阶段**：不允许跨阶段操作
3. **禁止偏离**：Execute 阶段必须 100% 遵循 Plan
4. **证据驱动**：每个决策都要有证据
5. **偏差检测**：Review 阶段必须标记所有偏差

**详细文档**：参见 `.cursor/rules/workflow/common/RIPER-5.md`

<br>

## 🏗️ 上下文体系

### 分层架构

Airules 采用分层的上下文组织方式：

```
.cursor/rules/
├── common/          # 🌐 通用层
│   ├── general.md       # 通用开发原则
│   ├── document.md      # 文档规范
│   ├── git.md           # Git 提交规范
│   └── gitflow.md       # Git 分支管理
│
├── languages/       # 💻 语言层
│   └── java.md          # Java 语言规范与最佳实践
│
├── frameworks/      # 🔧 框架层
│   ├── ctrip-frameworks.md  # 携程技术框架总览
│   ├── dal.md               # DAL 数据访问层
│   ├── soa.md               # SOA 服务框架
│   └── member-common.md     # 会员公共组件
│
├── project/         # 📦 项目层
│   ├── overview.md      # 项目概述（AI 生成）
│   └── dev-guide.md     # 开发规范（AI 生成）
│
└── workflow/        # ⚙️ 工作流层
    ├── common/          # 通用工作流协议
    │   └── RIPER-5.md       # RIPER-5 元工作流
    ├── requirement-review/  # 需求评审工作流
    ├── tech-design/         # 技术设计工作流
    └── coding/              # 代码生成工作流
```

### 各层职责

| 层级               | 职责                     | 示例内容                         | 适用范围         |
| ------------------ | ------------------------ | -------------------------------- | ---------------- |
| **通用层**   | 所有项目共享的基础规范   | 文档规范、Git 规范、通用开发原则 | 全局             |
| **语言层**   | 特定编程语言的知识和规范 | Java 特性、最佳实践、常见陷阱    | 使用该语言的项目 |
| **框架层**   | 特定技术框架的使用规范   | Spring 使用、DAL 规范、SOA 接口  | 使用该框架的项目 |
| **项目层**   | 具体项目的业务知识       | 项目架构、业务逻辑、DDD 分层     | 当前项目         |
| **工作流层** | 任务执行的方法论         | RIPER-5、需求评审流程、编码流程  | 特定任务场景     |

### 上下文组合机制

每个工作流通过 `context-map.yaml` 定义所需的上下文：

**示例：编码工作流的上下文映射**

```yaml
# .cursor/rules/workflow/coding/context-map.yaml
version: 1.0
workflow: coding-workflow

includes:
  # 加载通用规范
  - ../../common/general.md
  
  # 加载语言知识
  - ../../languages/java.md
  
  # 加载框架规范
  - ../../frameworks/ctrip-frameworks.md
  - ../../frameworks/dal.md
  - ../../frameworks/soa.md
  
  # 加载项目知识
  - ../../project/overview.md
  - ../../project/dev-guide.md

excludes:
  # 排除无关语言
  - ../../languages/python.md
```

**工作原理**：

```
用户执行：/coding auto 需求文档

1. 命令路由器识别命令
2. 读取 context-map.yaml
3. 加载 includes 中的所有规则文件
4. 排除 excludes 中的内容
5. 组装完整上下文
6. 启动编码工作流
```

这样实现了：

- ✅ **按需加载**：只加载任务相关的上下文
- ✅ **自动组合**：无需手动拼接上下文
- ✅ **避免冲突**：通过 excludes 排除矛盾信息
- ✅ **灵活配置**：可轻松调整上下文组合

### 生成项目规则

对于新项目，可以使用 AI 自动生成项目层规则：

**步骤 1：触发生成**

```
/Generate Cursor Rules AUTO MODE 
请深入分析当前项目,并根据已有 cursor rule 生成当前项目的 project rule,
生成的 project rule 需要放到 `.cursor/rules/project` 目录下。

Project rule 需要包含两个文件：
- 文件1：项目概述 (overview.md) - 描述整个项目的业务逻辑
- 文件2：开发规范 (dev-guide.md) - 项目的技术栈、架构、DDD 分层等
```

**步骤 2：AI 分析项目**

AI 会：

- 扫描代码结构
- 分析技术栈
- 识别业务模式
- 推断架构设计

**步骤 3：生成规则文件**

```
.cursor/rules/project/
├── overview.md      # 项目概述
│   ├─ 项目背景
│   ├─ 核心业务流程
│   ├─ 关键模块说明
│   └─ 数据模型
│
└── dev-guide.md     # 开发规范
    ├─ 技术栈清单
    ├─ 项目架构
    ├─ DDD 分层规范
    ├─ 模块划分
    └─ 开发示例
```

**好处**：

- ✅ 自动提取项目知识，无需手动编写
- ✅ 后续开发 AI 会自动遵循这些规范
- ✅ 团队新人也能快速了解项目

<br>

## 💡 进阶使用

### 自动模式 vs 手动模式

每个工作流支持两种执行模式：

**自动模式（auto）**

```bash
/req auto https://xxx
/tech auto 需求文档
/coding auto 需求文档
```

特点：

- ✅ 各阶段自动连续执行，无需人工干预
- ✅ 适合标准流程、低风险任务
- ✅ 执行速度快

质量保证：

- P0 问题自动回退重新规划
- P1/P2 问题记录假设后继续
- 所有决策都有审计日志

**手动模式（manual）**

```bash
/req manual https://xxx
/tech manual 需求文档
/coding manual 需求文档
```

特点：

- 🛑 每个阶段完成后暂停，等待人工确认
- 🛑 适合复杂任务、高风险操作
- 🛑 可在任何阶段介入调整

确认方式：

```
AI: [STAGE: Research] 完成，是否进入 Innovation 阶段？
你: NEXT MODE  （或直接说"继续"）
```

**选择建议**：

| 场景         | 推荐模式 | 理由                 |
| ------------ | -------- | -------------------- |
| 标准需求评审 | auto     | 流程标准化，风险低   |
| 复杂架构设计 | manual   | 需要仔细审查每个阶段 |
| 日常功能开发 | auto     | 提升效率             |
| 核心代码重构 | manual   | 高风险，需人工把关   |

### 阶段推进机制

**阶段声明格式**：

每次 AI 响应的第一行会声明当前状态：

```
[STAGE: Research] | [Coding_Workflow] | [Auto]
│       │                  │              │
│       │                  │              └─ 执行模式
│       │                  └─ 工作流名称
│       └─ 当前阶段
└─ 固定标识
```

**阶段推进信号**：

在手动模式下，使用以下信号推进：

| 信号                | 作用                 | 示例                   |
| ------------------- | -------------------- | ---------------------- |
| `NEXT MODE`       | 进入下一个阶段       | Research → Innovation |
| `NEXT STAGE`      | 同上（别名）         | Innovation → Plan     |
| `ENTER PLAN MODE` | 直接跳转到 Plan 阶段 | 任意阶段 → Plan       |
| `CONTINUE`        | 继续当前任务         | 执行下一个子任务       |

**阶段质量门禁**：

每个阶段结束时会检查质量门禁：

```
Research 阶段结束：
  ├─ 检查：证据覆盖率 >= 95%？
  ├─ 检查：P0/P1 澄清完成率 = 100%？
  └─ 通过 → 可进入 Innovation
      未通过 → 回退重新执行 Research
```

### 自定义命令

你可以创建自定义的斜杠命令。

**步骤 1：创建命令文件**

在 `.cursor/commands/` 目录创建新命令文件：

```markdown
---
description: "我的自定义命令"
argument-hint: "需要的参数说明"
---

基于用户输入 $ARGUMENTS，执行自定义工作流。

具体流程：
1. ...
2. ...
```

**步骤 2：注册命令**

在 `.cursor/rules/commond.yaml` 中注册：

```yaml
commands:
  mycmd:
    workflow: my-workflow
    contextEntrance: workflows/my-workflow/context-map.yaml
    description: "我的自定义命令"
```

**步骤 3：使用命令**

```bash
/mycmd auto 参数
```

### 最佳实践

#### 1. 合理使用工作流组合

```bash
# ❌ 不好：分散执行
/req auto prd_link
等待完成...
/tech auto 功能点文档
等待完成...
/coding auto 需求文档

# ✅ 更好：使用组合命令
/dev auto prd_link
```

#### 2. 重视 Research 阶段

不要急于执行，充分的研究分析能避免返工：

```bash
# 手动模式，仔细审查 Research 结果
/coding manual 需求文档

# 审查 Research 输出后再继续
NEXT MODE
```

#### 3. 维护项目规则

定期更新项目层规则，保持知识库新鲜：

```bash
# 项目架构调整后，重新生成项目规则
/Generate Cursor Rules AUTO MODE
```

#### 4. 善用证据追溯

当 AI 的结论不确定时，要求提供证据：

```
你: 为什么认为订单需要支持多币种？
AI: 
  Claim: 订单需要支持多币种
  Evidence: PRD § 4.3 "国际化需求" → "支持美元、欧元、人民币结算"
  Anchor: PRD 第 4.3 节
```

#### 5. 控制上下文大小

不要加载过多无关上下文，保持精准：

```yaml
# ❌ 加载所有语言
includes:
  - ../../languages/java.md
  - ../../languages/python.md
  - ../../languages/go.md

# ✅ 只加载需要的
includes:
  - ../../languages/java.md
```

<br>

## ❓ 常见问题

### 安装相关

**Q1: 执行安装脚本时提示 "command not found: git"**

A: 你的系统未安装 Git，请先安装：

- Windows: 下载 [Git for Windows](https://git-scm.com/download/win)
- macOS: `brew install git`
- Linux: `sudo apt-get install git` 或 `sudo yum install git`

**Q2: Windows 下执行脚本失败**

A: 请使用 Git Bash 执行脚本，而非 CMD 或 PowerShell：

1. 右键项目文件夹
2. 选择 "Git Bash Here"
3. 执行安装命令

**Q3: 安装完成后 Cursor 中看不到命令**

A: 请尝试：

1. 重启 Cursor
2. 检查 `.cursor/commands/` 目录是否存在
3. 检查 Cursor 设置中是否启用了自定义命令

### 使用相关

**Q4: 执行 /req 命令时提示找不到 feishu2md MCP 工具**

A: 需要先配置 feishu2md MCP 工具：

1. 参考文档：https://trip.larkenterprise.com/wiki/GMsdwi5Zvin7ImkU2f4csY0enVg
2. 在 `~/.cursor/mcp.json` 中添加配置
3. 重启 Cursor

**Q5: 工作流执行到一半停止了**

A: 可能原因：

- 触发了质量门禁（P0 问题）
- AI 等待澄清
- 网络超时

解决方法：

- 查看最后的阶段声明，了解停在哪里
- 如果是 P0 问题，需要先解决问题
- 如果超时，可以用 `CONTINUE` 继续执行

**Q6: 生成的代码不符合预期**

A: 检查：

1. 是否加载了正确的项目规则？
2. Plan 阶段的规划是否准确？（手动模式可以在 Plan 阶段审查）
3. 是否需要更新项目层规则？

**Q7: 如何查看工作流的详细日志？**

A: 工作流执行时会生成任务文件：

```
.tasks/任务名_时间戳/
├── task/
│   └── yyyyMMdd_task.md   # 详细执行日志
└── execution/
    └── 输出文件
```

### 配置相关

**Q8: 如何调整上下文加载？**

A: 修改工作流的 `context-map.yaml`：

```yaml
# 例如：为编码工作流添加新的框架规则
includes:
  - ../../frameworks/my-framework.md
```

**Q9: 如何禁用某个规则文件？**

A: 在 `context-map.yaml` 的 `excludes` 中添加：

```yaml
excludes:
  - ../../frameworks/unwanted.md
```

**Q10: 如何为团队定制 Airules？**

A:

1. Fork 本仓库
2. 在 `rules/common/` 中添加团队通用规范
3. 在 `rules/frameworks/` 中添加团队技术栈
4. 更新 `setup-ai-rules.sh` 中的仓库地址
5. 团队成员使用新的安装命令

<br>

`<br>`

---

<div align="center">

**让 AI 编程更可控、更高效、更可靠**

[快速开始](#-快速上手) · [工作流详解](#-工作流详解) · [常见问题](#-常见问题)

</div>
