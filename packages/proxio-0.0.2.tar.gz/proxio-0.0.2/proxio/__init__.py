__version__ = "0.0.2"  # Hatch will update this


def version() -> str:
    """Returns the current version."""
    return __version__
