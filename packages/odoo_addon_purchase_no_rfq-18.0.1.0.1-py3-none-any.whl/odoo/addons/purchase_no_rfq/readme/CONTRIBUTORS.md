- Sylvain LE GAL \<<https://twitter.com/legalsylvain>\>
- [Binhex](https://binhex.cloud/):
    -   Deriman Alonso
- [Heliconia Solutions Pvt. Ltd.](https://www.heliconia.io)
  - Bhavesh Heliconia


- Alejandro Parrales \<<alejandro17parrales@gmail.com>\>