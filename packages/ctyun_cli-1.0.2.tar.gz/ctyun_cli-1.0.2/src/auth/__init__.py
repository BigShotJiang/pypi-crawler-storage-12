"""认证模块"""

from .signature import CTYUNAuth

__all__ = ['CTYUNAuth']