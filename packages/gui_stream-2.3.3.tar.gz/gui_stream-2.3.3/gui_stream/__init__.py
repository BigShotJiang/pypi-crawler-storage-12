#!/usr/bin/env python3

from gui_stream._version import version

