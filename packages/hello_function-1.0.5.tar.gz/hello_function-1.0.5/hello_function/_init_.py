def Hello():
    print("Library succesfully worked..")
