import * as React from 'react';

interface IReplayLoadingOverlayProps {
  isVisible: boolean;
}

/**
 * Full-page loading overlay for replay mode
 * Shows "Loading SignalPilot demo..." with an animated spinner
 */
export function ReplayLoadingOverlay({
  isVisible
}: IReplayLoadingOverlayProps): JSX.Element | null {
  if (!isVisible) {
    return null;
  }

  return (
    <div className="sage-replay-loading-overlay">
      <div className="sage-replay-loading-content">
        <div className="sage-replay-loading-spinner">
          <svg
            className="sage-replay-spinner-svg"
            viewBox="0 0 50 50"
            xmlns="http://www.w3.org/2000/svg"
          >
            <circle
              className="sage-replay-spinner-path"
              cx="25"
              cy="25"
              r="20"
              fill="none"
              strokeWidth="4"
            />
          </svg>
        </div>
        <div className="sage-replay-loading-text">
          Loading SignalPilot demo...
        </div>
      </div>
    </div>
  );
}
