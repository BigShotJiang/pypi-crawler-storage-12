# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

# NOTE: This contains adapters that make the Promptflow dependency optional. In the first phase,
#       Promptflow will still be installed as part of the azure-ai-evaluation dependencies. This
#       will be removed in the future once the code migration is complete.
