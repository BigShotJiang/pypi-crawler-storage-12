from .embedder import AutoEmbedder as AutoEmbedder
