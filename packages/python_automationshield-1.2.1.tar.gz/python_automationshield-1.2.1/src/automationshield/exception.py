class AutomationShieldException(Exception):
    pass