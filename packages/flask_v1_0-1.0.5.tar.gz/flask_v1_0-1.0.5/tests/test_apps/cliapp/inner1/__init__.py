from flask import Flask

application = Flask(__name__)
