"""
DevLake MCP Server

一个用于 DevLake 的 Model Context Protocol 服务器。
"""

__version__ = "0.4.1"
