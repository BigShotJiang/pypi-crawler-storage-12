# onyx-engine

Optimize AI models for hardware simulation and control while the Engine automatically traces every step. We built the Engine to be the fastest platform for teams to turn data into performant, deployable models.

Get started with our [documentation.](<https://docs.onyx-robotics.com/>)