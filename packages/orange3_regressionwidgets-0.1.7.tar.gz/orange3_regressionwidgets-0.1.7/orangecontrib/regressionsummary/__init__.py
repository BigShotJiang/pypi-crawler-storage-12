# This file only needs to expose the help path if you're including documentation.
WIDGET_HELP_PATH = (
     "orangecontrib.regressionsummary.widgets",
     "docs/index.html",
 )
