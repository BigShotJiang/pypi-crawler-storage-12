import unittest

class Test(unittest.TestCase):

	def test(self):
		self.assertEqual(4, 4)

if __name__ == '__main__':
    unittest.main()