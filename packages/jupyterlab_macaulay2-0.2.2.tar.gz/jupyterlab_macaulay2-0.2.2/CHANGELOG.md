## version 0.2.2

- Release date: 2025-11-16
- Update symbols for Macaulay2 1.25.11

## version 0.2.1

- Release date: 2025-05-16
- Update symbols for Macaulay2 1.25.05

## version 0.2.0

- Release date: 2025-03-27
- Left-align PRE elements
- Syntax-highlight CODE elements

## version 0.1.0

- Release date: 2025-03-03
- Initial release
