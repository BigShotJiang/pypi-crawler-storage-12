
class DataNotFoundError(Exception):
    """Custom exception for when data is not found."""
    pass
