let induction-11div10tonmn1ton = `!n. 11 divides num_of_int (&(10 EXP n) - (-- &1) pow n)`;;
