let algebra-sqineq-at2malt1 = `!a:real. a * (&2 - a) <= &1`;;
