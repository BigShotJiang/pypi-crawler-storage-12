let mathb-algebra-44 = `!s t. s = &9 - &2 * t /\ t = &3 * s + &1 ==> s = &1 /\ t = &4`;;
