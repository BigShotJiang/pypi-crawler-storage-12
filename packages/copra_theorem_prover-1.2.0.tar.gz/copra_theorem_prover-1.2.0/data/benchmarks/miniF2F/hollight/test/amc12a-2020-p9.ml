let amc12a-2020-p9 = `(FINITE {x:real | (&0 <= x) /\ (x <= &2 * pi) /\ (tan (&2 * x) = cos (x / &2))})
==>
    (CARD {x:real | (&0 <= x) /\ (x <= &2 * pi) /\ (tan (&2 * x) = cos (x / &2))} = 5)
`;;
