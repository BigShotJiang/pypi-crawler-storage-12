let algebra-amgm-sumasqdivbgeqsuma = `!a b c d. &0 < a /\ &0 < b /\ &0 < c /\ &0 < d ==> a pow 2 / b + b pow 2 / c + c pow 2 / d + d pow 2 / a >= a + b + c + d`;;
