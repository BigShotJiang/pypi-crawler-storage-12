let amc12a-2002-p13 = `!a b. (&0 < a /\ &0 < b) /\ ~(a = b) /\ (abs (a - &1 / a) = &1) /\ (abs (b - &1 / b) = &1) ==> a + b = sqrt(&5)`;;
