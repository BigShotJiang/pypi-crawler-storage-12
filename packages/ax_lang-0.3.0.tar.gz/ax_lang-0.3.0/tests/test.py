def test_eval(ax_lang):
    assert ax_lang.eval(1) == 1
