"""Version information for mcp_compose."""

__version__ = "0.1.1"
