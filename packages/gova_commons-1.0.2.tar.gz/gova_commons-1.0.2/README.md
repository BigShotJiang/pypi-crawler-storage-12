Common backend utilities

Package: https://pypi.org/project/gova-commons/