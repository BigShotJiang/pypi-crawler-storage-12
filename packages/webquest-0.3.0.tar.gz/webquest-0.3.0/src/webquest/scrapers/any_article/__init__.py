from webquest.scrapers.any_article.scraper import AnyArticle

__all__ = ["AnyArticle"]
