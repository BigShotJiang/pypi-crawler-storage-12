from webquest.scrapers.youtube_transcript.scraper import YouTubeTranscript

__all__ = ["YouTubeTranscript"]
