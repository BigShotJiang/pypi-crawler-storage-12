from webquest.scrapers.youtube_search.scraper import YouTubeSearch

__all__ = ["YouTubeSearch"]
