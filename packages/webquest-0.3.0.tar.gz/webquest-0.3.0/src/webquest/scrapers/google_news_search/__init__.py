from webquest.scrapers.google_news_search.scraper import GoogleNewsSearch

__all__ = ["GoogleNewsSearch"]
