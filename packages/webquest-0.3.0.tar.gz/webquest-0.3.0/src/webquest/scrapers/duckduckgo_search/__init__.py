from webquest.scrapers.duckduckgo_search.scraper import DuckDuckGoSearch

__all__ = ["DuckDuckGoSearch"]
