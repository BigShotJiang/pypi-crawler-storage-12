from pwcp import main


main(
    [
        # "--prefer-py",
        "tests/test_modules.ppy"
    ]
)
