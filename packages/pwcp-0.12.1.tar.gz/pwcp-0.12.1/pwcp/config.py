FILE_EXTENSIONS = [".ppy"]

add_file_extension = FILE_EXTENSIONS.append
