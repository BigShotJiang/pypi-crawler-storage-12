"""Smart Gesture Package

"""

from . import alphabet

__all__ = ["alphabet"]
