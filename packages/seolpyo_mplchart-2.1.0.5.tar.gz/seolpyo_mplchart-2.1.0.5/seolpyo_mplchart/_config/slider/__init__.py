from .config import SLIDERCONFIG, SLIDERCONFIG_EN, SliderConfigData

