

class Nav:
    def __init__(self):
        self.edgecolor = '#2962FF'
        self.facecolor = '#0000002E'
        self.alpha = 0.18

NAV = Nav()

