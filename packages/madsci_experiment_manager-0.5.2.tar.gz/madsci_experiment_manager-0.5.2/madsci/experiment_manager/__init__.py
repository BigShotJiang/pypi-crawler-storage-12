"""The MADSci Experiment Manager."""
