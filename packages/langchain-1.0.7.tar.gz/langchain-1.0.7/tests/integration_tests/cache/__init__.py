"""All integration tests for Cache objects."""
