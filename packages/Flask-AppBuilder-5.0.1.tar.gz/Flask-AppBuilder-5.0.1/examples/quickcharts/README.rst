Google charts Example
---------------------

Simple application using Google charts. Will insert random data on init.

Run it::

    $ export FLASK_APP=app/__init__.py
    $ flask fab create-admin
    $ flask run

