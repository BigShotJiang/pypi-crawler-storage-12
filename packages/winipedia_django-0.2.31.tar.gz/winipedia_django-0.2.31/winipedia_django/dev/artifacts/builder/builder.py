"""Build script.

All subclasses of Builder in the builds package are automatically called.
"""
