from .base import BeanieBaseController

__all__ = ["BeanieBaseController"]
