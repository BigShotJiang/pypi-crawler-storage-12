"""Allow running the CLI as: python -m deepagents.cli"""

from .main import cli_main

if __name__ == "__main__":
    cli_main()
