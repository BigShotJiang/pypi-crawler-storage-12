"""The entrypoint for the Hera Runner when running on Argo."""

from hera.workflows._runner.util import _run

if __name__ == "__main__":
    _run()
