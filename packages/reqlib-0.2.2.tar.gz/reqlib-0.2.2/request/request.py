import http.client
import json as jsonlib
import shlex, re, uuid
from urllib.parse import urlencode, urlparse, urljoin
from html.parser import HTMLParser
from html.parser import HTMLParser

class _AttrFinder(HTMLParser):
    def __init__(self, tag, attr_name):
        super().__init__()
        self.tag = tag
        self.attr_name = attr_name
        self.results = []

    def handle_starttag(self, tag, attrs):
        if tag == self.tag:
            attrs = dict(attrs)
            if self.attr_name in attrs:
                self.results.append(attrs[self.attr_name])


class _FormParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.values = {}
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "input":
            name = attrs.get("name")
            value = attrs.get("value", "")
            if name:
                self.values[name] = value
        elif tag == "textarea":
            name = attrs.get("name")
            value = attrs.get("value", "")
            if name:
                self.values[name] = value
        elif tag == "select":
            name = attrs.get("name")
            if name:
                self.values[name] = attrs.get("value", "")

class HTMLFinder(HTMLParser):
    def __init__(self, tag, attr=None, value=None):
        super().__init__()
        self.tag = tag
        self.attr = attr
        self.value = value
        self.results = []
        self._capture = False
    def handle_starttag(self, tag, attrs):
        if tag == self.tag:
            if self.attr:
                for k, v in attrs:
                    if k == self.attr and (self.value is None or v == self.value):
                        self._capture = True
                        break
            else:
                self._capture = True
    def handle_endtag(self, tag):
        if tag == self.tag and self.__capture:
            self._capture = False
    def handle_data(self, data):
        if self._capture:
            self.results.append(data.strip())
from html.parser import HTMLParser

class _TagFinder(HTMLParser):
    def __init__(self, tag):
        super().__init__()
        self.tag = tag
        self.results = []

    def handle_starttag(self, tag, attrs):
        if tag == self.tag:
            self.results.append(dict(attrs))


    
class Response:
    def __init__(self, res, url, history=None):
        self.status = res.status
        self.headers = dict(res.getheaders())
        self._body = res.read()
        self.url = url
        self.cookies = {}
        self.history = history or []
        if "Set-Cookie" in self.headers:
            raw_cookie = self.headers["Set-Cookie"]
            for part in raw_cookie.split(";"):
                if "=" in part:
                    k, v = part.strip().split("=", 1)
                    self.cookies[k] = v
    def searchhtml(self, tag, attr=None, value=None):
        parser = HTMLFinder(tag, attr, value)
        parser.feed(self.text)
        return parser.results
    
    from html.parser import HTMLParser

    def gethtml(self, tag, attr_name=None):
        """
        يبحث في النص HTML عن كل العناصر من نوع tag.
        إذا أعطيت attr_name يرجع قائمة بالقيم لهذا الـ attribute.
        إذا ما أعطيت يرجع قائمة قواميس لكل الـ attributes.
        """
        parser = _TagFinder(tag)
        parser.feed(self.text)
        if attr_name:
            return [attrs.get(attr_name) for attrs in parser.results if attr_name in attrs]
        return parser.results
    @property
    def js(self):
        variables = {}
        scripts = re.findall(r"<script.*?>(.*?)</script>", self.text, re.S)
        for script in scripts:
            matches = re.findall(r"(?:var|let|const)\s+(\w+)\s*=\s*(.*?);", script)
            for k, v in matches:
                variables[k] = v.strip('"\' ')
        return variables
    @property
    def jsonhtml(self):
        found = []
        matches = re.findall(r"(\{.*?\}|\[.*?\])", self.text, re.S)
        for m in matches:
            try:
                obj = jsonlib.loads(m)
                found.append(obj)
            except Exception:
                continue
        return found
    @property
    def html(self):
        parser = _FormParser()
        parser.feed(self.text)
        return parser.values
    @property
    def text(self):
        return self._body.decode("utf-8", errors="ignore")
    def json(self):
        try:
            return jsonlib.loads(self.text)
        except jsonlib.JSONDecodeError:
            raise ValueError("Response body is not valid JSON")
    @property
    def content(self):
        return self._body
    @property
    def ok(self):
        return 200 <= self.status < 300

def _request(method, url, headers=None, cookies=None, data=None, json=None,
             files=None, params=None, timeout=10, proxies=None,
             allow_redirects=True, max_redirects=None, _redirect_count=0, _history=None):

    headers = headers or {}
    _history = _history or []

    # إضافة الكوكيز
    if cookies:
        cookie = "; ".join([f"{k}={v}" for k, v in cookies.items()])
        headers["Cookie"] = cookie

    # إضافة params
    if params:
        query = urlencode(params)
        if "?" in url:
            url += "&" + query
        else:
            url += "?" + query

    # تجهيز البيانات
    body = None
    if files:
        boundary = "----WebKitFormBoundary" + uuid.uuid4().hex
        parts = []
        if data:
            for k, v in data.items():
                parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n")
        for field, filepath in files.items():
            with open(filepath, "rb") as f:
                filedata = f.read()
            filename = filepath.split("/")[-1]
            parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{field}\"; filename=\"{filename}\"\r\nContent-Type: application/octet-stream\r\n\r\n")
            parts.append(filedata.decode("latin1") + "\r\n")
        parts.append(f"--{boundary}--\r\n")
        body = "".join(parts).encode("latin1")
        headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"
    elif json is not None:
        body = jsonlib.dumps(json).encode("utf-8")
        headers["Content-Type"] = "application/json"
    elif data is not None:
        if isinstance(data, dict):
            body = urlencode(data).encode("utf-8")
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        else:
            body = str(data).encode("utf-8")

    # تحليل الرابط
    parsed = urlparse(url)
    scheme = parsed.scheme
    host = parsed.netloc
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query

    # بروكسي
    if proxies and scheme in proxies:
        proxy_url = urlparse(proxies[scheme])
        proxy_host = proxy_url.hostname
        proxy_port = proxy_url.port
        if scheme == "https":
            conn = http.client.HTTPSConnection(proxy_host, proxy_port, timeout=timeout)
            conn.set_tunnel(host)
        else:
            conn = http.client.HTTPConnection(proxy_host, proxy_port, timeout=timeout)
            conn.set_tunnel(host)
    else:
        if scheme == "https":
            conn = http.client.HTTPSConnection(host, timeout=timeout)
        elif scheme == "http":
            conn = http.client.HTTPConnection(host, timeout=timeout)
        else:
            raise ValueError("Unsupported URL scheme")

    conn.request(method, path, body=body, headers=headers)
    res = conn.getresponse()

    # التعامل مع إعادة التوجيه
    if allow_redirects and res.status in (301, 302, 303, 307, 308):
        if max_redirects is not None and _redirect_count >= max_redirects:
            raise Exception("Too many redirects")
        location = res.getheader("Location")
        if location:
            location = urljoin(url, location)
            new_method = "GET" if res.status == 303 else method
            _history.append(Response(res, url, history=_history.copy()))
            return _request(new_method, location, headers=headers, cookies=cookies,
                            data=None, json=None, files=None, params=None, timeout=timeout,
                            proxies=proxies, allow_redirects=allow_redirects,
                            max_redirects=max_redirects, _redirect_count=_redirect_count+1, _history=_history)

    return Response(res, url, history=_history)

# دوال عامة
def get(url, headers=None, cookies=None, params=None,
        timeout=10, proxies=None,
        allow_redirects=True, max_redirects=None):
    return _request("GET", url,
                    headers=headers,
                    cookies=cookies,
                    params=params,
                    timeout=timeout,
                    proxies=proxies,
                    allow_redirects=allow_redirects,
                    max_redirects=max_redirects)

def post(url, headers=None, cookies=None, data=None, json=None, files=None, params=None,
         timeout=10, proxies=None,
         allow_redirects=True, max_redirects=None):
    return _request("POST", url,
                    headers=headers,
                    cookies=cookies,
                    data=data,
                    json=json,
                    files=files,
                    params=params,
                    timeout=timeout,
                    proxies=proxies,
                    allow_redirects=allow_redirects,
                    max_redirects=max_redirects)

def put(url, headers=None, cookies=None, data=None, json=None, files=None, params=None,
        timeout=10, proxies=None,
        allow_redirects=True, max_redirects=None):
    return _request("PUT", url,
                    headers=headers,
                    cookies=cookies,
                    data=data,
                    json=json,
                    files=files,
                    params=params,
                    timeout=timeout,
                    proxies=proxies,
                    allow_redirects=allow_redirects,
                    max_redirects=max_redirects)

def delete(url, headers=None, cookies=None, data=None, params=None,
           timeout=10, proxies=None,
           allow_redirects=True, max_redirects=None):
    return _request("DELETE", url,
                    headers=headers,
                    cookies=cookies,
                    data=data,
                    params=params,
                    timeout=timeout,
                    proxies=proxies,
                    allow_redirects=allow_redirects,
                    max_redirects=max_redirects)

def head(url, headers=None, cookies=None, params=None,
         timeout=10, proxies=None,
         allow_redirects=True, max_redirects=None):
    return _request("HEAD", url,
                    headers=headers,
                    cookies=cookies,
                    params=params,
                    timeout=timeout,
                    proxies=proxies,
                    allow_redirects=allow_redirects,
                    max_redirects=max_redirects)

def options(url, headers=None, cookies=None, params=None,
            timeout=10, proxies=None,
            allow_redirects=True, max_redirects=None):
    return _request("OPTIONS", url,
                    headers=headers,
                    cookies=cookies,
                    params=params,
                    timeout=timeout,
                    proxies=proxies,
                    allow_redirects=allow_redirects,
                    max_redirects=max_redirects)

def patch(url, headers=None, cookies=None, data=None, json=None, files=None, params=None,
          timeout=10, proxies=None,
          allow_redirects=True, max_redirects=None):
    return _request("PATCH", url,
                    headers=headers,
                    cookies=cookies,
                    data=data,
                    json=json,
                    files=files,
                    params=params,
                    timeout=timeout,
                    proxies=proxies,
                    allow_redirects=allow_redirects,
                    max_redirects=max_redirects)

def curl(curl_cmd):
    tokens = shlex.split(curl_cmd)
    method = "GET"
    headers = {}
    data = {}
    url = None
    cookies = {}
    files = {}

    i = 0
    while i < len(tokens):
        t = tokens[i]
        if t == "curl":
            i += 1
            continue
        elif t == "-X":
            method = tokens[i+1].upper()
            i += 2
        elif t in ("-H", "--header"):
            h = tokens[i+1]
            k, v = h.split(":", 1)
            headers[k.strip()] = v.strip()
            i += 2
        elif t == "-b":
            cookie_val = tokens[i+1]
            for part in cookie_val.split(";"):
                if "=" in part:
                    k, v = part.strip().split("=", 1)
                    cookies[k] = v
            i += 2
        elif t in ("-d", "--data", "--data-raw"):
            # بيانات عادية
            raw = tokens[i+1]
            if "=" in raw and "&" in raw:
                # نحولها dict
                for kv in raw.split("&"):
                    k, v = kv.split("=", 1)
                    data[k] = v
            else:
                data["_raw"] = raw
            if method == "GET":
                method = "POST"
            i += 2
        elif t == "-F":
            # رفع ملف أو حقل form-data
            form = tokens[i+1]
            if "=" in form:
                k, v = form.split("=", 1)
                if v.startswith("@"):
                    files[k] = v[1:]  # اسم الملف
                else:
                    data[k] = v
            if method == "GET":
                method = "POST"
            i += 2
        else:
            if not url and t.startswith("http"):
                url = t
            i += 1

    return _request(method, url, headers=headers, cookies=cookies, data=data, files=files)

