cb_name = 'increment'
print(f' onclick="handleClick(\'{cb_name.replace("'", "\\'")}\')"')