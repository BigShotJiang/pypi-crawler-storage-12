1.  Go to *Settings \> Gamification Tools \> Badges*.
2.  Open or create a new badge.
3.  Set an URL in Badge URL field if you want to link the badge on the
    website to a webpage.
4.  Set a 'Website Expiration Date' so the badge is not shown on the
    website after that date.
