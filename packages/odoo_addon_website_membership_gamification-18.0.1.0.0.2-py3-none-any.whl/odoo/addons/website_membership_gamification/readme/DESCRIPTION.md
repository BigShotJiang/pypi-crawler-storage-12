This module allows to see badges assigned to users on the Members page
in website. It also allows to set badges straight from contacts view.
