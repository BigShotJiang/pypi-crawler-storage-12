You can assign a badge to a contact from the contact form view. Only
contacts related to a user are allowed.
