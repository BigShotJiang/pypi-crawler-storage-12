from canopen_asyncio.node.local import LocalNode
from canopen_asyncio.node.remote import RemoteNode
