"""
Lyrics Client - Client library for interacting with the Lyrics Server.
"""

from .bash_client import BashClient

__all__ = ["BashClient"]
