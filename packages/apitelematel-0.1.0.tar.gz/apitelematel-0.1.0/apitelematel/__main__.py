"""Punto de entrada ejecutable del paquete apitelematel."""

from apitelematel.app import create_app


if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0")
