"""Punto de entrada principal para levantar la API con Flask."""

from flask import Flask

from .adapters.http.flask_app import register_routes
from .config.settings import load_settings


def create_app() -> Flask:
    """Construye la aplicación Flask con los componentes hexagonales conectados."""
    settings = load_settings()
    app = Flask(__name__)
    register_routes(app, settings)
    return app
