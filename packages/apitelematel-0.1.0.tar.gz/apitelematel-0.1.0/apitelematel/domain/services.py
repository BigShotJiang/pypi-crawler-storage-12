"""Servicios de dominio auxiliares."""

from apitelematel.domain.models import (
    AuthenticationError,
    QueryValidationError,
    QueryRequest,
)


class SecretValidator:
    """Valida que la clave enviada coincida con la esperada."""

    def __init__(self, expected: str):
        self.expected = expected

    def validate(self, provided: str):
        if not provided or provided != self.expected:
            raise AuthenticationError("Clave secreta inválida")


class QueryValidator:
    """Valida los requisitos mínimos de la consulta recibida."""

    def validate(self, request: QueryRequest):
        if not request.query or not request.query.strip():
            raise QueryValidationError("El campo 'query' es obligatorio.")

        # Evitar consultas vacías o peligrosas básicas
        if ";" in request.query:
            raise QueryValidationError("No se permiten múltiples sentencias.")
