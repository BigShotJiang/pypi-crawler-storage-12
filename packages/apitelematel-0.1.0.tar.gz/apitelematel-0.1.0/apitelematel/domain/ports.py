"""Puertos que definen las dependencias externas del dominio."""

from abc import ABC, abstractmethod

from apitelematel.domain.models import QueryRequest, QueryResult


class QueryRepository(ABC):
    """Interfaz para acceder a la base Progress."""

    @abstractmethod
    def execute(self, request: QueryRequest) -> QueryResult:
        raise NotImplementedError
