"""Entidades y errores del dominio de la API."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class QueryRequest:
    """Representa la petición válida que proviene del adaptador HTTP."""

    query: str
    max_rows: Optional[int] = None
    timeout: Optional[int] = None
    connection_key: Optional[str] = None


@dataclass
class QueryRow:
    """Dato individual devuelto por Progress."""

    values: Dict[str, Any] = field(default_factory=dict)


@dataclass
class QueryResult:
    """Respuesta del dominio con filas y metadatos."""

    rows: List[QueryRow]
    row_count: int = 0


class DomainError(Exception):
    """Base para errores específicos del dominio."""


class AuthenticationError(DomainError):
    """Se lanza cuando la clave secreta proporcionada es incorrecta."""


class QueryExecutionError(DomainError):
    """Se lanza cuando hay un fallo al ejecutar la consulta."""


class QueryValidationError(DomainError):
    """Se lanza cuando la petición no contiene una consulta válida."""
