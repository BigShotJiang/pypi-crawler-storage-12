"""Paquete principal que expone el factory de Flask sin importar dependencias pesadas."""

from importlib import import_module

__all__ = ["create_app"]


def create_app(*args, **kwargs):
    """Carga perezosamente el módulo principal para evitar efectos secundarios."""
    app_module = import_module(".app", __package__)
    return app_module.create_app(*args, **kwargs)
