"""Carga y valida la configuración mínima desde variables de entorno."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional

from dotenv import load_dotenv

load_dotenv(dotenv_path=Path(__file__).resolve().parents[1] / ".env", override=False)


@dataclass
class Settings:
    secret_key: str
    default_connection: Optional[str]
    named_connections: Dict[str, str] = field(default_factory=dict)
    query_timeout: int = 30

    def get_connection_string(self, alias: Optional[str]) -> str:
        if alias:
            normalized = alias.lower()
            candidate = self.named_connections.get(normalized)
            if candidate:
                return candidate
            raise RuntimeError(f"DSN desconocido: {alias}")

        if self.default_connection:
            return self.default_connection

        if self.named_connections:
            # seleccionar la primera conexión registrada
            return next(iter(self.named_connections.values()))

        raise RuntimeError("No hay conexiones ODBC configuradas.")


def _build_connection_string() -> Optional[str]:
    explicit = os.getenv("PROGRESS_CONN_STR", "").strip()
    if explicit:
        return explicit

    dsn = os.getenv("PROGRESS_DSN", "").strip()
    if not dsn:
        return None

    parts = [f"DSN={dsn}"]
    user = os.getenv("PROGRESS_USER")
    password = os.getenv("PROGRESS_PASSWORD")
    if user:
        parts.append(f"UID={user}")
    if password:
        parts.append(f"PWD={password}")

    return ";".join(parts)


def _collect_named_connections() -> Dict[str, str]:
    prefix = "PROGRESS_CONN_"
    result: Dict[str, str] = {}
    for key, value in os.environ.items():
        if not key.startswith(prefix):
            continue
        suffix = key[len(prefix) :].strip()
        if not suffix or suffix == "STR":
            continue
        result[suffix.lower()] = value.strip()
    return result


def _parse_int(value: Optional[str], default: int) -> int:
    try:
        return int(value) if value is not None else default
    except ValueError:
        return default


def load_settings() -> Settings:
    """Lee las variables de entorno necesarias y aplica valores por defecto."""
    secret_key = os.getenv("SECRET_KEY", "").strip()
    if not secret_key:
        raise RuntimeError("La variable SECRET_KEY es obligatoria.")

    default_connection = _build_connection_string()
    named_connections = _collect_named_connections()

    if not default_connection and not named_connections:
        raise RuntimeError(
            "Debe proporcionar al menos PROGRESS_CONN_STR o alguna PROGRESS_CONN_<NOMBRE>."
        )

    timeout_str = os.getenv("QUERY_TIMEOUT")
    query_timeout = _parse_int(timeout_str, 30)

    return Settings(
        secret_key=secret_key,
        default_connection=default_connection,
        named_connections=named_connections,
        query_timeout=query_timeout,
    )
