"""Fábrica de conexiones ODBC hacia Progress OpenEdge."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

try:
    import pyodbc  # type: ignore[attr-defined]
except ImportError as error:  # pragma: no cover - ODBC solo en servidor
    pyodbc = None  # type: ignore[assignment]
    _PYODBC_IMPORT_ERROR = error
else:
    _PYODBC_IMPORT_ERROR = None


@dataclass
class ODBCConnectionConfig:
    connection_string: str
    timeout: int


class ODBCConnection:
    """Representa una conexión ligera para ejecutar consultas."""

    def __init__(self, config: ODBCConnectionConfig):
        self.config = config

    def execute(
        self, query: str, *, timeout: Optional[int] = None, max_rows: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Ejecuta la consulta usando pyodbc y devuelve filas como diccionarios."""
        if pyodbc is None:
            raise RuntimeError(
                "pyodbc no está disponible en este entorno. Instala pyodbc y las dependencias ODBC."
            )
        effective_timeout = timeout or self.config.timeout
        with pyodbc.connect(self.config.connection_string, timeout=effective_timeout) as conn:
            cursor = conn.cursor()
            cursor.execute(query)
            columns = [column[0] for column in cursor.description or []]
            if max_rows:
                fetched = cursor.fetchmany(max_rows)
            else:
                fetched = cursor.fetchall()

            return [
                dict(zip(columns, row)) if columns else {"row": row}
                for row in fetched
            ]


def create_connection(connection_string: str, timeout: int):
    """Construye la configuración de conexión para una cadena concreta."""
    config = ODBCConnectionConfig(
        connection_string=connection_string,
        timeout=timeout,
    )
    return ODBCConnection(config)
