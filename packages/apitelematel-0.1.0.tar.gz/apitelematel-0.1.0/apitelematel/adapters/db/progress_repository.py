"""Repositorio que ejecuta consultas usando la conexión ODBC."""

from apitelematel.config.settings import Settings
from apitelematel.domain.models import QueryRequest, QueryResult, QueryRow
from apitelematel.domain.ports import QueryRepository
from apitelematel.infrastructure.odbc_connection import create_connection


class ProgressRepository(QueryRepository):
    """Implementación concreta del puerto hacia Progress OpenEdge."""

    def __init__(self, settings: Settings):
        self.settings = settings

    def execute(self, request: QueryRequest) -> QueryResult:
        """Ejecuta la consulta delegando en la conexión."""
        connection_string = self.settings.get_connection_string(request.connection_key)
        connection = create_connection(connection_string, self.settings.query_timeout)
        raw_rows = connection.execute(
            request.query, timeout=request.timeout, max_rows=request.max_rows
        )
        rows = [QueryRow(values=row) for row in raw_rows]
        return QueryResult(rows=rows, row_count=len(rows))
