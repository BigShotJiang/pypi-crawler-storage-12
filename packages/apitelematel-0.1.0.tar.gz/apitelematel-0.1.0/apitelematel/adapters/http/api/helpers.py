"""Utilidades comunes para los adaptadores HTTP por versión."""

from typing import Any, Optional


def parse_optional_int(value: Any) -> Optional[int]:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def parse_connection_key(value: Any) -> Optional[str]:
    if not value:
        return None
    return str(value).strip()
