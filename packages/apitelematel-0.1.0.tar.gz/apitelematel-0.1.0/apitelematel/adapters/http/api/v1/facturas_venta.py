"""Rutas de facturas de venta para la versión v1.0."""

from flask import jsonify, request

from apitelematel.adapters.http.api.helpers import parse_connection_key, parse_optional_int
from apitelematel.domain.models import (
    AuthenticationError,
    QueryExecutionError,
    QueryRequest,
    QueryValidationError,
)


def register_facturas_routes(version_blueprint, use_case, logger):
    """Añade los endpoints de facturas de venta."""

    def facturas_por_numero():
        try:
            num_fac_value = request.args.get("num_fac")
            num_fac = int(num_fac_value)
        except (TypeError, ValueError):
            return jsonify({"error": "num_fac debe ser un entero válido"}), 400

        connection_key = parse_connection_key(request.args.get("connection_key"))
        max_rows = parse_optional_int(request.args.get("max_rows"))
        timeout = parse_optional_int(request.args.get("timeout"))
        consulta = (
            f"SELECT f.* FROM PUB.gvfacab f WHERE f.num_fac={num_fac}"
            if num_fac
            else "SELECT f.num_fac, f.fec_fac, f.cod_cli FROM PUB.gvfacab f ORDER BY f.fec_fac DESC"
        )
        consulta_request = QueryRequest(
            query=consulta,
            max_rows=max_rows or 10,
            timeout=timeout,
            connection_key=connection_key,
        )

        try:
            resultado = use_case.run(request.headers.get("X-Secret-Key", ""), consulta_request)
        except AuthenticationError as error:
            logger.warning("Acceso denegado en facturas_venta: %s", error)
            return jsonify({"error": str(error)}), 401
        except QueryExecutionError as error:
            logger.error("Error ejecutando consulta de factura: %s", error)
            return jsonify({"error": "No se pudo ejecutar la consulta"}), 500
        except QueryValidationError as error:
            logger.warning("Petición inválida en facturas_venta: %s", error)
            return jsonify({"error": str(error)}), 400

        filas = [fila.values for fila in resultado.rows]
        respuesta = {"row_count": resultado.row_count}
        if resultado.row_count == 1:
            respuesta["row"] = filas[0]
            respuesta["rows"] = []
        else:
            respuesta["row"] = {}
            respuesta["rows"] = filas
        return jsonify(respuesta), 200

    version_blueprint.add_url_rule(
        "/facturas_venta", view_func=facturas_por_numero, methods=["GET"]
    )
