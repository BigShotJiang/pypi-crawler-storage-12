"""Rutas centradas en clientes para la versión v1.0 de la API."""

from flask import jsonify, request

from apitelematel.adapters.http.api.helpers import (
    parse_connection_key,
    parse_optional_int,
)
from apitelematel.domain.models import (
    AuthenticationError,
    QueryExecutionError,
    QueryRequest,
    QueryValidationError,
)


def register_client_routes(version_blueprint, use_case, logger):
    """Añade las rutas de clientes a la versión v1.0."""

    def cliente_por_codigo():
        try:
            cod_cli_value = request.args.get("cod_cli")
            cod_cli = int(cod_cli_value)
        except (TypeError, ValueError):
            return jsonify({"error": "cod_cli debe ser un entero válido"}), 400

        connection_key = parse_connection_key(request.args.get("connection_key"))
        max_rows = parse_optional_int(request.args.get("max_rows"))
        timeout = parse_optional_int(request.args.get("timeout"))
        consulta = (
            f"SELECT c.* FROM PUB.gmclien c WHERE c.cod_cli={cod_cli}"
            if cod_cli
            else "SELECT c.cod_cli, c.nom_cli, c.raz_cli FROM PUB.gmclien c ORDER BY c.cod_cli"
        )
        cliente_request = QueryRequest(
            query=consulta,
            max_rows=max_rows or 1,
            timeout=timeout,
            connection_key=connection_key,
        )

        try:
            resultado = use_case.run(request.headers.get("X-Secret-Key", ""), cliente_request)
        except AuthenticationError as error:
            logger.warning("Acceso denegado en cliente_por_codigo: %s", error)
            return jsonify({"error": str(error)}), 401
        except QueryExecutionError as error:
            logger.error("Error ejecutando consulta de cliente: %s", error)
            return jsonify({"error": "No se pudo ejecutar la consulta"}), 500
        except QueryValidationError as error:
            logger.warning("Petición inválida en cliente_por_codigo: %s", error)
            return jsonify({"error": str(error)}), 400

        filas = [fila.values for fila in resultado.rows]
        respuesta = {"row_count": resultado.row_count}
        if resultado.row_count == 1:
            respuesta["row"] = filas[0]
            respuesta["rows"] = []
        else:
            respuesta["row"] = {}
            respuesta["rows"] = filas
        return jsonify(respuesta), 200

    version_blueprint.add_url_rule("/clientes", view_func=cliente_por_codigo, methods=["GET"])
    return cliente_por_codigo
