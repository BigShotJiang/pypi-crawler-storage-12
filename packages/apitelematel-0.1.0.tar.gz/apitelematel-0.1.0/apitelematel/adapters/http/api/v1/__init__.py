"""Módulo que agrupa las rutas de la versión v1.0."""

from . import clientes  # noqa: F401
