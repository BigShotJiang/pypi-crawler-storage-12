"""Adaptador HTTP que expone los endpoints REST mediante Flask."""

from flask import Blueprint, Flask, jsonify, request

from apitelematel.adapters.db.progress_repository import ProgressRepository
from apitelematel.adapters.http.api.helpers import (
    parse_connection_key,
    parse_optional_int,
)
from apitelematel.adapters.http.api.v1.clientes import register_client_routes
from apitelematel.adapters.http.api.v1.facturas_venta import register_facturas_routes
from apitelematel.application.use_cases import ExecuteQueryUseCase
from apitelematel.domain.models import (
    AuthenticationError,
    QueryExecutionError,
    QueryRequest,
    QueryValidationError,
)
from apitelematel.infrastructure.logging import get_logger

logger = get_logger(__name__)


def register_routes(app: Flask, settings):
    """Construye los blueprints versionados y registra los endpoints principales."""
    repository = ProgressRepository(settings)
    use_case = ExecuteQueryUseCase(repository, settings.secret_key)

    version_blueprint = Blueprint("api_v1", __name__, url_prefix="/api/v1.0")
    cliente_view = register_client_routes(version_blueprint, use_case, logger)
    register_facturas_routes(version_blueprint, use_case, logger)

    query_view = _build_query_view(use_case, logger)
    app.add_url_rule("/query", endpoint="legacy_query", view_func=query_view, methods=["POST"])
    version_blueprint.add_url_rule("/query", endpoint="api_v1_query", view_func=query_view, methods=["POST"])

    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({"status": "healthy"}), 200

    app.add_url_rule("/api_v1.0/clientes", endpoint="legacy_clientes", view_func=cliente_view, methods=["GET"])
    app.register_blueprint(version_blueprint)


def _build_query_view(use_case, logger):
    def execute_query():
        provided_secret = request.headers.get("X-Secret-Key", "")
        payload_json = request.get_json(silent=True) or {}
        raw_query = payload_json.get("query", "")

        request_payload = QueryRequest(
            query=raw_query,
            max_rows=parse_optional_int(payload_json.get("max_rows")),
            timeout=parse_optional_int(payload_json.get("timeout")),
            connection_key=parse_connection_key(
                payload_json.get("connection_key") or payload_json.get("dsn")
            ),
        )
        try:
            resultado = use_case.run(provided_secret, request_payload)
        except AuthenticationError as error:
            logger.warning("Acceso denegado: %s", error)
            return jsonify({"error": str(error)}), 401
        except QueryExecutionError as error:
            logger.error("Error ejecutando consulta: %s", error)
            return jsonify({"error": "No se pudo ejecutar la consulta"}), 500
        except QueryValidationError as error:
            logger.warning("Payload inválido: %s", error)
            return jsonify({"error": str(error)}), 400

        respuesta = {
            "rows": [fila.values for fila in resultado.rows],
            "row_count": resultado.row_count,
        }
        return jsonify(respuesta), 200

    return execute_query
