"""Casos de uso orquestando la lógica del dominio."""

from apitelematel.domain.models import QueryExecutionError, QueryRequest, QueryResult
from apitelematel.domain.ports import QueryRepository
from apitelematel.domain.services import QueryValidator, SecretValidator


class ExecuteQueryUseCase:
    """Caso de uso para validar la clave y ejecutar la consulta."""

    def __init__(self, repository: QueryRepository, expected_secret: str):
        self.repository = repository
        self.secret_validator = SecretValidator(expected_secret)
        self.query_validator = QueryValidator()

    def run(self, provided_secret: str, request: QueryRequest) -> QueryResult:
        """Valida el secret, request y delega la ejecución al repositorio."""
        self.secret_validator.validate(provided_secret)
        self.query_validator.validate(request)

        try:
            return self.repository.execute(request)
        except Exception as error:
            raise QueryExecutionError("Error ejecutando la consulta") from error
