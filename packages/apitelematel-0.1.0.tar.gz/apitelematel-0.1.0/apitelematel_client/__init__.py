"""Cliente ligero para interactuar con la API de apitelematel."""

from .client import ApiTelematelClient

__all__ = ["ApiTelematelClient"]
