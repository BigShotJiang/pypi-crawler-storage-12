:tocdepth: 3

.. automodule:: guidata.io