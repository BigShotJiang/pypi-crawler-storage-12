:tocdepth: 3

.. automodule:: guidata.dataset.conv
