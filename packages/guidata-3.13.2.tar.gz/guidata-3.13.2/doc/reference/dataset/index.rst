Data set features
=================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   datatypes
   dataitems
   conv
   io
   qtwidgets