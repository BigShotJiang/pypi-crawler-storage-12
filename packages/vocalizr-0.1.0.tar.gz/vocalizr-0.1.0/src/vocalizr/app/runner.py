from vocalizr.app.builder import App
from vocalizr.app.settings import Settings

settings: Settings = Settings()
app: App = App(settings)
