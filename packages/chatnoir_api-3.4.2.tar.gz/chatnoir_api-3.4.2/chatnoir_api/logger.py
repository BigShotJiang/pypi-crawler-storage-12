from logging import getLogger

logger = getLogger("chatnoir-api")
