BASE_URL = "https://chatnoir.eu/"
BASE_URL_WEBCONTENT = "https://chatnoir-webcontent.chatnoir.eu/"
