function n(t,o){let e;return function(...u){clearTimeout(e),e=setTimeout(()=>t(...u),o)}}export{n as d};
