const s=globalThis.__sveltekit_1f1rmn0?.base??"",a=globalThis.__sveltekit_1f1rmn0?.assets??s??"";export{a,s as b};
