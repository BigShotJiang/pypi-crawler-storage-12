import{l as o,b as r}from"../chunks/DrAxT0oh.js";export{o as load_css,r as start};
