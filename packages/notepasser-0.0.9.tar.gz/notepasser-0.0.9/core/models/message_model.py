class MessageModel:
    def __init__(self, user_verify_key,  message):
        self.user_verify_key = user_verify_key
        self.message = message