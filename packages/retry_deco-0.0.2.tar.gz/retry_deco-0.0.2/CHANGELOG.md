## 0.0.2 (2025-11-14)
- add async support
