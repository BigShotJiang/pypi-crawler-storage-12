# chroma-haystack

[![PyPI - Version](https://img.shields.io/pypi/v/chroma-haystack.svg)](https://pypi.org/project/chroma-haystack)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/chroma-haystack.svg)](https://pypi.org/project/chroma-haystack)

- [Integration page](https://haystack.deepset.ai/integrations/chroma-documentstore)
- [Changelog](https://github.com/deepset-ai/haystack-core-integrations/blob/main/integrations/chroma/CHANGELOG.md)

---

## Contributing

Refer to the general [Contribution Guidelines](https://github.com/deepset-ai/haystack-core-integrations/blob/main/CONTRIBUTING.md).
