from .core import Core

if __name__ == "__main__":
    Core.start()
