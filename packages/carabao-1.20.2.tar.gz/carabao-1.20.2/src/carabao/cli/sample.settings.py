from carabao import Settings as S


class Settings(S):
    LANE_DIRECTORIES = [
        "LANE_DIRECTORY",
    ]
