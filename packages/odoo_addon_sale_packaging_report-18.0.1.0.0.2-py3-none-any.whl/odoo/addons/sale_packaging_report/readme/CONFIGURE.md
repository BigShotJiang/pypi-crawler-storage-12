To configure this module, you need to:

1.  Go to *Sales \> Configuration \> Settings*.
2.  Enable *Product Packagings*.
3.  Save.

Now, make sure the products you use for testing this module have some
packaging configured.
