To print sale order packaging data:

1.  Go to *Sales \> Orders \> Quotations* and pick or create one.
2.  Add some product(s) with packaging information (type and quantity).
3.  Print it.

To query sale packaging BI data:

1.  Go to *Sales \> Reporting*.
2.  Use the new options at will:
    - *Measures \> Packaging Qty*
    - *Measures \> Packaging Delivered Qty* (based on a ratio between
      *Qty Delivered* and *Packaging Qty*).
    - *Group By \> Packaging*.
