This module displays packaging data (quantity and type) in:

- Sale order printed reports.
- Sale BI reports.
