"""Python Factory Core Module."""

__version__ = "0.0.0"
